//---------------------------------------------------------------------------
#ifndef mainH
#define mainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Menus.hpp>
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>
#include <ToolWin.hpp>
#include "global.h"
#include <Buttons.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TOEditor : public TForm
{
__published:	// IDE-managed Components
        TMainMenu *MainMenu;
        TMenuItem *mFile;
        TMenuItem *mOpen;
        TMenuItem *mSave;
        TMenuItem *mLine;
        TMenuItem *mExit;
        TMenuItem *mAbout;
        TMenuItem *mHelp;
        TToolBar *ToolBar1;
        TToolButton *tbSeparator1;
        TSpeedButton *tbOpen;
        TSpeedButton *tbSave;
        TSpeedButton *tbExit;
        TToolButton *tbSeparator2;
        TSpeedButton *tbButton;
        TSpeedButton *tbTextEdit;
        TSpeedButton *tbLabel;
        TToolButton *tbSeparator3;
        TSpeedButton *tbHelp;
        TButton *baseButton;
        TLabel *baseLabel;
        TEdit *baseEdit;
        TPanel *helpPanel;
        TPopupMenu *OPopupMenu;
        TMenuItem *pmCreate;
        TMenuItem *pmButton;
        TMenuItem *pmTextEdit;
        TMenuItem *pmLabel;
        TMenuItem *pmDelete;
        TMenuItem *pmText;
        TPopupMenu *MPopupMenu;
        TMenuItem *pmOpen;
        TMenuItem *pmSave;
        TMenuItem *pmLine;
        TMenuItem *pmExit;
        TMenuItem *pmHelp;
        TOpenDialog *OpenDialog1;
        TSaveDialog *SaveDialog1;
        TSpeedButton *tbClear;
        TMenuItem *mClear;
        void __fastcall baseButtonMouseDown(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
        void __fastcall baseButtonMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
        void __fastcall baseButtonMouseUp(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
        void __fastcall tbExitClick(TObject *Sender);
        void __fastcall mOpenClick(TObject *Sender);
        void __fastcall FormResize(TObject *Sender);
        void __fastcall pmButtonClick(TObject *Sender);
        void __fastcall pmTextEditClick(TObject *Sender);
        void __fastcall pmLabelClick(TObject *Sender);
        void __fastcall pmTextClick(TObject *Sender);
        void __fastcall pmDeleteClick(TObject *Sender);
        void __fastcall mSaveClick(TObject *Sender);
        void __fastcall tbClearClick(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall tbHelpClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        void RepaintObject(TObject *Sender);
        void CreateNewButton(int X, int Y, int W, int H, AnsiString T);
        void CreateNewEdit(int X, int Y, int W, int H, AnsiString T);
        void CreateNewLabel(int X, int Y, int W, int H, AnsiString T);
        TObject *CoverObject(TObject *Sender);
        void AddNewObject(TObject *Sender);
        bool TransferObject(TObject *Sender);
        bool FindMinDelta(TObject *Sender, TObject *CovSender);
        void DeleteObject(TObject *Sender);
        void SaveToHTML(void);
        void SortObjects(void);
    __fastcall TOEditor(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TOEditor *OEditor;
//---------------------------------------------------------------------------
#endif
