//---------------------------------------------------------------------------
#ifndef wAboutH
#define wAboutH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
//---------------------------------------------------------------------------
class TAboutBox : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TLabel *Copyright;
        TLabel *Comments;
        TLabel *Label1;
        TLabel *Label4;
        TLabel *Label5;
        TButton *OKButton;
    TLabel *Label7;
    TLabel *Label8;
    TLabel *Label10;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label6;
    
private:	// User declarations
public:		// User declarations
        __fastcall TAboutBox(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TAboutBox *AboutBox;
//---------------------------------------------------------------------------
#endif
