//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "NewText.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TEnterNewText *EnterNewText;
//---------------------------------------------------------------------------
__fastcall TEnterNewText::TEnterNewText(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
