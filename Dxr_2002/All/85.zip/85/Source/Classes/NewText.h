//---------------------------------------------------------------------------

#ifndef NewTextH
#define NewTextH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TEnterNewText : public TForm
{
__published:	// IDE-managed Components
        TGroupBox *GroupBox1;
        TEdit *Edit1;
        TBitBtn *BitBtn1;
private:	// User declarations
public:		// User declarations
        __fastcall TEnterNewText(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TEnterNewText *EnterNewText;
//---------------------------------------------------------------------------
#endif
