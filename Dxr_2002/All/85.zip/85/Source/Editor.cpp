//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("Editor.res");
USEFORM("Classes\Main.cpp", OEditor);
USEFORM("Classes\NewText.cpp", EnterNewText);
USE("Classes\Global.h", File);
USEFORM("Classes\wAbout.cpp", AboutBox);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    try
    {
        Application->Initialize();
        Application->Title = "��������";
                 Application->CreateForm(__classid(TOEditor), &OEditor);
                 Application->CreateForm(__classid(TEnterNewText), &EnterNewText);
                 Application->CreateForm(__classid(TAboutBox), &AboutBox);
                 if(ParamCount() == 0)  Application->Run();
    }
    catch (Exception &exception)
    {
        Application->ShowException(&exception);
    }
    return 0;
}
//---------------------------------------------------------------------------
