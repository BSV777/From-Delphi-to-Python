/////////////////////////////////////////////////////////////////////////////
//
//  common.h
//
//  �������� �����������
//
/////////////////////////////////////////////////////////////////////////////
#ifndef commonH
#define commonH
/////////////////////////////////////////////////////////////////////////////

#define FormCaption "Woblin-Goblin HTML Form Editor"

#define MaxUndoRedoSize 10

#define min(a,b) ( ((a)<(b)) ? (a) : (b) )
#define max(a,b) ( ((a)>(b)) ? (a) : (b) )

/////////////////////////////////////////////////////////////////////////////

extern int GrabHandleSize;

typedef enum {otNone, otLabel, otButton, otTextEdit} TObjectType;

typedef enum {gtSmallDots, gtLargeDots, gtLines} TGridType;

typedef enum {
  ghtNone,
  ghtTopLeft,
  ghtTop,
  ghtTopRight,
  ghtLeft,
  ghtRight,
  ghtBottomLeft,
  ghtBottom,
  ghtBottomRight
} TGrabHandleType;

#define ghtFirst ghtTopLeft
#define ghtLast ghtBottomRight

typedef enum {
  ghoCreate, /*ghoParent,*/ ghoDestroy, ghoMove, ghoShow, ghoHide
} TGrabHandleOperation;

typedef enum {ostNone, ostLeft, ostTop} TObjectSortType;

typedef enum {
  atLefts=1, atTops=1,
  atCenters=2,
  atRights=3, atBottoms=3,
  atSpace=4,
  atCenter=5
} TAlignType;

typedef enum {stShrink=1, stGrow=2, stSet=3} TSizeType;

/////////////////////////////////////////////////////////////////////////////

typedef void __fastcall (__closure *TUndoRedoChangedEvent)(bool CanUndo, bool CanRedo);

typedef void __fastcall (__closure *TSelectedCountChangedEvent)(int Count);
typedef void __fastcall (__closure *TObjectCountChangedEvent)(int Count);
typedef void __fastcall (__closure *TClipboardChangedEvent)(int Count);

typedef void __fastcall (__closure *TUndoItemClickEvent)(int Pos);

/////////////////////////////////////////////////////////////////////////////

typedef enum {
  utChange, utAdd, utDelete
} TUndoType;

/////////////////////////////////////////////////////////////////////////////

TPoint GrabHandlePosition(TRect ControlRect, TGrabHandleType Type);
void OffsetPoint(TPoint &Point, int deltaX, int deltaY);
int RoundToNearest(int Value, int Step);

extern TCursor GrabHandleCursors[ghtLast-ghtFirst+1];

/////////////////////////////////////////////////////////////////////////////

class TUndoItem {
public:
    __fastcall TUndoItem(TUndoType fType, TMenuItem *fMenu);
    __fastcall ~TUndoItem();

    TUndoType Type;

    //  ������� ������������ ��������
    TMemoryStream *Mem;

    TUndoItemClickEvent OnClick;

    //  ������� �� ����������� ������ ��������
    //  (� ����������� �� Type �������� ���������� � �����������/���������
    //  �������� � ������� ������)
    TMemoryStream *Data;

    TMenuItem *MenuItem, *Menu;
    void __fastcall AddToMenu();
    void __fastcall RemoveFromMenu();

    __property AnsiString Description  = { read = FDescription, write = SetDescription };
private:
    AnsiString FDescription;
    void __fastcall SetDescription(AnsiString value);
    void __fastcall MenuItemClick(TObject * Sender);
};

/////////////////////////////////////////////////////////////////////////////

class TObjectList;

/////////////////////////////////////////////////////////////////////////////

class TEditObject {
private:
    TWinControl *Object;

    AnsiString FText;
    int FLeft;
    int FTop;
    int FWidth;
    int FHeight;
    TWinControl * FParent;

    void __fastcall SetText(AnsiString value);
    void __fastcall SetLeft(int value);
    void __fastcall SetTop(int value);
    void __fastcall SetWidth(int value);
    void __fastcall SetHeight(int value);
    void __fastcall SetParent(TWinControl * value);

    TRect __fastcall GetClientRect();
    HWND __fastcall GetHandle();

public:
    __fastcall TEditObject(TObjectType fType);
    __fastcall ~TEditObject();

    void __fastcall SetBounds(int ALeft, int ATop, int AWidth, int AHeight);
    void __fastcall BringToFront();
    void __fastcall SendToBack();

    TObjectType Type;
    void __fastcall Assign(TEditObject * Source);

    __property AnsiString Text  = { read = FText, write = SetText };
    __property int Left  = { read = FLeft, write = SetLeft };
    __property int Top  = { read = FTop, write = SetTop };
    __property int Width  = { read = FWidth, write = SetWidth };
    __property int Height  = { read = FHeight, write = SetHeight };
    __property TWinControl * Parent  = { read = FParent, write = SetParent };
    
    __property TRect ClientRect  = { read = GetClientRect };
    __property HWND Handle  = { read = GetHandle };

    TEditObject *IntersectWith;
    int EXPORT_Left, EXPORT_Top;
    // ��������������� ��� ������������� � ������� ��������
};

/////////////////////////////////////////////////////////////////////////////

class TGrabHandle : public TWinControl {
private:
    TGrabHandleType FType;
    
    void __fastcall SetType(TGrabHandleType value);
    TPoint __fastcall GetCenter();
    void __fastcall WMPaint(TMessage & Message);
    
public:
    __fastcall TGrabHandle(TWinControl *fParent, TGrabHandleType fType);
    
    void __fastcall ResetType(TRect Selection);
    void __fastcall Hide();
    void __fastcall Show();
    
    __property TGrabHandleType Type  = { read = FType, write = SetType };
    __property TPoint Center  = { read = GetCenter };
protected:
    BEGIN_MESSAGE_MAP
        VCL_MESSAGE_HANDLER(WM_PAINT, TMessage, WMPaint)
    END_MESSAGE_MAP(TWinControl)
};

/////////////////////////////////////////////////////////////////////////////

class TObjectList : public TList {
  protected:
	TEditObject * __fastcall Get(int Index) {return (TEditObject *)TList::Get(Index);};
	void __fastcall Put(int Index, TEditObject * Item) {TList::Put(Index, (void *)Item);};

  public:
    __fastcall TObjectList() : TList() {};

    __property TEditObject * Items[int Index] = { read = Get, write = Put };
};

/////////////////////////////////////////////////////////////////////////////

int __fastcall CompareLeft(void *Item1, void *Item2);
int __fastcall CompareTop(void *Item1, void *Item2);

/////////////////////////////////////////////////////////////////////////////

class TSortedObjectList : public TObjectList {
  public:
    __fastcall TSortedObjectList() : TObjectList() {SortType=ostNone;};
    __fastcall TSortedObjectList(TObjectSortType fSortType) : TObjectList()
      {SortType=fSortType;};

    TObjectSortType SortType;

    void __fastcall Sort() {
      switch (SortType) {
        case ostLeft: TList::Sort(CompareLeft); break;
        case ostTop: TList::Sort(CompareTop); break;
      }
    };
};

/////////////////////////////////////////////////////////////////////////////

class TUndoRedo : public TList {
  protected:
	TUndoItem * __fastcall Get(int Index) {return (TUndoItem *)TList::Get(Index);};
	void __fastcall Put(int Index, TUndoItem *Item) {TList::Put(Index, (void *)Item);};

  public:
    __fastcall TUndoRedo() : TList() {};

    __property TUndoItem *Items[int Index] = { read = Get, write = Put };
};
/////////////////////////////////////////////////////////////////////////////
#endif

