/////////////////////////////////////////////////////////////////////////////
//
//  main.cpp
//
//  ����� TMainForm (������� �����)
//
/////////////////////////////////////////////////////////////////////////////
#include <vcl.h>
#pragma hdrstop
/////////////////////////////////////////////////////////////////////////////
#include "common.h"
#include "editwindow.h"
#include "main.h"
#include "config.h"
#include "export.h"
#include "gridoptions.h"
#include "alignment.h"
#include "errors.h"
#include "size.h"
#include "about.h"
/////////////////////////////////////////////////////////////////////////////
#pragma package(smart_init)
#pragma resource "*.dfm"
/////////////////////////////////////////////////////////////////////////////

TMainForm *MainForm;

/////////////////////////////////////////////////////////////////////////////
//
//  TMainForm()
//
__fastcall TMainForm::TMainForm(TComponent* Owner)
    : TForm(Owner)
{
  ObjectProperties->ColWidths[0]=45;
  ObjectProperties->ColWidths[1]=PropertyEditor->ClientWidth-
    ObjectProperties->ColWidths[0]-ObjectProperties->GridLineWidth*3-4;
  ObjectProperties->Col=1;
  ObjectProperties->Enabled=false;
  
  for (int i=0; i<2; i++)
    for (int j=0; j<7; j++)
      ObjectProperties->Cols[i]->Add(" ");

  opPrevRow=-1;


  EditWindow=new TEditWindow(MainForm, EditArea, 1024, 768);
  EditWindow->UndoMenu=mEditUndoMul;
  EditWindow->OnUndoRedoChanged=UndoRedoChanged;
  EditWindow->OnClipboardChanged=ClipboardChanged;
  EditWindow->OnSelectedCountChanged=SelectedCountChanged;
  EditWindow->OnObjectCountChanged=ObjectCountChanged;
  EditWindow->ResetUndo();
//  EditWindow->ShowGrid=false;
//  EditWindow->GridType=gtLargeDots;
  EditWindow->HorizBar=HorizBar;
  EditWindow->VertBar=VertBar;
  EditWindow->ObjectProperties=ObjectProperties;
  EditWindow->opObjectType=ObjectType;
  EditWindow->Panels=StatusBar->Panels;
  EditWindow->btEdit=btEdit;
  EditWindow->SetPopupMenu(PopupMenu);
  UpdateScrollBars();

  Application->OnMessage=OnApplicationMessage;

  FileName="New Form";
  AskNameWhenSave=true;

  EditWindow->ResetObjectProperties();
  mEditRedo->ShortCut=ShortCut(Word('Z'),
    TShiftState() << ssCtrl << ssShift);
}

/////////////////////////////////////////////////////////////////////////////
//
//  ~TMainForm()
//
__fastcall TMainForm::~TMainForm()
{
  delete EditWindow;
}


/////////////////////////////////////////////////////////////////////////////
//
//  OnApplicationMessage()
//
//  ������������� ��� ��������� � hwnd ��������� � �������������� ��
//  � EditWindow, ��� �������� �������� ������� ��������� ���������������
//  �������� ���������
//
void __fastcall TMainForm::OnApplicationMessage(tagMSG &Msg, bool &Handled) {

  if (Msg.hwnd==EditWindow->Handle
      || GetParent(Msg.hwnd)==EditWindow->Handle) {
    Handled=EditWindow->HandleMessage(Msg);
  }
}

/////////////////////////////////////////////////////////////////////////////
//
//  VertBarChange()
//
void __fastcall TMainForm::VertBarChange(TObject *Sender)
{
  EditWindow->Top=-VertBar->Position;
}


/////////////////////////////////////////////////////////////////////////////
//
//  HorizBarChange()
//
void __fastcall TMainForm::HorizBarChange(TObject *Sender)
{
  EditWindow->Left=-HorizBar->Position;
}

/////////////////////////////////////////////////////////////////////////////
//
//  FormResize()
//
void __fastcall TMainForm::FormResize(TObject *Sender)
{
  if (!ComponentState.Contains(csDestroying)) {
    UpdateEditWindowPos();
    UpdateScrollBars();
  }
}

/////////////////////////////////////////////////////////////////////////////
//
//  UpdateEditWindowPos()
//
//  ���������� ��������� EditWindow �� EditArea, ���� ����������
//
void __fastcall TMainForm::UpdateEditWindowPos() {
  if (EditArea->Height>EditWindow->Height)
    EditWindow->Top=EditArea->Height/2-EditWindow->Height/2;
  if (EditArea->Width>EditWindow->Width)
    EditWindow->Left=EditArea->Width/2-EditWindow->Width/2;
}


/////////////////////////////////////////////////////////////////////////////
//
//  UpdateScrollBars()
//
void __fastcall TMainForm::UpdateScrollBars()
{
  if (EditArea->Height>EditWindow->Height)
    VertBar->Enabled=false;
  else {
    VertBar->Max=EditWindow->Height-EditArea->Height+2;
    VertBar->Enabled=true;
  }
  if (EditArea->Width>EditWindow->Width)
    HorizBar->Enabled=false;
  else {
    HorizBar->Max=EditWindow->Width-EditArea->Width+2;
    HorizBar->Enabled=true;
  }
}


/////////////////////////////////////////////////////////////////////////////
//
//  mInsertLabelClick()
//
void __fastcall TMainForm::mInsertLabelClick(TObject *Sender)
{
  btInsertLabel->Click();
  btInsertLabel->Down=true;
}


/////////////////////////////////////////////////////////////////////////////
//
//  mInsertTextEditClick()
//
void __fastcall TMainForm::mInsertTextEditClick(TObject *Sender)
{
  btInsertTextEdit->Click();
  btInsertTextEdit->Down=true;
}

/////////////////////////////////////////////////////////////////////////////
//
//  mInsertButtonClick()
//
void __fastcall TMainForm::mInsertButtonClick(TObject *Sender)
{
  btInsertButton->Click();
  btInsertButton->Down=true;
}


/////////////////////////////////////////////////////////////////////////////
//
//  btInsertLabelClick()
//
void __fastcall TMainForm::btInsertLabelClick(TObject *Sender)
{
  EditWindow->InsertingObject=otLabel;
  btInsertTextEdit->Marked=false;
  btInsertButton->Marked=false;
}


/////////////////////////////////////////////////////////////////////////////
//
//  btInsertTextEditClick()
//
void __fastcall TMainForm::btInsertTextEditClick(TObject *Sender)
{
  EditWindow->InsertingObject=otTextEdit;
  btInsertLabel->Marked=false;
  btInsertButton->Marked=false;
}


/////////////////////////////////////////////////////////////////////////////
//
//  btInsertButtonClick()
//
void __fastcall TMainForm::btInsertButtonClick(TObject *Sender)
{
  EditWindow->InsertingObject=otButton;
  btInsertLabel->Marked=false;
  btInsertTextEdit->Marked=false;
}


/////////////////////////////////////////////////////////////////////////////
//
//  btEditClick()
//
void __fastcall TMainForm::btEditClick(TObject *Sender)
{
  EditWindow->InsertingObject=otNone;
  btInsertLabel->Marked=false;
  btInsertTextEdit->Marked=false;
  btInsertButton->Marked=false;
}


/////////////////////////////////////////////////////////////////////////////
//
//  btInsertLabelMouseDown()
//
void __fastcall TMainForm::btInsertLabelMouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
  EditWindow->InsertingObject=otLabel;
  EditWindow->NeedToPressBtEdit=true;
  if (Shift.Contains(ssShift)) {
    btInsertLabel->Marked=true;
    EditWindow->NeedToPressBtEdit=false;
  }
}


/////////////////////////////////////////////////////////////////////////////
//
//  btInsertTextEditMouseDown()
//
void __fastcall TMainForm::btInsertTextEditMouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
  EditWindow->InsertingObject=otTextEdit;
  EditWindow->NeedToPressBtEdit=true;
  if (Shift.Contains(ssShift)) {
    btInsertTextEdit->Marked=true;
    EditWindow->NeedToPressBtEdit=false;
  }
}


/////////////////////////////////////////////////////////////////////////////
//
//  btInsertButtonMouseDown()
//
void __fastcall TMainForm::btInsertButtonMouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
  EditWindow->InsertingObject=otButton;
  EditWindow->NeedToPressBtEdit=true;
  if (Shift.Contains(ssShift)) {
    btInsertButton->Marked=true;
    EditWindow->NeedToPressBtEdit=false;
  }
}


/////////////////////////////////////////////////////////////////////////////
//
//  ObjectPropertiesSelectCell()
//
void __fastcall TMainForm::ObjectPropertiesSelectCell(TObject *Sender,
      int ACol, int ARow, bool &CanSelect)
{
  int temp_GiveMeTheWarning;
  AnsiString Value;

  CanSelect=true;
  if (ACol==0) CanSelect=false;
  if (opPrevRow!=-1) {
    Value=ObjectProperties->Cols[1]->Strings[opPrevRow];
    if (opPrevRow>0 && Value!="")
      try {
        temp_GiveMeTheWarning=StrToInt(Value);
      }
      catch (EConvertError &e) {
        Application->MessageBox(e.Message.c_str(),
          FormCaption, MB_OK | MB_ICONERROR);
        CanSelect=false;
        return;
      }
    EditWindow->SetObjectProperties(opPrevRow, Value);
    opPrevRow=-1;
  }
}


/////////////////////////////////////////////////////////////////////////////
//
//  ObjectPropertiesKeyPress()
//
void __fastcall TMainForm::ObjectPropertiesKeyPress(TObject *Sender,
      char &Key)
{
  bool temp;

  switch (Key) {
    case '\x1b':
      if (opPrevRow!=-1) {
        EditWindow->ResetObjectProperties();
        opPrevRow=-1;
      }
      break;
    case '\x0D':
      ObjectPropertiesSelectCell(Sender,
        ObjectProperties->Col,
        ObjectProperties->Row,
        temp);
      break;
    default:
      opPrevRow=ObjectProperties->Row;
  }
}


/////////////////////////////////////////////////////////////////////////////
//
//  mEditCopyClick()
//
void __fastcall TMainForm::mEditCopyClick(TObject *Sender)
{
  EditWindow->CopyToClipboard();
}


/////////////////////////////////////////////////////////////////////////////
//
//  mEditCutClick()
//
void __fastcall TMainForm::mEditCutClick(TObject *Sender)
{
  EditWindow->CutToClipboard();
}


/////////////////////////////////////////////////////////////////////////////
//
//  mEditPasteClick()
//
void __fastcall TMainForm::mEditPasteClick(TObject *Sender)
{
  EditWindow->PasteFromClipboard();
}


/////////////////////////////////////////////////////////////////////////////
//
//  mEditDeleteClick()
//
void __fastcall TMainForm::mEditDeleteClick(TObject *Sender)
{
  EditWindow->DeleteSelectedObjects();
}


/////////////////////////////////////////////////////////////////////////////
//
//  actSelectAllExecute()
//
void __fastcall TMainForm::actSelectAllExecute(TObject *Sender)
{
  EditWindow->SelectAll();
}


///////////////////////////////////////////////////////////////////////////////
//
//  ShowSaveDialog()
//
//  ���������� ������ ���������� �����
//  ���������� 0, ���� ������������ �� ������ ����
//
int __fastcall TMainForm::ShowSaveDialog() {
  if (SaveDialog->Execute()) {
    FileName=SaveDialog->FileName;
    AskNameWhenSave=false;
    return 1;
  }
  return 0;
}


/////////////////////////////////////////////////////////////////////////////
//
//  mFileSaveAsClick()
//
void __fastcall TMainForm::mFileSaveAsClick(TObject *Sender)
{
  if (ShowSaveDialog())
    EditWindow->SaveToFile(FileName);

}


/////////////////////////////////////////////////////////////////////////////
//
//  mFileSaveClick()
//
void __fastcall TMainForm::mFileSaveClick(TObject *Sender)
{
  if (AskNameWhenSave) {
    mFileSaveAsClick(Sender);
  } else
    EditWindow->SaveToFile(FileName);
}


/////////////////////////////////////////////////////////////////////////////
//
//  CloseConfirm()
//
//  ���������� 0, ���� ������� ���� ��������� ������, ��������
//  ������������ ��� �������������
//
int __fastcall TMainForm::CloseConfirm()
{
  AnsiString Message;

  if (EditWindow->Modified) {
    Message="��������� ��������� � "+ExtractFileName(FileName)+"?";
    switch (Application->MessageBox(Message.c_str(),
              FormCaption, MB_YESNOCANCEL | MB_ICONWARNING)) {
      case IDNO:
        return 1;
      case IDYES:
        mFileSaveClick(this);
        break;
    }
  }
  if (!EditWindow->Modified)
    return 1;
  else
    return 0;
}


/////////////////////////////////////////////////////////////////////////////
//
//  FormClose()
//
//  ���������� ��� �������� �����
//
void __fastcall TMainForm::FormClose(TObject *Sender, TCloseAction &Action)
{
  if (CloseConfirm())
    Action=caFree;
  else
    Action=caNone;
}


/////////////////////////////////////////////////////////////////////////////
//
//  mExitClick()
//
void __fastcall TMainForm::mExitClick(TObject *Sender)
{
  Close();
}


/////////////////////////////////////////////////////////////////////////////
//
//  mFileNewClick()
//
void __fastcall TMainForm::mFileNewClick(TObject *Sender)
{
  if (!CloseConfirm())
    return;
  EditWindow->SelectAll();
  EditWindow->DeleteSelectedObjects();
  EditWindow->Modified=false;
  EditWindow->ResetUndo();
  
  FileName="New Form";
  AskNameWhenSave=true;
}


/////////////////////////////////////////////////////////////////////////////
//
//  mFileOpenClick()
//
void __fastcall TMainForm::mFileOpenClick(TObject *Sender)
{
  TStringList *Errors;

  if (!CloseConfirm())
    return;

  if (OpenDialog->Execute()) {
    EditWindow->SelectAll();
    EditWindow->DeleteSelectedObjects();
    EditWindow->Modified=false;
    AskNameWhenSave=false;
    Errors=new TStringList();
    if (LoadObjectsFromFile(OpenDialog->FileName, EditWindow->Objects, Errors)) {
      FileName=OpenDialog->FileName;
      EditWindow->ResetUndo();
      EditWindow->UpdateObjectCount();
      EditWindow->SetObjectsParent();
    }
    if (Errors->Count>0)
      if (Application->MessageBox("��� �������� ����� �������� ������,\n�������, ��������, ������� ���������.\n������ �� ����������?",
        FormCaption, MB_YESNO | MB_ICONERROR)==IDYES) {
        ErrorsForm->Errors->Lines->Assign(Errors);
        ErrorsForm->ShowModal();
      }
    delete Errors;
  }

}


/////////////////////////////////////////////////////////////////////////////
//
//  SetFileName()
//
//  Put method for FileName
//
//  ������������� ��� �������� ����� ������������
//  � ��������������� ���������
//
void __fastcall TMainForm::SetFileName(AnsiString value)
{
    FFileName = value;
    Caption=ExtractFileName(FFileName)+" - "+FormCaption;
}


/////////////////////////////////////////////////////////////////////////////
//
//  mHelpAboutClick()
//
void __fastcall TMainForm::mHelpAboutClick(TObject *Sender)
{
  AboutForm=new TAboutForm(this);
  AboutForm->ShowModal();
  delete AboutForm;
}


/////////////////////////////////////////////////////////////////////////////
//
//  GridOptionsExecute()
//
void __fastcall TMainForm::actGridOptionsExecute(TObject *Sender)
{
  GridOptionsForm=new TGridOptionsForm(this);
  try {
    GridOptionsForm->XStep->Text=IntToStr(EditWindow->XGridStep);
    GridOptionsForm->YStep->Text=IntToStr(EditWindow->YGridStep);
    GridOptionsForm->GridMarker->ItemIndex=EditWindow->GridType;
    GridOptionsForm->VisibleGrid->Checked=EditWindow->ShowGrid;

    if (GridOptionsForm->ShowModal()==mrOk) {
      EditWindow->XGridStep=StrToInt(GridOptionsForm->XStep->Text);
      EditWindow->YGridStep=StrToInt(GridOptionsForm->YStep->Text);
      EditWindow->GridType=(TGridType)GridOptionsForm->GridMarker->ItemIndex;
      EditWindow->ShowGrid=GridOptionsForm->VisibleGrid->Checked;
      InvalidateRect(EditWindow->Handle, NULL, true);
    }
  }
  catch (EConvertError &e) {
    Application->MessageBox(e.Message.c_str(),
      FormCaption, MB_OK | MB_ICONERROR);
  }
  delete GridOptionsForm;
}

/////////////////////////////////////////////////////////////////////////////
//
//  BringToFrontExecute()
//
void __fastcall TMainForm::actBringToFrontExecute(TObject *Sender)
{
  EditWindow->BringToFrontSelection();
}


/////////////////////////////////////////////////////////////////////////////
//
//  SendToBackExecute()
//
void __fastcall TMainForm::actSendToBackExecute(TObject *Sender)
{
  EditWindow->SendToBackSelection();
}


/////////////////////////////////////////////////////////////////////////////
//
//  AlignObjectsExecute()
//
void __fastcall TMainForm::actAlignObjectsExecute(TObject *Sender)
{
  AlignForm=new TAlignForm(this);

  if (AlignForm->ShowModal()==mrOk)
    EditWindow->AlignSelectedObjects((TAlignType)AlignForm->HorizontalAlignment->ItemIndex,
      (TAlignType)AlignForm->VerticalAlignment->ItemIndex);

  delete AlignForm;
}


/////////////////////////////////////////////////////////////////////////////
//
//  SizeOfObjectsExecute()
//
void __fastcall TMainForm::actSizeOfObjectsExecute(TObject *Sender)
{
  int Width, Height;

  SizeForm=new TSizeForm(this);

  if (SizeForm->ShowModal()==mrOk) {
    if (SizeForm->SizeWidth->Text=="")
      SizeForm->SizeWidth->Text="0";
    if (SizeForm->SizeHeight->Text=="")
      SizeForm->SizeHeight->Text="0";

    try {
      Width=StrToInt(SizeForm->SizeWidth->Text);
      Height=StrToInt(SizeForm->SizeHeight->Text);
      EditWindow->SizeSelectedObjects(
        (TSizeType)SizeForm->HorizontalSize->ItemIndex,
        (TSizeType)SizeForm->VerticalSize->ItemIndex,
        Width, Height);
    }
    catch (EConvertError &e) {
        Application->MessageBox(e.Message.c_str(),
          FormCaption, MB_OK | MB_ICONERROR);
    }
  }

  delete SizeForm;
}

/////////////////////////////////////////////////////////////////////////////
//
//  mExportHTMLClick()
//
void __fastcall TMainForm::mExportHTMLClick(TObject *Sender)
{
  TStringList *Errors=new TStringList();
  if (ExportDialog->Execute()) {
    if (!ExportObjectsToFile(ExportDialog->FileName,
      EditWindow->Objects, Errors)) {

      if (Application->MessageBox("��� �������� � HTML �������� ������. ������ �� ����������?",
        FormCaption, MB_YESNO | MB_ICONERROR)==IDYES) {
        ErrorsForm->Errors->Lines->Assign(Errors);
        ErrorsForm->ShowModal();
      }
    }
  }
  delete Errors;
}


///////////////////////////////////////////////////////////////////////////////
//
//  mEditUndoClick();
//
void __fastcall TMainForm::mEditUndoClick(TObject *Sender)
{
  EditWindow->Undo(EditWindow->UndoRedoPos-1);
}


/////////////////////////////////////////////////////////////////////////////
//
//  mEditRedoClick()
//
void __fastcall TMainForm::mEditRedoClick(TObject *Sender)
{
  EditWindow->Undo(EditWindow->UndoRedoPos+1);
}


/////////////////////////////////////////////////////////////////////////////
//
//  UndoRedoChanged()
//
//  ��������� ��� ��������� ������� Undo-���������
//
void __fastcall TMainForm::UndoRedoChanged(bool CanUndo, bool CanRedo)
{
  if (CanUndo)
    mEditUndo->Enabled=true;
  else
    mEditUndo->Enabled=false;

  if (CanRedo || CanUndo) {
    mEditUndoMul->Enabled=true;
    UndoButton->Enabled=true;
  } else {
    UndoButton->Enabled=false;
    mEditUndoMul->Enabled=false;
  }

  if (CanRedo) {
    mEditRedo->Enabled=true;
    RedoButton->Enabled=true;
  } else {
    mEditRedo->Enabled=false;
    RedoButton->Enabled=false;
  }

//  RedoButton->Down=false;
//  UndoButton->Down=false;
}


/////////////////////////////////////////////////////////////////////////////
//
//  UndoButtonClick()
//
void __fastcall TMainForm::UndoButtonClick(TObject *Sender)
{
  if (mEditUndo->Enabled)
    mEditUndo->Click();
}


/////////////////////////////////////////////////////////////////////////////
//
//  ClipboardChanged()
//
//  ���������� ��� ��������� ��������� ������ ������
//
void __fastcall TMainForm::ClipboardChanged(int Count)
{
  bool flag;

  if (Count>0)
    flag=true;
  else
    flag=false;

  mEditPaste->Enabled=flag;
  PasteButton->Enabled=flag;

  //PasteButton->Down=false;
}


/////////////////////////////////////////////////////////////////////////////
//
//  SelectedCountChanged()
//
//  ���������� ��� ��������� ���������� ���������� ��������
//
void __fastcall TMainForm::SelectedCountChanged(int Count)
{
  bool flag;

  if (Count>0)
    flag=true;
  else
    flag=false;

  mEditCopy->Enabled=flag;
  mEditCut->Enabled=flag;
  mEditDelete->Enabled=flag;

  CopyButton->Enabled=flag;
  CutButton->Enabled=flag;
  DeleteButton->Enabled=flag;

  // CopyButton->Down=false;
  // CutButton->Down=false;
  // DeleteButton->Down=false;

  /*
  mEditAlignToGrid->Enabled=flag;
  mEditAlign->Enabled=flag;
  mEditSizeObjects->Enabled=flag;

  pAlignToGrid->Enabled=flag;
  pAlign->Enabled=flag;
  pSizeObjects->Enabled=flag;

  mEditBringToFront->Enabled=flag;
  mEditSendToBack->Enabled=flag;

  pBringToFront->Enabled=flag;
  pSendToBack->Enabled=flag;

  BringToFrontButton->Enabled=flag;
  SendToBackButton->Enabled=flag;

  BringToFrontButton->Down=false;
  SendToBackButton->Down=false;
  */
  actAlignToGrid->Enabled=flag;
  actAlignObjects->Enabled=flag;
  actSizeOfObjects->Enabled=flag;
  actSendToBack->Enabled=flag;
  actBringToFront->Enabled=flag;
}


/////////////////////////////////////////////////////////////////////////////
//
//  ObjectCountChanged()
//
//  ���������� ��� ��������� ���������� ������������� ��������
//
void __fastcall TMainForm::ObjectCountChanged(int Count)
{
  bool flag;

  if (Count>0)
    flag=true;
  else
    flag=false;

  /*
  mEditSelectAll->Enabled=flag;
  SelectAllButton->Enabled=flag;

  SelectAllButton->Down=false;
  */
  actSelectAll->Enabled=flag;
}


/////////////////////////////////////////////////////////////////////////////
//
//  AlignToGridExecute()
//
void __fastcall TMainForm::actAlignToGridExecute(TObject *Sender)
{
  EditWindow->AlignToGridSelectedObjects();
}

/////////////////////////////////////////////////////////////////////////////
//
//  mHelpContentsClick()
//
void __fastcall TMainForm::mHelpContentsClick(TObject *Sender)
{
  Application->HelpCommand(HELP_CONTENTS, 0);
}

