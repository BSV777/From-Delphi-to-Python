/////////////////////////////////////////////////////////////////////////////
//
//  export.cpp
//
//  ��������� ������� �������� � HTML
//
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
#include <vcl.h>
#pragma hdrstop
/////////////////////////////////////////////////////////////////////////////
#include <string.h>
#include "common.h"
#include "export.h"
/////////////////////////////////////////////////////////////////////////////
#pragma package(smart_init)
/////////////////////////////////////////////////////////////////////////////

#define ReallocNumber 10

#define SHIM_LEN 43

unsigned char SHIM[SHIM_LEN]={
  0x47,0x49,0x46,0x38,0x39,0x61,0x01,0x00,
  0x01,0x00,0x80,0x00,0x00,0xFF,0xFF,0xFF,
  0x00,0x00,0x00,0x21,0xF9,0x04,0x01,0x14,
  0x00,0x00,0x00,0x2C,0x00,0x00,0x00,0x00,
  0x01,0x00,0x01,0x00,0x00,0x02,0x02,0x44,
  0x01,0x00,0x3B
}; // magiq sequense ;)

struct TColList {
  int ColSpan, RowSpan, Col;
  TEditObject *Object;
  TColList *Next, *Prev;
} **Rows;

struct _MATRIX {
  int MaxRight, MaxDown, MaxLeft, MaxUp;
  TEditObject *Object;
  TColList *Col;
} **MATRIX;

// ��������� ������������ �����
int *XX, *YY, nXX, nYY; // all coords of objects
int *X, *Y, nX, nY, nMaxX, nMaxY; // the same, but sorted & w/o dups

bool NeedRebuild;

/////////////////////////////////////////////////////////////////////////////
//
//  SortArray()
//
void SortArray(int **Array, int Left, int Right) {
  int i=Left, j=Right, y, x=(*Array)[(i+j)/2];
  do {
    while ((*Array)[i]<x) i++;
    while (x<(*Array)[j]) j--;
    if (i<=j) {
      y=(*Array)[i];
      (*Array)[i]=(*Array)[j];
      (*Array)[j]=y;
      i++; j--;
    }
  } while (i<=j);
  if (Left<j) SortArray(Array, Left, j);
  if (i<Right) SortArray(Array, i, Right);
}


/////////////////////////////////////////////////////////////////////////////
//
//  FreeMatrix()
//
//  ��������������� ������� ��� ExportObjectsToFile()
//
void FreeMatrix() {
  for (int i=0; i<nY; i++)
    SysFreeMem(MATRIX[i]);
  SysFreeMem(MATRIX);
  SysFreeMem(X);
  SysFreeMem(Y);
}


/////////////////////////////////////////////////////////////////////////////
//
//  GetMatrix()
//
//  ��������������� ������� ��� ExportObjectsToFile()
//
void GetMatrix(TObjectList *Objects) {
  TEditObject *Object;
  int i, j;

  // getting arrays with all coords of objects
  nXX=nYY=1;
  XX=(int *)SysGetMem(Objects->Count*2*sizeof(int)+1);
  YY=(int *)SysGetMem(Objects->Count*2*sizeof(int)+1);
  XX[0]=0;
  YY[0]=0;
  for (i=0; i<Objects->Count; i++) {
    Object=Objects->Items[i];
    XX[nXX++]=Object->EXPORT_Left;
    XX[nXX++]=Object->EXPORT_Left+Object->Width;
    YY[nYY++]=Object->EXPORT_Top;
    YY[nYY++]=Object->EXPORT_Top+Object->Height;
  }

  // sorting arrays
  SortArray(&XX, 0, nXX-1);
  SortArray(&YY, 0, nYY-1);

  // deleting dups
  nX=nY=0;
  nMaxX=nMaxY=ReallocNumber;
  X=(int *)SysGetMem(nMaxX*sizeof(int));
  Y=(int *)SysGetMem(nMaxY*sizeof(int));

  i=0;
  while (i<nXX) {
    while (i<nXX-1 && XX[i]==XX[i+1]) i++;
    if (nX+1>nMaxX) {
      nMaxX+=ReallocNumber;
      X=(int *)SysReallocMem(X, nMaxX*sizeof(int));
    }
    X[nX++]=XX[i++];
  }

  i=0;
  while (i<nYY) {
    while (i<nYY-1 && YY[i]==YY[i+1]) i++;
    if (nY+1>nMaxY) {
      nMaxY+=ReallocNumber;
      Y=(int *)SysReallocMem(Y, nMaxY*sizeof(int));
    }
    Y[nY++]=YY[i++];
  }

  SysFreeMem(XX);
  SysFreeMem(YY);

  MATRIX=(struct _MATRIX **)SysGetMem(nY*sizeof(struct _MATRIX *));
  for (i=0; i<nY; i++) {
    MATRIX[i]=(struct _MATRIX *)SysGetMem(nX*sizeof(struct _MATRIX));
    for (j=0; j<nX; j++) {
      MATRIX[i][j].Col=NULL;
      MATRIX[i][j].MaxLeft=MATRIX[i][j].MaxUp=-1;
      MATRIX[i][j].MaxRight=MATRIX[i][j].MaxDown=0;
      MATRIX[i][j].Object=NULL;
    }
  }

  // mapping Objects to MATRIX
  int StartX, EndX, StartY, EndY; // object bounds in HTML table
  int left, right, pos, end, cur; // binary search vars

  for (i=0; i<Objects->Count; i++) {
    Object=Objects->Items[i];

    // applying binary search to...
    // ... Left border
    left=0; right=nX;
    end=Object->EXPORT_Left;
    do {
      pos=(left+right)/2;
      cur=X[pos];
      if (cur>=end)
        right=pos;
      else
        left=pos;
    } while (cur!=end);
    StartX=pos;

    // ...Right border
    left=0; right=nX;
    end=Object->EXPORT_Left+Object->Width;
    do {
      pos=(left+right)/2;
      cur=X[pos];
      if (cur>=end)
        right=pos;
      else
        left=pos;
    } while (cur!=end);
    EndX=pos;

    // ...Top border
    left=0; right=nY;
    end=Object->EXPORT_Top;
    do {
      pos=(left+right)/2;
      cur=Y[pos];
      if (cur>=end)
        right=pos;
      else
        left=pos;
    } while (cur!=end);
    StartY=pos;

    // ...Bottom border
    left=0; right=nY;
    end=Object->EXPORT_Top+Object->Height;
    do {
      pos=(left+right)/2;
      cur=Y[pos];
      if (cur>=end)
        right=pos;
      else
        left=pos;
    } while (cur!=end);
    EndY=pos;

    MATRIX[EndY-1][EndX-1].MaxLeft=EndX-StartX-1;
    MATRIX[EndY-1][EndX-1].MaxUp=EndY-StartY-1;
    if (MATRIX[EndY-1][EndX-1].Object!=NULL) {
      Object->IntersectWith=MATRIX[EndY-1][EndX-1].Object;
      NeedRebuild=true;
    }
    MATRIX[EndY-1][EndX-1].Object=Object;
  }
}


/////////////////////////////////////////////////////////////////////////////
//
//  ExportObjectsToFile()
//
//  ������������ ������� � HTML-�������
//
bool ExportObjectsToFile(AnsiString FileName, TObjectList *Objects, TStringList *Errors) {
  int i, j;
  TEditObject *Object, *Object2;
  int fd;

  // ���������� shim.gif
  fd=FileCreate(ExtractFilePath(FileName)+"shim.gif");
  if (fd==-1) {
    Errors->Add("���������� ������� ���� "+
      ExtractFilePath(FileName)+"shim.gif");
    return false;
  }
  FileWrite(fd, SHIM, SHIM_LEN);
  FileClose(fd);

  fd=FileCreate(FileName);
  if (fd==-1) {
    Errors->Add("���������� �������� ���� "+FileName);
    return false;
  }

  for (i=0; i<Objects->Count; i++) {
    Object=Objects->Items[i];
    Object->EXPORT_Left=Object->Left;
    Object->EXPORT_Top=Object->Top;
  }

  // extending object colspans and rowspans
  // and moving intersected objects to the
  // proper list
  do {
    for (i=0; i<Objects->Count; i++)
      Objects->Items[i]->IntersectWith=NULL;

    NeedRebuild=false;
    GetMatrix(Objects);

    for (i=nY-2; i>=0; i--)
      if (NeedRebuild)
        break;
      else for (j=nX-2; j>=0; j--) {

        if (MATRIX[i+1][j].MaxUp>0 && MATRIX[i][j+1].MaxLeft>0) {
          if (MATRIX[i+1][j].Object!=MATRIX[i][j+1].Object) {
            MATRIX[i+1][j].Object->IntersectWith=MATRIX[i][j+1].Object;
            NeedRebuild=true;
            break;
          }
        }

        if (MATRIX[i+1][j].MaxUp>0) {
          MATRIX[i][j].MaxUp=MATRIX[i+1][j].MaxUp-1;
          MATRIX[i][j].MaxDown=MATRIX[i+1][j].MaxDown+1;
          if (MATRIX[i][j].Object!=NULL) {
            MATRIX[i+1][j].Object->IntersectWith=MATRIX[i][j].Object;
            NeedRebuild=true;
            break;
          }
          MATRIX[i][j].Object=MATRIX[i+1][j].Object;
          MATRIX[i][j].MaxLeft=MATRIX[i+1][j].MaxLeft;
          MATRIX[i][j].MaxRight=MATRIX[i+1][j].MaxRight;
        } else if (MATRIX[i][j+1].MaxLeft>0) {
          MATRIX[i][j].MaxLeft=MATRIX[i][j+1].MaxLeft-1;
          MATRIX[i][j].MaxRight=MATRIX[i][j+1].MaxRight+1;
          if (MATRIX[i][j].Object!=NULL) {
            MATRIX[i][j+1].Object->IntersectWith=MATRIX[i][j].Object;
            NeedRebuild=true;
            break;
          }
          MATRIX[i][j].Object=MATRIX[i][j+1].Object;
          MATRIX[i][j].MaxUp=MATRIX[i][j+1].MaxUp;
          MATRIX[i][j].MaxDown=MATRIX[i][j+1].MaxDown;
        }
      } // else for

    // ���������� �������������� �������
    if (NeedRebuild)
      for (i=0; i<Objects->Count; i++) {
        Object=Objects->Items[i];
        if (Object->IntersectWith!=NULL) {
          Object2=Object->IntersectWith;
          if (Object2->EXPORT_Left+Object2->Width-Object->EXPORT_Left <
              Object2->EXPORT_Top+Object2->Height-Object->EXPORT_Top) {
            // ������� ������ �����
            Object2->EXPORT_Left=Object->EXPORT_Left-Object2->Width;
          } else {
            // ������� ������ �����
            Object2->EXPORT_Top=Object->EXPORT_Top-Object2->Height;
          }
          FreeMatrix();
          break;
        }
      } // for
      
  } while (NeedRebuild);

  bool TempFlag;
  TColList *TempCol;

  Rows=(TColList **)SysGetMem(nY*sizeof(TColList *));
  for (i=0; i<nY; i++)
    Rows[i]=NULL;

  // main idea
  for (i=nY-2; i>=0; i--) {
    for (j=nX-2; j>=-1; j--) {
      TempFlag=false;
      if (j!=-1) {
        TempFlag=MATRIX[i][j].Object!=MATRIX[i][j+1].Object;
      }
      if (TempFlag || j==nX-2 || j==-1) {
        if (j!=nX-2 && i!=nY-2) {
          // ���������� ������ ������� � ������� rowspan
          TempCol=MATRIX[i+1][j+1].Col;
          if (Rows[i]->Object==TempCol->Object
              && Rows[i]->Col==TempCol->Col
              && Rows[i]->ColSpan==TempCol->ColSpan) {
              Rows[i]->RowSpan+=TempCol->RowSpan;

              // ������� ������ ��� ������� ������� �������
              if (TempCol->Prev!=NULL)
                TempCol->Prev->Next=TempCol->Next;
              else {
                if (TempCol->Next!=NULL)
                  TempCol->Next->Prev=NULL;
                Rows[i+1]=TempCol->Next;
              }
              SysFreeMem(TempCol);
          }
        }

        if (j!=-1) {
          TempCol=(TColList *)SysGetMem(sizeof(TColList));
          TempCol->ColSpan=TempCol->RowSpan=1;
          TempCol->Object=MATRIX[i][j].Object;
          TempCol->Col=j;
          TempCol->Next=Rows[i];
          TempCol->Prev=NULL;
          if (Rows[i]!=NULL)
            Rows[i]->Prev=TempCol;
          Rows[i]=TempCol;
          MATRIX[i][j].Col=TempCol;
        }
      } else {
        // ���������� ������ ������� � ������� colspan
        if (j!=-1) {
          Rows[i]->ColSpan++;
          MATRIX[i][j].Col=Rows[i];
        }
      }
    }
  }

  // ������� ������ � HTML
  AnsiString CurStr, ObjStr, ObjName, SpanStr;

  CurStr="<html><head>\r\n<title>Woblin-Goblin Exported Form</title>\r\n";
  CurStr+="</head><body bgcolor=#ffffff topmargin=0 leftmargin=0>\r\n";
  CurStr+="<form><table border=0 cellpadding=0 cellspacing=0 width="
    +IntToStr(X[nX-1])+">\r\n";
  FileWrite(fd, CurStr.c_str(), CurStr.Length());

  CurStr="<tr>\r\n";
  FileWrite(fd, CurStr.c_str(), CurStr.Length());
  // shim row
  for (i=0; i<nX-1; i++) {
    CurStr="  <td><img src=shim.gif width="+IntToStr(X[i+1]-X[i])+" height=1 border=0></td>\r\n";
    FileWrite(fd, CurStr.c_str(), CurStr.Length());
  }
  CurStr="  <td><img src=shim.gif width=1 height=1 border=0></td>\r\n";
  FileWrite(fd, CurStr.c_str(), CurStr.Length());
  CurStr="</tr>\r\n";
  FileWrite(fd, CurStr.c_str(), CurStr.Length());

  for (i=0; i<nY-1; i++) {
    CurStr="<tr valign=top>\r\n";
    FileWrite(fd, CurStr.c_str(), CurStr.Length());
    TempCol=Rows[i];
    while (TempCol!=NULL) {
      if (TempCol->Object==NULL) {
        ObjStr="<img src=shim.gif width=1 height=1 border=0>";
      } else {
        switch (TempCol->Object->Type) {
          case otButton:
            ObjName="button";
            break;
          case otTextEdit:
            ObjName="text";
            break;
          case otLabel:
            ObjName="label";
            break;
        }
        if (ObjName=="label") {
          ObjStr=TempCol->Object->Text;
        } else {
          ObjStr="<input type="+ObjName+
            " style=\"width:"+(TempCol->Object->Width)+";height:"+
            (TempCol->Object->Height)+";\" value=\""+
            TempCol->Object->Text+"\">";
        }
      }
      SpanStr="";
      if (TempCol->RowSpan>1)
        SpanStr+=" rowspan="+IntToStr(TempCol->RowSpan);
      if (TempCol->ColSpan>1)
        SpanStr+=" colspan="+IntToStr(TempCol->ColSpan);
      CurStr="  <td"+SpanStr+">"+ObjStr+"</td>\r\n";
      FileWrite(fd, CurStr.c_str(), CurStr.Length());
      TempCol=TempCol->Next;
    }
    CurStr="  <td><img src=shim.gif width=1 height="
      +IntToStr(Y[i+1]-Y[i])+" border=0></td>\r\n";
    FileWrite(fd, CurStr.c_str(), CurStr.Length());
    CurStr="</tr>\r\n";
    FileWrite(fd, CurStr.c_str(), CurStr.Length());
  }
  CurStr="</table></form></body></html>\r\n";
  FileWrite(fd, CurStr.c_str(), CurStr.Length());
  FileClose(fd);


  // ��������� ������
  FreeMatrix();

  // glucks?
  for (i=0; i<nY-1; i++) {
    TempCol=Rows[i];
    while (TempCol!=NULL) {
      if (TempCol->Prev!=NULL)
        SysFreeMem(TempCol->Prev);
      if (TempCol->Next==NULL) {
        SysFreeMem(TempCol);
        TempCol=NULL;
      } else
        TempCol=TempCol->Next;
    }
  }

  SysFreeMem(Rows);

  return true;
}
