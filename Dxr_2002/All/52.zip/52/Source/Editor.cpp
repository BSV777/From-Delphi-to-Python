/////////////////////////////////////////////////////////////////////////////
//
//  Editor.cpp
//
//  �������� WinMain
//
/////////////////////////////////////////////////////////////////////////////
#include <vcl.h>
#include <stdio.h>
#pragma hdrstop
/////////////////////////////////////////////////////////////////////////////
#include "common.h"
#include "config.h"
#include "export.h"
#include "errors.h"
/////////////////////////////////////////////////////////////////////////////
USERES("Editor.res");
USEFORM("main.cpp", MainForm);
USEUNIT("common.cpp");
USEUNIT("editwindow.cpp");
USEUNIT("config.cpp");
USEUNIT("export.cpp");
USEFORM("gridoptions.cpp", GridOptionsForm);
USEFORM("alignment.cpp", AlignForm);
USEFORM("errors.cpp", ErrorsForm);
USEFORM("size.cpp", SizeForm);
USEFORM("about.cpp", AboutForm);

/////////////////////////////////////////////////////////////////////////////
//
//  WinMain()
//
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
  AnsiString ConfigName, ExportName;
  TStringList *Errors;
  TObjectList *Objects;

  if (ParamCount()!=2) {
    try {
      Application->Initialize();
      Application->Title = "HTML Form Editor";
      Application->HelpFile = "Editor.hlp";
      Application->CreateForm(__classid(TMainForm), &MainForm);
      Application->CreateForm(__classid(TErrorsForm), &ErrorsForm);
      Application->Run();
    }
    catch (Exception &exception)
    {
      Application->ShowException(&exception);
    }
    return 0;
  }

  ConfigName=ParamStr(1);
  ExportName=ParamStr(2);
  Errors=new TStringList();
  Objects=new TObjectList();
  if (LoadObjectsFromFile(ConfigName, Objects, Errors))
    ExportObjectsToFile(ExportName, Objects, Errors);
  if (Errors->Count>0)
    if (Application->MessageBox("��� �������� ����� ��� �������� � HTML �������� ������,\n�������, ��������, ������� ���������.\n������ �� ����������?",
      FormCaption, MB_YESNO | MB_ICONERROR)==IDYES) {
      Application->Initialize();
      Application->CreateForm(__classid(TErrorsForm), &ErrorsForm);
      ErrorsForm->Errors->Lines->Assign(Errors);
      Application->Run();
    }
  return 0;
}

