/////////////////////////////////////////////////////////////////////////////
//
//  common.cpp
//
//  �������� ����� �������: TEditObject, TGrabHandle
//  � ��������� ��������������� �������
//
/////////////////////////////////////////////////////////////////////////////
#include <vcl.h>
#pragma hdrstop
/////////////////////////////////////////////////////////////////////////////
#include <math.h>
#include "common.h"
/////////////////////////////////////////////////////////////////////////////
#pragma package(smart_init)
/////////////////////////////////////////////////////////////////////////////
int GrabHandleSize=5;

TCursor GrabHandleCursors[ghtLast-ghtFirst+1]={
  crSizeNWSE, crSizeNS, crSizeNESW,
  crSizeWE,             crSizeWE,
  crSizeNESW, crSizeNS, crSizeNWSE
};
/////////////////////////////////////////////////////////////////////////////
//
//  ������� ���������� ����� Point �� �������� delta
//
void OffsetPoint(TPoint &Point, int deltaX, int deltaY) {
  Point.x+=deltaX;
  Point.y+=deltaY;
}

/////////////////////////////////////////////////////////////////////////////
//
//  ��������������� ������� ��� ������������ �� �����
//
//  ��������� Value � ���������� ��������, �������� Step
//
int RoundToNearest(int Value, int Step) {
  return ((int)ceil(Value*1.0f/Step))*Step;
}

/////////////////////////////////////////////////////////////////////////////
//
//  ���������� ����������� ����� ��� ������� ���� Type, �����������
//  � �������������� ControlRect
//
TPoint GrabHandlePosition(TRect ControlRect, TGrabHandleType Type) {
  TPoint TopLeft, result;
  int Right,Bottom;

  TopLeft.x=ControlRect.left;
  TopLeft.y=ControlRect.top;
  Right=ControlRect.right-ControlRect.left;
  Bottom=ControlRect.bottom-ControlRect.top;

  switch (Type) {
    case ghtTopLeft:
      result=Point(0,0);
      break;
    case ghtTop:
      result=Point(Right/2, 0);
      break;
    case ghtTopRight:
      result=Point(Right, 0);
      break;
    case ghtLeft:
      result=Point(0, Bottom/2);
      break;
    case ghtRight:
      result=Point(Right, Bottom/2);
      break;
    case ghtBottomLeft:
      result=Point(0, Bottom);
      break;
    case ghtBottom:
      result=Point(Right/2, Bottom);
      break;
    case ghtBottomRight:
      result=Point(Right, Bottom);
      break;
  }

  OffsetPoint(result, TopLeft.x, TopLeft.y);
  return result;
}

/////////////////////////////////////////////////////////////////////////////
//
//  CompareLeft(), CompareTop()
//
//  ��������������� ������� ��� ������ TSortedObjectList
//
int __fastcall CompareLeft(void *Item1, void *Item2) {
  return ((TEditObject *)Item1)->Left==((TEditObject *)Item2)->Left?
    0 :
    ((TEditObject *)Item1)->Left<((TEditObject *)Item2)->Left ?
      -1 : 1;
};

int __fastcall CompareTop(void *Item1, void *Item2) {
  return ((TEditObject *)Item1)->Top==((TEditObject *)Item2)->Top?
    0 :
    ((TEditObject *)Item1)->Top<((TEditObject *)Item2)->Top ?
      -1 : 1;
};


/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
//
//  TEditObject class
//
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
//
//  TEditObject::TEditObject()
//
__fastcall TEditObject::TEditObject(TObjectType fType)
{
  Type=fType;
  switch (Type) {
    case otLabel:
      Object=new TStaticText(this);
      dynamic_cast<TStaticText*>(Object)->AutoSize=false;
      break;
    case otButton:
      Object=new TButton(this);
      break;
    case otTextEdit:
      Object=new TEdit(this);
      dynamic_cast<TEdit*>(Object)->ReadOnly=true;
      dynamic_cast<TEdit*>(Object)->AutoSize=false;
      break;
  }
  Width=175;
  Height=25;
  Text="New Object";
}


/////////////////////////////////////////////////////////////////////////////
//
//  TEditObject::~TEditObject()
//
__fastcall TEditObject::~TEditObject()
{
  delete Object;
}


/////////////////////////////////////////////////////////////////////////////
//
//  TEditObject::SetText()
//
//  Putter 
//
void __fastcall TEditObject::SetText(AnsiString value)
{
  FText = value;
  switch (Type) {
    case otLabel:
      dynamic_cast<TStaticText*>(Object)->Caption=value;
      break;
    case otButton:
      dynamic_cast<TButton*>(Object)->Caption=value;
      break;
    case otTextEdit:
      dynamic_cast<TEdit*>(Object)->Text=value;
      break;
  }
}


/////////////////////////////////////////////////////////////////////////////
//
//  TEditObject::SetLeft()
//
//  Putter
//
void __fastcall TEditObject::SetLeft(int value)
{
    FLeft = value;
    Object->Left=value;
}


/////////////////////////////////////////////////////////////////////////////
//
//  TEditObject::SetTop()
//
//  Putter
//
void __fastcall TEditObject::SetTop(int value)
{
    FTop = value;
    Object->Top=value;
}


/////////////////////////////////////////////////////////////////////////////
//
//  TEditObject::SetWidth()
//
//
//
void __fastcall TEditObject::SetWidth(int value)
{
  if (value<0) {
    Left+=value;
    value=-value;
  }
  FWidth = value;
  Object->Width=value;
}


/////////////////////////////////////////////////////////////////////////////
//
//  TEditObject::SetHeight()
//
//  Putter
//
void __fastcall TEditObject::SetHeight(int value)
{
  if (value<0) {
    Top+=value;
    value=-value;
  }
  FHeight = value;
  Object->Height=value;
}


/////////////////////////////////////////////////////////////////////////////
//
//  TEditObject::SetBounds()
//
void __fastcall TEditObject::SetBounds(int ALeft, int ATop, int AWidth, int AHeight)
{
  //Object->SetBounds(ALeft,ATop,AWidth,AHeight);
  Left=ALeft;
  Top=ATop;
  Width=AWidth;
  Height=AHeight;
}


/////////////////////////////////////////////////////////////////////////////
//
//  TEditObject::GetClientRect()
//
TRect __fastcall TEditObject::GetClientRect()
{
  return Object->ClientRect;
}


/////////////////////////////////////////////////////////////////////////////
//
//  TEditObject::GetHandle()
//
//  ���������� hwnd ����������� �������
//
HWND __fastcall TEditObject::GetHandle()
{
  return Object->Handle;
}


/////////////////////////////////////////////////////////////////////////////
//
//  TEditObject::Assign()
//
//  ������������� ����� �� �������� �������, ��� � � Source
//
void __fastcall TEditObject::Assign(TEditObject * Source)
{
  //TODO: Add your source code here
  Text=Source->Text;
  Left=Source->Left;
  Top=Source->Top;
  Width=Source->Width;
  Height=Source->Height;
}


/////////////////////////////////////////////////////////////////////////////
//
//  TEditObject::SetParent()
//
//  Putter
//
void __fastcall TEditObject::SetParent(TWinControl * value)
{
    FParent = value;
    Object->Parent=value;
    Object->Cursor=value->Cursor;
}

/////////////////////////////////////////////////////////////////////////////
//
//  TEditObject::BringToFront()
//
void __fastcall TEditObject::BringToFront()
{
  Object->BringToFront();
}


/////////////////////////////////////////////////////////////////////////////
//
//  TEditObject::SendToBack()
//
void __fastcall TEditObject::SendToBack()
{
  Object->SendToBack();
}

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
//
//  TGrabHandle class
//
//  ������ ������� (grab handles, �� ����� �������� � ��������
//  ������� �������)
//
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
//
//  TGrabHandle::TGrabHandle()
//
__fastcall TGrabHandle::TGrabHandle(TWinControl *fParent, TGrabHandleType fType)
  : TWinControl(Parent)
{
  Visible=false;
  SetBounds (0,0,GrabHandleSize,GrabHandleSize);
  SetType(fType);
  Parent=fParent;
}


/////////////////////////////////////////////////////////////////////////////
//
//  TGrabHandle::ResetType()
//
//  ����������������� ��� ������
//
void __fastcall TGrabHandle::ResetType(TRect Selection)
{
  TPoint Center;

  Center=GrabHandlePosition(Selection, Type);
  OffsetPoint(Center, -GrabHandleSize/2, -GrabHandleSize/2);
  SetBounds(Center.x, Center.y, GrabHandleSize, GrabHandleSize);
}


/////////////////////////////////////////////////////////////////////////////
//
//  TGrabHandle::SetType()
//
//  Putter
//
void __fastcall TGrabHandle::SetType(TGrabHandleType value)
{
  if (FType!=value) {
    FType=value;
    Cursor=GrabHandleCursors[value-ghtFirst];
  }
}

/////////////////////////////////////////////////////////////////////////////
//
//  TGrabHandle::GetCenter()
//
//  ��������� ����� � ������ ������
//
TPoint __fastcall TGrabHandle::GetCenter()
{
  TPoint result;

  result.x=Left+Width/2;
  result.y=Top+Height/2;

  return result;
}


/////////////////////////////////////////////////////////////////////////////
//
//  TGrabHandle::Hide()
//
void __fastcall TGrabHandle::Hide()
{
  SendToBack();
  Visible=false;
}


/////////////////////////////////////////////////////////////////////////////
//
//  TGrabHandle::Show()
//
void __fastcall TGrabHandle::Show()
{
  BringToFront();
  Visible=true;
}


/////////////////////////////////////////////////////////////////////////////
//
//  TGrabHandle::WMPaint()
//
//  ���������� ��������� WM_PAINT
//
void __fastcall TGrabHandle::WMPaint(TMessage & Message)
{
  HDC dc;
  PAINTSTRUCT ps;

  if (Message.WParam==0)
    dc=BeginPaint(Handle, &ps);
  else
    dc=(HDC)Message.WParam;

  PatBlt(dc, 0, 0, Width, Height, BLACKNESS);

  if (Message.WParam==0)
    EndPaint(Handle, &ps);
}


/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
//
//  TUndoItem class
//
//  ������� Undo
//
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
//
//  TUndoItem::TUndoItem()
//
__fastcall TUndoItem::TUndoItem(TUndoType fType, TMenuItem *fMenu) {

  Type=fType;
  Mem=new TMemoryStream();
  if (fType!=utChange) Data=new TMemoryStream();
  else Data=NULL;

  //Pos=0;
  OnClick=NULL;

  Menu=fMenu;

  AddToMenu();
};


/////////////////////////////////////////////////////////////////////////////
//
//  TUndoItem::~TUndoItem()
//
__fastcall TUndoItem::~TUndoItem() {

  RemoveFromMenu();
  
  delete Mem;
  if (Data)
    delete Data;
}


/////////////////////////////////////////////////////////////////////////////
//
//  TUndoItem::SetDescription()
//
//  Putter
//
void __fastcall TUndoItem::SetDescription(AnsiString value)
{
  FDescription = value;
  if (Menu)
    MenuItem->Caption=value;
}


/////////////////////////////////////////////////////////////////////////////
//
//  TUndoItem::MenuItemClick()
//
//  ���������� ��� ������ MenuItem
//
void __fastcall TUndoItem::MenuItemClick(TObject * Sender)
{
  if (OnClick && Menu)
    OnClick(MenuItem->MenuIndex+1);
}


/////////////////////////////////////////////////////////////////////////////
//
//  TUndoItem::AddToMenu()
//
void __fastcall TUndoItem::AddToMenu()
{
  if (Menu) {
    MenuItem=new TMenuItem(Menu);
    Description="����������� ��������";
    MenuItem->Checked=true;
    MenuItem->OnClick=MenuItemClick;
    Menu->Add(MenuItem);
  }
}


/////////////////////////////////////////////////////////////////////////////
//
//  TUndoItem::RemoveFromMenu()
//
void __fastcall TUndoItem::RemoveFromMenu()
{
  if (Menu) {
    Menu->Remove(MenuItem);
    delete MenuItem;
    Menu=NULL;
  }
}

