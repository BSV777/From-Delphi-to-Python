/////////////////////////////////////////////////////////////////////////////
//
//  main.h
//
//  �������� ������ TMainForm (������� �����)
//
/////////////////////////////////////////////////////////////////////////////
#ifndef mainH
#define mainH
/////////////////////////////////////////////////////////////////////////////
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Menus.hpp>
#include <ComCtrls.hpp>
#include <ToolWin.hpp>
#include <Buttons.hpp>
#include <ImgList.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
#include <Dialogs.hpp>
#include <ActnList.hpp>
/////////////////////////////////////////////////////////////////////////////

class TMainForm : public TForm
{
__published:	// IDE-managed Components
    TMainMenu *MainMenu;
    TMenuItem *mFile;
    TMenuItem *mFileNew;
    TMenuItem *N1;
    TMenuItem *mFileOpen;
    TMenuItem *mFileSave;
    TMenuItem *mFileSaveAs;
    TMenuItem *N2;
    TMenuItem *mExit;
    TMenuItem *mEdit;
    TMenuItem *mEditSelectAll;
    TMenuItem *N3;
    TMenuItem *mEditBringToFront;
    TMenuItem *mEditSendToBack;
    TMenuItem *mHelp;
    TMenuItem *mHelpContents;
    TMenuItem *mHelpAbout;
    TMenuItem *mEditCut;
    TMenuItem *mEditCopy;
    TMenuItem *mEditPaste;
    TMenuItem *mEditDelete;
    TMenuItem *mEditAlignToGrid;
    TMenuItem *mEditAlign;
    TMenuItem *mInsert;
    TMenuItem *N4;
    TMenuItem *mExport;
    TMenuItem *mExportHTML;
    TMenuItem *mInsertLabel;
    TMenuItem *mInsertTextEdit;
    TMenuItem *mInsertButton;
    TCoolBar *CoolBar1;
    TToolBar *ToolBar1;
    TToolButton *ToolButton1;
    TImageList *MenuImages;
    TToolButton *ToolButton2;
    TToolButton *ToolButton3;
    TToolButton *ToolButton4;
    TToolBar *ToolBar2;
    TToolButton *btInsertLabel;
    TToolButton *btInsertTextEdit;
    TToolButton *btInsertButton;
    TToolButton *CopyButton;
    TToolButton *CutButton;
    TToolButton *PasteButton;
    TToolButton *DeleteButton;
    TMenuItem *N5;
    TMenuItem *mEditUndoMul;
    TMenuItem *mEditRedo;
    TToolButton *ToolButton12;
    TToolButton *UndoButton;
    TToolButton *ToolButton15;
    TToolButton *SelectAllButton;
    TToolButton *BringToFrontButton;
    TToolButton *SendToBackButton;
    TImageList *ObjectImages;
    TPanel *EditArea;
    TPanel *PropertyEditor;
    TScrollBar *HorizBar;
    TScrollBar *VertBar;
    TStringGrid *ObjectProperties;
    TStaticText *ObjectType;
    TStatusBar *StatusBar;
    TToolButton *btEdit;
    TSaveDialog *SaveDialog;
    TOpenDialog *OpenDialog;
    TPopupMenu *PopupMenu;
    TMenuItem *N6;
    TMenuItem *mEditGridOptions;
    TSaveDialog *ExportDialog;
    TMenuItem *mEditUndo;
    TToolButton *RedoButton;
    TMenuItem *N7;
    TMenuItem *mEditSizeObjects;
    TMenuItem *pAlignToGrid;
    TMenuItem *pBringToFront;
    TMenuItem *pSendToBack;
    TMenuItem *N8;
    TMenuItem *pAlign;
    TMenuItem *pSizeObjects;
    TMenuItem *N9;
    TMenuItem *pGridOptions;
    TActionList *EditActionList;
    TAction *actAlignToGrid;
    TAction *actBringToFront;
    TAction *actSendToBack;
    TAction *actSizeOfObjects;
    TAction *actAlignObjects;
    TAction *actGridOptions;
    TAction *actSelectAll;
    TMenuItem *N10;
    TMenuItem *SelectAll1;
    
    void __fastcall mInsertLabelClick(TObject *Sender);
    void __fastcall mInsertTextEditClick(TObject *Sender);
    void __fastcall mInsertButtonClick(TObject *Sender);

    void __fastcall ObjectPropertiesSelectCell(TObject *Sender, int ACol,
          int ARow, bool &CanSelect);

    void __fastcall VertBarChange(TObject *Sender);
    void __fastcall HorizBarChange(TObject *Sender);
    void __fastcall FormResize(TObject *Sender);
    
    void __fastcall btInsertLabelClick(TObject *Sender);
    void __fastcall btInsertTextEditClick(TObject *Sender);
    void __fastcall btInsertButtonClick(TObject *Sender);
    void __fastcall btEditClick(TObject *Sender);
    void __fastcall btInsertLabelMouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall btInsertTextEditMouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall btInsertButtonMouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall ObjectPropertiesKeyPress(TObject *Sender, char &Key);

    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    
    void __fastcall mEditCutClick(TObject *Sender);
    void __fastcall mEditCopyClick(TObject *Sender);
    void __fastcall mEditPasteClick(TObject *Sender);
    void __fastcall mEditDeleteClick(TObject *Sender);
    void __fastcall mFileSaveAsClick(TObject *Sender);
    void __fastcall mFileSaveClick(TObject *Sender);
    void __fastcall mExitClick(TObject *Sender);
    void __fastcall mFileNewClick(TObject *Sender);
    void __fastcall mFileOpenClick(TObject *Sender);
    void __fastcall mHelpAboutClick(TObject *Sender);
    void __fastcall mExportHTMLClick(TObject *Sender);
    void __fastcall mEditUndoClick(TObject *Sender);
    void __fastcall mEditRedoClick(TObject *Sender);
    void __fastcall UndoButtonClick(TObject *Sender);
    void __fastcall actAlignToGridExecute(TObject *Sender);
    void __fastcall actBringToFrontExecute(TObject *Sender);
    void __fastcall actSendToBackExecute(TObject *Sender);
    void __fastcall actSizeOfObjectsExecute(TObject *Sender);
    void __fastcall actAlignObjectsExecute(TObject *Sender);
    void __fastcall actGridOptionsExecute(TObject *Sender);
    void __fastcall actSelectAllExecute(TObject *Sender);
    void __fastcall mHelpContentsClick(TObject *Sender);

private:
    int opPrevRow;
    AnsiString opPrevValue;

    bool AskNameWhenSave;

    AnsiString FFileName;
    __property AnsiString FileName  = { read = FFileName, write = SetFileName };

    void __fastcall OnApplicationMessage(tagMSG &Msg, bool &Handled);
    void __fastcall UpdateScrollBars();
    void __fastcall UpdateEditWindowPos();

    int __fastcall CloseConfirm();
    int __fastcall ShowSaveDialog();
    void __fastcall SetFileName(AnsiString value);
    void __fastcall UndoRedoChanged(bool CanUndo, bool CanRedo);
    void __fastcall ClipboardChanged(int Count);
    void __fastcall SelectedCountChanged(int Count);
    void __fastcall ObjectCountChanged(int Count);

public:
    TEditWindow *EditWindow;
    __fastcall TMainForm(TComponent* Owner);
    __fastcall ~TMainForm();
};

/////////////////////////////////////////////////////////////////////////////

extern PACKAGE TMainForm *MainForm;

/////////////////////////////////////////////////////////////////////////////
#endif
