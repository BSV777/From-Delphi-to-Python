/////////////////////////////////////////////////////////////////////////////
//
//  gridoptions.h
//
//  �������� ������ TGridOptionsForm (����� ��� ��������� ���������� �����)
//
/////////////////////////////////////////////////////////////////////////////
#ifndef gridoptionsH
#define gridoptionsH
/////////////////////////////////////////////////////////////////////////////
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
/////////////////////////////////////////////////////////////////////////////

class TGridOptionsForm : public TForm
{
__published:	// IDE-managed Components
    TRadioGroup *GridMarker;
    TCheckBox *VisibleGrid;
    TGroupBox *GridSize;
    TLabel *Label1;
    TLabel *Label2;
    TEdit *XStep;
    TEdit *YStep;
    TBitBtn *BitBtn1;
    TBitBtn *BitBtn2;
private:	// User declarations
public:		// User declarations
    __fastcall TGridOptionsForm(TComponent* Owner);
};

/////////////////////////////////////////////////////////////////////////////

extern PACKAGE TGridOptionsForm *GridOptionsForm;

/////////////////////////////////////////////////////////////////////////////
#endif
