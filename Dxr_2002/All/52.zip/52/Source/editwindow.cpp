/////////////////////////////////////////////////////////////////////////////
//
//  editwindow.cpp
//
//  ����� TEditWindow (������� ��������������)
//
/////////////////////////////////////////////////////////////////////////////
#include <vcl.h>
#pragma hdrstop
/////////////////////////////////////////////////////////////////////////////
#include <clipbrd.hpp>
#include <stdlib.h>
#include "editwindow.h"
/////////////////////////////////////////////////////////////////////////////
#pragma package(smart_init)
/////////////////////////////////////////////////////////////////////////////

#define PasteOffsetX 10
#define PasteOffsetY 10

/////////////////////////////////////////////////////////////////////////////
//
//  TEditWindow()
//
__fastcall TEditWindow::TEditWindow(TComponent *Owner, TWinControl *fParent, int fWidth, int fHeight)
  : TWinControl(Owner)
{
  Modified=false;

  ShowGrid=true;
//  ShowGrid=false;
  XGridStep=10;
  YGridStep=10;
  GridType=gtSmallDots;
//  GridType=gtLargeDots;

  InsertingObject=otNone;
  Drawing=false;
  Moving=false;
  Sizing=false;
  Objects=new TObjectList();
  SelectedObjects=new TObjectList();
  Clipboard=new TObjectList();

  Width=fWidth;
  Height=fHeight;

  BevelOuter=bvLowered;
  BevelInner=bvNone;
  BevelKind=bkFlat;

  Color=clWhite;
  Parent=fParent;

  HorizBar=NULL;
  VertBar=NULL;

  ObjectProperties=NULL;
  opObjectType=NULL;
  Panels=NULL;

  PopupMenu=NULL;

  btEdit=NULL;
  NeedToPressBtEdit=false;

  GrabHandlesOperation(ghoCreate);

  SelectedHandle=ghtNone;

  Cursor=crArrow;

  UndoRedo=new TUndoRedo();
  UndoMenu=NULL;
  
  OnUndoRedoChanged=NULL;
  OnSelectedCountChanged=NULL;
  OnClipboardChanged=NULL;
  OnObjectCountChanged=NULL;
}


/////////////////////////////////////////////////////////////////////////////
//
//  ~TEditWindow()
//
__fastcall TEditWindow::~TEditWindow()
{
  for (int i=0; i<Clipboard->Count; i++)
    delete Clipboard->Items[i];
  delete Clipboard;

  for (int i=0; i<Objects->Count; i++)
    delete Objects->Items[i];

  FreeUndoItems(0);
  delete UndoRedo;
  
  GrabHandlesOperation(ghoDestroy);
  delete SelectedObjects;
  delete Objects;
}


/////////////////////////////////////////////////////////////////////////////
//
//  EraseBackground()
//
//  ���������� ��������� WM_ERASEBKGND
//
void TEditWindow::EraseBackground(TMessage &Message)
{
  int XStep,YStep;
  TRect Rect;


  ::GetClientRect(Handle, &Rect);
  PatBlt((void *)Message.WParam,0,0,Rect.Right-Rect.Left,Rect.Bottom-Rect.Top,
         WHITENESS);
  if (ShowGrid && XGridStep>2 && YGridStep>2) {
    if (GridType==gtSmallDots) {
      for (XStep=1;XStep<=Rect.Right/XGridStep+1;XStep++)
        for (YStep=1;YStep<=Rect.Bottom/YGridStep+1;YStep++)
          SetPixel((void *)Message.WParam,XStep*XGridStep,YStep*YGridStep,0);
    } else if (GridType==gtLargeDots) {
      for (XStep=1;XStep<=Rect.Right/XGridStep+1;XStep++)
        for (YStep=1;YStep<=Rect.Bottom/YGridStep+1;YStep++) {
          PatBlt((void *)Message.WParam,XStep*XGridStep-1,YStep*YGridStep-1,
                 2,2,BLACKNESS);
        }
    } else {
      for (XStep=1;XStep<=Rect.Right/XGridStep+1;XStep++) {
        MoveToEx((void *)Message.WParam,XStep*XGridStep,0,NULL);
        LineTo((void *)Message.WParam,XStep*XGridStep,Rect.Bottom);
      }
      for (YStep=1;YStep<=Rect.Bottom/YGridStep+1;YStep++) {
        MoveToEx((void *)Message.WParam,0,YStep*YGridStep,NULL);
        LineTo((void *)Message.WParam,Rect.Right,YStep*YGridStep);
      }
    }
  }
  Message.Result=1;
}


/////////////////////////////////////////////////////////////////////////////
//
//  SetGridResolution()
//
void __fastcall TEditWindow::SetGridResolution(int XResolution, int YResolution)
{
  XGridStep=XResolution;
  YGridStep=YResolution;
}


/////////////////////////////////////////////////////////////////////////////
//
//  GetClipDC()
//
//  ������������� ������� ��������� ����� ��� ��������� ��������
//  � ���������� �� HDC
//
HDC TEditWindow::GetClipDC() {
  HDC dc;
  HRGN ClipRegion;
  TPoint ClipOrg;
  TRect ClipRect;

  // �������� ���. ���������� � ������������� ���������
  // ����� ��� ��������� ��������
  ClipOrg=Point(0,0);
  if (Width>Parent->Width) {
    ClipOrg=Parent->ClientToScreen(ClipOrg);
    ClipRect=Parent->ClientRect;
  } else {
    ClipOrg=ClientToScreen(ClipOrg);
    ClipRect=ClientRect;
  }
  OffsetRect(&ClipRect, ClipOrg.x, ClipOrg.y);
  ClipRect.bottom++;
  ClipRect.right++;

  dc=GetDC(0);
  SetViewportOrgEx(dc, ClipOrg.x, ClipOrg.y, NULL);
  ClipRegion=CreateRectRgnIndirect(&ClipRect);
  SelectClipRgn(dc, ClipRegion);
  DeleteObject(ClipRegion);

  return dc;
}


/////////////////////////////////////////////////////////////////////////////
//
//  DrawFocusRect()
//
//  ������ ����� ��� ���������� ��������
//
void TEditWindow::DrawFocusRect() {
  HDC dc;
  HBRUSH oldBrush;
  int PatchX=0, PatchY=0;

  TRect DrawRect;
  TEditObject *Object;

  if (Selection.Right!=Selection.Left && Selection.Top!=Selection.Bottom) {
    dc=GetClipDC();

    SetROP2(dc,R2_NOT);
    oldBrush=SelectObject(dc,GetStockObject(HOLLOW_BRUSH));

    if (Width>Parent->Width) {
      PatchX=Left+BevelWidth;
      PatchY=Top+BevelWidth;
    }

    if (SelectedObjects->Count<=1)
      Rectangle(dc, PatchX+Selection.Left, PatchY+Selection.Top,
                PatchX+Selection.Right, PatchY+Selection.Bottom);
    else
      for (int i=0; i<SelectedObjects->Count; i++) {
        Object=SelectedObjects->Items[i];
        Rectangle(dc, PatchX + Object->Left + CursorLast.x - CursorStart.x,
                  PatchY + Object->Top + CursorLast.y - CursorStart.y,
                  PatchX + Object->Left + Object->Width
                    + CursorLast.x - CursorStart.x,
                  PatchY + Object->Top + Object->Height
                    + CursorLast.y - CursorStart.y);
      }

    SelectObject(dc,oldBrush);
    ReleaseDC(this->Handle,dc);
  }
}


/////////////////////////////////////////////////////////////////////////////
//
//  SetSelection()
//
//  �������������� ������� ���������
//
void TEditWindow::SetSelection() {

  if (InsertingObject!=otNone) {
    if (XGridStep>1) {
      CursorStart.x=RoundToNearest(CursorStart.x, XGridStep);
      CursorLast.x=RoundToNearest(CursorLast.x, XGridStep);
    }
    if (YGridStep>1) {
      CursorStart.y=RoundToNearest(CursorStart.y, YGridStep);
      CursorLast.y=RoundToNearest(CursorLast.y, YGridStep);
    }
  }

  if (Sizing || Moving) {
    if (Sizing)
      CursorLast=GrabHandlePosition(Selection, SelectedHandle);
    if (XGridStep>1) {
      CursorStart.x=RoundToNearest(CursorStart.x, XGridStep);
      CursorLast.x=RoundToNearest(CursorLast.x, XGridStep);
    }
    if (YGridStep>1) {
      CursorStart.y=RoundToNearest(CursorStart.y, YGridStep);
      CursorLast.y=RoundToNearest(CursorLast.y, YGridStep);
    }
  } else
    Selection=Rect(CursorStart.x, CursorStart.y, CursorStart.x, CursorStart.y);

  DrawFocusRect();
}


/////////////////////////////////////////////////////////////////////////////
//
//  ChangeSelection()
//
//  ������ ������� � ��������� ������� ��������� ��� ����������� ���
//  ��������� ������� ��������
//
void TEditWindow::ChangeSelection() {
  TPoint delta;

  delta=Point(CursorNow.x-CursorLast.x, CursorNow.y-CursorLast.y);
  CursorLast=CursorNow;

  if (Sizing)
    switch (SelectedHandle) {
      case ghtTopLeft:
        Selection.Left+=delta.x;
        Selection.Top+=delta.y;
        break;
      case ghtTop:
        Selection.Top+=delta.y;
        break;
      case ghtTopRight:
        Selection.Right+=delta.x;
        Selection.Top+=delta.y;
        break;
      case ghtLeft:
        Selection.Left+=delta.x;
        break;
      case ghtRight:
        Selection.Right+=delta.x;
        break;
      case ghtBottomLeft:
        Selection.Left+=delta.x;
        Selection.Bottom+=delta.y;
        break;
      case ghtBottom:
        Selection.Bottom+=delta.y;
        break;
      case ghtBottomRight:
        Selection.Right+=delta.x;
        Selection.Bottom+=delta.y;
        break;
    }
  else if (Moving)
    OffsetRect(&Selection, delta.x, delta.y);
  else
    Selection=Rect(min(CursorStart.x, CursorNow.x),
                   min(CursorStart.y, CursorNow.y),
                   max(CursorStart.x, CursorNow.x),
                   max(CursorStart.y, CursorNow.y));
}


/////////////////////////////////////////////////////////////////////////////
//
//  ResetSelection()
//
//  ����������������� ������� ���������
//
void __fastcall TEditWindow::ResetSelection()
{
  TRect temp;
  TEditObject *Object;

  Selection=Rect(0,0,0,0);
  for (int i=0; i<SelectedObjects->Count; i++) {
    Object=SelectedObjects->Items[i];
    temp.Left=Object->Left;
    temp.Top=Object->Top;
    temp.Right=Object->Left+Object->Width;
    temp.Bottom=Object->Top+Object->Height;
    UnionRect(&Selection, &temp, &Selection);
  }

}


/////////////////////////////////////////////////////////////////////////////
//
//  ClearSelectedObjects()
//
//  ������� ���������
//
void __fastcall TEditWindow::ClearSelectedObjects()
{
  if (SelectedObjects->Count==1)
    GrabHandlesOperation(ghoHide);
  else if (SelectedObjects->Count>1)
    for (int i=0; i<SelectedObjects->Count; i++)
      DrawObjectHandles(SelectedObjects->Items[i], false);

  SelectedObjects->Clear();
  Selection=Rect(0,0,0,0);

  ResetObjectProperties();
  UpdateSelectedObjectCount();
}


/////////////////////////////////////////////////////////////////////////////
//
//  DeleteSelectedObjects()
//
//  ������� ���������� �������
//
void __fastcall TEditWindow::DeleteSelectedObjects()
{
  int ObjectPos;
  TUndoItem *UndoItem;
  AnsiString TempDescription;

  UndoItem=NewUndoItem(utDelete);
  TempDescription="��������";
  TempDescription+=SelectedObjects->Count>1 ?
    " ������ ��������" : " �������";
  UndoItem->Description=TempDescription;

  if (SelectedObjects->Count==1)
    GrabHandlesOperation(ghoHide);
  else if (SelectedObjects->Count>1)
    for (int i=0; i<SelectedObjects->Count; i++)
      DrawObjectHandles(SelectedObjects->Items[i], false);

  LockWindowUpdate(Handle);
  for (int i=0; i<SelectedObjects->Count; i++) {
    ObjectPos=Objects->IndexOf(SelectedObjects->Items[i]);
    AddDataUndoItem(UndoItem, SelectedObjects->Items[i], ObjectPos);
    delete Objects->Items[ObjectPos];
    Objects->Delete(ObjectPos);
  }
  LockWindowUpdate(0);

  SetMemUndoItem(UndoItem);

  SelectedObjects->Clear();
  Selection=Rect(0,0,0,0);

  ResetObjectProperties();

  UpdateSelectedObjectCount();
  UpdateObjectCount();

  Modified=true;
}


/////////////////////////////////////////////////////////////////////////////
//
//  GrabHandlesOperation()
//
//  ������������ �������� �� ��������� � �������
//
void __fastcall TEditWindow::GrabHandlesOperation(TGrabHandleOperation Operation)
{
  unsigned short HandleType;

  if (SelectedObjects->Count==1
      && (Operation==ghoShow || Operation==ghoHide))
    LockWindowUpdate(Handle);

  if (SelectedObjects->Count>1 && Operation==ghoShow)
    for (int Object=0; Object < SelectedObjects->Count; Object++)
      DrawObjectHandles(SelectedObjects->Items[Object],true);

  for (HandleType=ghtFirst;HandleType<=ghtLast;HandleType++) {
    switch (Operation) {
      case ghoCreate:
        GrabHandles[HandleType-ghtFirst]=new TGrabHandle(this, (TGrabHandleType)HandleType);
        break;
      case ghoDestroy:
        delete GrabHandles[HandleType-ghtFirst];
        break;
      case ghoMove:
        GrabHandles[HandleType-ghtFirst]->ResetType(Selection);
        break;
      case ghoShow:
        if (SelectedObjects->Count==1)
          GrabHandles[HandleType-ghtFirst]->Show();
        break;
      case ghoHide:
        GrabHandles[HandleType-ghtFirst]->Hide();
        break;
    }
  }

  if (SelectedObjects->Count==1
      && (Operation==ghoShow || Operation==ghoHide)) {
    LockWindowUpdate(0);
    Update();
  }
}


/////////////////////////////////////////////////////////////////////////////
//
//  DrawObjectHandles()
//
//  ������� ������������ ������ ��� ������� Object � ��������
//  � ����������� �� Visible
//
void __fastcall TEditWindow::DrawObjectHandles(TEditObject *Object, bool Visible)
{
  HDC dc;
  int Width, Height;
  TRect DrawRect;

  if (Visible) {
    dc=GetDC(Object->Handle);
    SelectObject(dc, GetStockObject(GRAY_BRUSH));
  }

  ::GetClientRect(Object->Handle, &DrawRect);
  Width=DrawRect.Right-DrawRect.Left;
  Height=DrawRect.Bottom-DrawRect.Top;

  DrawGrabHandle(Object->Handle, dc, 0, 0, Visible);
  DrawGrabHandle(Object->Handle, dc, (Width-GrabHandleSize)/2, 0, Visible);
  DrawGrabHandle(Object->Handle, dc, Width-GrabHandleSize, 0, Visible);

  DrawGrabHandle(Object->Handle, dc, 0, (Height-GrabHandleSize)/2, Visible);
  DrawGrabHandle(Object->Handle, dc, Width-GrabHandleSize, (Height-GrabHandleSize)/2, Visible);

  DrawGrabHandle(Object->Handle, dc, 0, Height-GrabHandleSize, Visible);
  DrawGrabHandle(Object->Handle, dc, (Width-GrabHandleSize)/2, Height-GrabHandleSize, Visible);
  DrawGrabHandle(Object->Handle, dc, Width-GrabHandleSize, Height-GrabHandleSize, Visible);

  if (Visible)
    ReleaseDC(Object->Handle,dc);

}


/////////////////////////////////////////////////////////////////////////////
//
//  DrawGrabHandle()
//
//  ��������������� ������� ��� DrawObjectHandles().
//
//  ������ ���� ������ �� dc ��� ������� �� � hwnd �� ����������� (X,Y)
//  � ����������� �� Visible
//
void __fastcall TEditWindow::DrawGrabHandle(HWND hwnd, HDC dc, int X, int Y, bool Visible)
{
  TRect Rect;

  if (Visible)
    PatBlt(dc, X, Y, GrabHandleSize, GrabHandleSize, PATCOPY);
  else {
    Rect=Bounds(X, Y, GrabHandleSize, GrabHandleSize);
    InvalidateRect(hwnd, &Rect, true);
  }
}


/////////////////////////////////////////////////////////////////////////////
//
//  GetGrabHandle()
//
//  ���������� ��� ��� ������ � ����������� �� �� hwnd
//  � ��������� Msg
//
TGrabHandleType __fastcall TEditWindow::GetGrabHandle(tagMSG Msg)
{
  for (unsigned short i=ghtFirst; i<=ghtLast; i++)
    if (Msg.hwnd==GrabHandles[i-ghtFirst]->Handle)
      return (TGrabHandleType)i;
  return ghtNone;
}


/////////////////////////////////////////////////////////////////////////////
//
//  FindObject()
//
//  ���������� ��������� �� ������������� ������ �� ��� hwnd
//
TEditObject * __fastcall TEditWindow::FindObject(HWND hwnd)
{
  for (int i=0;i<Objects->Count;i++)
    if (Objects->Items[i]->Handle==hwnd)
      return Objects->Items[i];
  return NULL;
}


/////////////////////////////////////////////////////////////////////////////
//
//  UpdateObjectCount()
//
//  ���������� ��� ��������� ���������� ������������� ��������
//
void __fastcall TEditWindow::UpdateObjectCount() {
  if (OnObjectCountChanged) {
    OnObjectCountChanged(Objects->Count);
  }
  if (Panels!=NULL)
    Panels->Items[0]->Text="��������: "+IntToStr(Objects->Count);
}


/////////////////////////////////////////////////////////////////////////////
//
//  UpdateSelectedObjectCount()
//
//  ���������� ��� ��������� ���������� ���������� ��������
//
void __fastcall TEditWindow::UpdateSelectedObjectCount() {
  if (OnSelectedCountChanged)
    OnSelectedCountChanged(SelectedObjects->Count);
  if (Panels!=NULL)
    Panels->Items[1]->Text="��������: "+IntToStr(SelectedObjects->Count);
}


/////////////////////////////////////////////////////////////////////////////
//
//  AddSelectedObject()
//
//  ��������� ������ � ������ ���������� ��������
//
void __fastcall TEditWindow::AddSelectedObject(TEditObject * Object, bool UpdateProperties=true)
{
  TRect temp;

  if (SelectedObjects->IndexOf(Object)==-1) {
    SelectedObjects->Add(Object);
    if (SelectedObjects->Count==1) {
      Selection.Left=Object->Left;
      Selection.Top=Object->Top;
      Selection.Right=Object->Left+Object->Width;
      Selection.Bottom=Object->Top+Object->Height;
    } else {
      if (SelectedObjects->Count==2)
        DrawObjectHandles(SelectedObjects->Items[0], true);
      DrawObjectHandles(Object, true);
      temp.Left=Object->Left;
      temp.Top=Object->Top;
      temp.Right=Object->Left+Object->Width;
      temp.Bottom=Object->Top+Object->Height;
      UnionRect(&Selection, &temp, &Selection);
    }
  }

  if (UpdateProperties)
    ResetObjectProperties();

  UpdateSelectedObjectCount();
}


/////////////////////////////////////////////////////////////////////////////
//
//  DeleteSelectedObject()
//
//  ������� ������ �� ������ ���������� ��������
//
void __fastcall TEditWindow::DeleteSelectedObject(TEditObject * Object)
{
  SelectedObjects->Delete(SelectedObjects->IndexOf(Object));
  ResetSelection();
  DrawObjectHandles(Object, false);
  if (SelectedObjects->Count==1)
    DrawObjectHandles(SelectedObjects->Items[0], false);

  ResetObjectProperties();
  UpdateObjectCount();
}


/////////////////////////////////////////////////////////////////////////////
//
//  AdjustSelectedObjects()
//
//  �������� ��������� ���������� �������� � ������������ � Selection
//
void __fastcall TEditWindow::AdjustSelectedObjects()
{
  LockWindowUpdate(Handle);
  if (Sizing)
    SelectedObjects->Items[0]->SetBounds(Selection.Left, Selection.Top,
      Selection.Right-Selection.Left, Selection.Bottom-Selection.Top);
  else
    for (int i=0; i<SelectedObjects->Count; i++)
      SelectedObjects->Items[i]->SetBounds(
        SelectedObjects->Items[i]->Left+CursorLast.x-CursorStart.x,
        SelectedObjects->Items[i]->Top+CursorLast.y-CursorStart.y,
        SelectedObjects->Items[i]->Width,
        SelectedObjects->Items[i]->Height
      );
  ResetObjectProperties();
  LockWindowUpdate(0);
  Update();
  Modified=true;
}


/////////////////////////////////////////////////////////////////////////////
//
//  AddObjectsInSelection()
//
//  ��������� ���������� ������� � ������������ � Selection
//
void __fastcall TEditWindow::AddObjectsInSelection()
{
  TRect Rect,SelectionRectangle=Selection;
  TEditObject *Object;

  for (int i=0; i<Objects->Count; i++) {
    Object=Objects->Items[i];
    Rect.Left=Object->Left;
    Rect.Top=Object->Top;
    Rect.Right=Object->Left+Object->Width;
    Rect.Bottom=Object->Top+Object->Height;
    if (IntersectRect(&Rect, &SelectionRectangle, &Rect))
      AddSelectedObject(Object, false);
  }
  ResetObjectProperties();
}


/////////////////////////////////////////////////////////////////////////////
//
//  HandleMessage()
//
//  �������� �������
//
//  ������������ ��������� � ������� ���������
//  ���������� true, ���� ��������� ���� ����������
//
bool __fastcall TEditWindow::HandleMessage(tagMSG Msg)
{
  TShiftState ShiftState;
  TEditObject *Object;

  TEditObject *EditObject;
  TUndoItem *UndoItem;
  int temp, ObjectPos;
  TPoint PopupPos;

  AnsiString TempDescription;

  ::ScreenToClient(Handle,&Msg.pt);

  switch (Msg.message) {

    case WM_LBUTTONDOWN:
      SetCapture(Handle);
      Drawing=true;
      GrabHandlesOperation(ghoHide);
      if (InsertingObject==otNone) {
        SelectedHandle=GetGrabHandle(Msg);
        if (SelectedHandle!=ghtNone)
          if (SelectedObjects->Count==1)
            Sizing=true;
          else
            Moving=true;
        else {
          if (Msg.hwnd==Handle)
            ClearSelectedObjects();
          else {
            Object=FindObject(Msg.hwnd);
            if (SelectedObjects->IndexOf(Object)==-1) {
              // �������� ������ � ������ ����������
              Moving=true;
              if (!(Msg.wParam&MK_SHIFT))
                ClearSelectedObjects();
              AddSelectedObject(Object);
            } else if (Msg.wParam&MK_SHIFT) {
              // ������ ������ �� ������ ����������
              Drawing=false;
              DeleteSelectedObject(Object);
              if (SelectedObjects->Count==1)
                GrabHandlesOperation(ghoMove);
            } else
              // ������ ����������� ���������� ��������
              Moving=true;
          } // else if (Msg.hwnd==Handle)
        } // if (SelectedHandle!=ghtNone)
      } else // if (InsertingObject==otNone)
        ClearSelectedObjects();

      if (Drawing) {
        CursorStart=TPoint(Msg.pt.x,Msg.pt.y);
        CursorLast=CursorStart;
        SetSelection();
      }
      break;

    case WM_MOUSEMOVE:
      Panels->Items[2]->Text="X: "+IntToStr((int)Msg.pt.x)+
        ", Y: "+IntToStr((int)Msg.pt.y);
      Panels->Items[3]->Text="";
      if (Drawing) {
        CursorNow=TPoint(Msg.pt.x,Msg.pt.y);

        Panels->Items[3]->Text=
          "L: "+IntToStr((int)Selection.Left)+
          ", T: "+IntToStr((int)Selection.Top)+
          ", W: "+IntToStr(abs(Selection.Left-Selection.Right))+
          ", H: "+IntToStr(abs(Selection.Top-Selection.Bottom));

        if (Sizing || Moving || InsertingObject!=otNone) {
          if (XGridStep>0)
            CursorNow.x=RoundToNearest(CursorNow.x, XGridStep);
          if (YGridStep>0)
            CursorNow.y=RoundToNearest(CursorNow.y, YGridStep);
        }
        if (CursorLast.x!=CursorNow.x || CursorLast.y!=CursorNow.y) {
          DrawFocusRect();
          ChangeSelection();
          DrawFocusRect();
        }

      }
      break;

    case WM_LBUTTONUP:
      ReleaseCapture();
      if (Drawing) {
        DrawFocusRect();
        Drawing=false;

        if (InsertingObject!=otNone) {
          // ���������� �������
          LockWindowUpdate(Handle);
          EditObject=new TEditObject(InsertingObject);
          EditObject->Parent=this;
          EditObject->Text="����� ������";
          EditObject->Left=Selection.Left;
          EditObject->Top=Selection.Top;
          if (Selection.Right!=Selection.Left) {
            EditObject->Width=Selection.Right-Selection.Left;
          } else if (XGridStep>1)
            EditObject->Width=RoundToNearest(EditObject->Width, XGridStep);
          if (Selection.Top!=Selection.Bottom) {
            EditObject->Height=Selection.Bottom-Selection.Top;
          } else if (YGridStep>1)
            EditObject->Height=RoundToNearest(EditObject->Height, YGridStep);

          ObjectPos=Objects->Add(EditObject);

          // UndoRedo
          UndoItem=NewUndoItem(utAdd);
          TempDescription="���������� �������";
          SetMemUndoItem(UndoItem);
          AddDataUndoItem(UndoItem, EditObject, ObjectPos);
          switch (InsertingObject) {
            case otButton:
              TempDescription+=" Button";
              break;
            case otTextEdit:
              TempDescription+=" TextEdit";
              break;
            case otLabel:
              TempDescription+=" Label";
              break;
          }

          UndoItem->Description=TempDescription;

          UpdateObjectCount();

          if (NeedToPressBtEdit && btEdit!=NULL) {
            btEdit->Click();
            btEdit->Down=true;
          }

          AddSelectedObject(EditObject);

          Modified=true;

          LockWindowUpdate(0);
        } else if (Sizing || Moving) {
          // ��������� ���������� ���������� ��������

          AdjustSelectedObjects();

          if (CursorStart.x!=CursorNow.x
              || CursorStart.y!=CursorNow.y) {
            // UndoRedo
            UndoItem=NewUndoItem(utChange);
            SetMemUndoItem(UndoItem);

            if (Sizing)
              TempDescription="��������� ��������";
            else
              TempDescription="�����������";

            TempDescription+=SelectedObjects->Count>1 ?
              " ������ ��������" : " �������";
            UndoItem->Description=TempDescription;
          }

          SelectedHandle=ghtNone;
          Sizing=Moving=false;
        } else
          // ���������� �������� � ���������
          AddObjectsInSelection();

        if (Selection.Left>Selection.Right) {
          temp=Selection.Left;
          Selection.Left=Selection.Right;
          Selection.Right=temp;
        }

        if (Selection.Top>Selection.Bottom) {
          temp=Selection.Top;
          Selection.Top=Selection.Bottom;
          Selection.Bottom=temp;
        }

        GrabHandlesOperation(ghoMove);

        if (SelectedObjects->Count>0)
          GrabHandlesOperation(ghoShow);

      } else if (SelectedObjects->Count==1)
        GrabHandlesOperation(ghoShow);

      break;

    case WM_LBUTTONDBLCLK:
      break;

    case WM_RBUTTONDOWN:
      if (PopupMenu) {
        PopupPos=Msg.pt;
        ::ClientToScreen(Handle, &PopupPos);
        PopupMenu->Popup(PopupPos.x, PopupPos.y);
      }
      break;

    case WM_RBUTTONUP:
      break;

    case WM_RBUTTONDBLCLK:
      break;

    default:
      return false;
  }
  return true;
}


/////////////////////////////////////////////////////////////////////////////
//
//  ResetObjectProperties()
//
//  ��������� ���������� � ���������� ��������
//
void __fastcall TEditWindow::ResetObjectProperties()
{
  AnsiString Text, Left, Top, Width, Height, Right, Bottom;
  TEditObject *Object;

  if (!(ObjectProperties && opObjectType))
    return;

  if (SelectedObjects->Count==0) {
    opObjectType->Caption="������� �� �������";
    ObjectProperties->Cols[0]->BeginUpdate();
    ObjectProperties->Cols[1]->BeginUpdate();
    for (int i=0; i<2; i++)
      for (int j=0; j<7; j++)
        ObjectProperties->Cols[i]->Strings[j]="";
    ObjectProperties->Cols[1]->EndUpdate();
    ObjectProperties->Cols[0]->EndUpdate();

  ObjectProperties->Enabled=false;
    return;
  }
  if (SelectedObjects->Count==1)
    switch (SelectedObjects->Items[0]->Type) {
      case otLabel:
        opObjectType->Caption="������ Label";
        break;
      case otTextEdit:
        opObjectType->Caption="������ TextEdit";
        break;
      case otButton:
        opObjectType->Caption="������ Button";
        break;
    }
  else
    opObjectType->Caption="������ ��������";

  if (ObjectProperties->Cols[0]->Strings[0]=="") {
    ObjectProperties->Cols[0]->Strings[0]="Value";
    ObjectProperties->Cols[0]->Strings[1]="Left";
    ObjectProperties->Cols[0]->Strings[2]="Top";
    ObjectProperties->Cols[0]->Strings[3]="[Right]";
    ObjectProperties->Cols[0]->Strings[4]="[Bottom]";
    ObjectProperties->Cols[0]->Strings[5]="Width";
    ObjectProperties->Cols[0]->Strings[6]="Height";
  }

  Object=SelectedObjects->Items[0];
  Text=Object->Text;
  Left=Object->Left;
  Top=Object->Top;
  Width=Object->Width;
  Height=Object->Height;
  Right=Object->Width+Object->Left;
  Bottom=Object->Height+Object->Top;

  for (int i=1; i<SelectedObjects->Count; i++) {
    Object=SelectedObjects->Items[i];
    if (Left!=Object->Left)
      Left="";
    if (Top!=Object->Top)
      Top="";
    if (Right!=Object->Left+Object->Width)
      Right="";
    if (Bottom!=Object->Top+Object->Height)
      Bottom="";
    if (Width!=Object->Width)
      Width="";
    if (Height!=Object->Height)
      Height="";
    if (Text!=Object->Text)
      Text="";
  }

  if (ObjectProperties->Cols[1]->Strings[0]!=Text)
    ObjectProperties->Cols[1]->Strings[0]=Text;
  if (ObjectProperties->Cols[1]->Strings[1]!=Left)
    ObjectProperties->Cols[1]->Strings[1]=Left;
  if (ObjectProperties->Cols[1]->Strings[2]!=Top)
    ObjectProperties->Cols[1]->Strings[2]=Top;
  if (ObjectProperties->Cols[1]->Strings[3]!=Right)
    ObjectProperties->Cols[1]->Strings[3]=Right;
  if (ObjectProperties->Cols[1]->Strings[3]!=Bottom)
    ObjectProperties->Cols[1]->Strings[4]=Bottom;
  if (ObjectProperties->Cols[1]->Strings[5]!=Width)
    ObjectProperties->Cols[1]->Strings[5]=Width;
  if (ObjectProperties->Cols[1]->Strings[6]!=Height)
    ObjectProperties->Cols[1]->Strings[6]=Height;

  ObjectProperties->Enabled=true;
}


/////////////////////////////////////////////////////////////////////////////
//
//  SetObjectProperties()
//
//  ������������� ��������� �������� �� ���������� ��������
//
void __fastcall TEditWindow::SetObjectProperties(int Property, AnsiString Value)
{
  TEditObject *Object;
  TUndoItem *UndoItem;
  AnsiString TempDescription;

  bool updating=false;

  if (Value=="")
    return;

  for (int i=0; i<SelectedObjects->Count; i++) {
    Object=SelectedObjects->Items[i];
    switch (Property) {
      case 0:
        if (Object->Text!=Value) {
          if (!updating) {
            LockWindowUpdate(Handle);
            updating=true;
          }
          Object->Text=Value;
        }
        break;
      case 1:
        if (Object->Left!=StrToInt(Value)) {
          if (!updating) {
            LockWindowUpdate(Handle);
            updating=true;
          }
          Object->Left=StrToInt(Value);
        }
        break;
      case 2:
        if (Object->Top!=StrToInt(Value)) {
          if (!updating) {
            LockWindowUpdate(Handle);
            updating=true;
          }
          Object->Top=StrToInt(Value);
        }
        break;
      case 3:
        if (Object->Width!=StrToInt(Value)-Object->Left) {
          if (!updating) {
            LockWindowUpdate(Handle);
            updating=true;
          }
          Object->Width=StrToInt(Value)-Object->Left;
        }
        break;
      case 4:
        if (Object->Height!=StrToInt(Value)-Object->Top) {
          if (!updating) {
            LockWindowUpdate(Handle);
            updating=true;
          }
          Object->Height=StrToInt(Value)-Object->Top;
        }
        break;
      case 5:
        if (Object->Width!=StrToInt(Value)) {
          if (!updating) {
            LockWindowUpdate(Handle);
            updating=true;
          }
          Object->Width=StrToInt(Value);
        }
        break;
      case 6:
        if (Object->Height!=StrToInt(Value)) {
          if (!updating) {
            LockWindowUpdate(Handle);
            updating=true;
          }
          Object->Height=StrToInt(Value);
        }
        break;
    }
  }

  ResetObjectProperties();

  if (updating) {
    ResetSelection();

    // UndoRedo
    UndoItem=NewUndoItem(utChange);
    SetMemUndoItem(UndoItem);

    TempDescription="��������� �������";
    TempDescription+=SelectedObjects->Count>1 ?
      " ������ ��������" : " �������";
      
    UndoItem->Description=TempDescription;

    GrabHandlesOperation(ghoMove);
    
    LockWindowUpdate(0);
    Update();
    
    if (SelectedObjects->Count>0)
      GrabHandlesOperation(ghoShow);

  }
}


/////////////////////////////////////////////////////////////////////////////
//
//  CopyToClipboard()
//
//  �������� ���������� ������� � clipboard
//
void __fastcall TEditWindow::CopyToClipboard()
{
  TEditObject *Object, *ClipboardObject;
  for (int i=0; i<Clipboard->Count; i++)
    delete Clipboard->Items[i];
  Clipboard->Clear();

  for (int i=0; i<SelectedObjects->Count; i++) {
    Object=SelectedObjects->Items[i];
    ClipboardObject=new TEditObject(Object->Type);
    ClipboardObject->Assign(Object);

    if (XGridStep>1)
      ClipboardObject->Left+=RoundToNearest(PasteOffsetX, XGridStep);
    else
      ClipboardObject->Left+=PasteOffsetX;

    if (YGridStep>1)
      ClipboardObject->Top+=RoundToNearest(PasteOffsetY, YGridStep);
    else
      ClipboardObject->Top+=PasteOffsetY;
      
    Clipboard->Add(ClipboardObject);
  }
  
  if (OnClipboardChanged) {
    OnClipboardChanged(Clipboard->Count);
  }
}


/////////////////////////////////////////////////////////////////////////////
//
//  CutToClipboard()
//
//  ���������� ���������� ������� � clipboard
//
void __fastcall TEditWindow::CutToClipboard()
{
  CopyToClipboard();
  DeleteSelectedObjects();
  if (OnClipboardChanged) {
    OnClipboardChanged(Clipboard->Count);
  }
}


/////////////////////////////////////////////////////////////////////////////
//
//  PasteFromClipboard()
//
//  ��������� ������� �� clipboard
//
void __fastcall TEditWindow::PasteFromClipboard()
{
  TUndoItem *UndoItem;
  int ObjectPos;
  AnsiString TempDescription;

  if (Clipboard->Count<1)
    return;

  UndoItem=NewUndoItem(utAdd);
  TempDescription="����������";
  TempDescription+=Clipboard->Count>1?
    " ������ ��������" : " �������";
  UndoItem->Description=TempDescription;

  LockWindowUpdate(Handle);

  ClearSelectedObjects();

  for (int i=0; i<Clipboard->Count; i++) {
    Clipboard->Items[i]->Parent=this;
    ObjectPos=Objects->Add(Clipboard->Items[i]);
    AddDataUndoItem(UndoItem, Clipboard->Items[i], ObjectPos);
    UpdateObjectCount();
    AddSelectedObject(Clipboard->Items[i], false);
  }

  SetMemUndoItem(UndoItem);
  
  Clipboard->Clear();
  CopyToClipboard();

  ResetObjectProperties();
  
  if (OnClipboardChanged) {
    OnClipboardChanged(Clipboard->Count);
  }

  LockWindowUpdate(0);
  Update();

  GrabHandlesOperation(ghoMove);
  GrabHandlesOperation(ghoShow);

  Modified=true;
}


/////////////////////////////////////////////////////////////////////////////
//
//  SelectAll()
//
void __fastcall TEditWindow::SelectAll()
{
  LockWindowUpdate(Handle);

  ClearSelectedObjects();

  for (int i=0; i<Objects->Count; i++)
    AddSelectedObject(Objects->Items[i], false);

  ResetObjectProperties();

  LockWindowUpdate(0);
  Update();

  GrabHandlesOperation(ghoMove);
  GrabHandlesOperation(ghoShow);
}


/////////////////////////////////////////////////////////////////////////////
//
//  SaveToFile()
//
//  ��������� ������������ �������� � ����
//
int __fastcall TEditWindow::SaveToFile(AnsiString FileName)
{
  int fd;
  TEditObject *Object;
  AnsiString CurStr, TextProperty;

  fd=FileCreate(FileName);
  if (fd==-1)
    return -1;

  for (int i=0; i<Objects->Count; i++) {
    Object=Objects->Items[i];
    CurStr="<";
    TextProperty="text";
    switch (Object->Type) {
      case otButton:
        CurStr+="BUTTON";
        TextProperty="caption";
        break;
      case otLabel:
        CurStr+="LABEL";
        break;
      case otTextEdit:
        CurStr+="TEXTEDIT";
        break;
      default:
        continue;
    }
    CurStr+=" left=\"" + IntToStr(Object->Left) + "\";"
      + " top=\"" + IntToStr(Object->Top) + "\";"
      + " width=\"" + IntToStr(Object->Width) + "\";"
      + " height=\"" + IntToStr(Object->Height) + "\";"
      + " " + TextProperty + "=\"" + Object->Text + "\">\n";
    FileWrite(fd, CurStr.c_str(), CurStr.Length());
  }

  FileClose(fd);
  Modified=false;

  return 0;
}


/////////////////////////////////////////////////////////////////////////////
//
//  SetObjectsParent()
//
//  ������������� �������� EditWindow ��� ���� ��������
//
void __fastcall TEditWindow::SetObjectsParent()
{
  LockWindowUpdate(Handle);
  for (int i=0; i<Objects->Count; i++) {
    Objects->Items[i]->Parent=this;
  }
  LockWindowUpdate(0);
}


/////////////////////////////////////////////////////////////////////////////
//
//  BringToFrontSelection()
//
void __fastcall TEditWindow::BringToFrontSelection()
{
  for (int i=0; i<SelectedObjects->Count; i++)
    SelectedObjects->Items[0]->BringToFront();
  GrabHandlesOperation(ghoShow);
}


/////////////////////////////////////////////////////////////////////////////
//
//  SendToBackSelection()
//
void __fastcall TEditWindow::SendToBackSelection()
{
  for (int i=0; i<SelectedObjects->Count; i++)
    SelectedObjects->Items[0]->SendToBack();
  GrabHandlesOperation(ghoShow);
}


/////////////////////////////////////////////////////////////////////////////
//
//  SetModified()
//
//  Putter
//
void __fastcall TEditWindow::SetModified(bool value)
{
  if (Panels!=NULL && FModified!=value)
    if (value)
      Panels->Items[4]->Text="������� ���������";
    else
      Panels->Items[4]->Text="��� ���������";

  FModified = value;
}


/////////////////////////////////////////////////////////////////////////////
//
//  ResetUndo()
//
//  ������������� UndoRedo � ��������� (������) ���������
//
void __fastcall TEditWindow::ResetUndo()
{
  TUndoItem *Item;

  FreeUndoItems(0);
  Item=NewUndoItem(utChange, false);
  SetMemUndoItem(Item);
}


/////////////////////////////////////////////////////////////////////////////
//
//  FreeUndoItems()
//
//  ����������� ������, ������� ���������� ���������� UndoRedo,
//  ������� � Pos, � ������� UndoRedo
//
void __fastcall TEditWindow::FreeUndoItems(int Pos)
{
  while (UndoRedo->Count-1>=Pos)
    DeleteUndoItem(Pos);

  UndoRedoPos=Pos-1;

  if (OnUndoRedoChanged)
    OnUndoRedoChanged(UndoRedoPos>0, UndoRedoPos<UndoRedo->Count-1);
}


/////////////////////////////////////////////////////////////////////////////
//
//  DeleteUndoItem()
//
//  ������� ������� Undo � �������� �������
//
void __fastcall TEditWindow::DeleteUndoItem(int Pos)
{
  int Bounds[5];
  int Values[7];
  TUndoItem *Item;

  Item=UndoRedo->Items[Pos];

  Item->Mem->Seek(0, soFromBeginning);
  while (Item->Mem->Read(Bounds, sizeof(Bounds))>0)
    delete (char *)Bounds[4];
    
  if (Item->Data) {
    Item->Data->Seek(0, soFromBeginning);
    while (Item->Data->Read(Values, sizeof(Values))>0)
      delete (char *)Values[6];
  }
  delete Item;

  UndoRedo->Delete(Pos);
}


/////////////////////////////////////////////////////////////////////////////
//
//  Undo()
//
//  �������� (���������) ��������� �������� �� ������� Pos � UndoRedo
//
void __fastcall TEditWindow::Undo(int Pos)
{
  int Bounds[5];
  TUndoItem *Item, *NextItem;
  bool ClearSelection=false;

  LockWindowUpdate(Handle);

  if (Pos<UndoRedoPos) {
    // UNDO
    for (int i=UndoRedoPos-1; i>=Pos; i--) {
      Item=UndoRedo->Items[i];
      NextItem=UndoRedo->Items[i+1];
      NextItem->MenuItem->Checked=false;

      if (NextItem->Type==utAdd) {
        if (!ClearSelection)
          ClearSelectedObjects();
        ClearSelection=true;
        UndoDeleteObjects(NextItem->Data);
      } else if (NextItem->Type==utDelete) {
        if (!ClearSelection)
          ClearSelectedObjects();
        ClearSelection=true;
        UndoAddObjects(NextItem->Data);
      }

      Item->Mem->Seek(0, soFromBeginning);
      for (int j=0; j<Objects->Count; j++) {
        Item->Mem->Read(Bounds, sizeof(Bounds));
        Objects->Items[j]->SetBounds(Bounds[0], Bounds[1],
          Bounds[2], Bounds[3]);
        Objects->Items[j]->Text=(char *)Bounds[4];
      }
    }
  } else if (Pos>UndoRedoPos) {
    // REDO
    for (int i=UndoRedoPos+1; i<=Pos; i++) {
      Item=UndoRedo->Items[i];
      Item->MenuItem->Checked=true;

      if (Item->Type==utAdd) {
        if (!ClearSelection)
          ClearSelectedObjects();
        ClearSelection=true;
        RedoAddObjects(Item->Data);
      } else if (Item->Type==utDelete) {
        if (!ClearSelection)
          ClearSelectedObjects();
        ClearSelection=true;
        RedoDeleteObjects(Item->Data);
      }

      Item->Mem->Seek(0, soFromBeginning);
      for (int j=0; j<Objects->Count; j++) {
        Item->Mem->Read(Bounds, sizeof(Bounds));
        Objects->Items[j]->SetBounds(Bounds[0], Bounds[1],
          Bounds[2], Bounds[3]);
        Objects->Items[j]->Text=(char *)Bounds[4];
      }
    }
  }

  ResetObjectProperties();
  
  if (ClearSelection) {
    UpdateObjectCount();
    LockWindowUpdate(0);
  } else {
    GrabHandlesOperation(ghoHide);
    ResetSelection();
    GrabHandlesOperation(ghoMove);
    LockWindowUpdate(0);
    Update();
    if (SelectedObjects->Count>0)
      GrabHandlesOperation(ghoShow);
  }

  UndoRedoPos=Pos;

  if (OnUndoRedoChanged)
    OnUndoRedoChanged(UndoRedoPos>0, UndoRedoPos<UndoRedo->Count-1);

}


/////////////////////////////////////////////////////////////////////////////
//
//  UndoDeleteObjects()
//
//  ��������������� ������� ��� Undo()
//
//  ������� ����������� ��� ���������� Undo �������
//
void __fastcall TEditWindow::UndoDeleteObjects(TMemoryStream * Data)
{
  int Values[7], StreamPos;

  StreamPos=Data->Size-sizeof(Values);

  while (StreamPos>=0) {
    Data->Seek(StreamPos, soFromBeginning);
    Data->Read(Values, sizeof(Values));
    delete Objects->Items[Values[5]];
    Objects->Delete(Values[5]);
    StreamPos-=sizeof(Values);
  }
}


/////////////////////////////////////////////////////////////////////////////
//
//  UndoAddObjects()
//
//  ��������������� ������� ��� Undo()
//
//  ��������� ����������� ��� ���������� Undo �������
//
void __fastcall TEditWindow::UndoAddObjects(TMemoryStream * Data)
{
  TEditObject *Object;
  int Values[7], StreamPos;

  StreamPos=Data->Size-sizeof(Values);

  while (StreamPos>=0) {
    Data->Seek(StreamPos, soFromBeginning);
    Data->Read(Values, sizeof(Values));
    Object=new TEditObject((TObjectType )Values[4]);
    Object->Left=Values[0];
    Object->Top=Values[1];
    Object->Width=Values[2];
    Object->Height=Values[3];
    Object->Text=(char *)Values[6];
    Object->Parent=this;
    Objects->Insert(Values[5], Object);
    StreamPos-=sizeof(Values);
  }
}

/////////////////////////////////////////////////////////////////////////////
//
//  RedoDeleteObjects()
//
//  ��������������� ������� ��� Undo()
//
//  ������� ����������� ��� ���������� Redo �������
//
void __fastcall TEditWindow::RedoDeleteObjects(TMemoryStream * Data)
{
  int Values[7];

  Data->Seek(0, soFromBeginning);
  while (Data->Read(Values, sizeof(Values))>0) {
    delete Objects->Items[Values[5]];
    Objects->Delete(Values[5]);
  }
}


/////////////////////////////////////////////////////////////////////////////
//
//  RedoAddObjects()
//
//  ��������������� ������� ��� Undo()
//
//  ��������� ����������� ��� ���������� Redo �������
//
void __fastcall TEditWindow::RedoAddObjects(TMemoryStream * Data)
{
  TEditObject *Object;
  int Values[7];

  Data->Seek(0, soFromBeginning);
  while (Data->Read(Values, sizeof(Values))>0) {
    Object=new TEditObject((TObjectType )Values[4]);
    Object->Left=Values[0];
    Object->Top=Values[1];
    Object->Width=Values[2];
    Object->Height=Values[3];
    Object->Text=(char *)Values[6];
    Object->Parent=this;
    Objects->Insert(Values[5], Object);
  }
}


/////////////////////////////////////////////////////////////////////////////
//
//  NewUndoItem()
//
//  ������� � ��������� � UndoRedo �������� �
//  ���������� �� ��� ������
//
TUndoItem * __fastcall TEditWindow::NewUndoItem(TUndoType Type, bool AddToMenu)
{
  TUndoItem *Item;

  if (UndoRedoPos<UndoRedo->Count-1) {
    FreeUndoItems(UndoRedoPos+1);
  }

  if (AddToMenu) {
    Item=new TUndoItem(Type, UndoMenu);
    //Item->Pos=UndoRedoPos+1;
    Item->OnClick=UndoItemClick;

    if (OnUndoRedoChanged)
      // can UNDO, can't REDO
      OnUndoRedoChanged(true, false);

  } else
    Item=new TUndoItem(Type, NULL);

  UndoRedo->Add(Item);
  UndoRedoPos++;

  if (UndoRedo->Count>MaxUndoRedoSize) {
    DeleteUndoItem(0);
    UndoRedo->Items[0]->RemoveFromMenu();
    UndoRedoPos--;
  }

  return Item;
}


/////////////////////////////////////////////////////////////////////////////
//
//  SetMemUndoItem()
//
//  ���������� � Item ������� ������������ ��������
//
void __fastcall TEditWindow::SetMemUndoItem(TUndoItem *Item)
{
  TEditObject *Object;
  int Bounds[5];
  char *Text;

  for (int i=0; i<Objects->Count; i++) {
    Object=Objects->Items[i];
    Text=new char[Object->Text.Length()+1];
    strcpy(Text, Object->Text.c_str());
    Bounds[0]=Object->Left;
    Bounds[1]=Object->Top;
    Bounds[2]=Object->Width;
    Bounds[3]=Object->Height;
    Bounds[4]=(int)Text;
    Item->Mem->Write(Bounds, sizeof(Bounds));
  }
}


/////////////////////////////////////////////////////////////////////////////
//
//  AddDataUndoItem()
//
//  ��������� � Item ���������� � �������/��������
//  ������� Object
//
void __fastcall TEditWindow::AddDataUndoItem(TUndoItem *Item, TEditObject * Object, int ObjectPos)
{
  int Values[7];
  char *Text;

  Text=new char[Object->Text.Length()+1];
  strcpy(Text, Object->Text.c_str());

  Values[0]=Object->Left;
  Values[1]=Object->Top;
  Values[2]=Object->Width;
  Values[3]=Object->Height;
  Values[4]=Object->Type;
  Values[5]=ObjectPos;
  Values[6]=(int)Text;
  Item->Data->Write(Values, sizeof(Values));
}


/////////////////////////////////////////////////////////////////////////////
//
//  UndoItemClick()
//
//  ���������� ��� ������ �������� Undo �� ������
//
void __fastcall TEditWindow::UndoItemClick(int Pos)
{
  if (UndoRedo->Items[Pos]->MenuItem->Checked)
    Undo(Pos-1);
  else
    Undo(Pos);
}


/////////////////////////////////////////////////////////////////////////////
//
//  AlignSelectedObjects()
//
//  ������������ ������������ ���������� ��������
//
void __fastcall TEditWindow::AlignSelectedObjects(TAlignType HorizType, TAlignType VertType)
{
  TEditObject *Object, *Anchor;
  TSortedObjectList *SortedObjects;
  int Space, DeltaX, DeltaY, OriginX, OriginY;
  TUndoItem *UndoItem;
  AnsiString TempDescription;

  if (!(SelectedObjects->Count>1
        || (SelectedObjects->Count==1
            && (HorizType==atCenter || VertType==atCenter)
           )
       )
     ) return;

  GrabHandlesOperation(ghoHide);

  // I. ������������ �� ��� X

  if (HorizType==atSpace || HorizType==atCenter) {
    SortedObjects=new TSortedObjectList(ostLeft);
    Space=0;
    
    for (int i=0; i<SelectedObjects->Count; i++) {
      SortedObjects->Add(SelectedObjects->Items[i]);
      Space+=SelectedObjects->Items[i]->Width;
    }
    SortedObjects->Sort();

    if (HorizType==atSpace) {
      DeltaX=(Selection.Right - Selection.Left + 1 - Space) /
             (SelectedObjects->Count - 1);
      OriginX=SortedObjects->Items[0]->Left;
      for (int i=0; i<SortedObjects->Count; i++) {
        SortedObjects->Items[i]->Left=OriginX;
        OriginX+=DeltaX+SortedObjects->Items[i]->Width;
      }
    } else {
      DeltaX=(Parent->ClientWidth - Selection.Right + Selection.Left - 1) / 2 -
             SortedObjects->Items[0]->Left - Left;
      for (int i=0; i<SortedObjects->Count; i++)
        SortedObjects->Items[i]->Left+=DeltaX;
    }

    delete SortedObjects;
  } else {
    // ����������� �� ������� ����������� ������� (�����)
    Anchor=SelectedObjects->Items[0];
    for (int i=0; i<SelectedObjects->Count; i++) {
      Object=SelectedObjects->Items[i];
      switch (HorizType) {
        case atLefts:
          Object->Left=Anchor->Left;
          break;
        case atCenters:
          Object->Left=Anchor->Left + Anchor->Width/2 - Object->Width/2;
          break;
        case atRights:
          Object->Left=Anchor->Left + Anchor->Width - Object->Width;
          break;
      }
    }
  }

  // II. ������������ �� ��� Y

  if (VertType==atSpace || VertType==atCenter) {
    SortedObjects=new TSortedObjectList(ostTop);
    Space=0;

    for (int i=0; i<SelectedObjects->Count; i++) {
      SortedObjects->Add(SelectedObjects->Items[i]);
      Space+=SelectedObjects->Items[i]->Height;
    }
    SortedObjects->Sort();

    if (VertType==atSpace) {
      DeltaY=(Selection.Bottom - Selection.Top + 1 - Space) /
             (SelectedObjects->Count - 1);
      OriginY=SortedObjects->Items[0]->Top;
      for (int i=0; i<SortedObjects->Count; i++) {
        SortedObjects->Items[i]->Top=OriginY;
        OriginY+=DeltaY+SortedObjects->Items[i]->Height;
      }
    } else {
      DeltaY=(Parent->ClientHeight - Selection.Bottom + Selection.Top - 1) / 2 -
             SortedObjects->Items[0]->Top - Top;
      for (int i=0; i<SortedObjects->Count; i++)
        SortedObjects->Items[i]->Top+=DeltaY;
    }

    delete SortedObjects;
  } else {
    // ����������� �� ������� ����������� ������� (�����)
    Anchor=SelectedObjects->Items[0];
    for (int i=0; i<SelectedObjects->Count; i++) {
      Object=SelectedObjects->Items[i];
      switch (VertType) {
        case atTops:
          Object->Top=Anchor->Top;
          break;
        case atCenters:
          Object->Top=Anchor->Top + Anchor->Height/2 - Object->Height/2;
          break;
        case atBottoms:
          Object->Top=Anchor->Top + Anchor->Height - Object->Height;
          break;
      }
    }
  }

  // UndoRedo
  UndoItem=NewUndoItem(utChange);
  SetMemUndoItem(UndoItem);
  TempDescription="������������";
  TempDescription+=SelectedObjects->Count>1 ?
    " ������ ��������" : " �������";
  UndoItem->Description=TempDescription;

  Update();
  ResetObjectProperties();

  ResetSelection();
  GrabHandlesOperation(ghoMove);
  GrabHandlesOperation(ghoShow);


}


/////////////////////////////////////////////////////////////////////////////
//
//  SizeSelectedObjects()
//
//  �������� ������� ��������� �������� � ������������ � TSizeType
//
void __fastcall TEditWindow::SizeSelectedObjects(TSizeType XType, TSizeType YType, int SetWidth, int SetHeight)
{
  int NewWidth, NewHeight;
  TUndoItem *UndoItem;
  AnsiString TempDescription;

  if (!(SelectedObjects->Count>1
        || (SelectedObjects->Count==1
            && (XType==stSet || YType==stSet)
           )
       )
     ) return;

  NewWidth=NewHeight=-1;

  if (SelectedObjects->Count>1
      && (XType==stShrink || XType==stGrow)) {
    NewWidth=SelectedObjects->Items[0]->Width;
    for (int i=1; i<SelectedObjects->Count; i++)
      if ((XType==stShrink && NewWidth>SelectedObjects->Items[i]->Width)
          || (XType==stGrow && NewWidth<SelectedObjects->Items[i]->Width))
        NewWidth=SelectedObjects->Items[i]->Width;
  } else if (XType==stSet)
    NewWidth=SetWidth;

  if (SelectedObjects->Count>1
      && (YType==stShrink || YType==stGrow)) {
    NewHeight=SelectedObjects->Items[0]->Height;
    for (int i=1; i<SelectedObjects->Count; i++)
      if ((YType==stShrink && NewHeight>SelectedObjects->Items[i]->Height)
          || (YType==stGrow && NewHeight<SelectedObjects->Items[i]->Height))
        NewHeight=SelectedObjects->Items[i]->Height;
  } else if (YType==stSet)
    NewHeight=SetHeight;

  if (NewWidth>-1 || NewHeight>-1) {
    GrabHandlesOperation(ghoHide);

    for (int i=0; i<SelectedObjects->Count; i++) {
      if (NewWidth!=-1)
        SelectedObjects->Items[i]->Width=NewWidth;

      if (NewHeight!=-1)
        SelectedObjects->Items[i]->Height=NewHeight;
    }

    // UndoRedo
    UndoItem=NewUndoItem(utChange);
    SetMemUndoItem(UndoItem);
    TempDescription="��������� ��������";
    TempDescription+=SelectedObjects->Count>1 ?
      " ������ ��������" : " �������";
    UndoItem->Description=TempDescription;

    Update();
    ResetObjectProperties();

    ResetSelection();
    GrabHandlesOperation(ghoMove);
    GrabHandlesOperation(ghoShow);

  }
}


/////////////////////////////////////////////////////////////////////////////
//
//  AlignToGridSelectedObjects()
//
//  ����������� ���������� ������� �� �����
//
void __fastcall TEditWindow::AlignToGridSelectedObjects()
{
  int Left, Top;
  TEditObject *Object;
  TUndoItem *UndoItem;
  AnsiString TempDescription;

  if (XGridStep<2 && YGridStep<2)
    return;

  GrabHandlesOperation(ghoHide);

  for (int i=0; i<SelectedObjects->Count; i++) {
    Object=SelectedObjects->Items[i];
    Left=Object->Left;
    Top=Object->Top;

    if (XGridStep>1)
      Object->Left=RoundToNearest(Left, XGridStep);
    if (YGridStep>1)
      Object->Top=RoundToNearest(Top, YGridStep);
  }

  // UndoRedo
  UndoItem=NewUndoItem(utChange);
  SetMemUndoItem(UndoItem);
  TempDescription="������������ �� �����";
  TempDescription+=SelectedObjects->Count>1 ?
    " ������ ��������" : " �������";
  UndoItem->Description=TempDescription;

  Update();
  ResetObjectProperties();

  ResetSelection();
  GrabHandlesOperation(ghoMove);
  GrabHandlesOperation(ghoShow);
}


/////////////////////////////////////////////////////////////////////////////
//
//  SetPopupMenu()
//
void __fastcall TEditWindow::SetPopupMenu(TPopupMenu * Menu)
{
  PopupMenu=Menu;
}

