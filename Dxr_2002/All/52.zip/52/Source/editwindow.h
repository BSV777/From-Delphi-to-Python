/////////////////////////////////////////////////////////////////////////////
//
//  editwindow.h
//
//  �������� ������ TEditWindow (������� ��������������)
//
/////////////////////////////////////////////////////////////////////////////
#ifndef editwindowH
#define editwindowH
/////////////////////////////////////////////////////////////////////////////
#include <Grids.hpp>
#include <Comctrls.hpp>
/////////////////////////////////////////////////////////////////////////////
#include "common.h"
/////////////////////////////////////////////////////////////////////////////

class TEditWindow : public TWinControl {

public:
    __fastcall TEditWindow(TComponent *Owner, TWinControl *fParent, int fWidth, int fHeight);
    __fastcall ~TEditWindow();

    TUndoRedo *UndoRedo;
    int UndoRedoPos;
    TUndoRedoChangedEvent OnUndoRedoChanged;

    TSelectedCountChangedEvent OnSelectedCountChanged;
    TClipboardChangedEvent OnClipboardChanged;
    TObjectCountChangedEvent OnObjectCountChanged;

    TMenuItem *UndoMenu;

    bool xModified;

    bool ShowGrid;
    TGridType GridType;
    int XGridStep;
    int YGridStep;

    TScrollBar *HorizBar;
    TScrollBar *VertBar;

    TStringGrid *ObjectProperties;
    TStaticText *opObjectType;

    TStatusPanels *Panels;

    TObjectType InsertingObject;
    TToolButton *btEdit;
    bool NeedToPressBtEdit;

    TPoint CursorStart,CursorLast,CursorNow;
    TRect Selection;
    bool Drawing,Moving,Sizing;

    TObjectList *Objects;
    TObjectList *SelectedObjects;
    TObjectList *Clipboard;

    TList *UndoItemsList;
    int UndoPos;

    void __fastcall SetGridResolution(int XResolution, int YResolution);

    void __fastcall GrabHandlesOperation(TGrabHandleOperation Operation);
    void __fastcall DrawObjectHandles(TEditObject *Object, bool Visible);
    
    void __fastcall ClearSelectedObjects();
    void __fastcall DeleteSelectedObjects();

    void __fastcall UpdateObjectCount();
    void __fastcall UpdateSelectedObjectCount();

    bool __fastcall HandleMessage(tagMSG Msg);

    void __fastcall ResetObjectProperties();
    void __fastcall SetObjectProperties(int Property, AnsiString Value);

    void __fastcall CopyToClipboard();
    void __fastcall CutToClipboard();
    void __fastcall PasteFromClipboard();
    void __fastcall SelectAll();
    int __fastcall SaveToFile(AnsiString FileName);
    void __fastcall SetObjectsParent();

    void __fastcall BringToFrontSelection();
    void __fastcall SendToBackSelection();

    void __fastcall ResetUndo();
    void __fastcall FreeUndoItems(int Pos);

    void __fastcall Undo(int Steps);

    TUndoItem * __fastcall NewUndoItem(TUndoType Type, bool AddToMenu=true);
    void __fastcall SetMemUndoItem(TUndoItem *Item);
    void __fastcall AddDataUndoItem(TUndoItem *Item, TEditObject * Object, int ObjectPos);
    void __fastcall UndoDeleteObjects(TMemoryStream * Data);
    void __fastcall UndoAddObjects(TMemoryStream * Data);
    void __fastcall RedoDeleteObjects(TMemoryStream * Data);
    void __fastcall RedoAddObjects(TMemoryStream * Data);

    void __fastcall AlignSelectedObjects(TAlignType HorizType, TAlignType VertType);
    void __fastcall SizeSelectedObjects(TSizeType XType, TSizeType YType, int SetWidth, int SetHeight);
    void __fastcall AlignToGridSelectedObjects();

    void __fastcall SetPopupMenu(TPopupMenu * Menu);

    __property bool Modified  = { read = FModified, write = SetModified };

private:
    TGrabHandle *GrabHandles[ghtLast-ghtFirst+1];
    TGrabHandleType SelectedHandle;
    bool FModified;

    void EraseBackground(TMessage &Message);
    HDC GetClipDC();
    void DrawFocusRect();
    void SetSelection();
    void ChangeSelection();
    void __fastcall DrawGrabHandle(HWND hwnd, HDC dc, int X, int Y, bool Visible);
    TEditObject * __fastcall FindObject(HWND hwnd);
    void __fastcall AddSelectedObject(TEditObject * Object, bool UpdateProperties);
    void __fastcall DeleteSelectedObject(TEditObject * Object);
    void __fastcall AdjustSelectedObjects();
    void __fastcall AddObjectsInSelection();
    void __fastcall ResetSelection();
    TGrabHandleType __fastcall GetGrabHandle(tagMSG Msg);
    void __fastcall SetModified(bool value);
    void __fastcall UndoItemClick(int Pos);
    void __fastcall DeleteUndoItem(int Pos);
    
protected:
    BEGIN_MESSAGE_MAP
        VCL_MESSAGE_HANDLER(WM_ERASEBKGND, TMessage, EraseBackground)
    END_MESSAGE_MAP(TWinControl)
};

/////////////////////////////////////////////////////////////////////////////
#endif
