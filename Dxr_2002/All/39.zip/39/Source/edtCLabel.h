// edtCLabel.h: interface for the edtCLabel class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EDTCLABEL_H__248B80E8_64F2_4316_B389_2011DA5CA572__INCLUDED_)
#define AFX_EDTCLABEL_H__248B80E8_64F2_4316_B389_2011DA5CA572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BaseObj.h"

class edtCLabel : public CBaseObj
{
	DECLARE_DYNAMIC(edtCLabel)
protected:
//	edtCLabel();
public:
	edtCLabel(CPoint position);
	virtual ~edtCLabel();

	virtual void Draw(CDC* pDC);
	virtual void Serialize(CArchive &ar);
};

#endif // !defined(AFX_EDTCLABEL_H__248B80E8_64F2_4316_B389_2011DA5CA572__INCLUDED_)
