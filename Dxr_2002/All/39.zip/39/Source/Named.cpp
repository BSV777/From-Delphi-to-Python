/*------------------------------------------------------------------------------
����:		Named.cpp
����������: 
������:		1.0
����:		01-03-2002
�����(�):	�������� ����� (merz@smtp.ru)
------------------------------------------------------------------------------*/

#include "stdafx.h"
#include "named.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//------------------------------------------------------------------------------

CNamed::CNamed(CString newname)
{
	m_sName = newname;
}

CNamed::CNamed()
{
	m_sName = "";
}

//------------------------------------------------------------------------------

CNamed::~CNamed()
{}

//------------------------------------------------------------------------------

CString CNamed::Name() const
{
	return m_sName;
}

//------------------------------------------------------------------------------

CNamed CNamed::operator = (CNamed& source)
{
	m_sName = source.Name();
	return *this;
}