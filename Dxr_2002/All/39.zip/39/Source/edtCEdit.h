// edtCEdit.h: interface for the edtCEdit class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EDTCEDIT_H__72C7DFB1_B7E4_4658_866C_D8E03B84EF3F__INCLUDED_)
#define AFX_EDTCEDIT_H__72C7DFB1_B7E4_4658_866C_D8E03B84EF3F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BaseObj.h"

class edtCEdit : public CBaseObj
{
	DECLARE_DYNAMIC(edtCEdit)
protected:
//	edtCEdit();

public:
	edtCEdit(CPoint position);
	virtual ~edtCEdit();

	virtual void ReSize(CSize& NewSize);

	virtual void Draw(CDC* pDC);
	virtual void Serialize(CArchive &ar);
};

#endif // !defined(AFX_EDTCEDIT_H__72C7DFB1_B7E4_4658_866C_D8E03B84EF3F__INCLUDED_)
