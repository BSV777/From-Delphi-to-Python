//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Editor.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_EDITORTYPE                  129
#define IDD_OBJPROPS                    132
#define IDD_WARNING                     134
#define IDC_COMBO1                      1001
#define IDC_NAME_EDIT                   1004
#define IDC_DONTSHOW                    1005
#define IDC_WARN_MESSAGE                1006
#define ID_OBJECT_ADD_BTN               32771
#define ID_OBJECT_ADD_EDIT              32772
#define ID_OBJECT_ADD_LABEL             32773
#define ID_BUTTON32777                  32777
#define ID_SELECT_MODE                  32777
#define ID_BUTTON32778                  32778
#define ID_DEL_SELECT_OBJ               32779
#define ID_EDIT_SEL_NONE                32781
#define ID_EDIT_SEL_INVERSE             32782
#define ID_EDIT_SEL_ALL                 32783
#define ID_EDIT_DEL                     32785
#define ID_OBJECT_PROPS                 32787
#define ID_FILE_CONVERT_HTML            32789

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32790
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
