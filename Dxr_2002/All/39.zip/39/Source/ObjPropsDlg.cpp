// ObjPropsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Editor.h"
#include "ObjPropsDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CObjPropsDlg dialog


CObjPropsDlg::CObjPropsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CObjPropsDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CObjPropsDlg)
	m_sName = _T("");
	//}}AFX_DATA_INIT
	object = NULL;
}


void CObjPropsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CObjPropsDlg)
	DDX_Text(pDX, IDC_NAME_EDIT, m_sName);
	DDV_MaxChars(pDX, m_sName, 128);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CObjPropsDlg, CDialog)
	//{{AFX_MSG_MAP(CObjPropsDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CObjPropsDlg message handlers

BOOL CObjPropsDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_sName = object->Name();
	UpdateData(FALSE);
	GetDlgItem(IDC_NAME_EDIT)->SetFocus();
	return FALSE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CObjPropsDlg::OnOK() 
{
	UpdateData();
	object->Name(m_sName);
	CDialog::OnOK();
}

