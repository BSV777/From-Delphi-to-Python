// EditorView.h : interface of the CEditorView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_EDITORVIEW_H__EB9994B7_0EDE_4465_9456_600040FAFF43__INCLUDED_)
#define AFX_EDITORVIEW_H__EB9994B7_0EDE_4465_9456_600040FAFF43__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

enum mode
{
	Action, // �������
	Button, // ���������� Button
	TextEdit, // ���������� TextEdit
	Label}; // ���������� Label

class CEditorView : public CScrollView
{
protected: // create from serialization only
	CEditorView();
	DECLARE_DYNCREATE(CEditorView)

// Attributes
public:
	CEditorDoc* GetDocument();

	CPoint StartPoint;
	CPoint DragPoint;

	BOOL DrawSelection;
	BOOL DrawMovedObjects;
	BOOL ResizeObject;
	CSize DragOffset;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditorView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	VOID ClearLayer(CDC* Layer);
	BOOL InitLayer(CDC* &Layer, CBitmap& map, bool bDeleteOnly = FALSE);
	virtual ~CEditorView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	mode MouseMode;
// Generated message map functions
protected:
	// ����, ��� �������� �������
	CDC* ObjectsLayer;
	// �������� � AreaColorLayer ��������
	//(�������� ��������� ������� �������)
	CBitmap objectsmap;
	// ����, ��� �������� ������������� ���������
	CDC* SelectLayer;
	// �������� � SelectLayer ��������
	CBitmap selectmap;

	//{{AFX_MSG(CEditorView)
	afx_msg void OnSelectMode();
	afx_msg void OnUpdateSelectMode(CCmdUI* pCmdUI);
	afx_msg void OnObjectAddBtn();
	afx_msg void OnUpdateObjectAddBtn(CCmdUI* pCmdUI);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnObjectAddEdit();
	afx_msg void OnUpdateObjectAddEdit(CCmdUI* pCmdUI);
	afx_msg void OnObjectAddLabel();
	afx_msg void OnUpdateObjectAddLabel(CCmdUI* pCmdUI);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnEditDel();
	afx_msg void OnUpdateEditDel(CCmdUI* pCmdUI);
	afx_msg void OnEditSelNone();
	afx_msg void OnUpdateEditSelNone(CCmdUI* pCmdUI);
	afx_msg void OnEditSelInverse();
	afx_msg void OnUpdateEditSelInverse(CCmdUI* pCmdUI);
	afx_msg void OnEditSelAll();
	afx_msg void OnUpdateEditSelAll(CCmdUI* pCmdUI);
	afx_msg void OnObjectProps();
	afx_msg void OnUpdateObjectProps(CCmdUI* pCmdUI);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in EditorView.cpp
inline CEditorDoc* CEditorView::GetDocument()
   { return (CEditorDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITORVIEW_H__EB9994B7_0EDE_4465_9456_600040FAFF43__INCLUDED_)
