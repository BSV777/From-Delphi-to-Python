// BaseObj.h: interface for the CBaseObj class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BASEOBJ_H__)
#define AFX_BASEOBJ_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Named.h"

enum SelectionType {SS_UNSELECT, SS_SELECT, SS_INVERSE};

class CBaseObj :public CNamed, public CObject
{
protected: // ������ ��� ������������
	CBaseObj();

public:
	virtual void Serialize(CArchive &ar);

	CBaseObj(CPoint position);
	
	CBaseObj(CBaseObj& source);

	virtual ~CBaseObj();

	virtual void Draw(CDC* pDC);
	
	void MoveTo(CPoint NewPos);
	void Offset(CSize offset);
	virtual void ReSize(CSize& NewSize);
	CRect GetRect();

	BOOL PointInRect(CPoint point);
	
	CPoint GetPosition() const;
	CSize GetSize() const;

	void Selection(SelectionType type);
	BOOL IsSelected() const;

	// �������� �� ����������� ������� ������� � ���������������
	BOOL IsIntersect(CRect rect);

	virtual CBaseObj operator = (CBaseObj& source);

protected:

	CPoint pos;
	CSize size;
	BOOL select;

};

AFX_INLINE CRect CBaseObj::GetRect()
	{return CRect(pos, size);}

AFX_INLINE void CBaseObj::MoveTo(CPoint NewPos)
	{pos = NewPos;}

AFX_INLINE void CBaseObj::Offset(CSize offset)
	{pos +=offset;}

AFX_INLINE BOOL CBaseObj::IsSelected() const
	{return select;}

AFX_INLINE CPoint CBaseObj::GetPosition() const
	{return pos;}

AFX_INLINE CSize CBaseObj::GetSize() const
	{return size;}
#endif // !defined(AFX_BASEOBJ_H__)
