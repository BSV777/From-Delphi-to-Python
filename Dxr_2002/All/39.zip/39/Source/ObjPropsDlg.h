#if !defined(AFX_OBJPROPSDLG_H__BC5C2149_0F26_4C4A_8D13_CA6C1B94F78C__INCLUDED_)
#define AFX_OBJPROPSDLG_H__BC5C2149_0F26_4C4A_8D13_CA6C1B94F78C__INCLUDED_


#include "Named.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ObjPropsDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CObjPropsDlg dialog

class CObjPropsDlg : public CDialog
{
// Construction
public:
	CNamed *object;

	CObjPropsDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CObjPropsDlg)
	enum { IDD = IDD_OBJPROPS };
	CString	m_sName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CObjPropsDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CObjPropsDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OBJPROPSDLG_H__BC5C2149_0F26_4C4A_8D13_CA6C1B94F78C__INCLUDED_)
