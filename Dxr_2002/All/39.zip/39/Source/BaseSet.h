// BaseSet.h: interface for the CBaseSet class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BASESET_H__6A072E04_54C1_495B_ACB0_B22F0247D5EC__INCLUDED_)
#define AFX_BASESET_H__6A072E04_54C1_495B_ACB0_B22F0247D5EC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>
#include "BaseObj.h"
#include "Named.h"

class CBaseSet  
{
public:
	CBaseSet();
	CBaseSet(CBaseSet& source);
	virtual ~CBaseSet();

	BOOL Add (CBaseObj* newobject);

	void Draw(CDC* pDC);

	virtual void Serialize(CArchive& ar);

	CBaseSet operator = (CBaseSet& source);

	void DrawSelRects(CDC* pDC);
	CRect UnionRect() const;

	void SelectByRect(CRect rect);
	BOOL SelectByPoint(CPoint point, SelectionType type = SS_SELECT);
	void SelectAllAs(SelectionType type);
	
	BOOL SelectedAll() const;
	BOOL AnyThingSelected() const;
	BOOL SelectedOneOnly() const;

	BOOL IsPointOnSelectedObject(CPoint point);
	BOOL IsPointOnCorner(CPoint& point);

	void OffsetSelected (CSize offset);

	BOOL ResizeSelectObject(CSize offset);

	void DeleteSelected();
	void DeleteAll();

	CBaseObj* GetAt(INT i);
	INT GetSize() const;

	CNamed* GetElemForProps();

	// ��������, � �������������� ����� ������ 1 ������?
	CBaseObj* IsOneOnly(CRect rect);
	// ��������, ���� �� � �������������� �������?
	BOOL AnyThingInRect(CRect rect);

	INT GetVertSplitter(CRect rect);
	INT GetHorizSplitter(CRect rect);

protected:
public:
	CArray <CBaseObj*, CBaseObj*> set;
};

AFX_INLINE INT CBaseSet::GetSize() const
{ return set.GetSize();}

#endif // !defined(AFX_BASESET_H__6A072E04_54C1_495B_ACB0_B22F0247D5EC__INCLUDED_)
