// edtCEdit.cpp: implementation of the edtCEdit class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Editor.h"
#include "edtCEdit.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNAMIC(edtCEdit, CObject)

edtCEdit::edtCEdit(CPoint position)
	:CBaseObj(position)
{
	m_sName = "Edit";
}

/*
edtCEdit::edtCEdit()
	: CBaseObj()
{
	m_sName = "Edit";
}
*/
edtCEdit::~edtCEdit()
{

}

void edtCEdit::ReSize(CSize& NewSize)
{
	size.cx = NewSize.cx;
}

void edtCEdit::Draw(CDC* pDC)
{

	CBaseObj::Draw(pDC);
	// ������� ������ ���� �����

	CRect region(pos + CPoint(1,1),
		size - CSize(2,2));
	CPen pen1(PS_SOLID, 1, RGB(50, 50, 50));
	CPen pen2(PS_SOLID, 1, RGB(200, 200, 200));
	CPen pen3(PS_SOLID, 1, RGB(128, 128, 128));
	
	CPen* oldpen = pDC->SelectObject(&pen3);
	pDC->MoveTo(CPoint(pos.x + 1, pos.y + size.cy - 3));
	pDC->LineTo(CPoint(pos.x + 1, pos.y + 1));
	pDC->LineTo(CPoint(pos.x + size.cx - 2, pos.y + 1));
	
	pDC->SelectObject(&pen2);
	pDC->MoveTo(CPoint(pos.x + 2, pos.y + size.cy - 3));
	pDC->LineTo(CPoint(pos.x + size.cx - 3, pos.y + size.cy - 3));
	pDC->LineTo(CPoint(pos.x + size.cx - 3, pos.y + 1));

	pDC->SelectObject(&pen1);
	pDC->MoveTo(CPoint(pos.x + 2, pos.y + size.cy - 4));
	pDC->LineTo(CPoint(pos.x + 2, pos.y + 2));
	pDC->LineTo(CPoint(pos.x + size.cx - 3, pos.y + 2));

	pen1.DeleteObject();
	pen2.DeleteObject();
	pen3.DeleteObject();

	//����� ��������
	pDC->SetBkColor(RGB(255,255,255));
	CRect out = GetRect();

	CSize textsize = pDC->GetTextExtent(m_sName);
	CSize offsetsize = out.Size();
	offsetsize -= textsize;

	out.bottom -=2; out.right -=2;
	out.top +=2; out.left +=2;

	pDC->ExtTextOut(pos.x + offsetsize.cx/2,
		pos.y + offsetsize.cy/2,
		ETO_CLIPPED, &out, m_sName, NULL);

	pDC->SelectObject(oldpen);
}

void edtCEdit::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		CString buf;
		buf.Format("<TextEdit left=\"%i\"; top=\"%i\"; height=\"%i\"; width=\"%i\"; Text=\"%s\">",
			pos.x,pos.y, size.cy, size.cx, m_sName);
		ar.WriteString(buf);
		ar << (char)13 << (char)10;
	}
}