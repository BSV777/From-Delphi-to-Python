// EditorDoc.cpp : implementation of the CEditorDoc class
//

#include "stdafx.h"
#include "Editor.h"

#include "EditorDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditorDoc

IMPLEMENT_DYNCREATE(CEditorDoc, CDocument)

BEGIN_MESSAGE_MAP(CEditorDoc, CDocument)
	//{{AFX_MSG_MAP(CEditorDoc)
	ON_COMMAND(ID_FILE_CONVERT_HTML, OnFileConvertHtml)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditorDoc construction/destruction

CEditorDoc::CEditorDoc()
{
	tempObj = NULL;
}

CEditorDoc::~CEditorDoc()
{
}

BOOL CEditorDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CEditorDoc serialization

void CEditorDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{// ��������� ��������� ��������
		MainObjectSet.Serialize(ar);
	}
	else
	{// ��������������� �������
		MainObjectSet = ((CEditorApp*)AfxGetApp())->ConvertFileToSet(ar);
		UpdateAllViews(NULL);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CEditorDoc diagnostics

#ifdef _DEBUG
void CEditorDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CEditorDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

//------------------------------------------------------------------------------
// �������� ������ ���������
CSize CEditorDoc::GetDocumentSize()
{
	CRect mainrect = MainObjectSet.UnionRect();
	CSize res(mainrect.BottomRight());
	res.cx += 5; res.cy +=5;
	return res;
}

//------------------------------------------------------------------------------

void CEditorDoc::OnFileConvertHtml() 
{
	char szFilter[] = "HTML Files (*.html)|*.html|All Files (*.*)|*.*||";
 
	CFileDialog dlg(FALSE, "html", NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter);
	if (IDOK == dlg.DoModal())
	{
		CFile file;
		if(!file.Open(dlg.GetFileName(), CFile::modeCreate | CFile::modeWrite))
			return;

		CArchive ar(&file, CArchive::store);

		((CEditorApp*)AfxGetApp())->ConvertSetToHTML(
			ar, MainObjectSet);
		ar.Close();
		file.Close();
	}
}
