// edtCButton.cpp: implementation of the edtCButton class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Editor.h"
#include "edtCButton.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNAMIC(edtCButton, CObject)

edtCButton::edtCButton(CPoint position)
	:CBaseObj(position)
{
	m_sName = "Button";
}

/*edtCButton::edtCButton()
	: CBaseObj()
{
	m_sName = "Button";
}*/

edtCButton::~edtCButton()
{

}

void edtCButton::Draw(CDC* pDC)
{

	CBaseObj::Draw(pDC);
	// ������� ������ ������
	CRect region(pos + CPoint(1,1),
		size - CSize(2,2));
	CPen pen1(PS_SOLID, 1, RGB(50, 50, 50));
	CPen pen2(PS_SOLID, 1, RGB(255, 255, 255));
	CPen pen3(PS_SOLID, 1, RGB(128, 128, 128));
	
	CBrush back;
	back.CreateSolidBrush(RGB(200,200,200));

	pDC->FillRect(region, &back);
	back.DeleteObject();

	CPen* oldpen = pDC->SelectObject(&pen1);
	pDC->MoveTo(CPoint(pos.x + 1, pos.y + size.cy - 2));
	pDC->LineTo(CPoint(pos.x + size.cx - 2, pos.y + size.cy - 2));
	pDC->LineTo(CPoint(pos.x + size.cx - 2, pos.y  - 1));
	
	pDC->SelectObject(&pen2);
	pDC->MoveTo(CPoint(pos.x + 1, pos.y + size.cy - 3));
	pDC->LineTo(CPoint(pos.x + 1, pos.y + 1));
	pDC->LineTo(CPoint(pos.x + size.cx - 2, pos.y + 1));

	pDC->SelectObject(&pen3);
	pDC->MoveTo(CPoint(pos.x + 2, pos.y + size.cy - 3));
	pDC->LineTo(CPoint(pos.x + size.cx - 3, pos.y + size.cy - 3));
	pDC->LineTo(CPoint(pos.x + size.cx - 3, pos.y + 1));

	pen1.DeleteObject();
	pen2.DeleteObject();
	pen3.DeleteObject();

	//����� ��������
	pDC->SetBkColor(RGB(200,200,200));
	CRect out = GetRect();

	CSize textsize = pDC->GetTextExtent(m_sName);
	CSize offsetsize = out.Size();
	offsetsize -= textsize;

	out.bottom -=3; out.right -=3;
	out.top +=2; out.left +=2;

	pDC->ExtTextOut(pos.x + offsetsize.cx/2,
		pos.y + offsetsize.cy/2,
		ETO_CLIPPED, &out, m_sName, NULL);

	pDC->SelectObject(oldpen);
}


void edtCButton::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		CString buf;
		buf.Format("<Button left=\"%i\"; top=\"%i\"; height=\"%i\"; width=\"%i\"; Caption=\"%s\">",
			pos.x,pos.y, size.cy, size.cx, m_sName);
		ar.WriteString(buf);
		ar << (char)13 << (char)10;
	}
}

edtCButton edtCButton::operator = (edtCButton& source)
{
	this->CBaseObj::operator =(source);
	return *this;
}