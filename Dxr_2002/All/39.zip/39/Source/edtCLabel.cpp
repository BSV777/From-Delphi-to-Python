// edtCLabel.cpp: implementation of the edtCLabel class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Editor.h"
#include "edtCLabel.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNAMIC(edtCLabel, CObject)

edtCLabel::edtCLabel(CPoint position)
	:CBaseObj(position)
{
	m_sName = "Label";
}
/*
edtCLabel::edtCLabel()
	: CBaseObj()
{
	m_sName = "Label";
}
*/
edtCLabel::~edtCLabel()
{

}

void edtCLabel::Draw(CDC* pDC)
{
	CBaseObj::Draw(pDC);
	// ������� ������ �����
	CRect region(pos + CPoint(1,1),
		size - CSize(2,2));

	CBrush back;
	back.CreateSolidBrush(RGB(200,200,200));

	pDC->FillRect(region, &back);
	back.DeleteObject();

	//����� ��������
	pDC->SetBkColor(RGB(200,200,200));
	CRect out = GetRect();

	CSize textsize = pDC->GetTextExtent(m_sName);
	CSize offsetsize = out.Size();
	offsetsize -= textsize;

	out.bottom -=1; out.right -=1;
	out.top +=1; out.left +=1;

	pDC->ExtTextOut(pos.x + offsetsize.cx/2,
		pos.y + offsetsize.cy/2,
		ETO_CLIPPED, &out, m_sName, NULL);
}

void edtCLabel::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		CString buf;
		buf.Format("<Label left=\"%i\"; top=\"%i\"; height=\"%i\"; width=\"%i\"; Text=\"%s\">",
			pos.x,pos.y, size.cy, size.cx, m_sName);
		ar.WriteString(buf);
		ar << (char)13 << (char)10;
	}
}