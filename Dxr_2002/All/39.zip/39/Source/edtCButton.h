//------------------------------------------------------------------------------
// edtCButton.h
// ��������� ������ edtCButton

#if !defined(AFX_EDTCBUTTON_H__)
#define AFX_EDTCBUTTON_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BaseObj.h"

class edtCButton : public CBaseObj
{
	DECLARE_DYNAMIC(edtCButton)
protected:
//	edtCButton();

public:
	edtCButton(CPoint position);
	virtual ~edtCButton();
	
	virtual void Draw(CDC* pDC);
	virtual void Serialize(CArchive &ar);
	
	edtCButton operator = (edtCButton& source);
};

#endif // !defined(AFX_EDTCBUTTON_H__)
//------------------------------------------------------------------------------
