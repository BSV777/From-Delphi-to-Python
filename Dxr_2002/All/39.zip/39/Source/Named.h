/*------------------------------------------------------------------------------
����:		Named.h
����������: 
������:		1.0
����:		01-03-2002
�����(�):	�������� ����� (merz@smtp.ru)
------------------------------------------------------------------------------*/

#if !defined(AFX_NAMED_H_)
#define AFX_NAMED_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CNamed
{
public:
	CNamed();
	CNamed(CString newname);
	virtual ~CNamed();
	void Name(CString &newName);
	CString Name() const;

	CNamed operator = (CNamed& source);

protected:
	CString m_sName;
};


//------------------------------------------------------------------------------

AFX_INLINE void CNamed::Name(CString &newName)
{ m_sName = newName; }

//------------------------------------------------------------------------------

#endif // !defined(AFX_NAMED_H_)
