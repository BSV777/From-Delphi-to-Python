/*
 * FormDesigner
 *
 * Misc. low-level functions
 *
 * by	Andrey V Rogozhin	rav@tula.net
 *
 */

#include <windows.h>
#include "common.h"

LPTSTR ReplaceExtension(LPTSTR lpFilename, LPCTSTR lpExtension)
{
   LPTSTR lpTemp;
   LPCTSTR lpTemp2;

   lpTemp=lpFilename;
   // Find the end of NULL-terminated sting
   while(*lpTemp++);							
   // Locate "." position
   while(((--lpTemp)>=lpFilename)&&((*lpTemp)!='.')); 
   if(lpTemp>lpFilename) {								// We found the extention
      lpTemp2=lpExtension;
      // Copy the extention
      while(*lpTemp2) *(++lpTemp)=*(lpTemp2++);
      *(++lpTemp)=NULL;										// Terminate the string
   } else {													// No extension found
      lstrcat(lpFilename,".");
      lstrcat(lpFilename,lpExtension);
   }
   return lpFilename;
}

BOOL IsBlank(TCHAR a)
{
   switch(a) {
      case 0x20:			// Space
      case 0x0D:			// CR
      case 0x0A:			// LF
      case 0x09:			// Tab
      case 0x00:
         return TRUE;
   }
   return FALSE;
}

BOOL IsNumber(TCHAR a)
{
   if((a>='0')&&(a<='9')) return TRUE;
   return FALSE;
}

