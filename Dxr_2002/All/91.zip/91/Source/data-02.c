/*
 * FormDesigner
 *
 * Internal data storage and manipulation
 *
 * by	Andrey V Rogozhin	rav@tula.net
 *
 */

#include <windows.h>
#include <alloc.h>
#include <stdlib.h>
#include <stdio.h>
#include <values.h>

#include "resource.h"

#define __GLOBALS_LOCAL__
#include "common.h"

// Globals

HINSTANCE hInst;

HWND hWndMain;													// Main window indentifier

LPTSTR szTitle, szCurTitle, szSeparator, szWindowClass;
LPTSTR szHello,szExportDlgTitle;
LPTSTR szFileName,szFullFileName,szExportFileName;
LPTSTR szCurFileName,szCurFullFileName;

PBasicObject Data;

OPENFILENAME *ofnOpen,*ofnSave,*ofnExport;

// Locals

static LPTSTR Buffer,TempBuffer;
static DWORD Size, Position;
static LPTSTR szErrorTitle;
static BOOL skipFlag;
static TCHAR szMarginBuf[48];

BOOL AllocateBasicData(void)
{
	if((szTitle=malloc(MAXLOADSTR))==NULL) return FALSE;
	if((szCurTitle=malloc(MAXFILENAMESIZE+2*MAXLOADSTR))==NULL) return FALSE;
	if((szSeparator=malloc(MAXLOADSTR))==NULL) return FALSE;
	if((szWindowClass=malloc(MAXLOADSTR))==NULL) return FALSE;
	if((szHello=malloc(MAXLOADSTR))==NULL) return FALSE;
	if((szExportDlgTitle=malloc(MAXLOADSTR))==NULL) return FALSE;
	if((szFileName=malloc(MAXFILENAMESIZE))==NULL) return FALSE;
	if((szFullFileName=malloc(MAXFILENAMESIZE))==NULL) return FALSE;
	if((szExportFileName=malloc(MAXFILENAMESIZE))==NULL) return FALSE;
	if((szCurFileName=malloc(MAXFILENAMESIZE))==NULL) return FALSE;
	if((szCurFullFileName=malloc(MAXFILENAMESIZE))==NULL) return FALSE;
	if((ofnOpen=malloc(sizeof(OPENFILENAME)))==NULL) return FALSE;
	if((ofnSave=malloc(sizeof(OPENFILENAME)))==NULL) return FALSE;
	if((ofnExport=malloc(sizeof(OPENFILENAME)))==NULL) return FALSE;
   return TRUE;
}

void FreeBasicData(void)
{
	free(ofnExport);
   free(ofnSave);
   free(ofnOpen);
   free(szCurFullFileName);
   free(szCurFileName);
   free(szExportFileName);
   free(szFullFileName);
   free(szFileName);
   free(szExportDlgTitle);
   free(szHello);
   free(szWindowClass);
   free(szSeparator);
   free(szCurTitle);
   free(szTitle);
}

void InitData(void)
{
	// Erase current file names
	szFullFileName[0]=NULL;
	szFileName[0]=NULL;
	szCurFullFileName[0]=NULL;
	szCurFileName[0]=NULL;
   szExportFileName[0]=NULL;
   if(Data!=NULL) ReleaseData(&Data);
}

void ResetData(void)
{
	InitData();
   UpdateWindowTitle();
	MessageBox(
   	hWndMain,
      "Data reinitialized",
      "Data reinitialized",
      MB_OK | MB_ICONINFORMATION | MB_APPLMODAL
   );
}

void ReleaseData(PBasicObject *start)
{
   PBasicObject pA,pB;

	pA=*start;
	while(pA!=NULL) {
   	pB=pA->n;
      free(pA);
      pA=pB;
   }
   *start=NULL;
}

static void FindCursorPosition(LPDWORD row, LPDWORD col)
{
	DWORD Cursor, x, y;

   Cursor=0;
   x=y=1;

   while((Cursor<Position)&&(Cursor<Size))
   	switch(Buffer[Cursor++]) {
      	case 0x0D:						// CR
            break;
         case 0x0A:						// LF
            x=0;
            y++;
         case 0x09:						// Tab
            x+=8;
            break;
         default:
            x++;
            break;
      }

   *row=y; *col=x;
}

static BOOL ShowParseError(DWORD peType, BOOL warnFlag, DWORD Adjust)
{
	DWORD row, col, idFormat, idMessage;
   TCHAR szErrorDesc[MAXLOADSTR], szMsgFormat[MAXLOADSTR];
   LPTSTR Message;
   BOOL r, lineNumbers;
   LPVOID args[3];
	LPVOID lpMsgBuf;

   switch(peType) {
   	case IDS_PE_LOADING:
      case IDS_PE_UNEXPECTEDEND:
      	idFormat=IDS_PE_MESSAGE;
			lineNumbers=FALSE;
      	break;
      case IDS_PE_OBJECTOVERLAP:
      	idFormat=(warnFlag)?IDS_PE_OBJECTOVERLAPWARN:IDS_PE_OBJECTOVERLAP;
         idMessage=0;
			lineNumbers=TRUE;
         break;
      default:
			idFormat=(warnFlag)?IDS_PE_WARNING:IDS_PE_MESSAGENUM;
			lineNumbers=TRUE;
         break;
   }

   LoadString(hInst, idFormat, szMsgFormat, MAXLOADSTR);

	if(peType!=IDS_PE_OBJECTOVERLAP)
   	LoadString(hInst, peType, szErrorDesc, MAXLOADSTR);

   args[0]=szErrorDesc;

   if(lineNumbers) {
     	Position-=Adjust;
     	FindCursorPosition(&row, &col);
      Position+=Adjust;
      args[1]=(LPVOID)row;
      args[2]=(LPVOID)col;
   };

   r=TRUE;

   if(
   	FormatMessage(
      	FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_STRING|
				FORMAT_MESSAGE_ARGUMENT_ARRAY,
			szMsgFormat,
        	0,
         0,
      	&Message,
      	0,
      	(va_list *) args
      )) {
   	r=(MessageBox(
      	hWndMain,
         Message,
         szErrorTitle,
         MB_APPLMODAL|(warnFlag?(MB_YESNO|MB_ICONWARNING):(MB_OK|MB_ICONERROR))
      )!=IDYES);
   	LocalFree(Message);
   } else {
		FormatMessage(
		    FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		    NULL,
		    GetLastError(),
		    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
          (LPTSTR) &lpMsgBuf,
		    0,
		    NULL
		);
		// Display the string.
		MessageBox(NULL, lpMsgBuf, "GetLastError", MB_OK|MB_ICONINFORMATION);
		// Free the buffer.
		LocalFree(lpMsgBuf);
   }

   return r;
}

BOOL LoadDataFromFile(LPCTSTR FullFileName)
{
	TCHAR szFileName[MAXFILENAMESIZE], szTitleFormat[MAXLOADSTR];
	HANDLE File;
	DWORD Read;
   BOOL qStatus;
   LPVOID args[1];
	LPVOID lpMsgBuf;
   PBasicObject SavedData;

   qStatus=FALSE;

   if((TempBuffer=malloc(MAXCONTENTSIZE))==NULL) return 0;

	if(GetFileTitle(FullFileName, szFileName, MAXFILENAMESIZE)<0) {
   	free(TempBuffer);
      return 0;
   }

	LoadString(hInst, IDS_PE_TITLE, szTitleFormat, MAXLOADSTR);

   args[0]=szFileName;
	if(!FormatMessage(
   	FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_STRING|
   		FORMAT_MESSAGE_ARGUMENT_ARRAY,
      szTitleFormat,
      0,
      0,
      &szErrorTitle,
      0,
      (va_list *)args
   )) {
		FormatMessage(
		    FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		    NULL,
		    GetLastError(),
		    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
          (LPTSTR) &lpMsgBuf,
		    0,
		    NULL
		);
		// Display the string.
		MessageBox(NULL, lpMsgBuf, "GetLastError", MB_OK|MB_ICONINFORMATION);
		// Free the buffer.
		LocalFree(lpMsgBuf);
   }

   File=CreateFile(
   	FullFileName,
   	GENERIC_READ,
      FILE_SHARE_READ,
      NULL,
      OPEN_EXISTING,
      FILE_FLAG_SEQUENTIAL_SCAN,
      NULL
   );

	if(File==INVALID_HANDLE_VALUE) goto errHandle3;

   if((Size=GetFileSize(File, NULL))==0xFFFFFFFF) goto errHandle2;

	if((Buffer=malloc(Size+1))==NULL) goto errHandle2;

   if(!ReadFile(File, Buffer, Size, &Read, NULL)) goto errHandle1;

   if(Read!=Size) goto errHandle1;

   CloseHandle(File);

   SavedData=Data;

	Position=0;
   Buffer[Size]=NULL;

   while((Position<Size)&&(!qStatus)) {
   	qStatus=ParseNextItem();
   }

   if(qStatus) goto errHandle0;

   free(Buffer);
   LocalFree(szErrorTitle);
	free(TempBuffer);

   ReleaseData(&SavedData);

   return 1;

errHandle0:
   ReleaseData(&Data);
   Data=SavedData;

errHandle1:
	free(Buffer);

errHandle2:
	CloseHandle(File);

errHandle3:
	if(!qStatus) ShowParseError(IDS_PE_LOADING, FALSE, 0);
	LocalFree(szErrorTitle);
	free(TempBuffer);

	return 0;
}

static BOOL SkipTo(TCHAR ch)
{
	while((Buffer[Position]!=ch)&&(Position<Size)) Position++;
	return (Position==Size);
}

static BOOL ParseNumProperty(UINT *Target)
{
	BOOL aFlag;
	int i;
	__int64 t;

   skipFlag=FALSE;

	// Skip blank space
   while(IsBlank(Buffer[Position])&&(Position<Size)) Position++;
	if(Position==Size) {
   	// Unexpected EOF
		ShowParseError(IDS_PE_UNEXPECTEDEND, FALSE, 0);
  		return TRUE;
   }

   if(Buffer[Position]=='=') Position++;
	else {
   	// Must have '='
		ShowParseError(IDS_PE_MISSINGEQ, FALSE, 0);
     	return TRUE;
   }

   // Skip blank space
	while(IsBlank(Buffer[Position])&&(Position<Size)) Position++;
	if(Position==Size) {
   	// Unexpected EOF
		ShowParseError(IDS_PE_UNEXPECTEDEND, FALSE, 0);
  		return TRUE;
   }

   if(Buffer[Position]=='"') Position++;
	else {
   	// Must have '"'
		ShowParseError(IDS_PE_MISSINGQT, FALSE, 0);
     	return TRUE;
   }

	// Copy next string of numbers for convertion
  	i=0;
	while(IsNumber(Buffer[Position])&&(Position<Size)&&(i<MAXCONTENTSIZE))
 		TempBuffer[i++]=Buffer[Position++];
	if(!i) {
   	// Missing number
   	ShowParseError(IDS_PE_MISSINGNUM, FALSE, 0);
      return TRUE;
   }
   if(i>5) {
   	// Number too large
		aFlag=ShowParseError(IDS_PE_LARGENUM, TRUE, i);
      if(aFlag) return TRUE;
      SkipTo('"');
      skipFlag=TRUE;
      return FALSE;
   }
   TempBuffer[i]=NULL;

   t=_atoi64(TempBuffer);
   if(t>MAXINT) {
   	// Number too large
		aFlag=ShowParseError(IDS_PE_LARGENUM, TRUE, i);
      if(aFlag) return TRUE;
      skipFlag=TRUE;
      return FALSE;
   }
   if(Target!=NULL) *Target=(UINT)t;

   if(Buffer[Position]=='"') Position++;
	else {
   	// Must have '"'
		ShowParseError(IDS_PE_MISSINGQT, FALSE, 0);
     	return TRUE;
   }

  	return FALSE;
}

static BOOL ParseStrProperty(LPTSTR Target)
{
	BOOL aFlag;
	int i;

   skipFlag=FALSE;

   // Skip blank space
	while(IsBlank(Buffer[Position])&&(Position<Size)) Position++;
	if(Position==Size) {
   	// Unexpected EOF
		ShowParseError(IDS_PE_UNEXPECTEDEND, FALSE, 0);
  		return TRUE;
   }

   if(Buffer[Position]=='=') Position++;
	else {
   	// Must have '='
		ShowParseError(IDS_PE_MISSINGEQ, FALSE, 0);
     	return TRUE;
   }

   // Skip blank space
	while(IsBlank(Buffer[Position])&&(Position<Size)) Position++;
	if(Position==Size) {
   	// Unexpected EOF
		ShowParseError(IDS_PE_UNEXPECTEDEND, FALSE, 0);
  		return TRUE;
   }

   if(Buffer[Position]=='"') Position++;
	else {
   	// Must have '"'
		ShowParseError(IDS_PE_MISSINGQT, FALSE, 0);
     	return TRUE;
   }

	// Copy quoted string content into target
   i=0;
	while((Buffer[Position]!='"')&&(Position<Size)&&(i<MAXCONTENTSIZE))
  		Target[i++]=Buffer[Position++];
   if(i==MAXCONTENTSIZE) {
   	// String too large
		aFlag=ShowParseError(IDS_PE_LARGESTR, TRUE, i);
      if(aFlag) return TRUE;
      SkipTo('"');
      skipFlag=TRUE;
      Target[0]=NULL;
      if(Position<Size) Position++;
      else {
         // Unexpected EOF
         ShowParseError(IDS_PE_UNEXPECTEDEND, FALSE, 0);
         return TRUE;
      }
      return FALSE;
   }
   Target[i]=NULL;

	// Skip '"' after the string
	if(Position<Size) Position++;
   else {
   	// Unexpected EOF
		ShowParseError(IDS_PE_UNEXPECTEDEND, FALSE, 0);
  		return TRUE;
   }

  	return FALSE;
}

BOOL ParseNextItem(void)
{
   PBasicObject ob;
   BOOL lFlag, tFlag, wFlag, hFlag, cFlag, Injectable;
   int i;
   DWORD ObjectStart;

	// Skip blank space
   while(IsBlank(Buffer[Position])&&(Position<Size)) Position++;
	if(Position==Size) {
   	// Unexpected EOF
		ShowParseError(IDS_PE_UNEXPECTEDEND, FALSE, 0);
  		return TRUE;
   }

   ObjectStart=Position;

   // New object?
   if(Buffer[Position]=='<') Position++;
	else {
   	// Must have '<'
		ShowParseError(IDS_PE_MISSINGLT, FALSE, 0);
     	return TRUE;
   }

	// Allocate new object
	if((ob=malloc(sizeof(struct TBasicObject)))==NULL) {
		ShowParseError(IDS_PE_ALLOCMEM, FALSE, 0);
     	return TRUE;
   }

	// Copy next word for comparison
	i=0;
	while(IsCharAlpha(Buffer[Position])&&(Position<Size)&&(i<MAXCONTENTSIZE))
   	TempBuffer[i++]=Buffer[Position++];
   if(i==MAXCONTENTSIZE) {
      // Unknown very large object type
		ShowParseError(IDS_PE_UNKNOWNTYPE, FALSE, i);
   	return TRUE;
   }
   TempBuffer[i]=NULL;

	if(!lstrcmpi(TempBuffer, "Button" ))
		// Button object detected
		ob->type=OT_BUTTON;
   else
	if(!lstrcmpi(TempBuffer, "TextEdit"))
		// Text Edit object detected
		ob->type=OT_TEDIT;
   else
	if(!lstrcmpi(TempBuffer, "Label"))
		// Label object detected
		ob->type=OT_LABEL;
	else {
		// Garbage detected
		ShowParseError(IDS_PE_UNKNOWNTYPE, FALSE, i);
   	return TRUE;
   }

   // Initialize defaults
   InitDefaults(ob);
   lFlag=tFlag=wFlag=hFlag=cFlag=FALSE;

	while(TRUE)	{
		// Skip blank space
   	while(IsBlank(Buffer[Position])&&(Position<Size)) Position++;
	  	if(Position==Size) {
   		// Unexpected EOF
			ShowParseError(IDS_PE_UNEXPECTEDEND, FALSE, 0);
	  		return TRUE;
	   }

		// Copy next word for comparison
		i=0;
		while(IsCharAlpha(Buffer[Position])&&(Position<Size)&&(i<MAXCONTENTSIZE))
	   	TempBuffer[i++]=Buffer[Position++];
	   if(i==MAXCONTENTSIZE) {
      	// Unknown very large property
			ShowParseError(IDS_PE_UNKNOWNPROP, FALSE, i);
	   	return TRUE;
	   }
   	TempBuffer[i]=NULL;

		if(!lstrcmpi(TempBuffer, "left")) {
			// Left property detected
			if(lFlag) {
         	// Already had this property
				if(ShowParseError(IDS_PE_DBLLEFT, TRUE, 4)) return TRUE;
				if(ParseNumProperty(NULL)) return TRUE;
         } else {
				if(ParseNumProperty(&(ob->left))) return TRUE;
   	      lFlag=!skipFlag;
         }
	   } else if(!lstrcmpi(TempBuffer, "top")) {
			// Top property detected
			if(tFlag) {
         	// Already had this property
				if(ShowParseError(IDS_PE_DBLTOP, TRUE, 3)) return TRUE;
				if(ParseNumProperty(NULL)) return TRUE;
         } else {
				if(ParseNumProperty(&(ob->top))) return TRUE;
   	      tFlag=!skipFlag;
         }
	   } else if(!lstrcmpi(TempBuffer, "width")) {
			// Width property detected
			if(wFlag) {
         	// Already had this property
				if(ShowParseError(IDS_PE_DBLWIDTH, TRUE, 5)) return TRUE;
				if(ParseNumProperty(NULL)) return TRUE;
         } else {
				if(ParseNumProperty(&(ob->width))) return TRUE;
   	      wFlag=!skipFlag;
         }
		} else if(!lstrcmpi(TempBuffer, "height")) {
      	// Height property detected
			if(ob->type!=OT_BUTTON) {
            // Valid only for buttons
				if(ShowParseError(IDS_PE_NONBUTTONHEIGHT, TRUE, 6)) return TRUE;
				if(ParseNumProperty(NULL)) return TRUE;
         } else
         if(hFlag) {
         	// Already had this property
				if(ShowParseError(IDS_PE_DBLHEIGHT, TRUE, 6)) return TRUE;
				if(ParseNumProperty(NULL)) return TRUE;
         } else {
				if(ParseNumProperty(&(ob->height))) return TRUE;
   	      hFlag=!skipFlag;
         }
		} else if(!lstrcmpi(TempBuffer, "caption")) {
       	// Caption property detected
			if(ob->type!=OT_BUTTON) {
            // Valid only for buttons
				if(ShowParseError(IDS_PE_NONBUTTONCAPTION, TRUE, 7)) return TRUE;
				if(ParseStrProperty(NULL)) return TRUE;
         } else
         if(cFlag) {
         	// Already had this property
				if(ShowParseError(IDS_PE_DBLCAPTION, TRUE, 7)) return TRUE;
				if(ParseStrProperty(NULL)) return TRUE;
         } else {
				if(ParseStrProperty(ob->content)) return TRUE;
   	      cFlag=!skipFlag;
         }
		} else if(!lstrcmpi(TempBuffer, "text")) {
      	// Text property detected
			if((ob->type!=OT_LABEL)&&(ob->type!=OT_TEDIT)) {
            // Valid only for labels and text edits
				if(ShowParseError(IDS_PE_BUTTONTEXT, TRUE, 4)) return TRUE;
				if(ParseStrProperty(NULL)) return TRUE;
         } else
         if(cFlag) {
         	// Already had this property
				if(ShowParseError(IDS_PE_DBLTEXT, TRUE, 4)) return TRUE;
				if(ParseStrProperty(NULL)) return TRUE;
         } else {
				if(ParseStrProperty(ob->content)) return TRUE;
   	      cFlag=!skipFlag;
         }
		} else {
      	// Garbage detected
			ShowParseError(IDS_PE_UNKNOWNPROP, FALSE, i);
	   	return TRUE;
	   }

		// Skip blank space
   	while(IsBlank(Buffer[Position])&&(Position<Size)) Position++;
	  	if(Position==Size) {
   		// Unexpected EOF
			ShowParseError(IDS_PE_UNEXPECTEDEND, FALSE, 0);
	  		return TRUE;
	   }

      if(Buffer[Position]==';')
      	Position++;
      else
      	if(Buffer[Position]=='>') {
         	// Object end detected
         	Position++;
            if(ObjectWillOverlap(ob, &Injectable, NULL)) {
            	if(ShowParseError(
               	IDS_PE_OBJECTOVERLAP,
                  Injectable,
                  Position-ObjectStart
               ))
               	return TRUE;
               else
               	InjectObject(ob);
            } else
	            AppendObject(ob);
            // Skip blank space
				while(IsBlank(Buffer[Position])&&(Position<Size)) Position++;
            return FALSE;
         } else {
	   		// Missing ">"
				ShowParseError(IDS_PE_MISSINGGT, FALSE, 0);
	  			return TRUE;
		   }
   }
}

void InitDefaults(PBasicObject ob)
{
	ob->left=DEFAULT_OBJECT_LEFT;
   ob->top=DEFAULT_OBJECT_TOP;
	switch(ob->type) {
     	case OT_LABEL:
      	ob->width=DEFAULT_LABEL_WIDTH;
         break;
      case OT_TEDIT:
      	ob->width=DEFAULT_TEDIT_WIDTH;
  	      break;
      case OT_BUTTON:
        	ob->width=DEFAULT_BUTTON_WIDTH;
         break;
      default:
        	ob->width=0;
         break;
   }
	switch(ob->type) {
     	case OT_LABEL:
      	ob->height=DEFAULT_LABEL_HEIGHT;
         break;
      case OT_TEDIT:
      	ob->height=DEFAULT_TEDIT_HEIGHT;
  	      break;
      case OT_BUTTON:
        	ob->height=DEFAULT_BUTTON_HEIGHT;
         break;
      default:
        	ob->height=0;
         break;
   }
   ob->content[0]=NULL;
}

BOOL SaveDataToFile(LPCTSTR FileName)
{
	FILE *out;
   PBasicObject ob;
   BOOL q;

   // It's more stylish to sort data before output
	SortData();

	if((out=fopen(FileName, "w"))==NULL)
   	// Unable to open file for writing
   	return FALSE;

	ob=Data; q=FALSE;

   while((ob!=NULL)&&(!q)) {
   	switch(ob->type) {
      	case OT_BUTTON:
         	q=(fprintf(
            		out,
               	"<Button left=\"%d\"; top=\"%d\"; width=\"%d\"; "
            			"height=\"%d\"; caption=\"%s\">\n",
	               ob->left,
	               ob->top,
	               ob->width,
   	            ob->height,
	               ob->content
   	         )==EOF);
				break;
         case OT_LABEL:
         	q=(fprintf(
            		out,
                  "<Label left=\"%d\"; top=\"%d\"; width=\"%d\"; "
                  	"text=\"%s\">\n",
                  ob->left,
                  ob->top,
                  ob->width,
                  ob->content
            	)==EOF);
				break;
         case OT_TEDIT:
         	q=(fprintf(
            		out,
                  "<TextEdit left=\"%d\"; top=\"%d\"; width=\"%d\"; "
            			"text=\"%s\">\n",
                  ob->left,
                  ob->top,
                  ob->width,
                  ob->content
            	)==EOF);
				break;
      }
      ob=ob->n;
   }

   fclose(out);

   return (!q);
}

int CompareUINT(const void *lpA, const void *lpB)
{
	UINT A, B;

   A=*((UINT*)lpA);
   B=*((UINT*)lpB);

   if(A<B)
   	return -1;
   if(A>B)
   	return 1;
   return 0;
}

static void AppendUniqueValue(UINT *array, LPDWORD count, UINT value)
{
   DWORD i;

   i=0;
   while(i<(*count))
   	if(array[i++]==value)
      	// Value already in array
      	return;
   array[(*count)++]=value;
}

static void FormatMargin(char *buffer, char *const fill,
								 UINT mTop, UINT mRight, UINT mBottom, UINT mLeft)
{
	if((mTop)&&(!mLeft)&&(!mRight)&&(!mBottom)) {
   	// All margins are zeros except Top
      sprintf(buffer, "%smargin-top:%d", fill, mTop);
   	return;
   }
	if((!mTop)&&(mLeft)&&(!mRight)&&(!mBottom)) {
   	// All margins are zeros except Left
      sprintf(buffer, "%smargin-left:%d", fill, mTop);
   	return;
   }
   if((mLeft==mRight)&&(mTop==mBottom)&&(mLeft==mTop)) {
      // All margins are equal
      if(!mLeft) {
         // All margins are zeros
         buffer[0]=NULL;
         return;
      }
      sprintf(buffer, "%smargin:%d", fill, mLeft);
   	return;
   }
   if((mLeft==mRight)&&(mTop==mBottom)) {
      // Left==Right and Top==Bottom
      sprintf(buffer, "%smargin:%d %d", fill, mTop, mLeft);
      return;
   }
   if(mLeft==mRight) {
      // Left==Right
      sprintf(buffer, "%smargin:%d %d %d", fill, mTop, mLeft, mBottom);
      return;
   }
	// All margins are different
   sprintf(buffer, "%smargin:%d %d %d %d", fill, mTop, mRight, mBottom, mLeft);
}

/*
static void WriteDump(char *filename, PBasicObject *ExportTable,
							 int rows, int cols)
{
	FILE *out;
   int x, y, i;

   out=fopen(filename ,"w");
   for(y=0;y<=rows;y++) {
   	for(x=0;x<=cols;x++) {
      	if((y==rows)||(x==cols))
            fprintf(out, ".");
         else {
	         i=y*cols+x;
	         if(ExportTable[i]!=NULL)
	            fprintf(out, "%c", ExportTable[i]->content[0]);
	         else
   	         fprintf(out, " ");
         }
      }
      fprintf(out, "\n");
   }
   fclose(out);
}
*/

static BOOL PrintHTMLHeader(FILE *out,
									 DWORD count,
                            int cols,
                            BOOL labelPresent)
{
	// Print out an HTML header
   if(fprintf(
      out,
      "<HMTL>"
   )==EOF)
   	return FALSE;

	if((count>1)||((Data->type)==OT_LABEL)) {
      if(fprintf(
         out,
          "<HEAD>"
           "<STYLE type=\"text/css\">"
            "*{"
      )==EOF)
      	return FALSE;

      if(count>1)
         if(fprintf(
            out,
            "padding:0"
         )==EOF)
         	return FALSE;

      if((count>1)&&(cols>1))
         // Specify top vertical alignment
         if(fprintf(
            out,
            ";vertical-align:top"
         )==EOF)
         	return FALSE;

      if((count>1)&&labelPresent)
         // Delimiter needed
         if(fprintf(
            out,
            ";"
         )==EOF)
         	return FALSE;

      if((count==1)||labelPresent)
         // Needed for non box elements
         if(fprintf(
            out,
            "white-space:nowrap;overflow:hidden"
         )==EOF)
            return FALSE;

      if(fprintf(
         out,
            "}"
           "</STYLE>"
          "</HEAD>"
      )==EOF)
      	return FALSE;
   }

   return TRUE;
}


static BOOL PrintObject(FILE *out,
								PBasicObject ob,
                        UINT cLeft,
                        UINT cTop,
                        UINT cRight,
                        UINT cBottom)
{
   FormatMargin(
   	szMarginBuf,
      ";",
      (ob->top)-cTop,
      cRight-(ob->left)-(ob->width),
      cBottom-(ob->top)-(ob->height),
      (ob->left)-cLeft
   );

   switch(ob->type) {
      case OT_BUTTON:
         if(fprintf(
            out,
            "<BUTTON style=\"height:%d;width:%d%s\">%s</BUTTON>",
            ob->height,
            ob->width,
            szMarginBuf,
            ob->content
         )==EOF)
         	return FALSE;
         break;
      case OT_TEDIT:
         if(fprintf(
            out,
            "<INPUT style=\"width:%d%s\" value=\"%s\">",
            ob->width,
            szMarginBuf,
            ob->content
         )==EOF)
         	return FALSE;
         break;
      case OT_LABEL:
         if(fprintf(
            out,
            "<P style=\"width:%d%s\">%s",
            ob->width,
            szMarginBuf,
            ob->content
         )==EOF)
         	return FALSE;
         break;
   }

   return TRUE;
}

BOOL ExportDataToFile(LPCTSTR FileName)
{
	// File output handle
	FILE *out;
	// Dynamic data containers
	PBasicObject *ExportTable;
	UINT *xx, *yy;
	// Basic data
   DWORD count, xCount, yCount;
   int rows, cols, x, y, x0, y0, x1, y1;
   int i, m, n, o, p, obToSpan;
   UINT maxX, maxY, right, bottom;
	PBasicObject obX;
	// Used during optimization
   PBasicObject *OpExportTable;
   int opRowsN, opColsN, newCols, newRows;
   BOOL *opRows, *opCols;
   // General purpose flags
	BOOL f, fa, labelPresent;

	if(Data==NULL) {
     	// Trivial case for empty data set
		if((out=fopen(FileName, "w"))==NULL)
      	return FALSE;
      f=(fprintf(out, "<HMTL></HTML>")!=EOF);
	   fclose(out);
      return f;
	}

   // Compile sorted arrays of unique values on X and Y coordinates
	count=TotalObjects();

   if(count>1) {
   	// Full routine
      if((xx=malloc(sizeof(UINT)*(count+1)))==NULL)
         return FALSE;
      if((yy=malloc(sizeof(UINT)*(count+1)))==NULL)
         goto errHandler0;

      obX=Data;
      xCount=yCount=0;
      maxX=maxY=0;
      labelPresent=FALSE;

      while(obX!=NULL) {
         // Walk every object
         AppendUniqueValue(xx, &xCount, obX->left);

         right=(obX->left)+(obX->width);
         if(right>maxX)
            maxX=right;

         AppendUniqueValue(yy, &yCount, obX->top);

         bottom=(obX->top)+(obX->height);
         if(bottom>maxY)
            maxY=bottom;

         labelPresent|=((obX->type)==OT_LABEL);

         obX=obX->n;
      }

      AppendUniqueValue(xx, &xCount, maxX);
      AppendUniqueValue(yy, &yCount, maxY);

      qsort(xx, xCount, sizeof(UINT), CompareUINT);
      qsort(yy, yCount, sizeof(UINT), CompareUINT);

      // Build table template
      rows=yCount-1;
      cols=xCount-1;

      if((ExportTable=malloc(sizeof(PBasicObject)*rows*cols))==NULL)
         goto errHandler1;

      // Initialize table template
      for(i=0;i<rows*cols;i++)
         ExportTable[i]=NULL;

      // Fill template with object pointers
      obX=Data;

      while(obX!=NULL) {
         // Find cell with equal origin
         for(x0=0;xx[x0]<(obX->left);x0++);
         for(y0=0;yy[y0]<(obX->top);y0++);

         // Fill in object pointers
         for(y=y0;yy[y]<(obX->top)+(obX->height);y++)
            for(x=x0;xx[x]<(obX->left)+(obX->width);x++)
               ExportTable[y*cols+x]=obX;

         // Fetch next object
         obX=obX->n;
      }

      // Fill empty cells before objects
      for(x0=cols-1;x0;x0--)
         for(y0=0;y0<rows;y0++) {
            i=y0*cols+x0;
            if(
               (ExportTable[i]!=NULL)&&
               (x0?(ExportTable[i-1]==NULL):FALSE)&&
               (y0?(ExportTable[i-cols]!=ExportTable[i]):TRUE)
            ) {
               // Object left top boundary detected
               // How many rows are occupied?
               n=1;
               while(ExportTable[i]==ExportTable[i+n*cols])
                  n++;
               // Are all cells before front unoccupied?
               f=TRUE;
               for(m=1;f&&(m<n);m++)
                  f=(ExportTable[i+m*cols-1]==NULL);
               if(f)
                  // Available NULL front detected
                  for(m=0;m<n;m++)
                     // Fill it with current object pointer
                     ExportTable[i+m*cols-1]=ExportTable[i];
            }
         }

      // Fill empty cells above objects
      for(y0=rows-1;y0;y0--)
         for(x0=0;x0<cols;x0++) {
            i=y0*cols+x0;
            if(
               (ExportTable[i]!=NULL)&&
               (x0?(ExportTable[i-1]!=ExportTable[i]):TRUE)&&
               (ExportTable[i-cols]==NULL)
            ) {
               // Object left top boundary detected
               // How many columns are occupied?
               n=1;
               while(ExportTable[i]==ExportTable[i+n])
                  n++;
               // Are all cells before front unoccupied?
               f=TRUE;
               for(m=1;f&&(m<n);m++)
                  f=(ExportTable[i-cols+m]==NULL);
               if(f)
                  // Available NULL front detected
                  for(m=0;m<n;m++)
                     // Fill it with current object pointer
                     ExportTable[i-cols+m]=ExportTable[i];
            }
         }

      // Fill empty cells below objects
      for(y0=0;y0<(rows-1);y0++)
         for(x0=0;x0<cols;x0++) {
            i=y0*cols+x0;
            if(
               (ExportTable[i]!=NULL)&&
               (x0?(ExportTable[i-1]!=ExportTable[i]):TRUE)&&
               (ExportTable[i+cols]==NULL)
            ) {
               // Object left bottom boundary detected
               // How many columns are occupied?
               n=1;
               while(ExportTable[i]==ExportTable[i+n])
                  n++;
               // Are all cells before front unoccupied?
               f=TRUE;
               for(m=1;f&&(m<n);m++)
                  f=(ExportTable[i+cols+m]==NULL);
               if(f)
                  // Available NULL front detected
                  for(m=0;m<n;m++)
                     // Fill it with current object pointer
                     ExportTable[i+cols+m]=ExportTable[i];
            }
         }

      // Fill empty cells after objects
      for(x0=0;x0<(cols-1);x0++)
         for(y0=0;y0<rows;y0++) {
            i=y0*cols+x0;
            if(
               (ExportTable[i]!=NULL)&&
               (ExportTable[i+1]==NULL)&&
               (y0?(ExportTable[i-cols]!=ExportTable[i]):TRUE)
            ) {
               // Object right top boundary detected
               // How many rows are occupied?
               n=1;
               while(ExportTable[i]==ExportTable[i+n*cols])
                  n++;
               // Are all cells before front unoccupied?
               f=TRUE;
               for(m=1;f&&(m<n);m++)
                  f=(ExportTable[i+m*cols+1]==NULL);
               if(f)
                  // Available NULL front detected
                  for(m=0;m<n;m++)
                     // Fill it with current object pointer
                     ExportTable[i+m*cols+1]=ExportTable[i];
            }
         }

      // Optimize ExportTable by removing extra rows and columns
      if((opRows=malloc(sizeof(BOOL)*(rows-1)))==NULL)
         goto skipHandler1;
      if((opCols=malloc(sizeof(BOOL)*(cols-1)))==NULL)
         goto skipHandler2;

      for(i=0;i<(cols-1);i++)
         opCols[i]=TRUE;
      for(i=0;i<(rows-1);i++)
         opRows[i]=TRUE;

      for(y=0;y<rows-1;y++)
         for(x=0;x<cols-1;x++) {
            i=y*cols+x;
            opCols[x]=(opCols[x]&&(ExportTable[i]==ExportTable[i+1]));
            opRows[y]=(opRows[y]&&(ExportTable[i]==ExportTable[i+cols]));
         }

      opColsN=opRowsN=0;
      for(i=0;i<(cols-1);i++)
         if(opCols[i])
            opColsN++;
      for(i=0;i<(rows-1);i++)
         if(opRows[i])
            opRowsN++;

      if(opRowsN||opColsN) {
         // We need to optimize
         newCols=cols-opColsN;
         newRows=rows-opRowsN;

         if((OpExportTable=malloc(sizeof(PBasicObject)*newRows*newCols))==NULL)
            goto skipHandler3;

         if(opColsN) {
            // Throw away extra widths
            i=n=0;
            while(i<newCols) {
               while(opCols[n]&&(n<(cols-1)))
                  // Skip all extra values
                  n++;
               xx[++i]=xx[++n];
            }
         }

         if(opRowsN) {
            // Throw away extra heights
            i=n=0;
            while(i<newRows) {
               while(opRows[n]&&(n<(rows-1)))
                  // Skip all extra values
                  n++;
               yy[++i]=yy[++n];
            }
         }

         // Throw away extra cells
         for(y=y0=0;y<newRows;y++, y0++) {
            while(opRows[y0]&&(y0<(rows-1)))
               // Skip all extra rows
               y0++;
            for(x=x0=0;x<newCols;x++, x0++) {
               while(opCols[x0]&&(x0<(cols-1)))
                  // Skip all extra cells
                  x0++;
               OpExportTable[y*newCols+x]=ExportTable[y0*cols+x0];
            }
         }

         // Free && replace ExportTable with optimized one
         free(ExportTable);
         ExportTable=OpExportTable;
         rows=newRows;
         cols=newCols;
      }

   skipHandler3:
      free(opCols);

   skipHandler2:
      free(opRows);

   skipHandler1:

      // Compile list of colums which will be spanned in every row
      if((opCols=malloc(sizeof(BOOL)*(cols-1)))==NULL)
         goto skipHandler0;

      for(x=0;x<(cols-1);x++) {
         opCols[x]=TRUE;
         for(y=0;opCols[x]&&(y<rows);y++) {
            i=y*cols+x;
            if(ExportTable[i]!=ExportTable[i+1]) {
               opCols[x]=(
                  (
                     (ExportTable[i]!=NULL)?(
                        (ExportTable[i]->type)!=OT_LABEL
                     ):
                        FALSE
                  )&&(
                     (ExportTable[i+1]!=NULL)?(
                        (ExportTable[i+1]->type)!=OT_LABEL
                     ):
                        FALSE
                  )
               );
               if(opCols[x]&&(y<(rows-1)))
                  opCols[x]=!(
                     (ExportTable[i]==ExportTable[i+cols])^
                     (ExportTable[i+1]==ExportTable[i+cols+1])
                  );
            }
         }
      }

   skipHandler0:
   }

	// Write HTML file according to ExportTable
	if((out=fopen(FileName, "w"))==NULL)
     	goto errHandler2;

   f=PrintHTMLHeader(
   	out,
      count,
      cols,
      labelPresent
   );

   if(f)
      f=(fprintf(
         out,
          "<BODY>"
      )!=EOF);

   if(count==1) {
   	// We don't need table for just one element
      if(f)
      	f=PrintObject(
	         out,
   	      Data,
      	   0,
	         0,
      	   Data->left+Data->width,
   	      Data->top+Data->height
	      );
   } else {
   	// Print out complete table
      if(f)
         f=(fprintf(
            out,
            "<TABLE border=0"
         )!=EOF);

      // Adjust HTML table origin to (minX, minY)
      if(f) {
         FormatMargin(szMarginBuf, "", yy[0], 0, 0, xx[0]);
         if(szMarginBuf[0]) {
            f=(fprintf(
               out,
               " style=\"%s\">",
               szMarginBuf
            )!=EOF);
         } else {
            f=(fprintf(
               out,
               ">"
            )!=EOF);
         }
      }

      for(y=0;(y<rows)&&f;y++) {
         // Begin new row
         f=(fprintf(
            out,
            "<TR>"
         )!=EOF);
         obToSpan=0;
         for(x=0;(x<cols)&&f;x++) {
            i=y*cols+x;
            if(
               (x?(ExportTable[i-1]!=ExportTable[i]):TRUE)&&
               (y?(ExportTable[i-cols]!=ExportTable[i]):TRUE)
            ) {
               // Object origin detected
               // Find object span dimensions in table
               for(
                  x0=x, n=i;
                  f&&(ExportTable[i]==ExportTable[n])&&(x0<cols);
                  x0++
               ) n++;
               x1=x0;
               x0-=x;
               for(
                  y0=y, n=i;
                  f&&(ExportTable[i]==ExportTable[n])&&(y0<rows);
                  y0++
               ) n+=cols;
               y0-=y;
               if(!obToSpan) {
                  // There is no objects to span
                  if(
                     (ExportTable[i]!=NULL)&&
                     ((ExportTable[i]->type)!=OT_LABEL)
                  ) {
                     // We can combine several Buttons and TextEdits in one cell
                     // Find additional objects for horizontal span
                     for(fa=TRUE;f&&fa&&(x1<cols);x1++) {
                        o=y*cols+x1;
                        if((!y)||(ExportTable[o-cols]!=ExportTable[o])) {
                           if((!x1)||(ExportTable[o-1]!=ExportTable[o])) {
                              // New object origin
                              fa=(
                                 (ExportTable[o]!=NULL)&&
                                 ((ExportTable[o]->type)!=OT_LABEL)
                              );
                              if(!fa)
                                 continue;
                              for(
                                 y1=y, p=o;
                                 f&&
                                 (ExportTable[o]==ExportTable[p])&&
                                 (y1<rows);
                                 y1++
                              ) p+=cols;
                              y1-=y;
                              if(y1==y0)
                                 // Row span is equal
                                 obToSpan++;
                              else
                                 // Object bottom below current - abort scan
                                 fa=FALSE;
                           }
                        } else
                           // Object top above current - abort scan
                           fa=FALSE;
                     }
                     x1--;
                  }
                  p=x1;
                  x1-=x;
                  // Adjust for totally spanned columns
                  for(o=x;(o<(cols-1))&&(o<p);o++)
                     if(opCols[o])
                        x1--;
                  // Print out new <TD> tag
                  if(f)
                     f=(fprintf(out, "<TD")!=EOF);
                  if(f&&(x1>1))
                     f=(fprintf(out, " colspan=%d", x1)!=EOF);
                  if(f&&(y0>1))
                     f=(fprintf(out, " rowspan=%d", y0)!=EOF);
                  if(ExportTable[i]==NULL) {
                     // We need to specify dimentions for empty cell
                     if(f)
                        f=(fprintf(out, " width=%d", xx[x+x0]-xx[x])!=EOF);
                     if(f)
                        f=(fprintf(out, " height=%d", yy[y+y0]-yy[y])!=EOF);
                  }
                  if(f)
                     f=(fprintf(out, ">")!=EOF);
               } else {
                  // Span next object
                  obToSpan--;
               }
               if(f&&(ExportTable[i]!=NULL))
               	f=PrintObject(
                  	out,
                     ExportTable[i],
                     xx[x],
                     yy[y],
                     xx[x+x0],
                     yy[y+y0]
                  );
            }
         }
      }

		goto cont;

  	errHandler2:
   	free(ExportTable);

  	errHandler1:
      free(yy);

	errHandler0:
      free(xx);

      return FALSE;

	cont:
   }

	// HTML footer
   if(f&&(count>1))
      f=(
         fprintf(
            out,
              "</TABLE>"
         )!=EOF);

   if(f)
   	f=(fprintf(
      	out,
          "</BODY>"
         "</HTML>"
      )!=EOF);

   fclose(out);

   if(count>1) {
   	// We allocated those only if count>1
      if(opCols!=NULL)
         free(opCols);

      free(ExportTable);
      free(yy);
      free(xx);
   }

   return(!f);
}

void AppendObject(PBasicObject ob)
{
	PBasicObject obX;

   obX=FindTail();
   if(obX==NULL) {
   	// Data set was empty
   	Data=ob;
      ob->p=ob->n=NULL;
   } else {
   	obX->n=ob;
      ob->p=obX;
      ob->n=NULL;
   }
}

PBasicObject FindTail(void)
{
	PBasicObject obX,obY;

   obX=obY=Data;
   while(obX!=NULL) {
   	obY=obX;
      obX=obX->n;
   }
   return obY;
}

DWORD TotalObjects(void)
{
	PBasicObject obX;
   DWORD count;

	count=0;
   obX=Data;

   while(obX!=NULL) {
      obX=obX->n;
      count++;
   }

   return count;
}

int CompareBasicObjects(const void *lpA, const void *lpB)
{
	PBasicObject obA, obB;

   obA=(PBasicObject)lpA;
   obB=(PBasicObject)lpB;

	if((obA->top)<(obB->top))
   	// Object A is located higher then B
   	return -1;
   if((obA->top)>(obB->top))
   	// Object A is located lower then B
   	return 1;
   // Objects are on the same line
   if((obA->left)<(obB->left))
   	// Object A is located before B
      return -1;
   if((obA->left)>(obB->left))
   	// Object A is located after B
      return 1;
  	// Objects have same origin
   return 0;
}

BOOL SortData(void)
{
	PBasicObject *list;
   PBasicObject obX;
   DWORD count, i;

	if((count=TotalObjects())<2)
   	// We don't need to sort this array
	   return TRUE;

   if((list=malloc(sizeof(PBasicObject)*count))==NULL)
   	return FALSE;

	// Compile object pointer list in array
	obX=Data;
   i=0;
   while(obX!=NULL) {
   	list[i++]=obX;
      obX=obX->n;
   }

	qsort(list, count, sizeof(PBasicObject), CompareBasicObjects);

   // Rearrange according to sorted list
	Data=list[0];
   i=0;
   while(i<count) {
		if(i)
      	list[i]->p=list[i-1];
      else
      	list[i]->p=NULL;
      if(i<count-1)
      	list[i]->n=list[i+1];
      else
      	list[i]->n=NULL;
      i++;
   }

   free(list);

   return TRUE;
}

BOOL ObjectWillOverlap(PBasicObject ob,
							  BOOL *Injectable,
                       PBasicObject *which)
{
	// Dynamic data containers
	PBasicObject *Table, Tail, obWhich;
	UINT *xx, *yy;
	// Basic data
   DWORD count, xCount, yCount;
   int rows, cols, x, y, x0, y0, i;
   UINT maxX, maxY, right, bottom;
	PBasicObject obX;
   // General purpose flags
	BOOL f, fa;

	if(Data==NULL)
     	// Trivial case for empty data set
      return FALSE;

	// Temporary append object
   Tail=FindTail();
   Tail->n=ob;

   // Compile sorted arrays of unique values on X and Y coordinates
	count=TotalObjects();

   if((xx=malloc(sizeof(UINT)*(count+1)))==NULL)
      return FALSE;
   if((yy=malloc(sizeof(UINT)*(count+1)))==NULL)
      goto errHandler0;

   obX=Data;
   xCount=yCount=0;
   maxX=maxY=0;

   while(obX!=NULL) {
      // Walk every object
      AppendUniqueValue(xx, &xCount, obX->left);

      right=(obX->left)+(obX->width);
      if(right>maxX)
         maxX=right;

      AppendUniqueValue(yy, &yCount, obX->top);

      bottom=(obX->top)+(obX->height);
      if(bottom>maxY)
         maxY=bottom;

      obX=obX->n;
   }

   AppendUniqueValue(xx, &xCount, maxX);
   AppendUniqueValue(yy, &yCount, maxY);

   qsort(xx, xCount, sizeof(UINT), CompareUINT);
   qsort(yy, yCount, sizeof(UINT), CompareUINT);

   // Build table template
   rows=yCount-1;
   cols=xCount-1;

   if((Table=malloc(sizeof(PBasicObject)*rows*cols))==NULL)
      goto errHandler1;

   // Initialize table template
   for(i=0;i<rows*cols;i++)
      Table[i]=NULL;

   // Fill template with object pointers
   obX=Data;
   f=fa=TRUE;

   while(f&&fa&&(obX!=NULL)) {
      // Find cell with equal origin
      for(x0=0;xx[x0]<(obX->left);x0++);
      for(y0=0;yy[y0]<(obX->top);y0++);

      // Fill in object pointers
      for(y=y0;f&&fa&&(yy[y]<(obX->top)+(obX->height));y++)
         for(x=x0;f&&fa&&(xx[x]<(obX->left)+(obX->width));x++) {
            i=y*cols+x;
            if(Table[i]==NULL)
            	// Unoccupied cell - fill
            	Table[i]=obX;
            else {
            	// Cell already occupied - abort
              	fa=FALSE;
               obWhich=Table[i];
               // Origins are equal - uninjectable
               f=!(
               	((obX->left)==(obWhich->left))&&
                  ((obX->top)==(obWhich->top))
               );
            }
         }

      // Fetch next object
      obX=obX->n;
   }

	// Remove temporary added object from data
   Tail->n=NULL;

   if(Injectable!=NULL)
   	*Injectable=f;

   if(which!=NULL)
   	*which=obWhich;

   return (!fa);

errHandler1:
	free(yy);

errHandler0:
	free(xx);

   return TRUE;
}

static UINT getMaxX()
{
	PBasicObject obX;
   UINT maxX, X;

   obX=Data;
   maxX=0;
   while(obX!=NULL) {
   	X=(obX->left)+(obX->width);
      if(maxX<X)
      	maxX=X;
   	obX=obX->n;
   }
   return(space);
}

static UINT getMaxY()
{
	PBasicObject obX;
   UINT maxY, Y;

   obX=Data;
   maxY=0;
   while(obX!=NULL) {
   	Y=(obX->top)+(obX->height);
      if(maxY<Y)
      	maxY=Y;
   	obX=obX->n;
   }
   return(space);
}

static BOOL Intersect(UINT fromA, UINT toA,
							 UINT fromB, UINT toB)
{
	if((fromA<fromB)&&(toA<fromB))
   	return FALSE;
   if((fromA>toB)&&(toA>toB))
   	return FALSE;
   return TRUE;
}

static UINT availableSpace(UINT fromX, UINT fromY, UINT front, BOOL dir)
{
	PBasicObject obX;
   UINT space, s, obLeft, obRight, obTop, obBottom;

   obX=Data;
   if(dir)
   	space=GetMaxX()-fromX;
   else
   	space=GetMaxY()-fromY;

   while(obX!=NULL) {
   	obLeft=obX->left;
      obRight=obLeft+(obX->width);
      obTop=obX->top;
      obBottom=obTop+(obX->height);

      if(dir) {
	   	if((obLeft>=fromX)&&Intersect(obTop, obBottom, fromY, fromY+front)) {
   	      	// Object is located before front
      	   	s=obLeft-fromX;
         	   if(s<space)
            		space=s;
	      }
      } else {
	   	if((obTop>=fromY)&&Intersect(obLeft, obRight, fromX, fromX+front)) {
   	      	// Object is located before front
      	   	s=obTop-fromY;
         	   if(s<space)
            		space=s;
	      }
      }

   	obX=obX->n;
   }

   return(space);
}

void ResetAllObject(UINT flags)
{
	PBasicObject obX;

   obX=Data;
   while(obX!=NULL) {
   	obX->flags=flags;
   	obX=obX->n;
   }

}

static void ShiftAllObjects(UINT fromX, UINT fromY,
									 UINT front, UINT delta,
                            BOOL dir)
{
}

void InjectObject(PBasicObject ob)
{
	PBasicObject obstacle, obX;
   BOOL Injectable;
   UINT dX, dY, fromX, fromY, width;

	obX=ob;
   if(ObjectWillOverlap(obX, &Injectable, &obstacle)) {
   	if(Injectable) {
			dX=(obstacle->left)+(obstacle->width)-(obX->left);
         dY=(obstacle->top)+(obstable->height)-(obX->top);
         if((dX>(obstacle->width))||(dY>(obstacle->height))) {
         	// Swap object pointers
            if(dX>(obstacle->width))
            	dX-=obstacle->width;
            if(dY>(obstacle->height))
            	dY-=obstacle->height;
            obX=obstacle;
            obstacle=ob;
         }
         if(dx<dy) {
         	// It's better to shift horizontally
	         fromX=(obstacle->left)+(obstable->width);
   	      fromY=obX->top;
            width=obX->height;
            dx=(obX->width)-availableSpace(fromX, fromY, width, TRUE);
            ShiftAllObjects(fromX, fromY, width, dx, TRUE);
         } else {
         	// It's better to shift vertically
	         fromX=obX->left;
   	      fromY=(obstacle->top)+(obstable->height);
            width=obX->width;
            dy=(obY->height)-availableSpaceY(fromX, fromY, width, FALSE);
            ShiftAllObjects(fromX, fromY, width, dy, TRUE);
         }
      } else
   		return;
   } else
		AppendObject(ob);
}

