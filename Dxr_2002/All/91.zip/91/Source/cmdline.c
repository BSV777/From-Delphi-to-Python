/*
 * FormDesigner
 *
 * Automatic processing of command line arguments
 *
 * by	Andrey V Rogozhin	rav@tula.net
 *
 */

#include <windows.h>
#include <commctrl.h>

#include "resource.h"
#include "common.h"

int ProcessWOGUI(LPSTR FromFile, LPSTR ToFile)
{
   LPVOID lpMsgBuf;
   BOOL q;

	hWndMain=CreateDialog(hInst, (LPCTSTR)IDD_PROGRESSDLG,
   									  NULL, (DLGPROC)ProgressDlg);

   if(hWndMain==NULL) {
   	FormatMessage(
    		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
         NULL,
    		GetLastError(),
    		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
    		(LPTSTR) &lpMsgBuf,
    		0,
    		NULL
		);
      MessageBox(NULL, lpMsgBuf, "GetLastError", MB_OK|MB_ICONINFORMATION);
		LocalFree(lpMsgBuf);
   }

   ShowWindow(hWndMain, SW_SHOW);

   if(LoadDataFromFile(FromFile, hWndMain, IDC_PROGRESSBARLOAD)) {
   	// Process loaded data
      SendDlgItemMessage(hWndMain, IDC_PROGRESSBARVERIFY,
                         PBM_SETRANGE, 0, MAKELPARAM(0, 100));
      SendDlgItemMessage(hWndMain, IDC_PROGRESSBARVERIFY,
                         PBM_SETPOS, (WPARAM) 100, 0);

      q=ExportDataToFile(ToFile, hWndMain, IDC_PROGRESSBARSAVE);

      if(!q)
      	ShowSaveError(IDS_SE_EXPORT, ToFile);
   }

   DestroyWindow(hWndMain);

	return(q?0:1);
}

LRESULT CALLBACK ProgressDlg(HWND hDlg,
									  UINT message,
                             WPARAM wParam,
                             LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
				return TRUE;

		case WM_COMMAND:
			switch(LOWORD(wParam))
         {
				case IDOK:
               PostQuitMessage(0);
               return TRUE;
            case IDCANCEL:
               PostQuitMessage(1);
					return TRUE;
			}
			break;
   }
   return 0;
}
