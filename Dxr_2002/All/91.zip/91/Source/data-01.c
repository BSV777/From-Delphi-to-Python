/*
 * FormDesigner
 *
 * Internal data storage and manipulation
 *
 * by	Andrey V Rogozhin	rav@tula.net
 *
 */

#include <windows.h>
#include <alloc.h>
#include <stdlib.h>
#include <stdio.h>
#include <values.h>

#include "resource.h"

#define __GLOBALS_LOCAL__
#include "common.h"

// Globals

HINSTANCE hInst;

HWND hWndMain;													// Main window indentifier

LPTSTR szTitle, szCurTitle, szSeparator, szWindowClass;
LPTSTR szHello,szExportDlgTitle;
LPTSTR szFileName,szFullFileName,szExportFileName;
LPTSTR szCurFileName,szCurFullFileName;

PBasicObject Data;

OPENFILENAME *ofnOpen,*ofnSave,*ofnExport;

// Locals

static LPTSTR Buffer,TempBuffer;
static DWORD Size, Position;
static LPTSTR szErrorTitle;
static BOOL skipFlag;

BOOL AllocateBasicData(void)
{
	if((szTitle=malloc(MAXLOADSTR))==NULL) return FALSE;
	if((szCurTitle=malloc(MAXFILENAMESIZE+2*MAXLOADSTR))==NULL) return FALSE;
	if((szSeparator=malloc(MAXLOADSTR))==NULL) return FALSE;
	if((szWindowClass=malloc(MAXLOADSTR))==NULL) return FALSE;
	if((szHello=malloc(MAXLOADSTR))==NULL) return FALSE;
	if((szExportDlgTitle=malloc(MAXLOADSTR))==NULL) return FALSE;
	if((szFileName=malloc(MAXFILENAMESIZE))==NULL) return FALSE;
	if((szFullFileName=malloc(MAXFILENAMESIZE))==NULL) return FALSE;
	if((szExportFileName=malloc(MAXFILENAMESIZE))==NULL) return FALSE;
	if((szCurFileName=malloc(MAXFILENAMESIZE))==NULL) return FALSE;
	if((szCurFullFileName=malloc(MAXFILENAMESIZE))==NULL) return FALSE;
	if((ofnOpen=malloc(sizeof(OPENFILENAME)))==NULL) return FALSE;
	if((ofnSave=malloc(sizeof(OPENFILENAME)))==NULL) return FALSE;
	if((ofnExport=malloc(sizeof(OPENFILENAME)))==NULL) return FALSE;
   return TRUE;
}

void FreeBasicData(void)
{
	free(ofnExport);
   free(ofnSave);
   free(ofnOpen);
   free(szCurFullFileName);
   free(szCurFileName);
   free(szExportFileName);
   free(szFullFileName);
   free(szFileName);
   free(szExportDlgTitle);
   free(szHello);
   free(szWindowClass);
   free(szSeparator);
   free(szCurTitle);
   free(szTitle);
}

void InitData(void)
{
	// Erase current file names
	szFullFileName[0]=NULL;
	szFileName[0]=NULL;
	szCurFullFileName[0]=NULL;
	szCurFileName[0]=NULL;
   szExportFileName[0]=NULL;
   if(Data!=NULL) ReleaseData(&Data);
}

void ResetData(void)
{
	InitData();
   UpdateWindowTitle();
	MessageBox(
   	hWndMain,
      "Data reinitialized",
      "Data reinitialized",
      MB_OK | MB_ICONINFORMATION | MB_APPLMODAL
   );
}

void ReleaseData(PBasicObject *start)
{
   PBasicObject pA,pB;

	pA=*start;
	while(pA!=NULL) {
   	pB=pA->n;
      free(pA);
      pA=pB;
   }
   *start=NULL;
}

static void FindCursorPosition(LPDWORD row, LPDWORD col)
{
	DWORD Cursor, x, y;

   Cursor=x=y=0;
   while(Cursor<Position)
   	switch(Buffer[Cursor++]) {
      	case 0x0D:						// CR
            break;
         case 0x0A:						// LF
            x=0;
            y++;
         case 0x09:						// Tab
            x+=8;
            break;
         default:
            x++;
            break;
      }
   *row=y; *col=x;
}

static BOOL ShowParseError(DWORD peType, BOOL warnFlag)
{
	DWORD row, col;
   TCHAR szErrorDesc[MAXLOADSTR], szMsgFormat[MAXLOADSTR];
   LPTSTR Message;
   BOOL r;
   LPVOID args[3];
	LPVOID lpMsgBuf;

   switch(peType) {
   	case IDS_PE_LOADING:
      case IDS_PE_UNEXPECTEDEND:
      	break;
      default:
      	FindCursorPosition(&row, &col);
         break;
   }

	LoadString(hInst, peType, szErrorDesc, MAXLOADSTR);
	LoadString(hInst, IDS_PE_MESSAGE, szMsgFormat, MAXLOADSTR);

   r=TRUE;

   args[0]=szErrorDesc;
   args[1]=(LPVOID)row;
   args[2]=(LPVOID)col;

   if(
   	FormatMessage(
      	FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_STRING|
				FORMAT_MESSAGE_ARGUMENT_ARRAY,
			szMsgFormat,
        	0,
         0,
      	&Message,
      	0,
      	(va_list *) args
      )) {
   	r=(MessageBox(
      	hWndMain,
         Message,
         szErrorTitle,
         MB_ICONERROR|MB_APPLMODAL|(warnFlag ? MB_OKCANCEL : MB_OK)
      )!=IDOK);
   	LocalFree(Message);
   } else {
		FormatMessage(
		    FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		    NULL,
		    GetLastError(),
		    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
          (LPTSTR) &lpMsgBuf,
		    0,
		    NULL
		);
		// Display the string.
		MessageBox(NULL, lpMsgBuf, "GetLastError", MB_OK|MB_ICONINFORMATION);
		// Free the buffer.
		LocalFree(lpMsgBuf);
   }

   return r;
}

BOOL LoadDataFromFile(LPCTSTR FullFileName)
{
	TCHAR szFileName[MAXFILENAMESIZE], szTitleFormat[MAXLOADSTR];
	HANDLE File;
	DWORD Read;
   BOOL qStatus;
   LPVOID args[1];
	LPVOID lpMsgBuf;
   PBasicObject SavedData;

   qStatus=FALSE;

   if((TempBuffer=malloc(MAXCONTENTSIZE))==NULL) return 0;

	if(GetFileTitle(FullFileName, szFileName, MAXFILENAMESIZE)<0) {
   	free(TempBuffer);
      return 0;
   }

	LoadString(hInst, IDS_PE_TITLE, szTitleFormat, MAXLOADSTR);

   args[0]=szFileName;
	if(!FormatMessage(
   	FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_STRING|
   		FORMAT_MESSAGE_ARGUMENT_ARRAY,
      szTitleFormat,
      0,
      0,
      &szErrorTitle,
      0,
      (va_list *)args
   )) {
		FormatMessage(
		    FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		    NULL,
		    GetLastError(),
		    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
          (LPTSTR) &lpMsgBuf,
		    0,
		    NULL
		);
		// Display the string.
		MessageBox(NULL, lpMsgBuf, "GetLastError", MB_OK|MB_ICONINFORMATION);
		// Free the buffer.
		LocalFree(lpMsgBuf);
   }

   File=CreateFile(
   	FullFileName,
   	GENERIC_READ,
      FILE_SHARE_READ,
      NULL,
      OPEN_EXISTING,
      FILE_FLAG_SEQUENTIAL_SCAN,
      NULL
   );

	if(File==INVALID_HANDLE_VALUE) goto errHandle3;

   if((Size=GetFileSize(File, NULL))==0xFFFFFFFF) goto errHandle2;

	if((Buffer=malloc(Size+1))==NULL) goto errHandle2;

   if(!ReadFile(File, Buffer, Size, &Read, NULL)) goto errHandle1;

   if(Read!=Size) goto errHandle1;

   CloseHandle(File);

   SavedData=Data;

	Position=0;
   Buffer[Size]=NULL;

   while((Position<Size)&&(!qStatus)) {
   	qStatus=ParseNextItem();
   }

   if(qStatus) goto errHandle0;

   ReleaseData(&SavedData);

  	MessageBox(
   	hWndMain,
      Buffer,
      "Data loaded from",
      MB_OK | MB_ICONINFORMATION | MB_APPLMODAL
   );

   free(Buffer);
   LocalFree(szErrorTitle);
	free(TempBuffer);

   return 1;

errHandle0:
   ReleaseData(&Data);
   Data=SavedData;

errHandle1:
	free(Buffer);

errHandle2:
	CloseHandle(File);

errHandle3:
	if(!qStatus) ShowParseError(IDS_PE_LOADING, FALSE);
	LocalFree(szErrorTitle);
	free(TempBuffer);

	return 0;
}

static BOOL SkipTo(TCHAR ch)
{
	while((Buffer[Position]!=ch)&&(Position<Size)) Position++;
	return (Position==Size);
}

static BOOL ParseNumProperty(UINT *Target)
{
	BOOL aFlag;
	int i;
	__int64 t;

   skipFlag=FALSE;

	// Skip blank space
   while(IsBlank(Buffer[Position])&&(Position<Size)) Position++;
	if(Position==Size) {
   	// Unexpected EOF
		ShowParseError(IDS_PE_UNEXPECTEDEND, FALSE);
  		return TRUE;
   }

   if(Buffer[Position]=='=') Position++;
	else {
   	// Must have '='
		ShowParseError(IDS_PE_MISSINGEQ, FALSE);
     	return TRUE;
   }

   // Skip blank space
	while(IsBlank(Buffer[Position])&&(Position<Size)) Position++;
	if(Position==Size) {
   	// Unexpected EOF
		ShowParseError(IDS_PE_UNEXPECTEDEND, FALSE);
  		return TRUE;
   }

   if(Buffer[Position]=='"') Position++;
	else {
   	// Must have '"'
		ShowParseError(IDS_PE_MISSINGQT, FALSE);
     	return TRUE;
   }

	// Copy next string of numbers for convertion
  	i=0;
	while(IsNumber(Buffer[Position])&&(Position<Size)&&(i<MAXCONTENTSIZE))
 		TempBuffer[i++]=Buffer[Position++];
	if(!i) {
   	// Missing number
   	ShowParseError(IDS_PE_MISSINGNUM, FALSE);
      return TRUE;
   }
   if(i>5) {
   	// Number too large
		Position-=i;
		aFlag=ShowParseError(IDS_PE_LARGENUM, TRUE);
      if(aFlag) return TRUE;
      SkipTo('"');
      skipFlag=TRUE;
      return FALSE;
   }
   TempBuffer[i]=NULL;

   t=_atoi64(TempBuffer);
   if(t>MAXINT) {
   	// Number too large
		Position-=i;
		aFlag=ShowParseError(IDS_PE_LARGENUM, TRUE);
      if(aFlag) return TRUE;
      skipFlag=TRUE;
      return FALSE;
   }
   if(Target!=NULL) *Target=(UINT)t;

   if(Buffer[Position]=='"') Position++;
	else {
   	// Must have '"'
		ShowParseError(IDS_PE_MISSINGQT, FALSE);
     	return TRUE;
   }

  	return FALSE;
}

static BOOL ParseStrProperty(LPTSTR Target)
{
	BOOL aFlag;
	int i;

   skipFlag=FALSE;

   // Skip blank space
	while(IsBlank(Buffer[Position])&&(Position<Size)) Position++;
	if(Position==Size) {
   	// Unexpected EOF
		ShowParseError(IDS_PE_UNEXPECTEDEND, FALSE);
  		return TRUE;
   }

   if(Buffer[Position]=='=') Position++;
	else {
   	// Must have '='
		ShowParseError(IDS_PE_MISSINGEQ, FALSE);
     	return TRUE;
   }

   // Skip blank space
	while(IsBlank(Buffer[Position])&&(Position<Size)) Position++;
	if(Position==Size) {
   	// Unexpected EOF
		ShowParseError(IDS_PE_UNEXPECTEDEND, FALSE);
  		return TRUE;
   }

   if(Buffer[Position]=='"') Position++;
	else {
   	// Must have '"'
		ShowParseError(IDS_PE_MISSINGQT, FALSE);
     	return TRUE;
   }

	// Copy quoted string content into target
   i=0;
	while((Buffer[Position]!='"')&&(Position<Size)&&(i<MAXCONTENTSIZE))
  		Target[i++]=Buffer[Position++];
   if(i==MAXCONTENTSIZE) {
   	// String too large
		Position-=i;
		aFlag=ShowParseError(IDS_PE_LARGESTR, TRUE);
      if(aFlag) return TRUE;
      SkipTo('"');
      skipFlag=TRUE;
      return FALSE;
   }
   Target[i]=NULL;

	// Skip '"' after the string
	if(Position<Size) Position++;
   else {
   	// Unexpected EOF
		ShowParseError(IDS_PE_UNEXPECTEDEND, FALSE);
  		return TRUE;
   }

  	return FALSE;
}

BOOL ParseNextItem(void)
{
   PBasicObject ob;
   BOOL lFlag, tFlag, wFlag, hFlag, cFlag;
   int i;

	// Skip blank space
   while(IsBlank(Buffer[Position])&&(Position<Size)) Position++;
	if(Position==Size) {
   	// Unexpected EOF
		ShowParseError(IDS_PE_UNEXPECTEDEND, FALSE);
  		return TRUE;
   }

   // New object?
   if(Buffer[Position]=='<') Position++;
	else {
   	// Must have '<'
		ShowParseError(IDS_PE_MISSINGLT, FALSE);
     	return TRUE;
   }

	// Allocate new object
	if((ob=malloc(sizeof(struct TBasicObject)))==NULL) {
		ShowParseError(IDS_PE_ALLOCMEM, FALSE);
     	return TRUE;
   }

	// Copy next word for comparison
	i=0;
	while(IsCharAlpha(Buffer[Position])&&(Position<Size)&&(i<MAXCONTENTSIZE))
   	TempBuffer[i++]=Buffer[Position++];
   if(i==MAXCONTENTSIZE) {
      // Unknown very large object type
   	Position-=i;
		ShowParseError(IDS_PE_UNKNOWNTYPE, FALSE);
   	return TRUE;
   }
   TempBuffer[i]=NULL;

	if(!lstrcmpi(TempBuffer, "Button" ))
		// Button object detected
		ob->type=OT_BUTTON;
   else
	if(!lstrcmpi(TempBuffer, "TextEdit"))
		// Text Edit object detected
		ob->type=OT_TEDIT;
   else
	if(!lstrcmpi(TempBuffer, "Label"))
		// Label object detected
		ob->type=OT_LABEL;
	else {
		// Garbage detected
   	Position-=i;
		ShowParseError(IDS_PE_UNKNOWNTYPE, FALSE);
   	return TRUE;
   }

   // Initialize defaults
   InitDefaults(ob);
   lFlag=tFlag=wFlag=hFlag=cFlag=FALSE;

	while(TRUE)	{
		// Skip blank space
   	while(IsBlank(Buffer[Position])&&(Position<Size)) Position++;
	  	if(Position==Size) {
   		// Unexpected EOF
			ShowParseError(IDS_PE_UNEXPECTEDEND, FALSE);
	  		return TRUE;
	   }

		// Copy next word for comparison
		i=0;
		while(IsCharAlpha(Buffer[Position])&&(Position<Size)&&(i<MAXCONTENTSIZE))
	   	TempBuffer[i++]=Buffer[Position++];
	   if(i==MAXCONTENTSIZE) {
      	// Unknown very large property
	   	Position-=i;
			ShowParseError(IDS_PE_UNKNOWNPROP, FALSE);
	   	return TRUE;
	   }
   	TempBuffer[i]=NULL;

		if(!lstrcmpi(TempBuffer, "left")) {
			// Left property detected
			if(lFlag) {
         	// Already had this property
				if(ShowParseError(IDS_PE_DBLLEFT, TRUE)) return TRUE;
				if(ParseNumProperty(NULL)) return TRUE;
         } else {
				if(ParseNumProperty(&(ob->left))) return TRUE;
   	      lFlag=!skipFlag;
         }
	   } else if(!lstrcmpi(TempBuffer, "top")) {
			// Top property detected
			if(tFlag) {
         	// Already had this property
				if(ShowParseError(IDS_PE_DBLTOP, TRUE)) return TRUE;
				if(ParseNumProperty(NULL)) return TRUE;
         } else {
				if(ParseNumProperty(&(ob->top))) return TRUE;
   	      tFlag=!skipFlag;
         }
	   } else if(!lstrcmpi(TempBuffer, "width")) {
			// Width property detected
			if(wFlag) {
         	// Already had this property
				if(ShowParseError(IDS_PE_DBLWIDTH, TRUE)) return TRUE;
				if(ParseNumProperty(NULL)) return TRUE;
         } else {
				if(ParseNumProperty(&(ob->width))) return TRUE;
   	      wFlag=!skipFlag;
         }
		} else if(!lstrcmpi(TempBuffer, "height")) {
      	// Height property detected
			if(ob->type!=OT_BUTTON) {
            // Valid only for buttons
				if(ShowParseError(IDS_PE_NONBUTTONHEIGHT, TRUE)) return TRUE;
				if(ParseNumProperty(NULL)) return TRUE;
         } else
         if(hFlag) {
         	// Already had this property
				if(ShowParseError(IDS_PE_DBLHEIGHT, TRUE)) return TRUE;
				if(ParseNumProperty(NULL)) return TRUE;
         } else {
				if(ParseNumProperty(&(ob->height))) return TRUE;
   	      hFlag=!skipFlag;
         }
		} else if(!lstrcmpi(TempBuffer, "caption")) {
       	// Caption property detected
			if(ob->type!=OT_BUTTON) {
            // Valid only for buttons
				if(ShowParseError(IDS_PE_NONBUTTONCAPTION, TRUE)) return TRUE;
				if(ParseStrProperty(NULL)) return TRUE;
         } else
         if(cFlag) {
         	// Already had this property
				if(ShowParseError(IDS_PE_DBLCAPTION, TRUE)) return TRUE;
				if(ParseStrProperty(NULL)) return TRUE;
         } else {
				if(ParseStrProperty(ob->content)) return TRUE;
   	      cFlag=!skipFlag;
         }
		} else if(!lstrcmpi(TempBuffer, "text")) {
      	// Text property detected
			if((ob->type!=OT_LABEL)&&(ob->type!=OT_TEDIT)) {
            // Valid only for labels and text edits
				if(ShowParseError(IDS_PE_BUTTONTEXT, TRUE)) return TRUE;
				if(ParseStrProperty(NULL)) return TRUE;
         } else
         if(cFlag) {
         	// Already had this property
				if(ShowParseError(IDS_PE_DBLTEXT, TRUE)) return TRUE;
				if(ParseStrProperty(NULL)) return TRUE;
         } else {
				if(ParseStrProperty(ob->content)) return TRUE;
   	      cFlag=!skipFlag;
         }
		} else {
      	// Garbage detected
	   	Position-=i;
			ShowParseError(IDS_PE_UNKNOWNPROP, FALSE);
	   	return TRUE;
	   }

		// Skip blank space
   	while(IsBlank(Buffer[Position])&&(Position<Size)) Position++;
	  	if(Position==Size) {
   		// Unexpected EOF
			ShowParseError(IDS_PE_UNEXPECTEDEND, FALSE);
	  		return TRUE;
	   }

      if(Buffer[Position]==';')
      	Position++;
      else
      	if(Buffer[Position]=='>') {
         	// Object end detected
         	Position++;
            AppendObject(ob);
            // Skip blank space
				while(IsBlank(Buffer[Position])&&(Position<Size)) Position++;
            return FALSE;
         } else {
	   		// Missing ">"
				ShowParseError(IDS_PE_MISSINGGT, FALSE);
	  			return TRUE;
		   }
   }
}

void InitDefaults(PBasicObject ob)
{
	ob->left=DEFAULT_OBJECT_LEFT;
   ob->top=DEFAULT_OBJECT_TOP;
	switch(ob->type) {
     	case OT_LABEL:
      	ob->width=DEFAULT_LABEL_WIDTH;
         break;
      case OT_TEDIT:
      	ob->width=DEFAULT_TEDIT_WIDTH;
  	      break;
      case OT_BUTTON:
        	ob->width=DEFAULT_BUTTON_WIDTH;
         break;
      default:
        	ob->width=0;
         break;
   }
	switch(ob->type) {
     	case OT_LABEL:
      	ob->height=DEFAULT_LABEL_HEIGHT;
         break;
      case OT_TEDIT:
      	ob->height=DEFAULT_TEDIT_HEIGHT;
  	      break;
      case OT_BUTTON:
        	ob->height=DEFAULT_BUTTON_HEIGHT;
         break;
      default:
        	ob->height=0;
         break;
   }
   ob->content[0]=NULL;
}

BOOL SaveDataToFile(LPCTSTR FileName)
{
	FILE *out;
   PBasicObject ob;
   BOOL q;

   // It's more stylish to sort data before output
	SortData();

	if((out=fopen(FileName, "w"))==NULL)
   	// Unable to open file for writing
   	return FALSE;

	ob=Data; q=FALSE;

   while((ob!=NULL)&&(!q)) {
   	switch(ob->type) {
      	case OT_BUTTON:
         	q=(fprintf(
            		out,
               	"<Button left=\"%d\"; top=\"%d\"; width=\"%d\"; "
            			"height=\"%d\"; caption=\"%s\">\n",
	               ob->left,
	               ob->top,
	               ob->width,
   	            ob->height,
	               ob->content
   	         )==EOF);
				break;
         case OT_LABEL:
         	q=(fprintf(
            		out,
                  "<Label left=\"%d\"; top=\"%d\"; width=\"%d\"; "
                  	"text=\"%s\">\n",
                  ob->left,
                  ob->top,
                  ob->width,
                  ob->content
            	)==EOF);
				break;
         case OT_TEDIT:
         	q=(fprintf(
            		out,
                  "<TextEdit left=\"%d\"; top=\"%d\"; width=\"%d\"; "
            			"text=\"%s\">\n",
                  ob->left,
                  ob->top,
                  ob->width,
                  ob->content
            	)==EOF);
				break;
      }
      ob=ob->n;
   }

   fclose(out);

   if(q) return FALSE;

	MessageBox(
   	hWndMain,
      FileName,
      "Data saved to",
      MB_OK | MB_ICONINFORMATION | MB_APPLMODAL
   );

   return TRUE;
}

int CompareUINT(const void *lpA, const void *lpB)
{
	UINT A, B;

   A=*((UINT*)lpA);
   B=*((UINT*)lpB);

   if(A<B)
   	return -1;
   if(A>B)
   	return 1;
   return 0;
}

static void AppendUniqueValue(UINT *array, LPDWORD count, UINT value)
{
   DWORD i;

   i=0;
   while(i<(*count))
   	if(array[i++]==value)
      	// Value already in array
      	return;
   array[(*count)++]=value;
}

BOOL ExportDataToFile(LPCTSTR FileName)
{
	BOOL q;
	FILE *out;
	PBasicObject obX, *ExportTable;
	UINT *xx, *yy, minX, minY, maxX, maxY, lastWidth, curWidth, right, bottom;
   DWORD count, xCount, yCount, rows, cols, x, y, x0, y0, i, n, TDCount;

	if(Data==NULL) {
     	// Empty data
		if((out=fopen(FileName, "w"))==NULL)
      	return FALSE;
      q=(fprintf(out, "<HMTL></HTML>")!=EOF);
	   fclose(out);
      return q;
	}

   // Compile sorted arrays of unique values on X and Y coordinates
	count=TotalObjects();

   if((xx=malloc(sizeof(UINT)*(count+1)))==NULL)
   	return FALSE;
   if((yy=malloc(sizeof(UINT)*(count+1)))==NULL)
   	goto errHandler0;

	obX=Data;
   xCount=yCount=0;
   maxX=maxY=0;

	while(obX!=NULL) {
   	// Walk every object
   	AppendUniqueValue(xx, &xCount, obX->left);

		right=(obX->left)+(obX->width);
      if(right>maxX)
      	maxX=right;

      AppendUniqueValue(yy, &yCount, obX->top);

      bottom=(obX->top)+(obX->height);
      if(bottom>maxY)
      	maxY=bottom;

      obX=obX->n;
   }

   AppendUniqueValue(xx, &xCount, maxX);
   AppendUniqueValue(yy, &yCount, maxY);

   qsort(xx, xCount, sizeof(UINT), CompareUINT);
   qsort(yy, yCount, sizeof(UINT), CompareUINT);

   // Build table template
	rows=yCount-1;
   cols=xCount-1;

	if((ExportTable=malloc(sizeof(PBasicObject)*rows*cols))==NULL)
   	goto errHandler1;

	// Initialize table template
   for(i=0;i<rows*cols;i++)
   	ExportTable[i]=NULL;

	// Fill template with object pointers
	obX=Data;

	while(obX!=NULL) {
   	// Find cell with equal origin
      for(x0=0;xx[x0]<(obX->left);x0++);
      for(y0=0;yy[y0]<(obX->top);y0++);

      // Fill in object pointers
      for(y=y0;yy[y]<(obX->top)+(obX->height);y++)
      	for(x=x0;xx[x]<(obX->left)+(obX->width);x++)
         	ExportTable[y*cols+x]=obX;

		// Fetch next
      obX=obX->n;
   }

   out=fopen("debug.dmp","w");
   for(y=0;y<=rows;y++) {
   	for(x=0;x<=cols;x++) {
      	if((y==rows)||(x==cols))
            fprintf(out, ".");
         else {
	         i=y*cols+x;
	         if(ExportTable[i]!=NULL)
	            fprintf(out, "%c", ExportTable[i]->content[0]);
	         else
   	         fprintf(out, " ");
         }
      }
      fprintf(out, "\n");
   }
   fclose(out);

   minX=xx[0];
   minY=yy[0];

	// Write HTML file according to ExportTable
	if((out=fopen(FileName, "w"))==NULL)
     	goto errHandler2;

	// Standard HTML header
   if(
   	fprintf(
		  	out,
   	   "<HMTL>\n"
	     	" <BODY>\n"
		   "  <TABLE border=0 cellpadding=0 cellspacing=0 "
                  "style=\"margin:%d 0 0 %d\">\n",
         minY,
         minX
   	)==EOF)
   		goto errHandler3;

	// Output column widths in an optimized way
/*   lastWidth=xx[1]-xx[0];
	for(i=2, q=FALSE;(i<xCount)&&(!q);i++)
   	q=(lastWidth!=(xx[i]-xx[i-1]));
   if(!q) {
   	// Special case when all column widths are equal
	   if(
	   	fprintf(
			  	out,
	   	   "    <COLGROUP valign=top span=%d width=%d>\n",
	         cols,
	         lastWidth
	   	)==EOF)
	   		goto errHandler3;
   } else {
   	// Not all column widths are equal
	   if(fprintf(out, "    <COLGROUP valign=top>\n")==EOF)
	   		goto errHandler3;
	   lastWidth=xx[1]-xx[0];
      n=1;
      q=FALSE;
	   for(i=2;(i<xCount)&&(!q);i++) {
	   	curWidth=xx[i]-xx[i-1];
	   	if(curWidth!=lastWidth) {
				if(n>1)
					q=(fprintf(
	   	      	out,
	      	      "     <COL span=%d width=%d>\n",
                  n,
                  lastWidth
               )==EOF);
            else
					q=(fprintf(
	   	      	out,
	      	      "     <COL width=%d>\n",
                  lastWidth
               )==EOF);
            n=1;
            lastWidth=curWidth;
         } else
         	n++;
      }
      if(!q)
			if(n>1)
				q=(fprintf(
	   	      	out,
	      	      "     <COL span=%d width=%d>\n",
                  n,
                  curWidth
               )==EOF);
            else
					q=(fprintf(
	   	      	out,
	      	      "     <COL width=%d>\n",
                  curWidth
               )==EOF);
      if(q)
      	goto errHandler3;
   } */

   for(y=0, q=FALSE;(y<rows)&&(!q);y++) {
   	// Begin new row
		if(y+1==rows)
      	// Last row don't need to specify height
      	q=(fprintf(
	      	out,
	  	      "   <TR>\n",
	         yy[y+1]-yy[y]
	      )==EOF);
      else
      	q=(fprintf(
	      	out,
	  	      "   <TR style=\"height:%dpx\">\n",
	         yy[y+1]-yy[y]
	      )==EOF);
      for(x=0, TDCount=0;(x<cols)&&(!q);x++) {
      	i=y*cols+x;
      	if(ExportTable[i]!=NULL) {
         	if(
            	(x?(ExportTable[i-1]!=ExportTable[i]):TRUE)&&
					(y?(ExportTable[i-cols]!=ExportTable[i]):TRUE)
            ) {
            	// Object origin detected
					// Find object (x, y) span dimensions in table
               for(
               	x0=x, n=i;
               	(!q)&&(ExportTable[i]==ExportTable[n])&&(x0<cols);
                  x0++
               ) n++;
               x0=x0-x+TDCount;
               for(
               	y0=y, n=i;
                  (!q)&&(ExportTable[i]==ExportTable[n])&&(y0<rows);
                  y0++
               ) n+=cols;
               y0-=y;
					if(!q) q=(fprintf(out, "     <TD")==EOF);
               if((!q)&&(x0>1)) q=(fprintf(out, " colspan=%d", x0)==EOF);
               if((!q)&&(y0>1)) q=(fprintf(out, " rowspan=%d", y0)==EOF);
               if(!q) q=(fprintf(out, ">")==EOF);
               // Object output code here
               if(!q)
						switch(ExportTable[i]->type) {
   	            	case OT_BUTTON:
                     	if(TDCount) {
                        	// We must specify left margin
	      						q=(fprintf(
							      	out,
							  	      "<BUTTON style=\"height:%dpx;width:%dpx;"
                                              "margin-left:%dpx\">%s"
         	                  "</BUTTON>\n",
		      	               ExportTable[i]->height,
               	            ExportTable[i]->width,
                              xx[x]-xx[x-TDCount],
                  	         ExportTable[i]->content
						   	   )==EOF);
                        } else {
	      						q=(fprintf(
							      	out,
							  	      "<BUTTON style=\"height:%dpx;width:%dpx\">%s"
         	                  "</BUTTON>\n",
		      	               ExportTable[i]->height,
               	            ExportTable[i]->width,
                  	         ExportTable[i]->content
						   	   )==EOF);
                        }
      	               break;
         	         case OT_TEDIT:
                     	if(TDCount) {
                        	// We must specify left margin
      							q=(fprintf(
							      	out,
							  	      "<INPUT style=\"width:%dpx;margin-left:%dpx\" "
                                     "value=\"%s\">\n",
                  	         ExportTable[i]->width,
                              xx[x]-xx[x-TDCount],
                     	      ExportTable[i]->content
						      	)==EOF);
                        } else {
      							q=(fprintf(
							      	out,
							  	      "<INPUT style=\"width:%dpx\" value=\"%s\">\n",
                  	         ExportTable[i]->width,
                     	      ExportTable[i]->content
						      	)==EOF);
                        }
      	               break;
         	         case OT_LABEL:
                     	if(TDCount) {
                        	// We must specify left margin
	      						q=(fprintf(
							      	out,
      	                     "<P style=\"margin-left:%dpx\">%s\n",
                              xx[x]-xx[x-TDCount],
         	                  ExportTable[i]->content
							      )==EOF);
                        } else {
	      						q=(fprintf(
							      	out,
      	                     "%s\n",
         	                  ExportTable[i]->content
							      )==EOF);
                        }
      	               break;
                  }
               TDCount=0;
            } else {
            	// We're just stepping over a spanned cell
            }
         } else {
         	// An empty cell detected
            TDCount++;
         }
      }
   }

   if(q)
     	goto errHandler3;

	// Standard HTML footer
   if(
   	fprintf(
      	out,
         "  </TABLE>\n"
         " </BODY>\n"
         "</HTML>"
      )==EOF)
   		goto errHandler3;

   fclose(out);

	free(ExportTable);
	free(yy);
   free(xx);

   return TRUE;

errHandler3:
   fclose(out);

errHandler2:
	free(ExportTable);

errHandler1:
	free(yy);

errHandler0:
	free(xx);

   return FALSE;
}

void AppendObject(PBasicObject ob)
{
	PBasicObject obX;

   obX=FindTail();
   if(obX==NULL) {
   	// Data set was empty
   	Data=ob;
      ob->p=ob->n=NULL;
   } else {
   	obX->n=ob;
      ob->p=obX;
      ob->n=NULL;
   }
}

PBasicObject FindTail(void)
{
	PBasicObject obX,obY;

   obX=obY=Data;
   while(obX!=NULL) {
   	obY=obX;
      obX=obX->n;
   }
   return obY;
}

DWORD TotalObjects(void)
{
	PBasicObject obX;
   DWORD count;

	count=0;
   obX=Data;

   while(obX!=NULL) {
      obX=obX->n;
      count++;
   }

   return count;
}

int CompareBasicObjects(const void *lpA, const void *lpB)
{
	PBasicObject obA, obB;

   obA=(PBasicObject)lpA;
   obB=(PBasicObject)lpB;

	if((obA->top)<(obB->top))
   	// Object A is located higher then B
   	return -1;
   if((obA->top)>(obB->top))
   	// Object A is located lower then B
   	return 1;
   // Objects are on the same line
   if((obA->left)<(obB->left))
   	// Object A is located before B
      return -1;
   if((obA->left)>(obB->left))
   	// Object A is located after B
      return 1;
  	// Objects have same origin
   return 0;
}

BOOL SortData(void)
{
	PBasicObject *list;
   PBasicObject obX;
   DWORD count, i;

	if((count=TotalObjects())<2)
   	// We don't need to sort this array
	   return TRUE;

   if((list=malloc(sizeof(PBasicObject)*count))==NULL)
   	return FALSE;

	// Compile object pointer list in array
	obX=Data;
   i=0;
   while(obX!=NULL) {
   	list[i++]=obX;
      obX=obX->n;
   }

	qsort(list, count, sizeof(PBasicObject), CompareBasicObjects);

   // Rearrange according to sorted list
	Data=list[0];
   i=0;
   while(i<count) {
		if(i)
      	list[i]->p=list[i-1];
      else
      	list[i]->p=NULL;
      if(i<count-1)
      	list[i]->n=list[i+1];
      else
      	list[i]->n=NULL;
      i++;
   }

   free(list);

   return TRUE;
}


