/*
 * FormDesigner
 *
 * Main procedure
 *
 * by	Andrey V Rogozhin	rav@tula.net
 *
 */

#include <windows.h>
#include <commctrl.h>

#include "resource.h"
#include "common.h"

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	int r;
   LPWSTR *argv;
   int argc;
   TCHAR szFromFile[MAXFILENAMESIZE], szToFile[MAXFILENAMESIZE];

	hInst=hInstance;

	InitCommonControls();

   if(!AllocateBasicData()) return 1;

   InitData();

	LoadString(hInst, IDS_APP_TITLE, szTitle, MAXLOADSTR);
	LoadString(hInst, IDS_TITLE_SEPARATOR, szSeparator, MAXLOADSTR);
	LoadString(hInst, IDC_FORMDESIGNER, szWindowClass, MAXLOADSTR);

   argv=CommandLineToArgvW(GetCommandLineW(), &argc);

	if(argc>1) {
      WideCharToMultiByte(
         CP_ACP,
         0,
         argv[1],
         -1,
         szFromFile,
         MAXFILENAMESIZE,
         NULL,
         NULL
      );
      if(argc>2) {
         WideCharToMultiByte(
            CP_ACP,
            0,
            argv[2],
            -1,
            szToFile,
            MAXFILENAMESIZE,
            NULL,
            NULL
         );
	   	r=ProcessWOGUI(szFromFile, szToFile);
      } else
	   	r=GUIStart(nCmdShow, szFromFile);
   } else
     	r=GUIStart(nCmdShow, NULL);

   FreeBasicData();

   GlobalFree(argv);

	return r;
}

