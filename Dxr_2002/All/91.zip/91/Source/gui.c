/*
 * FormDesigner
 *
 * GUI editor interface
 *
 * by	Andrey V Rogozhin	rav@tula.net
 *
 */

#include <windows.h>

#include "resource.h"
#include "common.h"

int GUIStart(int nCmdShow, LPSTR FromFile)
{
	MSG msg;
	HACCEL hAccelTable;

	if(!RegisterMainClass()) return 1;

	LoadString(hInst, IDS_EXPORT_DLG_TITLE, szExportDlgTitle, MAXLOADSTR);

   if (!InitInstance(nCmdShow)) return 1;

   InitializeFileDialogs();

	hAccelTable = LoadAccelerators(hInst, (LPCTSTR)IDC_FORMDESIGNER);

   if(FromFile!=NULL)
      if(LoadDataFromFile(FromFile, NULL, 0)) {
         lstrcpy(szFullFileName, FromFile);
         lstrcpy(szFileName, FromFile);
         lstrcpy(szCurFullFileName, FromFile);
         lstrcpy(szCurFileName, FromFile);
         UpdateWindowTitle();
         InvalidateRect(hWndMain, NULL, TRUE);
         UpdateWindow(hWndMain);
      }

   while(GetMessage(&msg, NULL, 0, 0))
   {
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

   return 0;
}

ATOM RegisterMainClass(void)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra	= 0;
	wcex.cbWndExtra	= 0;
	wcex.hInstance		= hInst;
	wcex.hIcon			= LoadIcon(hInst, (LPCTSTR)IDI_FORMDESIGNER);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= (LPCSTR)IDC_FORMDESIGNER;
	wcex.lpszClassName= szWindowClass;
	wcex.hIconSm		= LoadIcon(hInst, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

BOOL InitInstance(int nCmdShow)
{
	HWND hWnd;

   hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInst, NULL);

   if (!hWnd)
   {
      return FALSE;
   }

   hWndMain=hWnd;				// Save identifier globally

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

void InitializeFileDialogs(void)
{
	// "Open..." dialog
   ofnOpen->lStructSize=sizeof(OPENFILENAME);
   ofnOpen->hwndOwner=hWndMain;
   ofnOpen->hInstance=hInst;
   ofnOpen->lpstrFilter="Form configuration files (*.frm)\0*.frm\0"
   						  "All files (*.*)\0*.*\0"
                       "\0\0";
   ofnOpen->lpstrCustomFilter=NULL;
   ofnOpen->nMaxCustFilter=0;
   ofnOpen->nFilterIndex=1;
   ofnOpen->lpstrFile=szFullFileName;
   ofnOpen->nMaxFile=MAXFILENAMESIZE;
   ofnOpen->lpstrFileTitle=szFileName;
   ofnOpen->nMaxFileTitle=MAXFILENAMESIZE;
   ofnOpen->lpstrInitialDir=NULL;
   ofnOpen->lpstrTitle=NULL;
   ofnOpen->Flags=OFN_CREATEPROMPT | OFN_HIDEREADONLY | OFN_PATHMUSTEXIST;
   ofnOpen->nFileOffset=0;
   ofnOpen->nFileExtension=0;
   ofnOpen->lpstrDefExt="frm";
   ofnOpen->lpfnHook=NULL;
   ofnOpen->lpTemplateName=NULL;

   // "Save as..." dialog
   ofnSave->lStructSize=sizeof(OPENFILENAME);
   ofnSave->hwndOwner=hWndMain;
   ofnSave->hInstance=hInst;
   ofnSave->lpstrFilter="Form configuration files (*.frm)\0*.frm\0"
   						  "All files (*.*)\0*.*\0"
                       "\0\0";
   ofnSave->lpstrCustomFilter=NULL;
   ofnSave->nMaxCustFilter=0;
   ofnSave->nFilterIndex=1;
   ofnSave->lpstrFile=szFullFileName;
   ofnSave->nMaxFile=MAXFILENAMESIZE;
   ofnSave->lpstrFileTitle=szFileName;
   ofnSave->nMaxFileTitle=MAXFILENAMESIZE;
   ofnSave->lpstrInitialDir=NULL;
   ofnSave->lpstrTitle=NULL;
   ofnSave->Flags=OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
   ofnSave->nFileOffset=0;
   ofnSave->nFileExtension=0;
   ofnSave->lpstrDefExt="frm";
   ofnSave->lpfnHook=NULL;
   ofnSave->lpTemplateName=NULL;

   // "Export HTML..." dialog
   ofnExport->lStructSize=sizeof(OPENFILENAME);
   ofnExport->hwndOwner=hWndMain;
   ofnExport->hInstance=hInst;
   ofnExport->lpstrFilter="HTML files (*.html;*.htm)\0*.html;*.htm\0"
   							 "All files (*.*)\0*.*\0"
                         "\0\0";
   ofnExport->lpstrCustomFilter=NULL;
   ofnExport->nMaxCustFilter=0;
   ofnExport->nFilterIndex=1;
   ofnExport->lpstrFile=szExportFileName;
   ofnExport->nMaxFile=MAXFILENAMESIZE;
   ofnExport->lpstrFileTitle=NULL;
   ofnExport->nMaxFileTitle=0;
   ofnExport->lpstrInitialDir=NULL;
   ofnExport->lpstrTitle=szExportDlgTitle;
   ofnExport->Flags=OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
   ofnExport->nFileOffset=0;
   ofnExport->nFileExtension=0;
   ofnExport->lpstrDefExt="html";
   ofnExport->lpfnHook=NULL;
   ofnExport->lpTemplateName=NULL;
}

void UpdateWindowTitle(void)
{
	if(szFullFileName[0]) {
   	lstrcpy(szCurTitle, szCurFileName);
   	lstrcat(szCurTitle, szSeparator);
   	lstrcat(szCurTitle, szTitle);
   } else {
   	lstrcpy(szCurTitle, szTitle);
   }
	SetWindowText(hWndMain, szCurTitle);
}

LRESULT CALLBACK WndProc(HWND	  hWnd,
								 UINT	  message,
                         WPARAM wParam,
                         LPARAM lParam)
{
	PBasicObject SavedData;

	switch (message) {
		case WM_COMMAND:
			// Parse the menu selections:
			switch (LOWORD(wParam)) {
				case IDM_NEW:
            	ResetData();
               break;
				case IDM_OPEN:
			   	lstrcpy(szFullFileName, szCurFullFileName);
			   	lstrcpy(szFileName, szCurFileName);
            	if(GetOpenFileName(ofnOpen)) {
               	if(LoadDataFromFile(szFullFileName, NULL, 0)) {
			   			lstrcpy(szCurFullFileName, szFullFileName);
			   			lstrcpy(szCurFileName, szFileName);
		               UpdateWindowTitle();
                     InvalidateRect(hWndMain, NULL, TRUE);
                     UpdateWindow(hWndMain);
                  }
               }
            	break;
           	case IDM_SAVE:
            	if(szCurFullFileName[0]) {
	            	if(!SaveDataToFile(szCurFullFileName))
	 				     	ShowSaveError(IDS_SE_SAVE, szCurFileName);
                } else {
			   		lstrcpy(szFullFileName, szCurFullFileName);
			   		lstrcpy(szFileName, szCurFileName);
            		if(GetSaveFileName(ofnSave)) {
               		if(SaveDataToFile(szFullFileName)) {
				   			lstrcpy(szCurFullFileName, szFullFileName);
				   			lstrcpy(szCurFileName, szFileName);
      	           		UpdateWindowTitle();
                     } else
		 				     	ShowSaveError(IDS_SE_SAVE, szFileName);
               	}
               }
               break;
            case IDM_SAVEAS:
			   	lstrcpy(szFullFileName, szCurFullFileName);
			   	lstrcpy(szFileName, szCurFileName);
            	if(GetSaveFileName(ofnSave)) {
               	if(SaveDataToFile(szFullFileName)) {
				   		lstrcpy(szCurFullFileName, szFullFileName);
				   		lstrcpy(szCurFileName, szFileName);
      	            UpdateWindowTitle();
                  } else
	 				     	ShowSaveError(IDS_SE_SAVE, szFileName);
               }
            	break;
            case IDM_EXPORT:
            	lstrcpy(szExportFileName,szCurFullFileName);
               if(szExportFileName[0])
	               ReplaceExtension(szExportFileName,"html");
            	if(GetSaveFileName(ofnExport)) {
               	if(!ExportDataToFile(szExportFileName, NULL, 0))
                  	ShowSaveError(IDS_SE_EXPORT, szExportFileName);
               }
            	break;
		 		case IDM_ABOUT:
				   DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
				   break;
				case IDM_EXIT:
				   DestroyWindow(hWnd);
      		   break;
				default:
				   return DefWindowProc(hWnd, message, wParam, lParam);
			}
			break;
		case WM_PAINT:
      	PaintWindow(hWnd);
			break;
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

void PaintWindow(HWND hWnd)
{
	PAINTSTRUCT ps;
	HDC hdc;
	RECT rt, obRect;
   PBasicObject obX;
   HBRUSH rdBrush, grBrush, blBrush;

	hdc = BeginPaint(hWnd, &ps);
	// TODO: Add any drawing code here...
	GetClientRect(hWnd, &rt);
   rdBrush = CreateSolidBrush(RGB(255, 0, 0));
   grBrush = CreateSolidBrush(RGB(0, 255, 0));   blBrush = CreateSolidBrush(RGB(0, 0, 255));
   obX=Data;
   while(obX!=NULL) {
   	obRect.left=obX->left;
      obRect.top=obX->top;
      obRect.right=(obX->left)+(obX->width);
      obRect.bottom=(obX->top)+(obX->height);

      if((obRect.left<=rt.right)&&(obRect.top<=rt.bottom))
      	switch(obX->type) {
         	case OT_BUTTON:
               FillRect(hdc, &obRect, blBrush);
               break;
         	case OT_TEDIT:
               FillRect(hdc, &obRect, rdBrush);
               break;
         	case OT_LABEL:
               FillRect(hdc, &obRect, grBrush);
               break;
         }

      obX=obX->n;
   }

	EndPaint(hWnd, &ps);
}

LRESULT CALLBACK About(HWND hDlg,
							  UINT message,
                       WPARAM wParam,
                       LPARAM lParam)
{
	switch (message) {
		case WM_INITDIALOG:
				return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wParam)) {
            case IDOK:
            case IDCANCEL:
					EndDialog(hDlg, LOWORD(wParam));
					return TRUE;
			}
			break;
   }
   return 0;
}
