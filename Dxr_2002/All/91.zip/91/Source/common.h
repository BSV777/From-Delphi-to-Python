/*
 * FormDesigner
 *
 * Common header file
 *
 * by	Andrey V Rogozhin	rav@tula.net
 *
 */

#define MAXCONTENTSIZE 256
#define MAXLOADSTR 128
#define MAXFILENAMESIZE 256

// Data model

// Basic data container
typedef struct TBasicObject {
	// Object type
	UINT type;
	// Origin coordinates & dimentions
   UINT left, top, width, height;
	// Attached text
   TCHAR content[MAXCONTENTSIZE];
	// Object state flags
   UINT flags;
	// Pointers to next & prev objects
   struct TBasicObject *n, *p;
};
typedef struct TBasicObject *PBasicObject;

// Object types declaration
#define OT_NULL   	0						// Undefined
#define OT_BUTTON 	1						// Button
#define OT_TEDIT  	2						// Text edit
#define OT_LABEL  	3						// Label

// Object state flags
#define OS_SELECTED 	1						// Object selected
#define OS_MOVED 	1							// Object moved

// Object properties defaults
#define DEFAULT_OBJECT_LEFT	0
#define DEFAULT_OBJECT_TOP		0
#define DEFAULT_BUTTON_WIDTH	5
#define DEFAULT_TEDIT_WIDTH	5
#define DEFAULT_LABEL_WIDTH	5
#define DEFAULT_BUTTON_HEIGHT	5
#define DEFAULT_TEDIT_HEIGHT	24
#define DEFAULT_LABEL_HEIGHT	24

// Define global objects if they aren't local
#ifndef __GLOBALS_LOCAL__
extern HINSTANCE hInst;	  			 	// Current application instance
extern HWND hWndMain;					// Main window indentifier
extern LPTSTR szTitle;				 	// Application title read from resources
extern LPTSTR szSeparator;				// To separate file name and title in the bar
extern LPTSTR szWindowClass;		 	// Main window class read from resources
extern LPTSTR szFileName;				// Buffer with file name
extern LPTSTR szFullFileName;			// Buffer with directory & file name
extern LPTSTR szExportFileName;		// Buffer to contain export file name
extern LPTSTR szCurFullFileName;		// Buffer with current directory & file name
extern LPTSTR szCurFileName;			// Buffer with current file name
extern LPTSTR szCurTitle;				// Current window title with file name
extern LPTSTR szExportDlgTitle;		// "Export HTML..." dialog title
extern PBasicObject Data;				// Data root pointer
extern OPENFILENAME *ofnOpen;			// Saved "Open..." dialog parameters
extern OPENFILENAME *ofnSave;			// Saved "Save as..." dialog parameters
extern OPENFILENAME *ofnExport;		// Saved "Export HTML..." dialog parameters
#endif

// gui.c
int GUIStart(int nCmdShow, LPSTR FromFile);
ATOM RegisterMainClass(void);
BOOL InitInstance(int nCmdShow);
void InitializeFileDialogs(void);
void UpdateWindowTitle(void);
LRESULT CALLBACK WndProc(HWND	hWnd,UINT message, WPARAM wParam, LPARAM lParam);
void PaintWindow(HWND hWnd);
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

// cmdline.c
int ProcessWOGUI(LPSTR FromFile, LPSTR ToFile);
LRESULT CALLBACK ProgressDlg(HWND hDlg, UINT message, WPARAM wParam,
									  LPARAM lParam);

// data.c
int AllocateBasicData(void);
void FreeBasicData(void);
void InitData(void);
void ResetData(void);
void ReleaseData(PBasicObject *start);
void ShowSaveError(DWORD seType, LPCTSTR filename);
BOOL LoadDataFromFile(LPCTSTR FullFileName, HWND dlgProgress, int barId);
int ParseNextItem(void);
void InitDefaults(PBasicObject ob);
BOOL SaveDataToFile(LPCTSTR FileName);
BOOL ExportDataToFile(LPCTSTR FileName, HWND dlgProgress, int barId);
void AppendObject(PBasicObject ob);
PBasicObject FindTail(void);
DWORD TotalObjects(void);
int CompareBasicObjects(const void *lpA, const void *lpB);
BOOL SortData(void);
BOOL ObjectWillOverlap(PBasicObject ob,
							  BOOL *Injectable,
                       PBasicObject *which);
void ResetAllObject(UINT flags);
void InjectObject(PBasicObject ob);

// lib.c
LPTSTR ReplaceExtension(LPTSTR lpFilename, LPCTSTR lpExtension);
BOOL IsBlank(TCHAR a);
BOOL IsNumber(TCHAR a);

