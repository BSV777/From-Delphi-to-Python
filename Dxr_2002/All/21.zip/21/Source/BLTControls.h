#ifndef BLTControlsH
#define BLTControlsH

#include "BLTControl.h"
#include "BLTButton.h"
#include "BLTLabel.h"
#include "BLTTextEdit.h"

bool CreateBLTControl(TBLTControl **Control, AnsiString name){
  if(name == "Button")
          *Control = new TBLTButton;
  else if(name == "TextEdit")
         *Control = new TBLTTextEdit;
  else if(name == "Label")
         *Control = new TBLTLabel;
  else {
        *Control = NULL;
        return false;
   }
   return true;
};

#endif

 