//---------------------------------------------------------------------------


#pragma hdrstop

#include "BLTButton.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)


TBLTButton::TBLTButton():TBLTControl()
{
        //TODO: Add your source code here
        name = "Button";
}

AnsiString TBLTButton::getCaption(void)
{
        //TODO: Add your source code here
                return Caption;
}

bool TBLTButton::setProperty(AnsiString property, AnsiString value)
{
        if(property == "Caption")
                Caption = value;
        else return TBLTControl::setProperty( property,  value);

       return true;
}

AnsiString TBLTButton::getState(void)
{
AnsiString result;
        //TODO: Add your source code here
        result = TBLTControl::getState();
        return result+= " Caption = \""+Caption+ "\"; >";
}

AnsiString TBLTButton::getHTMString(void)
{
AnsiString result;
        //TODO: Add your source code here
return result = "<INPUT TYPE = button value=\""+Caption+"\" style=\"width:"+getWidth()+";height:"+getHeight()+"\">";
}