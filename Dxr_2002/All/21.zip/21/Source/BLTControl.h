//---------------------------------------------------------------------------

#ifndef BLTControlH
#define BLTControlH
//---------------------------------------------------------------------------
#include <vcl.h>

const int DefWidth_ = 40;
const int DefHeight_ = 20;

class TBLTControl{
        private:
        int     top, left, width, height;
        protected:
        AnsiString  name;
        public:
        virtual bool setProperty(AnsiString property, AnsiString value);
        virtual AnsiString getState(void);
        virtual AnsiString getHTMString(void);
        TBLTControl();
        void setTop(int top_);
        void setLeft(int left_);
        void setWidth(int width_);
        void setHeight(int height_);
        int getTop(void);
        int getLeft(void);
        int getWidth(void);
        int getHeight(void);
virtual        AnsiString getName(void);
        TBLTControl& operator=(TControl &cont);
};

#endif
