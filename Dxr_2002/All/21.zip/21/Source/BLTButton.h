//---------------------------------------------------------------------------

#ifndef BLTButtonH
#define BLTButtonH
//---------------------------------------------------------------------------
#include "BLTControl.h"

class TBLTButton : public TBLTControl{
        private:
        AnsiString      Caption;
public:
        TBLTButton();
        AnsiString getCaption(void);
        bool setProperty(AnsiString property, AnsiString value);
        AnsiString getState(void);
        AnsiString getHTMString(void);
};

#endif
