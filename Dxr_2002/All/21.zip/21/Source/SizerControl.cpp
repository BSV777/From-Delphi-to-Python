//---------------------------------------------------------------------------


#pragma hdrstop

#include "SizerControl.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

__fastcall TSizerControl::TSizerControl(TComponent * AOwner, TControl * AControl):TCustomControl(AOwner)
{
TRect R;
        //TODO: Add your source code here
        FControl = AControl;
        R = FControl->BoundsRect;
        InflateRect(R,2,2);
        BoundsRect = R;
        FLastBoundRect =BoundsRect;
        Parent = FControl->Parent;
        OnExit = SizerControlExit;
        FWereNoReSize = 0;
        FCheckOverlap = false;
        if(fChangeControl)
                fChangeControl(this,FControl);


}

void __fastcall TSizerControl::CreateParams(TCreateParams & Params)
{
        TCustomControl::CreateParams( Params);
        Params.ExStyle += WS_EX_TRANSPARENT;
}

void __fastcall TSizerControl::CreateHandle(void)
{
        TCustomControl::CreateHandle();
        SetFocus();
}

void __fastcall TSizerControl::SizerControlExit(TObject * Sender)
{
        //TODO: Add your source code here
        Free();
}

void __fastcall TSizerControl::WmSize(TWMMouse & msg)
{
TRect R;
        //TODO: Add your source code here
        if(FCheckOverlap)
                if(CheckOverlapReSize(-2)==0){
                        BoundsRect = FLastBoundRect;
                        return;
                }
        R = BoundsRect;
        FLastBoundRect =BoundsRect;
        InflateRect(R,-2,-2);
        FControl->BoundsRect = R;
        FRectList[0] = Rect(0,0,5,5);
        FRectList[1] = Rect(Width/2-3,0,Width/2+2,5);
        FRectList[2] = Rect(Width-5,0,Width,5);
        FRectList[3] = Rect(Width-5,Height/2-3,Width,Height/2+2);
        FRectList[4] = Rect(Width-5,Height-5,Width,Height);
        FRectList[5] = Rect(Width/2-3,Height-5,Width/2+2,Height);
        FRectList[6] = Rect(0,Height-5,5,Height);
        FRectList[7] = Rect(0,Height/2-3,5,Height/2+2);
        if(fChangeControl)
                fChangeControl(this,FControl);

}

void __fastcall TSizerControl::Paint(void)
{
int     I;
        //TODO: Add your source code here
         Canvas->Brush->Color = clBlack;
        for( I=0; I<8; I++){
                Canvas->Rectangle(FRectList[I]);
        }
}

void __fastcall TSizerControl::WmNcHitTest(TWMMouse & msg)
{
TPoint P;
int     i;
        //TODO: Add your source code here

         P = Point(msg.XPos,msg.YPos);
         P = ScreenToClient(P);
         msg.Result = 0;
         for(i=0;i<8;i++)
                if(PtInRect(FRectList[i],P))
                        msg.Result = FPosList[i];
                if( FCheckOverlap==true && msg.Result!=0)
                        msg.Result=CheckOverlapReSize(msg.Result);
                 if(FWereNoReSize && msg.Result!=0)
                        if( (msg.Result==HTLEFT || msg.Result==HTTOPLEFT ||  msg.Result==HTBOTTOMLEFT)&& (FWereNoReSize&NoReSizeLeft))
                                msg.Result = 0;
                        else if( (msg.Result==HTRIGHT|| msg.Result==HTTOPRIGHT || msg.Result==HTBOTTOMRIGHT) && (FWereNoReSize&NoReSizeRight))
                                msg.Result = 0;
                        else if( (msg.Result==HTTOP || msg.Result==HTTOPLEFT ||msg.Result==HTTOPRIGHT) && (FWereNoReSize&NoReSizeTop))
                                msg.Result = 0;
                        else if((msg.Result==HTBOTTOM ||msg.Result==HTBOTTOMLEFT || msg.Result==HTBOTTOMRIGHT)&& (FWereNoReSize&NoReSizeBottom))
                                msg.Result = 0;

          if(msg.Result == 0)
                DefaultHandler((void*)&msg);
}

void TSizerControl::InflateRect(TRect & R, int dx, int dy)
{
        //TODO: Add your source code here
        R.left -= dx;
        R.top -= dy;
        R.Right += dx;
        R.Bottom +=dy;
}

void TSizerControl::WmLButtonDown(TWMLButtonDown & msg) const
{
        //TODO: Add your source code here
        Perform(WM_SYSCOMMAND,0xF012,0);
}

void __fastcall TSizerControl::WmMove(TWMMouse & msg)
{
TRect R;
        //TODO: Add your source code here
         if(FCheckOverlap)
                if(CheckOverlapReSize(-2)==0){
                        BoundsRect = FLastBoundRect;
                        return;
                }
        R = BoundsRect;
        FLastBoundRect =BoundsRect;
        InflateRect(R,-2,-2);
        FControl->Invalidate();
        FControl->BoundsRect = R;
        if(fChangeControl)
                fChangeControl(this,FControl);



}

int TSizerControl::CheckOverlapReSize(int were)
{
TRect R, F, T;
int     index;
        //TODO: Add your source code here
        for( index = 0; index < Screen->ActiveForm->ControlCount; index++){
             if((R = Screen->ActiveForm->Controls[index]->BoundsRect)!= BoundsRect){
                if(Screen->ActiveForm->Controls[index]!=FControl){
                        F = BoundsRect;
                        if(were==-2)
                                InflateRect(F,1,1);
                        else if( were == HTTOP )
                                ResizeRect(F,ToTop_,2);
                        else if(were == HTTOPLEFT){
                                ResizeRect(F,ToTop_,2);
                                ResizeRect(F,ToLeft_,2);
                        }
                         else if(were == HTTOPRIGHT){
                                ResizeRect(F,ToTop_,2);
                                ResizeRect(F,ToRight_,2);
                         }
                        else if( were == HTBOTTOM)
                                ResizeRect(F,ToBottom_,2);
                        else if( were == HTBOTTOMLEFT ){
                               ResizeRect(F,ToBottom_,2);
                               ResizeRect(F,ToLeft_,2);
                        }
                        else if( were == HTBOTTOMRIGHT){
                               ResizeRect(F,ToBottom_,2);
                               ResizeRect(F,ToRight_,2);
                        }
                        else if( were == HTLEFT)
                                ResizeRect(F,ToLeft_,2);
                        else if( were == HTRIGHT)
                                ResizeRect(F,ToRight_,2);
                        if(IntersectRect(T,R,F)==true)
                                return 0;
                }
             }

        }

        return were;
}

void TSizerControl::ResizeRect(TRect & R, int were, int dz)
{
        //TODO: Add your source code here
        switch(were){
        case ToLeft_:    R.Left-=dz;
                        break;
        case ToRight_:   R.Right+=dz;
                        break;
        case ToTop_:     R.Top-=dz;
                        break;
        case ToBottom_:  R.Bottom+=dz;
                        break;
        }

}

void __fastcall TSizerControl::SetChangeControl(TChangeControl value)
{
        if(fChangeControl != value) {
                fChangeControl = value;
        }
}
TChangeControl __fastcall TSizerControl::GetChangeControl()
{
        return fChangeControl;
}


void TSizerControl::UpdateState(void)
{
        //TODO: Add your source code here
        if(fChangeControl)
                fChangeControl(this,FControl);
}



void __fastcall TSizerControl::WmKeyUp(TWMKey & msg)
{
        //TODO: Add your source code here
        if(msg.CharCode == VK_DELETE ){
              if(FDeleteControl)
                delete FControl;
                FDeleteControl(this,&FControl);
                fChangeControl(this, NULL);
                 SizerControlExit(this);
        }

}

void __fastcall TSizerControl::SetDeleteControl(TDeleteControl value)
{
        if(FDeleteControl != value) {
                FDeleteControl = value;
        }
}
TDeleteControl __fastcall TSizerControl::GetDeleteControl()
{
        return FDeleteControl;
}
