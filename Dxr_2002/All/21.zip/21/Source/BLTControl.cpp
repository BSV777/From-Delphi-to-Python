//---------------------------------------------------------------------------


#pragma hdrstop

#include "BLTControl.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)


bool TBLTControl::setProperty(AnsiString property, AnsiString value)
{
        //TODO: Add your source code here
        if(property == "top")
                top = StrToInt(value);
        else  if(property == "left")
               left = StrToInt(value);
        else  if(property == "width")
               width = StrToInt(value);
        else  if(property == "height")
               height = StrToInt(value);
        else return false;

        return true;
}

AnsiString TBLTControl::getState(void)
{
AnsiString result;
        //TODO: Add your source code here
        return result = "< " + name + " top = \"" + IntToStr(top)+"\"; left =\"" +
         IntToStr(left)+ "\"; width = \"" + IntToStr(width)+"\"; height = \""+
         IntToStr(height)+"\";";
}

AnsiString TBLTControl::getHTMString(void)
{
AnsiString result;
        //TODO: Add your source code here
        return result = " ";
}

TBLTControl::TBLTControl()
{
        //TODO: Add your source code here
        name = "Control";
        top  = -1;
        left = -1;
        width = DefWidth_;
        height = DefHeight_;
}

void TBLTControl::setTop(int top_)
{
        //TODO: Add your source code here
                top = top_;
}

void TBLTControl::setLeft(int left_)
{
        //TODO: Add your source code here
                left = left_;
}

void TBLTControl::setWidth(int width_)
{
        //TODO: Add your source code here
                width = width_;
}

void TBLTControl::setHeight(int height_)
{
        //TODO: Add your source code here
                height = height_;
}

int TBLTControl::getTop(void)
{
        //TODO: Add your source code here
                return top;
}

int TBLTControl::getLeft(void)
{
        //TODO: Add your source code here
                return left;
}

int TBLTControl::getWidth(void)
{
        //TODO: Add your source code here
                return width;
}

int TBLTControl::getHeight(void)
{
        //TODO: Add your source code here
                return height;
}

AnsiString TBLTControl::getName(void)
{
AnsiString result;
        //TODO: Add your source code here
        result = name;
        return   result;
}
TBLTControl& TBLTControl::operator=(TControl &cont){
        setTop(cont.Top);
        setLeft(cont.Left);
        setWidth(cont.Width);
        setHeight(cont.Height);
        return *this;
};
