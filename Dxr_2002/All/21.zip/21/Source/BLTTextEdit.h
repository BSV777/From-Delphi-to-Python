//---------------------------------------------------------------------------

#ifndef BLTTextEditH
#define BLTTextEditH
//---------------------------------------------------------------------------
#include "BLTControl.h"

class TBLTTextEdit : public TBLTControl{
        private:
        AnsiString Text;
        public:
        TBLTTextEdit();
        void setHeight(int height_);
        AnsiString getHTMString(void);
        AnsiString getState(void);
        AnsiString getText(void);
        bool setProperty(AnsiString property, AnsiString value);
};

#endif
