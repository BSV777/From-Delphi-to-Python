//---------------------------------------------------------------------------

#ifndef EditFieldFormH
#define EditFieldFormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "SizerControl.h"
#include <ActnList.hpp>
#include <ActnMan.hpp>
//---------------------------------------------------------------------------
#include <vector>
#include "iBLTFile.h"
using namespace std;

typedef enum { wcNone, wcButton, wcLabel, wcEdit}WhatControl;

const   AnsiString      IndefStr = "Object";
const   int     DefWidth = 80;
const   int     DefHeight = 20;

class TEditField : public TForm
{
__published:	// IDE-managed Components
        void __fastcall AttachSizer(TObject * Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FormMouseUp(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
  private:	// User declarations
        TSizerControl   *Sizer;
        TBLTControl* fBLTControl;
        iBLTFile     fBLTFile;
        TChangeControl FChangedControl;
        bool CheckDefOverlap(int X, int Y);
        void __fastcall fChangeControl(TObject * Sender, TControl* Control);
        void __fastcall SetChangedControl(TChangeControl value);
        TChangeControl __fastcall GetChangedControl();
        void __fastcall DeleteControl(TObject * Sender, TControl ** Control);



public:		// User declarations
          vector<TControl*>        FieldControls;
          WhatControl      WhatNewControl;
        __fastcall TEditField(TComponent* Owner);
DYNAMIC   void __fastcall Paint(void);
        bool LoadFromFile(AnsiString file);
        bool SaveToFile(AnsiString file);
        void FieldControlsClear(void);
        void setCurControlText(AnsiString str);
        __property TChangeControl ChangedControl  = { read=GetChangedControl, write=SetChangedControl };

};
//---------------------------------------------------------------------------
extern PACKAGE TEditField *EditField;
//---------------------------------------------------------------------------
#endif
