//---------------------------------------------------------------------------


#pragma hdrstop

#include "BLTLabel.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)


TBLTLabel::TBLTLabel():TBLTControl()
{
        //TODO: Add your source code here
        name = "Label";
}

bool TBLTLabel::setProperty(AnsiString property, AnsiString value)
{
        //TODO: Add your source code here
      if(property == "Text")
                Text = value;
        else
                return TBLTControl::setProperty( property,  value);

       return true;
}

AnsiString TBLTLabel::getText(void)
{
        //TODO: Add your source code here
                return Text;
}

AnsiString TBLTLabel::getState(void)
{
AnsiString result;
        //TODO: Add your source code here
        result = TBLTControl::getState();
        return result+= "Text =\""+Text+ "\"; >";
}

AnsiString TBLTLabel::getHTMString(void)
{
AnsiString result;
        //TODO: Add your source code here
        return result = Text ;
}