//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "BLTDesing.h"
#include "EditFieldForm.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
ValueListEditor1->EditorMode = false;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Exit1Click(TObject *Sender)
{
        Application->Terminate();        
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SpeedButton1Click(TObject *Sender)
{
        EditField->Show();
        EditField->ChangedControl = ChangeControl;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ComboBox1Change(TObject *Sender)
{
        EditField->WhatNewControl =(WhatControl) ComboBox1->ItemIndex;    
}
//---------------------------------------------------------------------------


void __fastcall TForm1::ChangeControl(TObject* Sender, TControl* Control)
{
AnsiString str;
        //TODO: Add your source code here
        if(Control){
        ValueListEditor1->Values["Top"] = IntToStr(Control->Top);
        ValueListEditor1->Values["Left"] = IntToStr(Control->Left);
        ValueListEditor1->Values["Width"] = IntToStr(Control->Width);
        ValueListEditor1->Values["Height"] = IntToStr(Control->Height);
        str = Control->ClassName();
        if(str=="TButton")
                ValueListEditor1->Values["Caption"] = ((TButton*)Control)->Caption;
        else if(str=="TEdit")
                ValueListEditor1->Values["Caption"] = ((TEdit*)Control)->Text;
        else if(str=="TLabel")
                ValueListEditor1->Values["Caption"] = ((TLabel*)Control)->Caption;
        }else {
        ValueListEditor1->Values["Top"] = "";
        ValueListEditor1->Values["Left"] = "";
        ValueListEditor1->Values["Width"] ="";
        ValueListEditor1->Values["Height"] ="";
        ValueListEditor1->Values["Caption"] = "";
        }

}

//---------------------------------------------------------------------------


void __fastcall TForm1::Open1Click(TObject *Sender)
{
       if(OpenDialog1->Execute()){
                EditField->LoadFromFile(OpenDialog1->FileName);
        };

}
//---------------------------------------------------------------------------

void __fastcall TForm1::Save1Click(TObject *Sender)
{
       if(SaveDialog1->Execute()){
                EditField->SaveToFile(SaveDialog1->FileName);
        };
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ConverttoHTML1Click(TObject *Sender)
{
AnsiString str;
       if(OpenDialog1->Execute()){
         str = OpenDialog1->FileName;
         str.Delete(str.Length()-2,3);
         str += "html";
         fConverter.ConvertFile(OpenDialog1->FileName.c_str(),str.c_str());
        }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::New1Click(TObject *Sender)
{
        EditField->FieldControlsClear();
}
//---------------------------------------------------------------------------


void __fastcall TForm1::ValueListEditor1SetEditText(TObject *Sender,
      int ACol, int ARow, const AnsiString Value)
{
AnsiString str;
    if(ACol == 1 && ARow == 5){
        str = ValueListEditor1->Values["Caption"];
        if(Value!=str)
                EditField->setCurControlText(Value);
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ValueListEditor1SelectCell(TObject *Sender,
      int ACol, int ARow, bool &CanSelect)
{
        if( ARow!=5){
                CanSelect =false;
                ValueListEditor1->EditorMode = false;
        }
        else    {
        ValueListEditor1->EditorMode = true;
         CanSelect =true;
         }

}
//---------------------------------------------------------------------------

