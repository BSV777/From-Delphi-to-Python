//---------------------------------------------------------------------------

#ifndef BLTDesingH
#define BLTDesingH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
#include "SizerControl.h"
#include <Menus.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
#include <ValEdit.hpp>
#include <ComCtrls.hpp>
#include <ToolWin.hpp>
#include <Buttons.hpp>
#include "BLTControls.h"
#include <Dialogs.hpp>
//#include "BLTButton.h"
//#include "BLTTextEdit.h"
//#include "BLTLabel.h"
#include <fstream>
#include "iBLTFile.h"
#include "BLT2HTMConverter.h"

using namespace std;

class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TMainMenu *MainMenu1;
        TMenuItem *File1;
        TMenuItem *Open1;
        TMenuItem *Save1;
        TMenuItem *ConverttoHTML1;
        TMenuItem *Exit1;
        TPanel *Panel1;
        TComboBox *ComboBox1;
        TLabel *Label1;
        TValueListEditor *ValueListEditor1;
        TBevel *Bevel1;
        TSpeedButton *SpeedButton1;
        TOpenDialog *OpenDialog1;
        TSaveDialog *SaveDialog1;
        TMenuItem *New1;
        void __fastcall Exit1Click(TObject *Sender);
        void __fastcall SpeedButton1Click(TObject *Sender);
        void __fastcall ComboBox1Change(TObject *Sender);
        void __fastcall Open1Click(TObject *Sender);
        void __fastcall Save1Click(TObject *Sender);
        void __fastcall ConverttoHTML1Click(TObject *Sender);
        void __fastcall New1Click(TObject *Sender);
        void __fastcall ValueListEditor1SetEditText(TObject *Sender,
          int ACol, int ARow, const AnsiString Value);
        void __fastcall ValueListEditor1SelectCell(TObject *Sender,
          int ACol, int ARow, bool &CanSelect);

private:
        TBLT2HTMConverter       fConverter;
        void __fastcall ChangeControl(TObject* Sender, TControl* Control);	// User declarations

public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
