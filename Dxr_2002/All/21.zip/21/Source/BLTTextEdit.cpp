//---------------------------------------------------------------------------


#pragma hdrstop

#include "BLTTextEdit.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)


TBLTTextEdit::TBLTTextEdit():TBLTControl()
{
        //TODO: Add your source code here
        name = "TextEdit";
}

void TBLTTextEdit::setHeight(int height_)
{
        //TODO: Add your source code here
        return;
}

AnsiString TBLTTextEdit::getHTMString(void)
{
AnsiString result;
        //TODO: Add your source code here
return result = "<INPUT TYPE = text value=\""+Text+"\" style=\"width:"+getWidth()+";height:"+getHeight()+"\">";
}

AnsiString TBLTTextEdit::getState(void)
{
AnsiString result;
        //TODO: Add your source code here
       result = "< " + name + " top = \"" + IntToStr(getTop())+"\"; left = \"" +
         IntToStr(getLeft())+ "\"; width = \"" + IntToStr(getWidth())+"\"; "+" Text = \""+Text+ "\"; >";
 return result;
}

AnsiString TBLTTextEdit::getText(void)
{
        //TODO: Add your source code here
                return Text;
}

bool TBLTTextEdit::setProperty(AnsiString property, AnsiString value)
{
        //TODO: Add your source code here
       if(property == "Text")
                Text = value;
       else
                return TBLTControl::setProperty( property,  value);
       return true;
}