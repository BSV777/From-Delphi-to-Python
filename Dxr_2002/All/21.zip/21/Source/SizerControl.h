//---------------------------------------------------------------------------

#ifndef SizerControlH
#define SizerControlH
//---------------------------------------------------------------------------
#include <vcl.h>

const int FPosList[8] ={HTTOPLEFT,HTTOP,HTTOPRIGHT,HTRIGHT,HTBOTTOMRIGHT,HTBOTTOM,HTBOTTOMLEFT,HTLEFT};
#define NoReSizeLeft 0x01
#define NoReSizeRight 0x02
#define NoReSizeTop 0x04
#define NoReSizeBottom 0x08
#define ToLeft_ 0
#define ToRight_ 1
#define ToTop_ 2
#define ToBottom_ 3

typedef TControl* PControl;
typedef void __fastcall(__closure *TChangeControl)(TObject* Sender, TControl * Control);
typedef void __fastcall(__closure *TDeleteControl)(TObject* Sender, PControl *Control);

class TSizerControl : public TCustomControl{
        public:
        __fastcall TSizerControl(TComponent * AOwner, TControl * AControl);
        void __fastcall CreateParams(TCreateParams & Params);
        void __fastcall CreateHandle(void);
        void __fastcall SizerControlExit(TObject * Sender);
         void __fastcall Paint(void);
        int     FWereNoReSize;
        bool    FCheckOverlap;
        TControl* FControl;
        void UpdateState(void);

private:

        TRect   FRectList[8];
        TRect FLastBoundRect;
        TChangeControl fChangeControl;
        TDeleteControl FDeleteControl;

        void InflateRect(TRect & R, int dx, int dy);
        int CheckOverlapReSize(int were);
        void ResizeRect(TRect & R, int were, int dz);
        void __fastcall SetChangeControl(TChangeControl value);
        void __fastcall WmSize(TWMMouse & msg);
        void __fastcall WmNcHitTest(TWMMouse & msg);
        void WmLButtonDown(TWMLButtonDown & msg) const;
        void __fastcall WmMove(TWMMouse & msg);
        TChangeControl __fastcall GetChangeControl();
        void __fastcall WmKeyUp(TWMKey & msg);
        void __fastcall SetDeleteControl(TDeleteControl value);
        TDeleteControl __fastcall GetDeleteControl();
__published:
                __property TChangeControl ChangeControl  = { read=GetChangeControl, write=SetChangeControl };
                __property TDeleteControl DeleteControl  = { read=GetDeleteControl, write=SetDeleteControl };
protected:
        BEGIN_MESSAGE_MAP
                VCL_MESSAGE_HANDLER(WM_SIZE, TWMMouse, WmSize)
                VCL_MESSAGE_HANDLER(WM_NCHITTEST, TWMMouse, WmNcHitTest)
                VCL_MESSAGE_HANDLER(WM_LBUTTONDOWN, TWMLButtonDown, WmLButtonDown)
                VCL_MESSAGE_HANDLER(WM_MOVE, TWMMouse, WmMove)
                VCL_MESSAGE_HANDLER(WM_KEYUP, TWMKey, WmKeyUp)
        END_MESSAGE_MAP(TCustomControl)

};

#endif
