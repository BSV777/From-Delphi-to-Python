//---------------------------------------------------------------------------


#pragma hdrstop

#include "BLT2HTMConverter.h"

//---------------------------------------------------------------------------


#pragma package(smart_init)
const char *HTMBegin = "<HTML>\n<BODY>\n";
const char *HTMEnd = "</BODY>\n</HTML>\n";
const char *HTMTableBegin = "<TABLE>\n";
const char *HTMTableEnd = "</TABLE>\n";

//#define NEED_SMALL

bool TBLT2HTMConverter::ConvertFile(AnsiString fromFile, AnsiString toFile)
{
unsigned int index, indexR, indexD, rows = 0, cols = 0;
int colspan =-1;
TBLTControl *tBLT;
        //TODO: Add your source code here
        iFile.open(fromFile.c_str());
        oFile.open(toFile.c_str());
        Clear();
        oFile << HTMBegin;
        TDcoord.push_back(0);
        TRcoord.push_back(0);
        while(iFile.readBLTControl(&fBLT)){
                Controls.push_back(fBLT);
                if(*find(TDcoord.begin(),TDcoord.end(), fBLT->getLeft())!=fBLT->getLeft())
                          TDcoord.push_back(fBLT->getLeft());
                if(*find(TDcoord.begin(),TDcoord.end(), fBLT->getLeft()+fBLT->getWidth())!=fBLT->getLeft()+fBLT->getWidth())
                          TDcoord.push_back(fBLT->getLeft()+fBLT->getWidth());
                if(*find(TRcoord.begin(),TRcoord.end(), fBLT->getTop())!=fBLT->getTop())
                          TRcoord.push_back(fBLT->getTop());
                if(*find(TRcoord.begin(),TRcoord.end(), fBLT->getTop()+fBLT->getHeight())!= fBLT->getTop()+fBLT->getHeight())
                          TRcoord.push_back(fBLT->getTop()+fBLT->getHeight());
        }
         sort(TDcoord.begin(),TDcoord.end());
         sort(TRcoord.begin(),TRcoord.end());

         oFile << HTMTableBegin;
         for( indexR = 0; indexR < TRcoord.size()-1; indexR++){
         oFile << "<TR height="<<(TRcoord[indexR+1]-TRcoord[indexR])<<" > ";
                 for( indexD = 0; indexD < TDcoord.size()-1; indexD++){
                    if((tBLT=findBLTControlIn(TRcoord[indexR],TDcoord[indexD], cols, rows))!=NULL){
#ifdef  NEED_SMALL
                               if(colspan>1)
                                      oFile << " COLSPAN="<<colspan;
                                 oFile << " > </TD>";
                                 colspan =-1;
#endif //NEED_SMALL
                                oFile << "<TD width=" << (TDcoord[indexD+1]-TDcoord[indexD]);
                                if( rows > 1)
                                        oFile << " ROWSPAN="<<rows<<" ";
                                if( cols > 1)
                                        oFile << " COLSPAN="<<cols<<" ";
                                oFile << " >";
                                oFile << tBLT->getHTMString().c_str();
                                oFile <<" </TD>";
                     };

                     if(NeedTD(TRcoord[indexR],TDcoord[indexD])){
#ifdef  NEED_SMALL
                        if(indexR==0){
#endif  //NEED_SMALL
                                oFile << "<TD width=" << (TDcoord[indexD+1]-TDcoord[indexD])<<" > </TD>";
#ifdef  NEED_SMALL
                        }else{
                                if(colspan==-1){
                                        oFile << "<TD width=" << (TDcoord[indexD+1]-TDcoord[indexD]);
                                        colspan++;colspan++;
                                }else colspan++;
                                if(indexD==(TDcoord.size()-2)){
                                        if(colspan>1){
                                                oFile << " COLSPAN="<<colspan;
                                        }
                                        oFile << " > </TD>";
                                        colspan =-1;
                                }

                        }
                     }else if(colspan!=-1){
                         if(colspan>2){
                                        oFile << " COLSPAN="<<colspan;
                          }
                         oFile << " > </TD>";
                         colspan =-1;
#endif  //NEED_SMALL
                     }

                  }

         oFile << "</TR >\n";
         }
         oFile << HTMTableEnd;
         oFile << HTMEnd;
        return true;
};

TBLTControl* TBLT2HTMConverter::findBLTControlIn(int top, int left, unsigned int &cols,unsigned int &rows)
{
unsigned int index, rw=1, cl=1, indexR;
        //TODO: Add your source code here
        for(index=0; index < Controls.size(); index++){
             if((Controls[index]->getTop()==top) && (Controls[index]->getLeft()==left)){
                        for( indexR = 0; indexR < TRcoord.size(); indexR++){
                                if((TRcoord[indexR]>top) && (TRcoord[indexR]<(top+Controls[index]->getHeight())))
                                        rw++;
                        }
                        for( indexR = 0; indexR < TDcoord.size(); indexR++){
                                if(TDcoord[indexR]>left && (TDcoord[indexR]<(left+Controls[index]->getWidth())))
                                        cl++;
                        }
                        cols = cl;
                        rows = rw;
                        return  Controls[index];
             }
        }
        return NULL;

}

bool TBLT2HTMConverter::NeedTD(int top, int left)
{
        //TODO: Add your source code here
unsigned int index;
        for(index=0; index < Controls.size(); index++){
             if((Controls[index]->getTop()<top) && ((Controls[index]->getTop()+Controls[index]->getHeight())>top))
                if((Controls[index]->getLeft()<=left)&&((Controls[index]->getLeft()+Controls[index]->getWidth())>left)){
                        return false;
                }
        }
        return true;
}

void TBLT2HTMConverter::Clear(void)
{
        //TODO: Add your source code here
unsigned int index;
        if(Controls.empty()){
                for(index =0; index< Controls.size(); index++)
                        delete Controls[index];
                Controls.erase(Controls.begin(),Controls.end());
                TRcoord.erase(TRcoord.begin(), TRcoord.end());
                TDcoord.erase(TDcoord.begin(), TDcoord.end());

        }
}

