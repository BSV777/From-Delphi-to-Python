//---------------------------------------------------------------------------

#ifndef iBLTFileH
#define iBLTFileH
//---------------------------------------------------------------------------
#include "BLTControls.h"
#include <fstream>
using namespace std;

typedef enum tokens{ INDEF, EQL, STRINGS, EOFS, UNKNOWN}token;

class iBLTFile{
        public:
        int readBLTControl(TBLTControl **object);
        iBLTFile(const char* fn);
        int open( const char * fn);
        iBLTFile();
        void close(void);

        private:

        ifstream infile;
        token   get_token();
        void    read_indef(AnsiString & str);
        int read_string(AnsiString & str);

};
#endif
