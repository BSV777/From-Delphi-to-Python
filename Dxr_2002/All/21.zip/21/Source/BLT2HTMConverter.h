//---------------------------------------------------------------------------

#ifndef BLT2HTMConverterH
#define BLT2HTMConverterH
//---------------------------------------------------------------------------
#include "BLTControls.h"
#include "iBLTFile.h"
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;


class TBLT2HTMConverter{
        private:
        iBLTFile iFile;
        ofstream oFile;
        vector<TBLTControl*>    Controls;
        vector<int>     TDcoord;
        vector<int>     TRcoord;
        TBLTControl     *fBLT;
        TBLTControl* findBLTControlIn(int top, int left,unsigned int &cols,unsigned int &rows);
        bool NeedTD(int top, int left);
        void Clear(void);
        public:
        bool ConvertFile(AnsiString fromFile, AnsiString toFile);

};
#endif
