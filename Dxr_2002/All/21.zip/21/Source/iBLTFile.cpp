//---------------------------------------------------------------------------


#pragma hdrstop

#include "iBLTFile.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

#include <cctype>
#include <cstdlib>

int iBLTFile::readBLTControl(TBLTControl **object)
{
token   tok;
AnsiString  indef, str;
char    ch;
        //TODO: Add your source code here
        while(infile.get(ch), ch!='<')
                if(!infile.good())
                        return 0;
         while((tok=get_token())!= EOFS && tok != UNKNOWN){
              if(tok == STRINGS || tok == EQL || tok == UNKNOWN || tok == EOFS)
                        return 0;
              if(tok == INDEF){
                        read_indef(indef);
                if(CreateBLTControl(object,indef)==false)
                                        return 0;
                 break;
              }
         }
         while((tok=get_token())!= EOFS && tok != UNKNOWN){
              if(tok == INDEF){
                read_indef(indef);
                if((tok=get_token())==EQL ){
                        if((tok=get_token())== STRINGS){
                                read_string(str);
                                if(!((*object)->setProperty(indef,str)))
                                        return 0;
                        }else return 0;
                }else return 0;

              }else return 0;
        }
        if(!infile.good())
                return 0;
        return 1;
};

token iBLTFile::get_token()
{
        //TODO: Add your source code here
char    ch;
        while(infile.get(ch), infile.good() && ch!='>'){
         if( ch =='=')
                return EQL;
        else if(ch == '\"')
                return STRINGS;
        else if(isalpha(ch) || isdigit(ch)){
                infile.putback(ch);
                return INDEF;
                }
        }
                return EOFS;
//        else    return UNKNOWN;
}

void iBLTFile::read_indef(AnsiString & str)
{
       //TODO: Add your source code here
char ch;
        str="";
        while(infile.get(ch), isalpha(ch) && infile.good())
                str+=ch;
        infile.putback(ch);
}

iBLTFile::iBLTFile(const char* fn):infile(fn)
{
        //TODO: Add your source code here

}

int iBLTFile::read_string(AnsiString & str)
{
        //TODO: Add your source code here
char ch;
        str="";
        while(infile.get(ch), ch!='"' && infile.good())
                str+=ch;
        if (infile.good())
                return 1;
        else return 0;
}



int iBLTFile::open(const char * fn)
{
        infile.clear();
        infile.open(fn);
   return 1;     //TODO: Add your source code here
}

iBLTFile::iBLTFile()
{
        //TODO: Add your source code here
}

void iBLTFile::close(void)
{
        //TODO: Add your source code here
        infile.close();
}
