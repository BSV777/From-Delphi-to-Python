//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("BLTDesing.cpp", Form1);
USEFORM("EditFieldForm.cpp", EditField);
//---------------------------------------------------------------------------
#include "BLT2HTMConverter.h"

WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
TBLT2HTMConverter *Converter;
        if(ParamCount()==2){
                Converter = new TBLT2HTMConverter;
                Converter->ConvertFile(ParamStr(1),ParamStr(2));
                delete Converter;
                return 0;
        }
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TForm1), &Form1);
                 Application->CreateForm(__classid(TEditField), &EditField);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        catch (...)
        {
                 try
                 {
                         throw Exception("");
                 }
                 catch (Exception &exception)
                 {
                         Application->ShowException(&exception);
                 }
        }
        return 0;
}
//---------------------------------------------------------------------------
