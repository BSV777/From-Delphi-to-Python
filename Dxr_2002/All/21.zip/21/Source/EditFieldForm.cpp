//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "EditFieldForm.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TEditField *EditField;
//---------------------------------------------------------------------------
__fastcall TEditField::TEditField(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TEditField::AttachSizer(TObject *Sender)
{
AnsiString str;
        //TODO: Add your source code here
        Sizer = new TSizerControl(this,(TControl*)Sender);
        str = Sender->ClassName();
        if(str == "TEdit")
                Sizer->FWereNoReSize = NoReSizeTop | NoReSizeBottom;
        Sizer->FCheckOverlap = true;
        Sizer->ChangeControl = fChangeControl;
        Sizer->DeleteControl = DeleteControl;
        Sizer->UpdateState();
}
void __fastcall TEditField::FormCreate(TObject *Sender)
{
        WhatNewControl = wcNone;
}
//---------------------------------------------------------------------------



void __fastcall TEditField::FormMouseUp(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
        if(WhatNewControl!=wcNone)
        if(!CheckDefOverlap(X,Y)){
                switch(WhatNewControl){
                case wcButton: FieldControls.push_back(new TButton(this));
                                ((TButton*)FieldControls.back())->OnClick = AttachSizer;
                                break;
                case wcLabel: FieldControls.push_back(new TLabel(this));
                                ((TLabel*)FieldControls.back())->OnClick = AttachSizer;
                                break;
                case wcEdit: FieldControls.push_back(new TEdit(this));
                                ((TEdit*)FieldControls.back())->OnClick = AttachSizer;
                                break;
                }
                FieldControls.back()->Top = Y;
                FieldControls.back()->Left = X;
                FieldControls.back()->Width = DefWidth;
                FieldControls.back()->Height = DefHeight;
                FieldControls.back()->Parent = this;
                FieldControls.back()->Name = IndefStr+IntToStr(FieldControls.size());
        }
}
//---------------------------------------------------------------------------


bool TEditField::CheckDefOverlap(int X, int Y)
{
TRect   R(X,Y,X+DefWidth,Y+DefHeight), F;

int     i;
        //TODO: Add your source code here
         for( i=0; i < ControlCount; i++){
                 if(IntersectRect(F,R,Controls[i]->BoundsRect))
                        return true;
         }
         return false;
}

void __fastcall TEditField::Paint(void)
{
int     x,y;
        //TODO: Add your source code here
        for( y=0; y < Height/10; y++)
                for(x=0; x < Width/10; x++)
                        Canvas->Pixels[x*10][y*10]=clBlue;;
}


void __fastcall TEditField::fChangeControl(TObject * Sender, TControl* Control)
{
        //TODO: Add your source code here
        if(FChangedControl)
                FChangedControl(this,Control);
}

void __fastcall TEditField::SetChangedControl(TChangeControl value)
{
        if(FChangedControl != value) {
                FChangedControl = value;
        }
}
TChangeControl __fastcall TEditField::GetChangedControl()
{
        return FChangedControl;
}

bool TEditField::LoadFromFile(AnsiString file)
{
        //TODO: Add your source code here
TBLTControl *control;
    fBLTFile.open(file.c_str());
    FieldControlsClear();

    while(fBLTFile.readBLTControl(&control)){
        if(control->getName()=="Button"){
                FieldControls.push_back(new TButton(this));
                ((TButton*)FieldControls.back())->Caption = ((TBLTButton*)control)->getCaption();
                ((TButton*)FieldControls.back())->OnClick = AttachSizer;
        }else if(control->getName()=="Label"){
                FieldControls.push_back(new TLabel(this));
                ((TLabel*)FieldControls.back())->Caption = ((TBLTLabel*)control)->getText();
                ((TLabel*)FieldControls.back())->OnClick = AttachSizer;
        }else  if(control->getName()=="TextEdit"){
                FieldControls.push_back(new TEdit(this));
               ((TEdit*)FieldControls.back())->Text = ((TBLTTextEdit*)control)->getText();
                ((TEdit*)FieldControls.back())->OnClick = AttachSizer;
        };
        FieldControls.back()->Top = control->getTop();
        FieldControls.back()->Left = control->getLeft();
        FieldControls.back()->Width = control->getWidth();
        FieldControls.back()->Height = control->getHeight();
        FieldControls.back()->Parent = this;
        delete control;
    }

      fBLTFile.close();
    return true;
}

bool TEditField::SaveToFile(AnsiString file)
{
        //TODO: Add your source code here
AnsiString str;
ofstream ofile;
unsigned int index;
    if(ofile.open(file.c_str()), !ofile.is_open())
        return false;
    for(index = 0; index < FieldControls.size() ; index++){
        str = FieldControls[index]->ClassName();
        if(str=="TButton"){
                fBLTControl = new TBLTButton;
                fBLTControl->setProperty("Caption",((TButton*)(FieldControls[index]))->Caption);
        }
        else if(str=="TLabel"){
                fBLTControl = new TBLTLabel;
                fBLTControl->setProperty("Text",((TLabel*)(FieldControls[index]))->Caption);
        }
        else if(str=="TEdit"){
                fBLTControl = new TBLTTextEdit;
                fBLTControl->setProperty("Text",((TEdit*)(FieldControls[index]))->Text);
        }
        *fBLTControl = *FieldControls[index];
        ofile<<fBLTControl->getState().c_str()<<endl;
    }
    ofile.close();
        return true;
}

void TEditField::FieldControlsClear(void)
{
unsigned int index;
        //TODO: Add your source code here
        if(!FieldControls.empty()){
                for(index = 0; index < FieldControls.size(); index++)
                        delete FieldControls[index];
                FieldControls.erase(FieldControls.begin(),FieldControls.end());
                   if(Sizer)
                         delete Sizer;
        }

}
//---------------------------------------------------------------------------



void __fastcall TEditField::DeleteControl(TObject * Sender, TControl **Control)
{
unsigned int index;
        //TODO: Add your source code here
        //
        for(index = 0; index < FieldControls.size(); index++){
                        if (FieldControls[index]==*Control);
                                FieldControls.erase(&FieldControls[index]);
        }
}

void TEditField::setCurControlText(AnsiString str)
{
//AnsiString str1;
        //TODO: Add your source code here
        if(Sizer){
        Sizer->FControl->SetTextBuf(str.c_str());

        /*if(str1 == "TEdit")
                ((TEdit*)Sizer->FControl)->Text = str;
        else  if(str1 == "TLabel")
                ((TLabel*)Sizer->FControl)->Caption = str;
        else   if(str1 == "TButton")
               ((TButton*) Sizer->FControl)->Caption = str;
          */
        }
}
