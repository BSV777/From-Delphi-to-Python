//---------------------------------------------------------------------------

#ifndef BLTLabelH
#define BLTLabelH
//---------------------------------------------------------------------------
#include "BLTControl.h"

class TBLTLabel: public TBLTControl{
        public:
        TBLTLabel();
        bool setProperty(AnsiString property, AnsiString value);
        AnsiString getText(void);
        AnsiString getState(void);
        AnsiString getHTMString(void);
        
        private:
        AnsiString Text;

};

#endif
