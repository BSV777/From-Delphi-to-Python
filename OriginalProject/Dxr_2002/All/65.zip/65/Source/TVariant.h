#ifndef TVariant_h
#define TVariant_h 1

#include "TString.h"

class TVariant 
{
public:

	TVariant(int number);
	TVariant(const char *string);
	TVariant();
    TVariant(const TVariant &right);
    ~TVariant();

	bool isNumber() const;

    TVariant & operator=(const TVariant &right);
	TVariant & operator=(const char *right);
	TVariant & operator=(const int right);

	operator int() const;
	operator const char *() const;

private:
	
	bool FisNumber;
	union
	{
		char *sData;
		int nData;
	};
};

#endif
