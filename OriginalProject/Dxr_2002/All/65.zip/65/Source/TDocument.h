#ifndef TDocument_h
#define TDocument_h 1

#include "TObject.h"
#include "TString.h"

class TDocument 
{
public:
	void DeleteObject(int n);
enum {byTop, byLeft};

	TDocument();
	TDocument(const TDocument& source);
	~TDocument();
	void Reset();

	bool LoadFromFile(const char *Filename);
	bool SaveToFile(const char *Filename);
	bool CheckObjectOverlay(int number);
	bool CheckObjectOverlay(TObject *Object);
	bool CreateObjects(char *Specification);
	TObject* AddObject(const char *name);

	TString getFilename() const;
	const int getObjectCount() const;
	void setObjectCount(int value);
	TObject* getObject(int n) const;
	void setObject(int n, TObject *value);

protected:

	void SetObjectPropertys(TObject *Object, char *Propertys);
	bool CorrectObjectsOverlay();

	void Sort(int type);
	static int _cdecl CompareByTop(const void *A, const void *B);
	static int _cdecl CompareByLeft(const void *A, const void *B);

	int FObjectCount;
	TObject **FObjects;

private:

	bool m_bIgnoreErrors;
	TString Filename;
};

// Class TDocument 

inline TObject* TDocument::getObject(int n) const
{
	return FObjects[n];
}

inline void TDocument::setObject(int n, TObject *value)
{
	FObjects[n] = value;
}

inline const int TDocument::getObjectCount() const
{
	return FObjectCount;
}

#endif
