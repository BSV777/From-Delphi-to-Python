#if !defined(AFX_EDITORDIALOG_H__795785B6_3826_11D6_A8BC_CEFC9A079561__INCLUDED_)
#define AFX_EDITORDIALOG_H__795785B6_3826_11D6_A8BC_CEFC9A079561__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EditorDialog.h : header file
//

#include "TObject.h"

/////////////////////////////////////////////////////////////////////////////
// CEditorDialog dialog

class CEditorDialog : public CDialog
{
// Construction
public:
	void UpdateInfo(TObject*Object);
	CEditorDialog(CWnd* pParent = NULL);   // standard constructor

private:
// Dialog Data
	//{{AFX_DATA(CEditorDialog)
	enum { IDD = IDR_MAINFRAME };
	CString	m_caption;
	CString	m_text;
	int		m_left;
	int		m_top;
	int		m_width;
	int		m_height;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditorDialog)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEditorDialog)
	afx_msg void OnChangeEdits();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void Reset();
	void SetObjectPropertys(TObject *Object);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITORDIALOG_H__795785B6_3826_11D6_A8BC_CEFC9A079561__INCLUDED_)
