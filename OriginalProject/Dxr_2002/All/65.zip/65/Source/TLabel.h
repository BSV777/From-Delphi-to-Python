#ifndef TLabel_h
#define TLabel_h 1

#include "TObject.h"
#include "TString.h"	// Added by ClassView

class TLabel : public TObject
{
public:
enum {prText = prMinPropertyCount};

	virtual TString getName();
	TLabel();
	~TLabel();

	void Paint (CDC *dc);

	TString ToHTML ();
};

#endif
