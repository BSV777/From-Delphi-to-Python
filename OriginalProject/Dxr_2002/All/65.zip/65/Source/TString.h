#ifndef TString_h
#define TString_h 1

class TVariant;
class TString 
{
public:

	friend int GetLengthOfParser(char *& str);
	friend TString ReadWord(char *& source, bool ShiftPosition = true);

	TString(const TVariant& right);
	TString(const int number);
	TString(const char *string);
	TString(const char c);
	TString();
    TString(const TString &right);
    ~TString();

	void ToLowerCase();
	int Length();

    TString & operator=(const TString &right);
	TString & operator=(const char *string);

    int operator==(const TString &right) const;
	int operator!=(const TString &right) const;
	TString& operator +=(const TString &right);

	operator int() const;
	operator const char *() const;

private:

	char *Data;
};

#endif
