#include "stdafx.h"
#include "TDocument.h"
#include <stdio.h>
#include <string.h>
#include "TString.h"
#include "TLabel.h"
#include "TButton.h"
#include "TTextEdit.h"
#include "Editor.h"

// Class TDocument 

TDocument::TDocument()
{
	FObjects = 0;
	FObjectCount = 0;
	m_bIgnoreErrors = false;
}

TDocument::~TDocument()
{
	Reset();
}

bool TDocument::LoadFromFile(const char *Filename)
{
	m_bIgnoreErrors = false;
	FILE *infile;
	char buffer[4097];

	if (!(infile = fopen(Filename, "rt"))) return false;

	Reset();

	while (!feof(infile))
	{
		if (!fgets(buffer, 4096, infile)) break;
		if (!CreateObjects(buffer))
		{
			Reset();
			return false;
		}
	}
	
	this->Filename = Filename;

	for (int i=0;i<FObjectCount;i++)
		if (!CheckObjectOverlay((int)i))
		{
			if (!((CEditorApp*)AfxGetApp())->Promt("Objects are overlapped. Do you want to correct it?"))
			{
				Reset();
				return false;
			}
			
			CorrectObjectsOverlay();
			break;
		}

	return true;
}

bool TDocument::CreateObjects(char *Specification)
{
	TString buffer;
	TObject *Object;

	int ParserLength = GetLengthOfParser(Specification);
	
	if (!ParserLength) return true;

	if (!CreateObjects(Specification + ParserLength + 1)) return false;
	*(Specification + ParserLength) = 0;
	Specification++;

	buffer = ReadWord(Specification);
	buffer.ToLowerCase();
	if (Object = AddObject(buffer))
	{
		SetObjectPropertys(Object, Specification);
		return true;
	}

	if (m_bIgnoreErrors) return true;

	return false;		
}

TObject* TDocument::AddObject(const char *name)
{
	TObject *Object = 0;

	if (!strcmp(name, "label")) Object = new TLabel();
	if (!strcmp(name, "button")) Object = new TButton();
	if (!strcmp(name, "textedit")) Object = new TTextEdit();

	if (Object)
	{
		setObjectCount(getObjectCount() + 1);
		setObject(getObjectCount() - 1, Object);
	} else
	{
		if (!m_bIgnoreErrors&&!((CEditorApp*)AfxGetApp())->Promt("There are wrong data format. Continue?"))
			return 0;
		m_bIgnoreErrors = true;
	}

	return Object;
}

void TDocument::SetObjectPropertys(TObject *Object, char *Propertys)
{
	TString name, buffer, value;
	
	while (strlen(Propertys))
	{
		name = ReadWord(Propertys);
		name.ToLowerCase();
		buffer = ReadWord(Propertys, false);
		if (buffer != (TString)"=") continue;
		buffer = ReadWord(Propertys);
		value = ReadWord(Propertys);

		Object->setProperty(name, value);
	}
}

bool TDocument::SaveToFile(const char *Filename)
{
	Sort(byTop);
	
	FILE *outfile;

	if (!(outfile = fopen(Filename, "wt"))) return false;

	for (int i=0;i<FObjectCount;i++)
		if (fputs(getObject(i)->ToString(), outfile) == EOF)
		{
			fclose(outfile);
			return false;
		}
	
	fclose(outfile);

	this->Filename = Filename;

	return true;
}

TString TDocument::getFilename() const
{
	return Filename;
}

void TDocument::Reset()
{
	Filename = "";
	for (int i=0;i<FObjectCount;i++)
		delete FObjects[i];
	delete FObjects;
	FObjectCount = 0;
	FObjects = 0;
}

bool TDocument::CheckObjectOverlay(int number)
{
	TObject *Object = getObject(number);

	CSize Common;
	CRect SelfRect = Object->getRect();

	if ((SelfRect.left < 0)||(SelfRect.top < 0))
		return false;

	if ((SelfRect.right >= GlobalViewSize)||(SelfRect.bottom >= GlobalViewSize))
		return false;

	if ((SelfRect.Width()<20)||(SelfRect.Height()<20))
		return false;

	for (int i=0;i<getObjectCount();i++)
	{
		if (i==number) continue;
		Common = (getObject(i)->getRect() & SelfRect).Size();
		if (Common.cx || Common.cy)
			return false;
	}

	return true;
}

bool TDocument::CorrectObjectsOverlay()
{
	bool OK = true;
	TObject *Object;
	CSize Common;
	CRect SelfRect, Rect;

Again:

	Sort(byLeft);
	Sort(byTop);

	for (int j=0;j<getObjectCount();j++)
	{
		SelfRect = getObject(j)->getRect();

		if (SelfRect.left < 0)
		{
			SelfRect.right = -SelfRect.left;
			SelfRect.left = 0;
			OK = false;
		}
		if (SelfRect.top < 0)
		{
			SelfRect.bottom = -SelfRect.top;
			SelfRect.top = 0;
			OK = false;
		}
		if (SelfRect.right >= GlobalViewSize)
		{
			TDocument::DeleteObject(j);
			OK = false;
			goto Again;
		}
		if (SelfRect.bottom >= GlobalViewSize)
		{
			TDocument::DeleteObject(j);
			OK = false;
			goto Again;
		}
		if (SelfRect.Width() < 20)
		{
			SelfRect.right = SelfRect.left + 20;
			OK = false;
		}
		if (SelfRect.Height() < 20)
		{
			SelfRect.bottom = SelfRect.top + 20;
			OK = false;
		}

		getObject(j)->setRect(SelfRect);

		for (int i=0;i<getObjectCount();i++)
		{
			if (i==j) continue;
			
			Object = getObject(i);
			Rect = Object->getRect();
			Common = (Rect & SelfRect).Size();
			if (Common.cx || Common.cy)
			{
				OK = false;
				if (Common.cx < Common.cy)
				{
					Common.cy = 0;
					if (SelfRect.left <= Rect.left)
						Rect += Common;
					else goto Again;
				}
				else
				{
					Common.cx = 0;
					if (SelfRect.top <= Rect.top)
						Rect += Common;
					else goto Again;
				}
				Object->setRect(Rect);
				i = 0;
			}
		}
	}

	return OK;
}

void TDocument::Sort(int type)
{
	switch (type)
	{
	case byTop:
	default:
		qsort(FObjects, FObjectCount, sizeof(TObject*), CompareByTop);
		break;
	case byLeft:
		qsort(FObjects, FObjectCount, sizeof(TObject*), CompareByLeft);
	}
}

int _cdecl TDocument::CompareByTop(const void *A, const void *B)
{
	TObject *a = *((TObject**)A), *b = *((TObject**)B);
	if (a->getRect().top > b->getRect().top) return 1;
	if (a->getRect().top < b->getRect().top) return -1;
	if (a->getRect().left > b->getRect().left) return 1;
	if (a->getRect().left < b->getRect().left) return -1;
	return 0;
}

int _cdecl TDocument::CompareByLeft(const void *A, const void *B)
{
	TObject *a = *((TObject**)A), *b = *((TObject**)B);
	if (a->getRect().left > b->getRect().left) return 1;
	if (a->getRect().left < b->getRect().left) return -1;
	if (a->getRect().top > b->getRect().top) return 1;
	if (a->getRect().top < b->getRect().top) return -1;
	return 0;
}


TDocument::TDocument(const TDocument &source)
{
	FObjects = 0;
	FObjectCount = 0;
	Reset();

	int ObjectCount = source.getObjectCount();
	FObjects = new TObject* [ObjectCount];
	for (int i=0;i<ObjectCount;i++)
	{
		FObjects[i] = AddObject(source.getObject(i)->getName());
		*(FObjects[i]) = *(source.getObject(i));
	}
	Filename = source.getFilename();
}

bool TDocument::CheckObjectOverlay(TObject *Object)
{
	for (int i=0;i<getObjectCount();i++)
		if (getObject(i)==Object)
			return CheckObjectOverlay(i);
	return true;
}

void TDocument::setObjectCount(int value)
{
	TObject **Temp = new TObject* [value];
	for (int i=value;i<FObjectCount;i++) delete FObjects[i];
	int common = (FObjectCount > value) ? value : FObjectCount;
	for (i=0;i<common;i++) Temp[i] = FObjects[i];
	for (i=FObjectCount;i<value;i++) Temp[i] = 0;
	if (FObjects) delete FObjects;
	FObjects = Temp;
	FObjectCount = value;
}

void TDocument::DeleteObject(int n)
{
	if ((n < 0)||(n >= getObjectCount())) return;
	
	TObject *Buffer = getObject(n);

	setObject(n, getObject(getObjectCount() - 1));
	setObject(getObjectCount() - 1, Buffer);
	setObjectCount(getObjectCount() - 1); 
}
