#include "stdafx.h"
#include "TProperty.h"

// Class TProperty 

TProperty::TProperty(const char* Name, const TVariant& Value)
{
	this->Name = Name;
	this->Value = Value;
}

TProperty::TProperty(const TProperty &right)
{
	(*this) = right;
}

TProperty::~TProperty()
{
}

TProperty & TProperty::operator=(const TProperty &right)
{
        Value = right.Value;
        Name = right.Name;
        return *this;
}
