#include "stdafx.h"
#include "TButton.h"
// Class TButton 

TButton::TButton()
		:TObject()
{
	setPropertyCount(getPropertyCount() + 1);
	FProperty[getPropertyCount() - 1] 
		= new TProperty("caption", (TVariant)(char *)"Caption");
}

TButton::~TButton()
{
}

void TButton::Paint (CDC *dc)
{
	CRect MyRect = getRect();
	
	if (!dc->RectVisible(MyRect)) return;

	CBrush brush(RGB(200, 200, 200));
	CBrush* pOldBrush = dc->SelectObject(&brush);

	CPen penBlack;
	penBlack.CreatePen(PS_SOLID, 1, RGB(0, 0, 0));
	CPen* pOldPen = dc->SelectObject(&penBlack);
	CPen penGrey;
	penGrey.CreatePen(PS_SOLID, 1, RGB(225, 225, 225));

	dc->Rectangle(MyRect);
	dc->SelectObject(&penGrey);
	dc->MoveTo(MyRect.left, MyRect.bottom-2);
	dc->LineTo(MyRect.TopLeft());
	dc->LineTo(MyRect.right-1, MyRect.top);
	dc->SelectObject(&penBlack);
	dc->SetBkColor(RGB(200, 200, 200));
	MyRect.DeflateRect(1, 1);
	dc->DrawText((const char *)getProperty(prCaption)->getValue(), MyRect, DT_CENTER|DT_VCENTER);

	dc->SelectObject(pOldBrush);
	dc->SelectObject(pOldPen);	
}

TString TButton::ToHTML ()
{
	TString s = "<input type=button value='";
	s += (TString)FProperty[prCaption]->getValue();
	s += (TString)"' style='width=";
	s += (TString)getProperty(prWidth)->getValue();
	s += (TString)";height=";
	s += (TString)getProperty(prHeight)->getValue();
	s += (TString)"'>";
	return s;
}

TString TButton::getName()
{
	return "button";
}
