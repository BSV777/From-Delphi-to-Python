#ifndef THTMLDocument_h
#define THTMLDocument_h 1

#include "TDocument.h"

struct TTable
{
public:
	
	TTable() { N = RowSpan = ColSpan = 0; }

	int N;
	int RowSpan;
	int ColSpan;
};

class THTMLDocument : public TDocument
{
enum {caWidths, caHeights};
public:
	THTMLDocument();
	bool ExportToFile(const char *Filename);

	THTMLDocument(TDocument &source);
	~THTMLDocument();
private:
	void CheckForColSpanOrRowSpan();
	void GenerateTable();
	void WriteTable(FILE* outfile);
	int GetValueByObject(TObject *Object, int what);
	int* CreateArray(int what, int& Count, int& MinValue);
	
	int Width;
	int Height;
	TTable ** Table;
	int * CellWidths;
	int * CellHeights;
};

#endif
