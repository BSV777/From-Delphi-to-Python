#ifndef TTextEdit_h
#define TTextEdit_h 1

#include "TObject.h"
#include "TString.h"	// Added by ClassView

class TTextEdit : public TObject
{
public:
enum {prText = prMinPropertyCount};

	virtual TString getName();
	virtual void setProperty(int n, const TVariant& value);

	TTextEdit();
	~TTextEdit();

	void Paint(CDC *dc);
	TString ToHTML();
};

#endif
