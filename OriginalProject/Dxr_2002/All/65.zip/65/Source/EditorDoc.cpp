// EditorDoc.cpp : implementation of the CEditorDoc class
//

#include "stdafx.h"
#include "Editor.h"
#include "EditorDoc.h"
#include "THTMLDocument.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditorDoc

IMPLEMENT_DYNCREATE(CEditorDoc, CDocument)

BEGIN_MESSAGE_MAP(CEditorDoc, CDocument)
	//{{AFX_MSG_MAP(CEditorDoc)
	ON_COMMAND(ID_FILE_EXPORT, OnFileExport)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditorDoc construction/destruction

CEditorDoc::CEditorDoc()
	:CDocument(),
	TDocument()
{
}

CEditorDoc::~CEditorDoc()
{
}

///////////////////////////////////////////////////////////////////////////
// CEditorDoc diagnostics

#ifdef _DEBUG
void CEditorDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CEditorDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CEditorDoc commands

BOOL CEditorDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	return LoadFromFile(lpszPathName);
}

BOOL CEditorDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	bool OK = SaveToFile(lpszPathName);
	SetModifiedFlag(!OK);
	return OK;
}

BOOL CEditorDoc::OnNewDocument()
{
	Reset();
	return true;
}

void CEditorDoc::MoveObject(int number, const CSize &Offset)
{
	CRect Rect = getObject(number)->getRect();
	Rect += Offset;
	getObject(number)->setRect(Rect);
}

bool CEditorDoc::GetObjectByPoint(int &number, const CPoint &point)
{
	CRect Rect;
	
	for (int i=0;i<getObjectCount();i++)
	{
	        Rect = getObject(i)->getRect();
	        if (Rect.PtInRect(point))
	        {
	                number = i;
	                return true;
	        }
	}
	
	return false;
}

void CEditorDoc::OnFileExport() 
{
	CFileDialog FileDialog(false, "htm");
	if (FileDialog.DoModal() == IDCANCEL) return;
	
	AfxGetApp()->DoWaitCursor(1);
	THTMLDocument HTMLDocument(*this);
	HTMLDocument.ExportToFile(FileDialog.GetFileName());
	AfxGetApp()->DoWaitCursor(-1);
}

TObject* CEditorDoc::getObject(int n)
{
	SetModifiedFlag();
	return TDocument::getObject(n);
}
