#ifndef TProperty_h
#define TProperty_h 1

#include "TString.h"
#include "TVariant.h"

//	��� �������� �������.
class TProperty 
{
public:
	
	TProperty(const char* Name, const TVariant& Value);
	TProperty(const TProperty &right);
	~TProperty();

	TProperty & operator=(const TProperty &right);

	const TString getName() const;

	const TVariant getValue() const;
	void setValue(TVariant value);

private:
	TString Name;
	TVariant Value;
};

// Class TProperty 

inline const TVariant TProperty::getValue() const
{
	return Value;
}

inline void TProperty::setValue(TVariant value)
{
	Value = value;
}

inline const TString TProperty::getName() const
{
	return Name;
}

#endif
