// EditorView.h : interface of the CEditorView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_EDITORVIEW_H__795785AE_3826_11D6_A8BC_CEFC9A079561__INCLUDED_)
#define AFX_EDITORVIEW_H__795785AE_3826_11D6_A8BC_CEFC9A079561__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class TSelection
{
public:

	void Update();
	TSelection();
	int GetCount();
	int First();
	bool Contain(int n);
	void Add(int n);
	void Clear();
private:
	CList<int, int&> Data;
};

class CEditorDoc;
class CEditorView : public CScrollView
{
protected: // create from serialization only
	CEditorView();
	DECLARE_DYNCREATE(CEditorView)

public:
	CEditorDoc* GetDocument();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditorView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	TObject* GetSelectedObject();
	virtual ~CEditorView();
	void RedrawAll(bool FillBackground = false);

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

// Generated message map functions
protected:
	//{{AFX_MSG(CEditorView)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnEditCopy();
	afx_msg void OnEditCut();
	afx_msg void OnEditPaste();
	afx_msg void OnEditDelete();
	afx_msg void OnNewButton();
	afx_msg void OnNewLabel();
	afx_msg void OnNewTextedit();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:

	void NewObject(const char* name);
	void CheckSizeType(const CPoint& Point);
	void SizeObject(const CPoint& Point);
	void SetSelectRect(const CPoint& Point);
	void MoveObjects(CSize Offset);
	void SelectObjects(int fCtrl);
	void AddObject(const CPoint& point);
	bool SelectObject(const CPoint& Point, int fCtrl);
	void UpdateRect(const CRect& Rect);

	bool m_bSizing;
	int m_stSizeType;
	void SetSizeCursor(const int& SizeType);
	TString m_strNewObjectName;
	bool m_bNewObject;
	CPoint m_ptMouse;
	bool m_bSelecting;
	CRect m_rectSelection;
	bool m_bMoving;
	TSelection m_listSelected;
};

#ifndef _DEBUG  // debug version in EditorView.cpp
inline CEditorDoc* CEditorView::GetDocument()
   { return (CEditorDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITORVIEW_H__795785AE_3826_11D6_A8BC_CEFC9A079561__INCLUDED_)
