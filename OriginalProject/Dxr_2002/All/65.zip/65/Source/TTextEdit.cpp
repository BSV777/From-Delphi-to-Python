#include "stdafx.h"
#include "TTextEdit.h"

// Class TTextEdit 

TTextEdit::TTextEdit()
:TObject()
{
	setPropertyCount(getPropertyCount() + 1);
	FProperty[getPropertyCount() - 1] 
		= new TProperty("text", (TVariant)(char *)"Text");
}

TTextEdit::~TTextEdit()
{
}

void TTextEdit::Paint (CDC *dc)
{
	CRect MyRect = getRect();
	
	if (!dc->RectVisible(MyRect)) return;

	CBrush brush(RGB(255, 255, 255));
	CBrush* pOldBrush = dc->SelectObject(&brush);

	CPen penBlack;
	penBlack.CreatePen(PS_SOLID, 1, RGB(0, 0, 0));
	CPen* pOldPen = dc->SelectObject(&penBlack);
	CPen penGrey;
	penGrey.CreatePen(PS_SOLID, 1, RGB(225, 225, 225));

	dc->Rectangle(MyRect);
	dc->SelectObject(&penGrey);
	dc->MoveTo(MyRect.left, MyRect.bottom-1);
	dc->LineTo(MyRect.right-1, MyRect.bottom-1);
	dc->LineTo(MyRect.right-1, MyRect.top);
	dc->SelectObject(&penBlack);
	dc->SetBkColor(RGB(255, 255, 255));
	MyRect.DeflateRect(1, 1);
	dc->DrawText((const char *)getProperty(prText)->getValue(), MyRect, DT_SINGLELINE);

	dc->SelectObject(pOldBrush);
	dc->SelectObject(pOldPen);	
}

TString TTextEdit::ToHTML ()
{
	TString s = "<input type=textedit value='";
	s += (TString)FProperty[prText]->getValue();
	s += (TString)"' style='width=";
	s += (TString)getProperty(prWidth)->getValue();
	s += (TString)"'>";
	return s;
}

TString TTextEdit::getName()
{
	return "textedit";
}

void TTextEdit::setProperty(int n, const TVariant& value)
{
	if (n == prHeight) return;
	TObject::setProperty(n, value);
}
