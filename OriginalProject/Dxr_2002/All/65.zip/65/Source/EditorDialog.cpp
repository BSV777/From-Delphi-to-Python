// EditorDialog.cpp : implementation file
//

#include "stdafx.h"
#include "Editor.h"
#include "EditorDialog.h"
#include "TObject.h"
#include "EditorView.h"
#include "TProperty.h"
#include "EditorDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditorDialog dialog


CEditorDialog::CEditorDialog(CWnd* pParent /*=NULL*/)
        : CDialog(CEditorDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEditorDialog)
	m_caption = _T("");
	m_text = _T("");
	m_left = 0;
	m_top = 0;
	m_width = 0;
	m_height = 0;
	//}}AFX_DATA_INIT
}

void CEditorDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEditorDialog)
	DDX_Text(pDX, IDC_EDIT5, m_caption);
	DDV_MaxChars(pDX, m_caption, 255);
	DDX_Text(pDX, IDC_EDIT6, m_text);
	DDV_MaxChars(pDX, m_text, 255);
	DDX_Text(pDX, IDC_EDIT1, m_left);
	DDV_MinMaxInt(pDX, m_left, 0, 32000);
	DDX_Text(pDX, IDC_EDIT2, m_top);
	DDV_MinMaxInt(pDX, m_top, 0, 32000);
	DDX_Text(pDX, IDC_EDIT3, m_width);
	DDV_MinMaxInt(pDX, m_width, 0, 32000);
	DDX_Text(pDX, IDC_EDIT4, m_height);
	DDV_MinMaxInt(pDX, m_height, 0, 32000);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CEditorDialog, CDialog)
	//{{AFX_MSG_MAP(CEditorDialog)
	ON_EN_KILLFOCUS(IDC_EDIT1, OnChangeEdits)
	ON_EN_KILLFOCUS(IDC_EDIT2, OnChangeEdits)
	ON_EN_KILLFOCUS(IDC_EDIT3, OnChangeEdits)
	ON_EN_KILLFOCUS(IDC_EDIT4, OnChangeEdits)
	ON_EN_CHANGE(IDC_EDIT5, OnChangeEdits)
	ON_EN_CHANGE(IDC_EDIT6, OnChangeEdits)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditorDialog message handlers

void CEditorDialog::OnChangeEdits() 
{
	UpdateData(true);
	CEditorView * View=(CEditorView*)((CFrameWnd *)AfxGetMainWnd())->GetActiveView();
	TObject *Object = View->GetSelectedObject();
	if (Object) 
	{
	        SetObjectPropertys(Object);
	        UpdateInfo(Object);
	        View->RedrawAll(true);
	} else Reset();
}

void CEditorDialog::SetObjectPropertys(TObject *Object)
{
	if (!Object) return;
	
	int t_left = Object->getProperty("left")->getValue();
	int t_top = Object->getProperty("top")->getValue();
	int t_width = Object->getProperty("width")->getValue();
	int t_height = Object->getProperty("height")->getValue();
	
	Object->setProperty("left", (TString)m_left);
	Object->setProperty("top", (TString)m_top);
	Object->setProperty("width", (TString)m_width);
	Object->setProperty("height", (TString)m_height);
	Object->setProperty("text", (TString)m_text);
	Object->setProperty("caption", (TString)m_caption);
	
	CEditorDoc * Doc=(CEditorDoc*)((CFrameWnd *)AfxGetMainWnd())->GetActiveDocument();
	if (!Doc->CheckObjectOverlay(Object))
	{
	        Object->setProperty("left", (TString)t_left);
	        Object->setProperty("top", (TString)t_top);
	        Object->setProperty("width", (TString)t_width);
	        Object->setProperty("height", (TString)t_height);
	}
}

void CEditorDialog::UpdateInfo(TObject *Object)
{
	if (!Object)
	{
	        Reset();
	        return;
	};
	m_left = Object->getProperty("left")->getValue();
	m_top = Object->getProperty("top")->getValue();
	m_width = Object->getProperty("width")->getValue();
	m_height = Object->getProperty("height")->getValue();
	if (Object->getProperty("text"))
	        m_text = Object->getProperty("text")->getValue();
	else m_text = "";
	if (Object->getProperty("caption"))
	        m_caption = Object->getProperty("caption")->getValue();
	else m_caption = "";
	UpdateData(false);
}

void CEditorDialog::Reset()
{
	m_caption = _T("");
	m_text = _T("");
	m_left = 0;
	m_top = 0;
	m_width = 0;
	m_height = 0;
	UpdateData(false);
}
