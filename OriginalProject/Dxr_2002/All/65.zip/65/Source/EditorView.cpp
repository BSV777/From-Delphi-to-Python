// EditorView.cpp : implementation of the CEditorView class
//

#include "stdafx.h"
#include "Editor.h"

#include "EditorDoc.h"
#include "EditorView.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

enum TSizeType
{
	stLeft = 1, stRight = 2, stTop = 4, stTopLeft = 5,
	stTopRight = 6,stBottom = 8,
	stBottomLeft = 9, stBottomRight = 10
};
	 

/////////////////////////////////////////////////////////////////////////////
// CEditorView

IMPLEMENT_DYNCREATE(CEditorView, CScrollView)

BEGIN_MESSAGE_MAP(CEditorView, CScrollView)
	//{{AFX_MSG_MAP(CEditorView)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_COMMAND(ID_EDIT_DELETE, OnEditDelete)
	ON_COMMAND(ID_NEW_BUTTON, OnNewButton)
	ON_COMMAND(ID_NEW_LABEL, OnNewLabel)
	ON_COMMAND(ID_NEW_TEXTEDIT, OnNewTextedit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditorView construction/destruction

CEditorView::CEditorView()
{
	m_bMoving = false;
	m_bSelecting = false;
	m_bNewObject = false;
	m_bSizing = false;
	m_stSizeType = 0;
}

CEditorView::~CEditorView()
{
}

BOOL CEditorView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CEditorView drawing

void CEditorView::OnDraw(CDC* pDC)
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	int ObjectCount = pDoc->getObjectCount();
	for (int i=0;i<ObjectCount;i++)
	{
		pDoc->getObject(i)->Paint(pDC);
		if (m_listSelected.Contain(i))
			pDoc->getObject(i)->SelectPaint(pDC);
	}
	
	if (m_bSelecting)
	{
		CRect Select = m_rectSelection;
		Select.NormalizeRect();
		pDC->MoveTo(Select.TopLeft());
		pDC->LineTo(Select.right, Select.top);
		pDC->LineTo(Select.BottomRight());
		pDC->LineTo(Select.left, Select.bottom);
		pDC->LineTo(Select.TopLeft());
	}
}

void CEditorView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	CSize sizeTotal;
	CSize sizePage;
	CSize sizeLine;

	sizeTotal.cx = sizeTotal.cy = GlobalViewSize;
	sizePage.cx = sizePage.cy = 500;
	sizeLine.cx = sizeLine.cy = 20;
	
	SetScrollSizes(MM_TEXT, sizeTotal, sizePage, sizeLine);
}

/////////////////////////////////////////////////////////////////////////////
// CEditorView diagnostics

#ifdef _DEBUG
void CEditorView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CEditorView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CEditorDoc* CEditorView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CEditorDoc)));
	return (CEditorDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CEditorView message handlers

void CEditorView::OnLButtonDown(UINT nFlags, CPoint point) 
{	
	CPoint Mouse = point + GetDeviceScrollPosition();

	SetCapture();
	if (!m_stSizeType && !m_bNewObject)
		::SetCursor(::LoadCursor(NULL, IDC_CROSS));
	if (m_stSizeType)
		SetSizeCursor(m_stSizeType);
	
	if (m_bNewObject)
	{
		m_ptMouse = Mouse;
		return;
	}

	if (SelectObject(Mouse, nFlags & MK_CONTROL)) return;

	m_bSelecting = true;
	m_rectSelection.TopLeft() = Mouse;
	m_rectSelection.BottomRight() = Mouse;
}

void CEditorView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	ReleaseCapture();

	if (m_bNewObject)
	{
		AddObject(point);
		((CMainFrame*)AfxGetMainWnd())->m_wndStatusBar.SetWindowText("Ready");
	}
	
	if (m_bMoving) m_bMoving = false;
	
	if (m_bSizing) m_bSizing = false;

	if (m_bSelecting) SelectObjects(nFlags & MK_CONTROL);

	RedrawAll();
}

void CEditorView::OnMouseMove(UINT nFlags, CPoint point) 
{
	CPoint Mouse = point + GetDeviceScrollPosition();
	CSize Offset = Mouse - m_ptMouse;
	CEditorDoc *Document = GetDocument();

	if (m_bMoving) MoveObjects(Offset);

	if (m_bSelecting) SetSelectRect(Mouse);

	if (m_bSizing) SizeObject(Mouse);

	if (!m_bNewObject) m_ptMouse = Mouse;

	if (!m_bSelecting && !m_bMoving && !m_bNewObject && !m_bSizing)
		CheckSizeType(Mouse);
}

void CEditorView::OnEditCopy() 
{
	if (!OpenClipboard()) return;
	EmptyClipboard();

	TString String = "";

	for (int i=0;i<GetDocument()->getObjectCount();i++)
	{
		if (m_listSelected.Contain(i))
			String += GetDocument()->getObject(i)->ToString();
	}

	HGLOBAL hglbCopy;

	hglbCopy = GlobalAlloc(GMEM_MOVEABLE, String.Length() + 1);

	if (!hglbCopy) return;
	char * szString = (char *)GlobalLock(hglbCopy);
	strcpy(szString, String);
	GlobalUnlock(hglbCopy);

	SetClipboardData(CF_TEXT, hglbCopy);
	CloseClipboard();
}

void CEditorView::OnEditCut() 
{
	OnEditCopy();
	OnEditDelete();
}

void CEditorView::OnEditPaste() 
{
	if (!OpenClipboard()) return;
	HGLOBAL hglbPaste = GetClipboardData(CF_TEXT);
	CloseClipboard();

	if (!hglbPaste) return;
	char *szString = (char *)GlobalLock(hglbPaste);
	TString String = szString;
	GlobalUnlock(hglbPaste);
	int OldObjectCount = GetDocument()->getObjectCount();

	int MaxBottom = 0;
	for (int i=0;i<OldObjectCount;i++)
		if (GetDocument()->getObject(i)->getRect().bottom > MaxBottom)
			MaxBottom = GetDocument()->getObject(i)->getRect().bottom;
	
	szString = new char[String.Length() + 1];
	strcpy(szString, String);
	if (!GetDocument()->CreateObjects(szString))
		GetDocument()->setObjectCount(OldObjectCount);

	delete szString;
	m_listSelected.Clear();

	int MinTop = GlobalViewSize;
	int MinLeft = GlobalViewSize;
	for (i=OldObjectCount;i<GetDocument()->getObjectCount();i++)
	{
		if (GetDocument()->getObject(i)->getRect().top < MinTop)
			MinTop = GetDocument()->getObject(i)->getRect().top;
		if (GetDocument()->getObject(i)->getRect().left < MinLeft)
			MinLeft = GetDocument()->getObject(i)->getRect().left;
		m_listSelected.Add(i);
	}

	for (i=OldObjectCount;i<GetDocument()->getObjectCount();i++)
	{
		CRect Rect = GetDocument()->getObject(i)->getRect();
		Rect.top += MaxBottom - MinTop + 20;
		Rect.bottom += MaxBottom - MinTop + 20;
		Rect.left += 20 - MinLeft;
		Rect.right += 20 - MinLeft;
		GetDocument()->getObject(i)->setRect(Rect);
	}

	RedrawAll();
}

void CEditorView::OnEditDelete() 
{
	for (int i=0;i<GetDocument()->getObjectCount();i++)
		if (m_listSelected.Contain(i))
		{
			bool ShiftElementWillDelete;
			do
			{
				ShiftElementWillDelete =
					(m_listSelected.Contain(GetDocument()->getObjectCount() - 1)) ? true : false;
				GetDocument()->DeleteObject(i);
			} while ((ShiftElementWillDelete)&&(GetDocument()->getObjectCount() > i));
		}

	m_listSelected.Clear();
	RedrawAll();
}

void CEditorView::OnNewButton() 
{
	NewObject("button");
}

void CEditorView::OnNewLabel() 
{
	NewObject("label");
}

void CEditorView::OnNewTextedit() 
{
	NewObject("textedit");
}

void CEditorView::SetSizeCursor(const int &SizeType)
{
	switch ((TSizeType)SizeType)
	{
	case stLeft:
	case stRight:
		::SetCursor(::LoadCursor(NULL, IDC_SIZEWE));
		break;
	case stTop:
	case stBottom:
		::SetCursor(::LoadCursor(NULL, IDC_SIZENS));
		break;
	case stTopLeft:
	case stBottomRight:
		::SetCursor(::LoadCursor(NULL, IDC_SIZENWSE));
		break;
	case stBottomLeft:
	case stTopRight:
		::SetCursor(::LoadCursor(NULL, IDC_SIZENESW));
		break;
	default:
		::SetCursor(::LoadCursor(NULL, IDC_ARROW));
	}
}

void CEditorView::RedrawAll(bool FillBackground)
{
	CRect ClientRect;
	GetClientRect(ClientRect);
	InvalidateRect(ClientRect, FillBackground);
}

void CEditorView::UpdateRect(const CRect& Rect)
{
	CRect UpdateRect = Rect - GetDeviceScrollPosition();
	InvalidateRect(UpdateRect, true);
}

bool CEditorView::SelectObject(const CPoint &Point, int fCtrl)
{
	int number;
	if (GetDocument()->GetObjectByPoint(number, Point))
	{
		if (!m_listSelected.Contain(number) || m_stSizeType)
		{
			if (!fCtrl || m_stSizeType)
				m_listSelected.Clear();
			m_listSelected.Add(number);
		}
		if (!m_stSizeType) m_bMoving = true;
		else m_bSizing = true;
		m_ptMouse = Point;
		RedrawAll();
		return true;
	}

	return false;
}

void CEditorView::AddObject(const CPoint& point)
{
	TObject *Object = GetDocument()->AddObject(m_strNewObjectName);
	CRect Rect(point + GetDeviceScrollPosition(), m_ptMouse);
	Rect.NormalizeRect();

	if (Rect.Width() < 20) Rect.right = Rect.left + 20;
	if (Rect.Height() < 20) Rect.bottom = Rect.top + 20;

	Object->setRect(Rect);
	if (!GetDocument()->CheckObjectOverlay(GetDocument()->getObjectCount()-1))
	{
		GetDocument()->DeleteObject(GetDocument()->getObjectCount()-1);
		::MessageBeep(0);
	}
	m_bNewObject = false;
}

void CEditorView::SelectObjects(int fCtrl)
{
	CRect Common, Select;
	int ObjectCount = GetDocument()->getObjectCount();

	Select = m_rectSelection;
	Select.NormalizeRect();

	if (!fCtrl) m_listSelected.Clear();

	for (int i=0;i<ObjectCount;i++)
	{
		Common = Select & GetDocument()->getObject(i)->getRect();
		if (!Common.IsRectEmpty())
			if (!m_listSelected.Contain(i))
				m_listSelected.Add(i);
	}

	Select.InflateRect(1,1);
	UpdateRect(Select);
	m_bSelecting = false;
}

void CEditorView::MoveObjects(CSize Offset)
{
	bool OK = true;
	CRect Rect(0,0,0,0);
	for (int i=0;i<GetDocument()->getObjectCount();i++)
	{
		if (!m_listSelected.Contain(i)) continue;

		Rect |= GetDocument()->getObject(i)->getRect();
		GetDocument()->MoveObject(i, Offset);
		Rect |= GetDocument()->getObject(i)->getRect();
	}
	
	for (i=0;i<GetDocument()->getObjectCount();i++)
		OK &= GetDocument()->CheckObjectOverlay(i);

	if (!OK)
	{
		Offset = CSize(0,0) - Offset;
		for (i=0;i<GetDocument()->getObjectCount();i++)
		{
			if (!m_listSelected.Contain(i)) continue;

			GetDocument()->MoveObject(i, Offset);
		}
	}

	if (OK) UpdateRect(Rect);
	m_listSelected.Update();
}

void CEditorView::SetSelectRect(const CPoint &Point)
{
	m_rectSelection.BottomRight() = Point;

	CRect Select;
	Select = m_rectSelection;
	Select.NormalizeRect();

	CSize Offset(abs(m_ptMouse.x - Point.x) + 1,
				abs(m_ptMouse.y - Point.y) + 1);

	Select.InflateRect(Offset);
	UpdateRect(Select);
}

void CEditorView::SizeObject(const CPoint &Point)
{
	TObject *Object = GetDocument()->getObject(m_listSelected.First());
	CRect OldRect = Object->getRect();
	CRect Rect = OldRect;
	if (m_stSizeType & stLeft) Rect.left = Point.x;
	if (m_stSizeType & stRight) Rect.right = Point.x;
	if (m_stSizeType & stTop) Rect.top = Point.y;
	if (m_stSizeType & stBottom) Rect.bottom = Point.y;
	Object->setRect(Rect);
	if (!GetDocument()->CheckObjectOverlay(m_listSelected.First()))
		Object->setRect(OldRect);
	CSize Offset(abs(m_ptMouse.x 
		- Point.x) + 4, abs(m_ptMouse.y -
		Point.y) + 4);
	Rect |= OldRect;
	Rect.InflateRect(Offset);
	UpdateRect(Rect);
	m_listSelected.Update();
}

void CEditorView::CheckSizeType(const CPoint& Point)
{
	int number;
	
	if (GetDocument()->GetObjectByPoint(number, Point))
	{
		CRect Rect = GetDocument()->getObject(number)->getRect();
		CSize Offset = Point - Rect.TopLeft();
		int SizeType = 0;
		if (Offset.cx <= 3) SizeType |= stLeft;
		if (Offset.cy <= 3) SizeType |= stTop;
		if (Offset.cx >= (Rect.Width() - 4)) SizeType |= stRight;
		if (Offset.cy >= (Rect.Height() - 4)) SizeType |= stBottom;
		SetSizeCursor(SizeType);
		m_stSizeType = SizeType;
	} else m_stSizeType = 0;
}

TObject* CEditorView::GetSelectedObject()
{
	if (m_listSelected.GetCount()!=1) return 0;
	return GetDocument()->getObject(m_listSelected.First());
}

void CEditorView::NewObject(const char *name)
{
	m_bNewObject = true;
	m_strNewObjectName = name;
	((CMainFrame*)AfxGetMainWnd())->m_wndStatusBar.SetWindowText("Draw the object with mouse");
}

TSelection::TSelection()
{
	Data.RemoveAll();
}

void TSelection::Clear()
{
	Data.RemoveAll();
	Update();
}

void TSelection::Add(int n)
{
	Data.AddHead(n);
	Update();
}

bool TSelection::Contain(int n)
{
	return Data.Find(n) != 0;
}

int TSelection::First()
{
	return Data.GetHead();
}

int TSelection::GetCount()
{
	return Data.GetCount();
}

void TSelection::Update()
{
	if (Data.GetCount()==1)
	{
		((CMainFrame*)AfxGetMainWnd())->m_wndDlgBar.UpdateInfo(
			((CEditorDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->getObject(Data.GetHead()));
	} else
	{
		((CMainFrame*)AfxGetMainWnd())->m_wndDlgBar.UpdateInfo(NULL);
	}
}
