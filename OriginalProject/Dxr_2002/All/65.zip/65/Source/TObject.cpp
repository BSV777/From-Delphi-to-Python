#include "stdafx.h"
#include "TObject.h"
#include "String.h"
#include "TVariant.h"

// Class TObject 

TObject::TObject()
{
	Init();
}

TObject::~TObject()
{
	for (int i=0;i<FPropertyCount;i++)
		delete FProperty[i];
	delete FProperty;
}

TObject& TObject::operator=(const TObject &right)
{
	setPropertyCount(right.getPropertyCount());
	for (int i=0;i<getPropertyCount();i++)
		setProperty(i, right.getProperty(i)->getValue());
	return *this;
}

void TObject::Init()
{
	FPropertyCount = prMinPropertyCount;
	FProperty = new TProperty* [FPropertyCount];
	FProperty[prLeft] = new TProperty("left", (TVariant)(int)0);
	FProperty[prTop] = new TProperty("top", (TVariant)(int)0);
	FProperty[prWidth] = new TProperty("width", (TVariant)(int)32);
	FProperty[prHeight] = new TProperty("height", (TVariant)(int)32);
}

const int TObject::getPropertyCount() const
{
	return FPropertyCount;
}

void TObject::setPropertyCount(int value)
{
	TProperty **Temp = new TProperty* [value];
	for (int i=value;i<FPropertyCount;i++) delete FProperty[i];
	int common = (FPropertyCount > value) ? value : FPropertyCount;
	for (i=0;i<common;i++) Temp[i] = FProperty[i];
	for (i=FPropertyCount;i<value;i++) Temp[i] = 0;
	delete FProperty;
	FProperty = Temp;
	FPropertyCount = value;
}

void TObject::setProperty(const char *name, const char *value)
{
	for (int i=0;i<FPropertyCount;i++)
		if (getProperty(i)->getName() == (TString)name)
		{
			TVariant Variant = getProperty(i)->getValue();
			Variant = value;
			setProperty(i, Variant);
		}
}

TProperty* TObject::getProperty(const char *name) const
{
	for (int i=0;i<FPropertyCount;i++)
		if (FProperty[i]->getName() == (TString)name)
			return FProperty[i];
	return 0;
}

CRect TObject::getRect()
{
	return CRect((int)FProperty[prLeft]->getValue(), (int)FProperty[prTop]->getValue(), (int)FProperty[prLeft]->getValue() + (int)FProperty[prWidth]->getValue(),
			(int)FProperty[prTop]->getValue() + (int)FProperty[prHeight]->getValue());
}

void TObject::setProperty(int n, const TVariant& value)
{
	FProperty[n]->setValue(value);
}

void TObject::SelectPaint(CDC *dc)
{
	CRect SelfRect = getRect();
	if (!dc->RectVisible(SelfRect)) return;

	CPen penBlack;
	penBlack.CreatePen(PS_SOLID, 5, RGB(0, 0, 0));
	CPen* pOldPen = dc->SelectObject(&penBlack);

	int n=0;

	for (int i=SelfRect.left + 3;i<=(SelfRect.right-3);i+=(SelfRect.Width()-6)/2)
		for (int j=SelfRect.top + 3;j<=(SelfRect.bottom-3);j+=(SelfRect.Height()-6)/2)
			if (++n!=5) dc->Rectangle(CRect(i-1,j-1,i+1,j+1));
	
	// put back the old objects
	dc->SelectObject(pOldPen);	
}

void TObject::setRect(const CRect &Rect)
{
	setProperty(prLeft, Rect.left);
	setProperty(prTop, Rect.top);
	setProperty(prWidth, Rect.Width());
	setProperty(prHeight, Rect.Height());
}

TString TObject::ToString()
{
	TString String = "<";
	String += getName();
	String += (TString)" ";
	for (int j=0;j<getPropertyCount();j++)
	{
		if (j) String += (TString)"; ";
		String += (TString)getProperty(j)->getName();
		String += (TString)"=\"";
		String += (TString)getProperty(j)->getValue();
		String += (TString)"\"";
	}
	String += (TString)">\n";
	return String;
}
