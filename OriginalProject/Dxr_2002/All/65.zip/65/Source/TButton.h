#ifndef TButton_h
#define TButton_h 1

#include "TObject.h"
#include "TString.h"	// Added by ClassView

class TButton : public TObject
{
public:
enum {prCaption = prMinPropertyCount};
	virtual TString getName();
	TButton();
	~TButton();

	void Paint(CDC *dc);

	TString ToHTML();
};

#endif
