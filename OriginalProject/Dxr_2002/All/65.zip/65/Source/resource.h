//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Editor.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_OBJECTINSPECTOR             128
#define IDR_EDITORTYPE                  129
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_EDIT3                       1002
#define IDC_EDIT4                       1003
#define IDC_EDIT5                       1005
#define IDC_EDIT6                       1006
#define ID_FILE_EXPORT                  32771
#define ID_EDIT_DELETE                  32772
#define ID_ADD_BUTTON                   32776
#define ID_ADD_LABEL                    32777
#define ID_ADD_TEXTEDIT                 32778
#define ID_NEW_BUTTON                   32779
#define ID_NEW_TEXTEDIT                 32780
#define ID_NEW_LABEL                    32781

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
