#include "stdafx.h"
#include "TVariant.h"
#include <String.h>
#include <StdLib.h>
#include "TString.h"


// Class Variant 

TVariant::TVariant()
{
	FisNumber = true;
	nData = 0;
}

TVariant::TVariant(const TVariant &right)
{
	(*this) = right;
}

TVariant::~TVariant()
{
	if (!FisNumber&&sData) delete sData;
}

TVariant & TVariant::operator=(const TVariant &right)
{
	if (FisNumber = right.FisNumber) nData = (int)right;
	else sData = strdup((const char *)right);

	return *this;
}

TVariant::operator int() const
{
	if (!FisNumber) return atoi(sData);
	return nData;
}

TVariant::operator const char *() const
{
	if (FisNumber)
		return 0;
	return sData;
}

TVariant& TVariant::operator =(const char *string)
{
	if (FisNumber) nData = atoi(string);
	else sData = strdup(string);
	return *this;
}

TVariant::TVariant(const char *string)
{
	FisNumber = false;
	(*this) = string;
}

TVariant::TVariant(int number)
{
	FisNumber = true;
	(*this) = number;
}

TVariant & TVariant::operator=(const int right)
{
	if (FisNumber)
		nData = right;
	else
	{
		TString String = right;
		sData = strdup(String);
	}

	return *this;
}

bool TVariant::isNumber() const
{
	return FisNumber;
}
