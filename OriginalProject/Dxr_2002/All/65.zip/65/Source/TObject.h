#ifndef TObject_h
#define TObject_h 1

#include "TProperty.h"
#include "TString.h"	// Added by ClassView


//	��� ������.
class TObject 
{
public:
enum {prLeft, prTop, prWidth, prHeight, prMinPropertyCount};

	TObject();
	~TObject();
	TObject& operator=(const TObject &right);
	
	TString ToString();
	void SelectPaint(CDC *dc);
	CRect getRect();
	

	virtual void Paint (CDC *dc) = 0;
	virtual TString getName() = 0;
	virtual TString ToHTML () = 0;
	virtual void setProperty(int n, const TVariant& value);

	const int getPropertyCount() const;
	void setPropertyCount(int value);

	void setRect(const CRect& Rect);
	TProperty* getProperty(const char *name) const;
	void setProperty(const char *name, const char *value);
	TProperty* getProperty(int n) const;

protected:

	void Init();
	TProperty **FProperty;
  
private:

	int FPropertyCount;
};

inline TProperty* TObject::getProperty(int n) const
{
  return FProperty[n];
}


//DEL inline const int TObject::getLeft() const
//DEL {
//DEL   return FProperty[prLeft]->getValue();
//DEL }

//DEL inline void TObject::setLeft(int value)
//DEL {
//DEL   FProperty[prLeft]->setValue(value);
//DEL }
//DEL inline const int TObject::getTop() const
//DEL {
//DEL   return FProperty[prTop]->getValue();
//DEL }

//DEL inline void TObject::setTop(int value)
//DEL {
//DEL   FProperty[prTop]->setValue(value);
//DEL }
//DEL inline const int TObject::getWidth() const
//DEL {
//DEL   return FProperty[prWidth]->getValue();
//DEL }

//DEL inline void TObject::setWidth(int value)
//DEL {
//DEL   FProperty[prWidth]->setValue(value);
//DEL }
//DEL inline const int TObject::getHeight() const
//DEL {
//DEL   return FProperty[prHeight]->getValue();
//DEL }

//DEL inline void TObject::setHeight(int value)
//DEL {
//DEL   FProperty[prHeight]->setValue(value);
//DEL }

#endif
