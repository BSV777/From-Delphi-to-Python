#include "stdafx.h"
#include "TLabel.h"

// Class TLabel 

TLabel::TLabel()
:TObject()
{
	setPropertyCount(getPropertyCount() + 1);
	FProperty[getPropertyCount() - 1] 
		= new TProperty("text", (TVariant)(char *)"Text");
}

TLabel::~TLabel()
{
}

void TLabel::Paint (CDC *dc)
{
	CRect MyRect = getRect();
	
	if (!dc->RectVisible(MyRect)) return;

	CBrush brush(RGB(255, 255, 255));
	CBrush* pOldBrush = dc->SelectObject(&brush);

	CPen penWhite, penBlack;
	penBlack.CreatePen(PS_SOLID, 1, RGB(0, 0, 0));
	penWhite.CreatePen(PS_SOLID, 1, RGB(255, 255, 255));

	CPen* pOldPen = dc->SelectObject(&penWhite);
	dc->Rectangle(MyRect);

	dc->SelectObject(&penBlack);
	dc->SetBkColor(RGB(255, 255, 255));
	dc->DrawText((const char *)getProperty(prText)->getValue(), MyRect, DT_SINGLELINE);

	dc->SelectObject(pOldPen);	
	dc->SelectObject(pOldBrush);
}

TString TLabel::ToHTML ()
{
	TString s = "<div style='width=";
	s += (TString)getProperty(prWidth)->getValue();
	s += (TString)";height=";
	s += (TString)getProperty(prHeight)->getValue();
	s += (TString)"'>";
	s += (TString)getProperty(prText)->getValue();
	s += (TString)"</div>";
	return s;
}

TString TLabel::getName()
{
	return "label";
}
