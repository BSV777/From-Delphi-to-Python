#include "stdafx.h"
#include "THTMLDocument.h"
#include <stdio.h>

// Class THTMLDocument 

THTMLDocument::THTMLDocument(TDocument &source)
	:TDocument(source)
{
}

THTMLDocument::~THTMLDocument()
{
	if (Table) for (int i=0;i<Height;i++) delete Table[i];
	delete Table, CellWidths, CellHeights;
}

bool THTMLDocument::ExportToFile(const char *Filename)
{
	FILE *outfile;
	TString String = "<html>\n<head>\n<title>��� �������� �������������� �� ����� \"";
	String += TDocument::getFilename();
	String += "\"</title>\n</head>\n<body>\n<form>\n";

	if (!(outfile = fopen(Filename,"wt"))) return false;
	fputs(String, outfile);

	GenerateTable();
	CheckForColSpanOrRowSpan();

	WriteTable(outfile);
	fputs("</form>\n</body>\n</html>", outfile);
	fclose(outfile);
	return true;
}

THTMLDocument::THTMLDocument()
	:TDocument()
{
}

int* THTMLDocument::CreateArray(int what, int& Count, int& MinValue)
{
	Sort((what) ? byTop : byLeft);

	int *Array = new int[FObjectCount];
	int DifferentValuesCount = 0;
	int LastValue = -1, Max = 0;

	for (int i=0;i<FObjectCount;i++)
	{
		if (GetValueByObject(FObjects[i], what) != LastValue)
		{
			if (i) Array[DifferentValuesCount-1] = GetValueByObject(FObjects[i], what) - LastValue;
			DifferentValuesCount++;
		}
		int temp = (what) ? FObjects[i]->getRect().bottom : FObjects[i]->getRect().right;
		if (temp > Max) Max = temp;
		LastValue = GetValueByObject(FObjects[i], what);
	}

	Array[DifferentValuesCount-1] = Max - LastValue;

	Count = DifferentValuesCount;
	Array = (int*)realloc(Array, sizeof(int)*Count);
	MinValue = GetValueByObject(FObjects[0], what);
	return Array;
}

int THTMLDocument::GetValueByObject(TObject *Object, int what)
{
	return (what) ? Object->getRect().top : Object->getRect().left;
}

void THTMLDocument::WriteTable(FILE *outfile)
{
	TString String = "<table border=0 cellpadding=0 cellspacing=0>\n";
	String += "<tr>\n<td height=1 width=1></td>\n";

	for (int j=0;j<Width;j++)
	{
		String += "<td width=";
		String += (TString)CellWidths[j];
		String += "></td>\n";
	}
	String += "</tr>\n";
	fputs(String, outfile);

	for (int i=0;i<Height;i++)
	{
		String = "<tr valign=top height=";
		String += (TString)CellHeights[i];
		String += ">\n";
		String += "<td height=";
		String += (TString)CellHeights[i];
		String += "></td>\n";

		for (int j=0;j<Width;j++)
		{
			if (Table[j][i].N < 0) continue;

			String += "<td";
			if (Table[j][i].ColSpan)
			{
				String += " colspan=";
				String += (TString)(Table[j][i].ColSpan + 1);
			}
			if (Table[j][i].RowSpan)
			{
				String += " rowspan=";
				String += (TString)(Table[j][i].RowSpan + 1);
			}
			String += ">";
			if (Table[j][i].N)
				String += FObjects[Table[j][i].N-1]->ToHTML();
			String += "</td>\n";
		}
		String += "</tr>\n";
		fputs(String, outfile);
	}

	fputs("</table>\n", outfile);
}

void THTMLDocument::GenerateTable()
{
	int MinX, MinY;
	CellHeights = CreateArray(caHeights, Height, MinY);
	CellWidths = CreateArray(caWidths, Width, MinX);

	Table = new TTable* [Width];
	int XPos = MinX;
	int YPos;
	int count = 0;
	for (int i=0;i<Width;i++)
	{
		Table[i] = new TTable[Height];
		YPos = MinY;
		for (int j=0;j<Height;j++)
		{
			if ((FObjects[count]->getRect().top==YPos)&&(FObjects[count]->getRect().left==XPos))
				Table[i][j].N = count++ + 1;
			if (count>=FObjectCount) break;
			YPos += CellHeights[j];
		}
		if (count>=FObjectCount) break;
		XPos += CellWidths[i];
	}
}

void THTMLDocument::CheckForColSpanOrRowSpan()
{
	int	RowSpan, ColSpan, CellHeight, CellWidth;

	for (int i=0;i<Height;i++)
		for (int j=0;j<Width;j++)
		{
			RowSpan = 0;
			ColSpan = 0;
			if (Table[j][i].N > 0)
			{
				CellHeight = CellHeights[i];
				CellWidth = CellWidths[j];
				bool OK = false;

				while (!OK)
				{
					OK = true;
					if (FObjects[Table[j][i].N-1]->getRect().Width() > CellWidth)
					{
						ColSpan++;
						CellWidth += CellWidths[j+ColSpan];
						OK = false;
					}
					if (FObjects[Table[j][i].N-1]->getRect().Height() > CellHeight)
					{
						RowSpan++;
						CellHeight += CellHeights[i+RowSpan];
						OK = false;
					}
				}

			}
			if (Table[j][i].N == 0)
			{
				bool OKCol = true, OKRow = true;
				while (OKCol||OKRow)
				{
					if (OKRow)
					{
						for (int k=i; k<=(i+RowSpan); k++)
							if (((j+ColSpan+1)>=Width)||(Table[j+ColSpan+1][k].N!=0))
								OKRow = false;
						if (OKRow) ColSpan++;
					}
					if (OKCol)
					{
						for (int k=j; k<=(j+ColSpan); k++)
							if (((i+RowSpan+1)>=Height)||(Table[k][i+RowSpan+1].N!=0))
								OKCol = false;
						if (OKCol) RowSpan++;
					}
				}

			}

			for (int k=i; k<=(i+RowSpan);k++)
				for (int m=j; m<=(j+ColSpan);m++)
					if ((k!=i) || (m!=j))
						Table[m][k].N = -1;
			Table[j][i].ColSpan = ColSpan;
			Table[j][i].RowSpan = RowSpan;
		}
}
