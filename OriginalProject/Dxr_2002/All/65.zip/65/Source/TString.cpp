#include "stdafx.h"
#include "TString.h"
#include <String.h>
#include <StdLib.h>
#include "TVariant.h"

// Class String 

TString::TString()
{
	Data = 0;
}

TString::TString(const TString &right)
{
	Data = strdup(right.Data);
}

TString::~TString()
{
	delete Data;
}

TString & TString::operator=(const TString &right)
{
	if (Data) delete Data;
	Data = strdup(right.Data);
	return *this;
}

int TString::operator==(const TString &right) const
{
	return !strcmp(Data, right.Data);
}

int TString::operator!=(const TString &right) const
{
	return strcmp(Data, right.Data);
}

TString& TString::operator +=(const TString &right)
{
	int MyLength = strlen(Data),
		AllLength = MyLength + strlen(right.Data);
	char *NewString = new char[AllLength+1];

	strcpy(NewString, Data);
	strcpy(NewString + MyLength, right.Data);

	delete Data;
	Data = NewString;

	return *this;
}

TString::operator int() const
{
	return atoi(Data);
}

TString::operator const char *() const
{
	return Data;
}

TString& TString::operator =(const char *string)
{
	if (Data) delete Data;
	Data = strdup(string);
	return *this;
}

TString::TString(const char *string)
{
	Data = strdup(string);
}

TString::TString(const int number)
{
	char buffer[11];
	itoa(number, buffer, 10);
	Data = strdup(buffer);
}

TString::TString(const TVariant &right)
{
	Data = 0;
	if (right.isNumber())
		(*this) = (int)right;
	else (*this) = (const char *)right;
}

int TString::Length()
{
	return strlen(Data);
}

void TString::ToLowerCase()
{
	_strlwr(Data);
}

TString ReadWord(char *&source, bool ShiftPosition)
{
	bool isQuote = false;
	TString String = "";
	char *oldsource = source;

	while ((*source==' ')||(*source==';')) source++;
	
	while (strlen(source))
	{
		if (*source=='"')
		{
			isQuote = !isQuote;
			source++;
			continue;
		}
		
		if (*source=='=')
		{
			if (String.Length()) break;
			else
			{
				String = "=";
				source++;
				if (!ShiftPosition) source = oldsource;
				return String;
			}
		}
		if (((*source==' ')||(*source==';'))&&(!isQuote))
			break;
		String += *source;
		source++;
	}

	if (!ShiftPosition) source = oldsource;
	return String;
}

TString::TString(const char c)
{
	Data = new char[2];
	Data[0] = c;
	Data[1] = 0;
}

int GetLengthOfParser(char *&str)
{
	bool isQuote = false;

	while ((*str)&&(*str!='<')) str++;

	char * source = str;
	
	while (strlen(source))
	{
		if (*source=='"')
			isQuote = !isQuote;
		
		if ((*source=='>')&&!isQuote)
			return source - str;

		source++;
	}

	return 0;
}
