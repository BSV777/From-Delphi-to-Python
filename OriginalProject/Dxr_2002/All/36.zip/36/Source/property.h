//---------------------------------------------------------------------------
#ifndef propertyH
#define propertyH
#include <vector>
#include <stdarg.h>
using namespace std;
//---------------------------------------------------------------------------
class Property
{
 public:
  Property(){};
  Property(AnsiString name, int type ,int selectedIndex,int size,...);
  Property(Property* p);
//  Property(int i);
  int selIndex;
  AnsiString pName;
  int pType;
  vector<AnsiString> pValues;
	AnsiString __fastcall GetValue(void);
	void __fastcall SetValue(AnsiString);
	AnsiString __fastcall GetItem(unsigned int idx);
    int __fastcall Size();	
};
//---------------------------------------------------------------------------
class PropertyList
{
 private:
  vector<Property> vProperties;
 public:
  PropertyList(){}; 
  PropertyList(PropertyList& p);
  int __fastcall Add(Property p);
  AnsiString __fastcall GetPropertyValue(AnsiString name);
  AnsiString __fastcall GetPropertyValue(unsigned int Idx);  
  void __fastcall SetPropertyValue(AnsiString name,AnsiString value);
  void __fastcall SetPropertyValue(unsigned int Idx,AnsiString value);
  int __fastcall GetPropertyIdxByName(AnsiString name);
  AnsiString __fastcall GetPropertyNameByIdx(unsigned int pIdx);  
  int __fastcall GetPropertyType(AnsiString name);
  int __fastcall GetPropertyType(unsigned int Idx);
  int __fastcall ListSize();
  int __fastcall PropertySize(unsigned int pIdx);  
  AnsiString __fastcall GetPropertyItem(unsigned int pIdx, unsigned int iIdx);
  int __fastcall GetPropertySelected(unsigned int pIdx);  
};
#endif
