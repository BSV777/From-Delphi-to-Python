//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "SDIMain.h"
#include "About.h"
#include "inspect.h"
#include "winlist.h"
//---------------------------------------------------------------------
#pragma resource "*.dfm"
TfMain *fMain;
int ObjType=0;
//---------------------------------------------------------------------
__fastcall TfMain::TfMain(TComponent *AOwner)
		: TForm(AOwner)
{
 CurrObj.Wnd=-1000;
}
//---------------------------------------------------------------------

void __fastcall TfMain::actNewProjectExecute(TObject *Sender)
{
/* if(!NewProject())
  {
   Application->MessageBox("�� ���� ������� ������!","������!",
							MB_OK|MB_ICONSTOP);
  }*/
}
//---------------------------------------------------------------------------

void __fastcall TfMain::FileOpen1Execute(TObject *Sender)
{
 dlgOpen->Filter="Dfn files (*.dfn)|*.dfn|All Files (*.*)|*.*";
 dlgOpen->FilterIndex=0;
 dlgOpen->DefaultExt="dfn";
 if(dlgOpen->Execute())
  {
   OpenFromFile(dlgOpen->FileName);
  }
}
//---------------------------------------------------------------------------
void __fastcall TfMain::FileSave1Execute(TObject *Sender)
{
 if(vWindows.size()<=0) return;
 SaveWindow(CurrObj.Wnd);
}
//---------------------------------------------------------------------------
void __fastcall TfMain::FileSaveAs1Execute(TObject *Sender)
{
 if(vWindows.size()<=0) return;
 AnsiString filename("");
 dlgSave->Filter="Dfn files (*.dfn)|*.dfn|All Files (*.*)|*.*";
 dlgSave->FilterIndex=0;
 dlgSave->DefaultExt="dfn";
// dlgSave->FileName=AnsiString(vWindows[CurrObj.Wnd]->pList->GetPropertyValue("NAME"));
 dlgSave->FileName=AnsiString(vWindows[CurrObj.Wnd]->wName);
 if(dlgSave->Execute())
  {
     filename = dlgSave->FileName;
  }
 else return;
 if(FileExists(filename))
  {
   if(Application->MessageBox("���� ��� ����������!\n������������?","��������!",
                           MB_YESNO|MB_ICONQUESTION)==ID_NO)
   return;
  }
// ShowMessage(filename);
  vWindows[CurrObj.Wnd]->SaveToFile(filename);
}
//---------------------------------------------------------------------------
void __fastcall TfMain::FileExit1Execute(TObject *Sender)
{
 Close();
}
//---------------------------------------------------------------------------

void __fastcall TfMain::HelpAbout1Execute(TObject *Sender)
{
  AboutBox->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TfMain::actNewWindowExecute(TObject *Sender)
{
// if(!project.CreateNewWindow(true)) return false;
 fMain->spbArrow->Down=true;
 ObjType=0; 
 CreateNewWindow();
}
//---------------------------------------------------------------------------
void __fastcall TfMain::actArrayExecute(TObject *Sender)
{
 ObjType=0;
}
//---------------------------------------------------------------------------
void __fastcall TfMain::actNewButtonExecute(TObject *Sender)
{
 ObjType=1;
}
//---------------------------------------------------------------------------
void __fastcall TfMain::actNewStaticExecute(TObject *Sender)
{
 ObjType=2;
}
//---------------------------------------------------------------------------
void __fastcall TfMain::actNewEditTextExecute(TObject *Sender)
{
 ObjType=3;
}
//---------------------------------------------------------------------------

void __fastcall TfMain::SaveProjectAs1Click(TObject *Sender)
{
 //EditForm->SaveProjectAs(Sender);
 //������������� ������
/* SaveDialog->Filter = "������ (*.tpr)|*.tpr|";
 SaveDialog->DefaultExt = "tpr";
 SaveDialog->FileName="";
 if(SaveDialog->Execute())
  {
   if(FileExists(SaveDialog->FileName))
	{
	 int res=MessageDlg(SaveDialog->FileName+"\n���� ����� �����������!",
			 mtConfirmation,TMsgDlgButtons()<<mbYes<<mbCancel,0);
	 switch(res)
	  {
	   case mrCancel:
       return;
      }
    }
   BreakFullPath(SaveDialog->FileName,project.projectPath,project.projectName);
   if(!project.RewriteProjectFile())
    {
     Application->MessageBox("�� ���� ��������� ���� �������","������!",MB_OK|MB_ICONSTOP);
     return;
    }
//   EditForm->SaveAllFiles(Sender);
//   project.SaveAllWindows();
   Caption="TasmEdit: "+project.projectName;
   DisplayProjectStruct();
  }*/
}
//---------------------------------------------------------------------------

void __fastcall TfMain::Context1Click(TObject *Sender)
{
 Application->HelpCommand(HELP_CONTENTS,0);
}
//---------------------------------------------------------------------------

void __fastcall TfMain::actDeleteWindowExecute(TObject *Sender)
{
 if(vWindows.size()==0) return;

 DeleteWindow(CurrObj.Wnd);
 if(vWindows.size()==0)
  {
   fObjInsp->cbObjects->Clear();
   fObjInsp->sgPropertys->RowCount=0;
   fObjInsp->sgPropertys->ColCount=2;   
   fObjInsp->sgPropertys->Cells[0][0]="";
   fObjInsp->sgPropertys->Cells[1][0]="";
   CurrObj.Wnd=-1000;
   CurrObj.Idx=-1000;
   CurrObj.Type="";         
   return;
  }
 else 
  vWindows[0]->WinMouseDown( NULL,mbLeft,TShiftState(),0,0);
}
//---------------------------------------------------------------------------
void __fastcall TfMain::FormCreate(TObject *Sender)
{
  RECT rwa;
  ::SystemParametersInfo(SPI_GETWORKAREA, 0, &rwa, 0);
  SetBounds(rwa.left, rwa.top, rwa.right - rwa.left, Height);
}
//---------------------------------------------------------------------------
void __fastcall TfMain::FormCloseQuery(TObject *Sender, bool &CanClose)
{
 if(vWindows.size()==0)
  {
   CanClose=true;
   return;
  }
 while(vWindows.size()>0)
  {
   if(DeleteWindow(0)==false)
	{
	 CanClose=false;
	 break;
	}
  }
 if(vWindows.size()==0)
  {
   fObjInsp->cbObjects->Clear();
   fObjInsp->sgPropertys->RowCount=0;
   fObjInsp->sgPropertys->ColCount=2;
   fObjInsp->sgPropertys->Cells[0][0]="";
   fObjInsp->sgPropertys->Cells[1][0]="";
   CurrObj.Wnd=-1000;
   CurrObj.Idx=-1000;
   CurrObj.Type="";
   return;
  }
 else
  vWindows[vWindows.size()-1]->WinMouseDown( NULL,mbLeft,TShiftState(),0,0);
}
//---------------------------------------------------------------------------

void __fastcall TfMain::tbRunClick(TObject *Sender)
{
  if(!vWindows.size()) return;
  dlgSave->DefaultExt="*.html";
  dlgSave->Filter="HTML-����� (*.html)|*.html";
  try
   {
	if(dlgSave->Execute())
	 {
	  fObjInsp->Enabled=false;
	  fMain->spbNewButton->Enabled=false;
	  fMain->spbNewStatic->Enabled=false;
	  fMain->spbNewEditText->Enabled=false;
	  vWindows[CurrObj.Wnd]->SaveToHtmlFile(dlgSave->FileName);
	  fObjInsp->Enabled=true;
	  fMain->spbNewButton->Enabled=true;
	  fMain->spbNewStatic->Enabled=true;
	  fMain->spbNewEditText->Enabled=true;
	 }
   }	 
  catch(...)
   {
	Application->MessageBox("������ ���������������!","��������!",
							 MB_YESNO|MB_ICONSTOP);
	fObjInsp->Enabled=true;
	fMain->spbNewButton->Enabled=true;
	fMain->spbNewStatic->Enabled=true;
	fMain->spbNewEditText->Enabled=true;
   }	 
}
//---------------------------------------------------------------------------
void __fastcall TfMain::FormShow(TObject *Sender)
{
 fObjInsp->Show();
}
//---------------------------------------------------------------------------

bool __fastcall TfMain::CreateNewWindow()
{
 fObjInsp->controlExit();
 fObjInsp->DeleteControls();
 int id=vWindows.size();
 Window *wnd;
 wnd=new Window(id);
 if(!wnd) return false;
 vWindows.push_back(wnd);

 wnd->WinMouseDown( NULL,mbLeft,TShiftState(),0,0);
 return true;
}
//---------------------------------------------------------------------------
void __fastcall TfMain::ClearSelect()
{
 #define Win fMain->vWindows[CurrObj.Wnd]
 if(CurrObj.Type=="BUTTON")
 {
  Win->vButton[CurrObj.Idx]->Draw();
 }
 if(CurrObj.Type=="LABEL")
 {
  Win->vLabel[CurrObj.Idx]->Draw();
 }
 if(CurrObj.Type=="EDIT")
 {
  Win->vEdit[CurrObj.Idx]->Draw();
 }
 #undef Win
}
//---------------------------------------------------------------------------
bool __fastcall TfMain::OpenFromFile(AnsiString fname)
{
 fObjInsp->controlExit();
 int id=vWindows.size();
 Window *wnd;
 wnd=new Window(id,false,fname);
 if(!wnd) return false;
 vWindows.push_back(wnd);
 wnd->WinMouseDown( NULL,mbLeft,TShiftState(),0,0);
 return true;
}
//---------------------------------------------------------------------------
bool __fastcall TfMain::GetString(FILE* stream,AnsiString& str)
{
 int ch;
 str="<";
 while((ch=fgetc(stream))!=EOF&&ch!='<');
 while((ch=fgetc(stream))!=EOF&&ch!='>')
  {
   str+=(char(ch));
   if(str[str.Length()]=='\n')
    str=str.SubString(1,str.Length()-1);
  }
 str+=">";
 if(ch==EOF) return false;
 return true;
}
//---------------------------------------------------------------------------
bool __fastcall TfMain::CreateNewWindow(AnsiString str)
{
 int left=250;
 int top=130;
 int width=450;
 int height=350;
 AnsiString caption=350;
// ShowMessage(str);
 AnsiString pname, pvalue;
 int i=2;
 while(i<str.Length() && str[i]==' ') i++;
 while(i<str.Length())
  {
   pname=pvalue="";
   while(i<str.Length() && str[i]!='=')
	pname+=str[i++];
   i++;
   while(i<str.Length() && str[i]!='\"') i++;
   i++;
   while(i<str.Length() && str[i]!='\"')
	pvalue+=str[i++];
   while(i<str.Length() && str[i]!=';') i++;
   i++;
   pname=pname.Trim();
   pvalue=pvalue.Trim();
//   ShowMessage(pname+"="+pvalue);
   if(pname.UpperCase()=="LEFT")
    {
     try {left=StrToInt(pvalue);}
     catch(...) {left=250;}
     continue;
    }
   if(pname.UpperCase()=="TOP")
    {
     try {top=StrToInt(pvalue);}
     catch(...) {top=130;}
     continue;
    }
   if(pname.UpperCase()=="HEIGHT")
	{
     try {height=StrToInt(pvalue);}
     catch(...) {height=350;}
     continue;
    }
   if(pname.UpperCase()=="WIDTH")
    {
     try {width=StrToInt(pvalue);}
     catch(...) {width=450;}
     continue;
	}
   if(pname.UpperCase()=="CAPTION")
    {
     try {caption=pvalue;}
     catch(...) {caption="";}
	 continue;
    }
  }
 PropertyList* pList;
 pList=new PropertyList();
 pList->Add(*(new Property("Caption",1,0,1,caption.c_str())));
 pList->Add(*(new Property("Height",2,0,1,IntToStr(height).c_str())));
 pList->Add(*(new Property("Left",2,0,1,IntToStr(left).c_str())));
 pList->Add(*(new Property("Name",1,0,1,AnsiString("Window"+IntToStr(Window::wCnt+1)).c_str())));
 pList->Add(*(new Property("Top",2,0,1,IntToStr(top).c_str())));
 pList->Add(*(new Property("Width",2,0,1,IntToStr(width).c_str())));
 pList->Add(*(new Property("Window Type",3,0,3,"Popup","Overlapped","Child")));

 fObjInsp->controlExit();
 int id=vWindows.size();
 Window *wnd;
 wnd=new Window(id,pList);
 if(pList) delete pList;
 if(!wnd)
  {
   return false;
  }
 vWindows.push_back(wnd);
 wnd->WinMouseDown( NULL,mbLeft,TShiftState(),0,0);
 return true;
}
//---------------------------------------------------------------------------
void __fastcall TfMain::SaveWindow(int wnum)
{
 AnsiString filename("");
 filename=vWindows[wnum]->GetFileName();
 if(filename.IsEmpty())
  {
   dlgSave->Filter="Dfn files (*.dfn)|*.dfn|All Files (*.*)|*.*";
   dlgSave->FilterIndex=0;
   dlgSave->DefaultExt="dfn";
//   dlgSave->FileName=AnsiString(vWindows[wnum]->pList->GetPropertyValue("NAME"));
   dlgSave->FileName=AnsiString(vWindows[wnum]->wName);
   if(dlgSave->Execute())
	{
	 filename = dlgSave->FileName;
	}
   else return;
   if(FileExists(filename))
    {
	 if(Application->MessageBox("���� ��� ����������!\n������������?","��������!",
							 MB_YESNO|MB_ICONQUESTION)==ID_NO)
	 return;
	}
  }
  vWindows[wnum]->SaveToFile(filename);
}
//---------------------------------------------------------------------------
void __fastcall TfMain::actSaveAllExecute(TObject *Sender)
{
 if(vWindows.size()==0) return;
 for(unsigned int i=0; i<vWindows.size(); i++)
  {
   SaveWindow(i);
  }
}
//---------------------------------------------------------------------------
bool __fastcall TfMain::DeleteWindow(int wnum)
{
 AnsiString msg("");
 int res=0;
 if(vWindows[wnum]->Modified)
  {
   msg="���� "+vWindows[wnum]->wName+" ���� ��������!\n��������� ���������?";
   res=Application->MessageBox(msg.c_str(),"��������!",
						   MB_YESNOCANCEL|MB_ICONQUESTION);
   if(res==ID_YES)
	{
	 SaveWindow(wnum);
	}
   else
    if(res==ID_CANCEL) return false;   
  } 
 delete vWindows[wnum];
 for(unsigned int i=wnum; i<vWindows.size(); i++)
  {
   vWindows[i]->wForm->Tag--;
   vWindows[i]->Id--;
  }
 vWindows.erase(&vWindows[wnum]);
 fObjInsp->DeleteControls();
 return true;
}
//---------------------------------------------------------------------------

void __fastcall TfMain::N4Click(TObject *Sender)
{
 if(!fObjInsp->Visible) fObjInsp->Show();
}
//---------------------------------------------------------------------------
void __fastcall TfMain::actCloseAllExecute(TObject *Sender)
{
 if(vWindows.size()==0) return;
 while(vWindows.size()>0)
  {
   if(DeleteWindow(0)==false) break;
  }
 if(vWindows.size()==0)
  {
   fObjInsp->cbObjects->Clear();
   fObjInsp->sgPropertys->RowCount=0;
   fObjInsp->sgPropertys->ColCount=2;
   fObjInsp->sgPropertys->Cells[0][0]="";
   fObjInsp->sgPropertys->Cells[1][0]="";
   CurrObj.Wnd=-1000;
   CurrObj.Idx=-1000;
   CurrObj.Type="";
   return;
  }
 else
  vWindows[vWindows.size()-1]->WinMouseDown( NULL,mbLeft,TShiftState(),0,0);
}
//---------------------------------------------------------------------------

void __fastcall TfMain::actWndListExecute(TObject *Sender)
{
 if(fWinList->ShowModal()!=mrOk) return;
 if(fWinList->wNum<0) return;
 if(!vWindows[fWinList->wNum]->wForm->Visible)
  vWindows[fWinList->wNum]->wForm->Show();
 vWindows[fWinList->wNum]->WinMouseDown(NULL,mbLeft,TShiftState(),0,0);
}
//---------------------------------------------------------------------------

