//---------------------------------------------------------------------------
#ifndef windowH
#define windowH
#include "button.h"
#include "property.h"
#include "label.h"
#include "edit.h"
#include "HtmlObj.h"
#include <vector>
using namespace std;
//---------------------------------------------------------------------------
class Window
{
 private:
  void __fastcall WinActivate(TObject *Sender);
  void __fastcall WinDeactivate(TObject *Sender);   
  void __fastcall DeleteButton(int ind);
  void __fastcall DeleteLabel(int ind);
  void __fastcall DeleteEdit(int ind);    
  bool __fastcall Imposition(TRect r);
  bool __fastcall ButtonResizeImposition(TRect r);
  bool __fastcall LabelResizeImposition(TRect r);  
  bool __fastcall GetString(FILE* stream,AnsiString& str);
  void __fastcall CreateWindowPropertyList(AnsiString str);
  bool __fastcall FillHObjVector();
  bool __fastcall Convert(FILE* stream, vector<HtmlObj*>& vHO, int b);
  bool __fastcall SubConvert(FILE* stream, vector<HtmlObj*>& vHO, int T, int B, int& R);
  bool __fastcall RegulateHObjVectorByY(vector<HtmlObj*>& vHO);
  bool __fastcall RegulateHObjVectorByX(vector<HtmlObj*>& vHO);
  bool __fastcall GetCoveringHObjVectorByY(vector<HtmlObj*>& vHOResult, vector<HtmlObj*>& vHOSource);
  bool __fastcall CoveringDownByX(HtmlObj* HObj);
  bool __fastcall CoveringUpByX(HtmlObj* HObj);
  bool __fastcall CoveringLeftByY(HtmlObj* HObj, vector<HtmlObj*> vHOSource, int& idx);
  bool __fastcall GetCoveringHObjVectorByX(vector<HtmlObj*>& vHOResult, vector<HtmlObj*>& vHOSource);
  bool __fastcall GetTopBottom(vector<HtmlObj*> vHO, int& top, int& bottom);
  bool __fastcall GetLeftRight(vector<HtmlObj*> vHO, int& left, int& right);
  void __fastcall GetBounds(AnsiString str,TRect& r);    
  AnsiString filename;
  int bCnt;
  int lCnt;
  int eCnt;    
 public:
  Window(int id);
  Window(int id, PropertyList* pl);
  Window(int id, bool hide, AnsiString fName);
  ~Window();  
  int Id;
  AnsiString wName;
  TForm *wForm;
  bool Modified;
  static int wCnt;
  PropertyList* pList;
  vector<Button*>  vButton;
  vector<Label*>   vLabel;
  vector<Edit*>    vEdit;
  vector<HtmlObj*> vHObj;
  vector<HtmlObj*> vHOTmp;
  void __fastcall FillCombo(TComboBox* cbx);
  void __fastcall WinMouseDown(TObject *Sender,TMouseButton Button,
							 TShiftState Shift, int X, int Y);
  void __fastcall WinMouseUp(TObject *Sender,TMouseButton Button,
							 TShiftState Shift, int X, int Y);
  void __fastcall WinCanResize(TObject *Sender, int &NewWidth,
							   int &NewHeight, bool &Resize);
  void __fastcall WinPaint(TObject *Sender);							   
  void __fastcall WinResize(TObject *Sender);
  void __fastcall WinKeyUp(TObject *Sender, WORD &Key, TShiftState Shift);
  void __fastcall WinShowGrid(int stepX, int stepY);
  bool __fastcall InsertNewObject(int X,int Y, int objtype);
  void __fastcall NewButton(int X,int Y);
  void __fastcall NewLabel(int X,int Y);
  void __fastcall NewEdit(int X,int Y);
  bool __fastcall ResizeImposition(TRect r);
  bool __fastcall SaveToFile(AnsiString fname);
  bool __fastcall SaveToHtmlFile(AnsiString fname);  
  AnsiString __fastcall GetFileName();  
};
#endif
