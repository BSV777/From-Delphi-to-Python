//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "property.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
Property::Property(AnsiString name, int type, int selectedIndex,int size,...)
{
 pName=name;
 selIndex=selectedIndex;
 pType=type;
 va_list ap;
 va_start(ap,size);
 AnsiString s;
 for(int i=0;i<size;i++)
  {
   s=va_arg(ap,char*);
   pValues.push_back(s);
  }
  va_end(ap);
}
//---------------------------------------------------------------------------
Property::Property(Property* p)
{
 pName=p->pName;
 selIndex=p->selIndex;
 pType=p->pType;
 pValues=p->pValues;
}
//---------------------------------------------------------------------------
AnsiString __fastcall Property::GetValue(void)
{
// if(pValues.size()==1) return pValues[0];
 return pValues[selIndex];
}
//---------------------------------------------------------------------------
void __fastcall Property::SetValue(AnsiString value)
{
// if(pValues.size()==1)
 if(pType==1 || pType==2)
  pValues[0]=value;
 else
 if(pType==3)
  for(unsigned int i=0;i<pValues.size();i++)
  {
   if(AnsiUpperCase(pValues[i])==AnsiUpperCase(value))
    {
     selIndex=i;
     break;
    }
  }
}
//---------------------------------------------------------------------------
AnsiString __fastcall Property::GetItem(unsigned int idx)
{
// if(pValues.size()==1)
 if(pType==1 || pType==2)
  return pValues[0];
 else
 if(pType==3)
  return pValues[idx];
  return (idx<pValues.size())?pValues[idx]:AnsiString("NotFound");  
}
//---------------------------------------------------------------------------
int __fastcall Property::Size()
{
  return (pValues.size());
}
//---------------------------------------------------------------------------
PropertyList::PropertyList(PropertyList& p)
{
 for(unsigned int i=0; i<p.vProperties.size(); i++)
 Add(*(new Property(p.vProperties[i])));
}
//---------------------------------------------------------------------------
AnsiString __fastcall PropertyList::GetPropertyValue(AnsiString name)
{
 vector<Property>::iterator i;
 for(i=vProperties.begin();i!=vProperties.end();++i)
  {
   if(AnsiUpperCase(name)==AnsiUpperCase(i->pName))
   return(i->GetValue());
  }
 return "NotFound";
}
//---------------------------------------------------------------------------
AnsiString __fastcall PropertyList::GetPropertyValue(unsigned int Idx)
{
 return (Idx<vProperties.size())?vProperties[Idx].GetValue():AnsiString("NotFound");
}
//---------------------------------------------------------------------------
void __fastcall PropertyList::SetPropertyValue(AnsiString name,AnsiString value)
{
 vector<Property>::iterator i;
 for(i=vProperties.begin();i!=vProperties.end();++i)
  {
   if(AnsiUpperCase(name)==AnsiUpperCase(i->pName))
	{
	 i->SetValue(value);
	 break;
	}
  }
}
//---------------------------------------------------------------------------
void __fastcall PropertyList::SetPropertyValue(unsigned int Idx,AnsiString value)
{
 if(Idx<vProperties.size()) vProperties[Idx].SetValue(value);
}
//---------------------------------------------------------------------------
int __fastcall PropertyList::Add(Property p)
{
 vProperties.push_back(p);
 return vProperties.size()-1;
}
//---------------------------------------------------------------------------
int __fastcall PropertyList::GetPropertyType(unsigned int Idx)
{
 return (Idx<vProperties.size())?vProperties[Idx].pType:-1;
}
//---------------------------------------------------------------------------
int __fastcall PropertyList::GetPropertyType(AnsiString name)
{
 vector<Property>::iterator i;
 for(i=vProperties.begin();i!=vProperties.end();++i)
  {
   if(AnsiUpperCase(name)==AnsiUpperCase(i->pName))
	{
	 return i->pType;
	}
  }
 return -1;
}
//---------------------------------------------------------------------------
int __fastcall PropertyList::ListSize()
{
 return vProperties.size();
}
//---------------------------------------------------------------------------
AnsiString __fastcall PropertyList::GetPropertyItem(unsigned int pIdx, unsigned int iIdx)
{
 return vProperties[pIdx].GetItem(iIdx);
}
//---------------------------------------------------------------------------
int __fastcall PropertyList::GetPropertySelected(unsigned int pIdx)
{
 return vProperties[pIdx].selIndex;
}
//---------------------------------------------------------------------------
int __fastcall PropertyList::PropertySize(unsigned int pIdx)
{
 return vProperties[pIdx].Size();
}
//---------------------------------------------------------------------------
AnsiString __fastcall PropertyList::GetPropertyNameByIdx(unsigned int pIdx)
{
 return (pIdx<vProperties.size())?vProperties[pIdx].pName:AnsiString("NotFound");
}
//---------------------------------------------------------------------------
int __fastcall PropertyList::GetPropertyIdxByName(AnsiString name)
{
 vector<Property>::iterator i;
 for(i=vProperties.begin();i!=vProperties.end();++i)
  {
   if(AnsiUpperCase(name)==AnsiUpperCase(i->pName))
	{
	 return i-vProperties.begin();
	}
  }
 return -1;
}
//---------------------------------------------------------------------------
