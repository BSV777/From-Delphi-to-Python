//---------------------------------------------------------------------------
#ifndef labelH
#define labelH
#include "property.h"
//#include "event.h"
#include <vector>
using namespace std;
//---------------------------------------------------------------------------
class Label
{
 private:
  bool move;
  TRect Focus;
  int X0;
  int Y0;
  bool IsLeftSizing;
  bool IsRightSizing;
  bool IsTopSizing;
  bool IsBottomSizing;
  void __fastcall GetSizingType(int x, int y);
  void __fastcall CreateLabelPropertyList(AnsiString str);
 public:
  Label(int id, int lCnt, bool selected, int startX, int startY, TWinControl* AOwner);
  Label(int id, int lCnt, bool selected, PropertyList* pl, TWinControl* AOwner);
  Label(int id, int lCnt, bool selected, AnsiString props, TWinControl* AOwner);
  ~Label();
  TImage *img;
  AnsiString Name;
  int Id;
  PropertyList* pList;
  void __fastcall LblMouseDown(TObject *Sender,TMouseButton Button,
							 TShiftState Shift, int X, int Y);
  void __fastcall LblMouseUp(TObject *Sender,TMouseButton Button,
							 TShiftState Shift, int X, int Y);
  void __fastcall LblMouseMove(TObject *Sender, TShiftState Shift,
							   int X, int Y);
  void Draw(AnsiString caption="");
  void DrawSelect(AnsiString caption="");
};
#endif
