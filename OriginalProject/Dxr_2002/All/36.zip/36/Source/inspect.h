//---------------------------------------------------------------------------

#ifndef inspectH
#define inspectH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>
#include "property.h"
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TfObjInsp : public TForm
{
__published:	// IDE-managed Components
	TPanel *Panel1;
	TComboBox *cbObjects;
	TPanel *Panel2;
	TTabSheet *tshPropertys;
	TPageControl *pcPropertys;        
	TStringGrid *sgPropertys;
	void __fastcall FormShow(TObject *Sender);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall FormResize(TObject *Sender);
	void __fastcall sgPropertysSelectCell(TObject *Sender, int ACol, int ARow,
          bool &CanSelect);
	void __fastcall cbObjectsChange(TObject *Sender);
	void __fastcall sgPropertysTopLeftChanged(TObject *Sender);
private:	// User declarations
	int ItemHeight;
	int ItemWidth;
	int DataItemWidth;
	int pType;
	void __fastcall cbExit(TObject *Sender);
	void __fastcall edExit(TObject *Sender);
	void __fastcall edKeyPress(TObject *Sender, char &Key);
	void __fastcall edChange(TObject *Sender);
    void __fastcall cbChange(TObject *Sender);	
	void __fastcall edKeyUp(TObject *Sender, WORD &Key, TShiftState Shift);
	void __fastcall cbKeyUp(TObject *Sender, WORD &Key, TShiftState Shift);
    int __fastcall GetPropertyType(int idx);		
public:		// User declarations
	__fastcall TfObjInsp(TComponent* Owner);
	void __fastcall ShowObjProperties(PropertyList pList);
	int __fastcall FindObjByName(AnsiString name);
	void __fastcall ClearSelect();
        void __fastcall DeleteControls();
    void __fastcall controlExit();
	TComponent* cmp;	
};
//---------------------------------------------------------------------------
extern PACKAGE TfObjInsp *fObjInsp;
//---------------------------------------------------------------------------
struct CurrentObject
{
 public:
  int Wnd;
  int Idx;
  AnsiString Type;
};
//---------------------------------------------------------------------------
extern CurrentObject CurrObj;
//---------------------------------------------------------------------------
#endif
