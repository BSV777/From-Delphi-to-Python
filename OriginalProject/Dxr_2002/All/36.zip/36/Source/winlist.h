//---------------------------------------------------------------------------

#ifndef winlistH
#define winlistH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TfWinList : public TForm
{
__published:	// IDE-managed Components
	TPanel *Panel1;
	TPanel *Panel2;
	TButton *btnOk;
	TListBox *lbWindows;
	TButton *btnCancel;
	void __fastcall FormShow(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall btnOkClick(TObject *Sender);
	void __fastcall lbWindowsDblClick(TObject *Sender);
	void __fastcall lbWindowsKeyPress(TObject *Sender, char &Key);
private:	// User declarations
public:		// User declarations
	__fastcall TfWinList(TComponent* Owner);
	int wNum;
};
//---------------------------------------------------------------------------
extern PACKAGE TfWinList *fWinList;
//---------------------------------------------------------------------------
#endif
