//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "window.h"
#include "inspect.h"
#include "SDIMain.h"
extern int ObjType;
//---------------------------------------------------------------------------
#pragma package(smart_init)
int Window::wCnt=0;
Window::Window(int id)
{
 bCnt=0;
 lCnt=0;
 eCnt=0;
 wCnt++;
 Id=id;
 wName="Window"+IntToStr(wCnt);
 pList=new PropertyList;
 pList->Add(*(new Property("Caption",1,0,1,wName.c_str())));
 pList->Add(*(new Property("Height",2,0,1,IntToStr(350).c_str())));
 pList->Add(*(new Property("Left",2,0,1,IntToStr(250).c_str())));
// pList->Add(*(new Property("Name",1,0,1,wName.c_str())));
 pList->Add(*(new Property("Top",2,0,1,IntToStr(130).c_str())));
 pList->Add(*(new Property("Width",2,0,1,IntToStr(450).c_str())));
// pList->Add(*(new Property("Window Type",3,0,3,"Popup","Overlapped","Child")));
 Modified=false;
 wForm=new TForm(Application);
 wForm->Color=clBtnFace;
 wForm->Top=130;
 wForm->Left=250;
 wForm->Height=350;
 wForm->Width=450;
 wForm->Font->Name="Times New Roman";
 wForm->Font->Size=10;
 wForm->Tag=Id;
 wForm->OnMouseDown=WinMouseDown;
 wForm->OnResize=WinResize;
 wForm->OnCanResize=WinCanResize;
 wForm->OnPaint=WinPaint;
 wForm->OnKeyUp=WinKeyUp;
 wForm->OnActivate=WinActivate;
 wForm->Caption=wName;
 wForm->Show();
}
//---------------------------------------------------------------------------
Window::Window(int id, PropertyList* pl)
{
 bCnt=0;
 lCnt=0;
 eCnt=0;
 wCnt++;
 Id=id;
 pList=new PropertyList(*pl);
 wForm=new TForm(Application);
 wForm->Color=clBtnFace;
 wName="Window"+IntToStr(wCnt);
 wForm->Top=StrToInt(pl->GetPropertyValue("Top"));
 wForm->Left=StrToInt(pl->GetPropertyValue("Left"));
 wForm->Height=StrToInt(pl->GetPropertyValue("Height"));
 wForm->Width=StrToInt(pl->GetPropertyValue("Width"));
 wForm->Caption=pl->GetPropertyValue("Caption");
 wForm->Font->Name="Arial";
 wForm->Tag=Id;
 wForm->OnMouseDown=WinMouseDown;
 wForm->OnResize=WinResize;
 wForm->OnCanResize=WinCanResize;
 wForm->OnPaint=WinPaint;
 wForm->OnKeyUp=WinKeyUp;
 wForm->OnActivate=WinActivate;
 Modified=false;
 wForm->Show();
}
//---------------------------------------------------------------------------
Window::Window(int id, bool hide, AnsiString fName)
{
 FILE *stream;
 bCnt=0;
 lCnt=0;
 eCnt=0;
 wCnt++;
 Id=id;
 TRect r;
 try
  {
   wForm=new TForm(Application);
   wForm->Color=clBtnFace;
   wName="Window"+IntToStr(wCnt);
   wForm->Top=130;
   wForm->Left=250;
   wForm->Height=350;
   wForm->Width=450;
   wForm->Caption=wName;
   stream=fopen(fName.c_str(),"r");
   fseek(stream,SEEK_SET,0);
   AnsiString str("");
   AnsiString s("");
   bool ok=true;
   bool find=false;
   while(ok)
	{
	 s="";
	 ok=GetString(stream,str);
	 int i = 2;
	 while(str[i]==' ' && i<str.Length()) i++;
	 if(i<str.Length())
	  s=str.SubString(i,str.Pos(' ')-2);
	 if(s.UpperCase()=="WINDOW")
	  {
	   CreateWindowPropertyList("<"+str.SubString(str.Pos(' ')+1,str.Length()));
	   find=true;
	  }
	 if(s.UpperCase()=="BUTTON")
	  {
	   GetBounds("<"+str.SubString(str.Pos(' ')+1,str.Length()),r);
	   if(!Imposition(r))
		{
		 bCnt++;
		 vButton.push_back((new ::Button(vButton.size(), bCnt, false,
					  "<"+str.SubString(str.Pos(' ')+1,str.Length()) , wForm)));
		}
	  }
	 if(s.UpperCase()=="LABEL")
	  {
	   GetBounds("<"+str.SubString(str.Pos(' ')+1,str.Length()),r);
	   if(!Imposition(r))
		{
		 lCnt++;
	     vLabel.push_back((new ::Label(vLabel.size(), lCnt, false,
					  "<"+str.SubString(str.Pos(' ')+1,str.Length()) , wForm)));
		}			  
	  }
	 if(s.UpperCase()=="EDIT")
	  {
	   GetBounds("<"+str.SubString(str.Pos(' ')+1,str.Length()),r);
	   r.Bottom=r.Top+25;
	   if(!Imposition(r))
		{
		 eCnt++;
		 vEdit.push_back((new ::Edit(vEdit.size(), eCnt, false,
					  "<"+str.SubString(str.Pos(' ')+1,str.Length()) , wForm)));
	    }
	  }
	}
   if(find)
	{
	 wForm->Top=StrToInt(pList->GetPropertyValue("Top"));
	 wForm->Left=StrToInt(pList->GetPropertyValue("Left"));
	 wForm->Height=StrToInt(pList->GetPropertyValue("Height"));
	 wForm->Width=StrToInt(pList->GetPropertyValue("Width"));
	 wForm->Caption=pList->GetPropertyValue("Caption");
	}
   else
	{
	 pList=new PropertyList;
	 pList->Add(*(new Property("Caption",1,0,1,wName.c_str())));
	 pList->Add(*(new Property("Height",2,0,1,IntToStr(wForm->Height).c_str())));
	 pList->Add(*(new Property("Left",2,0,1,IntToStr(wForm->Left).c_str())));
//     pList->Add(*(new Property("Name",1,0,1,wName.c_str())));
	 pList->Add(*(new Property("Top",2,0,1,IntToStr(wForm->Top).c_str())));
	 pList->Add(*(new Property("Width",2,0,1,IntToStr(wForm->Width).c_str())));
//	 pList->Add(*(new Property("Window Type",3,0,3,"Popup","Overlapped","Child")));
	}
   wForm->Font->Name="Arial";
   wForm->Tag=Id;
   wForm->OnMouseDown=WinMouseDown;
   wForm->OnResize=WinResize;
   wForm->OnCanResize=WinCanResize;
   wForm->OnPaint=WinPaint;
   wForm->OnKeyUp=WinKeyUp;
   wForm->OnActivate=WinActivate;   
   filename=fName;
   Modified=false;
   if(!hide) wForm->Show();
  }
 catch(...)
  {
   AnsiString str("������ ������� � ����� ");
   str+=fName+"!";
   Application->MessageBox(str.c_str(),"������!",MB_OK|MB_ICONSTOP);
  }
 if(stream) fclose(stream);
}
//---------------------------------------------------------------------------
Window::~Window()
{
 unsigned int i;
 for(i=0; i<vButton.size(); i++)
  {
   delete vButton[i];
  }
 vButton.clear();
 for(i=0; i<vLabel.size(); i++)
  {
   delete vLabel[i];
  }
 vLabel.clear();
 for(i=0; i<vEdit.size(); i++)
  {
   delete vEdit[i];
  }
 vEdit.clear();
 delete wForm;
}
//---------------------------------------------------------------------------
void __fastcall Window::CreateWindowPropertyList(AnsiString str)
{
 int left=250;
 int top=130;
 int width=450;
 int height=350;
 AnsiString caption;
 AnsiString pname, pvalue;
 int i=2;
 while(i<str.Length() && str[i]==' ') i++;
 while(i<str.Length())
  {
   pname=pvalue="";
   while(i<str.Length() && str[i]!='=')
    pname+=str[i++];
   i++;
   while(i<str.Length() && str[i]!='\"') i++;
   i++;
   while(i<str.Length() && str[i]!='\"')
    pvalue+=str[i++];
   while(i<str.Length() && str[i]!=';') i++;
   i++;
   pname=pname.Trim();
   pvalue=pvalue.Trim();
   if(pname.UpperCase()=="LEFT")
    {
     try {left=StrToInt(pvalue);}
     catch(...) {left=250;}
     continue;
    }
   if(pname.UpperCase()=="TOP")
    {
	 try {top=StrToInt(pvalue);}
     catch(...) {top=130;}
     continue;
    }
   if(pname.UpperCase()=="HEIGHT")
    {
     try {height=StrToInt(pvalue);}
     catch(...) {height=350;}
     continue;
    }
   if(pname.UpperCase()=="WIDTH")
    {
     try {width=StrToInt(pvalue);}
     catch(...) {width=450;}
     continue;
    }
   if(pname.UpperCase()=="CAPTION")
    {
     try {caption=pvalue;}
     catch(...) {caption="";}
     continue;
    }
  }
 pList=new PropertyList();
 pList->Add(*(new Property("Caption",1,0,1,caption.c_str())));
 pList->Add(*(new Property("Height",2,0,1,IntToStr(height).c_str())));
 pList->Add(*(new Property("Left",2,0,1,IntToStr(left).c_str())));
// pList->Add(*(new Property("Name",1,0,1,AnsiString("Window"+IntToStr(Window::wCnt)).c_str())));
 pList->Add(*(new Property("Top",2,0,1,IntToStr(top).c_str())));
 pList->Add(*(new Property("Width",2,0,1,IntToStr(width).c_str())));
 pList->Add(*(new Property("Window Type",3,0,3,"Popup","Overlapped","Child")));
}
//---------------------------------------------------------------------------
bool __fastcall Window::GetString(FILE* stream,AnsiString& str)
{
 int ch;
 str="<";
 while((ch=fgetc(stream))!=EOF&&ch!='<');
 while((ch=fgetc(stream))!=EOF&&ch!='>')
  {
   str+=(char(ch));
   if(str[str.Length()]=='\n')
    str=str.SubString(1,str.Length()-1);
  }
 str+=">";
 if(ch==EOF) return false;
 return true;
}
//---------------------------------------------------------------------------
void __fastcall Window::WinMouseDown(TObject *Sender,TMouseButton Button,
										  TShiftState Shift, int X, int Y)
{
 if(Button==mbLeft)
  {
   fObjInsp->controlExit();
   fObjInsp->DeleteControls();   
   fObjInsp->ClearSelect();  
   wForm->SetFocus();
	 CurrObj.Type="WINDOW";
	 int idx=-1;
	 if(CurrObj.Wnd!=Id)
	  {
	   CurrObj.Wnd=Id;
	   CurrObj.Idx=Id;
	   FillCombo(fObjInsp->cbObjects);
	   idx=fObjInsp->FindObjByName(wName);
	   fObjInsp->cbObjects->ItemIndex=idx;
	   fObjInsp->ShowObjProperties(*pList);
	  }
	 CurrObj.Wnd=Id;
	 CurrObj.Idx=Id;
	 if(ObjType!=0)
	  {
	   if(InsertNewObject(X,Y,ObjType))
		{
		 Modified=true;
		 return;
		}
	  }
	 idx=fObjInsp->FindObjByName(wName);
	 if(idx>=0 && fObjInsp->cbObjects->ItemIndex!=idx)
	  {
	   fObjInsp->cbObjects->ItemIndex=idx;
	   fObjInsp->ShowObjProperties(*pList);
	  }
  }
}
//---------------------------------------------------------------------------
void __fastcall Window::WinActivate(TObject *Sender)
{
 if(ObjType==0 && CurrObj.Wnd!=Id)
  WinMouseDown(Sender,mbLeft,TShiftState(),0,0);
 else
  fObjInsp->DeleteControls(); 
}
//---------------------------------------------------------------------------
void __fastcall Window::WinCanResize(TObject *Sender, int &NewWidth,
									 int &NewHeight, bool &Resize)
{

 if(CurrObj.Wnd==Id)
  {
   pList->SetPropertyValue("LEFT",wForm->Left);
   pList->SetPropertyValue("TOP",wForm->Top);
   if(CurrObj.Type=="WINDOW")
	{
	 fObjInsp->sgPropertys->Cells[1][pList->GetPropertyIdxByName("LEFT")]=IntToStr(wForm->Left);
	 fObjInsp->sgPropertys->Cells[1][pList->GetPropertyIdxByName("TOP")]=IntToStr(wForm->Top);
	}
   Modified=true;
  }
}
//---------------------------------------------------------------------------
void __fastcall Window::WinResize(TObject *Sender)
{
 pList->SetPropertyValue("WIDTH",IntToStr(wForm->Width));
 pList->SetPropertyValue("HEIGHT",IntToStr(wForm->Height));
 if(CurrObj.Type=="WINDOW")
  {
   int i=pList->GetPropertyIdxByName("WIDTH");
   fObjInsp->sgPropertys->Cells[1][i]=IntToStr(wForm->Width);
   i=pList->GetPropertyIdxByName("HEIGHT");
   fObjInsp->sgPropertys->Cells[1][i]=IntToStr(wForm->Height);
   Modified=true;   
  }
}
//---------------------------------------------------------------------------
void __fastcall Window::WinShowGrid(int stepX, int stepY)
{
 if(stepX>0&&stepY>0)
  {
   for(int x=0;x<wForm->Width;x+=stepX)
	for(int y=0;y<wForm->Height;y+=stepY)
	 {
	  wForm->Canvas->Pixels[x][y]=clBlack;
	 }
  }
}
//---------------------------------------------------------------------------
bool __fastcall Window::InsertNewObject(int X,int Y, int objtype)
{
  if(Imposition(TRect(X,Y,X+75,Y+25)))
   {
     Application->MessageBox("��������� �������� �����������!","��������!",
                                                 MB_OK|MB_ICONEXCLAMATION);
     return false;
   }
   switch(objtype)
	{
	 case 1:
	  NewButton(X,Y);
	 break;
	 case 2:
	  NewLabel(X,Y);
	 break;
	 case 3:
	  NewEdit(X,Y);
	 break;
	 default:
	 return false;
	}
   fMain->spbArrow->Down=true;
   ObjType=0;
   return true;   
}
//---------------------------------------------------------------------------
void __fastcall Window::NewButton(int X, int Y)
{
  bCnt++;
  fObjInsp->controlExit();
  vButton.push_back((new ::Button(vButton.size(), bCnt, true, X, Y, wForm)));
  fObjInsp->cbObjects->ItemIndex =
  fObjInsp->cbObjects->Items->AddObject(vButton[vButton.size()-1]->Name+" : Button",
						vButton[vButton.size()-1]->img);
  CurrObj.Type="BUTTON";
  CurrObj.Idx=vButton.size()-1;
  fObjInsp->ShowObjProperties(*(vButton[vButton.size()-1]->pList));
}
//---------------------------------------------------------------------------
void __fastcall Window::NewLabel(int X, int Y)
{
  lCnt++;
  fObjInsp->controlExit();
  vLabel.push_back((new ::Label(vLabel.size(), lCnt, true, X, Y, wForm)));
  fObjInsp->cbObjects->ItemIndex =
  fObjInsp->cbObjects->Items->AddObject(vLabel[vLabel.size()-1]->Name+" : Label",
						vLabel[vLabel.size()-1]->img);
  CurrObj.Type="LABEL";
  CurrObj.Idx=vLabel.size()-1;
  fObjInsp->ShowObjProperties(*(vLabel[vLabel.size()-1]->pList));
}
//---------------------------------------------------------------------------
void __fastcall Window::NewEdit(int X, int Y)
{
  eCnt++;
  fObjInsp->controlExit();
  vEdit.push_back((new ::Edit(vEdit.size(), eCnt, true, X, Y, wForm)));
  fObjInsp->cbObjects->ItemIndex =
  fObjInsp->cbObjects->Items->AddObject(vEdit[vEdit.size()-1]->Name+" : Edit",
						vEdit[vEdit.size()-1]->img);
  CurrObj.Type="EDIT";
  CurrObj.Idx=vEdit.size()-1;
  fObjInsp->ShowObjProperties(*(vEdit[vEdit.size()-1]->pList));
}
//---------------------------------------------------------------------------
void __fastcall Window::FillCombo(TComboBox* cbx)
{
  unsigned int i;
  cbx->Clear();
  cbx->Items->AddObject(wName+" : Window",wForm);
  for(i=0;i<vButton.size();i++)
   {
    cbx->Items->AddObject(vButton[i]->Name+" : Button",vButton[i]->img);
   }
  for(i=0;i<vLabel.size();i++)
   {
    cbx->Items->AddObject(vLabel[i]->Name+" : Label",vLabel[i]->img);
   }
  for(i=0;i<vEdit.size();i++)
   {
	cbx->Items->AddObject(vEdit[i]->Name+" : Edit",vEdit[i]->img);
   }
}
//---------------------------------------------------------------------------
void __fastcall Window::WinKeyUp(TObject *Sender, WORD &Key, TShiftState Shift)
{
 int ind=0;
 AnsiString str("");
 if(Key==VK_DELETE)
  {
   if(CurrObj.Type=="BUTTON")
	{
	 DeleteButton(CurrObj.Idx);
	 Modified=true;	 
	 fObjInsp->cbObjects->Items->Delete(fObjInsp->cbObjects->ItemIndex);
	 ind=fObjInsp->FindObjByName(wName);
	 fObjInsp->cbObjects->ItemIndex=ind;
	 if(ind>=0)
	  {
	   CurrObj.Type="Window";
	   CurrObj.Wnd=ind;
 	   CurrObj.Idx=ind;	   	   	  
	   fObjInsp->ShowObjProperties(*pList);
	  }
	}
   if(CurrObj.Type=="LABEL")
	{
	 DeleteLabel(CurrObj.Idx);
	 Modified=true;	 
	 fObjInsp->cbObjects->Items->Delete(fObjInsp->cbObjects->ItemIndex);
	 ind=fObjInsp->FindObjByName(wName);
	 fObjInsp->cbObjects->ItemIndex=ind;
	 if(ind>=0)
	  {
	   CurrObj.Type="Window";
	   CurrObj.Wnd=ind;
	   CurrObj.Idx=ind;
	   fObjInsp->ShowObjProperties(*pList);
	  }
	}
   if(CurrObj.Type=="EDIT")
	{
	 DeleteEdit(CurrObj.Idx);
	 Modified=true;	 
	 fObjInsp->cbObjects->Items->Delete(fObjInsp->cbObjects->ItemIndex);
	 ind=fObjInsp->FindObjByName(wName);
	 fObjInsp->cbObjects->ItemIndex=ind;
	 if(ind>=0)
	  {
	   CurrObj.Type="Window";
	   CurrObj.Wnd=ind;
	   CurrObj.Idx=ind;
	   fObjInsp->ShowObjProperties(*pList);
	  }
	}
  }
}
//---------------------------------------------------------------------------
void __fastcall Window::DeleteButton(int ind)
{
 delete vButton[ind];
 for(unsigned int i=ind; i<vButton.size(); i++)
  {
   vButton[i]->img->Tag--;
   vButton[i]->Id--;
  }
 vButton.erase(&vButton[ind]);
}
//---------------------------------------------------------------------------
void __fastcall Window::DeleteLabel(int ind)
{
 delete vLabel[ind];
 for(unsigned int i=ind; i<vLabel.size(); i++)
  {
   vLabel[i]->img->Tag--;
   vLabel[i]->Id--;
  }
 vLabel.erase(&vLabel[ind]);
}
//---------------------------------------------------------------------------
void __fastcall Window::DeleteEdit(int ind)
{
 delete vEdit[ind];
 for(unsigned int i=ind; i<vEdit.size(); i++)
  {
   vEdit[i]->img->Tag--;
   vEdit[i]->Id--;
  }
 vEdit.erase(&vEdit[ind]);
}
//---------------------------------------------------------------------------
void __fastcall Window::WinPaint(TObject *Sender)
{
 WinShowGrid(7,7);
}
//---------------------------------------------------------------------------
bool __fastcall Window::Imposition(TRect r)
{
 int i;
 int size=vButton.size();
 TRect bnds;
 #define Btn vButton[i]
 for(i=0; i<size; i++)
  {
   bnds.Top=Btn->img->Top;
   bnds.Left=Btn->img->Left;
   bnds.Right=Btn->img->Left+Btn->img->Width;
   bnds.Bottom=Btn->img->Top+Btn->img->Height;
   if((r.Top>=bnds.Top && r.Top<=bnds.Bottom) ||
	  (r.Bottom>=bnds.Top && r.Bottom<=bnds.Bottom) ||
	  (bnds.Top>=r.Top && bnds.Top<=r.Bottom) ||
	  (bnds.Bottom>=r.Top && bnds.Bottom<=r.Bottom))
	{
	 if((r.Right>=bnds.Left && r.Right<=bnds.Right) ||
		(r.Left<=bnds.Right && r.Left>=bnds.Left) ||
		(r.Left>=bnds.Left && r.Right<=bnds.Right) ||
		(bnds.Left>=r.Left && bnds.Right<=r.Right))		
	   return true;
	}
  }
 #undef Btn
 size=vLabel.size(); 
 #define Lbl vLabel[i]
 for(i=0; i<size; i++)
  {
   bnds.Top=Lbl->img->Top;
   bnds.Left=Lbl->img->Left;
   bnds.Right=Lbl->img->Left+Lbl->img->Width;
   bnds.Bottom=Lbl->img->Top+Lbl->img->Height;
   if((r.Top>=bnds.Top && r.Top<=bnds.Bottom) ||
      (r.Bottom>=bnds.Top && r.Bottom<=bnds.Bottom) ||
	  (bnds.Top>=r.Top && bnds.Top<=r.Bottom) ||
      (bnds.Bottom>=r.Top && bnds.Bottom<=r.Bottom))
    {
     if((r.Right>=bnds.Left && r.Right<=bnds.Right) ||
    	(r.Left<=bnds.Right && r.Left>=bnds.Left) ||
    	(r.Left>=bnds.Left && r.Right<=bnds.Right) ||
    	(bnds.Left>=r.Left && bnds.Right<=r.Right))
       return true;
    }
  }
 #undef Lbl
 size=vEdit.size();
 #define Edt vEdit[i]
 for(i=0; i<size; i++)
  {
   bnds.Top=Edt->img->Top;
   bnds.Left=Edt->img->Left;
   bnds.Right=Edt->img->Left+Edt->img->Width;
   bnds.Bottom=Edt->img->Top+Edt->img->Height;
   if((r.Top>=bnds.Top && r.Top<=bnds.Bottom) ||
	  (r.Bottom>=bnds.Top && r.Bottom<=bnds.Bottom) ||
	  (bnds.Top>=r.Top && bnds.Top<=r.Bottom) ||
	  (bnds.Bottom>=r.Top && bnds.Bottom<=r.Bottom))
	{
	 if((r.Right>=bnds.Left && r.Right<=bnds.Right) ||
		(r.Left<=bnds.Right && r.Left>=bnds.Left) ||
		(r.Left>=bnds.Left && r.Right<=bnds.Right) ||
		(bnds.Left>=r.Left && bnds.Right<=r.Right))
	   return true;
	}
  }
 #undef Edt
 return false;
}
//---------------------------------------------------------------------------
bool __fastcall Window::ResizeImposition(TRect r)
{
 int i;
 int size=vButton.size();
 #define Btn vButton[i]
 TRect bnds;
 for(i=0; i<size; i++)
  {
   if(i==CurrObj.Idx && CurrObj.Type=="BUTTON") continue;
   bnds.Top=Btn->img->Top;
   bnds.Left=Btn->img->Left;
   bnds.Right=Btn->img->Left+Btn->img->Width;
   bnds.Bottom=Btn->img->Top+Btn->img->Height;
   if((r.Top>=bnds.Top && r.Top<=bnds.Bottom) ||
	  (r.Bottom>=bnds.Top && r.Bottom<=bnds.Bottom) ||
	  (bnds.Top>=r.Top && bnds.Top<=r.Bottom) ||
	  (bnds.Bottom>=r.Top && bnds.Bottom<=r.Bottom))
	{
	 if((r.Right>=bnds.Left && r.Right<=bnds.Right) ||
		(r.Left<=bnds.Right && r.Left>=bnds.Left) ||
		(r.Left>=bnds.Left && r.Right<=bnds.Right) ||
		(bnds.Left>=r.Left && bnds.Right<=r.Right))
	   return true;
	}
  }
 #undef Btn
 size=vLabel.size(); 
 #define Lbl vLabel[i]
 for(i=0; i<size; i++)
  {
   if(i==CurrObj.Idx && CurrObj.Type=="LABEL") continue;
   bnds.Top=Lbl->img->Top;
   bnds.Left=Lbl->img->Left;
   bnds.Right=Lbl->img->Left+Lbl->img->Width;
   bnds.Bottom=Lbl->img->Top+Lbl->img->Height;
   if((r.Top>=bnds.Top && r.Top<=bnds.Bottom) ||
	  (r.Bottom>=bnds.Top && r.Bottom<=bnds.Bottom) ||
	  (bnds.Top>=r.Top && bnds.Top<=r.Bottom) ||
	  (bnds.Bottom>=r.Top && bnds.Bottom<=r.Bottom))
	{
	 if((r.Right>=bnds.Left && r.Right<=bnds.Right) ||
		(r.Left<=bnds.Right && r.Left>=bnds.Left) ||
		(r.Left>=bnds.Left && r.Right<=bnds.Right) ||
		(bnds.Left>=r.Left && bnds.Right<=r.Right))
	   return true;
	}
  }
 #undef Lbl
 size=vEdit.size();
 #define Edt vEdit[i]
 for(i=0; i<size; i++)
  {
   if(i==CurrObj.Idx && CurrObj.Type=="EDIT") continue;
   bnds.Top=Edt->img->Top;
   bnds.Left=Edt->img->Left;
   bnds.Right=Edt->img->Left+Edt->img->Width;
   bnds.Bottom=Edt->img->Top+Edt->img->Height;
   if((r.Top>=bnds.Top && r.Top<=bnds.Bottom) ||
	  (r.Bottom>=bnds.Top && r.Bottom<=bnds.Bottom) ||
	  (bnds.Top>=r.Top && bnds.Top<=r.Bottom) ||
	  (bnds.Bottom>=r.Top && bnds.Bottom<=r.Bottom))
	{
	 if((r.Right>=bnds.Left && r.Right<=bnds.Right) ||
		(r.Left<=bnds.Right && r.Left>=bnds.Left) ||
		(r.Left>=bnds.Left && r.Right<=bnds.Right) ||
		(bnds.Left>=r.Left && bnds.Right<=r.Right))
	   return true;
	}
  }
 #undef Edt
 return false;
}
//---------------------------------------------------------------------------
bool __fastcall Window::ButtonResizeImposition(TRect r)
{
 int i;
 int size=vButton.size();
 #define Btn vButton[i]
 TRect bnds;
 for(i=0; i<size; i++)
  {
   if(i==CurrObj.Idx) continue;
   bnds.Top=Btn->img->Top;
   bnds.Left=Btn->img->Left;
   bnds.Right=Btn->img->Left+Btn->img->Width;
   bnds.Bottom=Btn->img->Top+Btn->img->Height;
   if((r.Top>=bnds.Top && r.Top<=bnds.Bottom) ||
	  (r.Bottom>=bnds.Top && r.Bottom<=bnds.Bottom) ||
	  (bnds.Top>=r.Top && bnds.Top<=r.Bottom) ||
	  (bnds.Bottom>=r.Top && bnds.Bottom<=r.Bottom))
	{
	 if((r.Right>=bnds.Left && r.Right<=bnds.Right) ||
		(r.Left<=bnds.Right && r.Left>=bnds.Left) ||
		(r.Left>=bnds.Left && r.Right<=bnds.Right) ||
		(bnds.Left>=r.Left && bnds.Right<=r.Right))
	   return true;
	}
  }
 #undef Btn
 return false;
}
//---------------------------------------------------------------------------
bool __fastcall Window::LabelResizeImposition(TRect r)
{
 int i;
 int size=vLabel.size();
 #define Lbl vLabel[i]
 TRect bnds;
 for(i=0; i<size; i++)
  {
   if(i==CurrObj.Idx) continue;
   bnds.Top=Lbl->img->Top;
   bnds.Left=Lbl->img->Left;
   bnds.Right=Lbl->img->Left+Lbl->img->Width;
   bnds.Bottom=Lbl->img->Top+Lbl->img->Height;
   if((r.Top>=bnds.Top && r.Top<=bnds.Bottom) ||
	  (r.Bottom>=bnds.Top && r.Bottom<=bnds.Bottom) ||
	  (bnds.Top>=r.Top && bnds.Top<=r.Bottom) ||
	  (bnds.Bottom>=r.Top && bnds.Bottom<=r.Bottom))
	{
	 if((r.Right>=bnds.Left && r.Right<=bnds.Right) ||
		(r.Left<=bnds.Right && r.Left>=bnds.Left) ||
		(r.Left>=bnds.Left && r.Right<=bnds.Right) ||
		(bnds.Left>=r.Left && bnds.Right<=r.Right))
	   return true;
	}
  }
 #undef Lbl
 return false;
}
//---------------------------------------------------------------------------
bool __fastcall Window::SaveToFile(AnsiString fname)
{
 FILE *stream;
 stream=fopen(fname.c_str(),"w");
 if(!stream)
  {
   Application->MessageBox("������ ������ � ����!","������!",MB_OK|MB_ICONSTOP);
   return false;
  }
 try
  {
   AnsiString s;
/***************************Window*********************************/
   s="<Window left=\""+IntToStr(wForm->Left)+"\";";
   s+="top=\""+IntToStr(wForm->Top)+"\";";
   s+="height=\""+IntToStr(wForm->Height)+"\";";
   s+="width=\""+IntToStr(wForm->Width)+"\";";
   s+="caption=\""+wForm->Caption+"\">";
   s+="\n";
   fputs(s.c_str(),stream);
/****************************Button*********************************/
   unsigned int i;
   for(i=0; i<vButton.size(); i++)
    {
     s="<Button left=\""+IntToStr(vButton[i]->img->Left)+"\";";
     s+="top=\""+IntToStr(vButton[i]->img->Top)+"\";";
     s+="height=\""+IntToStr(vButton[i]->img->Height)+"\";";
     s+="width=\""+IntToStr(vButton[i]->img->Width)+"\";";
	 s+="caption=\""+vButton[i]->pList->GetPropertyValue("CAPTION")+"\">";
     s+="\n";
     fputs(s.c_str(),stream);
    }
/****************************Label*********************************/
   for(i=0; i<vLabel.size(); i++)
    {
     s="<Label left=\""+IntToStr(vLabel[i]->img->Left)+"\";";
     s+="top=\""+IntToStr(vLabel[i]->img->Top)+"\";";
     s+="height=\""+IntToStr(vLabel[i]->img->Height)+"\";";
     s+="width=\""+IntToStr(vLabel[i]->img->Width)+"\";";
     s+="text=\""+vLabel[i]->pList->GetPropertyValue("TEXT")+"\">";
     s+="\n";
     fputs(s.c_str(),stream);
	}
/****************************Edit*********************************/
   for(i=0; i<vEdit.size(); i++)
	{
	 s="<Edit left=\""+IntToStr(vEdit[i]->img->Left)+"\";";
	 s+="top=\""+IntToStr(vEdit[i]->img->Top)+"\";";
//	 s+="height=\""+IntToStr(vEdit[i]->img->Height)+"\";";
	 s+="width=\""+IntToStr(vEdit[i]->img->Width)+"\";";
	 s+="text=\""+vEdit[i]->pList->GetPropertyValue("TEXT")+"\">";
	 s+="\n";
	 fputs(s.c_str(),stream);
	}
/*******************************************************************/
   fclose(stream);
//   if(stream) delete stream;
   filename=fname;
   Modified=false;   
   return true;
  }
 catch(...)
  {
   if(stream) fclose(stream);
//   if(stream) delete stream;
   Application->MessageBox("������ ������ � ����!","������!",MB_OK|MB_ICONSTOP);
   return false;
  }
}
//---------------------------------------------------------------------------
AnsiString __fastcall Window::GetFileName()
{
 return filename;
}
//---------------------------------------------------------------------------
bool __fastcall Window::SaveToHtmlFile(AnsiString fname)
{
 if(!FillHObjVector()) return false;
 FILE *stream;
 stream=fopen(fname.c_str(),"w");
 if(!stream)
  {
   Application->MessageBox("������ ������ � ����!","������!",MB_OK|MB_ICONSTOP);
   return false;
  }
 wForm->Enabled=false;
 if(fMain) fMain->pbConvert->Position=0;
 if(fMain) fMain->pbConvert->Min=0;
 if(fMain) fMain->pbConvert->Max=vHObj.size();   

 fseek(stream,SEEK_SET,0);
 AnsiString s;
// int left=0, right=0;
// int top=0, bottom=0;
// GetTopBottom(vHObj, top, bottom);
 s="<HTML>\n<BODY>\n";
 //fDebug->Add(s);
 fputs(s.c_str(),stream);
 s="<table width="+IntToStr(wForm->Width)+" CELLPADDING=0 CELLPADDING=0>\n";
 fputs(s.c_str(),stream);
 s="<tr height="+IntToStr(wForm->Height)+" VALIGN=\"Top\">\n";
 fputs(s.c_str(),stream);
 s="<td width="+IntToStr(wForm->Width)+">\n";
 fputs(s.c_str(),stream);
 if(!Convert(stream,vHObj,0)) return false;
 s="</td>\n";
 fputs(s.c_str(),stream);
 s="</tr>\n";
 fputs(s.c_str(),stream);
/* if(wForm->Height>bottom)
  {
   s="<tr height="+IntToStr(wForm->Height-bottom)+" \"VALIGN\"=\"Top\">\n";
   fputs(s.c_str(),stream);
   s="<td width="+IntToStr(wForm->Width)+" \"VALIGN\"=\"Top\"></td>\n";
   fputs(s.c_str(),stream);
   s="</tr>\n";
   fputs(s.c_str(),stream);
  }*/
 s="</table>\n";
 //fDebug->Add(s);
 fputs(s.c_str(),stream);
 s="</HTML>\n</BODY>";
 fputs(s.c_str(),stream);
 //fDebug->Add(s);
 fclose(stream);
 wForm->Enabled=true;
 if(fMain) fMain->pbConvert->Position=0;
 Application->MessageBox("�������������� ���������!","��������!",MB_OK|MB_ICONINFORMATION);   
 return true;
}
//---------------------------------------------------------------------------
bool __fastcall Window::Convert(FILE* stream, vector<HtmlObj*>& vHO, int b)
{
 if(!RegulateHObjVectorByY(vHO)) return false;
 vector<HtmlObj*> vCoverY;
 vector<HtmlObj*> vCoverX;
 AnsiString s;
 int BOTTOM=b;
 int top=0, bottom=0, left=0, right=0;
 while(vHO.size())
  {
   s="<table CELLPADDING=0 CELLPADDING=0>\n";
   fputs(s.c_str(),stream);
   if(!GetCoveringHObjVectorByY(vCoverY, vHO)) return false;
/*   for(int i=0; i<vCoverY.size();i++)
	{
	 ShowMessage(vCoverY[i]->Text);
    }*/
   GetTopBottom(vCoverY, top, bottom);

   if(BOTTOM!=top)
	{
	 s="<tr height=\""+IntToStr(top-BOTTOM)+"\" VALIGN=\"Top\">\n";
	 fputs(s.c_str(),stream);
         //fDebug->Add(s);
	 s="<td></td>\n";
	 fputs(s.c_str(),stream);
         //fDebug->Add(s);
	 s="</tr>\n";
	 fputs(s.c_str(),stream);
         //fDebug->Add(s);         
	 BOTTOM=top;
	}
   s="<tr height=\""+IntToStr(bottom-top)+"\" VALIGN=\"Top\">\n";
   fputs(s.c_str(),stream);
   //fDebug->Add(s);

   GetLeftRight(vCoverY, left, right);
   if(left>0)
	{
	 s="<td width="+IntToStr(left)+"></td>\n";
	 fputs(s.c_str(),stream);
         //fDebug->Add(s);         
	}
   s="<td width="+IntToStr(right-left)+">\n";
   fputs(s.c_str(),stream);
   //fDebug->Add(s);
   for(unsigned int i=0; i<vCoverY.size(); i++)
	{
	 HtmlObj* ho=new HtmlObj(vCoverY[i]);
	 vHOTmp.push_back(ho);
	}
   SubConvert(stream,vCoverY, top, bottom, right);
   s="</td>\n";
   fputs(s.c_str(),stream);
   //fDebug->Add(s);
   s="</tr>\n";
   fputs(s.c_str(),stream);
   //fDebug->Add(s);
   s="</table>\n";
   fputs(s.c_str(),stream);
   BOTTOM=bottom;
   for(unsigned int i=0; i<vHOTmp.size(); i++)
	{
	 delete vHOTmp[i];
	}
   vHOTmp.clear();
  }
 for(unsigned int i=0; i<vCoverY.size(); i++)
  {
   delete vCoverY[i];
  }
 vCoverY.clear();
 return true;
}
//---------------------------------------------------------------------------
bool __fastcall Window::SubConvert(FILE* stream, vector<HtmlObj*>& vHO, int T, int B, int& R)
{
 if(!RegulateHObjVectorByY(vHO)) return false;
 vector<HtmlObj*> vCoverY;
 vector<HtmlObj*> vCoverX;
 vector<HtmlObj*> vTmp;
 int BOTTOM=T;
 int top=0, bottom=0, left=0, right=0;
 AnsiString s;
 for(unsigned int i=0; i<vHO.size(); i++)
  {
   HtmlObj* ho=new HtmlObj(vHO[i]);
   vTmp.push_back(ho);
  }
 while(vHO.size())
  {

   s="<table CELLPADDING=0 CELLPADDING=0>\n";
   fputs(s.c_str(),stream);

   if(!GetCoveringHObjVectorByY(vCoverY, vHO)) return false;
   GetTopBottom(vCoverY, top, bottom);

  if(BOTTOM!=top)
   {
	s="<tr height=\""+IntToStr(top-BOTTOM)+"\" VALIGN=\"Top\">\n";
	fputs(s.c_str(),stream);
	s="<td></td>\n";
	fputs(s.c_str(),stream);
	s="</tr>\n";
	fputs(s.c_str(),stream);
	BOTTOM=top;
   }

   if(vCoverY.size()==1)
	{
	 int t=0,b=0,h=0;
	 GetTopBottom(vHOTmp, t, b);

	 if(!CoveringUpByX(vCoverY[0]))
	  {
	   h=vCoverY[0]->r.Top-t;
	   if(h>0)
		{
		 s="<tr height="+IntToStr(h)+" VALIGN=\"Top\">\n";
		 fputs(s.c_str(),stream);
		 s="<td ></td>\n";
		 fputs(s.c_str(),stream);
		 s="</tr>\n";
		 fputs(s.c_str(),stream);
		}
	  }
	 h=vCoverY[0]->r.Bottom-vCoverY[0]->r.Top;
	 s="<tr height=\""+IntToStr(h)+"\" VALIGN=\"Top\">\n";
	 fputs(s.c_str(),stream);
	 h=0;
	 if(CoveringLeftByY(vCoverY[0],vTmp,h))
	  {//������ �� �������������� ��-�� � ������� h
	   h=vCoverY[0]->r.Left-vTmp[h]->r.Right;
	   s="<td width="+IntToStr(h)+"></td>\n";
	   fputs(s.c_str(),stream);
	  }
	 else
	  {//������ �� ���� ������
	   GetLeftRight(vTmp, left, right);
	   h=vCoverY[0]->r.Left-left;
	   if(h>0)
		{
		 s="<td width="+IntToStr(h)+"></td>\n";
		 fputs(s.c_str(),stream);
		}
	  }
	 if(vCoverY[0]->Type=="BUTTON")
	  {
	   s="<td><input type=button Value='"+vCoverY[0]->Text+"' style=";
	   s+="\"{font: 10pt 'Times New Roman'; width="+
			 IntToStr((int)vCoverY[0]->r.Right-(int)vCoverY[0]->r.Left)+";";
	   s+="height="+IntToStr((int)vCoverY[0]->r.Bottom-(int)vCoverY[0]->r.Top)+";";
	   s+="}\"></td>\n";
	   fputs(s.c_str(),stream);
	  }
	 if(vCoverY[0]->Type=="LABEL")
	  {
	   s="<td VALIGN=\"Center\" style=";
	   s+="\"{font: 10pt 'Times New Roman'; width="+
			 IntToStr((int)vCoverY[0]->r.Right-(int)vCoverY[0]->r.Left)+";";
	   s+="height="+IntToStr((int)vCoverY[0]->r.Bottom-(int)vCoverY[0]->r.Top)+";";
	   s+="}\">"+vCoverY[0]->Text+"</td>\n";
	   fputs(s.c_str(),stream);
	  }
	 if(vCoverY[0]->Type=="EDIT")
	  {
	   s="<td><input type=text Value='"+vCoverY[0]->Text+"' style=";
	   s+="\"{font: 10pt 'Times New Roman'; width="+
			 IntToStr((int)vCoverY[0]->r.Right-(int)vCoverY[0]->r.Left)+";";
	   s+="height="+IntToStr((int)vCoverY[0]->r.Bottom-(int)vCoverY[0]->r.Top)+";";
	   s+="}\"></td>\n";
	   fputs(s.c_str(),stream);
	  }
	 s="</tr>\n";
	 fputs(s.c_str(),stream);
	 R=vCoverY[0]->r.Right;
	 delete vCoverY[0];
	 vCoverY.clear();
	 if(fMain) fMain->pbConvert->Position++;
	}
   else
	{
	 s="<tr height=\""+IntToStr(bottom-top)+"\" VALIGN=\"Top\">\n";
	 fputs(s.c_str(),stream);
	 if(!RegulateHObjVectorByX(vCoverY)) return false;

	   while(vCoverY.size())
		{
		 if(!GetCoveringHObjVectorByX(vCoverX, vCoverY)) return false;
		 GetLeftRight(vCoverX, left, right);

		 if(left-R>0)
		  {
		   s="<td width=\""+IntToStr(left-R)+"\"></td>\n";
		   fputs(s.c_str(),stream);
		  }
		 s="<td width=\""+IntToStr(right-left)+"\">\n";
		 fputs(s.c_str(),stream);
		 if(!RegulateHObjVectorByX(vCoverX)) return false;
		 int t=0,b=0;
		 GetTopBottom(vCoverX, t, b);
		 R=right;
		 SubConvert(stream,vCoverX,t,b,right);

		 for(unsigned int i=0; i<vCoverX.size(); i++)
		  {
		   delete vCoverX[i];
		  }
		 vCoverX.clear();
		 s="</td>\n";
		 fputs(s.c_str(),stream);
		}
	   s="</tr>\n";
	   fputs(s.c_str(),stream);
	}
   s="</table>\n";
   fputs(s.c_str(),stream);
   BOTTOM=bottom;
  }
 for(unsigned int i=0; i<vTmp.size(); i++)
  {
   delete vTmp[i];
  }
 vTmp.clear();
 return true;
}
//---------------------------------------------------------------------------
bool __fastcall Window::FillHObjVector()
{
 try
  {
   TRect r;
   unsigned int i;
   for(i=0; i<vButton.size(); i++)
	{
	 r.Top=vButton[i]->img->Top;
	 r.Left=vButton[i]->img->Left;
	 r.Right=vButton[i]->img->Left+vButton[i]->img->Width;
	 r.Bottom=vButton[i]->img->Top+vButton[i]->img->Height;
	 HtmlObj* ho=new HtmlObj("BUTTON",r,
				 vButton[i]->pList->GetPropertyValue("CAPTION"));
	 vHObj.push_back(ho);
	}
   for(i=0; i<vLabel.size(); i++)
	{
	 r.Top=vLabel[i]->img->Top;
	 r.Left=vLabel[i]->img->Left;
	 r.Right=vLabel[i]->img->Left+vLabel[i]->img->Width;
	 r.Bottom=vLabel[i]->img->Top+vLabel[i]->img->Height;
	 HtmlObj* ho=new HtmlObj("LABEL",r,
				 vLabel[i]->pList->GetPropertyValue("TEXT"));
	 vHObj.push_back(ho);
	}
   for(i=0; i<vEdit.size(); i++)
	{
	 r.Top=vEdit[i]->img->Top;
	 r.Left=vEdit[i]->img->Left;
	 r.Right=vEdit[i]->img->Left+vEdit[i]->img->Width;
	 r.Bottom=vEdit[i]->img->Top+vEdit[i]->img->Height;
	 HtmlObj* ho=new HtmlObj("EDIT",r,
				 vEdit[i]->pList->GetPropertyValue("TEXT"));
	 vHObj.push_back(ho);
	}
   return true;
  }
 catch(...)
  {
   Application->MessageBox("������ �������������� � HTML!","������!",MB_OK|MB_ICONSTOP);
   return false;
  }
}
//---------------------------------------------------------------------------
bool __fastcall Window::RegulateHObjVectorByY(vector<HtmlObj*>& vHO)
{
 HtmlObj* ho;
 unsigned int size=0;
 try
  {
   size=vHO.size();
   for(unsigned int i=0; i<size; i++)
	{
	 for(unsigned int j=0; j<size; j++)
	  {
	   if(vHO[j]->r.Top>vHO[i]->r.Top)
		{
		 ho=vHO[j];
		 vHO[j]=vHO[i];
		 vHO[i]=ho;
		}
	  }
	}
   return true;
  }
 catch(...)
  {
   Application->MessageBox("������ �������������� � HTML!","������!",MB_OK|MB_ICONSTOP);
   return false;
  }
}
//---------------------------------------------------------------------------
bool __fastcall Window::RegulateHObjVectorByX(vector<HtmlObj*>& vHO)
{
 HtmlObj* ho;
 unsigned int size=0;
 try
  {
   size=vHO.size();
   for(unsigned int i=0; i<size; i++)
	{
	 for(unsigned int j=0; j<size; j++)
	  {
	   if(vHO[j]->r.Left>vHO[i]->r.Left)
		{
		 ho=vHO[j];
		 vHO[j]=vHO[i];
		 vHO[i]=ho;
		}
	  }
	}
   return true;
  }
 catch(...)
  {
   Application->MessageBox("������ �������������� � HTML!","������!",MB_OK|MB_ICONSTOP);
   return false;
  }
}
//---------------------------------------------------------------------------
bool __fastcall Window::CoveringDownByX(HtmlObj* HObj)
{
 try
  {
   for(unsigned int i=0; i<vHOTmp.size(); i++)
	{
//	 ShowMessage("�������� �� ���������� �� � �����: "+vHOTmp[i]->Text+"    "+HObj->Text);
	 if((vHOTmp[i]->r.Right>=HObj->r.Left && vHOTmp[i]->r.Right<=HObj->r.Right) ||
		(vHOTmp[i]->r.Left<=HObj->r.Right && vHOTmp[i]->r.Left>=HObj->r.Left) ||
		(vHOTmp[i]->r.Right>=HObj->r.Left && vHOTmp[i]->r.Right<=HObj->r.Right) ||
		(HObj->r.Left>=vHOTmp[i]->r.Left && HObj->r.Right<=vHOTmp[i]->r.Right))
	  {
	   if(vHOTmp[i]->r.Top>=HObj->r.Bottom)
		{
//		 ShowMessage("������������� �� � ����� �������� "+vHOTmp[i]->Text);
		 return true;
		}
	  }
	}
   return false;
  }
 catch(...)
  {
   Application->MessageBox("������ �������������� � HTML!","������!",MB_OK|MB_ICONSTOP);
   return true;
  }
}
//---------------------------------------------------------------------------
bool __fastcall Window::CoveringUpByX(HtmlObj* HObj)
{
 try
  {
   for(unsigned int i=0; i<vHOTmp.size(); i++)
	{
//	 ShowMessage("�������� �� ���������� �� � ������: "+vHOTmp[i]->Text+"    "+HObj->Text);
	 if((vHOTmp[i]->r.Right>=HObj->r.Left && vHOTmp[i]->r.Right<=HObj->r.Right) ||
		(vHOTmp[i]->r.Left<=HObj->r.Right && vHOTmp[i]->r.Left>=HObj->r.Left) ||
		(vHOTmp[i]->r.Right>=HObj->r.Left && vHOTmp[i]->r.Right<=HObj->r.Right) ||
		(HObj->r.Left>=vHOTmp[i]->r.Left && HObj->r.Right<=vHOTmp[i]->r.Right))
	  {
	   if(vHOTmp[i]->r.Bottom<=HObj->r.Top &&
		  vHOTmp[i]->r.Top!=HObj->r.Top)
		{
//		 ShowMessage("������������� �� � ������ �������� "+vHOTmp[i]->Text);		
		  return true;
		}
	  }
	}
   return false;
  }
 catch(...)
  {
   Application->MessageBox("������ �������������� � HTML!","������!",MB_OK|MB_ICONSTOP);
   return true;
  }
}
//---------------------------------------------------------------------------
bool __fastcall Window::CoveringLeftByY(HtmlObj* HObj, vector<HtmlObj*> vHOSource, int& idx )
{
 idx=-1;
 try
  {
   for(unsigned int i=0; i<vHOSource.size(); i++)
	{
//	 ShowMessage("�������� �� ���������� �� Y �����: "+vHOSource[i]->Text+"    "+HObj->Text);
	 if((vHOSource[i]->r.Top>=HObj->r.Top && vHOSource[i]->r.Top<=HObj->r.Bottom) ||
		(vHOSource[i]->r.Bottom>=HObj->r.Top && vHOSource[i]->r.Bottom<=HObj->r.Bottom) ||
		(HObj->r.Top>=vHOSource[i]->r.Top && HObj->r.Top<=vHOSource[i]->r.Bottom) ||
		(HObj->r.Bottom>=vHOSource[i]->r.Top && HObj->r.Bottom<=vHOSource[i]->r.Bottom))
	  {
	   if(vHOSource[i]->r.Right<=HObj->r.Left)
		{
//		 ShowMessage("������������� �� Y ����� �������� "+vHOSource[i]->Text);
		 idx=i;
		 return true;
		}
	  }
	}
   return false;
  }
 catch(...)
  {
   Application->MessageBox("������ �������������� � HTML!","������!",MB_OK|MB_ICONSTOP);
   return false;
  }
}
//---------------------------------------------------------------------------
bool __fastcall Window::GetCoveringHObjVectorByY(vector<HtmlObj*>& vHOResult,
												 vector<HtmlObj*>& vHOSource)
{
 try
  {
   vHOResult.push_back(vHOSource[0]);
   vHOSource.erase(&vHOSource[0]);
   for(unsigned int j=0; j<vHOResult.size(); j++)
   for(unsigned int i=0; i<vHOSource.size(); i++)
	{
	 if((vHOSource[i]->r.Top>=vHOResult[j]->r.Top && vHOSource[i]->r.Top<=vHOResult[j]->r.Bottom) ||
		(vHOSource[i]->r.Bottom>=vHOResult[j]->r.Top && vHOSource[i]->r.Bottom<=vHOResult[j]->r.Bottom) ||
		(vHOResult[j]->r.Top>=vHOSource[i]->r.Top && vHOResult[j]->r.Top<=vHOSource[i]->r.Bottom) ||
		(vHOResult[j]->r.Bottom>=vHOSource[i]->r.Top && vHOResult[j]->r.Bottom<=vHOSource[i]->r.Bottom))
	  {
	   vHOResult.push_back(vHOSource[i]);
	   vHOSource.erase(&vHOSource[i]);
	   i--;
	  }
	}
   return true;
  }
 catch(...)
  {
   Application->MessageBox("������ �������������� � HTML!","������!",MB_OK|MB_ICONSTOP);
   return false;
  }
}
//---------------------------------------------------------------------------
bool __fastcall Window::GetCoveringHObjVectorByX(vector<HtmlObj*>& vHOResult,
												 vector<HtmlObj*>& vHOSource)
{
 try
  {
   vHOResult.push_back(vHOSource[0]);
   vHOSource.erase(&vHOSource[0]);
   for(unsigned int j=0; j<vHOResult.size(); j++)
   for(unsigned int i=0; i<vHOSource.size(); i++)
	{
	 if((vHOSource[i]->r.Right>=vHOResult[j]->r.Left && vHOSource[i]->r.Right<=vHOResult[j]->r.Right) ||
		(vHOSource[i]->r.Left<=vHOResult[j]->r.Right && vHOSource[i]->r.Left>=vHOResult[j]->r.Left) ||
		(vHOSource[i]->r.Right>=vHOResult[j]->r.Left && vHOSource[i]->r.Right<=vHOResult[j]->r.Right) ||
		(vHOResult[j]->r.Left>=vHOSource[i]->r.Left && vHOResult[j]->r.Right<=vHOSource[i]->r.Right))
	  {
	   vHOResult.push_back(vHOSource[i]);
	   vHOSource.erase(&vHOSource[i]);
	   i--;
	  }
	}
   return true;
  }
 catch(...)
  {
   Application->MessageBox("������ �������������� � HTML!","������!",MB_OK|MB_ICONSTOP);
   return false;
  }
}
//---------------------------------------------------------------------------
bool __fastcall Window::GetTopBottom(vector<HtmlObj*> vHO, int& top, int& bottom)
{
 unsigned int size=0;
 try
  {
   size=vHO.size();
   top=vHO[0]->r.Top;
   bottom=vHO[0]->r.Bottom;
   for(unsigned int i=0; i<size; i++)
	{
	 if(vHO[i]->r.Top<top) top=vHO[i]->r.Top;
	 if(vHO[i]->r.Bottom>bottom) bottom=vHO[i]->r.Bottom;
	}
   return true;
  }
 catch(...)
  {
   Application->MessageBox("������ �������������� � HTML!","������!",MB_OK|MB_ICONSTOP);
   return false;
  }
}
//---------------------------------------------------------------------------
bool __fastcall Window::GetLeftRight(vector<HtmlObj*> vHO, int& left, int& right)
{
 unsigned int size=0;
 try
  {
   size=vHO.size();
   left=vHO[0]->r.Left;
   right=vHO[0]->r.Right;
   for(unsigned int i=0; i<size; i++)
	{
	 if(vHO[i]->r.Left<left) left=vHO[i]->r.Left;
	 if(vHO[i]->r.Right>right) right=vHO[i]->r.Right;
	}
   return true;
  }
 catch(...)
  {
   Application->MessageBox("������ �������������� � HTML!","������!",MB_OK|MB_ICONSTOP);
   return false;
  }
}
//--------------------------------------------------------------------------
void __fastcall Window::GetBounds(AnsiString str,TRect& r)
{
 r.Left=1;
 r.Top=1;
 r.Right=76;
 r.Bottom=26; 
 AnsiString pname, pvalue;
 int i=2;
 while(i<str.Length() && str[i]==' ') i++;
 while(i<str.Length())
  {
   pname=pvalue="";
   while(i<str.Length() && str[i]!='=')
	pname+=str[i++];
   i++;
   while(i<str.Length() && str[i]!='\"') i++;
   i++;
   while(i<str.Length() && str[i]!='\"')
	pvalue+=str[i++];
   while(i<str.Length() && str[i]!=';') i++;
   i++;
   pname=pname.Trim();
   pvalue=pvalue.Trim();
   if(pname.UpperCase()=="LEFT")
    {
	 try {r.Left=StrToInt(pvalue);}
     catch(...) {r.Left=1;}
     continue;
    }
   if(pname.UpperCase()=="TOP")
    {
	 try {r.Top=StrToInt(pvalue);}
     catch(...) {r.Top=1;}
     continue;
    }
   if(pname.UpperCase()=="HEIGHT")
    {
	 try {r.Bottom=r.Top+StrToInt(pvalue);}
	 catch(...) {r.Bottom=26;}
	 continue;
	}
   if(pname.UpperCase()=="WIDTH")
	{
	 try {r.Right=r.Left+StrToInt(pvalue);}
	 catch(...) {r.Right=76;}
     continue;
    }
  }
}
//--------------------------------------------------------------------------
