//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "HtmlObj.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
HtmlObj::HtmlObj()
{
 Type="";
 r=Rect(0,0,0,0);
 Text="";
}
//---------------------------------------------------------------------------
HtmlObj::HtmlObj(AnsiString type, TRect rec, AnsiString text)
{
 Type=type;
 r=rec;
 Text=text;
}
//---------------------------------------------------------------------------
HtmlObj::HtmlObj(HtmlObj* ho)
{
 Type=ho->Type;
 r=ho->r;
 Text=ho->Text;
}
//---------------------------------------------------------------------------

