//---------------------------------------------------------------------------
#ifndef buttonH
#define buttonH
#include "property.h"
//#include "event.h"
#include <vector>
using namespace std;
//---------------------------------------------------------------------------
class Button
{
 private:
  bool move;
  TRect Focus;
  int X0;
  int Y0;
  bool IsLeftSizing;
  bool IsRightSizing;
  bool IsTopSizing;
  bool IsBottomSizing;
  void __fastcall GetSizingType(int x, int y);
  void __fastcall CreateButtonPropertyList(AnsiString str);  
 public:
  Button(int id, int bCnt, bool selected, int startX, int startY, TWinControl* AOwner);
  Button(int id, int bCnt, bool selected, PropertyList* pl, TWinControl* AOwner);
  Button(int id, int bCnt, bool selected, AnsiString props, TWinControl* AOwner);  
  ~Button();
  TImage *img;
  AnsiString Name;
  int Id;
  PropertyList* pList;
  void __fastcall BtnMouseDown(TObject *Sender,TMouseButton Button,
                             TShiftState Shift, int X, int Y);
  void __fastcall BtnMouseUp(TObject *Sender,TMouseButton Button,
                             TShiftState Shift, int X, int Y);
  void __fastcall BtnMouseMove(TObject *Sender, TShiftState Shift,
							   int X, int Y);
  void Draw(AnsiString caption="");
  void DrawSelect(AnsiString caption="");
};
#endif
