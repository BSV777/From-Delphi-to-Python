//---------------------------------------------------------------------
#include <vcl.h>
#include "window.h"
#include "dir.h"
#pragma hdrstop
//---------------------------------------------------------------------
USEFORM("SDIMain.cpp", fMain);
USEFORM("About.cpp", AboutBox);
USERES("sdiapp.res");
USEUNIT("window.cpp");
USEUNIT("property.cpp");
USEFORM("inspect.cpp", fObjInsp);
USEUNIT("button.cpp");
USEUNIT("HtmlObj.cpp");
USEUNIT("label.cpp");
USEUNIT("edit.cpp");
USEFORM("winlist.cpp", fWinList);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR params, int)
{
		AnsiString str(params);
		str=str.Trim();
		if(!str.IsEmpty())
		 {
		  AnsiString file_from;
		  AnsiString file_to;
		  file_from=str.SubString(1,str.Pos(' ')-1);
		  file_from=file_from.Trim();
		  if(file_from.IsEmpty())
		   {
			str="�����������: sdiapp.exe source_file destination_file";
			Application->MessageBox(str.c_str(),"������!",MB_OK|MB_ICONEXCLAMATION);
			return 0;
		   }
		  file_to=str.SubString(str.Pos(' ')+1,str.Length()-1);
		  file_to=file_to.Trim();
		  if(file_to.Pos(' '))
		   file_to=file_to.SubString(1,file_to.Pos(' ')-1);
		  file_to=file_to.Trim();
//		  ShowMessage("|"+file_from+"|"+file_to+"|");
		  if(!FileExists(file_from))
		   {
			str="���� "+file_from+" �� ������!";
			Application->MessageBox(str.c_str(),"������!",MB_OK|MB_ICONSTOP);
			return 0;
		   }
		  if(FileExists(file_to))
		   {
			str="���� "+file_to+" ��� ����������!\n������������ ���?";
			if(Application->MessageBox(str.c_str(),"��������!",
			   MB_YESNO|MB_ICONQUESTION)==IDNO)
			return 0;
		   }
//		  ShowMessage("|"+file_from+"|"+file_to+"|");
		  Window *wnd;
		  wnd=new Window(0,true,file_from);
		  if(!wnd) return 1;
		  wnd->SaveToHtmlFile(file_to);
		  delete wnd;
		  return 0;
		 }
		Application->Initialize();
		Application->CreateForm(__classid(TfMain), &fMain);
		Application->CreateForm(__classid(TAboutBox), &AboutBox);
		Application->CreateForm(__classid(TfObjInsp), &fObjInsp);
		Application->CreateForm(__classid(TfWinList), &fWinList);
		Application->Run();

        return 0;
}
//---------------------------------------------------------------------
