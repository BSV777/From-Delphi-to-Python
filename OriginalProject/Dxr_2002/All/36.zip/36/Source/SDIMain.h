//----------------------------------------------------------------------------
#ifndef SDIMainH
#define SDIMainH
//----------------------------------------------------------------------------
#include <vcl\ComCtrls.hpp>
#include <vcl\ExtCtrls.hpp>
#include <vcl\Buttons.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Dialogs.hpp>
#include <vcl\Menus.hpp>
#include <vcl\Controls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\Graphics.hpp>
#include <vcl\Classes.hpp>
#include <vcl\Windows.hpp>
#include <vcl\System.hpp>
#include <ActnList.hpp>
#include <ImgList.hpp>
#include <StdActns.hpp>
#include <ToolWin.hpp>
#include "window.h"
#include <vector>
using namespace std;
//----------------------------------------------------------------------------
class TfMain : public TForm
{
__published:
        TSaveDialog *dlgSave;
    TActionList *ActionList1;
    TAction *FileOpen1;
    TAction *FileSave1;
    TAction *FileSaveAs1;
    TAction *FileExit1;
    TAction *HelpAbout1;
    TImageList *ImageList1;
    TMainMenu *MainMenu1;
    TMenuItem *File1;
        TMenuItem *New;
    TMenuItem *FileOpenItem;
    TMenuItem *FileSaveItem;
    TMenuItem *FileSaveAsItem;
    TMenuItem *N1;
    TMenuItem *FileExitItem;
    TMenuItem *Help1;
    TMenuItem *HelpAboutItem;
        TAction *actNewWindow;
        TAction *actArray;
        TAction *actNewButton;
        TAction *actNewStatic;
        TAction *actNewEditText;
        TOpenDialog *dlgOpen;
        TMenuItem *CloseAll1;
        TAction *actDeleteWindow;
        TAction *actSaveAll;
        TMenuItem *SaveAll1;
        TPanel *Panel1;
        TPanel *Panel2;
        TPanel *Panel3;
        TSpeedButton *SpeedButton1;
        TSpeedButton *SpeedButton2;
        TSpeedButton *SpeedButton3;
        TSpeedButton *SpeedButton4;
        TSpeedButton *SpeedButton5;
        TPageControl *PageControl1;
        TTabSheet *TabSheet1;
        TSpeedButton *spbNewButton;
        TSpeedButton *spbArrow;
        TSpeedButton *spbNewStatic;
        TSpeedButton *spbNewEditText;
        TBevel *Bevel1;
	TMenuItem *N2;
	TBevel *Bevel2;
	TPanel *Panel4;
	TProgressBar *pbConvert;
	TMenuItem *N3;
	TMenuItem *N4;
	TAction *actCloseAll;
	TAction *actWndList;
	TMenuItem *N5;void __fastcall actNewProjectExecute(TObject *Sender);
        void __fastcall FileOpen1Execute(TObject *Sender);
        void __fastcall FileSaveAs1Execute(TObject *Sender);
        void __fastcall FileExit1Execute(TObject *Sender);
        void __fastcall HelpAbout1Execute(TObject *Sender);
        void __fastcall actNewWindowExecute(TObject *Sender);
        void __fastcall actArrayExecute(TObject *Sender);
        void __fastcall actNewButtonExecute(TObject *Sender);
        void __fastcall actNewStaticExecute(TObject *Sender);
        void __fastcall actNewEditTextExecute(TObject *Sender);
        void __fastcall FileSave1Execute(TObject *Sender);
        void __fastcall SaveProjectAs1Click(TObject *Sender);
        void __fastcall Context1Click(TObject *Sender);
        void __fastcall actDeleteWindowExecute(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
        void __fastcall tbRunClick(TObject *Sender);
	void __fastcall FormShow(TObject *Sender);
	void __fastcall actSaveAllExecute(TObject *Sender);
	void __fastcall N4Click(TObject *Sender);
	void __fastcall actCloseAllExecute(TObject *Sender);
	void __fastcall actWndListExecute(TObject *Sender);
private:
	bool __fastcall CreateNewWindow();
//	bool __fastcall CreateNewWindow(AnsiString caption="", int left=250,
//                                        int top=130, int width=450, int height=350);
	bool __fastcall CreateNewWindow(AnsiString str);
	vector<Window*> vWindows;
	friend class Window;
	friend class Button;
	friend class Label;
	friend class Edit;                	
	friend class TfObjInsp;
	friend class TfWinList;
	bool __fastcall OpenFromFile(AnsiString fname);
	bool __fastcall GetString(FILE* stream,AnsiString& str);
	void __fastcall SaveWindow(int wnum);
    bool __fastcall DeleteWindow(int wnum);		
public:
	virtual __fastcall TfMain(TComponent *AOwner);
    void __fastcall ClearSelect();	
};
//----------------------------------------------------------------------------
extern TfMain *fMain;
//----------------------------------------------------------------------------
#endif
