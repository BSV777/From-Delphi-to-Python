//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "winlist.h"
#include "SDIMain.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfWinList *fWinList;
//---------------------------------------------------------------------------
__fastcall TfWinList::TfWinList(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfWinList::FormShow(TObject *Sender)
{
 lbWindows->Clear();
 wNum=0;
 #define Win fMain->vWindows
 for(unsigned int i=0; i<Win.size(); i++)
  {
   lbWindows->Items->AddObject(Win[i]->wName,Win[i]->wForm);
  }
 #undef Win
 lbWindows->SetFocus();
 if(lbWindows->Items->Count>0)
  {
   lbWindows->ItemIndex=0;
  }
}
//---------------------------------------------------------------------------
void __fastcall TfWinList::FormClose(TObject *Sender, TCloseAction &Action)
{
 lbWindows->Clear();
}
//---------------------------------------------------------------------------
void __fastcall TfWinList::btnOkClick(TObject *Sender)
{
 if(lbWindows->SelCount)
  {
   wNum=((TForm*)lbWindows->Items->Objects[lbWindows->ItemIndex])->Tag;
   ModalResult=mrOk;
  }
}
//---------------------------------------------------------------------------
void __fastcall TfWinList::lbWindowsDblClick(TObject *Sender)
{
 btnOkClick(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TfWinList::lbWindowsKeyPress(TObject *Sender, char &Key)
{
  if(Key=='\r')
   btnOkClick(Sender);
}
//---------------------------------------------------------------------------
