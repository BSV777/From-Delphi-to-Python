//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "edit.h"
#include "inspect.h"
#include "SDIMain.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
Edit::Edit(int id, int eCnt, bool selected, int startX, int startY,
               TWinControl* AOwner)
{
 X0=Y0=0;
 Height=25; 
 IsLeftSizing=IsRightSizing=false;
 IsTopSizing=IsBottomSizing=false;
 img=new TImage(NULL);
 img->OnMouseDown=EdtMouseDown;
 img->OnMouseUp=EdtMouseUp;
 img->OnMouseMove=EdtMouseMove;
 img->Top=startY; img->Left=startX;
 img->Width=75; img->Height=25;
 img->Parent=AOwner;
 Id=id;
 Name="Edit"+IntToStr(eCnt);
 img->Tag=Id;
 img->AutoSize=false;
 pList=new PropertyList;
// pList->Add(*(new Property("Height",2,0,1,IntToStr(img->Height).c_str())));
 pList->Add(*(new Property("Left",2,0,1,IntToStr(img->Left).c_str())));
 pList->Add(*(new Property("Text",1,0,1,Name.c_str()))); 
 pList->Add(*(new Property("Top",2,0,1,IntToStr(img->Top).c_str())));
 pList->Add(*(new Property("Width",2,0,1,IntToStr(img->Width).c_str())));
 move=false;
 if(selected) DrawSelect();
 else Draw();
 img->Show();
}
//---------------------------------------------------------------------------
Edit::Edit(int id, int eCnt, bool selected, PropertyList* pl,
           TWinControl* AOwner)
{
 X0=Y0=0;
 Height=25;
 IsLeftSizing=IsRightSizing=false;
 IsTopSizing=IsBottomSizing=false;
 pList=new PropertyList(*pl);
 img=new TImage(NULL);
 img->OnMouseDown=EdtMouseDown;
 img->OnMouseUp=EdtMouseUp;
 img->OnMouseMove=EdtMouseMove;
 img->Top=StrToInt(pList->GetPropertyValue("Top"));
 img->Left=StrToInt(pList->GetPropertyValue("Left"));
 img->Width=StrToInt(pList->GetPropertyValue("Width"));
// img->Height=StrToInt(pList->GetPropertyValue("Height"));
 img->Height=Height;
 img->Parent=AOwner;
 Id=id;
 Name="Edit"+IntToStr(eCnt);
 img->Tag=Id;
 img->AutoSize=false;
 move=false;
 if(selected) DrawSelect();
 else Draw();
 img->Show();
}
//---------------------------------------------------------------------------
Edit::Edit(int id, int eCnt, bool selected, AnsiString props,
			   TWinControl* AOwner)
{
 X0=Y0=0;
 Height=25;
 IsLeftSizing=IsRightSizing=false;
 IsTopSizing=IsBottomSizing=false;
 CreateEditPropertyList(props);
 img=new TImage(NULL);
 img->OnMouseDown=EdtMouseDown;
 img->OnMouseUp=EdtMouseUp;
 img->OnMouseMove=EdtMouseMove;
 img->Top=StrToInt(pList->GetPropertyValue("Top"));
 img->Left=StrToInt(pList->GetPropertyValue("Left"));
 img->Width=StrToInt(pList->GetPropertyValue("Width"));
// img->Height=StrToInt(pList->GetPropertyValue("Height"));
 img->Height=Height;
 img->Parent=AOwner;
 Id=id;
 Name="Edit"+IntToStr(eCnt);
 img->Tag=Id;
 img->AutoSize=false;
 move=false;
 if(selected) DrawSelect();
 else Draw();
 img->Show();
}
//---------------------------------------------------------------------------
Edit::~Edit()
{
 if(img) delete img;
 if(pList) delete pList;
}
//---------------------------------------------------------------------------
void __fastcall Edit::EdtMouseDown(TObject *Sender,TMouseButton Button,
				     TShiftState Shift, int X, int Y)
{
   if(Button!=mbLeft) return;
   GetSizingType(X,Y);
   if(!IsLeftSizing && !IsRightSizing && !IsTopSizing && !IsBottomSizing)
	{
	 fObjInsp->controlExit();
	 fObjInsp->DeleteControls();
	 fMain->ClearSelect();
	}
   else
	{
	 X0=X; Y0=Y;
	 Focus=img->BoundsRect;
	 return;
	}
   CurrObj.Type="EDIT";
   CurrObj.Idx=Id;

   if(fMain->vWindows[CurrObj.Wnd]->wForm!=img->Parent)
	{
	 for(unsigned int i=0; i<fMain->vWindows.size(); i++)
	  {
	   if(fMain->vWindows[i]->wForm==img->Parent)
		{
		 CurrObj.Wnd=fMain->vWindows[i]->Id;
		 fMain->vWindows[i]->FillCombo(fObjInsp->cbObjects);
		 break;
		}
	  }
	}
   int idx=fObjInsp->FindObjByName(Name);
   Draw();
   if(idx>=0 && fObjInsp->cbObjects->ItemIndex!=idx)
	{
	 fObjInsp->cbObjects->ItemIndex=idx;
	 fObjInsp->ShowObjProperties(*pList);
	}
   img->BringToFront();
   Focus=img->BoundsRect;
   X0=X; Y0=Y;
   move=true;
}
//---------------------------------------------------------------------------
void __fastcall Edit::EdtMouseMove(TObject *Sender, TShiftState Shift,
							 int X, int Y)
{
 if(CurrObj.Type.UpperCase()!="EDIT") return;
 if(move)
  {
   ((TForm*)(img->Parent))->Canvas->DrawFocusRect(Focus);
   Focus.Left+=X-X0;
   Focus.Right+=X-X0;
   Focus.Top+=Y-Y0;
   Focus.Bottom+=Y-Y0;
   X0=X; Y0=Y;
   ((TForm*)(img->Parent))->Canvas->DrawFocusRect(Focus);
  }
 else
  {
   if(IsRightSizing)
	{
	 ((TForm*)(img->Parent))->Canvas->DrawFocusRect(Focus);
	 Focus.Right+=X-X0;
	 ((TForm*)(img->Parent))->Canvas->DrawFocusRect(Focus);
	 if(Focus.Left-Focus.Right>0)
	  {            
	   Focus.Left=img->Left;
	   IsRightSizing=false;
	   IsLeftSizing=true;
	   return;
	  }
	 X0=X;
	}
   if(IsLeftSizing)
	{
	 ((TForm*)(img->Parent))->Canvas->DrawFocusRect(Focus);
	 Focus.Left+=X-X0;
	 ((TForm*)(img->Parent))->Canvas->DrawFocusRect(Focus);
	 if(Focus.Left-Focus.Right>0)
	  {
	   Focus.Left=img->Left+img->Width;	  
	   IsRightSizing=true;
	   IsLeftSizing=false;
	   return;
	  }
	 X0=X;
	}
   if(IsTopSizing)
	{
	 ((TForm*)(img->Parent))->Canvas->DrawFocusRect(Focus);
	 Focus.Top+=Y-Y0;
	 ((TForm*)(img->Parent))->Canvas->DrawFocusRect(Focus);
	 if(Focus.Top-Focus.Bottom>0)
	  {
	   Focus.Top=img->Top+img->Height;
	   IsTopSizing=false;
	   IsBottomSizing=true;
	   return;
	  }
	 Y0=Y;
	}
   if(IsBottomSizing)
	{
	 ((TForm*)(img->Parent))->Canvas->DrawFocusRect(Focus);
	 Focus.Bottom+=Y-Y0;
	 ((TForm*)(img->Parent))->Canvas->DrawFocusRect(Focus);
	 if(Focus.Top-Focus.Bottom>0)
	  {
	   Focus.Top=img->Top;
	   IsTopSizing=true;
	   IsBottomSizing=false;
	   return;
	  }
	 Y0=Y;
	}
  }
}
//---------------------------------------------------------------------------
void __fastcall Edit::EdtMouseUp(TObject *Sender,TMouseButton Button,
				   TShiftState Shift, int X, int Y)
{
 if(CurrObj.Type.UpperCase()!="EDIT") return;
 ((TForm*)(img->Parent))->Canvas->DrawFocusRect(Focus);
 #define Win fMain->vWindows[CurrObj.Wnd]
 TRect r;
 if(move)
  {
   move=false;
   r.Left=Focus.Left+X-X0;
   r.Top=Focus.Top+Y-Y0;
   r.Right=r.Left+((TControl*)Sender)->Width;
   r.Bottom=r.Top+((TControl*)Sender)->Height;
   if(!Win->ResizeImposition(r))
	{
	 ((TControl*)Sender)->SetBounds(Focus.Left+X-X0,Focus.Top+Y-Y0,
					((TControl*)Sender)->Width,
					((TControl*)Sender)->Height);
	 Win->Modified=true;					
	}
   else
	  Application->MessageBox("��������� �������� �����������!","��������!",
				   MB_OK|MB_ICONEXCLAMATION);
  }
 if(IsLeftSizing || IsRightSizing || IsTopSizing || IsBottomSizing)
  {
   IsLeftSizing=IsRightSizing=false;
   IsTopSizing=IsBottomSizing=false;
   if(!Win->ResizeImposition(TRect(Focus.Left,Focus.Top,
				   Focus.Right,Focus.Bottom)))
	{
	 ((TControl*)Sender)->SetBounds(Focus.Left,Focus.Top,
					Focus.Right-Focus.Left,
					Focus.Bottom-Focus.Top);
	 Win->Modified=true;					
	}
   else
	  Application->MessageBox("��������� �������� �����������!","��������!",
								   MB_OK|MB_ICONEXCLAMATION);
  }
 pList->SetPropertyValue("LEFT",IntToStr(img->Left));
 pList->SetPropertyValue("TOP",IntToStr(img->Top));
 pList->SetPropertyValue("WIDTH",IntToStr(img->Width));
// pList->SetPropertyValue("HEIGHT",IntToStr(img->Height));
 int i=pList->GetPropertyIdxByName("LEFT");
 fObjInsp->sgPropertys->Cells[1][i]=IntToStr(img->Left);
 i=pList->GetPropertyIdxByName("TOP");
 fObjInsp->sgPropertys->Cells[1][i]=IntToStr(img->Top);
 i=pList->GetPropertyIdxByName("WIDTH");
 fObjInsp->sgPropertys->Cells[1][i]=IntToStr(img->Width);
// i=pList->GetPropertyIdxByName("HEIGHT");
// fObjInsp->sgPropertys->Cells[1][i]=IntToStr(img->Height);
 DrawSelect(); 
}
//---------------------------------------------------------------------------
void Edit::Draw(AnsiString caption)
{
 img->Picture->Assign(NULL);
 img->Update();

 img->Canvas->Brush->Color = clWhite;
 img->Canvas->FillRect(Rect(0,0,img->Width,img->Height));

// img->Canvas->Brush->Color = clBtnFace;
 img->Canvas->Brush->Color = clWindow;
 img->Canvas->FillRect(Rect(2,2,img->Width-2,img->Height-2));

 img->Canvas->Brush->Color = clBlack;
 img->Canvas->MoveTo(0,0);
 img->Canvas->LineTo(img->Width-1,0);
 img->Canvas->MoveTo(1,1);
 img->Canvas->LineTo(img->Width-2,1);

 img->Canvas->MoveTo(0,0);
 img->Canvas->LineTo(0,img->Height);
 img->Canvas->MoveTo(1,1);
 img->Canvas->LineTo(1,img->Height-1);

 img->Canvas->Pen->Color = clGray;
 img->Canvas->MoveTo(2,img->Height-2);
 img->Canvas->LineTo(img->Width-2,img->Height-2);
 img->Canvas->MoveTo(img->Width-2,2);
 img->Canvas->LineTo(img->Width-2,img->Height-2);

 if(caption.IsEmpty())
  caption=pList->GetPropertyValue("TEXT");
 img->Canvas->Brush->Color = clWindow;
 int y=img->Height/2-(img->Canvas->TextHeight(caption)/2);
 img->Canvas->TextRect(Rect(3,3,img->Width-3,img->Height-3),3, y, caption);
}
//---------------------------------------------------------------------------
void Edit::DrawSelect(AnsiString caption)
{
 img->Picture->Assign(NULL);
 img->Update();

 img->Canvas->Brush->Color = clWhite;
 img->Canvas->FillRect(Rect(0,0,img->Width,img->Height));

 img->Canvas->Brush->Color = clWindow;
 img->Canvas->FillRect(Rect(2,2,img->Width-2,img->Height-2));

 img->Canvas->Brush->Color = clBlack;
 img->Canvas->MoveTo(0,0);
 img->Canvas->LineTo(img->Width-1,0);
 img->Canvas->MoveTo(1,1);
 img->Canvas->LineTo(img->Width-2,1);

 img->Canvas->MoveTo(0,0);
 img->Canvas->LineTo(0,img->Height);
 img->Canvas->MoveTo(1,1);
 img->Canvas->LineTo(1,img->Height-1);

 img->Canvas->Pen->Color = clGray;
 img->Canvas->MoveTo(2,img->Height-2);
 img->Canvas->LineTo(img->Width-2,img->Height-2);
 img->Canvas->MoveTo(img->Width-2,2);
 img->Canvas->LineTo(img->Width-2,img->Height-2);

 if(caption.IsEmpty())
  caption=pList->GetPropertyValue("TEXT");
 img->Canvas->Brush->Color = clWindow;
 int y=img->Height/2-(img->Canvas->TextHeight(caption)/2);
 img->Canvas->TextRect(Rect(3,3,img->Width-3,img->Height-3),3, y, caption);
 y=img->Height/2;
 img->Canvas->Brush->Color = clBlack;
 img->Canvas->FillRect(Rect(0,y-3,6,y+3));
 img->Canvas->FillRect(Rect(img->Width-6,y-3,img->Width,y+3));
}
//---------------------------------------------------------------------------
void __fastcall Edit::GetSizingType(int x, int y)
{
 IsTopSizing=IsBottomSizing=IsLeftSizing=IsRightSizing=false;
// int x1=img->Width/2;
 int y1=img->Height/2;
/* if((x>=x1-3 && x<=x1+3) && ((y>=0 && y<=6)||(y>=img->Height-6 && y<=img->Height)))
  {
   if(y>=0 && y<=6) IsTopSizing=true;
   else if(y>=img->Height-6 && y<=img->Height) IsBottomSizing=true;
   return;
  }*/
 if(y>=y1-3 && y<=y1+3)
  {
   if(x>=0 && x<=6)	IsLeftSizing=true;
   else if(x>=img->Width-6 && x<=img->Width) IsRightSizing=true;
  }
}
//---------------------------------------------------------------------------
void __fastcall Edit::CreateEditPropertyList(AnsiString str)
{
 int left=1;
 int top=1;
 int width=75;
// int height=25;
 AnsiString caption;
 AnsiString pname, pvalue;
 int i=2;
 while(i<str.Length() && str[i]==' ') i++;
 while(i<str.Length())
  {
   pname=pvalue="";
   while(i<str.Length() && str[i]!='=')
    pname+=str[i++];
   i++;
   while(i<str.Length() && str[i]!='\"') i++;
   i++;
   while(i<str.Length() && str[i]!='\"')
    pvalue+=str[i++];
   while(i<str.Length() && str[i]!=';') i++;
   i++;
   pname=pname.Trim();
   pvalue=pvalue.Trim();
   if(pname.UpperCase()=="LEFT")
    {
     try {left=StrToInt(pvalue);}
	 catch(...) {left=1;}
	 continue;
	}
   if(pname.UpperCase()=="TOP")
	{
	 try {top=StrToInt(pvalue);}
	 catch(...) {top=1;}
	 continue;
	}
   if(pname.UpperCase()=="WIDTH")
	{
	 try {width=StrToInt(pvalue);}
	 catch(...) {width=75;}
	 continue;
	}
   if(pname.UpperCase()=="TEXT")
	{
	 try
	  {
	   if(pvalue.Length()>255)
		pvalue=pvalue.SubString(1,255);
	   caption=pvalue;
	  }
	 catch(...) {caption="";}
	 continue;
	}
  }
 pList=new PropertyList();
// pList->Add(*(new Property("Height",2,0,1,IntToStr(height).c_str())));
 pList->Add(*(new Property("Left",2,0,1,IntToStr(left).c_str())));
 pList->Add(*(new Property("Text",1,0,1,caption.c_str()))); 
 pList->Add(*(new Property("Top",2,0,1,IntToStr(top).c_str())));
 pList->Add(*(new Property("Width",2,0,1,IntToStr(width).c_str())));
}
//---------------------------------------------------------------------------
