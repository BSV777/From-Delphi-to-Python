//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "inspect.h"
#include "window.h"
#include "SDIMain.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfObjInsp *fObjInsp;
CurrentObject CurrObj;
const int MAX_STR_LENGTH=255;
//---------------------------------------------------------------------------
__fastcall TfObjInsp::TfObjInsp(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfObjInsp::ShowObjProperties(PropertyList pList)
{
 if(pType && cmp)
  {
   switch(pType)
	{
	 case 1:
	 case 2:
	  delete (TEdit*)cmp;
	 break;
	 case 3:
	  delete (TComboBox*)cmp;
	 break;
	}
   pType=0;
  }
// vector<Property>::iterator vi;
 sgPropertys->ColCount=1;
 sgPropertys->RowCount=1;
/* for(vi=pList.vProperties.begin();vi!=pList.vProperties.end();++vi)
  {
   sgPropertys->RowCount++;
   sgPropertys->Cells[0][vi-pList.vProperties.begin()]=vi->pName;
   sgPropertys->Cells[1][vi-pList.vProperties.begin()]=vi->pValues[vi->selIndex];
  }*/
 for(int i=0; i<pList.ListSize(); i++)
  {
   sgPropertys->ColCount=2;
   sgPropertys->FixedCols=1;
   sgPropertys->RowCount++;
   sgPropertys->Cells[0][i]=pList.GetPropertyNameByIdx(i);
   sgPropertys->Cells[1][i]=pList.GetPropertyValue(i);
  }
 sgPropertys->RowCount--;
 sgPropertys->ColWidths[1]=sgPropertys->Width-sgPropertys->ColWidths[0];
// sgPropertys->Row=-1;
/* if(sel<props.size())
  {
   bool CanSelect=false;
   sgPropertysSelectCell(NULL, 1, sel, CanSelect);
//   ShowMessage(sel);
  }*/
}
//---------------------------------------------------------------------------
void __fastcall TfObjInsp::FormShow(TObject *Sender)
{
//
}
//---------------------------------------------------------------------------

void __fastcall TfObjInsp::FormCreate(TObject *Sender)
{
  RECT rwa;
  ::SystemParametersInfo(SPI_GETWORKAREA, 0, &rwa, 0);
  SetBounds(rwa.left, fMain->Height+20, Width, Height);

 ItemHeight=21;
 ItemWidth=100;
 DataItemWidth=100;
 pType=0;
 sgPropertys->DefaultColWidth=ItemWidth;
 sgPropertys->DefaultRowHeight=ItemHeight;
}
//---------------------------------------------------------------------------

void __fastcall TfObjInsp::FormResize(TObject *Sender)
{
 sgPropertys->ColWidths[1]=sgPropertys->Width-sgPropertys->ColWidths[0];
 if(pType && cmp)
  {
   switch(pType)
	{
	 case 1:
	 case 2:
	  ((TEdit*)cmp)->Width=sgPropertys->ColWidths[1]-4;
	 break;
	 case 3:
	  ((TComboBox*)cmp)->Width=sgPropertys->ColWidths[1]-4;
	 break;
	}
  }
}
//---------------------------------------------------------------------------

void __fastcall TfObjInsp::sgPropertysSelectCell(TObject *Sender, int ACol,
	  int ARow, bool &CanSelect)
{
 if(cbObjects->Items->Count==0 || ACol==0 || sgPropertys->Row<0) return;
 if(pType && cmp)
  {
   switch(pType)
	{
	 case 1:
	 case 2:
	  delete (TEdit*)cmp;
	 break;
	 case 3:
	  delete (TComboBox*)cmp;
	 break;
	}
   pType=0;
  }
 pType=GetPropertyType(ARow);

 TRect r;
 r=sgPropertys->CellRect(ACol,ARow);

 if(pType==1 || pType==2)
  {
   cmp = new TEdit((TComponent*)NULL);
   ((TEdit*)cmp)->Visible=false;
   ((TEdit*)cmp)->Parent=tshPropertys;//sgPropertys;
   ((TEdit*)cmp)->Left=r.Left+2;
   ((TEdit*)cmp)->Top=r.Top+2;
   ((TEdit*)cmp)->Width=r.Right-r.Left;
   ((TEdit*)cmp)->Height=r.Bottom-r.Top+6;
   ((TEdit*)cmp)->OnExit=edExit;
   ((TEdit*)cmp)->OnKeyUp=edKeyUp;
   /*if(pType==2)*/ ((TEdit*)cmp)->OnKeyPress=edKeyPress;
   ((TEdit*)cmp)->OnChange=edChange;
   ((TEdit*)cmp)->Clear();
  }
 if(pType==3)
  {
   cmp = new TComboBox((TComponent*)NULL);
   ((TComboBox*)cmp)->Visible=false;
   ((TComboBox*)cmp)->Parent=tshPropertys;//sgPropertys;
   ((TComboBox*)cmp)->Left=r.Left+2;
   ((TComboBox*)cmp)->Top=r.Top+2;
   ((TComboBox*)cmp)->Width=r.Right-r.Left;
   ((TComboBox*)cmp)->Height=r.Bottom-r.Top+6;
   ((TComboBox*)cmp)->ItemHeight=13;
   ((TComboBox*)cmp)->OnExit=cbExit;
   ((TComboBox*)cmp)->OnChange=cbChange;
   ((TComboBox*)cmp)->OnKeyUp=cbKeyUp;
   ((TComboBox*)cmp)->Items->Clear();
  }

 if(CurrObj.Type=="WINDOW")
 {
  #define Win fMain->vWindows[CurrObj.Idx]
  if(pType==1 || pType==2)
   {
	((TEdit*)cmp)->Text=Win->pList->GetPropertyValue(ARow);
	((TEdit*)cmp)->Visible=true;
	((TEdit*)cmp)->SetFocus();        
   }
  if(pType==3)
   {
	for(int i=0; i<Win->pList->PropertySize(ARow); i++)
	 {
	  ((TComboBox*)cmp)->Items->Add(Win->pList->GetPropertyItem(ARow,i));
	 }
	((TComboBox*)cmp)->ItemIndex=Win->pList->GetPropertySelected(ARow);
	((TComboBox*)cmp)->Style=csDropDownList;
	((TComboBox*)cmp)->Visible=true;
	((TComboBox*)cmp)->SetFocus();
	#undef Win
   }
  return;
 }
 if(CurrObj.Type=="BUTTON")
 {
  #define Btn fMain->vWindows[CurrObj.Wnd]->vButton[CurrObj.Idx]
  if(pType==1 || pType==2)
   {
	((TEdit*)cmp)->Text=Btn->pList->GetPropertyValue(ARow);
	((TEdit*)cmp)->Visible=true;
	((TEdit*)cmp)->SetFocus();
   }
  if(pType==3)
   {
	for(int i=0; i<Btn->pList->PropertySize(ARow); i++)
	 {
	  ((TComboBox*)cmp)->Items->Add(Btn->pList->GetPropertyItem(ARow,i));
	 }
	((TComboBox*)cmp)->ItemIndex=Btn->pList->GetPropertySelected(ARow);
	((TComboBox*)cmp)->Style=csDropDownList;
	((TComboBox*)cmp)->Visible=true;
	((TComboBox*)cmp)->SetFocus();
	#undef Btn
   }
  return;
 }
 if(CurrObj.Type=="LABEL")
 {
  #define Lbl fMain->vWindows[CurrObj.Wnd]->vLabel[CurrObj.Idx]
  if(pType==1 || pType==2)
   {
	((TEdit*)cmp)->Text=Lbl->pList->GetPropertyValue(ARow);
	((TEdit*)cmp)->Visible=true;
	((TEdit*)cmp)->SetFocus();
   }
  if(pType==3)
   {
	for(int i=0; i<Lbl->pList->PropertySize(ARow); i++)
	 {
	  ((TComboBox*)cmp)->Items->Add(Lbl->pList->GetPropertyItem(ARow,i));
	 }
	((TComboBox*)cmp)->ItemIndex=Lbl->pList->GetPropertySelected(ARow);
	((TComboBox*)cmp)->Style=csDropDownList;
	((TComboBox*)cmp)->Visible=true;
	((TComboBox*)cmp)->SetFocus();
	#undef Lbl
   }
  return;
 }
 if(CurrObj.Type=="EDIT")
 {
  #define Edt fMain->vWindows[CurrObj.Wnd]->vEdit[CurrObj.Idx]
  if(pType==1 || pType==2)
   {
	((TEdit*)cmp)->Text=Edt->pList->GetPropertyValue(ARow);
	((TEdit*)cmp)->Visible=true;
	((TEdit*)cmp)->SetFocus();
   }
  if(pType==3)
   {
	for(int i=0; i<Edt->pList->PropertySize(ARow); i++)
	 {
	  ((TComboBox*)cmp)->Items->Add(Edt->pList->GetPropertyItem(ARow,i));
	 }
	((TComboBox*)cmp)->ItemIndex=Edt->pList->GetPropertySelected(ARow);
	((TComboBox*)cmp)->Style=csDropDownList;
	((TComboBox*)cmp)->Visible=true;
	((TComboBox*)cmp)->SetFocus();
	#undef Edt
   }
  return;
 }
}
//---------------------------------------------------------------------------
int __fastcall TfObjInsp::GetPropertyType(int idx)
{
/* int ind=0;
 AnsiString str(cbObjects->Text);
 str=str.SubString(str.Pos(":")+1,str.Length());
 str=str.Trim().UpperCase();*/
 #define Win fMain->vWindows[CurrObj.Wnd]
 if(CurrObj.Type=="WINDOW")
 {
  return Win->pList->GetPropertyType(idx);
 }
 if(CurrObj.Type=="BUTTON")
 {
  return Win->vButton[CurrObj.Idx]->pList->GetPropertyType(idx);
 }
 if(CurrObj.Type=="LABEL")
 {
  return Win->vLabel[CurrObj.Idx]->pList->GetPropertyType(idx);
 }
 if(CurrObj.Type=="EDIT")
 {
  return Win->vEdit[CurrObj.Idx]->pList->GetPropertyType(idx);
 }
 #undef Win
 return -1;
}
//---------------------------------------------------------------------------
void __fastcall TfObjInsp::cbObjectsChange(TObject *Sender)
{
// ShowMessage("Change");
 ClearSelect();
 int ind=0;
 AnsiString str(cbObjects->Text);
 str=str.SubString(str.Pos(":")+1,str.Length());
 str=str.Trim().UpperCase();
 CurrObj.Type=str;
 if(str=="WINDOW")
  {
   CurrObj.Idx=CurrObj.Wnd;
   if(!fMain->vWindows[CurrObj.Idx]->wForm->Visible) fMain->vWindows[CurrObj.Idx]->wForm->Show();
   ShowObjProperties(*(fMain->vWindows[CurrObj.Idx]->pList));
   fMain->vWindows[CurrObj.Idx]->wForm->SetFocus();
   return;
  }
 if(str=="BUTTON")
  {
   ind=((TImage*)fObjInsp->cbObjects->Items->
		Objects[fObjInsp->cbObjects->ItemIndex])->Tag;
   CurrObj.Idx=ind;		
   #define Btn fMain->vWindows[CurrObj.Wnd]->vButton[CurrObj.Idx]
	ShowObjProperties(*(Btn->pList));
	Btn->DrawSelect();
   #undef Btn
   return;
  }
 if(str=="LABEL")
  {
   ind=((TImage*)fObjInsp->cbObjects->Items->
		Objects[fObjInsp->cbObjects->ItemIndex])->Tag;
   CurrObj.Idx=ind;
   #define Lbl fMain->vWindows[CurrObj.Wnd]->vLabel[CurrObj.Idx]
    ShowObjProperties(*(Lbl->pList));
    Lbl->DrawSelect();
   #undef Lbl
   return;   
  }
 if(str=="EDIT")
  {
   ind=((TImage*)fObjInsp->cbObjects->Items->
		Objects[fObjInsp->cbObjects->ItemIndex])->Tag;
   CurrObj.Idx=ind;
   #define Edt fMain->vWindows[CurrObj.Wnd]->vEdit[CurrObj.Idx]
	ShowObjProperties(*(Edt->pList));
	Edt->DrawSelect();
   #undef Edt
   return;
  }
}
//---------------------------------------------------------------------------
int __fastcall TfObjInsp::FindObjByName(AnsiString name)
{
 AnsiString str("");
 for(int i=0; i<cbObjects->Items->Count; i++)
  {
   str=cbObjects->Items->Strings[i];
   str=str.SubString(1,str.Pos(":")-1);
   str=str.Trim().UpperCase();
   if(str==name.UpperCase())
	{
 //    ShowMessage(str);
	 return i;
	}
  }
 return -1;
}
//---------------------------------------------------------------------------
void __fastcall TfObjInsp::sgPropertysTopLeftChanged(TObject *Sender)
{
 if(pType && cmp)
  {
   switch(pType)
	{
	 case 1:
	 case 2:
	  delete (TEdit*) cmp;
	 break;
	 case 3:
	  delete (TComboBox*) cmp;
	 break;
	}
   pType=0;
  }
}
//---------------------------------------------------------------------------
void __fastcall TfObjInsp::cbChange(TObject *Sender)
{
 #define Win fMain->vWindows[CurrObj.Wnd]
 if(CurrObj.Type=="WINDOW")
  {
   Win->pList->SetPropertyValue(sgPropertys->Row,((TComboBox*)cmp)->Text);
   sgPropertys->Cells[1][sgPropertys->Row]=((TComboBox*)cmp)->Text;
   Win->Modified=true;
  }
 if(CurrObj.Type=="BUTTON")
  {
   #define Btn fMain->vWindows[CurrObj.Wnd]->vButton[CurrObj.Idx]
   Btn->pList->SetPropertyValue(sgPropertys->Row,((TComboBox*)cmp)->Text);
   sgPropertys->Cells[1][sgPropertys->Row]=((TComboBox*)cmp)->Text;
   Win->Modified=true;
   #undef Btn
  }
 if(CurrObj.Type=="LABEL")
  {
   #define Lbl fMain->vWindows[CurrObj.Wnd]->vLabel[CurrObj.Idx]
   Lbl->pList->SetPropertyValue(sgPropertys->Row,((TComboBox*)cmp)->Text);
   sgPropertys->Cells[1][sgPropertys->Row]=((TComboBox*)cmp)->Text;
   Win->Modified=true;
   #undef Lbl
  }
 if(CurrObj.Type=="EDIT")
  {
   #define Edt fMain->vWindows[CurrObj.Wnd]->vEdit[CurrObj.Idx]
   Edt->pList->SetPropertyValue(sgPropertys->Row,((TComboBox*)cmp)->Text);
   sgPropertys->Cells[1][sgPropertys->Row]=((TComboBox*)cmp)->Text;
   Win->Modified=true;
   #undef Edt
  }
 #undef Win
}
//---------------------------------------------------------------------------
void __fastcall TfObjInsp::cbExit(TObject *Sender)
{
/* #define Win fMain->vWindows[CurrObj.Wnd]
 if(CurrObj.Type=="WINDOW")
  {
   Win->pList->SetPropertyValue(sgPropertys->Row,((TComboBox*)cmp)->Text);
   sgPropertys->Cells[1][sgPropertys->Row]=((TComboBox*)cmp)->Text;
   Win->Modified=true;
  }
 if(CurrObj.Type=="BUTTON")
  {
   #define Btn fMain->vWindows[CurrObj.Wnd]->vButton[CurrObj.Idx]
   Btn->pList->SetPropertyValue(sgPropertys->Row,((TComboBox*)cmp)->Text);
   sgPropertys->Cells[1][sgPropertys->Row]=((TComboBox*)cmp)->Text;
   Win->Modified=true;
   #undef Btn
  }
 if(CurrObj.Type=="LABEL")
  {
   #define Lbl fMain->vWindows[CurrObj.Wnd]->vLabel[CurrObj.Idx]
   Lbl->pList->SetPropertyValue(sgPropertys->Row,((TComboBox*)cmp)->Text);
   sgPropertys->Cells[1][sgPropertys->Row]=((TComboBox*)cmp)->Text;
   Win->Modified=true;
   #undef Lbl
  }
 if(CurrObj.Type=="EDIT")
  {
   #define Edt fMain->vWindows[CurrObj.Wnd]->vEdit[CurrObj.Idx]
   Edt->pList->SetPropertyValue(sgPropertys->Row,((TComboBox*)cmp)->Text);
   sgPropertys->Cells[1][sgPropertys->Row]=((TComboBox*)cmp)->Text;
   Win->Modified=true;
   #undef Edt
  }
 #undef Win*/
}
//---------------------------------------------------------------------------
void __fastcall TfObjInsp::edExit(TObject *Sender)
{
 int ind=0;
 AnsiString val=0;
/* AnsiString str(cbObjects->Text);
 str=str.SubString(str.Pos(":")+1,str.Length());
 str=str.Trim().UpperCase();*/
 #define Win fMain->vWindows[CurrObj.Wnd]
 if(CurrObj.Type=="WINDOW")
  {
/*  ind=((TForm*)fObjInsp->cbObjects->Items->
	  Objects[fObjInsp->cbObjects->ItemIndex])->Tag;*/
//   ShowMessage(sgPropertys->Row);
   if(Win->pList->GetPropertyNameByIdx(sgPropertys->Row).UpperCase()=="LEFT")
    {
     try
      {
       Win->wForm->Left=StrToInt(((TEdit*)cmp)->Text);
      }
     catch(...)
      {
       val=Win->pList->GetPropertyValue("LEFT");
	   ((TEdit*)cmp)->Text=val;
       Win->wForm->Left=StrToInt(val);
      }
    }
   else
   if(Win->pList->GetPropertyNameByIdx(sgPropertys->Row).UpperCase()=="TOP")
    {
     try
      {
       Win->wForm->Top=StrToInt(((TEdit*)cmp)->Text);
	  }
     catch(...)
      {
       val=Win->pList->GetPropertyValue("TOP");
       ((TEdit*)cmp)->Text=val;
       Win->wForm->Left=StrToInt(val);
      }
    }
   else
   if(Win->pList->GetPropertyNameByIdx(sgPropertys->Row).UpperCase()=="WIDTH")
    {
     try
      {
       Win->wForm->Width=StrToInt(((TEdit*)cmp)->Text);
      }
     catch(...)
      {
       val=Win->pList->GetPropertyValue("WIDTH");
       ((TEdit*)cmp)->Text=val;
       Win->wForm->Left=StrToInt(val);
      }
    }
   else
   if(Win->pList->GetPropertyNameByIdx(sgPropertys->Row).UpperCase()=="HEIGHT")
    {
     try
      {
       Win->wForm->Height=StrToInt(((TEdit*)cmp)->Text);
	  }
     catch(...)
      {
       val=Win->pList->GetPropertyValue("HEIGHT");
       ((TEdit*)cmp)->Text=val;
       Win->wForm->Left=StrToInt(val);
      }
    }
   Win->pList->SetPropertyValue(sgPropertys->Row,((TEdit*)cmp)->Text);
   sgPropertys->Cells[1][sgPropertys->Row]=((TEdit*)cmp)->Text;
   return;
  }
// ind=((TForm*)fObjInsp->cbObjects->Items->
//	  Objects[fObjInsp->cbObjects->ItemIndex])->Tag;
 ind=CurrObj.Idx;
 TRect r;
 if(CurrObj.Type=="BUTTON")
  {
   r.Left=Win->vButton[ind]->img->Left;
   r.Top=Win->vButton[ind]->img->Top;
   r.Right=Win->vButton[ind]->img->Left+Win->vButton[ind]->img->Width;
   r.Bottom=Win->vButton[ind]->img->Top+Win->vButton[ind]->img->Height;
   if(Win->vButton[ind]->pList->GetPropertyNameByIdx(sgPropertys->Row).UpperCase()=="LEFT")
    {
     try
      {
       r.Left=StrToInt(((TEdit*)cmp)->Text);
       r.Right=r.Left+Win->vButton[ind]->img->Width;
	   if(Win->ResizeImposition(r))
        {
         Application->MessageBox("��������� �������� �����������!","��������!",
                                 MB_OK|MB_ICONEXCLAMATION);
         ((TEdit*)cmp)->Text=Win->vButton[ind]->pList->GetPropertyValue("LEFT");
         return;
        }
       Win->vButton[ind]->img->Left=StrToInt(((TEdit*)cmp)->Text);
      }
     catch(...)
      {
       val=Win->vButton[ind]->pList->GetPropertyValue("LEFT");
       ((TEdit*)cmp)->Text=val;
       Win->vButton[ind]->img->Left=StrToInt(val);
      }
    }
   else
   if(Win->vButton[ind]->pList->GetPropertyNameByIdx(sgPropertys->Row).UpperCase()=="TOP")
    {
     try
      {
       r.Top=StrToInt(((TEdit*)cmp)->Text);
       r.Bottom=r.Top+Win->vButton[ind]->img->Height;
       if(Win->ResizeImposition(r))
        {
         Application->MessageBox("��������� �������� �����������!","��������!",
                                 MB_OK|MB_ICONEXCLAMATION);
         ((TEdit*)cmp)->Text=Win->vButton[ind]->pList->GetPropertyValue("TOP");
		 return;
        }
       Win->vButton[ind]->img->Top=StrToInt(((TEdit*)cmp)->Text);
      }
     catch(...)
      {
       val=Win->vButton[ind]->pList->GetPropertyValue("TOP");
       ((TEdit*)cmp)->Text=val;
       Win->vButton[ind]->img->Top=StrToInt(val);
      } 
    }
   else
   if(Win->vButton[ind]->pList->GetPropertyNameByIdx(sgPropertys->Row).UpperCase()=="WIDTH")
    {
     try
      {
       r.Right=r.Left+StrToInt(((TEdit*)cmp)->Text);
       if(Win->ResizeImposition(r))
        {
         Application->MessageBox("��������� �������� �����������!","��������!",
                                 MB_OK|MB_ICONEXCLAMATION);
         ((TEdit*)cmp)->Text=Win->vButton[ind]->pList->GetPropertyValue("WIDTH");
         return;
        }
       Win->vButton[ind]->img->Width=StrToInt(((TEdit*)cmp)->Text);
      }
     catch(...)
      {
	   val=Win->vButton[ind]->pList->GetPropertyValue("WIDTH");
       ((TEdit*)cmp)->Text=val;
       Win->vButton[ind]->img->Width=StrToInt(val);
      }
     Win->vButton[ind]->img->Update();
     Win->vButton[ind]->DrawSelect();
    }
   else
   if(Win->vButton[ind]->pList->GetPropertyNameByIdx(sgPropertys->Row).UpperCase()=="HEIGHT")
    {
     try
      {
       r.Bottom=r.Top+StrToInt(((TEdit*)cmp)->Text);
       if(Win->ResizeImposition(r))
        {
         Application->MessageBox("��������� �������� �����������!","��������!",
                                 MB_OK|MB_ICONEXCLAMATION);
         ((TEdit*)cmp)->Text=Win->vButton[ind]->pList->GetPropertyValue("HEIGHT");
         return;
        }
       Win->vButton[ind]->img->Height=StrToInt(((TEdit*)cmp)->Text);
      }
     catch(...)
      {
       val=Win->vButton[ind]->pList->GetPropertyValue("HEIGHT");
       ((TEdit*)cmp)->Text=val;
       Win->vButton[ind]->img->Height=StrToInt(val);
      }
	 Win->vButton[ind]->img->Update();
     Win->vButton[ind]->DrawSelect();
    }
   Win->vButton[ind]->pList->SetPropertyValue(sgPropertys->Row,((TEdit*)cmp)->Text);
   sgPropertys->Cells[1][sgPropertys->Row]=((TEdit*)cmp)->Text;        
   return;
  }
 if(CurrObj.Type=="LABEL")
  {
   r.Left=Win->vLabel[ind]->img->Left;
   r.Top=Win->vLabel[ind]->img->Top;
   r.Right=Win->vLabel[ind]->img->Left+Win->vLabel[ind]->img->Width;
   r.Bottom=Win->vLabel[ind]->img->Top+Win->vLabel[ind]->img->Height;
   if(Win->vLabel[ind]->pList->GetPropertyNameByIdx(sgPropertys->Row).UpperCase()=="LEFT")
    {
     try
      {
       r.Left=StrToInt(((TEdit*)cmp)->Text);
       r.Right=r.Left+Win->vLabel[ind]->img->Width;
       if(Win->ResizeImposition(r))
        {
         Application->MessageBox("��������� �������� �����������!","��������!",
                                 MB_OK|MB_ICONEXCLAMATION);
         ((TEdit*)cmp)->Text=Win->vLabel[ind]->pList->GetPropertyValue("LEFT");
         return;
        }
       Win->vLabel[ind]->img->Left=StrToInt(((TEdit*)cmp)->Text);
      }
	 catch(...)
      {
       val=Win->vLabel[ind]->pList->GetPropertyValue("LEFT");
       ((TEdit*)cmp)->Text=val;
       Win->vLabel[ind]->img->Left=StrToInt(val);
      }
    }
   else
   if(Win->vLabel[ind]->pList->GetPropertyNameByIdx(sgPropertys->Row).UpperCase()=="TOP")
    {
     try
      {
       r.Top=StrToInt(((TEdit*)cmp)->Text);
       r.Bottom=r.Top+Win->vLabel[ind]->img->Height;
       if(Win->ResizeImposition(r))
        {
         Application->MessageBox("��������� �������� �����������!","��������!",
                                 MB_OK|MB_ICONEXCLAMATION);
         ((TEdit*)cmp)->Text=Win->vLabel[ind]->pList->GetPropertyValue("TOP");
         return;
        }
       Win->vLabel[ind]->img->Top=StrToInt(((TEdit*)cmp)->Text);
      }
     catch(...)
      {
       val=Win->vLabel[ind]->pList->GetPropertyValue("TOP");
       ((TEdit*)cmp)->Text=val;
       Win->vLabel[ind]->img->Left=StrToInt(val);
	  }
    }
   else
   if(Win->vLabel[ind]->pList->GetPropertyNameByIdx(sgPropertys->Row).UpperCase()=="WIDTH")
    {
     try
      {
       r.Right=r.Left+StrToInt(((TEdit*)cmp)->Text);
       if(Win->ResizeImposition(r))
        {
         Application->MessageBox("��������� �������� �����������!","��������!",
                                 MB_OK|MB_ICONEXCLAMATION);
         ((TEdit*)cmp)->Text=Win->vLabel[ind]->pList->GetPropertyValue("WIDTH");
         return;
        }
       Win->vLabel[ind]->img->Width=StrToInt(((TEdit*)cmp)->Text);
      }
     catch(...)
      {
       val=Win->vLabel[ind]->pList->GetPropertyValue("WIDTH");
       ((TEdit*)cmp)->Text=val;
       Win->vLabel[ind]->img->Left=StrToInt(val);
      }
     Win->vLabel[ind]->img->Update();
     Win->vLabel[ind]->DrawSelect();
    }
   else
   if(Win->vLabel[ind]->pList->GetPropertyNameByIdx(sgPropertys->Row).UpperCase()=="HEIGHT")
	{
     try
      {
       r.Bottom=r.Top+StrToInt(((TEdit*)cmp)->Text);
       if(Win->ResizeImposition(r))
        {
		 Application->MessageBox("��������� �������� �����������!","��������!",
                                 MB_OK|MB_ICONEXCLAMATION);
         ((TEdit*)cmp)->Text=Win->vLabel[ind]->pList->GetPropertyValue("HEIGHT");
         return;
        }
       Win->vLabel[ind]->img->Height=StrToInt(((TEdit*)cmp)->Text);
      }
     catch(...)
      {
       val=Win->vLabel[ind]->pList->GetPropertyValue("HEIGHT");
       ((TEdit*)cmp)->Text=val;
       Win->vLabel[ind]->img->Left=StrToInt(val);
      }
     Win->vLabel[ind]->img->Update();
     Win->vLabel[ind]->DrawSelect();
    }
   Win->vLabel[ind]->pList->SetPropertyValue(sgPropertys->Row,((TEdit*)cmp)->Text);
   sgPropertys->Cells[1][sgPropertys->Row]=((TEdit*)cmp)->Text;
   return;
  }

 if(CurrObj.Type=="EDIT")
  {
   r.Left=Win->vEdit[ind]->img->Left;
   r.Top=Win->vEdit[ind]->img->Top;
   r.Right=Win->vEdit[ind]->img->Left+Win->vEdit[ind]->img->Width;
   r.Bottom=Win->vEdit[ind]->img->Top+Win->vEdit[ind]->img->Height;
   if(Win->vEdit[ind]->pList->GetPropertyNameByIdx(sgPropertys->Row).UpperCase()=="LEFT")
	{
	 try
	  {
	   r.Left=StrToInt(((TEdit*)cmp)->Text);
	   r.Right=r.Left+Win->vEdit[ind]->img->Width;
	   if(Win->ResizeImposition(r))
		{
		 Application->MessageBox("��������� �������� �����������!","��������!",
								 MB_OK|MB_ICONEXCLAMATION);
		 ((TEdit*)cmp)->Text=Win->vEdit[ind]->pList->GetPropertyValue("LEFT");
		 return;
		}
       Win->vEdit[ind]->img->Left=StrToInt(((TEdit*)cmp)->Text);
      }
     catch(...)
      {
       val=Win->vEdit[ind]->pList->GetPropertyValue("LEFT");
       ((TEdit*)cmp)->Text=val;
       Win->vEdit[ind]->img->Left=StrToInt(val);
      }
    }
   else
   if(Win->vEdit[ind]->pList->GetPropertyNameByIdx(sgPropertys->Row).UpperCase()=="TOP")
    {
     try
      {
       r.Top=StrToInt(((TEdit*)cmp)->Text);
       r.Bottom=r.Top+Win->vEdit[ind]->img->Height;
	   if(Win->ResizeImposition(r))
        {
         Application->MessageBox("��������� �������� �����������!","��������!",
                                 MB_OK|MB_ICONEXCLAMATION);
         ((TEdit*)cmp)->Text=Win->vEdit[ind]->pList->GetPropertyValue("TOP");
         return;
        }
       Win->vEdit[ind]->img->Top=StrToInt(((TEdit*)cmp)->Text);
      }
     catch(...)
      {
	   val=Win->vEdit[ind]->pList->GetPropertyValue("TOP");
       ((TEdit*)cmp)->Text=val;
       Win->vEdit[ind]->img->Left=StrToInt(val);
      }
    }
   else
   if(Win->vEdit[ind]->pList->GetPropertyNameByIdx(sgPropertys->Row).UpperCase()=="WIDTH")
    {
     try
      {
       r.Right=r.Left+StrToInt(((TEdit*)cmp)->Text);
	   if(Win->ResizeImposition(r))
        {
         Application->MessageBox("��������� �������� �����������!","��������!",
                                 MB_OK|MB_ICONEXCLAMATION);
         ((TEdit*)cmp)->Text=Win->vEdit[ind]->pList->GetPropertyValue("WIDTH");
         return;
		}
       Win->vEdit[ind]->img->Width=StrToInt(((TEdit*)cmp)->Text);
      }
     catch(...)
      {
       val=Win->vEdit[ind]->pList->GetPropertyValue("WIDTH");
       ((TEdit*)cmp)->Text=val;
       Win->vEdit[ind]->img->Left=StrToInt(val);
      }
     Win->vEdit[ind]->img->Update();
     Win->vEdit[ind]->DrawSelect();
	}
   else
   if(Win->vEdit[ind]->pList->GetPropertyNameByIdx(sgPropertys->Row).UpperCase()=="HEIGHT")
    {
     try
      {
       r.Bottom=r.Top+StrToInt(((TEdit*)cmp)->Text);
       if(Win->ResizeImposition(r))
        {
         Application->MessageBox("��������� �������� �����������!","��������!",
                                 MB_OK|MB_ICONEXCLAMATION);
		 ((TEdit*)cmp)->Text=Win->vEdit[ind]->pList->GetPropertyValue("HEIGHT");
         return;
        }
       Win->vEdit[ind]->img->Height=StrToInt(((TEdit*)cmp)->Text);
      }
     catch(...)
	  {
       val=Win->vEdit[ind]->pList->GetPropertyValue("HEIGHT");
       ((TEdit*)cmp)->Text=val;
       Win->vEdit[ind]->img->Left=StrToInt(val);
      }
     Win->vEdit[ind]->img->Update();
     Win->vEdit[ind]->DrawSelect();
    }
   Win->vEdit[ind]->pList->SetPropertyValue(sgPropertys->Row,((TEdit*)cmp)->Text);
   sgPropertys->Cells[1][sgPropertys->Row]=((TEdit*)cmp)->Text;
   return;
  }
 #undef Win
}
//---------------------------------------------------------------------------
void __fastcall TfObjInsp::edKeyPress(TObject *Sender, char &Key)
{
 if(pType==2)
  {
   Set <char,0,256> ch;
   ch<<','<<'-'<<'0'<<'1'<<'2'<<'3'<<'4'<<'5'<<'6'<<'7'<<'8'<<'9'<<8;
   if(!ch.Contains(Key)) Key=0;
   try
	{
	 if(Key!=8)
	  {
	   StrToInt(((TEdit*)cmp)->Text+Key);
       fMain->vWindows[CurrObj.Wnd]->Modified=true;	   
	  } 
	}
   catch(...)
	{
	 AnsiString msg("\""+((TEdit*)cmp)->Text);
		 if(Key!='\0')  msg+=Key;
		 msg+=("\" - �� ����� ��������!");
	 Application->MessageBox(msg.c_str(),"������!",MB_OK|MB_ICONSTOP);
	 #define Win fMain->vWindows[CurrObj.Wnd]
	 if(CurrObj.Type=="WINDOW")
	  ((TEdit*)cmp)->Text=Win->pList->GetPropertyValue(sgPropertys->Row);
	 else
	 if(CurrObj.Type=="BUTTON")
	  ((TEdit*)cmp)->Text=Win->vButton[CurrObj.Idx]->pList->GetPropertyValue(sgPropertys->Row);
	 else
	 if(CurrObj.Type=="LABEL")
	  ((TEdit*)cmp)->Text=Win->vLabel[CurrObj.Idx]->pList->GetPropertyValue(sgPropertys->Row);
	 else
	 if(CurrObj.Type=="EDIT")
	  ((TEdit*)cmp)->Text=Win->vEdit[CurrObj.Idx]->pList->GetPropertyValue(sgPropertys->Row);
	 #undef Win
	 ((TEdit*)cmp)->SetFocus();
	 Key=0;
	 return;
	}
  }
 int ind=0;
/* AnsiString str(cbObjects->Text);
 str=str.SubString(str.Pos(":")+1,str.Length());
 str=str.Trim().UpperCase();*/
 #define Win fMain->vWindows[CurrObj.Wnd]
 if(CurrObj.Type=="WINDOW")
  {
   if(Win->pList->GetPropertyNameByIdx(sgPropertys->Row).UpperCase()=="CAPTION")
	{
	 AnsiString str(((TEdit*)cmp)->Text);
	 if((Key=='\b'))
	  {
	   str=str.SubString(1,str.Length()-1);
	  }
	 else
      if(Key!='\r') str=str+Key;
	 Win->pList->SetPropertyValue("Caption",str);
	 Win->wForm->Caption=str;
	 Win->Modified=true;
	}
   return;
  }
// ind=((TImage*)fObjInsp->cbObjects->Items->
//	  Objects[fObjInsp->cbObjects->ItemIndex])->Tag;
 ind=CurrObj.Idx;
 if(CurrObj.Type=="BUTTON")
  {
   if(Win->vButton[ind]->pList->GetPropertyNameByIdx(sgPropertys->Row).UpperCase()=="CAPTION")
	{
	 AnsiString str(((TEdit*)cmp)->Text);
	 if((Key=='\b'))
	  {
	   str=str.SubString(1,str.Length()-1);
	  }
	 else
	  {
	   if(Key!='\r' && str.Length()<MAX_STR_LENGTH) str=str+Key;
	   else Key=0;
	  }
	 Win->vButton[ind]->pList->SetPropertyValue("Caption",str);
	 Win->vButton[ind]->DrawSelect();
	 Win->Modified=true;
    }
   return;
  }
 if(CurrObj.Type=="LABEL")
  {
   if(Win->vLabel[ind]->pList->GetPropertyNameByIdx(sgPropertys->Row).UpperCase()=="TEXT")
	{
	 AnsiString str(((TEdit*)cmp)->Text);
	 if((Key=='\b'))
	  {
	   str=str.SubString(1,str.Length()-1);
	  }
	 else
	  {
	   if(Key!='\r' && str.Length()<MAX_STR_LENGTH) str=str+Key;
	   else Key=0;
	  } 
	 Win->vLabel[ind]->pList->SetPropertyValue("Text",str);
	 Win->vLabel[ind]->DrawSelect();
	 Win->Modified=true;
	}
   return;
  }
 if(CurrObj.Type=="EDIT")
  {
   if(Win->vEdit[ind]->pList->GetPropertyNameByIdx(sgPropertys->Row).UpperCase()=="TEXT")
	{
	 AnsiString str(((TEdit*)cmp)->Text);
	 if((Key=='\b'))
	  {
	   str=str.SubString(1,str.Length()-1);
	  }
	 else
	  {
	   if(Key!='\r' && str.Length()<MAX_STR_LENGTH) str=str+Key;
	   else Key=0;
	  }
	 Win->vEdit[ind]->pList->SetPropertyValue("Text",str);
	 Win->vEdit[ind]->DrawSelect();
	 Win->Modified=true;
	}
   return;
  }
 #undef Win
}
//---------------------------------------------------------------------------
void __fastcall TfObjInsp::edChange(TObject *Sender)
{
/* int ind=0;
 AnsiString str(cbObjects->Text);
 str=str.SubString(str.Pos(":")+1,str.Length());
 str=str.Trim().UpperCase();
 if(str=="WINDOW")
 {
  ind=((TForm*)fObjInsp->cbObjects->Items->
	  Objects[fObjInsp->cbObjects->ItemIndex])->Tag;
  #define Win fMain->vWindows[ind]
//   Win.vProperties[sgProperties->Row].
   if(Win.vProperties[sgPropertys->Row].pName.UpperCase()=="CAPTION")
	{
	 Win.wForm->Caption=((TEdit*)cmp)->Text;
	}
  #undef Win
 }*/
}
//---------------------------------------------------------------------------
void __fastcall TfObjInsp::edKeyUp(TObject *Sender, WORD &Key, TShiftState Shift)
{
 if(Key==VK_RETURN)
  {
   edExit(Sender);
   fMain->vWindows[CurrObj.Wnd]->Modified=true;
  }
}
//---------------------------------------------------------------------------
void __fastcall TfObjInsp::cbKeyUp(TObject *Sender, WORD &Key, TShiftState Shift)
{
 if(Key==VK_RETURN)
  {
/*   cbExit(Sender);
   fMain->vWindows[CurrObj.Wnd]->Modified=true;*/
   cbChange(Sender);
  }
}
//---------------------------------------------------------------------------
void __fastcall TfObjInsp::controlExit()
{
 if(!cmp) return;
 switch(pType)
  {
   case 1: case 2:
	edExit(NULL);
   break;
   case 3:
	cbExit(NULL);
   break;
  }
}
//---------------------------------------------------------------------------
void __fastcall TfObjInsp::ClearSelect()
{
 if(CurrObj.Type=="BUTTON")
  {
   fMain->vWindows[CurrObj.Wnd]->vButton[CurrObj.Idx]->Draw();
  }
 else
 if(CurrObj.Type=="LABEL")
  {
   fMain->vWindows[CurrObj.Wnd]->vLabel[CurrObj.Idx]->Draw();
  }
 else
 if(CurrObj.Type=="EDIT")
  {
   fMain->vWindows[CurrObj.Wnd]->vEdit[CurrObj.Idx]->Draw();
  }
}
//---------------------------------------------------------------------------
void __fastcall TfObjInsp::DeleteControls()
{
 if(pType && cmp)
  {
   switch(pType)
	{
	 case 1:
	 case 2:
	  ((TEdit*)cmp)->Text="";	 
	  delete (TEdit*)cmp;
	 break;
	 case 3:
	  delete (TComboBox*)cmp;
	 break;
	}
   pType=0;
   cmp=NULL;
  }
}
//---------------------------------------------------------------------------
