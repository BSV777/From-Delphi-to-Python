//---------------------------------------------------------------------------
#ifndef editH
#define editH
#include "property.h"
//#include "event.h"
#include <vector>
using namespace std;
//---------------------------------------------------------------------------
class Edit
{
 private:
  bool move;
  TRect Focus;
  int X0;
  int Y0;
  bool IsLeftSizing;
  bool IsRightSizing;
  bool IsTopSizing;
  bool IsBottomSizing;
  void __fastcall GetSizingType(int x, int y);
  void __fastcall CreateEditPropertyList(AnsiString str);
  int Height;  
 public:
  Edit(int id, int eCnt, bool selected, int startX, int startY, TWinControl* AOwner);
  Edit(int id, int eCnt, bool selected, PropertyList* pl, TWinControl* AOwner);
  Edit(int id, int eCnt, bool selected, AnsiString props, TWinControl* AOwner);  
  ~Edit();
  TImage *img;
  AnsiString Name;
  int Id;
  PropertyList* pList;
  void __fastcall EdtMouseDown(TObject *Sender,TMouseButton Button,
                             TShiftState Shift, int X, int Y);
  void __fastcall EdtMouseUp(TObject *Sender,TMouseButton Button,
                             TShiftState Shift, int X, int Y);
  void __fastcall EdtMouseMove(TObject *Sender, TShiftState Shift,
						   int X, int Y);
  void Draw(AnsiString caption="");
  void DrawSelect(AnsiString caption="");
};
#endif
