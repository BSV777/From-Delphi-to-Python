//---------------------------------------------------------------------------

#ifndef HtmlObjH
#define HtmlObjH
//---------------------------------------------------------------------------
class HtmlObj
{
 public:
  HtmlObj();
  HtmlObj(AnsiString type, TRect rec, AnsiString text="");
  HtmlObj(HtmlObj* ho);
  AnsiString Type;
  TRect r;
  AnsiString Text;
};
//---------------------------------------------------------------------------
#endif
 