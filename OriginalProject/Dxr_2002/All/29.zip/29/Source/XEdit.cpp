// XEdit.cpp: implementation of the CXEdit class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "XEdit.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CXEdit::CXEdit()
{

}

CXEdit::~CXEdit()
{
}

void CXEdit::Create(HWND parent)
{
	hwnd = CreateWindow("EDIT",caption,WS_CHILD |WS_BORDER| ES_LEFT |ES_READONLY | ES_AUTOHSCROLL,x,y,dx,dy,parent,NULL,(HINSTANCE) GetWindowLong(parent, GWL_HINSTANCE),NULL);
}

