// XEdit.h: interface for the CXEdit class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_XEDIT_H__AC96B319_45FF_4170_B84D_A5E6FC795A78__INCLUDED_)
#define AFX_XEDIT_H__AC96B319_45FF_4170_B84D_A5E6FC795A78__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "XRect.h"

class CXEdit : public CXRect  
{
public:
	virtual void Create(HWND);

	CXEdit();
	virtual ~CXEdit();
};

#endif // !defined(AFX_XEDIT_H__AC96B319_45FF_4170_B84D_A5E6FC795A78__INCLUDED_)
