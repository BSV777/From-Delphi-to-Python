// Spawner.h: interface for the CSpawner class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SPAWNER_H__E680D1C3_4B2C_444C_A07D_5BC806318455__INCLUDED_)
#define AFX_SPAWNER_H__E680D1C3_4B2C_444C_A07D_5BC806318455__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "XRect.h"
#include "XButton.h"
#include "XEdit.h"
#include "XMarkBox.h"

#define MAX_CHILD 2048
#define MAX_DX 2048
#define MAX_DY 2048

#define TYPE_LABEL 1
#define TYPE_BUTTON 2
#define TYPE_EDIT 3

class CSpawner  
{
public:
	void SaveHTML(char *fname);
	__inline int isSaved(){return Saved || (n_child==0); };
	void Clear();
	void Load(char *fname);
	void Save(char *fname);
	void UpdateText(char *s);
	int getType(char **p);
	void ResUp(int c);
	void ResDw(int c);
	void ResLf(int c);
	void ResRt(int c);
	int isResPlace(LPPOINT p);
	void Delete();
	void Redraw();
	void CreateChild(HWND hOwn, int t, int x, int y);
	int isPlace(LPPOINT p);
	void MouseMove(LPPOINT p);
	void ButtonUp(LPPOINT p);
	int ButtonDown(LPPOINT p);
	void setY(int ny);
	void setX(int nx);
	__inline getXMax(){return MAX_DX-dx;};
	__inline getYMax(){return MAX_DY-dy;};
	__inline getXPage(){return dx;};
	__inline getYPage(){return dy;};
	__inline getXPos(){return x;};
	__inline getYPos(){return y;};

	void ReleaseNew(int b);
	void setGartenSize( int ndx, int ndy);
	void Prepare();
	void setPlaces(HWND parent, HWND garten, HWND place, HWND trash);
	CSpawner();
	virtual ~CSpawner();
private:
	HWND hParent;
	HWND hGarten;
	HWND hPlace;
	HWND hTrash;

	CXRect *LabelChild;
	CXButton *ButtonChild;
	CXEdit *EditChild;

	int NewType;
	CXRect *NewChild;
	int newx,newy;
	int LastType;
	CXRect *LastChild;

	int LabelCount,ButtonCount,EditCount;

	CXMarkBox *MarkBox;
	int i_mark;
	int b_move;
	int maynew_x,maynew_y;

	int b_resize,i_resize;
	int x_resize,y_resize;
	int u_resize,v_resize;

	int x,y;
	int dx,dy;

	int ChildX[MAX_CHILD];
	int ChildY[MAX_CHILD];
	int ChildT[MAX_CHILD];
	CXRect *Child[MAX_CHILD];
	int n_child;

	int Saved;
};

#endif // !defined(AFX_SPAWNER_H__E680D1C3_4B2C_444C_A07D_5BC806318455__INCLUDED_)
