// XMark.h: interface for the CXMark class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_XMARK_H__A1F73B19_5983_465B_A7EA_1273A5EB0876__INCLUDED_)
#define AFX_XMARK_H__A1F73B19_5983_465B_A7EA_1273A5EB0876__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "XRect.h"

class CXMark : public CXRect  
{
public:
	virtual void Create(HWND);
	CXMark();
	virtual ~CXMark();

};

#endif // !defined(AFX_XMARK_H__A1F73B19_5983_465B_A7EA_1273A5EB0876__INCLUDED_)
