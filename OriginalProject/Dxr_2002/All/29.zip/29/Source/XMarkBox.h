// XMarkBox.h: interface for the CXMarkBox class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_XMARKBOX_H__6E25A20A_3509_4AFE_9D9C_551175412E75__INCLUDED_)
#define AFX_XMARKBOX_H__6E25A20A_3509_4AFE_9D9C_551175412E75__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "XMark.h"

class CXMarkBox  
{
public:
	int isResizing(LPPOINT p);
	void setDXDY(int ndx, int ndy);
	void Redraw();
	void setXY(int nx, int ny);
	void Enable(int b);
	
	void Create(HWND parent);
	CXMarkBox();
	virtual ~CXMarkBox();
private:
	CXMark *Marks[8];
	int x,y;
	int dx,dy;
	int en;

};

#endif // !defined(AFX_XMARKBOX_H__6E25A20A_3509_4AFE_9D9C_551175412E75__INCLUDED_)
