// XMarkBox.cpp: implementation of the CXMarkBox class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "XMarkBox.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CXMarkBox::CXMarkBox()
{
	register i;
	for(i = 0; i < 8; i++) Marks[i] = new CXMark();
	x = 0; y = 0; dx = 0; dy = 0;
}

CXMarkBox::~CXMarkBox()
{
	register i;
	for(i = 0; i < 8; i++) if(Marks[i]) delete Marks[i];
}

void CXMarkBox::Create(HWND parent)
{
	register i;
	for(i = 0; i < 8; i++){
		Marks[i]->Create(parent);
	}
}

void CXMarkBox::Enable(int b)
{
	register i;

	for(i = 0; i < 8; i++){
		Marks[i]->Show(b);
	}

}

void CXMarkBox::setXY(int nx, int ny)
{
x = nx; y = ny; Redraw();
}

void CXMarkBox::Redraw()
{
	register i;
	Marks[0]->setXY(x - Marks[0]->getDX(), y - Marks[0]->getDY());
	Marks[1]->setXY(x + dx/2 - Marks[1]->getDX()/2, y - Marks[1]->getDY());
	Marks[2]->setXY(x + dx, y - Marks[2]->getDY());

	Marks[3]->setXY(x + dx, y + dy/2 - Marks[3]->getDY()/2);

	Marks[4]->setXY(x + dx, y + dy);
	Marks[5]->setXY(x + dx/2 - Marks[1]->getDX()/2, y + dy);
	Marks[6]->setXY(x - Marks[6]->getDX(), y + dy);

	Marks[7]->setXY(x - Marks[7]->getDX(), y + dy/2 - Marks[7]->getDY()/2);
	for(i = 0; i < 8; i++){
		Marks[i]->Redraw();
		Marks[i]->setTop();
	}
}

void CXMarkBox::setDXDY(int ndx, int ndy)
{
dx = ndx; dy = ndy; Redraw();
}

int CXMarkBox::isResizing(LPPOINT p)
{
	POINT pt;
	int i;

	for(i=0; i<8;i++)
	{
		pt.x = p->x; pt.y = p->y;
		if(Marks[i]->AdjustXY(&pt)) return i;
	}
	return -1;
}
