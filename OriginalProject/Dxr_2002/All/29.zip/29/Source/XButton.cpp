// XButton.cpp: implementation of the CXButton class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "XButton.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CXButton::CXButton()
{

}

CXButton::~CXButton()
{

}

void CXButton::Create(HWND parent)
{
	hwnd = CreateWindow("BUTTON",caption,WS_CHILD | BS_CENTER | BS_NOTIFY,x,y,dx,dy,parent,NULL,(HINSTANCE) GetWindowLong(parent, GWL_HINSTANCE),NULL);
}

