// dx_tst.cpp : Defines the entry point for the application.
//

#include "stdafx.h"

#include "Spawner.h"

	HWND Title1,Title2,Title3,Title4;
	HWND Frame1,Frame2,Frame3,Frame4;
	HWND Garten,Place,Trash,Edit;
	HWND Horiz,Vert;
	HWND hWnd;
	HBITMAP hBitmap;

HINSTANCE hInst;
CSpawner *Spawn = NULL;
static int Captured;
static int GartenDX,GartenDY,PlaceDX,PlaceDY;

#define MAX_FILENAME 512
static char LoadFilename[MAX_FILENAME];
static char ResFilename[MAX_FILENAME];
static char InitialDir[MAX_FILENAME];

static char SaveFilename[MAX_FILENAME];
static char SResFilename[MAX_FILENAME];
static char SInitialDir[MAX_FILENAME];

static char HTMLFilename[MAX_FILENAME];
static char HResFilename[MAX_FILENAME];
static char HInitialDir[MAX_FILENAME];

OPENFILENAME 	ofn = { sizeof(OPENFILENAME), NULL, NULL,
                                "All files (*.*)\0*.*\0\0", 
                                NULL, 0, 1, LoadFilename, (MAX_FILENAME-1), ResFilename, (MAX_FILENAME-1),
                                InitialDir, ("Open datafile..."), 
                                OFN_FILEMUSTEXIST|OFN_HIDEREADONLY, 0, 1, NULL, 0, NULL, NULL };

OPENFILENAME 	sfn = { sizeof(OPENFILENAME), NULL, NULL,
                                "All files (*.*)\0*.*\0\0", 
                                NULL, 0, 1, SaveFilename, (MAX_FILENAME-1), SResFilename, (MAX_FILENAME-1),
                                SInitialDir, ("Save datafile..."), 
                                OFN_HIDEREADONLY, 0, 1, NULL, 0, NULL, NULL };

OPENFILENAME 	hfn = { sizeof(OPENFILENAME), NULL, NULL,
                                "All files (*.*)\0*.*\0\0", 
                                NULL, 0, 1, HTMLFilename, (MAX_FILENAME-1), HResFilename, (MAX_FILENAME-1),
                                HInitialDir, ("Save HTML..."), 
                                OFN_HIDEREADONLY, 0, 1,"htm", 0, NULL, NULL };

LRESULT CALLBACK WindowProc(
  HWND hWnd,      // handle to window
  UINT uMsg,      // message identifier
  WPARAM wParam,  // first message parameter
  LPARAM lParam   // second message parameter
);

LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
				return TRUE;
		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
	
	}
    return FALSE;
}

void Props()
{
	char *s;
	int i = Spawn->getType(&s);

	ShowWindow(Edit,i?SW_SHOW:SW_HIDE);
	ShowWindow(Title4,i?SW_SHOW:SW_HIDE);
	if(i)
	{
		SetWindowText(Title4,(i==1)?"T E X T":"C A P T I O N");
		SetWindowText(Edit,s);
	}
}

static int SaveResult;

void Check()
{
	SaveResult = 1;
	if(!Spawn->isSaved())
	{
		if(MessageBox(hWnd,"Current state will be lost. Save data ?","Warning !",MB_YESNO)==IDYES)
			SendMessage(hWnd,WM_COMMAND,ID_FILESAVE,0);
	}
}



int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	WNDCLASSEX w;
	char *wclass="DX-CONTEST Window Class 1";
	char f1[MAX_FILENAME],f2[MAX_FILENAME];

	MSG msg;

	hInst = hInstance;

	Spawn = new CSpawner();

	if(Spawn)
	{
		// test da command line //
		if(sscanf(lpCmdLine,"%s %s",&f1,&f2)>=2)
		{
			Spawn->Load(f1);
			Spawn->SaveHTML(f2);
		}
		//////////////////////////
		else
		{
			if(sscanf(lpCmdLine,"%s",&f1)==1) Spawn->Load(f1);

			w.lpszClassName = wclass;
			w.hInstance = hInstance;
			w.lpfnWndProc	= WindowProc;
			w.hCursor	 = LoadCursor(NULL,IDC_ARROW);
			w.hIcon	= LoadIcon( hInstance, MAKEINTRESOURCE(IDI_ICON1) );
			w.hIconSm = LoadIcon( hInstance, MAKEINTRESOURCE(IDI_ICON1) );
			w.lpszMenuName	= NULL;
			w.hbrBackground	= (HBRUSH)GetStockObject (LTGRAY_BRUSH);
			w.style	= CS_HREDRAW | CS_VREDRAW | CS_PARENTDC;
			w.cbClsExtra = 0;
			w.cbWndExtra = 0;
			w.cbSize = sizeof(WNDCLASSEX);

			if (RegisterClassEx (&w))
			{
				hWnd = CreateWindow( wclass, "kinez DXContest variant v0.4",
					WS_OVERLAPPEDWINDOW,
					100, 100, 600, 420, NULL,
					LoadMenu( hInstance, MAKEINTRESOURCE(IDR_MENU1) ), hInstance, NULL );

				hBitmap = LoadBitmap(hInstance,MAKEINTRESOURCE(IDB_BITMAP1));

				if(hWnd)
				{
						Title1 = CreateWindow("STATIC","K I N D E R G A R T E N",WS_VISIBLE | WS_CHILD  | SS_CENTER ,2,2,400,16,hWnd,NULL,
											hInstance,NULL);
						Frame1 = CreateWindow("STATIC","",WS_VISIBLE | WS_CHILD  | SS_BLACKFRAME ,2,2,400,16,hWnd,NULL,
											hInstance,NULL);
						Title2 = CreateWindow("STATIC","C H I L D B I R T H",WS_VISIBLE | WS_CHILD  | SS_CENTER ,406,2,184,16,hWnd,NULL,
											hInstance,NULL);
						Frame2 = CreateWindow("STATIC","",WS_VISIBLE | WS_CHILD  | SS_BLACKFRAME ,406,2,184,16,hWnd,NULL,
											hInstance,NULL);
						Title3 = CreateWindow("STATIC","T R A S H C A N",WS_VISIBLE | WS_CHILD  | SS_CENTER ,406,184,184,16,hWnd,NULL,
											hInstance,NULL);
						Frame3 = CreateWindow("STATIC","",WS_VISIBLE | WS_CHILD  | SS_BLACKFRAME ,406,184,184,16,hWnd,NULL,
											hInstance,NULL);
						Title4 = CreateWindow("STATIC","", WS_CHILD  | SS_CENTER ,407,270,182,16,hWnd,NULL,
											hInstance,NULL);
						Frame4 = CreateWindow("STATIC","",WS_VISIBLE | WS_CHILD  | SS_BLACKFRAME ,406,270,184,16,hWnd,NULL,
											hInstance,NULL);
						Edit   = CreateWindow("EDIT","",WS_DLGFRAME | WS_CHILD | ES_AUTOHSCROLL,406,290,184,24,hWnd,NULL,
											hInstance,NULL);
		
						Garten = CreateWindow("STATIC","",WS_VISIBLE | WS_DLGFRAME | WS_CHILD  | SS_WHITERECT ,2,20,(400-18),(352-18),hWnd,NULL,
											hInstance,NULL);
						Place = CreateWindow("STATIC","",WS_VISIBLE | WS_DLGFRAME | WS_CHILD  | SS_WHITERECT ,406,20,184,160,hWnd,NULL,
											hInstance,NULL);
						Vert = CreateWindow("SCROLLBAR","",WS_VISIBLE | WS_CHILD  | SBS_VERT ,(403-18),20,16,(352-18),hWnd,NULL,
											hInstance,NULL);
						Horiz = CreateWindow("SCROLLBAR","",WS_VISIBLE |  WS_CHILD  | SBS_HORZ ,2,355,(400-18),16,hWnd,NULL,
											hInstance,NULL);
						Trash = CreateWindow("BUTTON","",WS_VISIBLE | WS_DLGFRAME | WS_CHILD  | BS_BITMAP ,406+62,202,60,60,hWnd,NULL,
											hInstance,NULL);

						Spawn->setPlaces( hWnd, Garten, Place, Trash);
				
						Spawn->Prepare();

						SendMessage(Trash,BM_SETIMAGE,IMAGE_BITMAP,(LPARAM)hBitmap);

						ShowWindow(hWnd,nCmdShow);
						UpdateWindow(hWnd);
	
						GetCurrentDirectory(MAX_PATH,InitialDir); LoadFilename[0] = '\0';
						GetCurrentDirectory(MAX_PATH,SInitialDir); SaveFilename[0] = '\0';
						GetCurrentDirectory(MAX_PATH,HInitialDir); HTMLFilename[0] = '\0';
	
						HACCEL hAccel = LoadAccelerators( NULL, MAKEINTRESOURCE(IDR_ACCELERATOR1) );
	
						while(GetMessage(&msg,NULL,0,0))
						{
							if( 0 == TranslateAccelerator( hWnd, hAccel, &msg ) )
							{
								TranslateMessage(&msg);
								DispatchMessage(&msg);
							}
						}

						Check();
				
						DeleteObject(hBitmap);
						DestroyWindow( Horiz );
						DestroyWindow( Vert );
						DestroyWindow( Trash );
						DestroyWindow( Edit );
						DestroyWindow( Place );
						DestroyWindow( Garten );
						DestroyWindow( Frame1 );
						DestroyWindow( Frame2 );
						DestroyWindow( Frame3 );
						DestroyWindow( Frame4 );
						DestroyWindow( Title1 );
						DestroyWindow( Title2 );
						DestroyWindow( Title3 );
						DestroyWindow( Title4 );
						DestroyMenu( GetMenu(hWnd) );
						DestroyWindow( hWnd );
				} // hwnd
			} // win class
		} // GUI

		delete Spawn;
	}// spawn

	return !Spawn;
}

int Test(char *s)
{
	register r;

	if((r = (int)fopen(s,"r")))
	{
		fclose((FILE*)r);
		if(MessageBox(hWnd,"File already exists. Overwite ?","Warning !",MB_YESNO)==IDYES)
			r = 0;
	}
	return !r;
}

LRESULT CALLBACK WindowProc(
  HWND hWn,       // handle to window
  UINT uMsg,      // message identifier
  WPARAM wParam,  // first message parameter
  LPARAM lParam   // second message parameter
)
{
	register RECT* rec;
	register BOOL x,y;
	SCROLLINFO sif;
	POINT pt;
	int i,j,d;
	char s[256];

	switch(uMsg)
	{

	case WM_COMMAND:
		if(HIWORD(wParam) == EN_CHANGE)
		{
			if(lParam == (LPARAM)Edit)
			{
				GetWindowText(Edit,s,255);
				s[255] = 0;
				Spawn->UpdateText(s);
			}
			return 0;
		}

		switch( LOWORD(wParam) )
		{
		case ID_FILENEW:
			{
				Check();
				if(SaveResult)Spawn->Clear();
			}
			return 0;

		case ID_FILESAVE:
			sfn.hwndOwner = hWnd;
            if( TRUE == (SaveResult = GetSaveFileName( &sfn )) )
            {
				strncpy(SInitialDir,sfn.lpstrFile,sfn.nFileOffset);
				InitialDir[sfn.nFileOffset] = '\0';
				strcpy(sfn.lpstrFile,sfn.lpstrFileTitle);
				if(Test(sfn.lpstrFile)) Spawn->Save(sfn.lpstrFile);
			}
			return 0;

		case ID_FILEHTML:
			hfn.hwndOwner = hWnd;
            if( TRUE == GetSaveFileName( &hfn ) )
            {
				strncpy(HInitialDir,hfn.lpstrFile,hfn.nFileOffset);
				HInitialDir[hfn.nFileOffset] = '\0';
				strcpy(hfn.lpstrFile,hfn.lpstrFileTitle);
				if(Test(hfn.lpstrFile)) Spawn->SaveHTML(hfn.lpstrFile);
			}
			return 0;

		case ID_FILELOAD:
			Check();
			if(SaveResult)
			{
				ofn.hwndOwner = hWnd;
				ofn.lpstrFile[0] = '\0';
				if( TRUE == GetOpenFileName( &ofn ) )
				{
					strncpy(InitialDir,ofn.lpstrFile,ofn.nFileOffset);
					InitialDir[ofn.nFileOffset] = '\0';
	//				strcpy(ofn.lpstrFile,ofn.lpstrFileTitle);
					Spawn->Load(ofn.lpstrFile);
				}
			}
			return 0;


		case IDM_ABOUT:
			DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
			return 0;

		case IDCLOSE:
			SendMessage(hWnd,WM_CLOSE,0,0);
			return 0;

		case BN_CLICKED:
			if(lParam == (LPARAM)Trash)
			{
				Spawn->Delete();
				Props();
			}
			return 0;
		}
		break;
	

	case WM_MOUSEMOVE:
		if(!Captured)
		{
			GetCursorPos(&pt);
			ScreenToClient(Place,&pt);
			if( (pt.x >= 0)&&(pt.y >= 0)&&(pt.x < PlaceDX)&&(pt.y < PlaceDY))
			{
				SetCapture(hWnd);
			}
			else
			{
				GetCursorPos(&pt);
				ScreenToClient(Garten,&pt);
				if( (pt.x >= 0)&&(pt.y >= 0)&&(pt.x < GartenDX)&&(pt.y < GartenDY))
				{
					SetCapture(hWnd);
				}
				else
				{
					ReleaseCapture();
				}
			}
		}
		GetCursorPos(&pt);
		Spawn->MouseMove(&pt);
		break;

	case WM_LBUTTONDOWN:
		GetCursorPos(&pt);
		if(Captured = Spawn->ButtonDown(&pt))
		{
			SetCapture(hWnd);
		}
		
		break;

	case WM_LBUTTONUP:
		if(Captured)
		{
			Captured = 0;
			GetCursorPos(&pt);
			Spawn->ButtonUp(&pt);
			Props();
//			ReleaseCapture();
		}
		break;
	

	case WM_SIZING:
		rec=(RECT*)lParam;
		x=((rec->right)-(rec->left))<520;
		y=((rec->bottom)-(rec->top))<411;
		switch(wParam)
		{
		case WMSZ_BOTTOMRIGHT:
			if(x)rec->right=rec->left+520;
			if(y)rec->bottom=rec->top+411;
			break;
		case WMSZ_BOTTOMLEFT:
			if(x)rec->left=rec->right-520;
		case WMSZ_BOTTOM:
			if(y)rec->bottom=rec->top+411;
			break;
		case WMSZ_LEFT:
			if(x)rec->left=rec->right-520;
			break;
		case WMSZ_RIGHT:
			if(x)rec->right=rec->left+520;
			break;
		case WMSZ_TOPRIGHT:
			if(x)rec->right=rec->left+520;
			if(y)rec->top=rec->bottom-411;
			break;
		case WMSZ_TOPLEFT:
			if(x)rec->left=rec->right-520;
		case WMSZ_TOP:
			if(y)rec->top=rec->bottom-411;
			break;
		}
		break;

	case WM_VSCROLL:
		i = Spawn->getYPos(); j = i;
		switch(LOWORD(wParam))
		{
		case SB_LINEUP:
			i -= 32; if(i<0) i = 0;
			break;
		case SB_LINEDOWN:
			i += 32; if(i>Spawn->getYMax()) i = Spawn->getYMax();
			break;
		case SB_PAGEUP:
			i -= Spawn->getYPage(); if(i<0) i = 0;
			break;
		case SB_PAGEDOWN:
			i += Spawn->getYPage(); if(i>Spawn->getYMax()) i = Spawn->getYMax();
			break;
		case SB_THUMBPOSITION:
		case SB_THUMBTRACK:
			i = HIWORD(wParam);if(i<0) i = 0; 
			if(i>Spawn->getYMax()) i = Spawn->getYMax();
			break;
		};
		if(i != j)
		{
			Spawn->setY(i);
			sif.cbSize = sizeof(SCROLLINFO);
			sif.fMask = SIF_POS;
			sif.nPos = i;
			SetScrollInfo(Vert,SB_CTL,&sif,1);
		}
		break;

	case WM_MOUSEWHEEL:
		d = -(int) ((signed int)wParam/0x40000);
		i = Spawn->getYPos(); j = i;
		if(d>0)
		{
			i += d; if(i>Spawn->getYMax()) i = Spawn->getYMax();
		}
		else
		{
			i += d; if(i<0) i = 0;
		}
		if(i!=j)
		{
			Spawn->setY(i);
			sif.cbSize = sizeof(SCROLLINFO);
			sif.fMask = SIF_POS;
			sif.nPos = i;
			SetScrollInfo(Vert,SB_CTL,&sif,1);
		}
		break;

	case WM_HSCROLL:
		i = Spawn->getXPos();  j = i;
		switch(LOWORD(wParam))
		{
		case SB_LINELEFT:
			i -= 32; if(i<0) i = 0;
			break;
		case SB_LINERIGHT:
			i += 32; if(i>Spawn->getXMax()) i = Spawn->getXMax();
			break;
		case SB_PAGELEFT:
			i -= Spawn->getXPage(); if(i<0) i = 0;
			break;
		case SB_PAGERIGHT:
			i += Spawn->getXPage(); if(i>Spawn->getXMax()) i = Spawn->getXMax();
			break;
		case SB_THUMBPOSITION:
		case SB_THUMBTRACK:
			i = HIWORD(wParam);if(i<0) i = 0; 
			if(i>Spawn->getXMax()) i = Spawn->getXMax();
			break;
		};
		if(i != j)
		{
			Spawn->setX(i);
			sif.cbSize = sizeof(SCROLLINFO);
			sif.fMask = SIF_POS;
			sif.nPos = i;
			SetScrollInfo(Horiz,SB_CTL,&sif,1);
		}
		break;

	case WM_SIZE:
		{
			MoveWindow(Title1,2,2,(LOWORD(lParam)-192),16,0);
			MoveWindow(Frame1,2,2,(LOWORD(lParam)-192),16,0);
			MoveWindow(Title2,(LOWORD(lParam)-186),2,184,16,0);
			MoveWindow(Frame2,(LOWORD(lParam)-186),2,184,16,0);
			MoveWindow(Title3,(LOWORD(lParam)-186),184,184,16,0);
			MoveWindow(Frame3,(LOWORD(lParam)-186),184,184,16,0);
			MoveWindow(Title4,(LOWORD(lParam)-185),270,182,16,0);
			MoveWindow(Frame4,(LOWORD(lParam)-186),269,184,18,0);
			MoveWindow(Edit,(LOWORD(lParam)-186),290,184,24,0);

			MoveWindow(Garten,2,20,(LOWORD(lParam)-210),(HIWORD(lParam)-40),0);
			GartenDX = ((LOWORD(lParam)-210) ); GartenDY = ((HIWORD(lParam)-40));
			MoveWindow(Place,(LOWORD(lParam)-186),20,184,160,0);
			PlaceDX = 184; PlaceDY = 160;

			MoveWindow(Trash,(LOWORD(lParam)-186+62),202,60,60,0);
			MoveWindow(Horiz,2,(HIWORD(lParam)-19),(LOWORD(lParam)-210),16,0);
			MoveWindow(Vert,(LOWORD(lParam)-207),20,16,(HIWORD(lParam)-40),0);

			Spawn->setGartenSize((LOWORD(lParam)-210),(HIWORD(lParam)-40));

			sif.cbSize = sizeof(SCROLLINFO);
	
			sif.fMask = SIF_PAGE|SIF_POS|SIF_RANGE;

			sif.nPage = Spawn->getXPage();
			sif.nPos = Spawn->getXPos();
			sif.nMin = 0;
			sif.nMax = Spawn->getXMax() + Spawn->getXPage();
			SetScrollInfo(Horiz,SB_CTL,&sif,1);

			sif.nPage = Spawn->getYPage();
			sif.nPos = Spawn->getYPos();
			sif.nMin = 0;
			sif.nMax = Spawn->getYMax() + Spawn->getYPage();
			SetScrollInfo(Vert,SB_CTL,&sif,1);

			InvalidateRgn(hWnd,NULL,TRUE);
			UpdateWindow(hWnd);
			return 0;
		}

	case WM_CLOSE:
		PostQuitMessage(0);
        return 0;
	}
	return DefWindowProc(hWn,uMsg,wParam,lParam);
}
