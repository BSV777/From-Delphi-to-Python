// Spawner.cpp: implementation of the CSpawner class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Spawner.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSpawner::CSpawner()
{
	hParent = NULL;
	hGarten = NULL;
	hPlace = NULL;
	hTrash = NULL;
	LabelChild = NULL;
	ButtonChild = NULL;
	EditChild = NULL;
	LastChild = NULL;
	
	NewChild = NULL; NewType = 0;

	n_child = 0;
	
	i_mark = -1;
	MarkBox = NULL;
}

CSpawner::~CSpawner()
{
	Clear();

	if(MarkBox) delete MarkBox;
	if(LabelChild) delete LabelChild;
	if(ButtonChild) delete ButtonChild;
	if(EditChild) delete EditChild;
}

void CSpawner::setPlaces(HWND parent, HWND garten, HWND place, HWND trash)
{
	hParent = parent;
	hGarten = garten;
	hPlace = place;
	hTrash = trash;
}

void CSpawner::Prepare()
{
	LabelChild = new CXRect();
	ButtonChild = new CXButton();
	EditChild = new CXEdit();

	LabelChild->Create(hPlace);
	LabelChild->setCaption("Label");
	LabelChild->setXY(40,20);
	LabelChild->Enable(1);
	LabelChild->Show(1);

	ButtonChild->Create(hPlace);
	ButtonChild->setCaption("Button");
	ButtonChild->setXY(40,60);
	ButtonChild->Enable(1);
	ButtonChild->Show(1);

	EditChild->Create(hPlace);
	EditChild->setCaption("TextEdit");
	EditChild->setXY(40,100);
	EditChild->Enable(1);
	EditChild->Show(1);

	NewChild = NULL;
	x = 0; y = 0;
	b_resize = 0;

	LabelCount = 0; ButtonCount = 0; EditCount = 0;

	MarkBox = new CXMarkBox();
	MarkBox->Create(hGarten);
	Saved = 1;
}

void CSpawner::setGartenSize(int ndx, int ndy)
{
	dx = ndx;
	dy = ndy;
}

void CSpawner::ReleaseNew(int b)
{
	if(NewChild){ delete NewChild; NewChild = NULL; }
	if(!b)MessageBeep(MB_OK);
}

void CSpawner::setX(int nx)
{
	x = nx;
	Redraw();
}

void CSpawner::setY(int ny)
{
	y = ny;
	Redraw();
}

int CSpawner::ButtonDown(LPPOINT p)
{
	POINT pt;
	int r = 1,i,j;

	LastChild = NULL;
	maynew_x = -1;

	if((i_mark>=0)&&((i = MarkBox->isResizing(p))>=0))
	{
		r=1;
		b_resize = 1;i_resize = i;
		x_resize = p->x; y_resize = p->y;
		pt.x = p->x; pt.y = p->y;
		i = i_mark;
		Child[i]->AdjustXY(&pt);
		u_resize = pt.x; v_resize = pt.y;
		p->x -= pt.x; p->y -= pt.y;
		ScreenToClient(hGarten,p);
		CreateChild(hGarten,ChildT[i],p->x,p->y);
		NewChild->setDXDY(Child[i]->getDX(),Child[i]->getDY());
		NewChild->setCaption(Child[i]->getCaption());
		LastChild = Child[i];
		LastType = ChildT[i];
		n_child--;
		for(j = i; j < n_child; j++)
		{
			Child[j] = Child[j+1];
			ChildT[j] = ChildT[j+1];
			ChildX[j] = ChildX[j+1];
			ChildY[j] = ChildY[j+1];
		}
		LastChild->Show(0);
	}
	else
	{
		b_resize = 0;
		pt.x = p->x; pt.y = p->y;

	if(LabelChild->AdjustXY(&pt))
	{
		ScreenToClient(hParent,p);
		CreateChild(hParent,TYPE_LABEL,p->x,p->y);
		NewChild->setCaption("New Label");
	}
	else
	{
		pt.x = p->x; pt.y = p->y;
		if(ButtonChild->AdjustXY(&pt))
		{
			ScreenToClient(hParent,p);
			CreateChild(hParent,TYPE_BUTTON,p->x,p->y);
			NewChild->setCaption("New Button");
		}
		else
		{
			pt.x = p->x; pt.y = p->y;
			if(EditChild->AdjustXY(&pt))
			{
				ScreenToClient(hParent,p);
				CreateChild(hParent,TYPE_EDIT,p->x,p->y);
				NewChild->setCaption("New TextEdit");
			}
			else
			{
				r = 0;
				for(i=0; i<n_child; i++)
				{
					pt.x = p->x; pt.y = p->y;
					if(Child[i] && Child[i]->AdjustXY(&pt))
					{
						maynew_x = p->x; maynew_y = p->y;

						ScreenToClient(hParent,p);
						CreateChild(hParent,ChildT[i],p->x - pt.x, p->y - pt.y);
						NewChild->setDXDY(Child[i]->getDX(),Child[i]->getDY());
						NewChild->setCaption(Child[i]->getCaption());
						NewChild->Show(0);
						LastChild = Child[i];
						LastType = ChildT[i];
						n_child--;
						if(i_mark>i) i_mark--; else b_move = (i_mark == i);
						for(j = i; j < n_child; j++)
						{
							Child[j] = Child[j+1];
							ChildT[j] = ChildT[j+1];
							ChildX[j] = ChildX[j+1];
							ChildY[j] = ChildY[j+1];
						}
						r = 1;
						break;
					}
				}
			}
		}
	}
	if(r)
	{
		newx = pt.x;newy = pt.y;
	}
	}
	return r;
}

void CSpawner::ButtonUp(LPPOINT p)
{
	POINT pt;

	pt.x = p->x;pt.y = p->y;
	if(b_resize)
	{
		i_mark = n_child;
		ChildT[n_child] = LastType;
		Child[n_child] = LastChild;
		if(isResPlace(p))
		{
			LastChild->setXY(p->x,p->y);
			LastChild->setDXDY(NewChild->getDX(),NewChild->getDY());
			ChildX[n_child] = p->x + x;
			ChildY[n_child] = p->y + y;
			ReleaseNew(1);
			Saved = 0;
		}
		else
		{
			ChildX[n_child] = LastChild->getX() + x;
			ChildY[n_child] = LastChild->getY() + y;
			MarkBox->setXY(LastChild->getX(),LastChild->getY());
			MarkBox->setDXDY(LastChild->getDX(),LastChild->getDY());
			ReleaseNew(0);
		}
		LastChild->Enable(1);
		LastChild->Show(1);
		n_child++;
		b_resize = 0;
	}
	else
	{
	ScreenToClient(hTrash,&pt);
	if(LastChild&&((pt.x>=0)&&(pt.x<60)&&(pt.y>=0)&&(pt.y<60)))
	{
		ReleaseNew(1);
		delete LastChild;
		if(b_move) { MarkBox->Enable(0); i_mark = -1;}
		MessageBeep(MB_ICONEXCLAMATION);
			Saved = 0;
	}
	else
	{
	p->x -= newx;p->y -= newy;
	ScreenToClient(hGarten,p);
	if((maynew_x>=0) || (isPlace(p)&&(n_child<MAX_CHILD)))
	{
		Saved = 0;
		ReleaseNew(1);
		if(LastChild)
		{
			ChildT[n_child] = LastType;
			Child[n_child] = LastChild;
			LastChild->setXY(p->x,p->y);
			LastChild->Enable(1);
			LastChild->Redraw();
			if(maynew_x>=0)
			{
				i_mark = n_child;
				MarkBox->Enable(1);
				MarkBox->setXY(LastChild->getX(),LastChild->getY());
				MarkBox->setDXDY(LastChild->getDX(),LastChild->getDY());
			}
			if(b_move) { i_mark = n_child; MarkBox->setXY(LastChild->getX(),LastChild->getY());}
		}
		else
		{
			CreateChild(hGarten,NewType,p->x,p->y);
			ChildT[n_child] = NewType;
			Child[n_child] = NewChild;
			{
				int *i = &LabelCount;
				char s[32] = "Unknown";
				switch(NewType)
				{
				case TYPE_LABEL:
					strcpy(s,"Label");
					break;
				case TYPE_BUTTON:
					strcpy(s,"Button"); i = &ButtonCount;
					break;
				case TYPE_EDIT:
					strcpy(s,"TextEdit"); i = &EditCount;
					break;
				}
				(*i)++; if((*i)>=1000) (*i) = 0;
				sprintf(s,"%s #%d",s,(*i));
				NewChild->setCaption(s);
			}
			NewChild = NULL;
		}
		ChildX[n_child] = p->x + x;
		ChildY[n_child++] = p->y + y;
	}
	else 
	{
		ReleaseNew(0);
		if(LastChild)
		{
			ChildT[n_child] = LastType;
			Child[n_child] = LastChild;
			ChildX[n_child] = LastChild->getX() + x;
			ChildY[n_child] = LastChild->getY() + y;
			LastChild->Enable(1);
			if(b_move) { i_mark = n_child; MarkBox->setXY(LastChild->getX(),LastChild->getY());}
			n_child++;
		}
	}
	}
	}
	LastChild = NULL;
	b_move = 0;
	MarkBox->Redraw();
}

void CSpawner::MouseMove(LPPOINT p)
{
	POINT pt;
	BOOL tr;

	if(b_resize)
	{
		if(isResPlace(p))
		{
			NewChild->Enable(1);
		}
		else
		{
			NewChild->Enable(0);
		}
		NewChild->Redraw();
	}
	else
	{

	if((maynew_x == p->x)&&(maynew_y == p->y)) return;

	maynew_x = -1;
	if(NewChild)
	{

		pt.x = p->x;pt.y = p->y;
		ScreenToClient(hTrash,&pt);
		tr = (LastChild&&((pt.x>=0)&&(pt.x<60)&&(pt.y>=0)&&(pt.y<60)));

		p->x -= newx;p->y -= newy;
		pt.x = p->x; pt.y = p->y;
		ScreenToClient(hParent,&pt);
		NewChild->setXY(pt.x,pt.y);
		ScreenToClient(hGarten,p);
		if(isPlace(p) || tr)
		{
			NewChild->Enable(1);
			if(LastChild)LastChild->Enable(0);
		}
		else
		{
			NewChild->Enable(0);
			if(LastChild)LastChild->Enable(1);
		}
		NewChild->Show(1);
		NewChild->Redraw();
//		if(b_move) MarkBox->setXY(NewChild->getX(),NewChild->getY());
	}
	}
}

int CSpawner::isPlace(LPPOINT p)
{
	int r=0,i;
	if(NewChild)
	{
		if( (p->x >= 0) &&(p->y >= 0) && ((p->x + NewChild->getDX()) < dx) && (( (p->y+ NewChild->getDY()) < dy)))
		{
			r = 1;
			for(i=0;i<n_child;i++)
			{
				if(p->x>=(Child[i]->getX() + Child[i]->getDX())) continue;
				if((p->x+NewChild->getDX()) <= Child[i]->getX()) continue;
				if(p->y>=(Child[i]->getY() + Child[i]->getDY())) continue;
				if((p->y+NewChild->getDY()) <= Child[i]->getY()) continue;
				r = 0; break;
			}
		}
	}	
	return r;
}

void CSpawner::ResUp(int c)
{
	if(LastType != TYPE_EDIT)
	{
		c = LastChild->getDY() - c;
		if(c < DY_MINIMUM) c = DY_MINIMUM;
		if(c > DY_MAXIMUM) c = DY_MAXIMUM;
		NewChild->setDXDY(NewChild->getDX(),c);
		NewChild->setXY(LastChild->getX(),LastChild->getY() - (c - LastChild->getDY()));
	}
}

void CSpawner::ResDw(int c)
{
	if(LastType != TYPE_EDIT)
	{
		c = LastChild->getDY() + c;
		if(c < DY_MINIMUM) c = DY_MINIMUM;
		if(c > DY_MAXIMUM) c = DY_MAXIMUM;
		NewChild->setDXDY(NewChild->getDX(),c);
	}
}

void CSpawner::ResLf(int c)
{
	c = LastChild->getDX() - c;
	if(c < DX_MINIMUM) c = DX_MINIMUM;
	if(c > DX_MAXIMUM) c = DX_MAXIMUM;
	NewChild->setDXDY(c,NewChild->getDY());
	NewChild->setXY(LastChild->getX() - (c - LastChild->getDX()), LastChild->getY());
}

void CSpawner::ResRt(int c)
{
	c = LastChild->getDX() + c;
	if(c < DX_MINIMUM) c = DX_MINIMUM;
	if(c > DX_MAXIMUM) c = DX_MAXIMUM;
	NewChild->setDXDY(c,NewChild->getDY());
}

int CSpawner::isResPlace(LPPOINT p)
{
	int r = 0,cx,cy;

	cx = p->x - x_resize;
	cy = p->y - y_resize;

	switch(i_resize)
	{
	case 0:
		if(LastType != TYPE_EDIT)
		{
			cy = LastChild->getDY() - cy;
			if(cy < DY_MINIMUM) cy = DY_MINIMUM;
			if(cy > DY_MAXIMUM) cy = DY_MAXIMUM;
//			NewChild->setDXDY(NewChild->getDX(),c);
//			NewChild->setXY(LastChild->getX(),LastChild->getY() - (c - LastChild->getDY()));
		}
		else cy = NewChild->getDY();
		cx = LastChild->getDX() - cx;
		if(cx < DX_MINIMUM) cx = DX_MINIMUM;
		if(cx > DX_MAXIMUM) cx = DX_MAXIMUM;
		NewChild->setDXDY(cx,cy);
		NewChild->setXY(LastChild->getX() - (cx - LastChild->getDX()),LastChild->getY() - (cy - LastChild->getDY()));
		break;
	case 1:
		ResUp(cy);
		break;
	case 2:
		ResUp(cy);
		ResRt(cx);
		break;
	case 3:
		ResRt(cx);
		break;
	case 4:
		ResDw(cy);
		ResRt(cx);
		break;
	case 5:
		ResDw(cy);
		break;
	case 6:
		ResDw(cy);
		ResLf(cx);
		break;
	case 7:
		ResLf(cx);
		break;
	}

	p->x = NewChild->getX();p->y = NewChild->getY();

	r = isPlace(p);
	MarkBox->setXY(p->x,p->y);
	MarkBox->setDXDY(NewChild->getDX(),NewChild->getDY());
	return r;
}


void CSpawner::CreateChild(HWND hOwn, int t, int x, int y)
{
NewType = t;
switch(t)
{
case TYPE_LABEL:
		NewChild = new CXRect();
		NewChild->Create(hOwn);
	break;
case TYPE_BUTTON:
		NewChild = new CXButton();
		NewChild->Create(hOwn);
	break;
case TYPE_EDIT:
		NewChild = new CXEdit();
		NewChild->Create(hOwn);
	break;
}
NewChild->setXY(x,y);
NewChild->Enable(1);
NewChild->Show(1);
}

void CSpawner::Redraw()
{
	int i;
	if(hGarten)
	{
	for(i = 0; i<n_child; i++)
	{
		if(Child[i])
		{
			Child[i]->setXY(ChildX[i] - x,ChildY[i] - y);
		}
	}
	if(i_mark>=0) MarkBox->setXY(Child[i_mark]->getX(),Child[i_mark]->getY());
	InvalidateRgn(hGarten,NULL,TRUE);
	}
}

void CSpawner::Delete()
{
	int j;

	Saved = 0;
	if(i_mark>=0)
	{
		n_child--;
		
		delete Child[i_mark];

		for(j = i_mark; j < n_child; j++)
		{
			Child[j] = Child[j+1];
			ChildT[j] = ChildT[j+1];
			ChildX[j] = ChildX[j+1];
			ChildY[j] = ChildY[j+1];
		}

		b_move = 0;
		i_mark = -1;
		MarkBox->Enable(0);
		MessageBeep(MB_ICONEXCLAMATION);
	}
}


int CSpawner::getType(char **p)
{
	int r = 0;

	if(i_mark>=0)
	{
		r = (ChildT[i_mark] == TYPE_BUTTON)?2:1; 
		*p = Child[i_mark]->getCaption();
	}
	return r;
}

void CSpawner::UpdateText(char *s)
{
	Saved = 0;
	if(i_mark>=0)
	{
		Child[i_mark]->setCaption(s);
	}
}

void CSpawner::Save(char *fname)
{
	FILE *f;
	int i;
	char s[400];

	if( (f = fopen(fname,"w")) )
	{
		for(i=0;i<n_child;i++)
		{
			sprintf(s,"<%s left=\"%d\"; top=\"%d\"; width=\"%d\"; ", (ChildT[i]==TYPE_LABEL)?"Label":((ChildT[i]==TYPE_BUTTON)?"Button":"TextEdit"),ChildX[i],ChildY[i],Child[i]->getDX());
			if((ChildT[i]==TYPE_BUTTON)||(ChildT[i]==TYPE_LABEL))sprintf(s,"%s height=\"%d\"; ",s,Child[i]->getDY());
			sprintf(s,"%s %s=\"%s\">\n",s,(ChildT[i]==TYPE_BUTTON)?"caption":"text",Child[i]->getCaption());
			fputs(s,f);
		}
		Saved = 1;
		fclose(f);
	}
}

void CSpawner::Clear()
{
	register i;

	i_mark = -1;
	for(i = 0; i<n_child; i++)
	{
		if(Child[i]) delete Child[i];
	}
	n_child = 0;
	b_move = 0;
	b_resize = 0;
	LastChild = NULL;
	ReleaseNew(1);
	if(MarkBox)MarkBox->Enable(0);
}

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

#define Is_Control_Char iscntrl
#define	Is_White_Space	isspace 

#define ScanChar() getc(File)
#define	PeekChar()	((char) ungetc( getc(File), File ))

typedef enum {
	Begin_Token,Next_Token,Symbol_Token,String_Token,Error_Token,Eof_Token
} Token;

static FILE *File;
static char * Token_String ;
static char Token_Buffer[256];
static int Token_Index;

int Is_Delimiter(int c)
{
    return( Is_White_Space(c) || c == '<' || c == '>' || c == '"' || 
	    c == ';' || c == EOF || c== '\0');
}

Token Read_Token()
{
	int	ch ; 	/* Hold input characters */

READ_A_TOKEN:

	while ( Is_White_Space( ch = ScanChar() ) );

	switch ( ch )
	{
	case '<' : return Begin_Token;
//	case '>' : return End_Token;
	case ';' : return Next_Token;
	case '"' :
		Token_Index = 0 ;
		while ( (ch = ScanChar()) != '\"' ) 
		{
			if ( Token_Index >= 255 )
			{ return Error_Token;
			}
			Token_Buffer[ Token_Index++ ] = ch ;
		}
		Token_Buffer[Token_Index] = '\0' ;
		Token_String = Token_Buffer ;
		return String_Token ;

	case '\0': return Eof_Token;
	case EOF : return Eof_Token ;
	default :
				//return Read_Symbol( ch ) ;
		{
			Token_Index = 0 ;
			if (! Is_Control_Char(ch))
			{
				Token_Buffer[Token_Index++] = ch;
			}

			while ( !Is_Delimiter( PeekChar() ) )
			{
				ch = ScanChar();
				if (! Is_Control_Char(ch))
				{
					Token_Buffer[Token_Index++] = ch;
				}
			}; 
			if (Token_Index > 0)
			{
				Token_Buffer[Token_Index] = '\0' ;
				Token_String = Token_Buffer ;
				strlwr(Token_Buffer);
				return Symbol_Token ;
			} 
			else
			{
				goto READ_A_TOKEN;
			}

		}


	}
}



void CSpawner::Load(char *fname)
{
	int i;
	int mode;
	Token t;

	Clear(); // kill da stuff
	if( File = fopen(fname,"r") )
	{
		mode = 1; // at first step find da element beginning

		do
		{
			if( (t = Read_Token()) == Eof_Token) break;
			if((t == Begin_Token) && (mode>1)) {mode = 2; continue;}
			switch(mode)
			{
			case 1:
				if(t==Begin_Token)
				{
					mode = 2; // find da element type
				}
				break;
			case 2:
//				if(t == Begin_Token) continue;
				mode = 1; // if all will be bad then repeat da element beginning search
				if(t == Symbol_Token){
					if(!strcmp("label",Token_String))
					{
						ChildT[n_child] = TYPE_LABEL;
						Child[n_child] = new CXRect(); // create kinda label
						mode = 3; // find da props
					}
					if(!strcmp("button",Token_String))
					{
						ChildT[n_child] = TYPE_BUTTON;
						Child[n_child] = new CXButton(); // create kinda button
						mode = 3; // find da props
					}
					if(!strcmp("textedit",Token_String))
					{
						ChildT[n_child] = TYPE_EDIT;
						Child[n_child] = new CXEdit(); // create kinda edit
						mode = 3; // find da props
					}
					if(mode == 3)
					{
						if(hGarten)
						{
							Child[n_child]->Create(hGarten);
							Child[n_child]->Enable(1);
							Child[n_child]->Show(1);
						}
						ChildX[n_child] = 0; // TODO: fetch auto positions
						ChildY[n_child] = 0;
						n_child++;
					}
				}
				break;
			case 3:
				if(t == Symbol_Token){
					if(!strcmp("left=",Token_String)) {mode = 4; break;}
					if(!strcmp("top=",Token_String))  {mode = 5; break;}
					if(!strcmp("width=",Token_String))  {mode = 6; break;}
					if( (!strcmp("height=",Token_String)) && (ChildT[n_child-1]!=TYPE_EDIT))  {mode = 7; break;}
					if( (!strcmp("caption=",Token_String)) && (ChildT[n_child-1]==TYPE_BUTTON))  {mode = 8; break;}
					if( (!strcmp("text=",Token_String)) && (ChildT[n_child-1]!=TYPE_BUTTON))  {mode = 8; break;}
				}
				break;
			case 4:
				mode = 3; /// repeat usual stuff
				if(t == String_Token){
					if(sscanf(Token_String,"%d",&i) && (i>=0) && (i<2000)) ChildX[n_child-1] = i;
				}
				break;
			case 5:
				mode = 3; /// repeat usual stuff
				if(t == String_Token){
					if(sscanf(Token_String,"%d",&i) && (i>=0) && (i<2000)) ChildY[n_child-1] = i;
				}
				break;
			case 6:
				mode = 3; /// repeat usual stuff
				if(t == String_Token){
					if(sscanf(Token_String,"%d",&i) && (i>=0) && (i<DX_MAXIMUM)) Child[n_child-1]->setDXDY(i,Child[n_child-1]->getDY());
				}
				break;
			case 7:
				mode = 3; /// repeat usual stuff
				if(t == String_Token){
					if(sscanf(Token_String,"%d",&i) && (i>=0) && (i<DY_MAXIMUM)) Child[n_child-1]->setDXDY(Child[n_child-1]->getDX(),i);
				}
				break;
			case 8:
				mode = 3; /// repeat usual stuff
				if(t == String_Token){
					Child[n_child-1]->setCaption(Token_String);
				}
				break;
			}
		}while(n_child<MAX_CHILD);

		fclose(File);
		Saved = 1;
	}
	Redraw();
}

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////


static char *head[]={"<html><head><title>autogenerated kinez HTML</title>\n",
"<style type=text/css>td {font-family: Arial; font-size: 14px}</style></head>\n",
"<body bgcolor=\"#FFFFFF\" text=\"#000000\" leftmargin=\"0\" topmargin=\"0\">\n",
"<form name=\"f\" method=\"post\" action=\"\"><table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" "};
static char tail[]="</table></form></body></html>";
static int cx[MAX_CHILD*2];
static int cy[MAX_CHILD*2];
static int nx[MAX_CHILD];
static int ny[MAX_CHILD];
static int sx[MAX_CHILD];
static int sy[MAX_CHILD];

void CSpawner::SaveHTML(char *fname)
{
	FILE *f;
	int i,j,a,ix,iy,mx,xx,yy;
	register k,l;
	char s[400];
	int *map,*row;

	if( (f = fopen(fname,"w")) )
	{
		fputs(head[0],f);fputs(head[1],f);fputs(head[2],f);fputs(head[3],f);
		
		if(n_child>0)
		{
			ix = 0; iy = 0; mx = 0;
			for(i=0;i<n_child;i++)
			{
				a = ChildX[i];
				for(j = 0; j<ix; j++){
					if(a == cx[j]) break;
					if(a < cx[j]){
						for(k = ix; k>=j; k--) cx[k+1] = cx[k];
						ix++;break;
					}
				}
				cx[j] = a; if(j==ix) ix++; a+= Child[i]->getDX();

				if(ChildT[i] == TYPE_LABEL)
				{
					for(; j<ix; j++){
						if(a == cx[j]) break;
						if(a < cx[j]){
							for(k = ix; k>=j; k--) cx[k+1] = cx[k];
							ix++;break;
						}
					}
					cx[j] = a; if(j==ix) ix++;
				}
				else if(a>mx) mx = a;

				a = ChildY[i];
				for(j = 0; j<iy; j++){
					if(a == cy[j]) break;
					if(a < cy[j]){
						for(k = iy; k>=j; k--) cy[k+1] = cy[k];
						iy++;break;
					}
				}
				cy[j] = a; if(j==iy) iy++; a+= Child[i]->getDY();
				for(; j<iy; j++){
					if(a == cy[j]) break;
					if(a < cy[j]){
						for(k = iy; k>=j; k--) cy[k+1] = cy[k];
						iy++;break;
					}
				}
				cy[j] = a; if(j==iy) iy++;
			}
			if(mx>cx[ix-1]) cx[ix++] = mx;   // set da extreme right edge

			sprintf(s,"width=\"%d\">\n",cx[ix-1]);fputs(s,f);

			mx = (ix-1); map = new int[ mx*(iy-1)];
			memset(map,-1,mx*(iy-1)*4);
			for(i=0;i<n_child;i++)
			{
				a = ChildX[i];
				for(j=0;j<ix;j++)
				{
					if(cx[j]==a)
					{
						a+= Child[i]->getDX();
						for(k=(j+1);k<ix;k++)
						{
							if(a<=cx[k]){ nx[i] = k-j; break;}
						}
						xx = j;
						break;
					}
				}
				a = ChildY[i];
				for(j=0;j<iy;j++)
				{
					if(cy[j]==a)
					{
						a+= Child[i]->getDY();
						for(k=(j+1);k<iy;k++)
						{
							if(a<=cy[k]){ ny[i] = k-j; break;}
						}
						yy = j;
						break;
					}
				}
				for(j = yy; j<(ny[i]+yy); j++)
				{
					row = &map[j*mx];
					for(k = xx; k<(nx[i]+xx); k++)
					{
						row[k] = 0;
					}
				}
				map[yy*mx + xx] = i + 1;
			}

			// decrease da size by collapse space
			a = 2;
			for(i=0;i<(iy-1);i++)
			{
				row = &map[i*mx];
				for(j=0;j<mx;j++)
				{
					if(row[j] == -1)
					{
						xx = 1; yy =1; ix = j;
						for(j=(j+1); j<mx; j++)
						{
							if(row[j]!=-1) break;
							xx++;
						}
						for(k=i+1; k<(iy-1);k++)
						{
							for(l=ix;l<(ix+xx);l++)
							{
								if(map[k*mx+l]!=-1) break;
							}
							if(l<(ix+xx)) break;
							yy++;
						}

						if( (xx>4) || (yy>4) || ((xx*yy)>6) )
						{
							for(k=i; k<(yy+i); k++)
							{
								for(l = ix; l<(xx+ix); l++)
								{
									map[k*mx+l] = 0;
								}
							}
							sx[a] = xx; sy[a] = yy;
							row[ix] = -a; a++;
						}
						else j = ix;
					}
				}
			}
			fputs("<tr>",f);
			if(cx[0]){sprintf(s,"<td width=\"%d\" height=\"%d\">",cx[0],cy[0]); fputs(s,f);}
			for(i = 0; i<mx; i++){sprintf(s,"<td width=\"%d\">",cx[i+1] - cx[i]); fputs(s,f);}
			fputs("</tr>\n",f);

			xx = 0; yy=0;
			for(i=0; i<(iy-1); i++)
			{
				sprintf(s,"<tr><td height=\"%d\">",cy[i+1]-cy[i]); fputs(s,f);
				row = &map[i*mx];
				for(j=0; j<mx; j++)
				{
					k = row[j];
					if(k>0)
					{
						k--;
						if((nx[k]>1) && (ny[k]>1)) {sprintf(s,"<td colspan=\"%d\" rowspan=\"%d\"",nx[k],ny[k]); fputs(s,f);}
						else if(nx[k]>1) {sprintf(s,"<td colspan=\"%d\"",nx[k]); fputs(s,f);}
						else if(ny[k]>1) {sprintf(s,"<td rowspan=\"%d\"",ny[k]); fputs(s,f);}
						else fputs("<td",f);
						switch(ChildT[k])
						{
						case TYPE_LABEL: sprintf(s," valign=\"top\">%s",Child[k]->getCaption());break;
						case TYPE_BUTTON:
							sprintf(s,"><input type=\"submit\" value=\"%s\" name=\"x%d\" style=\"width: %d; height: %d\">",
								Child[k]->getCaption(),xx++,Child[k]->getDX(),Child[k]->getDY());
							break;
						case TYPE_EDIT:
							sprintf(s,"><input type=\"text\" value=\"%s\" name=\"y%d\" style=\"width: %d; height: %d\">",
								Child[k]->getCaption(),yy++,Child[k]->getDX(),Child[k]->getDY());
							break;
						}
						fputs(s,f);
					}
					else if(k<-1)
					{
						k=-k;
						if((sx[k]>1) && (sy[k]>1)) {sprintf(s,"<td colspan=\"%d\" rowspan=\"%d\">",sx[k],sy[k]);}
						else if(sx[k]>1) {sprintf(s,"<td colspan=\"%d\">",sx[k]);}
						else {sprintf(s,"<td rowspan=\"%d\">",sy[k]);}
						fputs(s,f);
					}
					else if(k==-1)fputs("<td>",f);
					
				}
				fputs("</tr>\n",f);
			}

			delete map; //reliz da cell's map
		}
		fputs(tail,f);
		fclose(f);
	}
}
