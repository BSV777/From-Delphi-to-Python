// Rect.h: interface for the CRect class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RECT_H__0F7E1881_420B_4B84_ADD2_998DC7E24A85__INCLUDED_)
#define AFX_RECT_H__0F7E1881_420B_4B84_ADD2_998DC7E24A85__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "windows.h"

#define DX_MINIMUM 50
#define DY_MINIMUM 22

#define DX_MAXIMUM 400
#define DY_MAXIMUM 300

class CXRect  
{
public:
	__inline char *getCaption(){return caption;};
	void setCaption(char *name);
	virtual void Create(HWND);

	__inline int isShow(){return show;};
	__inline int isEnable(){return enable;};

	__inline int getX(){return x;};
	__inline int getY(){return y;};
	__inline int getDX(){return dx;};
	__inline int getDY(){return dy;};

	__inline void Show(int b){if(hwnd)ShowWindow(hwnd,b?SW_SHOW:SW_HIDE);};
	__inline void Enable(int b){if(hwnd)EnableWindow(hwnd,b);};

	__inline void setXY(int nx, int ny){x = nx; y = ny; if(hwnd)SetWindowPos(hwnd,NULL,nx,ny,0,0,SWP_NOZORDER|SWP_NOSIZE|SWP_NOACTIVATE);};
	__inline void setDXDY(int ndx, int ndy){dx = ndx; dy = ndy; if(hwnd)SetWindowPos(hwnd,NULL,0,0,ndx,ndy,SWP_NOZORDER|SWP_NOMOVE|SWP_NOACTIVATE);};
	__inline void setTop(){SetWindowPos(hwnd,HWND_TOPMOST,0,0,0,0,SWP_NOSIZE|SWP_NOMOVE|SWP_SHOWWINDOW);};
	__inline int AdjustXY(LPPOINT p){ScreenToClient(hwnd,p);return ( (p->x >= 0) &&(p->y >= 0) &&(p->x < dx) &&(p->y < dy));};
	__inline void Redraw(){if(hwnd)InvalidateRgn(hwnd,NULL,TRUE);};
	CXRect();
	virtual ~CXRect();

protected:
	char caption[256];
	HWND hwnd;
	int x,y,dx,dy;
	int enable;
	int show;

};

#endif // !defined(AFX_RECT_H__0F7E1881_420B_4B84_ADD2_998DC7E24A85__INCLUDED_)
