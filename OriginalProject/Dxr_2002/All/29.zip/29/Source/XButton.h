// XButton.h: interface for the CXButton class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_XBUTTON_H__DE54CE80_8700_4BAA_B1F2_FB7236104B8C__INCLUDED_)
#define AFX_XBUTTON_H__DE54CE80_8700_4BAA_B1F2_FB7236104B8C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "XRect.h"

class CXButton : public CXRect  
{
public:
	virtual void Create(HWND);

	CXButton();
	virtual ~CXButton();

};

#endif // !defined(AFX_XBUTTON_H__DE54CE80_8700_4BAA_B1F2_FB7236104B8C__INCLUDED_)
