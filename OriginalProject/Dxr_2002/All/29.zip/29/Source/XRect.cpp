// Rect.cpp: implementation of the CRect class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "XRect.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CXRect::CXRect()
{
	hwnd = NULL;
	x = 0;
	y = 0;
	dx = DX_MINIMUM*2;
	dy = DY_MINIMUM;
	enable = 0;
	show = 0;
	caption[0] = '\0';
}

CXRect::~CXRect()
{
	if(hwnd) DestroyWindow(hwnd);
}

void CXRect::Create(HWND parent)
{
	hwnd = CreateWindow("STATIC",caption,WS_CHILD|SS_LEFT  ,x,y,dx,dy,parent,NULL,(HINSTANCE) GetWindowLong(parent, GWL_HINSTANCE),NULL);
}


void CXRect::setCaption(char *name)
{
	register char *p=caption;

	if(name) {do{*p = *name++;}while(*p++);};
	if(hwnd) SetWindowText(hwnd,caption);
}
