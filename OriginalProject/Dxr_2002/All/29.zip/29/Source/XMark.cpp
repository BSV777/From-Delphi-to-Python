// XMark.cpp: implementation of the CXMark class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "XMark.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CXMark::CXMark()
{
dx = 8;dy = 8;
}

CXMark::~CXMark()
{

}

void CXMark::Create(HWND parent)
{
	hwnd = CreateWindow("STATIC",caption,WS_CHILD |WS_BORDER| SS_WHITERECT ,x,y,dx,dy,parent,NULL,(HINSTANCE) GetWindowLong(parent, GWL_HINSTANCE),NULL);
}

