//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDR_MENU1                       101
#define IDI_ICON1                       102
#define IDD_DIALOGBAR                   103
#define IDR_ACCELERATOR1                103
#define IDB_BITMAP1                     104
#define IDD_ABOUTBOX                    105
#define IDC_SCROLLBAR1                  1001
#define IDC_CUSTOM1                     1002
#define IDC_SCROLLBAR2                  1003
#define ID_FILENEW                      40001
#define ID_FILELOAD                     40002
#define ID_FILEHTML                     40003
#define IDM_ABOUT                       40004
#define ID_FILESAVE                     40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
