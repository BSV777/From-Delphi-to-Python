// EditorView.h : interface of the CEditorView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_EDITORVIEW_H__7EB284E9_1F8B_4284_975B_199304543C29__INCLUDED_)
#define AFX_EDITORVIEW_H__7EB284E9_1F8B_4284_975B_199304543C29__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "PropertyDialog.h"

class CEditorView : public CFormView
{
protected: // create from serialization only
	CEditorView();
	DECLARE_DYNCREATE(CEditorView)

public:
	//{{AFX_DATA(CEditorView)
	enum{ IDD = IDD_EDITOR_FORM };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	CEditorDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditorView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual void OnDraw(CDC* pDC);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
public:
	void ShowError(int nControl, LPRECT lpRect = NULL);
	CMenu m_menuPopup;
	HCURSOR m_hButtonCursor;
	HCURSOR m_hEditCursor;
	HCURSOR m_hLabelCursor;
	enum {
		MODE_SELECT,
		MODE_ADD_BUTTON,
		MODE_ADD_EDIT,
		MODE_ADD_LABEL
	} m_nMode;
	int m_iSelected;
	virtual ~CEditorView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	void OnPopupMenu(CPoint point);

// Generated message map functions
protected:
	//{{AFX_MSG(CEditorView)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnAddButton();
	afx_msg void OnUpdateAddButton(CCmdUI* pCmdUI);
	afx_msg void OnAddEdit();
	afx_msg void OnUpdateAddEdit(CCmdUI* pCmdUI);
	afx_msg void OnAddLabel();
	afx_msg void OnUpdateAddLabel(CCmdUI* pCmdUI);
	afx_msg void OnDeleteControl();
	afx_msg void OnUpdateDeleteControl(CCmdUI* pCmdUI);
	afx_msg void OnModeSelect();
	afx_msg void OnUpdateModeSelect(CCmdUI* pCmdUI);
	afx_msg void OnProperty();
	afx_msg void OnUpdateProperty(CCmdUI* pCmdUI);
	afx_msg void OnExportToHtml();
	afx_msg void OnPrevControl();
	afx_msg void OnNextControl();
	afx_msg void OnUpdatePrevControl(CCmdUI* pCmdUI);
	afx_msg void OnUpdateNextControl(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in EditorView.cpp
inline CEditorDoc* CEditorView::GetDocument()
   { return (CEditorDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITORVIEW_H__7EB284E9_1F8B_4284_975B_199304543C29__INCLUDED_)
