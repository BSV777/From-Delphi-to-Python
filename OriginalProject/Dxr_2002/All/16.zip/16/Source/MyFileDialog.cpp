// MyFileDialog.cpp : implementation file
//

#include "stdafx.h"
#include "Editor.h"
#include "MyFileDialog.h"
#include <dlgs.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyFileDialog

IMPLEMENT_DYNAMIC(CMyFileDialog, CFileDialog)

CMyFileDialog::CMyFileDialog(BOOL bOpenFileDialog, LPCTSTR lpszDefExt, LPCTSTR lpszFileName,
		DWORD dwFlags, LPCTSTR lpszFilter, CWnd* pParentWnd) :
		CFileDialog(bOpenFileDialog, lpszDefExt, lpszFileName, dwFlags, lpszFilter, pParentWnd)
{
}


BEGIN_MESSAGE_MAP(CMyFileDialog, CFileDialog)
	//{{AFX_MSG_MAP(CMyFileDialog)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CMyFileDialog::OnInitDialog() 
{
	CFileDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CWnd* pWnd = GetParent();
	RECT Rect;

	CWnd *wndComboCtrl = pWnd->GetDlgItem(cmb1);
	wndComboCtrl->GetWindowRect(&Rect);
	pWnd->ScreenToClient(&Rect);

	Rect.top += 25;
	Rect.bottom += 25;

	m_CheckBox.Create(_T("������ HTML 3.2"), BS_AUTOCHECKBOX | WS_VISIBLE | WS_CHILD,
		Rect, pWnd, WM_USER+1);	
	m_CheckBox.SetCheck(m_bSimple);
	m_CheckBox.SetFont(wndComboCtrl->GetFont(), TRUE);


	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CMyFileDialog::OnDestroy() 
{
	CFileDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	m_bSimple = m_CheckBox.GetCheck();	
}
