// ProgressDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Editor.h"
#include "ProgressDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CProgressDlg dialog


CProgressDlg::CProgressDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CProgressDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CProgressDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CProgressDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CProgressDlg)
	DDX_Control(pDX, IDC_PROGRESS1, m_Progress);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CProgressDlg, CDialog)
	//{{AFX_MSG_MAP(CProgressDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CProgressDlg message handlers

void CProgressDlg::Step()
{
	m_nPosition++;
	if (m_nPosition > m_nHigh)
		return;
	m_Progress.SetPos(m_nPosition);
}

BOOL CProgressDlg::Create(int nLow, int nHigh)
{
	if (!CDialog::Create(CProgressDlg::IDD))
		return FALSE;

	m_nLow = nLow;
	m_nHigh = nHigh;
	m_nPosition = nLow;
	m_Progress.SetRange32(m_nLow, m_nHigh);
	m_Progress.SetPos(m_nPosition);
	return TRUE;
}
