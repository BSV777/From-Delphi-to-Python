// Controls.h: interface for the CMyButton class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CONTROLS_H__38975108_F07B_40BA_A3AB_7052DE9DE884__INCLUDED_)
#define AFX_CONTROLS_H__38975108_F07B_40BA_A3AB_7052DE9DE884__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define TEXTEDIT_FIXED_HEIGHT	25		// ������������� ������ ������� TextEdit
#define DEFAULT_WIDTH			100		// ������ ������� �� ���������
#define DEFAULT_HEIGHT			25		// ������ ������� �� ���������

UINT GetNewID();
void ValidateString(CString* str);

class CMyTracker : public CRectTracker  
{
public:
	int HitTest(CPoint point);
	void GetTrueRect( LPRECT lpTrueRect );
	CRect m_rectClient;
	BOOL SetCursor( CScrollView* pWnd, UINT nHitTest );
	void Draw( CDC* pDC, CScrollView* pWnd);
	BOOL Track( CScrollView* pWnd, CPoint point, BOOL bAllowInvert = FALSE, CScrollView* pWndClipTo = NULL );
	UINT GetHandleMask() const;
	int m_nConstWidth;
	int m_nConstHeight;
	CMyTracker();
	CMyTracker(LPCRECT lpSrcRect, UINT nStyle);
	virtual ~CMyTracker();

//private:
//	CScrollView* m_pScrollView;
};

class CMyControl : public CObject  
{
DECLARE_DYNAMIC(CMyControl)
public:
	virtual void GetHTML(CString* pString);
	BOOL GetValue(LPCTSTR lpszFormat, LPCTSTR lpszName, int* iValue);
	BOOL GetValue(LPCTSTR lpszFormat, LPCTSTR lpszName, LPTSTR lpszValue, int iMaxLen);
	int Top();
	int Left();
	int Height();
	int Width();
	UINT GetID();
	virtual void OnDraw(CDC* pDC);
	CMyControl(LPRECT lpRect=NULL);
	virtual ~CMyControl();
	LPRECT GetRect(LPRECT lpRect = NULL);
	virtual void SetRect(CRect Rect);

	CMyTracker m_Rect;
protected:
	UINT ID;

};

class CMyButton : public CMyControl  
{
DECLARE_DYNAMIC(CMyButton)
public:
	void GetHTML(CString* pString);
	CMyButton(LPCTSTR lpszFormat);
	CMyButton(LPRECT lpRect=NULL, LPCTSTR szCaption=NULL);
	virtual ~CMyButton();
	virtual void Serialize(CArchive &ar);
	void OnDraw(CDC *pDC);
	void SetCaption(LPCTSTR szCaption);
	LPTSTR GetCaption(LPTSTR szCaption = NULL);
protected:
	char Caption[256];

};

class CMyTextEdit : public CMyControl
{
DECLARE_DYNAMIC(CMyTextEdit)
public:
	void GetHTML(CString* pString);
	void SetRect(CRect Rect);
	CMyTextEdit(LPCTSTR lpszFormat);
	CMyTextEdit(LPRECT lpRect=NULL, LPCTSTR szText=NULL);
	virtual ~CMyTextEdit();
	virtual void Serialize(CArchive &ar);
	void OnDraw(CDC *pDC);
	void SetText(LPCTSTR szText);
	LPTSTR GetText(LPTSTR szText = NULL);
protected:
	char Text[256];

};

class CMyLabel : public CMyControl
{
DECLARE_DYNAMIC(CMyLabel)
public:
	void GetHTML(CString* pString);
	CMyLabel(LPCTSTR lpszFormat);
	CMyLabel(LPRECT lpRect=NULL, LPCTSTR szText=NULL);
	virtual ~CMyLabel();
	virtual void Serialize(CArchive &ar);
	void OnDraw(CDC *pDC);
	void SetText(LPCTSTR szText);
	LPTSTR GetText(LPTSTR szText = NULL);
protected:
	char Text[256];
};

#endif // !defined(AFX_CONTROLS_H__38975108_F07B_40BA_A3AB_7052DE9DE884__INCLUDED_)
