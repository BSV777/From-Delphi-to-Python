#if !defined(AFX_PROPERTYDIALOG_H__9875D817_452C_4D18_9D68_13044D12A6A6__INCLUDED_)
#define AFX_PROPERTYDIALOG_H__9875D817_452C_4D18_9D68_13044D12A6A6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropertyDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropertyDialog dialog

class CPropertyDialog : public CDialog
{
// Construction
public:
	BOOL m_bHeightEnabled;
	CPropertyDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPropertyDialog)
	enum { IDD = IDD_CONTROL_PROPERTY };
	CSpinButtonCtrl	m_Spin4;
	CSpinButtonCtrl	m_Spin3;
	CSpinButtonCtrl	m_Spin2;
	CSpinButtonCtrl	m_Spin1;
	CString	m_strText;
	int		m_iHeight;
	int		m_iLeft;
	int		m_iTop;
	int		m_iWidth;
	CString	m_strTextCaption;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPropertyDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPropertyDialog)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPERTYDIALOG_H__9875D817_452C_4D18_9D68_13044D12A6A6__INCLUDED_)
