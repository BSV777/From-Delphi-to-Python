//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Editor.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_EDITOR_FORM                 101
#define IDR_MAINFRAME                   128
#define IDR_EDITORTYPE                  129
#define IDR_TOOLBAR1                    130
#define IDC_BUTTON_CURSOR               132
#define IDC_EDIT_CURSOR                 133
#define IDC_LABEL_CURSOR                134
#define IDD_CONTROL_PROPERTY            135
#define IDR_POPUP_MENU                  136
#define IDD_PROGRESS_DLG                137
#define IDD_MY_FILEDIALOG               139
#define IDC_BUTTON1                     1002
#define IDC_EDIT_TEXT                   1003
#define IDC_TEXT_TEXT                   1004
#define IDC_EDIT_LEFT                   1005
#define IDC_EDIT_TOP                    1006
#define IDC_EDIT_WIDTH                  1007
#define IDC_EDIT_HEIGHT                 1008
#define IDC_SPIN1                       1013
#define IDC_SPIN2                       1014
#define IDC_SPIN3                       1015
#define IDC_SPIN4                       1016
#define IDC_PROGRESS1                   1017
#define IDC_IPADDRESS1                  1018
#define ID_MODE_SELECT                  32771
#define ID_ADD_BUTTON                   32772
#define ID_ADD_EDIT                     32773
#define ID_ADD_LABEL                    32774
#define ID_DELETE_CONTROL               32775
#define ID_EDIT_ADD_EDIT                32777
#define ID_PROPERTY                     32780
#define ID_FILE_EXPORT_HTML             32783
#define ID_NEXT_CONTROL                 32784
#define ID_PREV_CONTROL                 32785

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32786
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
