#ifndef htmlButtonH
#define htmlButtonH

#include <SysUtils.hpp>
#include <Controls.hpp>
#include <Classes.hpp>
#include <Forms.hpp>
#include "htmlControl.h"

class PACKAGE htmlButton : public htmlControl
{
    private:
        TButton *btn;

    protected:

        void __fastcall setCaption(AnsiString);
        AnsiString __fastcall getCaption(void);

    public:
        __fastcall htmlButton(TComponent* Owner);

        virtual AnsiString __fastcall toHhtml(void);

    __published:
        __property AnsiString caption = { read=getCaption, write=setCaption };
};

#endif
