#include <vcl.h>
#pragma hdrstop

#include "htmlButton.h"
#pragma link "htmlControl"
#pragma package(smart_init)

static inline void ValidCtrCheck(htmlButton *)
{
    new htmlButton(NULL);
}

namespace Htmlbutton
{
    void __fastcall PACKAGE Register()
    {
         TComponentClass classes[1] = {__classid(htmlButton)};
         RegisterComponents("Samples", classes, 0);
    }
}

__fastcall htmlButton::htmlButton(TComponent* Owner)
    : htmlControl(Owner)
{
    name = "Button";

    btn = new TButton(this);
    setControl(btn);

    btn->Height = 21;
    updateSize();

    addProperty("Caption", getCaption, setCaption, "");
}

void __fastcall htmlButton::setCaption(AnsiString s) {
    btn->Caption = s.SubString(1, 255);
    Repaint();
}

AnsiString __fastcall htmlButton::getCaption(void) {
    return btn->Caption;
}

AnsiString __fastcall htmlButton::toHhtml(void) {
    AnsiString value = btn->Caption;
    int real_size = 12 + 5 * value.Length(),
        dsize = (right-left) - real_size;

    int more = (int)dsize / 5;

    if (more > 0) {
        while (more) {
            value.Insert(" ", 1);
            if (--more) {
                value.Insert(" ", value.Length()+1);
                more--;
            }
        }
    }
    if (more < 0) {
        more *= (-1);
        while (more) {
            value.Delete(1, 1);
            if (--more) {
                value.Delete(value.Length(), 1);
                more--;
            }
        }
    }

    AnsiString res = "<input type=\"button\" value=\"" + value + "\">";
    return res;
}

