#include <vcl.h>
#pragma hdrstop

#include "htmlTextEdit.h"
#pragma link "htmlControl"
#pragma package(smart_init)

static inline void ValidCtrCheck(htmlTextEdit *)
{
    new htmlTextEdit(NULL);
}

namespace Htmltextedit
{
    void __fastcall PACKAGE Register()
    {
         TComponentClass classes[1] = {__classid(htmlTextEdit)};
         RegisterComponents("Samples", classes, 0);
    }
}

__fastcall htmlTextEdit::htmlTextEdit(TComponent* Owner)
    : htmlControl(Owner)
{
    name = "TextEdit";

    edit = new TEdit(this); 
    setControl(edit);

    control->Height = 19;
    updateSize();    
    allowHeightChange = false;

    addProperty("Text", getText, setText, "");
}

AnsiString __fastcall htmlTextEdit::getText(void) {
    return edit->Text;
}

void __fastcall htmlTextEdit::setText(AnsiString s) {
    edit->Text = s.SubString(1, 255);
    Repaint();
}

AnsiString __fastcall htmlTextEdit::toHhtml(void) {
    int size = (int)edit->Width / 6;
    AnsiString res = "<input value=\"" + edit->Text + "\" maxlength=\"255\" " +
                     "size=\"" + size + "\">";
    return res;
}
