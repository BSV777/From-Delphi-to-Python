// ============================================================================
//
//  main.h, main.cpp
//  �����: ����� ������� (atv_jr@hotbox.ru)
//  ���� ���������: 28.03.02
//
//  ���� ���������� ��������� 
//
// ============================================================================

#ifndef mainH
#define mainH

#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>

#include "htmlControl.h"
#include "inspect.h"
#include <Menus.hpp>
#include <ImgList.hpp>
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
#include <ToolWin.hpp>
#include "htmlLabel.h"
#include "htmlTextEdit.h"
#include "htmlButton.h"
#include <Grids.hpp>
#include <vector>
using namespace std;

istream& operator>>(istream&, htmlControl **);

class TMainForm : public TForm
{
__published:
    TPanel *LeftDockPanel;
    TSplitter *LeftSplitter;
    TScrollBox *EditorBox;
    TShape *shape;
    TMainMenu *MainMenu;
    TMenuItem *FileMenu;
    TMenuItem *FileNewItem;
    TMenuItem *FileOpenItem;
    TMenuItem *FileSaveItem;
    TMenuItem *FileSaveAsItem;
    TMenuItem *N6;
    TMenuItem *FileExitItem;
    TMenuItem *EditMenu;
    TMenuItem *EditCutItem;
    TMenuItem *EditCopyItem;
    TMenuItem *EditPasteItem;
    TMenuItem *EditDelItem;
    TMenuItem *EditSelAllItem;
    TMenuItem *ViewInspectorItem;
    TMenuItem *HelpMenu;
    TMenuItem *HelpAboutItem;
    TImageList *ImageList;
    TMenuItem *ConvertMenu;
    TMenuItem *ConvertHTMLItem;
    TMenuItem *N1;
    TMenuItem *N2;
    TStatusBar *StatusBar;
    TOpenDialog *OpenDlg;
    TSaveDialog *SaveDlg;
    TControlBar *ControlBar;
    TToolBar *FileToolBar;
    TToolButton *NewBtn;
    TToolButton *OpenBtn;
    TToolButton *SaveBtn;
    TToolBar *EditToolBar;
    TToolButton *CutBtn;
    TToolButton *CopyBtn;
    TToolButton *PasteBtn;
    TToolButton *DelAllBtn;
    TToolBar *ConvertToolBar;
    TToolButton *InspectBtn;
    TToolButton *Separator;
    TToolButton *ConvertBtn;
    TToolBar *ComponentToolBar;
    TToolButton *CompMouseBtn;
    TToolButton *CompLabelBtn;
    TToolButton *CompTextEditBtn;
    TToolButton *CompButtonBtn;
    TImageList *CompImage;
    TSaveDialog *SaveHtmlDlg;
    void __fastcall OnMouseDown(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
    void __fastcall OnMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
    void __fastcall OnMouseUp(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);

    void __fastcall htmlControlSelect(TObject *Sender, bool shift, bool &sel);

    void __fastcall htmlControlCanMove(TObject *Sender, bool &can);
    void __fastcall htmlControlMoving(TObject *Sender, int dx, int dy);
    void __fastcall htmlControlEndMove(TObject *Sender, int dx, int dy);

    void __fastcall htmlControlCanResize(TObject *Sender, bool &can);
    void __fastcall htmlControlEndResize(TObject *Sender, TRect r);
    void __fastcall htmlControlResizing(TObject *Sender, TRect r);

    void __fastcall LeftDockPanelDockOver(TObject *Sender,
          TDragDockObject *Source, int X, int Y, TDragState State,
          bool &Accept);
    void __fastcall LeftDockPanelDockDrop(TObject *Sender,
          TDragDockObject *Source, int X, int Y);
    void __fastcall LeftDockPanelUnDock(TObject *Sender, TControl *Client,
          TWinControl *NewTarget, bool &Allow);

    void __fastcall FileNewItemClick(TObject *Sender);
    void __fastcall FileOpenItemClick(TObject *Sender);
    void __fastcall FileSaveItemClick(TObject *Sender);
    void __fastcall FileSaveAsItemClick(TObject *Sender);
    void __fastcall FileExitItemClick(TObject *Sender);

    void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);

    void __fastcall ViewInspectorItemClick(TObject *Sender);

    void __fastcall CompBtnClick(TObject *Sender);
    void __fastcall EditSelAllItemClick(TObject *Sender);
    void __fastcall EditDelItemClick(TObject *Sender);
    void __fastcall EditCutItemClick(TObject *Sender);
    void __fastcall EditCopyItemClick(TObject *Sender);
    void __fastcall EditPasteItemClick(TObject *Sender);
    void __fastcall ConvertHTMLItemClick(TObject *Sender);
    void __fastcall ConvertBtnClick(TObject *Sender);
    void __fastcall HelpAboutItemClick(TObject *Sender);

// ============================================================================
//
    private:

        int shape_ox, shape_oy;

        void __fastcall updateShape(int x, int y);
        bool __fastcall inShape(TWinControl*);

        vector<htmlControl*> selection;
        bool move;
        vector<TShape*> *shapes;
        TShape *resize_shape;

        void __fastcall clearSelection(void);
        void __fastcall addToSelection(htmlControl* cntrl);
        void __fastcall removeFromSelection(htmlControl* cntrl);

        void __fastcall updateInspector(void);

        AnsiString filename;
        bool changed;

        void __fastcall updateCaption(void);
        bool __fastcall newEditor(void);
        void __fastcall Save(void);
        void __fastcall SaveAs(void);

        void __fastcall createData(vector<htmlControl*>&);

        bool insert;

        void __fastcall insertHtmlComponent(void);

        void __fastcall updateEditMenu(void);
        void __fastcall registerClasses(void);

        void __fastcall checkOverlap(void);

    public:

        __fastcall TMainForm(TComponent* Owner);

        void __fastcall hideDockPanel(void);
        void __fastcall showDockPanel(void);
};

extern PACKAGE TMainForm *MainForm;

#endif
