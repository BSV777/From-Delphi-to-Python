#include <vcl.h>
#pragma hdrstop

#include "html_stream.h"

#pragma package(smart_init)

void __fastcall htmlStream::putCell(bool width_def, int width,
                                    bool height_def, int height,
                                    int colspan, int rowspan,
                                    AnsiString text)
{
    *this << "  <td";

    if (width_def) *this << " width=\"" << width << "\"";
    if (height_def) *this << " height=\"" << height << "\"";
    if (colspan > 1) *this << " colspan=\"" << colspan << "\"";
    if (rowspan > 1) *this << " rowspan=\"" << rowspan << "\"";    

    if (text != "")
        *this << ">" << text.c_str() << "</td>\n";
    else
        *this << "/>\n";
}

