// OptimConfTabl.cpp: implementation of the COptimConfTabl class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HtmlObject.h"
#include "OptimConfTabl.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

COptimConfTabl::COptimConfTabl()
{

}

COptimConfTabl::~COptimConfTabl()
{

}
