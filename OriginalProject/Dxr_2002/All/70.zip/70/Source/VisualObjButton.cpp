// VisualObjButton.cpp: implementation of the CVisualObjButton class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HtmlObject.h"
#include "VisualObjButton.h"
#include "HtmlObjButton.h"
#include "HtmlObjectView.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CVisualObjButton::CVisualObjButton(CHtmlObjectView* parent, CRect &r, CHtmlObj* htmlobj):CVisualObj(parent,htmlobj)
{
	CButton* b;
	b=new CButton;
	m_Wnd=b;
	b->Create(((CHtmlObjButton*)htmlobj)->m_Caption, WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON, r, parent, 1);
	SetWndProc();
}

void CVisualObjButton::UpdateProperites()
{
	CVisualObj::UpdateProperites();
	m_Wnd->SetWindowText(((CHtmlObjButton*)m_HtmlObj)->m_Caption);
}
