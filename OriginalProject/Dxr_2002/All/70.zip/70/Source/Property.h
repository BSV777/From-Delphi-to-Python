// Property.h: interface for the CProperty class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROPERTY_H__CB80C32A_E390_4D83_BA61_8D543326453E__INCLUDED_)
#define AFX_PROPERTY_H__CB80C32A_E390_4D83_BA61_8D543326453E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CProperty: public CObject  
{
public:
	void SetProperty(LPCTSTR name, LPCTSTR value);
	BOOL IsDefined;
	CString Value;
	CString Name;
	CProperty(LPCTSTR name, LPCTSTR value);
};

#endif // !defined(AFX_PROPERTY_H__CB80C32A_E390_4D83_BA61_8D543326453E__INCLUDED_)
