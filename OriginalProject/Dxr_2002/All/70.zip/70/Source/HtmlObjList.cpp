// HtmlObjList.cpp: implementation of the CHtmlObjList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HtmlObject.h"
#include "HtmlObjList.h"
#include "Parser.h"

#include "HtmlObj.h"
#include "HtmlObjLabel.h"
#include "HtmlObjTextEdit.h"
#include "HtmlObjButton.h"

#include "OptimConfTabl.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHtmlObjList::CHtmlObjList()
{
	m_Height=0;
	m_Width=0;
	m_KolObj=0;
}

CHtmlObjList::~CHtmlObjList()
{

}

int CHtmlObjList::ReadConfig(CString fn, CString erfn)
{
	CFile f;
	if( !f.Open( fn, CFile::modeRead ) ) {
		return cannotopen;
	};
	CArchive ar( &f, CArchive::load, 16384);


	CFile fer;
	if( !fer.Open( erfn, CFile::modeCreate | CFile::modeWrite ) ) {
		return cannotopenerfile;
	};
	CArchive arer( &fer, CArchive::store, 8192);

	BOOL b=ReadConfig(&ar, &arer); 

	ar.Close();
	arer.Close();
	f.Close();
	fer.Close();

	return b;
}

int CHtmlObjList::ReadConfig(CArchive *ar, CArchive *arer)
{
	TCreateIfMyName* tblf[]={CHtmlObjButton::CreateIfMyName,
		CHtmlObjLabel::CreateIfMyName,
		CHtmlObjTextEdit::CreateIfMyName
	};

	CParser Ps(ar, arer, *this, tblf, 3);
	if(Ps.Parse()){
		MakeNonIntersectHeight();
		return Ps.m_Error;
	}
	else return Ps.m_Error;
}

BOOL CHtmlObjList::WriteConfig(CArchive &ar)
{
	POSITION pos;
	CHtmlObj* o;
	pos=GetHeadPosition();
	while(pos!=NULL){
		o=GetAt(pos);
		if(!o->WriteConfig(ar)){
			return FALSE;
		};
		GetNext(pos);
	};
	return TRUE;
}

void CHtmlObjList::FreeObj()
{
	POSITION pos;
	CHtmlObj* o;
	pos=GetHeadPosition();
	while(pos!=NULL){
		o=GetAt(pos);
		delete o;
		GetNext(pos);
	};
	RemoveAll();
	m_SortVert.RemoveAll();
	m_Height=0;
	m_Width=0;
}

void CHtmlObjList::Insert(CHtmlObj *o)
{
	POSITION pos;
	CHtmlObj* obj;
	pos=GetTailPosition(); // �� ����������� x
	BOOL b=TRUE;

	int top=o->m_Rect.top;
	int left=o->m_Rect.left;
	int right=o->m_Rect.right;
	int bottom=o->m_Rect.bottom;
	if(right>m_Width)m_Width=right;
	if(bottom>m_Height)m_Height=bottom;
	while(pos!=NULL&&b){
		obj=GetAt(pos);
		if((obj->m_Rect.left < left)||((obj->m_Rect.left ==left)&&(obj->m_Rect.top <=top))){
			InsertAfter(pos, o);
			b=FALSE;
		};
		GetPrev(pos);
	};	
	if(b){
		AddHead(o);
	};


	pos=m_SortVert.GetTailPosition(); // �� ����������� y
	b=TRUE;
	top=o->m_Rect.top;
	left=o->m_Rect.left;
	while(pos!=NULL&&b){
		obj=m_SortVert.GetAt(pos);
		if((obj->m_Rect.top < top)||((obj->m_Rect.top ==top)&&(obj->m_Rect.left <=left))){
			m_SortVert.InsertAfter(pos, o);
			b=FALSE;
		};
		m_SortVert.GetPrev(pos);
	};	
	if(b){
		m_SortVert.AddHead(o);
	};
	m_KolObj++;

}

void CHtmlObjList::DeleteObj(CHtmlObj *o)
{
	POSITION pos;
	if( ( pos = Find( o ) ) != NULL ) {
		RemoveAt(pos);	
	}
	if( ( pos = m_SortVert.Find( o ) ) != NULL ) {
		m_SortVert.RemoveAt(pos);	
	}
	RecalcHeightWidth();
	m_KolObj--;
}

void CHtmlObjList::MakeNonIntersectHeight()
{
	POSITION pos,curpos, movepos;
	CHtmlObj *obj,*curobj,*moveobj;
	int hmove;
	CRect ris;

	curpos=m_SortVert.GetHeadPosition();
	if(curpos){
		m_SortVert.GetNext(curpos);
		while(curpos!=NULL){
			curobj=m_SortVert.GetAt(curpos);

			pos=m_SortVert.GetHeadPosition();
			while(pos!=curpos){
				obj=m_SortVert.GetAt(pos);
				ris.IntersectRect(obj->m_Rect, curobj->m_Rect);
				if(!ris.IsRectEmpty()){
					hmove=obj->m_Rect.bottom-curobj->m_Rect.top;
					// ������� ��� ������� � curobj �� hmove
					curobj->m_Rect.top+=hmove;
					curobj->m_Rect.bottom+=hmove;
					
					movepos=curpos;
					m_SortVert.GetNext(movepos);
					if(movepos){
						moveobj=m_SortVert.GetAt(movepos);
						if(moveobj->m_Rect.top<=curobj->m_Rect.top){
							while(movepos){
								moveobj=m_SortVert.GetAt(movepos);
								moveobj->m_Rect.top+=hmove;
								moveobj->m_Rect.bottom+=hmove;
								m_SortVert.GetNext(movepos);
							};
						};
					};


				};


				m_SortVert.GetNext(pos);
			};
			m_SortVert.GetNext(curpos);
		};	
	};
	RecalcHeightWidth();

}

#define WIDTHENDCELL 100
#define HEIGHTENDCELL 100


BOOL CHtmlObjList::WriteToHtml(CArchive *ar, int optimize)
{
	POSITION posgor, posvert, begposgor, begposvert;
	CHtmlObj *obj;
	int topall,leftall, top, left, 
		curvert, curgor, height,width, i, j,ii,jj,iii,jjj, kolstr, kolstolb,
		widthtable, heighttable,sum;
	int *widthar, *heightar;
	CString s;
	BOOL isleftfree, istopfree;
	
	struct CCell
	{
		CHtmlObj* obj;
		int cs;
		int rs;
		int mincs;
		int minrs;
		BOOL iswidth;
		BOOL isheight;
	};
	
	widthar=new int[m_KolObj+1];
	heightar=new int[m_KolObj+1];
	
	CCell** lin;
	lin=new CCell*[m_KolObj+1];
	for(i=0;i<=m_KolObj; i++) {
		lin[i]=new	CCell[m_KolObj+1];
		for(j=0;j<=m_KolObj; j++) {
			lin[i][j].obj=NULL;
			lin[i][j].cs=1;
			lin[i][j].rs=1;
			lin[i][j].iswidth=TRUE;
			lin[i][j].isheight=TRUE;
		};
	};
	//lin[������][�����]
	
	begposgor=GetHeadPosition();
	begposvert=m_SortVert.GetHeadPosition();
	
	topall=m_SortVert.GetAt(begposvert)->m_Rect.top;
	leftall=GetAt(begposgor)->m_Rect.left;
	
	istopfree=topall>0;
	isleftfree=leftall>0;
	
	if(begposgor){
		
		// ������� ������ ����� � ��� ��������
		kolstolb=0;
		posgor=begposgor;
		curgor=0;
		while(posgor){
			obj=GetAt(posgor);
			left=obj->m_Rect.left;
			width=left-curgor;
			obj->CalcHtmlSizes();
			if(width){
				widthar[kolstolb++]=width;
			};
			curgor=left;
			GetNext(posgor);
		};
		widthar[kolstolb++]=m_Width-curgor;
		if(!isleftfree){
			widthar[kolstolb++]=WIDTHENDCELL;
			widthtable=m_Width+	WIDTHENDCELL;
		}
		else{
			widthtable=m_Width;
		};
		
		
		// ������� ������ ����� � ��� �����	� ��������� ������� � ������
		kolstr=0;
		
		posvert=begposvert;
		curvert=0;
		while(posvert){
			obj=m_SortVert.GetAt(posvert);
			top=obj->m_Rect.top;
			height=top-curvert;
			if(height){
				heightar[kolstr++]=height;
			};
			// ��������� ������ � ������
			left=obj->m_Rect.left;
			curgor=0;
			i=0;
			while(left!=curgor){
				curgor+=widthar[i++];
			};
			//������ i,	kolstr
			lin[kolstr][i].obj=obj;
			
			/////////////////////////////
			curvert=top;
			m_SortVert.GetNext(posvert);
		};
		
		heightar[kolstr++]=m_Height-curvert;
		if(!istopfree){
			heightar[kolstr++]=HEIGHTENDCELL;
			heighttable=m_Height+ HEIGHTENDCELL;
		}
		else{
			heighttable=m_Height;
		};
		
		// ������� kolstr ����� � kolstolb ��������
		
		//������� ����������� COLSPAN � ROWSPAN
		
		for(i=0;i<kolstr; i++) {
			for(j=0;j<kolstolb; j++) {
				obj=lin[i][j].obj;
				if(obj){
					width=obj->m_HtmlWidth;
					sum=widthar[j];
					jj=j;
					while (sum<width){
						jj++;
						ASSERT(jj<kolstolb);
						sum+=widthar[jj];
					};
					lin[i][j].mincs=jj-j+1;
					
					height=obj->m_HtmlHeight;
					sum=heightar[i];
					ii=i;
					while (sum<height){
						ii++;
						ASSERT(ii<kolstr);
						sum+=heightar[ii];
					};
					lin[i][j].minrs=ii-i+1;
					for(iii=i;iii<=ii;iii++){	
						//  ���������� ������������������ colspan � rowspan
						for(jjj=j;jjj<=jj;jjj++){
							if((iii==i)&&(jjj==j)){
								lin[i][j].cs=lin[i][j].mincs;
								lin[i][j].rs=lin[i][j].minrs;
							}
							else{
								lin[iii][jjj].cs=0;
								lin[iii][jjj].rs=0;
							};
							lin[iii][jjj].iswidth=FALSE;
							lin[iii][jjj].isheight=FALSE;
							
						};
					};
					
					
				}
				else{
					lin[i][j].mincs=0;
					lin[i][j].minrs=0;
				};
			};
		};
		
		/*
		//�����������
		if(optimize==maxoptimize){
			int ostr=kolstr-1;//������� ����� ���
			int ostolb, slstr,cs,rs,kolstropt,kolstolbopt,begresstolb;
			int cena, mincena;
			BOOL b, firstcombin=TRUE, isnewcombinstolb=TRUE, 
				isnewcombinstr=TRUE,resetstolb, dopustimkonf,
				isediniccell;
			COptimConfTabl OptConf;
			 

			struct CCellOpt{
				int cs;
				int rs;
			};
			
			CCellOpt** linopt;
			linopt=new CCellOpt*[kolstr];
			for(i=0;i<kolstr; i++) {
				linopt[i]=new CCellOpt[kolstolb];
			};
			//linopt[������][�����]
			

			while(isnewcombinstr){
				
				ostolb=kolstolb;
				resetstolb=TRUE;
				isnewcombinstolb=TRUE;
				begresstolb=0;
				while(ostolb>=0){
					
					if(resetstolb){ //���� ����� ��������� ������ ���� ������� �� ����� ostolb+1
						ostolb=begresstolb-1;
						while((++ostolb)<kolstolb){
							//��������� ������ ����	� ����� ostolb
							sum=0;
							for (i=0;i<kolstr;i++){
								if((--sum)>0){
									lin[i][ostolb].rs=0;
									ASSERT(lin[i][ostolb].minrs==0);
								}
								else{
									if(lin[i][ostolb].minrs>0){
										sum=lin[i][ostolb].rs=lin[i][ostolb].minrs;
									}
									else{
										lin[i][ostolb].rs=1;
									};
								};
							};
							
						};
						ostolb=kolstolb-1;
					}

					
					if(isnewcombinstolb){
						// �������� �� ������������
						dopustimkonf=TRUE;
						
						for (i=0;i<kolstr && dopustimkonf;i++){
							isediniccell=FALSE;	 // ���� ������ � rorwspan=1
							for (j=0;j<kolstolb && dopustimkonf;j++){
								cs=lin[i][j].cs;
								rs=lin[i][j].rs;
								if( ((cs==2)&&(lin[i][j].mincs!=2))||((rs==2)&&(lin[i][j].minrs!=2)) ){
									dopustimkonf=FALSE;
								}
								else{
									if(rs==1) isediniccell=TRUE;
								};
							};
							dopustimkonf=dopustimkonf&&isediniccell;
						};
						
						for (j=0;j<kolstolb && dopustimkonf;j++){
							isediniccell=FALSE;
							for (i=0;i<kolstr && dopustimkonf;i++){
								if(lin[i][j].cs==1) isediniccell=TRUE;
							};
							dopustimkonf=isediniccell;
						};
						
						//dopustimkonf=TRUE;//-----------------------
						if(dopustimkonf){
							
							//������ ����
							if((!isleftfree)&&lin[0][kolstolb-1].rs==kolstr){
								kolstolbopt--;
							};
							if((!istopfree)&&lin[kolstr-1][0].cs==kolstolb){
								kolstropt--;
							};
							
							cena=0;
							for(i=0;i<kolstropt; i++) {
								for(j=0;j<kolstolbopt; j++) {
									if((lin[i][j].cs==1) && (lin[i][j].rs==1)){
										cena+=9;
									}
									else{
										if((lin[i][j].cs>1) && (lin[i][j].rs>1)){
											cena+=32;
										}
										else{
											if((lin[i][j].cs>1) || (lin[i][j].rs>1)){
												cena+=19;
											}
										};
									};
								};
							};
							
							if(firstcombin){
								//��������� ��� ���� ��� ����� ������
								for(i=0;i<kolstr; i++) {
									for(j=0;j<kolstolb; j++) {
										linopt[i][j].cs=lin[i][j].cs;
										linopt[i][j].rs=lin[i][j].rs;
									};
								};
								mincena=cena;
								firstcombin=FALSE;
							}
							else{
								if(cena<mincena){
									for(i=0;i<kolstr; i++) {
										for(j=0;j<kolstolb; j++) {
											linopt[i][j].cs=lin[i][j].cs;
											linopt[i][j].rs=lin[i][j].rs;
										};
									};
									mincena=cena;
								};
							};
						};
					};
					
					//����� ��������� ������������ � ��������
					
					i= kolstr-1;
					sum=0;
					b=TRUE;
					while(b){
						i--;
						if(i<0){
							b=FALSE;
							isnewcombinstolb=FALSE;
						}
						else{
							
							if(lin[i+1][ostolb].minrs==0) {
								sum=lin[i+1][ostolb].rs;	// ���� ����� ���������� i � i+1 �����
								slstr=i+1;
							};
							if((lin[i][ostolb].rs>0)&&(sum>0)&&
								(lin[i][ostolb].cs==lin[slstr][ostolb].cs) ){
								
								lin[slstr][ostolb].rs=0;
								
								lin[i][ostolb].rs++;
								sum--;
								while (sum>0){
									i+=lin[i][ostolb].rs;
									if(lin[i][ostolb].rs==0){
										lin[i][ostolb].rs=1;
										sum--;
									};
								};
								
								b=FALSE;
								isnewcombinstolb=TRUE;
							};
						};
					};
					resetstolb=isnewcombinstolb;
					begresstolb=ostolb+1;
					if(!isnewcombinstolb){
						ostolb--;
					};
					
				};	
				
				
				
				//����� ��������� ������������ � �������
				
				j= kolstolb-1;
				b=TRUE;
				while(b){
					j--;
					if(j<0){
						b=FALSE;
						isnewcombinstr=FALSE;
					}
					else{
						if(lin[ostr][j+1].mincs==0) sum=lin[ostr][j+1].cs;	// ���� ����� ���������� j-� � j+1 ������
						lin[ostr][j+1].cs=0;
						if((lin[ostr][j].cs>0)&&(sum>0)){
							lin[ostr][j].cs++;
							sum--;
							while (sum>0){
								j+=lin[ostr][j].cs;
								if(lin[ostr][j].cs==0){
									lin[ostr][j].cs=1;
									sum--;
								};
							};
							
							b=FALSE;
							isnewcombinstr=TRUE;
						};
					};
				};
				if(isnewcombinstr){
					while((++ostr)<kolstr){
						//��������� ������ ����	� ��� cs
						sum=0;
						for (j=0;j<kolstolb;j++){
							if((--sum)>0){
								lin[ostr][j].cs=0;
								ASSERT(lin[ostr][j].mincs==0);
							}
							else{
								if(lin[ostr][j].mincs>0){
									sum=lin[ostr][j].cs=lin[ostr][j].mincs;
								}
								else{
									lin[ostr][j].cs=1;
								};
							};
						};
						
					};
					ostr= kolstr-1;
					
				}
				else{
					ostr--;
					if (ostr<0){
						isnewcombinstr=FALSE;
					};
				};


			};
			
			// �������������� ��� ����	
			for(i=0;i<kolstr; i++) {
				for(j=0;j<kolstolb; j++) {
					lin[i][j].cs=linopt[i][j].cs;
					lin[i][j].rs=linopt[i][j].rs;
				};
			};

			if((!isleftfree)&&lin[0][kolstolb-1].rs==kolstr){
				widthtable-=widthar[kolstolb-1];
				kolstolb--;
			};
			if((!istopfree)&&lin[kolstr-1][0].cs==kolstolb){
				heighttable-=heightar[kolstr-1];
				kolstr--;
			};
			
			

		};
		
		
		
		//
		
		
		*/
		
		
		ar->WriteString("<HTML>\n<BODY leftMargin=0 topMargin=0 marginheight=0 marginwidth=0>\n<FORM>\n");
		
		s.Format("<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=%d HEIGHT=%d>\n",widthtable,heighttable);
		ar->WriteString(s);
		
		
		for(i=0;i<kolstr; i++) {
			ar->WriteString("<TR VALIGN=TOP>\n");
			
			for(j=0;j<kolstolb; j++) {
				if(lin[i][j].cs){
					obj=lin[i][j].obj;
					if(obj){
						s.Format("<TD COLSPAN=%d ROWSPAN=%d>",lin[i][j].cs,lin[i][j].rs);
						ar->WriteString(s);
						obj->WriteToHtml(ar);
						ar->WriteString("</TD>\n");
					}
					else{
						s.Format("<TD WIDTH=%d HEIGHT=%d>&nbsp;</TD>\n",widthar[j],heightar[i]);
						ar->WriteString(s);
					};
				};
			};
			
			ar->WriteString("</TR>\n");
		};
		
		ar->WriteString("</TABLE>\n");
		ar->WriteString("</FORM>\n</BODY>\n</HTML>");
		
		
	};
	return TRUE;
};	










int CHtmlObjList::GetHeight()
{
	return m_Height;
}

int CHtmlObjList::GetWidth()
{
	return m_Width;
}

void CHtmlObjList::RecalcHeightWidth()
{
	m_Height=0;
	m_Width=0;
	POSITION pos;
	CHtmlObj* o;
	int right;
	int bottom;
	pos=GetHeadPosition();
	while(pos!=NULL){
		o=GetAt(pos);
		right=o->m_Rect.right;
		bottom=o->m_Rect.bottom;
		if(right>m_Width)m_Width=right;
		if(bottom>m_Height)m_Height=bottom;
		GetNext(pos);
	};
}

BOOL CHtmlObjList::WriteToHtml(CString fn, int optimize)
{
	CFile fhtm;
	if( !fhtm.Open( fn, CFile::modeCreate | CFile::modeWrite ) ) {
		return FALSE;
	};
	CArchive ar( &fhtm, CArchive::store, 8192);
	WriteToHtml(&ar,optimize);
	ar.Close();
	fhtm.Close();
	return TRUE;
}
