// VisualObjTextEdit.cpp: implementation of the CVisualObjTextEdit class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HtmlObject.h"
#include "VisualObjTextEdit.h"
#include "HtmlObjTextEdit.h"
#include "HtmlObjectView.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CVisualObjTextEdit::CVisualObjTextEdit(CHtmlObjectView* parent, CRect &r, CHtmlObj* htmlobj):CVisualObj(parent,htmlobj)
{
	CEdit* b;
	b=new CEdit;
	m_Wnd=b;
	b->Create(WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_BORDER, r, parent, 1);
	b->SetWindowText("TextEdit");
	SetWndProc();
}


void CVisualObjTextEdit::UpdateProperites()
{
	CVisualObj::UpdateProperites();
	m_Wnd->SetWindowText(((CHtmlObjTextEdit*)m_HtmlObj)->m_Text);
}
