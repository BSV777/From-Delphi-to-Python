// HtmlObj.h: interface for the CHtmlObj class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HTMLOBJ_H__9582750A_503C_4CC4_8CCA_4B2BBA857946__INCLUDED_)
#define AFX_HTMLOBJ_H__9582750A_503C_4CC4_8CCA_4B2BBA857946__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "HtmlObjList.h"
#include "PropertyList.h"


#define PTOP "TOP"
#define PLEFT "LEFT"
#define PWIDTH "WIDTH"
#define PHEIGHT "HEIGHT"

class CHtmlObjectDoc;
class CVisualObj;
class CHtmlObjectView;

class CHtmlObj : public CObject  
{
public:
	virtual void WriteToHtml(CArchive* ar);
	int m_Oper;
	virtual void SetRect(CRect r);
	CRect GetRect();
	virtual void CalcHtmlSizes();
	int m_HtmlWidth;
	int m_HtmlHeight;
	void GetRect(CRect& r);
	CHtmlObjList* GetHtmlObjList();
	void ReInsertInHtmlList();
	void InsertInHtmlList(CHtmlObjList* HtmlObjList);
	CRect m_BeginMovePos;
	void Move(CPoint p);
	void EndMove();
	enum Oper {
		none=				0,
		move =				1,
		resizelefttop =		2,
		resizerighttop =	3,
		resizeleftbottom =	4,
		resizerightbottom =	5,
	};

	void BeginMove(int oper);

	virtual void GetPropertyList(CPropertyList& p);
	virtual BOOL SetPropertyList(CPropertyList& p);
	int GetWidth();
	int GetLeft();
	int GetHeight();
	int GetTop();
	void MoveTo(CPoint &p);
	CVisualObj*  CreateVisualObject(CHtmlObjectView* parent, CPoint scroll);
	BOOL WriteConfig(CArchive &ar);
	enum Error {
		ok =				1,
		uncnownprop =		-8,
		illegalvalue =		-9,
	};
	virtual BOOL SetTop(int top);
	virtual BOOL SetLeft(int left);
	virtual BOOL SetWidth(int width);
	virtual BOOL SetHeight(int height);
	virtual int SetProperty(CString propname, CString& propvalue);
	CRect m_Rect;
	virtual CString GetName();
	CHtmlObj();
	virtual ~CHtmlObj();
	static CString Name(); //��� ���������� �������
private:
	virtual CVisualObj* CreateVisualObject(CHtmlObjectView *parent, CRect& r);
	BOOL Str2IntP(CString s, int& i);
	virtual CRect Point2DefaultRect(CPoint &p);
protected:
	CHtmlObjList* m_HtmlObjList;
	virtual void GetPropertyStr(CString& s);
};

#endif // !defined(AFX_HTMLOBJ_H__9582750A_503C_4CC4_8CCA_4B2BBA857946__INCLUDED_)
