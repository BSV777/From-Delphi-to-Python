// HtmlObject.h : main header file for the HTMLOBJECT application
//

#if !defined(AFX_HTMLOBJECT_H__D91F7E4E_7798_443A_A173_251060902832__INCLUDED_)
#define AFX_HTMLOBJECT_H__D91F7E4E_7798_443A_A173_251060902832__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "State.h"	// Added by ClassView
#include "DialogProp.h"	// Added by ClassView

/////////////////////////////////////////////////////////////////////////////
// CHtmlObjectApp:
// See HtmlObject.cpp for the implementation of this class
//

class CHtmlObjectApp : public CWinApp
{
private:
	CState m_State;
public:
	void ShowDialogProp(BOOL b);
	void ShowDialogProp();
	HCURSOR m_hnormcur;
	HCURSOR m_hkrest;
	HCURSOR m_htoplefts;
	HCURSOR m_htopgights;
	HCURSOR m_hbottomlefts;
	HCURSOR m_hbottomrights;;

	
	BOOL m_ShowDialogProperty;
	CDialogProp m_DialogProp;
	CState* GetState();
	CHtmlObjectApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHtmlObjectApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CHtmlObjectApp)
	afx_msg void OnAppAbout();
	afx_msg void OnButtonshowprop();
	afx_msg void OnUpdateButtonshowprop(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HTMLOBJECT_H__D91F7E4E_7798_443A_A173_251060902832__INCLUDED_)
