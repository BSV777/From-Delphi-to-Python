// HtmlObjList.h: interface for the CHtmlObjList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HTMLOBJLIST_H__F8F308B3_59FE_480D_86EB_179C60AD2B9A__INCLUDED_)
#define AFX_HTMLOBJLIST_H__F8F308B3_59FE_480D_86EB_179C60AD2B9A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CHtmlObj;

typedef CTypedPtrList<CObList, CHtmlObj*>  CHtmlObjListBase;

class CHtmlObjList: public CHtmlObjListBase  
{
public:
	BOOL WriteToHtml(CString fn, int optimize);
	BOOL WriteToHtml(CArchive *ar, int optimize);
	enum ParamExport {
		maxoptimize =		0,
		minoptimize =		1
	};
	int GetWidth();
	int GetHeight();
	void MakeNonIntersectHeight();
	void DeleteObj(CHtmlObj *o);
	void Insert(CHtmlObj *o);
	void FreeObj();
	BOOL WriteConfig(CArchive& ar);
	int ReadConfig(CArchive *ar, CArchive *arer);
	enum ResultRead {
		ok =				1,
		cannotopen =		-1,
		cannotopenerfile =	-2
	};

	int ReadConfig(CString fn, CString erfn);
	CHtmlObjList();
	virtual ~CHtmlObjList();
protected:
	int m_KolObj;
	void RecalcHeightWidth();
	int m_Width;
	int m_Height;
	CHtmlObjListBase m_SortVert;

};

#endif // !defined(AFX_HTMLOBJLIST_H__F8F308B3_59FE_480D_86EB_179C60AD2B9A__INCLUDED_)
