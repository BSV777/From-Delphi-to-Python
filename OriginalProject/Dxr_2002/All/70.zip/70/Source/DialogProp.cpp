// DialogProp.cpp : implementation file
//

#include "stdafx.h"
#include "HtmlObject.h"
#include "HtmlObjectDoc.h"
#include "HtmlObjectView.h"
#include "DialogProp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDialogProp dialog


CDialogProp::CDialogProp(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogProp::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDialogProp)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_HtmlObjectView=NULL;
	m_CanSaveModifed=FALSE;
}


void CDialogProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDialogProp)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDialogProp, CDialog)
	//{{AFX_MSG_MAP(CDialogProp)
	ON_EN_CHANGE(IDC_EDITCAPTION, OnChangeEditcaption)
	ON_EN_CHANGE(IDC_EDITHEIGHT, OnChangeEditheight)
	ON_EN_CHANGE(IDC_EDITLEFT, OnChangeEditleft)
	ON_EN_CHANGE(IDC_EDITTOP, OnChangeEdittop)
	ON_EN_CHANGE(IDC_EDITWIDTH, OnChangeEditwidth)
	ON_EN_CHANGE(IDC_EDITTEXT, OnChangeEdittext)
	ON_EN_KILLFOCUS(IDC_EDITTOP, OnKillfocusEdit)
	ON_EN_KILLFOCUS(IDC_EDITLEFT, OnKillfocusEdit)
	ON_EN_KILLFOCUS(IDC_EDITHEIGHT, OnKillfocusEdit)
	ON_EN_KILLFOCUS(IDC_EDITWIDTH, OnKillfocusEdit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDialogProp message handlers

void CDialogProp::OnChangeEditcaption() 
{
	m_ModifedCaption=TRUE;
	SetProperty();
}

void CDialogProp::OnChangeEditheight() 
{
	m_ModifedHeight=TRUE;
}

void CDialogProp::OnChangeEditleft() 
{
	m_ModifedLeft=TRUE;
}

void CDialogProp::OnChangeEdittop() 
{
	m_ModifedTop=TRUE;
}

void CDialogProp::OnChangeEditwidth() 
{
	m_ModifedWidth=TRUE;
}

void CDialogProp::OnChangeEdittext() 
{
	m_ModifedText=TRUE;
	SetProperty();
}

void CDialogProp::OnCancel() 
{
	((CHtmlObjectApp*) AfxGetApp())->ShowDialogProp(FALSE);
}

void CDialogProp::SetView(CHtmlObjectView *v)
{
	m_HtmlObjectView=v;
	UpdateMember();
}

void CDialogProp::UpdateMember()
{
	m_CanSaveModifed=FALSE;
	if(m_HtmlObjectView){
		CPropertyList pl;
		CProperty* p;
		CString s;
		m_HtmlObjectView->m_VisualObjList.GetSelectedProperty(pl);
		p=pl.GetProperty("TEXT");
		if(p){
			SetDlgItemText(IDC_EDITTEXT, p->Value);
		}
		else{
			SetDlgItemText(IDC_EDITTEXT, "");
		};
		GetDlgItem(IDC_EDITTEXT)->EnableWindow(p!=NULL);
		
		p=pl.GetProperty("CAPTION");
		if(p){
			SetDlgItemText(IDC_EDITCAPTION, p->Value);
		}
		else{
			SetDlgItemText(IDC_EDITCAPTION, "");
		};
		GetDlgItem(IDC_EDITCAPTION)->EnableWindow(p!=NULL);
		
		p=pl.GetProperty("TOP");
		if(p){
			SetDlgItemText(IDC_EDITTOP, p->Value);
		}
		else{
			SetDlgItemText(IDC_EDITTOP, "");
		};
		GetDlgItem(IDC_EDITTOP)->EnableWindow(p!=NULL);
		
		p=pl.GetProperty("LEFT");
		if(p){
			SetDlgItemText(IDC_EDITLEFT, p->Value);
		}
		else{
			SetDlgItemText(IDC_EDITLEFT, "");
		};
		GetDlgItem(IDC_EDITLEFT)->EnableWindow(p!=NULL);
		
		p=pl.GetProperty("WIDTH");
		if(p){
			SetDlgItemText(IDC_EDITWIDTH, p->Value);
		}
		else{
			SetDlgItemText(IDC_EDITWIDTH, "");
		};
		GetDlgItem(IDC_EDITWIDTH)->EnableWindow(p!=NULL);
		
		p=pl.GetProperty("HEIGHT");
		if(p){
			SetDlgItemText(IDC_EDITHEIGHT, p->Value);
		}
		else{
			SetDlgItemText(IDC_EDITHEIGHT, "");
		};
		GetDlgItem(IDC_EDITHEIGHT)->EnableWindow(p!=NULL);
	}
	else{
		GetDlgItem(IDC_EDITCAPTION)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDITTEXT)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDITTOP)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDITLEFT)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDITWIDTH)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDITHEIGHT)->EnableWindow(FALSE);
	};
	ClearUpdated();
	m_CanSaveModifed=TRUE;
}

BOOL CDialogProp::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CRect r;
	GetWindowRect(r);
	MoveWindow(r+CPoint(0,650)-CPoint(r.left,r.top));
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDialogProp::ClearUpdated()
{
	m_ModifedCaption= FALSE;
	m_ModifedText= FALSE;
	m_ModifedTop= FALSE;
	m_ModifedLeft= FALSE;
	m_ModifedWidth= FALSE;
	m_ModifedHeight= FALSE;
}

void CDialogProp::SetProperty()
{
	if(m_CanSaveModifed){
		if(m_HtmlObjectView){
			
			CString s;
			CPropertyList p;
			
			if(m_ModifedCaption){
				GetDlgItemText(IDC_EDITCAPTION, s);
				p.SetProperty("CAPTION", s); 
			};
			
			if(m_ModifedText){
				GetDlgItemText(IDC_EDITTEXT, s);
				p.SetProperty("TEXT", s); 
			};
			
			if(m_ModifedTop){
				GetDlgItemText(IDC_EDITTOP, s);
				p.SetProperty("TOP", s); 
			};
			
			if(m_ModifedLeft){
				GetDlgItemText(IDC_EDITLEFT, s);
				p.SetProperty("LEFT", s); 
			};
			
			if(m_ModifedWidth){
				GetDlgItemText(IDC_EDITWIDTH, s);
				p.SetProperty("WIDTH", s); 
			};
			
			if(m_ModifedHeight){
				GetDlgItemText(IDC_EDITHEIGHT, s);
				p.SetProperty("HEIGHT", s);
			};
			
			m_HtmlObjectView->m_VisualObjList.SetSelectedProperty(p);
			CHtmlObjectDoc* doc=m_HtmlObjectView->GetDocument();
			doc->GetHtmlObjList()->MakeNonIntersectHeight();
			doc->UpdateAllViews(NULL,UPDATEONLYPROPERTY);

		};
		ClearUpdated();
	};
}

void CDialogProp::OnOK() 
{
	SetProperty();
	UpdateMember();
	//CDialog::OnOK();
}

void CDialogProp::OnKillfocusEdit() 
{
	SetProperty();
	UpdateMember();
}
