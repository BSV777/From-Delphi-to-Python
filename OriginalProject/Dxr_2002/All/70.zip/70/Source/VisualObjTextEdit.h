// VisualObjTextEdit.h: interface for the CVisualObjTextEdit class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VISUALOBJTEXTEDIT_H__C7C52FF1_2A25_4837_8621_1B49B2699950__INCLUDED_)
#define AFX_VISUALOBJTEXTEDIT_H__C7C52FF1_2A25_4837_8621_1B49B2699950__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "VisualObj.h"

class CVisualObjTextEdit : public CVisualObj  
{
public:
	CVisualObjTextEdit(CHtmlObjectView* parent, CRect &r, CHtmlObj* htmlobj);
	virtual void UpdateProperites();
};

#endif // !defined(AFX_VISUALOBJTEXTEDIT_H__C7C52FF1_2A25_4837_8621_1B49B2699950__INCLUDED_)
