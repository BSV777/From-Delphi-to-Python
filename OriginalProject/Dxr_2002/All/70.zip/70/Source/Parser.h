// Parser.h: interface for the CParser class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PARSER_H__FD3933F4_25B0_4117_833F_A6D1C4816791__INCLUDED_)
#define AFX_PARSER_H__FD3933F4_25B0_4117_833F_A6D1C4816791__INCLUDED_

#define MAXKOLOBJ 3
typedef CHtmlObj* TCreateIfMyName(CString& nane);


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CParser  
{
public:
	void GetErrSrt(CString& s, int err);
	enum Error {
		ok =				1,
		notopenskob =		-1,
		notidobj =			-2,
		notcloseskob =		-3,
		notravno =			-4,
		notopenkav =		-5,
		notclosekav =		-6,
		uncnownobj =		-7,
		uncnownprop =		-8,
		illegalvalue =		-9,
		nottz		 =		-10
	};

	int m_Error;
	BOOL CreateObj();
	BOOL Parse();
	CParser(CArchive* ar, CArchive* arer, CHtmlObjList& hol, TCreateIfMyName* *tblfun, int KolTypeObj);
	virtual ~CParser();
protected:
	CString ParseIdent(CString& s);
	BOOLEAN ParseLine(CString& s);
	int m_NumLine;
	int m_KolTypeObj;
	CFile* m_pFile;
	CString m_NameObj;
	int m_hf;
	int m_NumSym;
	CArchive *m_ar, *m_arer;
	CHtmlObjList* m_hol;
	CHtmlObj* m_Obj;
	TCreateIfMyName* *m_TblFun;
};

#endif // !defined(AFX_PARSER_H__FD3933F4_25B0_4117_833F_A6D1C4816791__INCLUDED_)
