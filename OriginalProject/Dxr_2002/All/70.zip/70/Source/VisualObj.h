// VisualObj.h: interface for the CVisualObj class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VISUALOBJ_H__B9CA737C_A785_4A6B_8272_E351814191F0__INCLUDED_)
#define AFX_VISUALOBJ_H__B9CA737C_A785_4A6B_8272_E351814191F0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#include "HtmlObjectView.h"
#include "VisualObjList.h"

class CHtmlObj;
class CVisualObj;
class CHtmlObjectView;


class CVisualObj: public CObject  
{
public:
	void MoveMouse(CPoint p);
	void Move(CPoint p);
	void EndMove();
	void BeginMove();
	CPoint m_PosMouseDown;
	void Paint();
	virtual void UpdateProperites();
	CHtmlObjectView* GetParent();
	CVisualObj(CHtmlObjectView* parent, CHtmlObj* htmlobj);
	virtual ~CVisualObj();

	static LRESULT CALLBACK WndProcAllObj(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
	static CVisualObj* SearchObj(HWND hwnd);
	BOOL IsObjForHwnd(HWND hwnd);
	BOOL GetSel();
	void SetSel(BOOL sel);
	virtual BOOL IsResizable();
	CHtmlObj* m_HtmlObj;
	CWnd* m_Wnd;

protected:
	//BOOL m_IsBeginSizeBottomLeft;
	//BOOL m_IsBeginSizeTopLeft;
	//BOOL m_IsBeginSizeBottomRight;
	//BOOL m_IsBeginSizeTopRight;
	//BOOL m_IsBeginMoved;
	int m_Oper;
	BOOL m_IsMouseMoved;
	void GetBottomRightRect(CRect& r);
	void GetBottomLeftRect(CRect& r);
	void GetTopRightRect(CRect& r);
	void GetTopLeftRect(CRect& r);
	CHtmlObjectView* m_Parent;
	virtual LRESULT CALLBACK WndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
	BOOL m_Sel;
	static CVisualObjList m_ListAllObj;
	void SetWndProc();
	WNDPROC m_WndProc;
};

#endif // !defined(AFX_VISUALOBJ_H__B9CA737C_A785_4A6B_8272_E351814191F0__INCLUDED_)
