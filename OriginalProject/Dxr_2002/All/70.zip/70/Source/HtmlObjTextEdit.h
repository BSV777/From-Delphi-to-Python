// HtmlObjTextEdit.h: interface for the CHtmlObjTextEdit class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HTMLOBJTEXTEDIT_H__BB65F8F5_8901_4320_82B2_096F30E1010B__INCLUDED_)
#define AFX_HTMLOBJTEXTEDIT_H__BB65F8F5_8901_4320_82B2_096F30E1010B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "HtmlObj.h"

#define PTEXT "TEXT"

class CHtmlObjTextEdit : public CHtmlObj  
{
public:
	virtual void WriteToHtml(CArchive *ar);
	virtual void SetRect(CRect r);
	virtual void GetPropertyList(CPropertyList& p);
	virtual BOOL SetHeight(int height);
	static CString Name();
	virtual int SetProperty(CString propname, CString& propvalue);
	BOOL SetText(CString &text);
	static CHtmlObj*  CreateIfMyName(CString& name);
	virtual CString GetName();
	CHtmlObjTextEdit();
	virtual ~CHtmlObjTextEdit();

	CString m_Text;
private:
	virtual CVisualObj* CreateVisualObject(CHtmlObjectView *parent, CRect& r);

protected:
	virtual void GetPropertyStr(CString &s);
};

#endif // !defined(AFX_HTMLOBJTEXTEDIT_H__BB65F8F5_8901_4320_82B2_096F30E1010B__INCLUDED_)
