// State.cpp: implementation of the CState class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HtmlObject.h"
#include "State.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CState::CState()
{
	m_InsertObj=NULL;
}

CState::~CState()
{
	FreeInsertObj();
}

CHtmlObj* CState::GetInsertObj()
{
	return m_InsertObj;
}


CState::SetInsertObj(CHtmlObj* obj)
{
	FreeInsertObj();
	m_InsertObj=obj;
}

void CState::DeleteInsertObj()
{
	m_InsertObj=NULL;
}

void CState::FreeInsertObj()
{
	if(m_InsertObj!=NULL) delete m_InsertObj;
	m_InsertObj=NULL;
}
