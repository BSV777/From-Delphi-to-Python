// HtmlObjButton.cpp: implementation of the CHtmlObjButton class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HtmlObject.h"
#include "HtmlObjButton.h"
#include "VisualObjButton.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHtmlObjButton::CHtmlObjButton()
{
	m_Caption="Button";
}

CHtmlObjButton::~CHtmlObjButton()
{

}

CString CHtmlObjButton::GetName()
{
	return Name();
}

CVisualObj* CHtmlObjButton::CreateVisualObject(CHtmlObjectView *parent, CRect& r)
{
	CVisualObj* o;
	o=new CVisualObjButton(parent, r, this);
	return o;
}

CHtmlObj* CHtmlObjButton::CreateIfMyName(CString &name)
{
	CString s=name;
	s.MakeUpper();
	if (s==Name()){
		CHtmlObj* o=new	CHtmlObjButton;
		return o;
	};
	return NULL;
}

BOOL CHtmlObjButton::SetCaption(CString &caption)
{
	if(caption.Find('"')<0){
		m_Caption=caption;
		return TRUE;
	}
	return FALSE;
}

int CHtmlObjButton::SetProperty(CString propname, CString &propvalue)
{
	propname.MakeUpper();
	if(propname==PCAPTION){
		SetCaption(propvalue);
		return ok;
	};
	return CHtmlObj::SetProperty(propname, propvalue);
}

void CHtmlObjButton::GetPropertyStr(CString &s)
{
	CHtmlObj::GetPropertyStr(s);
	s.Format("%s; Caption=\"%s\"",s,m_Caption);
}

CString CHtmlObjButton::Name()
{
	return CString("BUTTON");//��� ���������� �������
}

void CHtmlObjButton::GetPropertyList(CPropertyList &p)
{
	CHtmlObj::GetPropertyList(p);
	p.SetProperty(PCAPTION, m_Caption);
}

void CHtmlObjButton::WriteToHtml(CArchive *ar)
{
	CString s;
	s.Format("<INPUT type=reset value=\"%s\" style=\"width=%d; height=%d\">",m_Caption,m_HtmlWidth, m_HtmlHeight);
	ar->WriteString(s);
}
