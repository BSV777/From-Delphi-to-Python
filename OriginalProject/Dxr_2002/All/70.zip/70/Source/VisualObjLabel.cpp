// VisualObjLabel.cpp: implementation of the CVisualObjLabel class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HtmlObject.h"
#include "VisualObjLabel.h"
#include "HtmlObjLabel.h"
#include "HtmlObjectView.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CVisualObjLabel::CVisualObjLabel(CHtmlObjectView* parent, CRect &r, CHtmlObj* htmlobj):CVisualObj(parent,htmlobj)
{
	CEdit* b;
	b=new CEdit;
	m_Wnd=b;
	b->Create(WS_CHILD | WS_VISIBLE | WS_TABSTOP , r, parent, 1);
	b->SetWindowText("Label");
	SetWndProc();
}

void CVisualObjLabel::UpdateProperites()
{
	CVisualObj::UpdateProperites();
	m_Wnd->SetWindowText(((CHtmlObjLabel*)m_HtmlObj)->m_Text);
}
