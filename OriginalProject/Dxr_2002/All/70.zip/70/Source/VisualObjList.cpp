// VisualObjList.cpp: implementation of the CVisualObjList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HtmlObjectDoc.h"
#include "HtmlObjectView.h"
#include "HtmlObject.h"
#include "VisualObjList.h"
#include "VisualObj.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CVisualObjList::CVisualObjList(CHtmlObjectView* htmlobjectview)
{
	m_HtmlObjectView=htmlobjectview;
}

CVisualObjList::~CVisualObjList()
{

}

void CVisualObjList::SelectAll(BOOL b)
{
	POSITION pos;
	CVisualObj* o;
	pos=GetHeadPosition();
	while(pos!=NULL){
		o=GetAt(pos);
		o->SetSel(b);
		GetNext(pos);
	};
}


void CVisualObjList::RemoveSelected()
{
	POSITION pos;
	CVisualObj* o;
	pos=GetHeadPosition();
	while(pos!=NULL){
		o=GetAt(pos);
		if(o->GetSel()){
			
			o->GetParent()->GetDocument()->GetHtmlObjList()->DeleteObj(o->m_HtmlObj);
			delete o;
			RemoveAt(pos);
			pos=GetHeadPosition();
		}
		else{
			GetNext(pos);
		}
	};
	m_HtmlObjectView->GetDocument()->SetModifiedFlag();
}

void CVisualObjList::RemoveAllVisualObj()
{
	POSITION pos = GetHeadPosition();
	while(pos != NULL){
		CVisualObj* o=GetAt( pos );
		delete o;
		GetNext(pos);
	};	
	RemoveAll();
}

void CVisualObjList::SelectFirst()
{
	POSITION pos;
	CVisualObj* o;
	pos=GetHeadPosition();
	if(pos){
		o=GetAt(pos);
		o->SetSel(TRUE);
	};
}

void CVisualObjList::GetSelectedProperty(CPropertyList &pl)
{
	CPropertyList p;
	pl.RemoveAll();
	POSITION pos;
	CVisualObj* o;
	pos=GetHeadPosition();
	while(pos){
		o=GetAt(pos);
		if(o->GetSel()){
			o->m_HtmlObj->GetPropertyList(p);
			pl.AddProperty(p);
		};
		GetNext(pos);
	};
}

void CVisualObjList::SetSelectedProperty(CPropertyList &pl)
{
	POSITION pos;
	CVisualObj* o;
	pos=GetHeadPosition();
	while(pos){
		o=GetAt(pos);
		if(o->GetSel()){
			o->m_HtmlObj->SetPropertyList(pl);
		};
		GetNext(pos);
	};
}

void CVisualObjList::UpdateVisualObjProperites()
{
	POSITION pos;
	CVisualObj* o;
	pos=GetHeadPosition();
	while(pos){
		o=GetAt(pos);
		o->UpdateProperites();
		GetNext(pos);
	};
	m_HtmlObjectView->GetDocument()->SetModifiedFlag();
}

void CVisualObjList::BeginMove()
{
	POSITION pos;
	CVisualObj* o;
	pos=GetHeadPosition();
	while(pos){
		o=GetAt(pos);
		if(o->GetSel()) o->BeginMove();
		GetNext(pos);
	};
}

void CVisualObjList::EndMove()
{
	POSITION pos;
	CVisualObj* o;
	pos=GetHeadPosition();
	while(pos){
		o=GetAt(pos);
		if(o->GetSel()) o->EndMove();
		GetNext(pos);
	};
	m_HtmlObjectView->GetDocument()->GetHtmlObjList()->MakeNonIntersectHeight();
	m_HtmlObjectView->UpdateScrollBar();
	UpdateVisualObjProperites();
}

void CVisualObjList::Move(CPoint p)
{
	POSITION pos;
	CVisualObj *o;
	pos=GetHeadPosition();
	while(pos){
		o=GetAt(pos);
		if(o->GetSel()){
			o->Move(p);
		};
		GetNext(pos);
	};
	m_HtmlObjectView->GetDocument()->GetHtmlObjList()->MakeNonIntersectHeight();
	
	m_HtmlObjectView->UpdateScrollBar();
	UpdateVisualObjProperites();
}

void CVisualObjList::SelectRegion(CRect r)
{
	r.NormalizeRect();
	CRect ro;
	POSITION pos;
	CVisualObj* o;
	CHtmlObj* ho;
	BOOL b;
	pos=GetHeadPosition();
	while(pos){
		o=GetAt(pos);
		ho=o->m_HtmlObj;
		ro.SetRect(ho->GetLeft(), ho->GetTop(), 
			ho->GetLeft()+ho->GetWidth(), ho->GetTop()+ho->GetHeight());
		b=o->GetSel();
		CClientDC dc(o->GetParent());
		if(!((r&ro).IsRectEmpty())) {
			if(!b) o->GetParent()->DrawSelectRegion(&dc);
			o->SetSel(TRUE);
			o->m_Wnd->RedrawWindow();
			if(!b) o->GetParent()->DrawSelectRegion(&dc);
		}
		else{
			if(b) o->GetParent()->DrawSelectRegion(&dc);
			o->SetSel(FALSE);
			o->m_Wnd->RedrawWindow();
			if(b) o->GetParent()->DrawSelectRegion(&dc);
		};
		GetNext(pos);
	};
}
