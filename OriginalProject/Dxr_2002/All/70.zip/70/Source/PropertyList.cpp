// PropertyList.cpp: implementation of the CPropertyList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HtmlObject.h"
#include "PropertyList.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPropertyList::CPropertyList()
{

}

CPropertyList::~CPropertyList()
{
	RemoveAll();
}

void CPropertyList::SetProperty(LPCTSTR name, LPCTSTR value, BOOL isdefined)
{
	CProperty* p;
	POSITION pos=GetPropertyPos(name);
	if(pos) {
		p=GetAt(pos);
		p->SetProperty(name,value);
	}
	else{
		p=new CProperty(name, value);
		AddTail(p);
	};
	p->IsDefined=isdefined;
}

void CPropertyList::SetProperty(LPCTSTR name)
{
	SetProperty(name, "", FALSE);
}

CProperty* CPropertyList::GetProperty(LPCTSTR name)
{
	POSITION pos=GetPropertyPos(name);
	if(pos) return GetAt(pos);
	else return NULL;
}

POSITION CPropertyList::GetPropertyPos(LPCTSTR name)
{
	POSITION pos;
	CProperty* o;
	pos=GetHeadPosition();
	while(pos!=NULL){
		o=GetAt(pos);
		if(o->Name==CString(name)) return pos;
		GetNext(pos);
	};
	return NULL;
}

void CPropertyList::RemoveAll()
{
	POSITION pos;
	CProperty* o;
	pos=GetHeadPosition();
	while(pos!=NULL){
		o=GetAt(pos);
		delete o;
		GetNext(pos);
	};
	CPropertyListBase::RemoveAll();
}

void CPropertyList::AddProperty(CPropertyList &pl)
{
	POSITION pos, pospr;
	CProperty *o, *ois;
	pos=pl.GetHeadPosition();
	while(pos!=NULL){
		o=pl.GetAt(pos);
		if(pospr=GetPropertyPos(o->Name)){
			ois=GetAt(pospr);
			ois->IsDefined=o->IsDefined && ois->IsDefined;
			if(ois->IsDefined){
				ois->IsDefined=ois->Value!=o->Value;
			};
			if(ois->IsDefined){
				ois->Value="";
			};
		}
		else{
			SetProperty(o->Name,o->Value,o->IsDefined);
		};
		pl.GetNext(pos);
	};	
}

BOOL CPropertyList::DeleteProperty(LPCSTR name)
{
	POSITION pos;
	if(pos=GetPropertyPos(name)){
		RemoveAt(pos);
		return TRUE;
	};
	return FALSE;
}
