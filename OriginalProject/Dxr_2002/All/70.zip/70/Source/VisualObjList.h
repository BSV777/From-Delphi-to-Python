// VisualObjList.h: interface for the CVisualObjList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VISUALOBJLIST_H__825D12C3_AF11_4B95_8693_B0C3B0BF6685__INCLUDED_)
#define AFX_VISUALOBJLIST_H__825D12C3_AF11_4B95_8693_B0C3B0BF6685__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#include "VisualObj.h"
class CVisualObj;
class CHtmlObjectView;

typedef CTypedPtrList<CObList, CVisualObj*>  CVisualObjListBase;

class CVisualObjList : public CVisualObjListBase  
{
public:
	void SelectRegion(CRect r);
	void Move(CPoint p);
	void EndMove();
	void BeginMove();

	void UpdateVisualObjProperites();
	void GetSelectedProperty(CPropertyList& pl);
	void SetSelectedProperty(CPropertyList& pl);
	void SelectFirst();
	void RemoveAllVisualObj();
	void RemoveSelected();
	void SelectAll(BOOL b=TRUE);
	CVisualObjList(CHtmlObjectView* htmlobjectview);
	virtual ~CVisualObjList();
protected:	
	CHtmlObjectView* m_HtmlObjectView;

};

#endif // !defined(AFX_VISUALOBJLIST_H__825D12C3_AF11_4B95_8693_B0C3B0BF6685__INCLUDED_)
