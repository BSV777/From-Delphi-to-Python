// HtmlObj.cpp: implementation of the CHtmlObj class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HtmlObject.h"
#include "HtmlObjectDoc.h"
#include "HtmlObj.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define DEFAULTHEIGHT 20
#define DEFAULTWIDTH 100

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHtmlObj::CHtmlObj()
{
	m_Rect=Point2DefaultRect(CPoint(0,0));
	m_HtmlObjList=NULL;
}

CHtmlObj::~CHtmlObj()
{
}

CString CHtmlObj::GetName()
{
	ASSERT(FALSE);
	return CString("");
}

CVisualObj* CHtmlObj::CreateVisualObject(CHtmlObjectView *parent, CRect& r)
{
	return NULL;
}

CRect CHtmlObj::Point2DefaultRect(CPoint &p)
{
	CRect r;
	r.top=p.y;
	r.bottom=r.top+DEFAULTHEIGHT;
	r.left=p.x;
	r.right=r.left+DEFAULTWIDTH;
	return r;
}

int CHtmlObj::SetProperty(CString propname, CString& propvalue)
{
	int i;
	propname.MakeUpper();
	if(propname==PTOP){
		if(!Str2IntP(propvalue, i)) return illegalvalue;
		SetTop(i);
		return ok;
	};
	if(propname==PLEFT){
		if(!Str2IntP(propvalue, i)) return illegalvalue;
		SetLeft(i);
		return ok;
	};
	if(propname==PWIDTH){
		if(!Str2IntP(propvalue, i)) return illegalvalue;
		SetWidth(i);
		return ok;
	};
	if(propname==PHEIGHT){
		if(!Str2IntP(propvalue, i)) return illegalvalue;
		SetHeight(i);
		return ok;
	};
	
	return uncnownprop;
}

BOOL CHtmlObj::SetHeight(int height)
{
	if(height>0){
		m_Rect.bottom=m_Rect.top+height;
		ReInsertInHtmlList();
		return TRUE;
	};
	return FALSE;
}

BOOL CHtmlObj::SetWidth(int width)
{
	if(width>0){
		m_Rect.right=m_Rect.left+width;
		ReInsertInHtmlList();
		return TRUE;
	};
	return FALSE;
}

BOOL CHtmlObj::SetLeft(int left)
{
	if(left>=0){
		m_Rect.right=left+m_Rect.Width();
		m_Rect.left=left;
		ReInsertInHtmlList();
		return TRUE;
	};
	return FALSE;
}

BOOL CHtmlObj::SetTop(int top)
{
	if(top>=0){
		m_Rect.bottom=top+m_Rect.Height();
		m_Rect.top=top;
		ReInsertInHtmlList();
		return TRUE;
	};
	return FALSE;
}

BOOL CHtmlObj::Str2IntP(CString s, int &i)
{
	s.TrimLeft();
	s.TrimRight();
	int j=0,len=s.GetLength();
	if(len==0) return FALSE;
	if(s.GetAt(0)=='+'){
		if(len==1) return FALSE;
		j++;
	};
	for(;j<len;j++){
		CHAR c=s.GetAt(j);
		if(c>'9'||c<'0') return FALSE;
	};
	i=atoi(s);
	return TRUE;
}

BOOL CHtmlObj::WriteConfig(CArchive &ar)
{
	try
	{
		CString s, prop;
		GetPropertyStr(prop);
		s.Format("<%s %s>", GetName(),prop);
		ar.WriteString(s);
		ar.WriteString("\r\n");
		return TRUE;
	}
	catch( CException* e )
	{
		return FALSE;
	};

}

void CHtmlObj::GetPropertyStr(CString &s)
{
	s="";
	s.Format("Top=\"%u\"; Left=\"%u\"; Width=\"%u\"; Height=\"%u\"", 
		m_Rect.top, m_Rect.left, m_Rect.Width(), m_Rect.Height());
}


CVisualObj*  CHtmlObj::CreateVisualObject(CHtmlObjectView *parent, CPoint scroll)
{
	return CreateVisualObject(parent, m_Rect-scroll);
}

void CHtmlObj::MoveTo(CPoint &p)
{
	if(p.x>=0&&p.y>=0){
		m_Rect.SetRect(p.x,p.y,p.x+m_Rect.Width(),p.y+m_Rect.Height());
		ReInsertInHtmlList();
	};
}

CString CHtmlObj::Name()
{
	return CString("");
}

int CHtmlObj::GetTop()
{
	return m_Rect.top;
}

int CHtmlObj::GetHeight()
{
	return m_Rect.Height();
}

int CHtmlObj::GetLeft()
{
	return m_Rect.left;
}

int CHtmlObj::GetWidth()
{
	return m_Rect.Width();
}


BOOL CHtmlObj::SetPropertyList(CPropertyList &p)
{
	POSITION pos;
	CProperty* o;
	BOOL b=TRUE;
	pos=p.GetHeadPosition();
	while(pos!=NULL){
		o=p.GetAt(pos);
		if(SetProperty(o->Name, o->Value)==illegalvalue){
			b=FALSE;
		};
		p.GetNext(pos);
	};
	return b;
}

void CHtmlObj::GetPropertyList(CPropertyList &p)
{
	CHAR s[100];
	p.RemoveAll();
	p.SetProperty(PTOP, itoa(m_Rect.top, s, 10));
	p.SetProperty(PLEFT, itoa(m_Rect.left, s, 10));
	p.SetProperty(PWIDTH, itoa(m_Rect.Width(), s, 10));
	p.SetProperty(PHEIGHT, itoa(m_Rect.Height(), s, 10));

}

void CHtmlObj::BeginMove(int oper)
{
	m_Oper=oper;
	m_BeginMovePos=m_Rect;
}

void CHtmlObj::EndMove()
{
	m_Oper=none;
}

void CHtmlObj::Move(CPoint p)
{
		/*
		not=				0,
		move =				1,
		resizelefttop =		2,
		resizerighttop =	3,
		resizeleftbottom =	4,
		resizerightbottom*/
	CRect r=m_BeginMovePos;
	switch( m_Oper )
	{
		
	case move:
		MoveTo(m_BeginMovePos.TopLeft()+p);
		break;
	case resizelefttop:
		r.left=r.left+p.x;
		r.top=r.top+p.y;
		SetRect(r);
		break;
	case resizerighttop:
		r.right=r.right+p.x;
		r.top=r.top+p.y;
		SetRect(r);
		break;
	case resizeleftbottom:
		r.left=r.left+p.x;
		r.bottom=r.bottom+p.y;
		SetRect(r);
		break;
	case resizerightbottom:
		r.right=r.right+p.x;
		r.bottom=r.bottom+p.y;
		SetRect(r);
		break;
	};
}

void CHtmlObj::InsertInHtmlList(CHtmlObjList* HtmlObjList)
{
	m_HtmlObjList=HtmlObjList;
	m_HtmlObjList->Insert(this);
}

void CHtmlObj::ReInsertInHtmlList()
{
	if(m_HtmlObjList){
		m_HtmlObjList->DeleteObj(this);
		m_HtmlObjList->Insert(this);
	};
}

CHtmlObjList* CHtmlObj::GetHtmlObjList()
{
	return m_HtmlObjList;
}

void CHtmlObj::GetRect(CRect &r)
{
	r=m_Rect;
}

void CHtmlObj::CalcHtmlSizes()
{
	m_HtmlHeight=m_Rect.Height();
	m_HtmlWidth=m_Rect.Width();
}

CRect CHtmlObj::GetRect()
{
	return m_Rect;
}

void CHtmlObj::SetRect(CRect r)
{
	r.NormalizeRect();
	if((r.top>=0)&&(r.left>=0)&&(!r.IsRectEmpty())){
		m_Rect=r;
		if(m_Rect.Height()<1){
			m_Rect.bottom=m_Rect.top+1;
		};
		ReInsertInHtmlList();
	};
}

void CHtmlObj::WriteToHtml(CArchive *ar)
{
}
