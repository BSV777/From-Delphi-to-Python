// VisualObj.cpp: implementation of the CVisualObj class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HtmlObject.h"
#include "VisualObj.h"
#include "HtmlObjectView.h"
#include "HtmlObjectDoc.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define SIZERESIZE 7
CVisualObjList CVisualObj::m_ListAllObj(NULL);


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CVisualObj::CVisualObj(CHtmlObjectView* parent, CHtmlObj* htmlobj)
{
	m_HtmlObj=htmlobj;
	m_ListAllObj.AddTail(this);
	m_Parent=parent;
	m_Sel=FALSE;
}

CVisualObj::~CVisualObj()
{
	POSITION pos;
	
	delete m_Wnd;

	if( ( pos = m_ListAllObj.Find(this) ) != NULL ) {
		m_ListAllObj.RemoveAt(pos);
	};
}

void CVisualObj::SetWndProc()
{
	m_WndProc=WNDPROC(GetWindowLong(m_Wnd->m_hWnd, GWL_WNDPROC));
	SetWindowLong(m_Wnd->m_hWnd,GWL_WNDPROC, LONG(WndProcAllObj));
	m_Oper=CHtmlObj::none;

}

BOOL CVisualObj::IsObjForHwnd(HWND hwnd)
{
	if(hwnd==m_Wnd->m_hWnd){
		return TRUE;
	}
	else{
		return FALSE;
	};
}

CVisualObj* CVisualObj::SearchObj(HWND hwnd)
{
	POSITION pos;
	CVisualObj* o;
	pos=m_ListAllObj.GetHeadPosition();
	while(pos!=NULL){
		o=m_ListAllObj.GetAt(pos);
		if(o->IsObjForHwnd(hwnd)) return o;
		m_ListAllObj.GetNext(pos);
	};
	return NULL;
}

LRESULT CVisualObj::WndProcAllObj(
							 HWND hwnd,      // handle to window
							 UINT uMsg,      // message identifier
							 WPARAM wParam,  // first message parameter
							 LPARAM lParam   // second message parameter
							 )
{
	CVisualObj* ho=SearchObj(hwnd);
	ASSERT(ho!=NULL); 
	return ho->WndProc(hwnd, uMsg, wParam, lParam);
}

LRESULT CVisualObj::WndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	LRESULT lr;
	POINT pos;
	CRect r;

	if(uMsg==WM_LBUTTONDBLCLK){
		((CHtmlObjectApp*) AfxGetApp())->ShowDialogProp(TRUE);
		return 0;
	};

	if(uMsg==WM_LBUTTONDOWN){
		m_IsMouseMoved=FALSE;

		SetCapture(m_Wnd->m_hWnd);
		m_Parent->Activate();
		pos.x=GET_X_LPARAM(lParam); 
		pos.y=GET_Y_LPARAM(lParam); 

		GetBottomLeftRect(r);
		if(r.PtInRect(pos)){
			m_Oper=CHtmlObj::resizeleftbottom;
		}
		else{
			GetTopLeftRect(r);
			if(r.PtInRect(pos)){
				m_Oper=CHtmlObj::resizelefttop;
			}
			else{
				GetTopRightRect(r);
				if(r.PtInRect(pos)){
					m_Oper=CHtmlObj::resizerighttop;
				}
				else{
					GetBottomRightRect(r);
					if(r.PtInRect(pos)){
						m_Oper=CHtmlObj::resizerightbottom;
					}
					else{
						m_Oper=CHtmlObj::move;	
					};
				};
			};
		};

		ClientToScreen(m_Wnd->m_hWnd,&pos);
		m_PosMouseDown=pos;
		return 0;
	};

	if(uMsg==WM_LBUTTONUP){
		m_Oper=CHtmlObj::none;	
		ReleaseCapture();
		if(m_IsMouseMoved){
			m_Parent->m_VisualObjList.EndMove();
		}
		else{
			if((wParam&MK_SHIFT)==MK_SHIFT){
				SetSel(TRUE);
				return 0;
			}
			if((wParam&MK_CONTROL)==MK_CONTROL){
				SetSel(!GetSel());
				return 0;
			}
			m_Parent->m_VisualObjList.SelectAll(FALSE);
			SetSel(TRUE);
		};
		return 0;
	};

	if(uMsg==WM_MOUSEMOVE){
		if(!m_IsMouseMoved){
			m_IsMouseMoved=TRUE;
			if(!GetSel()){
				m_Parent->m_VisualObjList.SelectAll(FALSE);
				SetSel(TRUE);
			};
			if(m_Oper!=CHtmlObj::none){
				if(m_Oper==CHtmlObj::move){
					m_Parent->m_VisualObjList.BeginMove();
				}
				else{
					m_HtmlObj->BeginMove(m_Oper);
				};
			};
		};
		if(m_Oper!=CHtmlObj::none)
		{
			pos.x=GET_X_LPARAM(lParam); 
			pos.y=GET_Y_LPARAM(lParam); 
			ClientToScreen(m_Wnd->m_hWnd,&pos);
			switch( m_Oper )
			{
			case CHtmlObj::move:
				m_Parent->m_VisualObjList.Move(CPoint(pos)-m_PosMouseDown);
				break;
			default:
				m_HtmlObj->Move(CPoint(pos)-m_PosMouseDown);
				m_Parent->m_VisualObjList.UpdateVisualObjProperites();
				break;
			};
			((CHtmlObjectApp*) AfxGetApp())->m_DialogProp.UpdateMember();
		};
		return 0;
	};

	if(uMsg==WM_PAINT){
		lr=CallWindowProc(m_WndProc, hwnd,uMsg ,wParam, lParam);
		Paint();

		return 0;
	};
	if(uMsg==WM_SETTEXT){
		lr=CallWindowProc(m_WndProc, hwnd,uMsg ,wParam, lParam);
		Paint();
		return 0;
	};
	lr=CallWindowProc(m_WndProc, hwnd,uMsg ,wParam, lParam);
	return lr;
}

BOOL CVisualObj::GetSel()
{
	return m_Sel;
}

void CVisualObj::SetSel(BOOL sel)
{
	if(GetSel()!=sel){
		m_Sel=sel;
		((CHtmlObjectApp*) AfxGetApp())->m_DialogProp.SetView(m_Parent);
		m_Wnd->Invalidate();
	}
}

BOOL CVisualObj::IsResizable()
{
	return GetSel();// ��������
}



CHtmlObjectView* CVisualObj::GetParent()
{
	return m_Parent;
}

void CVisualObj::UpdateProperites()
{
	CRect r,rr;
	POINT p1,p2;
	m_Wnd->GetWindowRect(&rr);
	m_HtmlObj->GetRect(r);
	CPoint sp=m_Parent->GetScrollPosition();
	m_Wnd->MoveWindow(r-sp,FALSE);
	
	p1=rr.TopLeft();
	p2=rr.BottomRight();
	ScreenToClient(m_Parent->m_hWnd,&p1);
	ScreenToClient(m_Parent->m_hWnd,&p2);
	rr.SetRect(p1,p2);
	rr.InflateRect(SIZERESIZE,SIZERESIZE);
	InvalidateRect(m_Parent->m_hWnd,rr,TRUE);
}

void CVisualObj::Paint()
{
	if(GetSel()&&m_Parent->m_Active){
		CClientDC dc(m_Wnd);
		CRect r;
		GetTopLeftRect(r);
		dc.Rectangle(r);
		
		GetTopRightRect(r);
		dc.Rectangle(r);
		
		GetBottomLeftRect(r);
		dc.Rectangle(r);
		
		GetBottomRightRect(r);
		dc.Rectangle(r);
	};
	
}

void CVisualObj::GetTopLeftRect(CRect &r)
{
	r.SetRect(0, 0, SIZERESIZE, SIZERESIZE);
}

void CVisualObj::GetTopRightRect(CRect &r)
{
	CRect rc;
	GetClientRect(m_Wnd->m_hWnd, rc);
	r.SetRect(rc.right-SIZERESIZE, 0, rc.right, SIZERESIZE);
}

void CVisualObj::GetBottomLeftRect(CRect &r)
{
	CRect rc;
	GetClientRect(m_Wnd->m_hWnd, rc);
	r.SetRect(0, rc.bottom-SIZERESIZE, SIZERESIZE, rc.bottom);
}

void CVisualObj::GetBottomRightRect(CRect &r)
{
	CRect rc;
	GetClientRect(m_Wnd->m_hWnd, rc);
	r.SetRect(rc.right-SIZERESIZE, rc.bottom-SIZERESIZE, rc.right, rc.bottom);
}

void CVisualObj::BeginMove()
{
	m_HtmlObj->BeginMove(CHtmlObj::move);
}

void CVisualObj::EndMove()
{
	m_HtmlObj->EndMove();
}

void CVisualObj::Move(CPoint p)
{
	m_HtmlObj->Move(p);
}

void CVisualObj::MoveMouse(CPoint p)
{
	m_Parent->m_VisualObjList.Move(p);
}

