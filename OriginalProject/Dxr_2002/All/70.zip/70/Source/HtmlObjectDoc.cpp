// HtmlObjectDoc.cpp : implementation of the CHtmlObjectDoc class
//

#include "stdafx.h"
#include "HtmlObject.h"

#include "HtmlObjectDoc.h"
#include "Parser.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHtmlObjectDoc

IMPLEMENT_DYNCREATE(CHtmlObjectDoc, CDocument)

BEGIN_MESSAGE_MAP(CHtmlObjectDoc, CDocument)
	//{{AFX_MSG_MAP(CHtmlObjectDoc)
	ON_COMMAND(ID_BUTTONEXPORTHTML, OnButtonExportHtml)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHtmlObjectDoc construction/destruction

CHtmlObjectDoc::CHtmlObjectDoc()
{
	// TODO: add one-time construction code here

}

CHtmlObjectDoc::~CHtmlObjectDoc()
{
}

BOOL CHtmlObjectDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)
	m_HtmObjList.FreeObj();
	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CHtmlObjectDoc serialization

void CHtmlObjectDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
		m_HtmObjList.WriteConfig(ar);
	}
	else
	{
		m_HtmObjList.FreeObj();
		CFile fer;
		CArchive* pArer;
		if( !fer.Open( "Error.lst", CFile::modeCreate | CFile::modeWrite ) ) {
			pArer=NULL;
		}
		else{
			pArer=new CArchive ( &fer, CArchive::store, 4096);
		};
		if(m_HtmObjList.ReadConfig(&ar, pArer)!=CParser::ok){
			AfxGetApp()->GetMainWnd()->MessageBox("��� ������ ����� ������������ ���������� ������.\n������ ����� � ����� Error.lst",NULL,MB_ICONERROR);
		};

		pArer->Close();
		fer.Close();
		delete pArer;
		
	}
}

/////////////////////////////////////////////////////////////////////////////
// CHtmlObjectDoc diagnostics

#ifdef _DEBUG
void CHtmlObjectDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CHtmlObjectDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CHtmlObjectDoc commands

void CHtmlObjectDoc::InsertObj(CHtmlObj *o)
{
	o->InsertInHtmlList(&m_HtmObjList);
	m_HtmObjList.MakeNonIntersectHeight();
}

CHtmlObjList* CHtmlObjectDoc::GetHtmlObjList()
{
	return &m_HtmObjList;
}

void CHtmlObjectDoc::OnButtonExportHtml() 
{
	CFileDialog d(FALSE,"HTML",NULL,
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"����� HTML(*.html)|*.html|��� ����� (*.*)|*.*||");	
	
	if(d.DoModal()==IDOK){
		
		if(!m_HtmObjList.WriteToHtml( d.GetPathName(), CHtmlObjList::maxoptimize)){
			CString s;
			s.Format("������ ������ � ���� %s", d.GetPathName());
			AfxGetApp()->GetMainWnd()->MessageBox(s,NULL,MB_ICONERROR);
		};

	};

	
}
