//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by HtmlObject.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_HTMOBJTYPE                  129
#define IDR_TOOLBAROBJ                  130
#define IDD_DIALOGPROP                  134
#define IDB_BITMAPBUTTON                135
#define IDD_DIALOGcreate                136
#define IDC_EDITTOP                     1001
#define IDC_EDITCAPTION                 1002
#define IDC_EDITLEFT                    1003
#define IDC_EDITHEIGHT                  1004
#define IDC_EDITWIDTH                   1005
#define IDC_EDITTEXT                    1006
#define IDC_STATICTEXT                  1007
#define IDC_STATICCAPTION               1008
#define IDC_STATICfn                    1012
#define ID_TOOLBUTTON                   32771
#define ID_TOOLLABEL                    32772
#define ID_TOOLEDIT                     32773
#define ID_TOOLPOINT                    32774
#define ID_BUTTONDELETE                 32775
#define ID_BUTTONSHOWPROP               32776
#define IDSELECTALL                     32777
#define ID_BUTTONEXPORTHTML             32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
