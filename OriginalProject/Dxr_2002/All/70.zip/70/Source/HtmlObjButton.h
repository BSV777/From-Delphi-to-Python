// HtmlObjButton.h: interface for the CHtmlObjButton class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HTMLOBJBUTTON_H__0C25FC16_89C8_4423_9F05_1DA9C4A60A20__INCLUDED_)
#define AFX_HTMLOBJBUTTON_H__0C25FC16_89C8_4423_9F05_1DA9C4A60A20__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "HtmlObj.h"

#define PCAPTION "CAPTION"

class CHtmlObjButton : public CHtmlObj  
{
public:
	virtual void WriteToHtml(CArchive *ar);
	virtual void GetPropertyList(CPropertyList& p);
	static CString Name();
	virtual int SetProperty(CString propname, CString& propvalue);
	BOOL SetCaption(CString &caption);
	CString m_Caption;
	static CHtmlObj*  CreateIfMyName(CString& nane);
	virtual CString GetName();
	CHtmlObjButton();
	virtual ~CHtmlObjButton();
private:
	virtual CVisualObj* CreateVisualObject(CHtmlObjectView *parent, CRect& r);

protected:
	virtual void GetPropertyStr(CString &s);
};

#endif // !defined(AFX_HTMLOBJBUTTON_H__0C25FC16_89C8_4423_9F05_1DA9C4A60A20__INCLUDED_)
