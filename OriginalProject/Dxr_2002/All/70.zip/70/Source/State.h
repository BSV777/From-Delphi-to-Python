// State.h: interface for the CState class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STATE_H__8488BE30_714B_4118_A95D_383F4F22902B__INCLUDED_)
#define AFX_STATE_H__8488BE30_714B_4118_A95D_383F4F22902B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "HtmlObj.h"

class CState  
{
public:
	void FreeInsertObj();
	void DeleteInsertObj();
	SetInsertObj(CHtmlObj* obj);
	CHtmlObj* GetInsertObj();
	CState();
	virtual ~CState(); 

private:
	CHtmlObj* m_InsertObj;

};

#endif // !defined(AFX_STATE_H__8488BE30_714B_4118_A95D_383F4F22902B__INCLUDED_)
