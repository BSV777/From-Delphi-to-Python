// HtmlObjLabel.h: interface for the CHtmlObjLabel class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HTMLOBJLABEL_H__207B1BCD_94C9_4C2E_8CF5_4C89FC885547__INCLUDED_)
#define AFX_HTMLOBJLABEL_H__207B1BCD_94C9_4C2E_8CF5_4C89FC885547__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "HtmlObj.h"

#define PTEXT "TEXT"

class CHtmlObjLabel : public CHtmlObj  
{
public:
	virtual void WriteToHtml(CArchive *ar);
	virtual void GetPropertyList(CPropertyList& p);
	static CString Name();
	virtual int SetProperty(CString propname, CString& propvalue);
	virtual BOOL SetText(CString &text);
	static CHtmlObj*  CreateIfMyName(CString& name);
	virtual CString GetName();
	CHtmlObjLabel();
	virtual ~CHtmlObjLabel();
	CString m_Text;
private:
	virtual CVisualObj* CreateVisualObject(CHtmlObjectView *parent, CRect& r);

protected:
	virtual void GetPropertyStr(CString &s);
};

#endif // !defined(AFX_HTMLOBJLABEL_H__207B1BCD_94C9_4C2E_8CF5_4C89FC885547__INCLUDED_)
