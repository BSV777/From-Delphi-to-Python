// HtmlObjectView.cpp : implementation of the CHtmlObjectView class
//

#include "stdafx.h"
#include "HtmlObject.h"

#include "HtmlObjectDoc.h"
#include "HtmlObjectView.h"

#include "HtmlObj.h"
#include "HtmlObjLabel.h"
#include "HtmlObjTextEdit.h"
#include "HtmlObjButton.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHtmlObjectView

IMPLEMENT_DYNCREATE(CHtmlObjectView, CScrollView)

BEGIN_MESSAGE_MAP(CHtmlObjectView, CScrollView)
	//{{AFX_MSG_MAP(CHtmlObjectView)
	ON_WM_SETCURSOR()
	ON_WM_CREATE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_DESTROY()
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_COMMAND(ID_BUTTONDELETE, OnButtondelete)
	ON_WM_MOUSEWHEEL()
	ON_COMMAND(IDSELECTALL, OnSelectall)
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHtmlObjectView construction/destruction

CHtmlObjectView::CHtmlObjectView():m_VisualObjList(this)
{
	m_Active=FALSE;
}

CHtmlObjectView::~CHtmlObjectView()
{
}

BOOL CHtmlObjectView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CHtmlObjectView drawing

void CHtmlObjectView::OnDraw(CDC* pDC)
{
	//CHtmlObjectDoc* pDoc = GetDocument();
	//ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	DrawSelectRegion(pDC);
	DrawActive();
}

void CHtmlObjectView::OnInitialUpdate()
{
	m_IsSelectRegion=FALSE;
	CSize sizeTotal;
	// TODO: calculate the total size of this view
	UpdateScrollBar(TRUE);
	CScrollView::OnInitialUpdate();
	GetDocument()->UpdateAllViews(this);
}	


/////////////////////////////////////////////////////////////////////////////
// CHtmlObjectView printing

BOOL CHtmlObjectView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CHtmlObjectView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CHtmlObjectView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CHtmlObjectView diagnostics

#ifdef _DEBUG
void CHtmlObjectView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CHtmlObjectView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CHtmlObjectDoc* CHtmlObjectView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CHtmlObjectDoc)));
	return (CHtmlObjectDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CHtmlObjectView message handlers


BOOL CHtmlObjectView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	POINT pm;
	GetCursorPos(&pm);
	ScreenToClient(&pm);

	CHtmlObj* o;
	CHtmlObjectApp* app=(CHtmlObjectApp*)AfxGetApp();
	CState* state=app->GetState();
	o=state->GetInsertObj();
	if(o!=NULL){
		SetCursor(app->m_hkrest);
	}
	else{
		SetCursor(app->m_hnormcur);
	};
	
	return TRUE;

	//return CScrollView::OnSetCursor(pWnd, nHitTest, message);
}

int CHtmlObjectView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{

	if (CScrollView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	Activate();
	return 0;
}

void CHtmlObjectView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CHtmlObjectDoc* doc=GetDocument();
	CHtmlObj* o;
	CHtmlObjectApp* app=(CHtmlObjectApp*)AfxGetApp();
	CState* state=app->GetState();
	o=state->GetInsertObj();
	if(o!=NULL){
		CPoint sp=GetScrollPosition( );
		o->MoveTo(point+sp);
		doc->InsertObj(o);
		state->DeleteInsertObj();
		doc->UpdateAllViews(NULL);

		m_VisualObjList.SelectAll(FALSE);
		POSITION pos = m_VisualObjList.GetHeadPosition();
		while(pos != NULL){
			CVisualObj* ov=m_VisualObjList.GetAt( pos );
			if(ov->m_HtmlObj==o) ov->SetSel(TRUE);
			m_VisualObjList.GetNext(pos);
		};	

		doc->SetModifiedFlag();
	}
	else{
		m_IsSelectRegion=TRUE;
		SetCapture();
		m_SelectRegion.TopLeft()=point;
		m_SelectRegion.BottomRight()=point;
	};
	Activate();
	

	CScrollView::OnLButtonDown(nFlags, point);
}

void CHtmlObjectView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if(m_IsSelectRegion){
		Invalidate();
		ReleaseCapture();
		m_IsSelectRegion=FALSE;
	};
	CScrollView::OnLButtonUp(nFlags, point);
}

void CHtmlObjectView::OnMouseMove(UINT nFlags, CPoint point) 
{
	if(m_IsSelectRegion){
		CClientDC dc(this);
		DrawSelectRegion(&dc);
		m_SelectRegion.BottomRight()=point;
		DrawSelectRegion(&dc);
		CPoint scroll=GetScrollPosition();
		m_VisualObjList.SelectRegion(m_SelectRegion+scroll);
	};
	
	CScrollView::OnMouseMove(nFlags, point);
}

void CHtmlObjectView::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	
	Activate();
	CScrollView::OnLButtonDblClk(nFlags, point);
}

void CHtmlObjectView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	if(lHint==UPDATEALL){
		RecreateVisualObj();
	};
	if(lHint==UPDATEACTIVE){
		m_Active=FALSE;
		Invalidate();
	};
	if(lHint==UPDATEONLYPROPERTY){
		m_VisualObjList.UpdateVisualObjProperites();
	};
}

void CHtmlObjectView::RecreateVisualObj()
{
	m_VisualObjList.RemoveAllVisualObj();
	CHtmlObjectDoc* doc=GetDocument();
	CHtmlObjList* l=doc->GetHtmlObjList();

	CPoint scroll=GetScrollPosition();
	POSITION pos = l->GetHeadPosition();
	while(pos != NULL){
		CHtmlObj* o=l->GetAt(pos);
		m_VisualObjList.AddTail(o->CreateVisualObject(this, scroll));
		l->GetNext(pos);
	};	
	m_VisualObjList.SelectFirst();
}

void CHtmlObjectView::OnDestroy() 
{
	CScrollView::OnDestroy();
	m_VisualObjList.RemoveAllVisualObj();
}


void CHtmlObjectView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	if(nSBCode==SB_LINERIGHT){
		CPoint p=GetScrollPosition();
		CSize sz=GetTotalSize(); 
		CRect r;
		GetClientRect(r);
		if(p.x>=sz.cx-r.right){
			sz.cx=sz.cx+10;
			SetScrollSizes(MM_TEXT, sz);
		};
	};
	CScrollView::OnHScroll(nSBCode, nPos, pScrollBar);
	Invalidate();
}

void CHtmlObjectView::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	if(nSBCode==SB_LINEDOWN){
		CPoint p=GetScrollPosition();
		CSize sz=GetTotalSize(); 
		CRect r;
		GetClientRect(r);
		if(p.y>=sz.cy-r.bottom){
			sz.cy=sz.cy+10;
			SetScrollSizes(MM_TEXT, sz);
		};
	};
	
	CScrollView::OnVScroll(nSBCode, nPos, pScrollBar);
	Invalidate();

}

void CHtmlObjectView::Activate()
{
	if(!m_Active){
		GetDocument()->UpdateAllViews(this,1);
		m_Active=TRUE;
		Invalidate();
		((CHtmlObjectApp*) AfxGetApp())->m_DialogProp.SetView(this);
	};
}

void CHtmlObjectView::DrawActive()
{
	if(m_Active){
		CClientDC dc(this);
		CRect r;
		GetClientRect(r);
		//dc.SetROP2(R2_NOT);
		dc.MoveTo(0,0);
		dc.LineTo(r.right-1,0);
		dc.LineTo(r.right-1,r.bottom-1);
		dc.LineTo(0,r.bottom-1);
		dc.LineTo(0,0);
	};
}

void CHtmlObjectView::OnButtondelete() 
{
	if(m_Active){
		m_VisualObjList.RemoveSelected();
		GetDocument()->UpdateAllViews(NULL);
	};
}


BOOL CHtmlObjectView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	Invalidate();
	
	return CScrollView::OnMouseWheel(nFlags, zDelta, pt);
}

void CHtmlObjectView::OnSelectall() 
{
	m_VisualObjList.SelectAll();	
}

void CHtmlObjectView::DrawSelectRegion(CDC *pDC)
{
	if(m_IsSelectRegion){
		int r2=pDC->GetROP2();
		pDC->SetROP2(R2_NOT);
		
		pDC->MoveTo(m_SelectRegion.TopLeft());
		pDC->LineTo(m_SelectRegion.TopLeft()+CPoint(m_SelectRegion.Width(),0));
		pDC->LineTo(m_SelectRegion.BottomRight());
		pDC->LineTo(m_SelectRegion.TopLeft()+CPoint(0,m_SelectRegion.Height()));
		pDC->LineTo(m_SelectRegion.TopLeft());
		
		pDC->SetROP2(r2);
	};
}


void CHtmlObjectView::UpdateScrollBar(BOOL setdefault)
{
	CSize sizeTotal, cur;
	if(setdefault){
		cur.cx=cur.cy=0;
	}
	else{
		cur=GetTotalSize( ) ;
	};
	CHtmlObjectDoc* doc=GetDocument();
	sizeTotal.cx = doc->GetHtmlObjList()->GetWidth();
	sizeTotal.cy = doc->GetHtmlObjList()->GetHeight();
	if(sizeTotal.cx>cur.cx||sizeTotal.cy>cur.cy||setdefault){
		
		sizeTotal.cx=sizeTotal.cx>cur.cx?sizeTotal.cx:cur.cx;
		sizeTotal.cy=sizeTotal.cy>cur.cy?sizeTotal.cy:cur.cy;
		SetScrollSizes(MM_TEXT, sizeTotal);
	};
}

void CHtmlObjectView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if(nChar==46){
		OnButtondelete();
	}
	else{
		CScrollView::OnKeyDown(nChar, nRepCnt, nFlags);
	};
}
