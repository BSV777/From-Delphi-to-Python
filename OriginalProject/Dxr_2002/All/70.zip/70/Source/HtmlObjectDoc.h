// HtmlObjectDoc.h : interface of the CHtmlObjectDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_HTMLOBJECTDOC_H__DFBF2F29_DB05_4E87_A088_4F547BD4D34B__INCLUDED_)
#define AFX_HTMLOBJECTDOC_H__DFBF2F29_DB05_4E87_A088_4F547BD4D34B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "HtmlObj.h"
#include "HtmlObjLabel.h"
#include "HtmlObjTextEdit.h"
#include "HtmlObjButton.h"


class CHtmlObjectDoc : public CDocument
{
protected: // create from serialization only
	CHtmlObjectDoc();
	DECLARE_DYNCREATE(CHtmlObjectDoc)

// Attributes
	CHtmlObjList m_HtmObjList;
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHtmlObjectDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	CHtmlObjList* GetHtmlObjList();
	void InsertObj(CHtmlObj *o);
	//CHtmlObj* SearchObj(HWND hwnd);
	virtual ~CHtmlObjectDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CHtmlObjectDoc)
	afx_msg void OnButtonExportHtml();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HTMLOBJECTDOC_H__DFBF2F29_DB05_4E87_A088_4F547BD4D34B__INCLUDED_)
