// OptimConfTabl.h: interface for the COptimConfTabl class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_OPTIMCONFTABL_H__BEA5D37C_6A41_4678_A5F0_CBFB6F7433BA__INCLUDED_)
#define AFX_OPTIMCONFTABL_H__BEA5D37C_6A41_4678_A5F0_CBFB6F7433BA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class COptimConfTabl  
{
public:
	COptimConfTabl();
	virtual ~COptimConfTabl();

};

#endif // !defined(AFX_OPTIMCONFTABL_H__BEA5D37C_6A41_4678_A5F0_CBFB6F7433BA__INCLUDED_)
