// PropertyList.h: interface for the CPropertyList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROPERTYLIST_H__EE42C219_885E_4BD0_AED3_FAE14A4810F5__INCLUDED_)
#define AFX_PROPERTYLIST_H__EE42C219_885E_4BD0_AED3_FAE14A4810F5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Property.h"

typedef CTypedPtrList<CObList, CProperty*>  CPropertyListBase;

class CPropertyList : public CPropertyListBase  
{
public:
	BOOL DeleteProperty(LPCSTR name);
	void AddProperty(CPropertyList& pl);
	void RemoveAll();
	CProperty* GetProperty(LPCTSTR name);
	void SetProperty(LPCTSTR name);
	void SetProperty(LPCTSTR name, LPCTSTR value, BOOL isdefined=TRUE);
	CPropertyList();
	virtual ~CPropertyList();

protected:
	POSITION GetPropertyPos(LPCTSTR name);
};

#endif // !defined(AFX_PROPERTYLIST_H__EE42C219_885E_4BD0_AED3_FAE14A4810F5__INCLUDED_)
