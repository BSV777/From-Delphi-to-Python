// VisualObjButton.h: interface for the CVisualObjButton class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VISUALOBJBUTTON_H__F85C9D9A_725A_4CB2_8DEC_E81C41CAEBBF__INCLUDED_)
#define AFX_VISUALOBJBUTTON_H__F85C9D9A_725A_4CB2_8DEC_E81C41CAEBBF__INCLUDED_

#include "visualobj.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
	   
class CVisualObjButton : public  CVisualObj  
{
public:
	CVisualObjButton(CHtmlObjectView* parent, CRect &r, CHtmlObj* htmlobj);
	virtual void UpdateProperites();
};

#endif // !defined(AFX_VISUALOBJBUTTON_H__F85C9D9A_725A_4CB2_8DEC_E81C41CAEBBF__INCLUDED_)
