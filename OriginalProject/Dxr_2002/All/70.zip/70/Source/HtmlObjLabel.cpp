// HtmlObjLabel.cpp: implementation of the CHtmlObjLabel class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HtmlObject.h"
#include "HtmlObjLabel.h"
#include "VisualObjLabel.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHtmlObjLabel::CHtmlObjLabel()
{
	m_Text="Label";
}

CHtmlObjLabel::~CHtmlObjLabel()
{

}

CString CHtmlObjLabel::GetName()
{
	return Name();
}

CVisualObj* CHtmlObjLabel::CreateVisualObject(CHtmlObjectView *parent, CRect& r)
{
	CVisualObj* o;
	o=new CVisualObjLabel(parent, r, this);
	return o;
}

CHtmlObj* CHtmlObjLabel::CreateIfMyName(CString &name)
{
	CString s=name;
	s.MakeUpper();
	if (s==Name()){
		CHtmlObj* o=new	CHtmlObjLabel;
		return o;
	};
	return NULL;
}

BOOL CHtmlObjLabel::SetText(CString &text)
{
	if(text.Find('"')<0){
		m_Text=text;
		return TRUE;
	}
	return FALSE;
}

int CHtmlObjLabel::SetProperty(CString propname, CString &propvalue)
{
	propname.MakeUpper();
	if(propname==PTEXT){
		SetText(propvalue);
		return ok;
	};
	return CHtmlObj::SetProperty(propname, propvalue);
}

void CHtmlObjLabel::GetPropertyStr(CString &s)
{
	CHtmlObj::GetPropertyStr(s);
	s.Format("%s; Text=\"%s\"",s,m_Text);
}

CString CHtmlObjLabel::Name()
{
	return CString("LABEL"); //��� ���������� �������
}

void CHtmlObjLabel::GetPropertyList(CPropertyList &p)
{
	CHtmlObj::GetPropertyList(p);
	p.SetProperty(PTEXT, m_Text);
}

void CHtmlObjLabel::WriteToHtml(CArchive *ar)
{
	//CString s;
	//s.Format("<INPUT value=\"%s\" style=\"width=%d; height=%d\">",m_Text,m_HtmlWidth, m_HtmlHeight);
	ar->WriteString(m_Text);
}
