// VisualObjLabel.h: interface for the CVisualObjLabel class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VISUALOBJLABEL_H__FF530584_EC47_400A_9482_62FDCB9EFF0E__INCLUDED_)
#define AFX_VISUALOBJLABEL_H__FF530584_EC47_400A_9482_62FDCB9EFF0E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "VisualObj.h"

class CVisualObjLabel : public CVisualObj  
{
public:
	CVisualObjLabel(CHtmlObjectView* parent, CRect &r, CHtmlObj* htmlobj);
	virtual void UpdateProperites();
};

#endif // !defined(AFX_VISUALOBJLABEL_H__FF530584_EC47_400A_9482_62FDCB9EFF0E__INCLUDED_)
