// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "HtmlObject.h"

#include "MainFrm.h"

#include "HtmlObj.h"
#include "HtmlObjLabel.h"
#include "HtmlObjTextEdit.h"
#include "HtmlObjButton.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_TOOLBUTTON, OnToolbutton)
	ON_COMMAND(ID_TOOLEDIT, OnTooledit)
	ON_COMMAND(ID_TOOLLABEL, OnToollabel)
	ON_COMMAND(ID_TOOLPOINT, OnToolpoint)
	ON_UPDATE_COMMAND_UI(ID_TOOLBUTTON, OnUpdateToolbutton)
	ON_UPDATE_COMMAND_UI(ID_TOOLEDIT, OnUpdateTooledit)
	ON_UPDATE_COMMAND_UI(ID_TOOLLABEL, OnUpdateToollabel)
	ON_UPDATE_COMMAND_UI(ID_TOOLPOINT, OnUpdateToolpoint)
	ON_WM_ACTIVATEAPP()
	//}}AFX_MSG_MAP
	// Global help commands
	ON_COMMAND(ID_HELP_FINDER, CFrameWnd::OnHelpFinder)
	ON_COMMAND(ID_HELP, CFrameWnd::OnHelp)
	ON_COMMAND(ID_CONTEXT_HELP, CFrameWnd::OnContextHelp)
	ON_COMMAND(ID_DEFAULT_HELP, CFrameWnd::OnHelpFinder)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC)||//,CRect(0,0,0,0)) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_objToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC)||//,CRect(100,0,0,0)) ||
		!m_objToolBar.LoadToolBar(IDR_TOOLBAROBJ))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	m_objToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);
	DockControlBarLeftOf(&m_objToolBar,&m_wndToolBar);

	return 0;
}


void CMainFrame::DockControlBarLeftOf(CToolBar* Bar,CToolBar* LeftOf)
{
	CRect rect;
	DWORD dw;
	UINT n;

	RecalcLayout();
	LeftOf->GetWindowRect(&rect);
	rect.OffsetRect(1,0);
	dw=LeftOf->GetBarStyle();
	n = 0;
	n = (dw&CBRS_ALIGN_TOP) ? AFX_IDW_DOCKBAR_TOP : n;
	n = (dw&CBRS_ALIGN_BOTTOM && n==0) ? AFX_IDW_DOCKBAR_BOTTOM : n;
	n = (dw&CBRS_ALIGN_LEFT && n==0) ? AFX_IDW_DOCKBAR_LEFT : n;
	n = (dw&CBRS_ALIGN_RIGHT && n==0) ? AFX_IDW_DOCKBAR_RIGHT : n;

	DockControlBar(Bar,n,&rect);
}

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT /*lpcs*/,
	CCreateContext* pContext)
{
	return m_wndSplitter.Create(this,
		2, 2,               // TODO: adjust the number of rows, columns
		CSize(10, 10),      // TODO: adjust the minimum pane size
		pContext);
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

void CMainFrame::OnToolbutton() 
{
	CHtmlObjButton* o;
	o= new CHtmlObjButton;
	CHtmlObjectApp* app=(CHtmlObjectApp*)AfxGetApp();
	CState* state=app->GetState();
	state->SetInsertObj(o);
}

void CMainFrame::OnTooledit() 
{
	CHtmlObjTextEdit* o;
	o= new CHtmlObjTextEdit;
	CHtmlObjectApp* app=(CHtmlObjectApp*)AfxGetApp();
	CState* state=app->GetState();
	state->SetInsertObj(o);
}

void CMainFrame::OnToollabel() 
{
	CHtmlObjLabel* o;
	o= new CHtmlObjLabel;
	CHtmlObjectApp* app=(CHtmlObjectApp*)AfxGetApp();
	CState* state=app->GetState();
	state->SetInsertObj(o);
}

void CMainFrame::OnToolpoint() 
{
	CHtmlObjectApp* app=(CHtmlObjectApp*)AfxGetApp();
	CState* state=app->GetState();
	state->FreeInsertObj();
}

void CMainFrame::OnUpdateToolbutton(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(GetInsertObjName()==CHtmlObjButton::Name());
}

void CMainFrame::OnUpdateTooledit(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(GetInsertObjName()==CHtmlObjTextEdit::Name());
}

void CMainFrame::OnUpdateToollabel(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(GetInsertObjName()==CHtmlObjLabel::Name());
}

void CMainFrame::OnUpdateToolpoint(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(GetInsertObjName()=="");
}

CString CMainFrame::GetInsertObjName()
{
	CHtmlObjectApp* app=(CHtmlObjectApp*)AfxGetApp();
	CState* state=app->GetState();
	CHtmlObj* o=state->GetInsertObj();
	if (o==NULL){
		return "";
	}
	else{
		return o->GetName();
	};
}


void CMainFrame::OnActivateApp(BOOL bActive, HTASK hTask) 
{
	CFrameWnd::OnActivateApp(bActive, hTask);
	
	((CHtmlObjectApp*) AfxGetApp())->m_DialogProp.SetActiveWindow( );
	SetActiveWindow( );
	
}
