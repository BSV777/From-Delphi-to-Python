// HtmlObjTextEdit.cpp: implementation of the CHtmlObjTextEdit class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HtmlObject.h"
#include "HtmlObjTextEdit.h"
#include "VisualObjTextEdit.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHtmlObjTextEdit::CHtmlObjTextEdit()
{
	m_Text="TextEdit";
	m_Rect.bottom=m_Rect.top+20;
}

CHtmlObjTextEdit::~CHtmlObjTextEdit()
{
}

CString CHtmlObjTextEdit::GetName()
{
	return Name();
}

CVisualObj* CHtmlObjTextEdit::CreateVisualObject(CHtmlObjectView *parent, CRect& r)
{
	CVisualObj* o;
	o=new CVisualObjTextEdit(parent, r, this);
	return o;
}

CHtmlObj* CHtmlObjTextEdit::CreateIfMyName(CString &name)
{
	CString s=name;
	s.MakeUpper();
	if (s==Name()){
		CHtmlObj* o=new	CHtmlObjTextEdit;
		return o;
	};
	return NULL;
}

BOOL CHtmlObjTextEdit::SetText(CString &text)
{
	if(text.Find('"')<0){
		m_Text=text;
		return TRUE;
	}
	return FALSE;
}

int CHtmlObjTextEdit::SetProperty(CString propname, CString &propvalue)
{
	propname.MakeUpper();
	if(propname==PTEXT){
		SetText(propvalue);
		return ok;
	};
	if(propname==PHEIGHT){
		return ok;
	};
	return CHtmlObj::SetProperty(propname, propvalue);
}

void CHtmlObjTextEdit::GetPropertyStr(CString &s)
{
	CHtmlObj::GetPropertyStr(s);
	s.Format("%s; Text=\"%s\"",s,m_Text);
}

CString CHtmlObjTextEdit::Name()
{
	return CString("TEXTEDIT");	//��� ���������� �������
}

BOOL CHtmlObjTextEdit::SetHeight(int height)
{
	return TRUE;
}

void CHtmlObjTextEdit::GetPropertyList(CPropertyList &p)
{
	CHtmlObj::GetPropertyList(p);
	p.DeleteProperty(PHEIGHT);
	p.SetProperty(PTEXT, m_Text);
}


void CHtmlObjTextEdit::SetRect(CRect r)
{
	r.NormalizeRect();
	if((r.top>=0)&&(r.left>=0)&&(!r.IsRectEmpty())){
		r.bottom=r.top+GetHeight();
		m_Rect=r;
		ReInsertInHtmlList();
	};
}

void CHtmlObjTextEdit::WriteToHtml(CArchive *ar)
{
	CString s;
	s.Format("<INPUT value=\"%s\" style=\"width=%d; height=%d\">",m_Text,m_HtmlWidth, m_HtmlHeight);
	ar->WriteString(s);
}
