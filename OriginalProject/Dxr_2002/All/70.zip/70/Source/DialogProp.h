#if !defined(AFX_DIALOGPROP_H__2DF59996_6C6F_4AA1_B6D8_CF101DEFD810__INCLUDED_)
#define AFX_DIALOGPROP_H__2DF59996_6C6F_4AA1_B6D8_CF101DEFD810__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DialogProp.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDialogProp dialog

class CDialogProp : public CDialog
{
// Construction
public:
	BOOL m_CanSaveModifed;
	void UpdateMember();
	void SetView(CHtmlObjectView* v);
	CDialogProp(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDialogProp)
	enum { IDD = IDD_DIALOGPROP };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDialogProp)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void SetProperty();
	void ClearUpdated();
	BOOL m_ModifedCaption;
	BOOL m_ModifedText;
	BOOL m_ModifedTop;
	BOOL m_ModifedLeft;
	BOOL m_ModifedWidth;
	BOOL m_ModifedHeight;
	CHtmlObjectView* m_HtmlObjectView;

	// Generated message map functions
	//{{AFX_MSG(CDialogProp)
	afx_msg void OnChangeEditcaption();
	afx_msg void OnChangeEditheight();
	afx_msg void OnChangeEditleft();
	afx_msg void OnChangeEdittop();
	afx_msg void OnChangeEditwidth();
	afx_msg void OnChangeEdittext();
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnKillfocusEdit();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIALOGPROP_H__2DF59996_6C6F_4AA1_B6D8_CF101DEFD810__INCLUDED_)
