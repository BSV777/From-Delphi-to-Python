// Property.cpp: implementation of the CProperty class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HtmlObject.h"
#include "Property.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProperty::CProperty(LPCTSTR name, LPCTSTR value)
{
	SetProperty(name, value);
}

void CProperty::SetProperty(LPCTSTR name, LPCTSTR value)
{
	Name=name;
	Value=value;
	IsDefined=TRUE;
}
