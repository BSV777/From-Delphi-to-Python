//---------------------------------------------------------------------------

#ifndef PropertiesH
#define PropertiesH
#include "DXClasses.h"
#include "PairCollect.h"
//---------------------------------------------------------------------------
class DXSelProperties : public DXPairCollection
{
 TVProperty *VProperties;
public:
 DXSelProperties(TVProperty *VProperties);
 void Add(AnsiString AName,AnsiString AValue);
 void Clear();
// void OnPropChange(AnsiString AName,AnsiString AValue);
 void Merge(TList *Source);
// DXonPropChange OnChangeProperties;
};
class DXObjProperties : public DXPairCollection
{
public:

};
#endif
 