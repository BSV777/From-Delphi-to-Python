//---------------------------------------------------------------------------

#ifndef SelectionH
#define SelectionH
#include "DXClasses.h"
//---------------------------------------------------------------------------
class DXSelection
{
 TList *Objects;
 DXSelProperties *Properties;
public:
 DXSelection(TVProperty *AVProperties);
 ~DXSelection();
 void Clear();
 void Delete(DXObject *Object);
 void Add(DXObject *Object);
 void Move(int dX, int dY);
 void Resize(int ALeft, int ATop, int AWidth, int AHeight);
 void Replace();
 void UpdateProperties();
 void OnPropChange(AnsiString AName,AnsiString AValue);
};
#endif
 