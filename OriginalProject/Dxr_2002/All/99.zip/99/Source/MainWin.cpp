//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainWin.h"
#include "Scene.h"
#include "VScene.h"
#include "PropWin.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TWorkSpace *WorkSpace;
//---------------------------------------------------------------------------
__fastcall TWorkSpace::TWorkSpace(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TWorkSpace::FormDestroy(TObject *Sender)
{
 delete Scene;
}
//---------------------------------------------------------------------------

void __fastcall TWorkSpace::ToolButton1Click(TObject *Sender)
{
 Scene->SetTool(wtArrow);
}
//---------------------------------------------------------------------------

void __fastcall TWorkSpace::ToolButton3Click(TObject *Sender)
{
 Scene->SetTool(wtButton);
}
//---------------------------------------------------------------------------

void __fastcall TWorkSpace::ToolButton4Click(TObject *Sender)
{
 Scene->SetTool(wtLabel);
}
//---------------------------------------------------------------------------

void __fastcall TWorkSpace::ToolButton5Click(TObject *Sender)
{
  Scene->SetTool(wtEdit);
}
//---------------------------------------------------------------------------


void __fastcall TWorkSpace::FormClose(TObject *Sender,
      TCloseAction &Action)
{
 VProperty->Close();
}
//---------------------------------------------------------------------------

void __fastcall TWorkSpace::FormCreate(TObject *Sender)
{
 DXVScene *VScene = new DXVScene(ScrollBox1);
 VScene->Parent = ScrollBox1;
 VScene->Left = 0;
 VScene->Top = 0;
 VScene->Width = 2000;
 VScene->Height = 3000;

 Scene = new DXScene(VScene, VProperty);
 VScene->OnSelectionChange = Scene->SelChange;
 VScene->OnCreateObject = Scene->CreateObject;
 Scene->SetTool(wtArrow);
 if (ParamCount() == 1)
 {
   Scene->LoadFromFile(ParamStr(1));
 }
}
//---------------------------------------------------------------------------

void __fastcall TWorkSpace::New1Click(TObject *Sender)
{
 Scene->Clear();
}
//---------------------------------------------------------------------------

void __fastcall TWorkSpace::Open1Click(TObject *Sender)
{
 Scene->Clear();
 if (OpenDialog1->Execute())
 {
  Scene->LoadFromFile(OpenDialog1->FileName);
 }
}
//---------------------------------------------------------------------------

void __fastcall TWorkSpace::SaveAs1Click(TObject *Sender)
{
 if (SaveDialog1->Execute())
 {
  switch(SaveDialog1->FilterIndex)
  {
   case 1:
     Scene->ExportToFile(SaveDialog1->FileName);
     break;
   case 2:
   case 3:
     Scene->SaveToFile(SaveDialog1->FileName);
     break;
   }
 }
}
//---------------------------------------------------------------------------

void __fastcall TWorkSpace::Save1Click(TObject *Sender)
{
  if (SaveDialog1->FileName == "") SaveAs1Click(Sender);
  else
  {
  switch(SaveDialog1->FilterIndex)
  {
   case 1:
     Scene->ExportToFile(SaveDialog1->FileName);
     break;
   case 2:
   case 3:
     Scene->SaveToFile(SaveDialog1->FileName);
     break;
   }
  }
}
//---------------------------------------------------------------------------

void __fastcall TWorkSpace::Exit1Click(TObject *Sender)
{
 Application->Terminate();
}
//---------------------------------------------------------------------------

