//---------------------------------------------------------------------------

#ifndef DXClassesH
#define DXClassesH
//---------------------------------------------------------------------------
class DXScene;
class DXObject;
      class DXButton;
      class DXLabel;
      class DXEdit;
class DXParser;
class DXTag;
class DXPair;
class DXPairCollection;
      class DXProperties;
      class DXObjProperties;
      class DXTagAttributes;
      class DXSelProperties;
class DXTable;
class DXSelection;

class DXVScene;
class DXVObject;
      class DXVButton;
      class DXVLabel;
      class DXVEdit;
class TVProperty;

enum DXObjectType {otButton, otLabel, otEdit};
enum DXScanerCodes {scNull, scEndOfFile, scBeginTag, scEndTag,
     scName, scEqual, scQuote, scSemicolon, scString, scError};
enum DXCellState {csEmpty, csLeftTop, csSpan};
enum DXWorkTools {wtArrow, wtButton, wtLabel, wtEdit};

typedef void (__closure *DXonTagRead)(DXTag *Tag);
typedef void (__closure *DXonEndOfFile)(bool Result); // true - ���������� ����������
typedef void (__closure *DXonSelectionChange)(int Left, int Top, int Right, int Bottom);
typedef void (__closure *DXonSelectObject)(DXObject *Object);
typedef void (__closure *DXonCreateObject)(int Left, int Top, int Right, int Bottom, DXObjectType OType);
typedef void (__closure *DXonDrag)(int dX, int dY);//DXObject *Object);//int Left,int Top,int Width,int Height);
typedef void (__closure *DXonDrop)();
typedef void (__closure *DXonResize)(int dLeft, int dTop, int dWidth, int dHeight);
typedef void (__closure *DXonInvertSelection)();
typedef void (__closure *DXonSetSelection)();
typedef void (__closure *DXonPropChange)(AnsiString AName, AnsiString AValue);
#define AbsRect(Left,Top,Right,Bottom) Rect(min(Left,Right),min(Top,Bottom),max(Left,Right),max(Top,Bottom))

#endif
