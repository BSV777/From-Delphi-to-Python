//---------------------------------------------------------------------------

#ifndef MainWinH
#define MainWinH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "DXClasses.h"
#include <ComCtrls.hpp>
#include <ToolWin.hpp>
#include <Menus.hpp>
#include <Dialogs.hpp>
#include <ImgList.hpp>

//---------------------------------------------------------------------------
class TWorkSpace : public TForm
{
__published:	// IDE-managed Components
        TScrollBox *ScrollBox1;
        TCoolBar *CoolBar1;
        TToolBar *ToolBar1;
        TToolButton *ToolButton1;
        TToolButton *ToolButton3;
        TToolButton *ToolButton4;
        TToolButton *ToolButton5;
        TMainMenu *MainMenu1;
        TMenuItem *File1;
        TMenuItem *Exit1;
        TMenuItem *N1;
        TMenuItem *N2;
        TMenuItem *SaveAs1;
        TMenuItem *Save1;
        TMenuItem *Open1;
        TMenuItem *New1;
        TMenuItem *Edit1;
        TMenuItem *N4;
        TMenuItem *Paste1;
        TMenuItem *Copy1;
        TMenuItem *Cut1;
        TMenuItem *N5;
        TMenuItem *Repeatcommand1;
        TMenuItem *Undo1;
        TOpenDialog *OpenDialog1;
        TSaveDialog *SaveDialog1;
        TImageList *ImageList1;
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall ToolButton1Click(TObject *Sender);
        void __fastcall ToolButton3Click(TObject *Sender);
        void __fastcall ToolButton4Click(TObject *Sender);
        void __fastcall ToolButton5Click(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall New1Click(TObject *Sender);
        void __fastcall Open1Click(TObject *Sender);
        void __fastcall SaveAs1Click(TObject *Sender);
        void __fastcall Save1Click(TObject *Sender);
        void __fastcall Exit1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
 DXScene *Scene;
        __fastcall TWorkSpace(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TWorkSpace *WorkSpace;
//---------------------------------------------------------------------------
#endif
