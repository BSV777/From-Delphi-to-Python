//---------------------------------------------------------------------------

#ifndef VObjectH
#define VObjectH
#include "DXClasses.h"
//---------------------------------------------------------------------------
class DXVObject : public TCustomControl
{

 bool Draging;
 int CurX;
 int CurY;
public:
       __property Canvas;
       __property Caption;
       bool Selected;
       virtual __fastcall DXVObject(Classes::TComponent* AOwner);
       __fastcall ~DXVObject();
       virtual void __fastcall Paint();
       DYNAMIC void __fastcall MouseDown(TMouseButton Button, TShiftState Shift, int X, int Y);
       DYNAMIC void __fastcall MouseMove(TShiftState Shift, int X, int Y);
       DYNAMIC void __fastcall MouseUp(TMouseButton Button, TShiftState Shift, int X, int Y);

       DXonDrag OnDrag;
       DXonDrop OnDrop;
       DXonResize OnResize;
       DXonInvertSelection OnInvertSelection;
       DXonSetSelection OnSetSelection;

};
class DXVButton : public DXVObject
{
public:
       AnsiString Caption;
       virtual __fastcall DXVButton(Classes::TComponent* AOwner);
       virtual void __fastcall Paint();
};
class DXVLabel : public DXVObject
{
public:
       AnsiString Text;
       virtual __fastcall DXVLabel(Classes::TComponent* AOwner);
       virtual void __fastcall Paint();
};
class DXVEdit : public DXVObject
{
public:
       AnsiString Text;
       virtual __fastcall DXVEdit(Classes::TComponent* AOwner);
       virtual void __fastcall Paint();

};

#endif
