//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Properties.h"
#include "PropWin.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
DXSelProperties::DXSelProperties(TVProperty *AVProperties)
{
 VProperties = AVProperties;
}

//---------------------------------------------------------------------------
void DXSelProperties::Add(AnsiString AName,AnsiString AValue)
{
 DXPairCollection::Add(AName, AValue);
 VProperties->Add(AName, AValue);
}
//---------------------------------------------------------------------------
void DXSelProperties::Clear()
{
 DXPairCollection::Clear();
 VProperties->Clear();
}
//---------------------------------------------------------------------------

void DXSelProperties::Merge(TList *Source)
{
 int i,j;
 for (i=0; i<Source->Count; i++)
 {
     for (j=0; j<Length(); j++)
     {
      if (((DXPair*)Source->Items[i])->Name == GetName(j))
      {
       if (((DXPair*)Source->Items[i])->Value != operator[](GetName(j)))
          SetValue(GetName(j),"");
       break;
      }
     }
     if (j == Length())
        Add (((DXPair*)Source->Items[i])->Name,((DXPair*)Source->Items[i])->Value);
 }
}