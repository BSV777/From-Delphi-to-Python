//---------------------------------------------------------------------------

#ifndef PairCollectH
#define PairCollectH
//---------------------------------------------------------------------------
class DXPair
{
public:
 AnsiString Name;
 AnsiString Value;
 DXPair(AnsiString AName, AnsiString AValue)
 {
  Name = AName;
  Value = AValue;
 }
 DXPair(DXPair *APair)
 {
  Name = APair->Name;
  Value = APair->Value;
 }
};
//---------------------------------------------------------------------------
class DXPairCollection
{
 TList *Items;
public:
 bool CaseSensitive;
 DXPairCollection();
 ~DXPairCollection();
 TList *GetItems() { return Items; }
 void Add(AnsiString Name, AnsiString Value);
 void Add(DXPair *APair);
 void Clear();
 DXPair *operator[](int Index);
 AnsiString operator[](AnsiString AName);
 AnsiString GetName(int Index);
 int IndexOf(AnsiString Name);
 void SetValue(AnsiString Name, AnsiString Value);
 int Length();

};

#endif
