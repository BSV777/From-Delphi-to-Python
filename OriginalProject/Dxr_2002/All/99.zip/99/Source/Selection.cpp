//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Selection.h"
#include "Object.h"
#include "PropWin.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

DXSelection::DXSelection(TVProperty *AVProperties)
{
 Objects = new TList();
 Properties = new DXSelProperties(AVProperties);
 AVProperties->OnPropChange = OnPropChange;
}

DXSelection::~DXSelection()
{
 delete Properties;
 delete Objects;
}

void DXSelection::OnPropChange(AnsiString AName,AnsiString AValue)
{
 int i;
 for (i=0; i<Objects->Count; i++)
 {
  ((DXObject*)Objects->Items[i])->SetProperty(AName,AValue);
 }
 Replace();
}

void DXSelection::Clear()
{
 int i;
 for (i=0; i<Objects->Count; i++)
 {
  ((DXObject*)Objects->Items[i])->SetSelect(false);
 }
 Objects->Clear(); // don't delete!!!
}

void DXSelection::Delete(DXObject *Object)
{
 Objects->Remove(Object);
}

void DXSelection::Add(DXObject *Object)
{
 Objects->Add(Object);
}

void DXSelection::Move(int dX, int dY)
{
 int i;
 for (i=0; i<Objects->Count; i++)
 {
  ((DXObject*)Objects->Items[i])->Move(dX, dY);
 }
}

void DXSelection::Resize(int ALeft, int ATop, int AWidth, int AHeight)
{
 int i;
 for (i=0; i<Objects->Count; i++)
 {
  ((DXObject*)Objects->Items[i])->Resize(ALeft, ATop, AWidth, AHeight);
 }
}

void DXSelection::Replace()
{
 int i;
 for (i=0; i<Objects->Count; i++)
 {
  ((DXObject*)Objects->Items[i])->PlaceOnScene();
 }
}

void DXSelection::UpdateProperties()
{
 Properties->Clear();

 int i;
 for (i=0; i<Objects->Count; i++)
 {
  ((DXObject*)Objects->Items[i])->UpdateProperties();
  Properties->Merge(((DXObject*)Objects->Items[i])->GetProperties());
 }
}
