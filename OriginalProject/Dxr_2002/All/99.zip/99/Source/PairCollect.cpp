//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "PairCollect.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
DXPairCollection::DXPairCollection()
{
 Items = new TList();
 Items->Expand();
 CaseSensitive = false;
}

DXPairCollection::~DXPairCollection()
{
 Clear();
 delete Items;
}

void DXPairCollection::Add(AnsiString Name, AnsiString Value)
{
 Items->Add(new DXPair(Name,Value));
}

void DXPairCollection::Add(DXPair *APair)
{
 Items->Add(new DXPair(APair));
}

void DXPairCollection::Clear()
{
 int i;
 DXPair *Temp;
 for (int i=0; i < Items->Count; i++)
 {
  Temp = (DXPair*)Items->Items[i];
  delete Temp;
 }
// for (i=0; i<Items->Count; i++) delete Items->Items[i];
 Items->Clear();
}

DXPair *DXPairCollection::operator[](int Index)
{
 return (DXPair*)Items->Items[Index];
}

AnsiString DXPairCollection::operator[](AnsiString AName)
{
 int i;
 AnsiString name, attname;
 for (i=0;i<Items->Count;i++)
 {
  attname = CaseSensitive ? AName : AName.LowerCase();
  name = CaseSensitive ? ((DXPair*)Items->Items[i])->Name : ((DXPair*)Items->Items[i])->Name.LowerCase();
  if (name == attname) return ((DXPair*)Items->Items[i])->Value;
 }
 return NULL; // ���� ��� ������ ��������
}

AnsiString DXPairCollection::GetName(int Index)
{
 return ((DXPair*)Items->Items[Index])->Name;
}

int DXPairCollection::Length()
{
 return Items->Count;
}

int DXPairCollection::IndexOf(AnsiString Name)
{
 int i;
 for (i=0; i<Items->Count; i++)
     if (((DXPair*)Items->Items[i])->Name == Name) break;
 return i;
}

void DXPairCollection::SetValue(AnsiString Name, AnsiString Value)
{
 int Index = IndexOf(Name);
 if (Index == Items->Count) Items->Add(new DXPair(Name,Value));
 ((DXPair*)Items->Items[Index])->Value = Value;
}

