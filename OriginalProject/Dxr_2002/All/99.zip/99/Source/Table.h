//---------------------------------------------------------------------------

#ifndef TableH
#define TableH
#include "DXClasses.h"
//---------------------------------------------------------------------------

class DXCell
{
public:
 DXCell();
 DXCellState State;
 int RowSpan;
 int ColSpan;
 AnsiString HTMLCode;
};

class DXTable
{
 DXCell **Cells;

 int RowCount;
 int ColCount;
 int *Rows;
 int *Cols;
 int Level;

 TList *Objects;
 TFileStream *File;

 int GetRowIndex(int Y);
 int GetColIndex(int X);
 int PackData(int *Data, int Size);
 void Optimize();
 void Pack();
 void SetObjects();

 public:
 DXTable(TList *AObjects);
 ~DXTable();

 void Output(AnsiString FileName);
};
#endif
