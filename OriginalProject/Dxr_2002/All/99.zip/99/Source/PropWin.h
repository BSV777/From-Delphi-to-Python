//---------------------------------------------------------------------------

#ifndef PropWinH
#define PropWinH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "DXClasses.h"
//---------------------------------------------------------------------------
class TVProperty : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TEdit *Edit1;
        TLabel *Label2;
        TEdit *Edit2;
        TLabel *Label3;
        TEdit *Edit3;
        TLabel *Label4;
        TEdit *Edit4;
        TEdit *Edit5;
        TLabel *Label5;
        TEdit *Edit6;
        TLabel *Label6;
        void __fastcall PropChange(TObject *Sender);
        void __fastcall Edit1Change(TObject *Sender);
        void __fastcall Edit2Change(TObject *Sender);
        void __fastcall Edit3Change(TObject *Sender);
        void __fastcall Edit4Change(TObject *Sender);
        void __fastcall Edit5Change(TObject *Sender);
        void __fastcall Edit6Change(TObject *Sender);
private:	// User declarations
        int Index;
public:		// User declarations
  void Add(AnsiString AName, AnsiString AValue);
  void Clear();
  DXonPropChange OnPropChange;
        __fastcall TVProperty(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TVProperty *VProperty;
//---------------------------------------------------------------------------
#endif
