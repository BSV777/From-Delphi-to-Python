//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Object.h"
#include "Scene.h"
#include "parser.h"
#include "VObject.h"
#include "PairCollect.h"
#include "Properties.h"
#include "Selection.h"
//---------------------------------------------------------------------------

#pragma package(smart_init)
//---------------------------------------------------------------------------
DXObject::DXObject(DXScene *AScene): Scene(AScene)
{
// Properties = new TList();
 Properties = new DXObjProperties();

 Left = Top = 0;
 Width = 100;
 Height = 24;
 Selected = false;
 VObject = NULL;
}
//---------------------------------------------------------------------------
DXObject::DXObject(DXScene *AScene, DXVObject *AVObject):VObject(AVObject),Scene(AScene)
{
// DXObject::DXObject();
// Properties = new TList();
 Properties = new DXObjProperties();

 Left = Top = 0;
 Width = 100;
 Height = 24;
 Selected = false;
 VObject->OnDrag = OnDrag;
 VObject->OnDrop = OnDrop;
 VObject->OnInvertSelection = OnInvertSelection;
 VObject->OnSetSelection =OnSetSelection;
}
//---------------------------------------------------------------------------
DXObject::~DXObject()
{
// for (int i=0; i < Properties->Count; i++) delete Properties->Items[i];
 delete VObject;
 delete Properties;
}
//---------------------------------------------------------------------------
void DXObject::AddProperty(AnsiString Name, AnsiString Value)
{
// Properties->Add(new DXPair(Name,Value));
 SetProperty(Name,Value);
}
//---------------------------------------------------------------------------
void DXObject::SetProperty(AnsiString Name, AnsiString Value)
{
 AnsiString name = Name.LowerCase();
 int iValue = 0;
 bool Default = false;

 try { iValue = Value.ToInt(); }
 catch (...) { Default = true; }

 if (name == "left") Left = Default ? 0 : iValue;
 if (name == "top") Top = Default ? 0 : iValue;
 if (name == "width") Width = Default ? 100 : iValue;
 if (name == "height") Height = Default ? 24 : iValue;

 Update();
 SetProp(Name,Value);
 if (VObject) VObject->Paint();
}
//---------------------------------------------------------------------------
bool DXObject::Validate(int &left, int &top, int &width, int &height)
{
 return (left >= Left + Width || top >= Top + Height ||
        Left >= left + width || Top >= top + height);
}
//---------------------------------------------------------------------------
void DXObject::Update()
{
 if (VObject)
 {
  VObject->Left = Left;
  VObject->Top = Top;
  VObject->Width = Width;
  VObject->Height = Height;
 }
}
//---------------------------------------------------------------------------
void DXObject::PlaceOnScene()
{
 Scene->Validate(this);//Left,Top,Width,Height);
 Update();
}
//---------------------------------------------------------------------------
void DXObject::SetProp(AnsiString AName, AnsiString AValue)
{
 Properties->SetValue(AName, AValue);
}
//---------------------------------------------------------------------------
void DXObject::UpdateProperties()
{
 Update();
 SetProp("Left",IntToStr(Left));
 SetProp("Top",IntToStr(Top));
 SetProp("Width",IntToStr(Width));
 SetProp("Height",IntToStr(Height));
}
//---------------------------------------------------------------------------
void DXObject::SetSelect(bool ASel)
{
 Selected = ASel;
 VObject->Selected = Selected;
 VObject->Paint();
}

//---------------------------------------------------------------------------
void DXObject::OnInvertSelection()
{

 SetSelect(!Selected);
 if (Selected) Scene->Selection->Add(this);
 else Scene->Selection->Delete(this);

// VObject->Paint();
}
//---------------------------------------------------------------------------
void DXObject::OnSetSelection()
{
 Scene->Selection->Clear();
 OnInvertSelection();
}
//---------------------------------------------------------------------------
void DXObject::OnDrag(int dX, int dY)
{
 Scene->Selection->Move(dX, dY);
}
//---------------------------------------------------------------------------
void DXObject::OnDrop()
{
 Scene->Selection->Replace();
 Scene->Selection->UpdateProperties();
 Scene->SetTool(wtArrow);
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void DXObject::Move(int dX, int dY)
{
 Left += dX;
 Top += dY;
 VObject->Left = Left;
 VObject->Top = Top;
}
//---------------------------------------------------------------------------
void DXObject::Resize(int dLeft, int dTop, int dWidth, int dHeight)
{
 Left = dLeft;
 Top = dTop;
 Width = dWidth;
 Height = dHeight;

 VObject->Left = dLeft;
 VObject->Top = dTop;
 VObject->Width = dWidth;
 VObject->Height = dHeight;
}
//---------------------------------------------------------------------------
AnsiString DXObject::ConvSpecial(AnsiString Inp)
{
 AnsiString Out="";
 for (int i=1;i<=Inp.Length();i++)
 {
  switch (Inp[i])
  {
   case ' ': Out += "&nbsp;"; break;
   case '<': Out += "&lt;"; break;
   case '>': Out += "&gt;"; break;
   case '&': Out += "&amp;"; break;
   case '\t':
   case '\r':
   case '\n': Out += " "; break;
   default : Out += Inp[i];
  }
 }
 return Out;
}

//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\\
//                DESCENDANTS                           \\
//------------------------------------------------------\\
//---------------------------------------------------------------------------
void DXButton::SetProperty(AnsiString Name, AnsiString Value)
{
 DXObject::SetProperty(Name,Value);
 AnsiString name = Name.LowerCase();
 if (name == "caption") Caption = Value;
}
//---------------------------------------------------------------------------
void DXButton::Update()
{
 DXObject::Update();
 if (VObject) ((DXVButton*)VObject)->Caption = Caption;
}
//---------------------------------------------------------------------------
void DXButton::UpdateProperties()
{
DXObject::UpdateProperties();
 SetProp("Caption",Caption);
}
//---------------------------------------------------------------------------
AnsiString DXButton::ToHTML(int Level)
{
 AnsiString OptString;
 switch(Level)
 {
  case 1: OptString = " style='width:"+IntToStr(Width)+
          ";height:"+IntToStr(Height)+"'";
          break;
  case 2: OptString = ""; break;
 }
 return "<INPUT type=button value='" + ConvSpecial(Caption) +
        "' wiDth=" + IntToStr(Width) +
        " hEight=" + IntToStr(Height) +
        OptString + ">";
}
//---------------------------------------------------------------------------
AnsiString DXButton::ToStr()
{
 return "<Button Left=\"" + IntToStr(Left) + "\"; Top=\"" + IntToStr(Top) +
        "\"; Width=\"" + IntToStr(Width) + "\"; Height=\"" + IntToStr(Height) +
        "\"; Text=\"" + Caption + "\">\r\n";
}
//---------------------------------------------------------------------------
void DXLabel::SetProperty(AnsiString Name, AnsiString Value)
{
 DXObject::SetProperty(Name,Value);
 AnsiString name = Name.LowerCase();
 if (name == "text") Text = Value;
}
//---------------------------------------------------------------------------
void DXLabel::Update()
{
DXObject::Update();
 if (VObject) ((DXVLabel*)VObject)->Text = Text;
}
//---------------------------------------------------------------------------
void DXLabel::UpdateProperties()
{
DXObject::UpdateProperties();
 SetProp("Text",Text);
}
//---------------------------------------------------------------------------
AnsiString DXLabel::ToHTML(int Level)
{
 return "<DIV>" + ConvSpecial(Text) + "</DIV>";
}
//---------------------------------------------------------------------------
AnsiString DXLabel::ToStr()
{
 return "<Label Left=\"" + IntToStr(Left) + "\"; Top=\"" + IntToStr(Top) +
        "\"; Width=\"" + IntToStr(Width) + "\"; Height=\"" + IntToStr(Height) +
        "\"; Text=\"" + Text + "\">\r\n";
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void DXEdit::SetProperty(AnsiString Name, AnsiString Value)
{
 DXObject::SetProperty(Name,Value);
 AnsiString name = Name.LowerCase();
 if (name == "text") Text = Value;
 Height = 24;
}
//---------------------------------------------------------------------------
void DXEdit::Update()
{
DXObject::Update();
 if (VObject) ((DXVEdit*)VObject)->Text = Text;
}
//---------------------------------------------------------------------------
void DXEdit::UpdateProperties()
{
DXObject::UpdateProperties();
 SetProp("Text",Text);
}
//---------------------------------------------------------------------------
AnsiString DXEdit::ToHTML(int Level)
{
 AnsiString OptString;
 switch(Level)
 {
  case 1: OptString = " style='width:"+IntToStr(Width)+
          ";height:"+IntToStr(Height)+"'";
          break;
  case 2: OptString = ""; break;
 }
 return "<INPUT type=text value='" + ConvSpecial(Text) +
        "' wiDth=" + IntToStr(Width) +
        " hEight=" + IntToStr(Height) +
        OptString + ">";
}
//---------------------------------------------------------------------------
AnsiString DXEdit::ToStr()
{
 return "<Edit Left=\"" + IntToStr(Left) + "\"; Top=\"" + IntToStr(Top) +
        "\"; Width=\"" + IntToStr(Width) + "\"; Text=\"" + Text + "\">\r\n";
}


