//---------------------------------------------------------------------------

#ifndef SceneH
#define SceneH

#include "DXClasses.h"
#include "PropWin.h"

//---------------------------------------------------------------------------
class DXScene
{
 TList *Objects;
 int Width;
 int Height;
 bool Async;

 DXParser *Parser;
 DXVScene *VScene;

 int *ObjectCounters;
 int TypeCount;

 void Read(DXTag *Tag);
public:
 DXScene();
 DXScene(DXVScene *AVScene, TVProperty *AVProperties);
 ~DXScene();

 DXSelection *Selection;

 void LoadFromFile(AnsiString FileName);
 void SaveToFile(AnsiString FileName);
 void ExportToFile(AnsiString FileName);
 void Clear();
 void Validate(DXObject *Object);//int &Left, int &Top, int &Width, int &Height);
 void SelChange(int Left, int Top, int Width, int Height);
 void CreateObject(int Left, int Top, int Right, int Bottom, DXObjectType Type);
 void DropSelection(DXObject *Object);//int Left,int Top,int Width,int Height);
 void SetTool(DXWorkTools ATool);
};
#endif
