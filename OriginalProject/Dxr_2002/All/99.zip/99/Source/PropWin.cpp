//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "PropWin.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TVProperty *VProperty;
//---------------------------------------------------------------------------
__fastcall TVProperty::TVProperty(TComponent* Owner)
        : TForm(Owner)
{
Index = 0;
}
//---------------------------------------------------------------------------
void TVProperty::Add(AnsiString AName, AnsiString AValue)
{
 Index ++;
 if (AName == "Left") Edit1->Text = AValue;
 if (AName == "Top") Edit2->Text = AValue;
 if (AName == "Width") Edit3->Text = AValue;
 if (AName == "Height") Edit4->Text = AValue;
 if (AName == "Caption") Edit5->Text = AValue;
 if (AName == "Text") Edit6->Text = AValue;
}

void __fastcall TVProperty::PropChange(TObject *Sender)
{

 AnsiString Name = ((TLabel*)((TEdit*)Sender))->Caption;
 AnsiString Value = ((TEdit*)Sender)->Text;
 if (OnPropChange) OnPropChange(Name, Value);


}
//---------------------------------------------------------------------------
void TVProperty::Clear()
{
 int i;
 for (i=0; i<Index; i++)
 {
 //
 }
}
void __fastcall TVProperty::Edit1Change(TObject *Sender)
{
 AnsiString Name = Label1->Caption;
 AnsiString Value = Edit1->Text;
 if (OnPropChange) OnPropChange(Name, Value);
}
//---------------------------------------------------------------------------

void __fastcall TVProperty::Edit2Change(TObject *Sender)
{
 AnsiString Name = Label2->Caption;
 AnsiString Value = Edit2->Text;
 if (OnPropChange) OnPropChange(Name, Value);
}
//---------------------------------------------------------------------------

void __fastcall TVProperty::Edit3Change(TObject *Sender)
{
 AnsiString Name = Label3->Caption;
 AnsiString Value = Edit3->Text;
 if (OnPropChange) OnPropChange(Name, Value);
}
//---------------------------------------------------------------------------

void __fastcall TVProperty::Edit4Change(TObject *Sender)
{
 AnsiString Name = Label4->Caption;
 AnsiString Value = Edit4->Text;
 if (OnPropChange) OnPropChange(Name, Value);
}
//---------------------------------------------------------------------------

void __fastcall TVProperty::Edit5Change(TObject *Sender)
{
 AnsiString Name = Label5->Caption;
 AnsiString Value = Edit5->Text;
 if (OnPropChange) OnPropChange(Name, Value);
}
//---------------------------------------------------------------------------

void __fastcall TVProperty::Edit6Change(TObject *Sender)
{
 AnsiString Name = Label6->Caption;
 AnsiString Value = Edit6->Text;
 if (OnPropChange) OnPropChange(Name, Value);
}
//---------------------------------------------------------------------------




