//---------------------------------------------------------------------------

#include <vcl.h>
#include "parser.h"
#include "Scene.h"
#pragma hdrstop
USERES("Editor.res");
USEFORM("MainWin.cpp", WorkSpace);
USEUNIT("Scene.cpp");
USEUNIT("Selection.cpp");
USEUNIT("Parser.cpp");
USEUNIT("Object.cpp");
USEUNIT("Table.cpp");
USEUNIT("VScene.cpp");
USEUNIT("DXClasses.cpp");
USEUNIT("VObject.cpp");
USEUNIT("PairCollect.cpp");
USEUNIT("Properties.cpp");
USEFORM("PropWin.cpp", VProperty);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
// ��������������� ��� ������� ���������
 if (ParamCount() == 2)
 {
  DXScene *Scene = new DXScene();

  Scene->LoadFromFile(ParamStr(1));
  Scene->ExportToFile(ParamStr(2));

  delete Scene;
  return 0;
 }                      
//---------------------------------------------------------------------------
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TVProperty), &VProperty);
                 Application->CreateForm(__classid(TWorkSpace), &WorkSpace);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
