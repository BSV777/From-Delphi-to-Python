//---------------------------------------------------------------------------
#ifndef ObjectH
#define ObjectH
#include "DXClasses.h"
#include "Properties.h"
//---------------------------------------------------------------------------
class DXObject
{
// TList *Properties;
 DXObjProperties *Properties;
 DXScene *Scene;
 bool Selected;
public:
 int Left;
 int Top;
 int Width;
 int Height;
 DXVObject *VObject;

 DXObject(DXScene *AScene);
 DXObject(DXScene *AScene, DXVObject *AVObject);
 ~DXObject();

 bool Validate(int &left, int &top, int &width, int &height);
 void PlaceOnScene();
 void SetSelect(bool ASel);

 virtual void Move(int dX, int dY);
 virtual void Resize(int dLeft, int dTop, int dWidth, int dHeight);
 virtual void Update();

 void DropObject(DXObject *Object);
// DXonDrop OnDrop;
 void OnInvertSelection();
 void OnSetSelection();
 void OnDrag(int dX, int dY);
 void OnDrop();

 virtual void AddProperty(AnsiString Name, AnsiString Value);
 virtual void SetProperty(AnsiString Name, AnsiString Value);
 virtual void UpdateProperties();
 void SetProp(AnsiString AName, AnsiString AValue);
 TList *GetProperties(){ return Properties->GetItems(); }


 AnsiString ConvSpecial(AnsiString Inp);
 AnsiString virtual ToHTML(int Level) = 0;
 AnsiString virtual ToStr() = 0;

};
//---------------------------------------------------------------------------
class DXLabel : public DXObject
{
public:
 DXLabel(DXScene *AScene) : DXObject(AScene){}
 DXLabel(DXScene *AScene, DXVObject *AVObject) : DXObject(AScene, AVObject){}

// void AddProperty(AnsiString Name, AnsiString Value);
 virtual void SetProperty(AnsiString Name, AnsiString Value);
 void UpdateProperties();
 AnsiString Text;
 AnsiString virtual ToHTML(int Level);
  AnsiString ToStr();
 void Update();
};
//---------------------------------------------------------------------------
class DXButton : public DXObject
{
// DXVButton *VButton;
public:
 DXButton(DXScene *AScene) : DXObject(AScene){}
 DXButton(DXScene *AScene, DXVObject *AVButton) : DXObject(AScene, AVButton){}
// ~DXButton(){delete VButton;}
 virtual void SetProperty(AnsiString Name, AnsiString Value);
// void AddProperty(AnsiString Name, AnsiString Value);
 void UpdateProperties();
 AnsiString Caption;
 AnsiString ToHTML(int Level);
 AnsiString ToStr();
 void Update();
};
//---------------------------------------------------------------------------
class DXEdit : public DXObject
{
public:
 DXEdit(DXScene *AScene) : DXObject(AScene){}
 DXEdit(DXScene *AScene, DXVObject *AVObject) : DXObject(AScene, AVObject){}
 virtual void SetProperty(AnsiString Name, AnsiString Value);
// void AddProperty(AnsiString Name, AnsiString Value);
 void UpdateProperties();
 AnsiString Text;
 AnsiString virtual ToHTML(int Level);
  AnsiString ToStr();
 void Update();
};

#endif
