//---------------------------------------------------------------------------

#ifndef VSceneH
#define VSceneH
#include "DXClasses.h"
//---------------------------------------------------------------------------
class DXVScene: public TCustomControl
{
 bool Drawing;
 int CurLeft;
 int CurTop;
 int CurX;
 int CurY;

public:
//       TCanvas *Canvas;
       DXWorkTools Tool;
       __property Canvas;
       virtual __fastcall DXVScene(Classes::TComponent* AOwner);
       __fastcall ~DXVScene();

       virtual void __fastcall Paint();
       DYNAMIC void __fastcall MouseDown(TMouseButton Button, TShiftState Shift, int X, int Y);
       DYNAMIC void __fastcall MouseMove(TShiftState Shift, int X, int Y);
       DYNAMIC void __fastcall MouseUp(TMouseButton Button, TShiftState Shift, int X, int Y);

       DXonSelectionChange OnSelectionChange;
       DXonCreateObject OnCreateObject;
} ;
#endif
