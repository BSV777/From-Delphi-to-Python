//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "VScene.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
__fastcall DXVScene::DXVScene(Classes::TComponent* AOwner):TCustomControl(AOwner)
{
 Drawing = false;
 Tool = wtArrow; // ���������� - �������
 Tool = wtButton;
 Canvas->Brush->Color = clWhite;
 // �������� �������
 OnCreateObject = NULL;
 OnSelectionChange = NULL;
}

__fastcall DXVScene::~DXVScene()
{

}

void __fastcall DXVScene::Paint()
{
// Canvas->FillRect(ClientRect);
}

void __fastcall DXVScene::MouseDown(TMouseButton Button, TShiftState Shift, int X, int Y)
{
 if (Button == mbLeft)
 {
  Drawing = true;
  CurLeft = CurX = X; CurTop = CurY = Y;
  Canvas->DrawFocusRect(AbsRect(CurLeft,CurTop,X,Y));
 }
}
void __fastcall DXVScene::MouseMove(TShiftState Shift, int X, int Y)
{
 if (Drawing)
 {
    Canvas->DrawFocusRect(AbsRect(CurLeft,CurTop,CurX,CurY));
    Canvas->DrawFocusRect(AbsRect(CurLeft,CurTop,X,Y));
    CurX = X; CurY = Y;
    if (Tool == wtArrow)
       if (OnSelectionChange != NULL) OnSelectionChange(CurLeft,CurTop,X,Y);
 }
}
void __fastcall DXVScene::MouseUp(TMouseButton Button, TShiftState Shift, int X, int Y)
{
 if (Drawing)
 {
  Canvas->DrawFocusRect(AbsRect(CurLeft,CurTop,CurX,CurY));
  Drawing = false;
  switch(Tool)
  {
     case wtArrow:
       if (OnSelectionChange != NULL) OnSelectionChange(CurLeft,CurTop,X,Y);
       break;
     case wtButton:
       if (OnCreateObject != NULL) OnCreateObject(CurLeft,CurTop,X,Y,otButton);
       break;
     case wtLabel:
       if (OnCreateObject != NULL) OnCreateObject(CurLeft,CurTop,X,Y,otLabel);
       break;
     case wtEdit:
       if (OnCreateObject != NULL) OnCreateObject(CurLeft,CurTop,X,Y,otEdit);
       break;
  }
 }

}

