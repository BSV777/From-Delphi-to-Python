//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "VObject.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
__fastcall DXVObject::DXVObject(Classes::TComponent* AOwner):TCustomControl(AOwner)
{
 Draging = false;
 CurX = CurY = 0;
 Selected = false;
}

__fastcall DXVObject::~DXVObject()
{

}

void __fastcall DXVObject::MouseDown(TMouseButton Button, TShiftState Shift, int X, int Y)
{
 if (Button == mbLeft)
 {
  CurX = X;
  CurY = Y;
// ������ ��������� � ������� �����
//  bool Sel;
  if (Shift.Contains(ssShift))
  {
   if (OnInvertSelection) OnInvertSelection();
   Draging = Selected;
  }
  else
  {
   if (!Selected)
   {
    OnSetSelection();
//    OnInvertSelection(Selected);
    Selected = true;
   }
   Draging = true;
  }
 }
}

void __fastcall DXVObject::MouseMove(TShiftState Shift, int X, int Y)
{
if (Draging)
 {
  //Left = Left + (X - CurX);
  //Top = Top + (Y - CurY);
  OnDrag (X - CurX, Y - CurY);
 }

}

void __fastcall DXVObject::MouseUp(TMouseButton Button, TShiftState Shift, int X, int Y)
{
 if (Draging) Draging = false;
 //Selected = true;
 if (OnDrop != NULL) OnDrop();
 Paint();
}

void __fastcall DXVObject::Paint()
{
 if (Selected)
 {
 int H = ClientHeight;
 int W = ClientWidth;
 Canvas->Brush->Color = clBlue;
 Canvas->Pen->Color = clBlue;

 Canvas->Rectangle(0,0,4,4);
 Canvas->Rectangle(0,H-4,4,H);
 Canvas->Rectangle(W-4,0,W,4);
 Canvas->Rectangle(W-4,H-4,W,H);
 }

}
__fastcall DXVButton::DXVButton(Classes::TComponent* AOwner):DXVObject(AOwner)
{

}

void __fastcall DXVButton::Paint()
{
 Canvas->Brush->Color = clBtnFace;
 Canvas->Rectangle(0,0,ClientWidth,ClientHeight);
 Canvas->TextRect (Rect(0,0,ClientWidth,ClientHeight),
                  (ClientWidth - Canvas->TextWidth(Caption)) / 2,
                  (ClientHeight - Canvas->TextHeight(Caption)) /2, Caption);

 Canvas->Pen->Width = 2;
 Canvas->Pen->Color = clBtnHighlight;
 Canvas->MoveTo(0,ClientHeight-1);
 Canvas->LineTo(0,0);
 Canvas->LineTo(ClientWidth-1,0);
 Canvas->Pen->Color = clBtnShadow;
 Canvas->LineTo(ClientWidth-1,ClientHeight-1);
 Canvas->LineTo(0,ClientHeight-1);
 DXVObject::Paint();
}

__fastcall DXVLabel::DXVLabel(Classes::TComponent* AOwner):DXVObject(AOwner)
{

}

void __fastcall DXVLabel::Paint()
{
 Canvas->Brush->Color = clBtnFace;
 Canvas->Rectangle(0,0,ClientWidth,ClientHeight);
 Canvas->TextRect (Rect(0,0,ClientWidth,ClientHeight),0,0,Text);
 DXVObject::Paint();
}
__fastcall DXVEdit::DXVEdit(Classes::TComponent* AOwner):DXVObject(AOwner)
{

}

void __fastcall DXVEdit::Paint()
{
 Canvas->Brush->Color = clWhite;
 Canvas->Rectangle(0,0,ClientWidth,ClientHeight);
 Canvas->TextRect (Rect(0,0,ClientWidth,ClientHeight),4,
                  (ClientHeight - Canvas->TextHeight(Text)) /2,Text);

 Canvas->Pen->Width = 2;
 Canvas->Pen->Color = cl3DDkShadow;
 Canvas->MoveTo(0,ClientHeight-1);
 Canvas->LineTo(0,0);
 Canvas->LineTo(ClientWidth-1,0);
 Canvas->Pen->Color = cl3DLight;
 Canvas->LineTo(ClientWidth-1,ClientHeight-1);
 Canvas->LineTo(0,ClientHeight-1);

 DXVObject::Paint();
}
