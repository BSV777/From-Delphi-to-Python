using System;
using System.Windows.Forms;
using System.Drawing;
using System.Collections;

namespace Amba.VEdit.GUI
{
    public class VESelectedControlCollection : CollectionBase
    {
        private VEControl _ActiveControl;
        
        public VEControl ActiveControl
        {
            get {return _ActiveControl;}
            set {
                if (_ActiveControl != null) _ActiveControl.Active = false;
                _ActiveControl = value;
                if (_ActiveControl != null) _ActiveControl.Active = true;
            }
        }
        
        public int Add(VEControl ctrlToAdd)
        {
            ActiveControl = ctrlToAdd;
            return base.List.Add(ctrlToAdd);
        }
        
        public void Remove(VEControl ctrl)
        {
            base.List.Remove(ctrl);
            if (ctrl == ActiveControl) {
                if (Count != 0) { 
                    ActiveControl = this[0];
                } else {
                    ActiveControl = null;
                }
            }
        }
        
        public bool Contains(VEControl ctrl)
        {
            return base.List.Contains(ctrl);
        }
        
        public VEControl this[int index]
        {
            get{
                return (VEControl)base.List[index];
            }
        }
        
        protected override void OnClear()
        {
            foreach (VEControl ctrl in this){
                ctrl.Selected = false;
            }
            ActiveControl = null;
        }
        
        public void Sort(IComparer comparer)
        {
            InnerList.Sort(comparer);
        }
        
        public static IComparer SortByXCoord
        {
            get {
                return  ((IComparer) new SortByXCoordClass());
            }
        }
        
        private class SortByXCoordClass: IComparer
        {
            public int Compare(object obj1, object obj2)
            {
                VEControl ctrl1 = (VEControl) obj1;
                VEControl ctrl2 = (VEControl) obj2;
                return ( ((Int32) ctrl1.Left).CompareTo(ctrl2.Left));
            }
        }
        
        public static IComparer SortByYCoord
        {
            get {
                return  ((IComparer) new SortByYCoordClass());
            }
        }

        private class SortByYCoordClass: IComparer
        {
            public int Compare(object obj1, object obj2)
            {
                VEControl ctrl1 = (VEControl) obj1;
                VEControl ctrl2 = (VEControl) obj2;
                return ( ((Int32) ctrl1.Top).CompareTo(ctrl2.Top));
            }
        }
    }
}
