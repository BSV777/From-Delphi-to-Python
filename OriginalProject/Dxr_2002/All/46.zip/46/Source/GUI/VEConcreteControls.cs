using System;
using System.Windows.Forms;
using System.Drawing;
using System.ComponentModel;

using Amba.VEdit.Base;

namespace Amba.VEdit.GUI
{
    public class VEButton : Amba.VEdit.GUI.VEControl
    {
        public VEButton(ControlBase ctrl, string text, int left, int top, int width, int height):
            base(ctrl, text, left, top, width, height) 
            {
                _TextFormat.Alignment = System.Drawing.StringAlignment.Center;
            }
            
        protected override void DrawControl(System.Drawing.Graphics graphics)
        {
            System.Windows.Forms.ControlPaint.DrawButton(
                graphics,
                ClientRectangle,
                System.Windows.Forms.ButtonState.Normal);
            base.DrawText(graphics);
        }
        
        [VEBrowsable(),
        Category("Labeling"),
        Description("Text of the button caption")]
        public string Caption
        {
            get {return base.Text;}
            set {
                base.Text = value;
                Invalidate();
            }
        }
    }
    
    public class VETextEdit : Amba.VEdit.GUI.VEControl
    {
        public VETextEdit(ControlBase ctrl, string text, int left, int top, int width, int height):
            base(ctrl, text, left, top, width, height){}
            
        protected override void DrawControl(System.Drawing.Graphics graphics)
        {
            System.Drawing.SolidBrush backBrush =
                new SolidBrush(System.Drawing.Color.FromKnownColor(KnownColor.Window));
            graphics.FillRectangle(backBrush, DisplayRectangle);
            System.Windows.Forms.ControlPaint.DrawBorder3D(
                graphics,
                ClientRectangle,
                System.Windows.Forms.Border3DStyle.Sunken);
            base.DrawText(graphics);
        }
        
        [VEBrowsable(),
        Category("Labeling"),
        Description("Text in Editbox")]
        new public string Text
        {
            get {return base.Text;}
            set {
                base.Text = value;
                Invalidate();
            }
        }
        
        public override int Height
        {
            get {return base.Height;}
            set {base.Height = ControlBase.DefaultHeight;}
        }
    }
    
    public class VELabel : Amba.VEdit.GUI.VEControl
    {
        public VELabel(ControlBase ctrl, string text, int left, int top, int width, int height):
            base(ctrl, text, left, top, width, height)
        {
            _TextFormat.LineAlignment = System.Drawing.StringAlignment.Near;
        }
            
        protected override void DrawControl(System.Drawing.Graphics graphics)
        {
            System.Drawing.SolidBrush backBrush =
                new SolidBrush(System.Drawing.Color.FromKnownColor(KnownColor.Window));
            graphics.FillRectangle(backBrush, DisplayRectangle);
            System.Windows.Forms.ControlPaint.DrawBorder(
                graphics,
                ClientRectangle,
                Color.Black,
                System.Windows.Forms.ButtonBorderStyle.Dotted);
            base.DrawText(graphics);
        }
        
        [VEBrowsable(),
        Category("Labeling"),
        Description("Label text")]
        new public string Text
        {
            get {return base.Text;}
            set {
                base.Text = value;
                Invalidate();
            }
        }
    }
}
