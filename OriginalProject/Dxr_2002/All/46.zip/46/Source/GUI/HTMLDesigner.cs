using System;
using System.ComponentModel;
using System.Windows.Forms;
using System.Drawing;

using Amba.VEdit.Base;

namespace Amba.VEdit.GUI
{
    public class CCCEventArgs : EventArgs
    {
        private Control _ActiveControl;

        public CCCEventArgs(Control ctrl)
        {
            _ActiveControl = ctrl;
        }

        public Control ActiveControl
        {
            get { return _ActiveControl;}
        }
    }

    public class HTMLDesigner : UserControl{
        
        private System.ComponentModel.Container _Components;
        private Amba.VEdit.Base.Workspace _Workspace;
        private bool _MultiSelectMode = false;
        private VESelectedControlCollection _SelectedControls = new VESelectedControlCollection();
        
        public HTMLDesigner()
        {
            InitializeComponent();
            AutoScroll = true;
        }

        protected override void Dispose(bool disposing) 
        {
            if (disposing) {
                if (_Components != null) {
                    _Components.Dispose();
                }
            }
            base.Dispose(disposing);
        }
        
        private void InitializeComponent ()
        {
            _Components = new System.ComponentModel.Container ();
            base.Font = new Font(FontFamily.GenericSansSerif, 10f);
            _Workspace = new Amba.VEdit.Base.Workspace();
        }
            
        public delegate void CCCEventHandler(object sender, CCCEventArgs e);
        
        public event CCCEventHandler CurrentControlChanged;
                
        protected virtual void OnCurrentControlChanged(CCCEventArgs e)
        {
            if (CurrentControlChanged != null){
                CurrentControlChanged(this, e);
            }
        }
        
        [VEBrowsable(),
        Category("Form"),
        Description("Size of creating Form")]
        public Size WorkspaceSize
        {
            get {return _Workspace.EntireArea;}
            set {
                _Workspace.EntireArea = value;
                Invalidate();
            }
        }
        
        [VEBrowsable(),
        Category("Form"),
        Description("Just Text")]
        public override string Text
        {
            get {return "HTML Form Editor";}
        }

        protected override void OnPaint(PaintEventArgs pea)
        {
            base.OnPaint(pea);
            System.Drawing.SolidBrush backBrush;
            backBrush = new SolidBrush(System.Drawing.Color.FromKnownColor(KnownColor.Control));
            pea.Graphics.FillRectangle(backBrush, DisplayRectangle);
            backBrush = new SolidBrush(System.Drawing.Color.FromKnownColor(KnownColor.Window));
            pea.Graphics.FillRectangle(backBrush, new RectangleF(0, 0, _Workspace.EntireArea.Width, _Workspace.EntireArea.Height));
        }
        
        public void ControlClick(VEControl ctrl)
        {
            if (ctrl.Selected) {
                if (_SelectedControls.Contains(ctrl)){
                    _SelectedControls.ActiveControl = ctrl;
                } else {
                    if (!_MultiSelectMode) {
                        _SelectedControls.Clear();
                    } 
                    _SelectedControls.Add(ctrl);
                }
            } else {
                if (_SelectedControls.Contains(ctrl)){
                    _SelectedControls.Remove(ctrl);
                } 
            }
            if (_SelectedControls.ActiveControl != null){
                _SelectedControls.ActiveControl.BringToFront();
                ActiveControl = _SelectedControls.ActiveControl;
                OnCurrentControlChanged(new CCCEventArgs(_SelectedControls.ActiveControl));
            } else OnCurrentControlChanged(new CCCEventArgs(this));
        }
        
        public void ChangeMode()
        {
            _MultiSelectMode = !_MultiSelectMode;
            if (!_MultiSelectMode){
                VEControl curentlySelected = _SelectedControls.ActiveControl;
                if (curentlySelected != null){
                    _SelectedControls.Clear();
                    curentlySelected.Selected = true;
                    _SelectedControls.Add(curentlySelected);
                }
            }
        }
        
        public void DeleteSelectedControls()
        {
            foreach (VEControl ctrl in _SelectedControls) {
                _Workspace.RemoveControl(ctrl.ModelControl);
                Controls.Remove(ctrl);
            }
            _SelectedControls.Clear();
            OnCurrentControlChanged(new CCCEventArgs(this));
            GC.Collect();
            Invalidate();
        }
        
        public void SetSameWidth()
        {
            foreach (VEControl ctrl in _SelectedControls) {
                try{
                    ctrl.Width = _SelectedControls.ActiveControl.Width;
                } catch(InvalidBoundsException) {}
            }        
        }
        
        public void SetSameHeight()
        {
            foreach (VEControl ctrl in _SelectedControls) {
                try{
                    ctrl.Height = _SelectedControls.ActiveControl.Height;
                } catch(InvalidBoundsException) {}
            }
        }
        
        public void SetSameLeft()
        {
            foreach (VEControl ctrl in _SelectedControls) {
                try{
                    ctrl.Left = _SelectedControls.ActiveControl.Left;
                } catch(InvalidBoundsException) {}
            }
        }
        
        public void SetSameTop()
        {
            foreach (VEControl ctrl in _SelectedControls) {
                try{
                    ctrl.Top = _SelectedControls.ActiveControl.Top;
                } catch(InvalidBoundsException) {}
            }
        }
        
        public void SetSameHorSpace()
        {
            if (_SelectedControls.Count < 3) return;
            _SelectedControls.Sort(VESelectedControlCollection.SortByXCoord);
            int sumWidths = 0;
            foreach (VEControl ctrl in _SelectedControls) sumWidths += ctrl.Width;
            int confine = _SelectedControls[_SelectedControls.Count-1].Left + 
                _SelectedControls[_SelectedControls.Count-1].Width - 
                _SelectedControls[0].Left;
            if (sumWidths < confine){
                int space = (int)((confine - sumWidths)/(_SelectedControls.Count-1));
                for (int index = 1; index < _SelectedControls.Count; index++){
                    try{
                        _SelectedControls[index].Left = 
                            _SelectedControls[index-1].Left + 
                            _SelectedControls[index-1].Width + space;
                    } catch(InvalidBoundsException) {}
                }
            }
        }
        
        public void SetSameVertSpace()
        {
            if (_SelectedControls.Count < 3) return;
            _SelectedControls.Sort(VESelectedControlCollection.SortByYCoord);
            int sumHeights = 0;
            foreach (VEControl ctrl in _SelectedControls) sumHeights += ctrl.Height;
            int confine = _SelectedControls[_SelectedControls.Count-1].Top +
                _SelectedControls[_SelectedControls.Count-1].Height -
                _SelectedControls[0].Top;
            if (sumHeights < confine){
                int space = (int)((confine - sumHeights)/(_SelectedControls.Count-1));
                for (int index = 1; index < _SelectedControls.Count; index++){
                    try{
                        _SelectedControls[index].Top = 
                            _SelectedControls[index-1].Top + 
                            _SelectedControls[index-1].Height + space;
                    } catch(InvalidBoundsException) {}
                }
            }
        }
        
        public void AddButton()
        {
            int index = _Workspace.AddControl(new Amba.VEdit.Base.DMButton(
                    0,
                    0,
                    ControlBase.DefaultWidth,
                    ControlBase.DefaultHeight,
                    "Button"));
            _Workspace.ControlAtIndex(index).OnCheckBounds = 
                new Amba.VEdit.Base.CheckControlDelegate(_Workspace.CheckControlValid);
            AddVEControl(_Workspace.ControlAtIndex(index).CreateVEControl());
        }
        
        public void AddTextEdit()
        {
            int index = _Workspace.AddControl(new Amba.VEdit.Base.DMTextEdit(
                    0,
                    0,
                    ControlBase.DefaultWidth,
                    "TextEdit"));
            _Workspace.ControlAtIndex(index).OnCheckBounds = 
                new Amba.VEdit.Base.CheckControlDelegate(_Workspace.CheckControlValid);
            AddVEControl(_Workspace.ControlAtIndex(index).CreateVEControl());
        }
        
        public void AddLabel()
        {
            int index = _Workspace.AddControl(new Amba.VEdit.Base.DMLabel(
                    0,
                    0,
                    ControlBase.DefaultWidth,
                    ControlBase.DefaultHeight,
                    "Label"));
            _Workspace.ControlAtIndex(index).OnCheckBounds = 
                new Amba.VEdit.Base.CheckControlDelegate(_Workspace.CheckControlValid);
            AddVEControl(_Workspace.ControlAtIndex(index).CreateVEControl());
        }
        
        private void AddVEControl(VEControl ctrlVE)
        {
            Controls.Add(ctrlVE);
            ctrlVE.Left += 0;
            ctrlVE.Top += 0;
            ctrlVE.OnControlClick= new OnControlClickDelegate(ControlClick);
            ctrlVE.Invalidate();
        }
        
        
        public void LoadFromFile(string fileName)
        {
            Cursor = Cursors.WaitCursor;
            try {
                int countLoaded = _Workspace.Load(fileName);
                for (int index = _Workspace.ControlsCount-countLoaded; index < _Workspace.ControlsCount; index++){
                    AddVEControl(_Workspace.ControlAtIndex(index).CreateVEControl());
                }
            } catch (Exception){
            }
            Invalidate();
            Cursor = Cursors.Default;
        }
        
        public void SaveToFile(string fileName)
        {
            Cursor = Cursors.WaitCursor;
            try {
                _Workspace.Save(fileName);
            } catch (Exception){
            }
            Cursor = Cursors.Default;
        }
        
        public void ExportToHTMLFile(string fileName)
        {
            Cursor = Cursors.WaitCursor;
            try {
                _Workspace.Save2HTML(fileName);
            } catch (Exception){
            }
            Cursor = Cursors.Default;
        }
    }
}
