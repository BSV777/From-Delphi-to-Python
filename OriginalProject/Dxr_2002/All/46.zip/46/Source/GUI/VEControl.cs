using System;
using System.Windows.Forms;
using System.Drawing;

using Amba.VEdit.Base;

namespace Amba.VEdit.GUI
{
    public delegate void OnControlClickDelegate(VEControl ctrl);

    [AttributeUsage(AttributeTargets.Property)]
    public class VEBrowsableAttribute : System.Attribute 
    {
        public  VEBrowsableAttribute(): base(){  }
    }
    
    public abstract class VEControl : System.Windows.Forms.Control
    {
        private enum SideHandle {NWHandle, NHandle, NEHandle, EHandle, SEHandle, SHandle, SWHandle, WHandle, NoneHandle};
        
        protected System.Drawing.StringFormat _TextFormat = new StringFormat();
        private Amba.VEdit.Base.ControlBase _ModelControl;
        private bool _Resized = false;
        private bool _Moved = false;
        private bool _Selected = false;
        private bool _Active = false;
        private SideHandle _ResizedHandle = SideHandle.NoneHandle;
        private Point _StartPoint;
        private const float HandleSize = 8.0f;

        public OnControlClickDelegate OnControlClick;
        
        public VEControl(ControlBase ctrl, string text, int left, int top, int width, int height):
            base(text, left, top, width, height)
        {
            _TextFormat.Alignment = System.Drawing.StringAlignment.Near;
            _TextFormat.LineAlignment = System.Drawing.StringAlignment.Center;
            _ModelControl = ctrl;
        }
        
        protected void DrawText(System.Drawing.Graphics graphics)
        {
            graphics.DrawString(Text, Parent.Font, new SolidBrush(ForeColor), DisplayRectangle, _TextFormat);
        }
        
        protected virtual void DrawControl(System.Drawing.Graphics graphics)
        {
        }
        
        private SideHandle WhichHandle(int x, int y)
        {
            if (HandleRect(SideHandle.NWHandle).Contains(x, y)) return SideHandle.NWHandle;
            if (HandleRect(SideHandle.NHandle).Contains(x, y)) return SideHandle.NHandle;
            if (HandleRect(SideHandle.NEHandle).Contains(x, y)) return SideHandle.NEHandle;
            if (HandleRect(SideHandle.EHandle).Contains(x, y)) return SideHandle.EHandle;
            if (HandleRect(SideHandle.SEHandle).Contains(x, y)) return SideHandle.SEHandle;
            if (HandleRect(SideHandle.SHandle).Contains(x, y)) return SideHandle.SHandle;
            if (HandleRect(SideHandle.SWHandle).Contains(x, y)) return SideHandle.SWHandle;
            if (HandleRect(SideHandle.WHandle).Contains(x, y)) return SideHandle.WHandle;
            return SideHandle.NoneHandle;
        }

        private RectangleF HandleRect(SideHandle side)
        {
            RectangleF rect;
            switch (side) {
                case SideHandle.NWHandle : 
                    rect =  new RectangleF(0, 0, HandleSize, HandleSize);
                    break;
                case SideHandle.NHandle : 
                    rect =  new RectangleF(Width/2-HandleSize/2, 0, HandleSize, HandleSize);
                    break;
                case SideHandle.NEHandle :
                    rect =  new RectangleF(Width-HandleSize, 0, HandleSize, HandleSize);
                    break;
                case SideHandle.EHandle :
                    rect =  new RectangleF(Width-HandleSize, Height/2-HandleSize/2, HandleSize, HandleSize);
                    break;
                case SideHandle.SEHandle :
                    rect =  new RectangleF(Width-HandleSize, Height-HandleSize, HandleSize, HandleSize);
                    break;
                case SideHandle.SHandle :
                    rect =  new RectangleF(Width/2-HandleSize/2, Height-HandleSize, HandleSize, HandleSize);
                    break;
                case SideHandle.SWHandle : 
                    rect =  new RectangleF(0, Height-HandleSize, HandleSize, HandleSize);
                    break;
                case SideHandle.WHandle :
                    rect =  new RectangleF(0, Height/2-HandleSize/2, HandleSize, HandleSize);
                    break;
                default : //SideHandle.NoneHandle
                    rect = new RectangleF(0, 0, 0, 0);
                    break;
            }
            return rect;
        }
        
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            DrawControl(e.Graphics);
            if (_Selected){
                System.Drawing.SolidBrush blackBrush = (_Active) ? new SolidBrush(Color.Black) : new SolidBrush(Color.Gray);
                RectangleF[] rects = 
                {
                    HandleRect(SideHandle.NWHandle),
                    HandleRect(SideHandle.NHandle),
                    HandleRect(SideHandle.NEHandle),
                    HandleRect(SideHandle.EHandle),
                    HandleRect(SideHandle.SEHandle),
                    HandleRect(SideHandle.SHandle),
                    HandleRect(SideHandle.SWHandle),
                    HandleRect(SideHandle.WHandle)
                 };
                e.Graphics.FillRectangles(blackBrush, rects);
            }
        }
        
        protected override void OnMouseMove(MouseEventArgs mea)
        {
            base.OnMouseMove(mea);
            if (!_Selected) {
                Cursor = Cursors.Default;
                return;
            }
            if (!_Resized && !_Moved) {
                switch (WhichHandle(mea.X, mea.Y)){
                    case SideHandle.NWHandle :
                        goto case SideHandle.SEHandle;
                    case SideHandle.SEHandle :
                        Cursor = Cursors.SizeNWSE;
                        break;
                    case SideHandle.NHandle :
                        goto case SideHandle.SHandle;
                    case SideHandle.SHandle:
                        Cursor = Cursors.SizeNS;
                        break;
                    case SideHandle.NEHandle :
                        goto case SideHandle.SWHandle;
                    case SideHandle.SWHandle :    
                        Cursor = Cursors.SizeNESW;
                        break;
                    case SideHandle.EHandle :
                        goto case SideHandle.WHandle;
                    case SideHandle.WHandle :
                        Cursor = Cursors.SizeWE;
                        break;
                    default: 
                        Cursor = Cursors.Default;
                        break;
                }
            } else {
                Point curPoint = new Point(mea.X, mea.Y);
                if (_Resized){
                    if ((_ResizedHandle == SideHandle.NWHandle) ||
                        (_ResizedHandle == SideHandle.NHandle) ||
                        (_ResizedHandle == SideHandle.NEHandle)) {
                            Top = Top + curPoint.Y;
                            Height = Height - curPoint.Y;
                    }
                    if ((_ResizedHandle == SideHandle.NEHandle) ||
                        (_ResizedHandle == SideHandle.EHandle) ||
                        (_ResizedHandle == SideHandle.SEHandle)) {
                            Width = curPoint.X;
                    }
                    if ((_ResizedHandle == SideHandle.SEHandle) ||
                        (_ResizedHandle == SideHandle.SHandle) ||
                        (_ResizedHandle == SideHandle.SWHandle)) {
                            Height = curPoint.Y;
                    }
                    if ((_ResizedHandle == SideHandle.SWHandle) ||
                        (_ResizedHandle == SideHandle.WHandle) ||
                        (_ResizedHandle == SideHandle.NWHandle)) {
                            Left = Left + curPoint.X;
                            Width = Width - curPoint.X;
                    }
                } else {
                    Top = Top + curPoint.Y - _StartPoint.Y;
                    Left = Left + curPoint.X - _StartPoint.X;
                }
                Invalidate();
            }
        }
        
        protected override void OnMouseDown(MouseEventArgs mea)
        {
            base.OnMouseDown(mea);
            Selected = (mea.Button == MouseButtons.Left);
            if (OnControlClick != null) OnControlClick(this);
            if (Selected){
                _ResizedHandle = WhichHandle(mea.X, mea.Y);
                _Resized = (_ResizedHandle != SideHandle.NoneHandle);
                _Moved = (_ResizedHandle == SideHandle.NoneHandle);
                if (_Moved) Cursor = Cursors.Hand;
                _StartPoint = new Point(mea.X, mea.Y);
            }
            Invalidate();
        }
        
        private void ResetBounds()
        {
            Left = _ModelControl.Left;
            Top = _ModelControl.Top;
            Width = _ModelControl.Width;
            Height = _ModelControl.Height;
        }
        
        protected override void OnMouseUp(MouseEventArgs mea)
        {
            base.OnMouseUp(mea);
            if (_Resized || _Moved) {
                try{
                    _ModelControl.SetBounds(new Rectangle(Left, Top, Width, Height));
                } catch (InvalidBoundsException) { 
                    ResetBounds();
                } catch (IntersectionException) { 
                    ResetBounds();
                }
                _Resized = false;
                _Moved = false;
                Cursor = Cursors.Default;
            }
            Invalidate();
        }
        
        public Amba.VEdit.Base.ControlBase ModelControl
        {
            get {return _ModelControl;}
        }

        public bool Selected
        {
            get {return _Selected;}
            set {
                _Selected = value;
                Invalidate();
            }
        }
        
        public bool Active
        {
            get {return _Active;}
            set {
                _Active = value;
                Invalidate();
            }
        }
        
       new public string Text
        {
            get {return base.Text;}
            set {
                 _ModelControl.TextStr = value;
                 base.Text = value;
            }
        }
        
        [VEBrowsable()]
        new public virtual int Left
        {
            get 
            {
                if (_Moved || _Resized){
                   if (Parent != null) {
                        return base.Left - Parent.DisplayRectangle.Left;
                    } else{
                        return base.Left;
                    }
                }
                return _ModelControl.Left;
            }
            set 
            {
                try {
                    if (!_Moved && !_Resized) {
                        _ModelControl.Left = value;
                    }
                    if (Parent != null) {
                        if (_Moved || _Resized) {
                            try {
                                _ModelControl.OnCheckBounds(_ModelControl,  new Rectangle(value, _ModelControl.Top, _ModelControl.Width, _ModelControl.Height));
                            } catch (InvalidBoundsException) {
                                return;
                            } catch (IntersectionException) {
                            }
                        }
                        base.Left = value + Parent.DisplayRectangle.Left;
                    } else{
                        base.Left = value;
                    }
                } catch (InvalidBoundsException) {
                } catch (IntersectionException) { 
                }
                Invalidate();
            }
        }
        
        [VEBrowsable()]
        new public virtual int Top
        {
            get 
            {
                if (_Moved || _Resized){
                   if (Parent != null) {
                        return base.Top - Parent.DisplayRectangle.Top;
                    } else{
                        return base.Top;
                    }
                }
                return _ModelControl.Top;
            }
            set {
                try {
                    if (!_Moved && !_Resized) {
                        _ModelControl.Top = value;
                    }
                    if (Parent != null) {
                        if (_Moved || _Resized) {
                            try {
                                _ModelControl.OnCheckBounds(_ModelControl,  new Rectangle(_ModelControl.Left, value, _ModelControl.Width, _ModelControl.Height));
                            } catch (InvalidBoundsException) {
                                return;
                            } catch (IntersectionException) {
                            }
                        }
                        base.Top = value + Parent.DisplayRectangle.Top;
                    } else{
                        base.Top = value;
                    }
                } catch (InvalidBoundsException) {
                } catch (IntersectionException) {
                }
                Invalidate();
            }
        }
        
        [VEBrowsable()]
        new public virtual int Width
        {
            get {return base.Width;}
            set {
                try {
                    _ModelControl.Width = value;
                    base.Width = value;
                } catch (InvalidBoundsException) {
                } catch (IntersectionException){
                }
                if (base.Width < HandleSize) base.Width = (int)HandleSize;
                Invalidate();
            }
        }
        
        [VEBrowsable()]
        new public virtual int Height
        {
            get {return base.Height;}
            set {
                try {
                    _ModelControl.Height = value;
                    base.Height = value;
                } catch (InvalidBoundsException) {
                } catch (IntersectionException){
                }
                if (base.Height < HandleSize) base.Height = (int)HandleSize;
                Invalidate();
            }
        }
    }
}
