using System;
using System.Drawing;

using Amba.VEdit.GUI;

namespace Amba.VEdit.Base
{
    public class DMButton: ControlBase
    {
        public DMButton(int x, int y, int width, int height, string text) :
            base(x, y, width, height, text) {}
        
        public string Caption
        {
            get {return TextStr;}
            set {TextStr = value;}
        }
        
        protected override string GetHTMLTag()
        {
            System.Drawing.StringFormat strFormat = new StringFormat();
            strFormat.LineAlignment = System.Drawing.StringAlignment.Center;
            strFormat.Alignment = System.Drawing.StringAlignment.Center;
            return "<BUTTON STYLE=\"width="+Width.ToString()+"; height="+Height.ToString()+"\">"+
            BreakedString(TextStr, strFormat, Bounds)+"</BUTTON>";
        }
        
        public override string ToString()
        {
            return "<Button left=\""+Left.ToString()+"\"; top=\""+Top.ToString()+
                "\"; height=\""+Height.ToString()+"\"; width=\""+Width.ToString()+"\"; Caption=\""+TextStr+"\">";
        }
        
        public override Amba.VEdit.GUI.VEControl CreateVEControl()
        {
            return new Amba.VEdit.GUI.VEButton(this, TextStr, Left, Top, Width, Height);
        }
    }

    public class DMTextEdit: ControlBase
    {
        public DMTextEdit(int x, int y, int width, string text) :
            base(x, y, width, ControlBase.DefaultHeight, text) {}
        
        public string Text
        {
            get {return TextStr;}
            set {TextStr = value;}
        }
        
        new public int Height
        {
            get {return _Bounds.Height;}
        }
        
        protected override string GetHTMLTag()
        {
            return "<INPUT TYPE=\"TEXT\" STYLE=\"width="+Width+"; height="+Height+"\" VALUE=\""+TextStr+"\"/>";
        }
        
        public override string ToString()
        {
            return "<Edit left=\""+Left.ToString()+"\"; top=\""+Top.ToString()+
                "\"; height=\""+Height.ToString()+"\"; width=\""+Width.ToString()+"\"; Text=\""+TextStr+"\">";
        }
        
        public override Amba.VEdit.GUI.VEControl CreateVEControl()
        {
            return new Amba.VEdit.GUI.VETextEdit(this, TextStr, Left, Top, Width, Height);
        }
    }

    public class DMLabel: ControlBase
    {
        public DMLabel(int x, int y, int width, int height, string text) :
            base(x, y, width, height, text) {}
        
        public string Text
        {
            get {return TextStr;}
            set {TextStr = value;}
        }
        
        protected override string GetHTMLTag()
        {
            System.Drawing.StringFormat strFormat = new StringFormat();
            strFormat.LineAlignment = System.Drawing.StringAlignment.Near;
            strFormat.Alignment = System.Drawing.StringAlignment.Near;
            return BreakedString(TextStr, strFormat, Bounds);
        }
        
        public override string ToString()
        {
            return "<Label left=\""+Left.ToString()+"\"; top=\""+Top.ToString()+
                "\"; height=\""+Height.ToString()+"\"; width=\""+Width.ToString()+"\"; Text=\""+TextStr+"\">";
        }
        
        public override Amba.VEdit.GUI.VEControl CreateVEControl()
        {
            return new Amba.VEdit.GUI.VELabel(this, TextStr, Left, Top, Width, Height);
        }
    }
}
