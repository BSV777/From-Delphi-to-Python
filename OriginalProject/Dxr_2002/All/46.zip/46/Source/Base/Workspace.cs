using System;
using System.Drawing;
using System.Collections;
using System.IO;
using System.Text.RegularExpressions;

namespace Amba.VEdit.Base
{
    public class ControlNotFoundException: ApplicationException
    {
        public ControlNotFoundException()
        {
        }
        public ControlNotFoundException(string message): base(message)
        {
        }
        public ControlNotFoundException(string message, Exception inner): base(message, inner)
        {
        }
    }

    public class InvalidBoundsException: ApplicationException
    {
        public InvalidBoundsException()
        {
        }
        public InvalidBoundsException(string message): base(message)
        {
        }
        public InvalidBoundsException(string message, Exception inner): base(message, inner)
        {
        }
    }
    
    public class IntersectionException: ApplicationException
    {
        public IntersectionException()
        {
        }
        public IntersectionException(string message): base(message)
        {
        }
        public IntersectionException(string message, Exception inner): base(message, inner)
        {
        }
    }
    
    public class Workspace
    {
        private ControlCollection _CtrlColl = new ControlCollection();
        private Size _EntireArea;
        
        public Workspace()
        {
            _EntireArea = new Size(200, 300);
        }
        
        public Workspace(int width, int height)
        {
            _EntireArea = new Size(width, height);
        }
        
        public Size EntireArea
        {
            get {return _EntireArea;}
            set {
                foreach (ControlBase ctrl in _CtrlColl) {
                    if ((value.Width < ctrl.Left+ctrl.Width) || (value.Height < ctrl.Top+ctrl.Height)) {
                        return;
                    }
                }
                _EntireArea = value;
            }
        }
        
        public void RemoveControl(ControlBase ctrl)
        {
            _CtrlColl.Remove(ctrl);
        }
        
        public int AddControl(ControlBase ctrl)
        {
            Rectangle tmpRect = ctrl.Bounds;
            while (IsIntersected(ctrl, tmpRect)) {
                tmpRect.Y = tmpRect.Y + (int)ControlBase.DefaultHeight/2;
            }
            if (IsOutbounded(tmpRect)) InflateArea(tmpRect);
            ctrl.SetBounds(tmpRect);
            return _CtrlColl.Add(ctrl);
        }
        
        private void InflateArea(Rectangle newBounds)
        {
            if ((newBounds.Left + newBounds.Width) > _EntireArea.Width) _EntireArea.Width = newBounds.Left + newBounds.Width;
            if ((newBounds.Top + newBounds.Height) > _EntireArea.Height) _EntireArea.Height = newBounds.Top + newBounds.Height;
        }
        
        private bool IsIntersected(ControlBase ctrl, Rectangle newBounds)
        {
            foreach (ControlBase ctrlInColl in _CtrlColl) {
                if (ctrl == ctrlInColl) continue;
                if (newBounds.IntersectsWith(ctrlInColl.Bounds)) return true;
            }
            return false;
        }
        
        private bool IsOutbounded(Rectangle newBounds)
        {
            return ( (newBounds.Top < 0) ||
                       (newBounds.Left < 0) ||
                       ((newBounds.Left + newBounds.Width) > _EntireArea.Width) ||
                       ((newBounds.Top + newBounds.Height) > _EntireArea.Height));
        }
        
        public void CheckControlValid(ControlBase ctrl, Rectangle newBounds)
        {
            if (IsOutbounded(newBounds)) throw new InvalidBoundsException();
            if (IsIntersected(ctrl, newBounds)) throw new IntersectionException();
        }

        public int ControlsCount
        {
            get {
                return _CtrlColl.Count;
            }
        }
        
        public ControlBase ControlAtIndex(int index)
        {
            try{
                return _CtrlColl[index];
            } catch (ArgumentOutOfRangeException aore) {
                throw new ControlNotFoundException("No control with this index", aore);
            }
        }
        
        public void Save(string fileName)
        {
            try {
                StreamWriter sw = new StreamWriter(fileName, false, System.Text.Encoding.Default);
                foreach (ControlBase ctrl in _CtrlColl) {
                    sw.WriteLine(ctrl);
                    sw.Flush();
                }
                sw.Close();
            } catch  (Exception) {
            }
        }
        
        public int Load(string fileName)
        {
            string entireFileContent;
            try {
                StreamReader sr = new StreamReader(fileName, System.Text.Encoding.Default);
                entireFileContent = sr.ReadToEnd();
                sr.Close();
            } catch  (Exception) {
                return 0;
            }

            Regex ctrlRE = new Regex("<\\s*(?<control>button|label|edit)(?<properties>[^>]+)", RegexOptions.IgnoreCase);
            Regex leftRE = new Regex("left=\"(?<left>\\d+)\"", RegexOptions.IgnoreCase);
            Regex topRE = new Regex("top=\"(?<top>\\d+)\"", RegexOptions.IgnoreCase);
            Regex widthRE = new Regex("width=\"(?<width>\\d+)\"", RegexOptions.IgnoreCase);
            Regex heightRE = new Regex("height=\"(?<height>\\d+)\"", RegexOptions.IgnoreCase);
            Regex captionRE = new Regex("caption=\"(?<caption>[^\"]+)\"", RegexOptions.IgnoreCase);
            Regex textRE = new Regex("text=\"(?<text>[^\"]+)\"", RegexOptions.IgnoreCase);
            string propStr;
            Match propMatch;
            int left, top, width, height;
            string text;
            ControlBase ctrl;
            int resultCount = 0;
            
            for (Match ctrlMatch = ctrlRE.Match(entireFileContent);
                ctrlMatch != Match.Empty;
                ctrlMatch = ctrlMatch.NextMatch())
            {
                propStr = ctrlMatch.Groups["properties"].Value;
                try{
                    propMatch = leftRE.Match(propStr);
                    if (propMatch == Match.Empty) {
                        left = 0;
                    } else{
                        left = Convert.ToInt32(propMatch.Groups["left"].Value);
                    }
                    propMatch = widthRE.Match(propStr);
                    if (propMatch == Match.Empty) {
                        width = ControlBase.DefaultWidth;
                    } else{
                        width = Convert.ToInt32(propMatch.Groups["width"].Value);
                    }
                    propMatch = topRE.Match(propStr);
                    if (propMatch == Match.Empty) {
                        top = 0;
                    } else{
                        top = Convert.ToInt32(propMatch.Groups["top"].Value);
                    }
                    propMatch = heightRE.Match(propStr);
                    if (propMatch == Match.Empty) {
                        height = ControlBase.DefaultHeight;
                    } else{
                        height = Convert.ToInt32(propMatch.Groups["height"].Value);
                    }
                } catch (Exception) {
                    continue;
                }
                switch (ctrlMatch.Groups["control"].Value.ToLower()) {
                    case "button" :
                        propMatch = captionRE.Match(propStr);
                        text = propMatch.Groups["caption"].Value;
                        ctrl = new DMButton(left, top, width, height, text);
                        break;
                    case "label" :
                        propMatch = textRE.Match(propStr);
                        text = propMatch.Groups["text"].Value;
                        ctrl = new DMLabel(left, top, width, height, text);
                        break;
                    case "edit" :
                        propMatch = textRE.Match(propStr);
                        text = propMatch.Groups["text"].Value;
                        ctrl = new DMTextEdit(left, top, width, text);
                        break;
                    default :
                        continue;
                }
                AddControl(ctrl);
                ctrl.OnCheckBounds = new CheckControlDelegate(CheckControlValid);
                resultCount++;
            }
            return resultCount;
        }
        
        public void Save2HTML(string fileName)
        {
            ArrayList tmpBorderArr = new ArrayList();
            int curBorderCoord = 0;

            _CtrlColl.Sort(ControlCollection.SortByXCoord);
            tmpBorderArr.Add(_CtrlColl[0].Left);
            curBorderCoord = _CtrlColl[0].Left;
            foreach (ControlBase ctrl in _CtrlColl) {
                if (curBorderCoord != ctrl.Left) {
                    tmpBorderArr.Add(ctrl.Left);
                    curBorderCoord = ctrl.Left;
                }
            }
            int[] xBorderCoord = (int[])Array.CreateInstance(typeof(Int32), tmpBorderArr.Count);
            tmpBorderArr.CopyTo(xBorderCoord);
            tmpBorderArr = null;
            
            tmpBorderArr = new ArrayList();
            _CtrlColl.Sort(ControlCollection.SortByYCoord);
            tmpBorderArr.Add(_CtrlColl[0].Top);
            curBorderCoord = _CtrlColl[0].Top;
            foreach (ControlBase ctrl in _CtrlColl) {
                if (curBorderCoord != ctrl.Top) {
                    tmpBorderArr.Add(ctrl.Top);
                    curBorderCoord = ctrl.Top;
                }
            }
            int[] yBorderCoord = (int[])Array.CreateInstance(typeof(Int32), tmpBorderArr.Count);
            tmpBorderArr.CopyTo(yBorderCoord);
            tmpBorderArr = null;
            
            bool[,] spanedCells = (bool[,])Array.CreateInstance(typeof(Boolean), xBorderCoord.Length, yBorderCoord.Length);
            
            try {
                StreamWriter HTMLFile = new StreamWriter(fileName, false, System.Text.Encoding.Default);
                //add standart header
                HTMLFile.WriteLine("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 3.2 Final//EN\">");
                HTMLFile.WriteLine("<META HTTP-EQUIV=\"Autocreated form\" CONTENT=\"text/html; CHARSET="+HTMLFile.Encoding.WebName+"\">");
                HTMLFile.WriteLine("<HTML>");
                HTMLFile.WriteLine("<HEAD>");
                HTMLFile.WriteLine("<TITLE>Visual Editor Output</TITLE>");
                HTMLFile.WriteLine("</HEAD>");
                HTMLFile.WriteLine("<BODY>");
                HTMLFile.WriteLine("<TABLE STYLE=\"font-family:"+FontFamily.GenericSansSerif.Name+"; font-size:10pt\" BORDER=0 CELLSPACING=0 CELLPADDING=0>");
                
                //add first row with columns widths
                HTMLFile.WriteLine("\t<TR VALIGN=TOP ALIGN=LEFT HEIGHT={0}>", yBorderCoord[0]);
                HTMLFile.Write("\t\t<TD WIDTH={0}>", xBorderCoord[0]);
                HTMLFile.WriteLine("<IMG BORDER=0 WIDTH=0 HEIGHT=0></TD>");
                for (int x = 1; x < xBorderCoord.Length; x++) {
                    HTMLFile.Write("\t\t<TD WIDTH={0}>", xBorderCoord[x]-xBorderCoord[x-1]);
                    HTMLFile.WriteLine("<IMG BORDER=0 WIDTH=0 HEIGHT=0></TD>");
                }
                HTMLFile.WriteLine("\t\t<TD><IMG BORDER=0 WIDTH=0 HEIGHT=0></TD>");
                HTMLFile.WriteLine("\t</TR>");
                HTMLFile.Flush();
                
                //add controls
                int curXBorder, tmpCurYBorder, xSpan, ySpan, curCtrl = 0;
                for (int curYBorder = 0; curYBorder < yBorderCoord.Length; curYBorder++) {
                    HTMLFile.WriteLine("\t<TR VALIGN=TOP ALIGN=LEFT HEIGHT={0}>", 
                                              (curYBorder < yBorderCoord.Length-1) ?
                                              yBorderCoord[curYBorder+1]-yBorderCoord[curYBorder] :
                                              0);
                    HTMLFile.WriteLine("\t\t<TD></TD>");
                    curXBorder = 0;
                    while (_CtrlColl[curCtrl].Top == yBorderCoord[curYBorder]) {
                        while (xBorderCoord[curXBorder] != _CtrlColl[curCtrl].Left) {
                            if (!spanedCells[curXBorder, curYBorder]) HTMLFile.WriteLine("\t\t<TD></TD>");
                            curXBorder++;
                        }
                        xSpan = 1;
                        ySpan = 1;
                        curXBorder++;
                        while ((curXBorder < xBorderCoord.Length) && (xBorderCoord[curXBorder] < (_CtrlColl[curCtrl].Left+_CtrlColl[curCtrl].Width))) {
                            xSpan++;
                            curXBorder++;
                        }
                        tmpCurYBorder = curYBorder+1;
                        while ((tmpCurYBorder < yBorderCoord.Length) && (yBorderCoord[tmpCurYBorder] < (_CtrlColl[curCtrl].Top+_CtrlColl[curCtrl].Height))) {
                            ySpan++;
                            tmpCurYBorder++;
                        }
                        for (int y = tmpCurYBorder-ySpan; y < tmpCurYBorder; y++)
                            for (int x = curXBorder-xSpan; x < curXBorder; x++)
                                spanedCells[x,y] = true;
                        spanedCells[curXBorder-xSpan,tmpCurYBorder-ySpan] = false;
                        HTMLFile.Write("\t\t<TD");
                        if (xSpan > 1) {HTMLFile.Write(" COLSPAN={0}", xSpan);}
                        if (ySpan > 1) {HTMLFile.Write(" ROWSPAN={0}", ySpan);}
                        HTMLFile.Write(">");
                        HTMLFile.Write(_CtrlColl[curCtrl].HTMLTagString);
                        HTMLFile.WriteLine("</TD>");
                        curCtrl++;
                        if (curCtrl == _CtrlColl.Count) break;
                    }
                    HTMLFile.WriteLine("\t</TR>");
                    HTMLFile.Flush();
                }
                HTMLFile.WriteLine("</TABLE>");
                HTMLFile.WriteLine("</BODY>");
                HTMLFile.WriteLine("</HTML>");
                HTMLFile.Close();
            } catch  (Exception) {
            }
        }
    }
}
