using System;
using System.Collections;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;


using Amba.VEdit.GUI;

namespace Amba.VEdit.Base
{
    public delegate void CheckControlDelegate(ControlBase ctrl, Rectangle rect);
    
    public class ControlBase
    {
        protected Rectangle _Bounds;
        private string _TextStr;
        private CheckControlDelegate _ValidBounds;
        public const int DefaultHeight = 24;
        public const int DefaultWidth = 96;
        public const int MaxTextLength = 255;
        
        public ControlBase(int x, int y, int width, int height, string text) 
        {
            if (width < DefaultWidth) width = DefaultWidth;
            if (height < DefaultHeight) height = DefaultHeight;
            _Bounds = new Rectangle(new Point(x, y), new Size(width, height));
            _TextStr = text;
        }
        
        public CheckControlDelegate OnCheckBounds
        {
            get {return _ValidBounds;}
            set {_ValidBounds = value;}
        }
        
        public Rectangle Bounds
        {
            get {return _Bounds;}
        }
        
        public void SetBounds(Rectangle newRect)
        {
            try {
                if (_ValidBounds != null)  _ValidBounds(this, newRect);
                _Bounds = newRect;
            } catch (InvalidBoundsException){
                throw new InvalidBoundsException("Invalid bounds");
            } catch (IntersectionException){
                throw new IntersectionException();
            }
        }
        
        public int Top
        {
            get {return _Bounds.Top;}
            set {
                try {
                    if (_ValidBounds != null)  _ValidBounds(this,  new Rectangle(_Bounds.X, value, _Bounds.Width, _Bounds.Height));
                    _Bounds.Y = value;
                } catch (InvalidBoundsException){
                    throw new InvalidBoundsException("Invalid Top bound");
                } catch (IntersectionException){
                    throw new IntersectionException("Control has intersection with other");
                }
            }
        }
        
        public int Left
        {
            get {return _Bounds.Left;}
            set {
                try {
                    if (_ValidBounds != null)  _ValidBounds(this,  new Rectangle(value, _Bounds.Y, _Bounds.Width, _Bounds.Height));
                    _Bounds.X = value;
                } catch (InvalidBoundsException){
                    throw new InvalidBoundsException("Invalid Left bound");
                } catch (IntersectionException){
                    throw new IntersectionException("Control has intersection with other");
                }
            }
        }
        
        public int Width
        {
            get {return _Bounds.Width;}
            set {
                try {
                    if (_ValidBounds != null)  _ValidBounds(this,  new Rectangle(_Bounds.X, _Bounds.Y, value, _Bounds.Height));
                    _Bounds.Width = value;
                } catch (InvalidBoundsException){
                    throw new InvalidBoundsException("Invalid Control Width");
                } catch (IntersectionException){
                    throw new IntersectionException("Control has intersection with other");
                }
            }
        }
        
        public int Height
        {
            get {return _Bounds.Height;}
            set {
                try {
                    if (_ValidBounds != null)  _ValidBounds(this,  new Rectangle(_Bounds.X, _Bounds.Y, _Bounds.Width, value));
                    _Bounds.Height = value;
                } catch (InvalidBoundsException){
                    throw new InvalidBoundsException("Invalid Control height");
                } catch (IntersectionException){
                    throw new IntersectionException("Control has intersection with other");
                }
            }
        }
        
        public string TextStr
        {
            get {return _TextStr;}
            set {
                if (value.Length > MaxTextLength){
                    _TextStr = value.Substring(0, MaxTextLength);
                } else{
                    _TextStr = value;
                }
            }
        }
        
        public virtual Amba.VEdit.GUI.VEControl CreateVEControl()
        {
            return null;
        }
        
        protected virtual string GetHTMLTag()
        {
            return "<IMG BORDER=0 WIDTH=0 HEIGHT=0>";
        }
        
        public string HTMLTagString
        {
            get {return GetHTMLTag();}
        }
        
        protected string BreakedString(string inputStr, StringFormat strFormat, Rectangle layoutRect)
        {
            System.Text.StringBuilder  strBuild = new StringBuilder(inputStr);
            System.Text.RegularExpressions.Regex regEX = new Regex("([^\\s]+)");
            System.Text.RegularExpressions.MatchCollection matches = regEX.Matches(inputStr);
            System.Drawing.CharacterRange[] charRanges = new CharacterRange[matches.Count];
            for (int index = 0; index < matches.Count; index++) {
                charRanges[index] = new CharacterRange(matches[index].Index, matches[index].Length);
            }

            strFormat.FormatFlags = strFormat.FormatFlags | StringFormatFlags.LineLimit;
            System.Windows.Forms.Form trickForm = new Form();
            System.Drawing.Graphics g =  Graphics.FromHwnd(trickForm.Handle);
            System.Drawing.Font tnrFont = new Font(FontFamily.GenericSansSerif, 10f);
            int wholePartCnt = (int)(charRanges.Length - charRanges.Length % 32 ) / 32;
            System.Drawing.CharacterRange[] tmp32Ranges = new CharacterRange[32];
            System.Drawing.Region[] char32Regions = new Region[32];
            int predLeft = 0;
            int cntAddedChars = 0;
            System.Drawing.RectangleF tmpRect;
            
            for (int part = 0; part < wholePartCnt; part++) {
                Array.Copy(charRanges, part*32, tmp32Ranges, 0, 32);
                strFormat.SetMeasurableCharacterRanges(tmp32Ranges);
                char32Regions = g.MeasureCharacterRanges(inputStr, tnrFont, layoutRect, strFormat);
                for (int i = 0; i < 32; i++ ){
                    tmpRect  = char32Regions[i].GetBounds(g);
                    if (tmpRect.Width == 0) {
                        strBuild.Remove(tmp32Ranges[i].First+cntAddedChars, inputStr.Length-tmp32Ranges[i].First);
                        return strBuild.ToString();
                    }
                    if (tmpRect.Left < predLeft) {
                        strBuild.Insert(tmp32Ranges[i].First+cntAddedChars,"<BR>");
                        cntAddedChars += 4;
                    }
                    predLeft = (int)tmpRect.Left;
                }
            }
            int remainder = charRanges.Length % 32;
            if (remainder > 0){
                System.Drawing.CharacterRange[] tmpRanges = new CharacterRange[remainder];
                System.Drawing.Region[] charRegions = new Region[remainder];
                Array.Copy(charRanges, wholePartCnt*32, tmpRanges, 0, remainder);
                strFormat.SetMeasurableCharacterRanges(tmpRanges);
                charRegions = g.MeasureCharacterRanges(inputStr, tnrFont, layoutRect, strFormat);
                for (int i = 0; i < charRegions.Length; i++ ){
                    tmpRect  = charRegions[i].GetBounds(g);
                    if (tmpRect.Width == 0) {
                        strBuild.Remove(tmpRanges[i].First+cntAddedChars, inputStr.Length-tmpRanges[i].First);
                        return strBuild.ToString();
                    }
                    if (tmpRect.Left < predLeft) {
                        strBuild.Insert(tmpRanges[i].First+cntAddedChars,"<BR>");
                        cntAddedChars += 4;
                    }
                    predLeft = (int)tmpRect.Left;
                }
            }
            return strBuild.ToString();
        }
    }
}