using System;
using System.Collections;

namespace Amba.VEdit.Base
{
    public class ControlCollection: CollectionBase
    {
        public bool Contains(ControlBase ctrl)
        {
            return base.List.Contains(ctrl);
        }
        
        public int Add(ControlBase ctrlToAdd)
        {
            return base.List.Add(ctrlToAdd);
        }
        
        public ControlBase this[int index]
        {
            get{
                return (ControlBase)base.List[index];
            }
        }

        public int IndexOf(ControlBase ctrl)
        {
            return base.List.IndexOf(ctrl);
        }

        public void Remove(ControlBase ctrl)
        {
            base.List.Remove(ctrl);
        }
        
        public void Sort(IComparer comparer)
        {
            InnerList.Sort(comparer);
        }
        
        public static IComparer SortByXCoord
        {
            get {
                return  ((IComparer) new SortByXCoordClass());
            }
        }
        
        private class SortByXCoordClass: IComparer
        {
            public int Compare(object obj1, object obj2)
            {
                ControlBase ctrl1 = (ControlBase) obj1;
                ControlBase ctrl2 = (ControlBase) obj2;
                return ( ((Int32) ctrl1.Left).CompareTo(ctrl2.Left));
            }
        }
        
        public static IComparer SortByYCoord
        {
            get {
                return  ((IComparer) new SortByYCoordClass());
            }
        }

        private class SortByYCoordClass: IComparer
        {
            public int Compare(object obj1, object obj2)
            {
                ControlBase ctrl1 = (ControlBase) obj1;
                ControlBase ctrl2 = (ControlBase) obj2;
                if (ctrl1.Top != ctrl2.Top) {
                    return ( ((Int32) ctrl1.Top).CompareTo(ctrl2.Top));
                } else {
                    return ( ((Int32) ctrl1.Left).CompareTo(ctrl2.Left));
                }
            }
        }
    }
}
/*
        // Declare the event signatures
        public delegate void CollectionClear();
        public delegate void CollectionChange(int index, object value);

        // Collection change events
        public event CollectionClear Clearing;
        public event CollectionClear Cleared;
        public event CollectionChange Inserting;
        public event CollectionChange Inserted;
        public event CollectionChange Removing;
        public event CollectionChange Removed;
*/
