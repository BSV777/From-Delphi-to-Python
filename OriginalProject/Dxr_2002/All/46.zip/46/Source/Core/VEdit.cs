using System;
using System.IO;
using System.Windows.Forms;
using System.Drawing;
using System.ComponentModel;

using Amba.VEdit.Base;
using Amba.VEdit.GUI;

namespace Amba.VEdit.Core
{
    public class VEdit
    {
        [STAThread]
        public static void Main(string[] args)
        {
            if ((args.Length == 2) && File.Exists(args[0])){
                Amba.VEdit.Base.Workspace ws = new Amba.VEdit.Base.Workspace();
                ws.Load(args[0]);
                ws.Save2HTML(args[1]);
            } else {
                Application.Run(new MainForm());
            }
        }
    }
    
    public class MainForm : System.Windows.Forms.Form
    {
        private System.ComponentModel.Container _Components;
        private PropertyForm _PropForm;
        private Amba.VEdit.GUI.HTMLDesigner _Designer;
        private System.Windows.Forms.ToolBar _ToolBar;
        private System.Windows.Forms.ImageList _ImageList;
        private System.Windows.Forms.ToolBarButton _openButton;
        private System.Windows.Forms.ToolBarButton _saveButton; 
        private System.Windows.Forms.ToolBarButton _exportButton; 
        private System.Windows.Forms.ToolBarButton _separator1; 
        private System.Windows.Forms.ToolBarButton _deleteButton; 
        private System.Windows.Forms.ToolBarButton _addButton; 
        private System.Windows.Forms.ToolBarButton _addText; 
        private System.Windows.Forms.ToolBarButton _addLabel; 
        private System.Windows.Forms.ToolBarButton _separator2; 
        private System.Windows.Forms.ToolBarButton _multiButton;
        private System.Windows.Forms.ToolBarButton _propFormButton;
        private System.Windows.Forms.ToolBarButton _separator3; 
        private System.Windows.Forms.ToolBarButton _sameWidthButton; 
        private System.Windows.Forms.ToolBarButton _sameHeightButton; 
        private System.Windows.Forms.ToolBarButton _sameLeftButton; 
        private System.Windows.Forms.ToolBarButton _sameTopButton; 
        private System.Windows.Forms.ToolBarButton _sameHorButton; 
        private System.Windows.Forms.ToolBarButton _sameVertButton; 
    
        public MainForm() : base()
        {   
            InitializeComponent();   
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing){
                if(_Components != null){
                    _Components.Dispose();
                }
            }
            base.Dispose(disposing);
        }
        
        private void InitializeComponent()
        {
            _Components = new System.ComponentModel.Container();
            _ImageList = new System.Windows.Forms.ImageList();
            try {
                _ImageList.Images.Add(new Bitmap(".\\img\\open.bmp"));
                _ImageList.Images.Add(new Bitmap(".\\img\\save.bmp")); 
                _ImageList.Images.Add(new Bitmap(".\\img\\export.bmp")); 
                _ImageList.Images.Add(new Bitmap(".\\img\\delete.bmp")); 
                _ImageList.Images.Add(new Bitmap(".\\img\\button.bmp")); 
                _ImageList.Images.Add(new Bitmap(".\\img\\edit.bmp"));
                _ImageList.Images.Add(new Bitmap(".\\img\\label.bmp"));
                _ImageList.Images.Add(new Bitmap(".\\img\\multi.bmp"));
                _ImageList.Images.Add(new Bitmap(".\\img\\prop.bmp"));
                _ImageList.Images.Add(new Bitmap(".\\img\\Width.bmp"));
                _ImageList.Images.Add(new Bitmap(".\\img\\Height.bmp"));
                _ImageList.Images.Add(new Bitmap(".\\img\\Left.bmp"));
                _ImageList.Images.Add(new Bitmap(".\\img\\Top.bmp"));
                _ImageList.Images.Add(new Bitmap(".\\img\\Hor.bmp"));
                _ImageList.Images.Add(new Bitmap(".\\img\\Vert.bmp"));
            } catch (Exception){}
//            System.Resources.ResourceManager resources =
//                new System.Resources.ResourceManager(typeof(MainForm));
//            _ImageList.ImageStream =
//                    ((System.Windows.Forms.ImageListStreamer)
//                    (resources.GetObject("_ImageList.ImageStream")));
            _ImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth4Bit;
            _ImageList.ImageSize = new System.Drawing.Size(24, 24);
            _ImageList.TransparentColor = System.Drawing.Color.Yellow;
            _openButton = new  System.Windows.Forms.ToolBarButton();
            _openButton.ToolTipText = "Open Data File";
            _openButton.ImageIndex = 0;
            _saveButton = new  System.Windows.Forms.ToolBarButton(); 
            _saveButton.ToolTipText = "Save Data File";
            _saveButton.ImageIndex = 1;
            _exportButton = new  System.Windows.Forms.ToolBarButton(); 
            _exportButton.ToolTipText = "Export to HTML File";
            _exportButton.ImageIndex = 2;
            _deleteButton = new  System.Windows.Forms.ToolBarButton();
            _deleteButton.ToolTipText = "Delete selected control/controls";
            _deleteButton.ImageIndex = 3;
            _addButton = new  System.Windows.Forms.ToolBarButton(); 
            _addButton.ToolTipText = "Add Button control";
            _addButton.ImageIndex = 4;
            _addText = new  System.Windows.Forms.ToolBarButton(); 
            _addText.ToolTipText = "Add Text Edit control";
            _addText.ImageIndex = 5;
            _addLabel = new  System.Windows.Forms.ToolBarButton(); 
            _addLabel.ToolTipText = "Add Label control";
            _addLabel.ImageIndex = 6;
            _multiButton = new  System.Windows.Forms.ToolBarButton();
            _multiButton.ToolTipText = "Multiselect mode";
            _multiButton.Style = ToolBarButtonStyle.ToggleButton;
            _multiButton.ImageIndex = 7;
            _propFormButton = new  System.Windows.Forms.ToolBarButton();
            _propFormButton.ToolTipText = "Show/Hide Properties";
            _propFormButton.Style = ToolBarButtonStyle.ToggleButton;
            _propFormButton.ImageIndex = 8;
            _sameWidthButton = new  System.Windows.Forms.ToolBarButton(); 
            _sameWidthButton .ToolTipText = "Set same Width";
            _sameWidthButton.ImageIndex = 9;
            _sameHeightButton = new  System.Windows.Forms.ToolBarButton(); 
            _sameHeightButton .ToolTipText = "Set same Height";
            _sameHeightButton.ImageIndex = 10;
            _sameLeftButton = new  System.Windows.Forms.ToolBarButton(); 
            _sameLeftButton .ToolTipText = "Set same Left Coord";
            _sameLeftButton.ImageIndex = 11;
            _sameTopButton = new  System.Windows.Forms.ToolBarButton(); 
            _sameTopButton .ToolTipText = "Set same Top Coord";
            _sameTopButton.ImageIndex = 12;
            _sameHorButton = new  System.Windows.Forms.ToolBarButton(); 
            _sameHorButton .ToolTipText = "Set same horizontal space bitween Controls";
            _sameHorButton.ImageIndex = 13;
            _sameVertButton = new  System.Windows.Forms.ToolBarButton(); 
            _sameVertButton .ToolTipText = "Set same vertical space bitween Controls";
            _sameVertButton.ImageIndex = 14;
            _separator1 = new  System.Windows.Forms.ToolBarButton(); 
            _separator1.Style = ToolBarButtonStyle.Separator;
            _separator2 = new  System.Windows.Forms.ToolBarButton(); 
            _separator2.Style = ToolBarButtonStyle.Separator;
            _separator3 = new  System.Windows.Forms.ToolBarButton(); 
            _separator3.Style = ToolBarButtonStyle.Separator;
            _ToolBar = new System.Windows.Forms.ToolBar();
            _ToolBar.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
                                                    _openButton,
                                                    _saveButton, 
                                                    _exportButton, 
                                                    _separator1,
                                                    _deleteButton, 
                                                    _addButton, 
                                                    _addText, 
                                                    _addLabel, 
                                                    _separator2,
                                                    _multiButton,
                                                    _propFormButton,
                                                    _separator3,
                                                    _sameWidthButton,
                                                    _sameHeightButton,
                                                    _sameLeftButton,
                                                    _sameTopButton,
                                                    _sameHorButton,
                                                    _sameVertButton});
            _ToolBar.ImageList = _ImageList;
            _ToolBar.AutoSize = false;
            _ToolBar.Wrappable = false;
            _ToolBar.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            _ToolBar.Appearance = ToolBarAppearance.Flat;
            _ToolBar.ShowToolTips = true;
            _ToolBar.Location = new Point(0, 0);
            _ToolBar.Width = this.Width - 8;
            _ToolBar.Height = _ToolBar.ButtonSize.Height - 4;
            _ToolBar.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(ToolBar_ButtonClick);
            _Designer = new Amba.VEdit.GUI.HTMLDesigner();
            _Designer.Location = new System.Drawing.Point(0, _ToolBar.Height + 4);
            _Designer.Size = new System.Drawing.Size(this.Width - 8, this.Height - _ToolBar.Height - 32);
            _Designer.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Right;
            _Designer.CurrentControlChanged += new HTMLDesigner.CCCEventHandler(ControlChanged);
            Controls.AddRange(new System.Windows.Forms.Control[] {_Designer, _ToolBar});
            Text = "Visual HTML Form Editor";
            Bounds = new System.Drawing.Rectangle(0, 0, 500, 400);
            _PropForm = new PropertyForm();
            _PropForm.Closing += new CancelEventHandler(PropForm_Closing);
        }
        
        private void ControlChanged(object sender, CCCEventArgs e)
        {
            _PropForm.PropertyGrid.SelectedObject = e.ActiveControl;
            if (e.ActiveControl == null) {
                _PropForm.Text = "";
            } else {
                _PropForm.Text = e.ActiveControl.Text;
            }
        }
        
        private void PropForm_Closing(object sender, CancelEventArgs cea)
        {
            _propFormButton.Pushed = false;
        }
        
        private void ToolBar_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs tbbc)
        {
            if(tbbc.Button == _openButton)   
            {
                Open();
            }
            else if(tbbc.Button == _saveButton)
            {
                Save();
            }
            else if(tbbc.Button == _exportButton)
            {
                ExportToHTML();
            }
            else if(tbbc.Button == _deleteButton)
            {
                _Designer.DeleteSelectedControls();
            }
            else if(tbbc.Button == _addButton)
            {
                _Designer.AddButton();
            }
            else if(tbbc.Button == _addText)
            {
                _Designer.AddTextEdit();
            }
            else if(tbbc.Button == _addLabel)
            {
                _Designer.AddLabel();
            }
            else if(tbbc.Button == _multiButton)
            {
                _Designer.ChangeMode();
            }
            else if(tbbc.Button == _propFormButton)
            {
                _PropForm.Visible = !_PropForm.Visible;
            }
            else if(tbbc.Button == _sameWidthButton)
            {
                _Designer.SetSameWidth();
            }
            else if(tbbc.Button == _sameHeightButton)
            {
                _Designer.SetSameHeight();
            }
            else if(tbbc.Button == _sameLeftButton)
            {
                _Designer.SetSameLeft();
            }
            else if(tbbc.Button == _sameTopButton)
            {
                _Designer.SetSameTop();
            }
            else if(tbbc.Button == _sameHorButton)
            {
                _Designer.SetSameHorSpace();
            }
            else if(tbbc.Button == _sameVertButton)
            {
                _Designer.SetSameVertSpace();
            }
        }
        
        private void Open()
        {
            OpenFileDialog openDlg = new OpenFileDialog();
            openDlg.Filter  = "Layout Data Files (*.dat)|*.dat|All Files (*.*)|*.*";
            openDlg.FileName = "" ;
            openDlg.DefaultExt = ".dat";
            openDlg.CheckFileExists = true;
            openDlg.CheckPathExists = true;

            DialogResult res = openDlg.ShowDialog ();

            if(res == DialogResult.OK)
            {
                if( !(openDlg.FileName).EndsWith(".dat") && !(openDlg.FileName).EndsWith(".DAT")) 
                    MessageBox.Show("Unexpected file format","HTML Designer",MessageBoxButtons.OK );
                else
                {
                    Cursor = Cursors.WaitCursor;
                    _Designer.LoadFromFile(openDlg.FileName);
                    Cursor = Cursors.Default;
                }
            }       
        }

        private void Save()
        {
            SaveFileDialog saveDlg = new SaveFileDialog();
            saveDlg.Filter =  "Layout Data Files (*.dat)|*.dat|All Files (*.*)|*.*";
            saveDlg.DefaultExt = ".dat";
            saveDlg.FileName = "layout1.dat";
            DialogResult res = saveDlg.ShowDialog ();

            if(res == DialogResult.OK){
                Cursor = Cursors.WaitCursor;
                _Designer.SaveToFile(saveDlg.FileName);      
                Cursor = Cursors.Default;
            }
        }

        private void ExportToHTML()
        {       
            SaveFileDialog saveDlg = new SaveFileDialog();
            saveDlg.Filter =  "HTML Files (*.html)|*.html|All Files (*.*)|*.*";
            saveDlg.DefaultExt = ".html";
            saveDlg.FileName = "form1.html";
            DialogResult res = saveDlg.ShowDialog ();

            if(res == DialogResult.OK){
                Cursor = Cursors.WaitCursor;
                _Designer.ExportToHTMLFile(saveDlg.FileName);      
                Cursor = Cursors.Default;
            }
        }
    }

    public class PropertyForm : System.Windows.Forms.Form
    {
        private System.ComponentModel.Container _Components;
        private PropertyGrid _PropGrid;

        public PropertyForm() : base()
        {
            InitializeComponent();   
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing){
                if(_Components != null){
                    _Components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        public PropertyGrid PropertyGrid
        {
            get{return _PropGrid;}
        }
        
        private void InitializeComponent()
        {
            _Components = new System.ComponentModel.Container();
            _PropGrid = new PropertyGrid();
            _PropGrid.BrowsableAttributes = new AttributeCollection(new Attribute[] {new Amba.VEdit.GUI.VEBrowsableAttribute()});
            _PropGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            Controls.Add(_PropGrid);
            FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            Bounds = new System.Drawing.Rectangle(500, 0, 150, 300);
            ShowInTaskbar = false;
            TopMost = true;
        }
        
        protected override void OnClosing(CancelEventArgs cea)
        {
            base.OnClosing(cea);
            Hide();
            cea.Cancel = true;
        }
    }
}
