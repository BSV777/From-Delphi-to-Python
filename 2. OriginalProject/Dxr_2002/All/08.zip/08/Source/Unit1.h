//---------------------------------------------------------------------------
#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <Grids.hpp>
#include <ToolWin.hpp>
#include <ExtCtrls.hpp>
#include <ImgList.hpp>
#include <Menus.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
  TPanel *Panel1;
  TPanel *PanelView;
  TImageList *ImageList1;
  TControlBar *ControlBar1;
  TToolBar *ToolBar1;
  TToolButton *buttonNew;
  TToolButton *buttonOpen;
  TToolButton *buttonSave;
  TToolBar *ToolBar2;
  TToolButton *buttonCancel;
  TToolButton *buttonAppendButton;
  TToolButton *buttonAppendEdit;
  TToolButton *buttonAppendLabel;
  TToolBar *ToolBar3;
  TToolButton *buttonAlignHLeft;
  TToolButton *buttonAlignHCenter;
  TToolButton *buttonAlignHRight;
  TToolButton *buttonAlignVTop;
  TToolButton *buttonAlignVCenter;
  TToolButton *buttonAlignVBottom;
  TToolButton *ToolButton14;
  TMainMenu *MainMenu1;
  TMenuItem *N1;
  TMenuItem *N2;
  TMenuItem *N4;
  TMenuItem *N5;
  TMenuItem *N6;
  TMenuItem *N7;
  TMenuItem *N8;
  TMenuItem *N9;
  TMenuItem *N3;
  TMenuItem *N10;
  TMenuItem *N11;
  TMenuItem *N12;
  TMenuItem *N13;
  TMenuItem *N14;
  TMenuItem *N15;
  TMenuItem *N16;
  TMenuItem *HTML1;
  TMenuItem *N17;
  TToolButton *buttonErase;
  TToolButton *buttonExport;
  TOpenDialog *OpenDialog1;
  TSaveDialog *SaveDialog1;
  TMenuItem *N18;
  TMenuItem *N19;
  TMenuItem *N20;
  TPanel *Panel5;
  TPanel *Panel4;
  TPanel *Panel6;
  TLabel *Label1;
  TLabel *Label2;
  TLabel *Label5;
  TLabel *labelWidth;
  TLabel *labelHeight;
  TPanel *Panel7;
  TPanel *Panel8;
  TStringGrid *StringGrid1;
  TLabel *Label3;
  TLabel *Label4;
  TLabel *Label7;
  TLabel *labelCount;
  TLabel *labelSelectedCount;
  TLabel *labelX;
  TLabel *labelY;
  TLabel *labelXName;
  TLabel *labelYName;
  TLabel *Label6;
  TToolButton *buttonGrid;
  TToolButton *ToolButton1;
  TMenuItem *N21;
  TMenuItem *N22;
  void __fastcall FormCreate(TObject *Sender);
  void __fastcall FormDestroy(TObject *Sender);
  void __fastcall StringGrid1SetEditText(TObject *Sender, int ACol,
          int ARow, const AnsiString Value);
  void __fastcall buttonAppendButtonClick(TObject *Sender);
  void __fastcall buttonAppendEditClick(TObject *Sender);
  void __fastcall buttonAppendLabelClick(TObject *Sender);
  void __fastcall buttonEraseClick(TObject *Sender);

  void __fastcall buttonNewClick(TObject *Sender);
  void __fastcall buttonOpenClick(TObject *Sender);
  void __fastcall buttonSaveClick(TObject *Sender);
  void __fastcall buttonExportClick(TObject *Sender);
  void __fastcall buttonExitClick(TObject *Sender) ;

  void __fastcall buttonCancelClick(TObject *Sender);
  void __fastcall FormResize(TObject *Sender);
  void __fastcall buttonAlignHLeftClick(TObject *Sender);
  void __fastcall buttonAlignHCenterClick(TObject *Sender);
  void __fastcall buttonAlignHRightClick(TObject *Sender);
  void __fastcall buttonAlignVTopClick(TObject *Sender);
  void __fastcall buttonAlignVCenterClick(TObject *Sender);
  void __fastcall buttonAlignVBottomClick(TObject *Sender);

  void __fastcall buttonHelpClick(TObject *Sender);

  void __fastcall StringGrid1DrawCell(TObject *Sender, int ACol, int ARow,
          TRect &Rect, TGridDrawState State);
  void __fastcall StringGrid1Click(TObject *Sender);
  void __fastcall StringGrid1KeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
  void __fastcall buttonGridClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
  __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
