//---------------------------------------------------------------------------
// 5A6F726368 , ant@home.tula.net
//---------------------------------------------------------------------------
#include <stdio.h>
#include "view.hpp"
//---------------------------------------------------------------
void
ViewData::draw(
  HDC           _hdc,
  int         _viewX,
  int         _viewY,
  Location2D _window)
{
}
//---------------------------------------------------------------
Location2D
ViewData::getLocation(void)
{
  return Location2D(0,0,0,0) ;
}
//---------------------------------------------------------------
void
ViewData::test(Point2D& _point)
{
}
//---------------------------------------------------------------
void
ViewData::select(Location2D _rect)
{
}
//---------------------------------------------------------------
bool
ViewData::startMove(
  Point2D& _point,
  bool     _shift)
{
  return false ;
}
//---------------------------------------------------------------
void
ViewData::move(
  int _deltaX,
  int _deltaY)
{
}
//---------------------------------------------------------------
void
ViewData::endMove(
  int _deltaX,
  int _deltaY)
{
}
//---------------------------------------------------------------
void
ViewData::keyDown(Word& _key,TShiftState _shift)
{
}
//---------------------------------------------------------------
void
ViewData::keyPress(Messages::TWMKey& _message)
{
}
//---------------------------------------------------------------

//---------------------------------------------------------------
__fastcall
ViewWindow::ViewWindow(TWinControl* _owner):
  TWinControl(_owner),
  viewData(0),
  mdc(0),bitmap(0),
  wmsizeLevel(0),
  mouseMode(_none)
{
  Parent=_owner ;
  TabStop=false ;
  //
  SCROLLINFO scrollInfo ;
  scrollInfo.cbSize=sizeof(SCROLLINFO) ;
  scrollInfo.fMask=SIF_ALL ;
  scrollInfo.nMin=0 ;
  scrollInfo.nMax=0 ;
  scrollInfo.nPos=0 ;
  scrollInfo.nPage=0 ;
  SetScrollInfo(this->Handle,SB_HORZ,&scrollInfo,true) ;
  SetScrollInfo(this->Handle,SB_VERT,&scrollInfo,true) ;
  //
  brush=::CreateSolidBrush(RGB(0xE0,0xE0,0xE0)) ;
  logFont.lfHeight=14 ;
  logFont.lfWidth=0 ;
  logFont.lfOrientation=0 ;
  logFont.lfEscapement=0 ;
  logFont.lfWeight=FW_MEDIUM ;
  logFont.lfItalic=0 ;
  logFont.lfUnderline=0 ;
  logFont.lfStrikeOut=0 ;
  logFont.lfCharSet=0 ;
  logFont.lfOutPrecision=0 ;
  logFont.lfClipPrecision=0 ;
  logFont.lfQuality=PROOF_QUALITY ;
  logFont.lfPitchAndFamily=0 ;
  strcpy(logFont.lfFaceName,"Tahoma") ;
}
//---------------------------------------------------------------
__fastcall
ViewWindow::~ViewWindow()
{
  if( mdc ) {
    ::RestoreDC(mdc,mdcSaveIndex) ;
    ::DeleteDC(mdc) ;
  }
  if( bitmap )
    ::DeleteObject(bitmap) ;
  ::DeleteObject(brush) ;
}
//---------------------------------------------------------------

//---------------------------------------------------------------
void __fastcall
ViewWindow::CreateParams(TCreateParams& _params)
{
  TWinControl::CreateParams(_params) ;
  _params.WindowClass.style=CS_DBLCLKS ;
}
//---------------------------------------------------------------
void __fastcall
ViewWindow::WMPaint(Messages::TWMPaint& _message)
{
  if( bitmap ) {
    logFont.lfHeight=14 ;  
    PAINTSTRUCT paint ;
    HDC           hdc=::BeginPaint(Handle,&paint) ;
    HBRUSH  saveBrush=::SelectObject(mdc,::CreateSolidBrush(RGB(255,255,255))) ;
    HPEN      savePen=::SelectObject(mdc,::CreatePen(PS_SOLID,1,RGB(0,0,0))) ;
    HFONT    saveFont=::SelectObject(mdc,::CreateFontIndirect(&logFont)) ;
    ::SetBkMode(mdc,TRANSPARENT) ;
    //
    ::FillRect(mdc,&paint.rcPaint,brush) ;
    int viewX=GetScrollPos(Handle,SB_HORZ),
        viewY=GetScrollPos(Handle,SB_VERT) ;
    if( viewData )
      viewData->draw(mdc,viewX,viewY,Location2D(viewX,viewY,ClientWidth+viewX,ClientHeight+viewY)) ;
    ::BitBlt(hdc,0,0,Width,Height,
             mdc,0,0,SRCCOPY) ;
    //
    ::DeleteObject(::SelectObject(mdc,saveBrush)) ;
    ::DeleteObject(::SelectObject(mdc,savePen)) ;
    ::DeleteObject(::SelectObject(mdc,saveFont)) ;    
    ::EndPaint(Handle,&paint) ;
  }
}
//---------------------------------------------------------------
void __fastcall
ViewWindow::WMEraseBkgnd(Messages::TWMEraseBkgnd& _message)
{
}
//---------------------------------------------------------------
void __fastcall
ViewWindow::WMSize(Messages::TWMSize& _message)
{
  if( !wmsizeLevel ) {
    oldHPosition=GetScrollPos(Handle,SB_HORZ) ;
    oldVPosition=GetScrollPos(Handle,SB_VERT) ;
  }
  //
  wmsizeLevel++ ;
  SCROLLINFO scrollInfo ;
  scrollInfo.cbSize=sizeof(SCROLLINFO) ;
  scrollInfo.fMask=SIF_PAGE ;
  scrollInfo.nPage=ClientWidth ;
  SetScrollInfo(Handle,SB_HORZ,&scrollInfo,true) ;
  scrollInfo.nPage=ClientHeight ;
  SetScrollInfo(Handle,SB_VERT,&scrollInfo,true) ;
  wmsizeLevel-- ;
  //
  if( !wmsizeLevel ) {
    int newHPosition=GetScrollPos(Handle,SB_HORZ),
        newVPosition=GetScrollPos(Handle,SB_VERT) ;
    //
    HDC tempdc=::GetDC(Handle) ;
    //
    if( mdc ) {
      ::RestoreDC(mdc,mdcSaveIndex) ;
      ::DeleteDC(mdc) ;
    }
    if( bitmap )
     ::DeleteObject(bitmap) ;
    //
    mdc=::CreateCompatibleDC(tempdc) ;
    mdcSaveIndex=::SaveDC(mdc) ;
    if( mdc ) {
      bitmap=::CreateDiscardableBitmap(tempdc,ClientWidth,ClientHeight) ;
      if( bitmap )
        ::SelectObject(mdc,bitmap) ;
    }
    //
    ::ReleaseDC(Handle,tempdc) ;
    //
    ScrollBy(oldHPosition-newHPosition,oldVPosition-newVPosition) ;
    //
  }
}
//---------------------------------------------------------------
void __fastcall
ViewWindow::WMTimeChange(Messages::TWMTimer& _message)
{
}
//---------------------------------------------------------------

//---------------------------------------------------------------
void __fastcall
ViewWindow::KeyDown(Word& _key,TShiftState _shift)
{
  if( viewData )
    viewData->keyDown(_key,_shift) ;
}
//---------------------------------------------------------------
void
ViewWindow::mouseMove(void)
{
  MSG       message ;
  POINT startCursor,
             cursor ;
  MouseCapture=true ;
  ::GetCursorPos(&startCursor) ;
  ::ScreenToClient(Handle,&startCursor) ;
  message.message=0 ;
  //
  while( message.message!=WM_LBUTTONUP&&(message.message!=WM_MOUSEMOVE||(message.wParam&MK_LBUTTON)) ) {
    if( ::PeekMessage(&message,0,0,0,PM_REMOVE) ) {
      ::TranslateMessage(&message) ;
      ::DispatchMessage(&message) ;
    }
    //
    ::GetCursorPos(&cursor) ;
    ::ScreenToClient(Handle,&cursor) ;
    if( (cursor.x!=startCursor.x)||(cursor.y!=startCursor.y) )
      viewData->move(cursor.x-startCursor.x,cursor.y-startCursor.y) ;
    //
  }
  viewData->endMove(cursor.x-startCursor.x,cursor.y-startCursor.y) ;
  //
  MouseCapture=false ;
}

void
ViewWindow::mouseSelect(void)
{
  MSG       message ;
  POINT startCursor,
             cursor ;
  int         viewX=GetScrollPos(Handle,SB_HORZ),
              viewY=GetScrollPos(Handle,SB_VERT) ;
  MouseCapture=true ;
  ::GetCursorPos(&startCursor) ;
  ::ScreenToClient(Handle,&startCursor) ;
  message.message=0 ;
  //
  region.enableSelection(Handle,startCursor.x,startCursor.y) ;
  while( message.message!=WM_LBUTTONUP&&(message.message!=WM_MOUSEMOVE||(message.wParam&MK_LBUTTON)) ) {
    if( ::PeekMessage(&message,0,0,0,PM_REMOVE) ) {
      ::TranslateMessage(&message) ;
      ::DispatchMessage(&message) ;
    }
    //
    ::GetCursorPos(&cursor) ;
    ::ScreenToClient(Handle,&cursor) ;
    cursor.x=max(min(int(cursor.x),ClientWidth),0) ;
    cursor.y=max(min(int(cursor.y),ClientHeight),0) ;
    if( (cursor.x!=startCursor.x)||(cursor.y!=startCursor.y) )
      region.select(cursor.x,cursor.y) ;
    startCursor=cursor ;
    //
  }
  region.disableSelection() ;
  if( (region.rect.left!=region.rect.right)&&(region.rect.top!=region.rect.bottom) )
    viewData->select(
      Location2D(
        region.rect.left+viewX,
        region.rect.top+viewY,
        region.rect.right+viewX,
        region.rect.bottom+viewY)) ;
  //
  MouseCapture=false ;
}

void
ViewWindow::mouseScroll(void)
{
  MSG       message ;
  POINT startCursor,
             cursor ;
  int        deltaX,
             deltaY ;
  MouseCapture=true ;
  ::GetCursorPos(&startCursor) ;
  ::ScreenToClient(Handle,&startCursor) ;
  message.message=0 ;
  //
  while( message.message!=WM_RBUTTONUP&&(message.message!=WM_MOUSEMOVE||(message.wParam&MK_RBUTTON)) ) {
    if( ::PeekMessage(&message,0,0,0,PM_REMOVE) ) {
      ::TranslateMessage(&message) ;
      ::DispatchMessage(&message) ;
    }
    //
    ::GetCursorPos(&cursor) ;
    ::ScreenToClient(Handle,&cursor) ;
    if( cursor.x<0 )
      deltaX=cursor.x ;
    else if( cursor.x>=ClientWidth )
      deltaX=cursor.x-ClientWidth ;
    else
      deltaX=cursor.x-startCursor.x ;
    if( cursor.y<0 )
      deltaY=cursor.y ;
    else if( cursor.y>=ClientHeight )
      deltaY=cursor.y-ClientHeight ;
    else
      deltaY=cursor.y-startCursor.y ;
    if( deltaX||deltaY )
      pictureScroll(deltaX,deltaY) ;
    startCursor=cursor ;
    //
  }
  MouseCapture=false ;
}

void __fastcall
ViewWindow::MouseDown(TMouseButton _button,Classes::TShiftState _shift,int _x,int _y)
{
  SetFocus() ;
  //
  if( viewData&&(mouseMode==_none) ) {
    if( _button==mbLeft ) {
      int viewX=GetScrollPos(Handle,SB_HORZ),
          viewY=GetScrollPos(Handle,SB_VERT) ;
      if( viewData->startMove(Point2D(_x+viewX,_y+viewY),_shift.Contains(ssShift)) ) {
        mouseMode=_move ;
        mouseMove() ;
        mouseMode=_none ;
      }
      else {
        mouseMode=_select ;
        mouseSelect() ;
        mouseMode=_none ;
      }
    }
    else if( _button=mbRight ) {
      mouseMode=_select ;
      mouseScroll() ;
      mouseMode=_none ;
    }
  }
}
//---------------------------------------------------------------
void __fastcall
ViewWindow::MouseMove(Classes::TShiftState _shift,int _x,int _y)
{
  if( viewData&&(mouseMode==_none) ) {
    int viewX=GetScrollPos(Handle,SB_HORZ),
        viewY=GetScrollPos(Handle,SB_VERT) ;
    viewData->test(Point2D(_x+viewX,_y+viewY)) ;
  }
}
//---------------------------------------------------------------
void __fastcall
ViewWindow::MouseUp(TMouseButton _button,Classes::TShiftState _shift,int _x,int _y)
{
}
//---------------------------------------------------------------
void __fastcall
ViewWindow::WMHScroll(Messages::TWMScroll& _message)
{
  int oldPosition,
      newPosition ;
  oldPosition=newPosition=GetScrollPos(Handle,SB_HORZ) ;
  switch( _message.ScrollCode ) {
    case SB_LINELEFT      : newPosition=oldPosition-1 ; break ;
    case SB_LINERIGHT     : newPosition=oldPosition+1 ; break ;
    case SB_PAGELEFT      : newPosition=oldPosition-ClientWidth ; break ;
    case SB_PAGERIGHT     : newPosition=oldPosition+ClientWidth ; break ;
    case SB_THUMBTRACK    :
    case SB_THUMBPOSITION : newPosition=_message.Pos ; break ;
    case SB_ENDSCROLL     : break ;
  }
  if( newPosition!=oldPosition ) {
    SetScrollPos(Handle,SB_HORZ,newPosition,true) ;
    newPosition=GetScrollPos(Handle,SB_HORZ) ;
    ScrollBy(oldPosition-newPosition,0) ;
    Update() ;
  }
  _message.Result=0 ;
}
//---------------------------------------------------------------
void __fastcall
ViewWindow::WMVScroll(Messages::TWMScroll& _message)
{
  int oldPosition,
      newPosition ;
  oldPosition=newPosition=GetScrollPos(Handle,SB_VERT) ;
  switch( _message.ScrollCode ) {
    case SB_LINELEFT      : newPosition=oldPosition-1 ; break ;
    case SB_LINERIGHT     : newPosition=oldPosition+1 ; break ;
    case SB_PAGELEFT      : newPosition=oldPosition-ClientHeight ; break ;
    case SB_PAGERIGHT     : newPosition=oldPosition+ClientHeight ; break ;
    case SB_THUMBTRACK    :
    case SB_THUMBPOSITION : newPosition=_message.Pos ; break ;
    case SB_ENDSCROLL     : break ;
  }
  if( newPosition!=oldPosition ) {
    SetScrollPos(Handle,SB_VERT,newPosition,true) ;
    newPosition=GetScrollPos(Handle,SB_VERT) ;
    ScrollBy(0,oldPosition-newPosition) ;
    Update() ;
  }
  _message.Result=0 ;
}
//---------------------------------------------------------------

//---------------------------------------------------------------
void
ViewWindow::setViewData(ViewData* _viewData)
{
  viewData=_viewData ;
  updatePicture() ;
}
//---------------------------------------------------------------
void
ViewWindow::updatePicture(void)
{
  if( viewData ) {
    Location2D location=viewData->getLocation() ;
    SCROLLINFO scrollInfo ;
    scrollInfo.cbSize=sizeof(SCROLLINFO) ;
    scrollInfo.fMask=SIF_RANGE|SIF_PAGE ;
    scrollInfo.nMin=location.x1 ;
    scrollInfo.nMax=location.x2-1 ;
    scrollInfo.nPage=ClientWidth ;
    SetScrollInfo(this->Handle,SB_HORZ,&scrollInfo,true) ;
    scrollInfo.nMin=location.y1 ;
    scrollInfo.nMax=location.y2-1 ;
    scrollInfo.nPage=ClientHeight ;
    SetScrollInfo(this->Handle,SB_VERT,&scrollInfo,true) ;
  }
}
//---------------------------------------------------------------
void
ViewWindow::pictureScroll(
  int    _deltaX,
  int    _deltaY)
{
  int oldHPosition=GetScrollPos(Handle,SB_HORZ),
      oldVPosition=GetScrollPos(Handle,SB_VERT) ;
  //
  SCROLLINFO scrollInfo ;
  scrollInfo.cbSize=sizeof(SCROLLINFO) ;
  scrollInfo.fMask=SIF_POS ;
  scrollInfo.nPos=oldHPosition-_deltaX ;
  SetScrollInfo(Handle,SB_HORZ,&scrollInfo,true) ;
  scrollInfo.nPos=oldVPosition-_deltaY ;
  SetScrollInfo(Handle,SB_VERT,&scrollInfo,true) ;
  //
  int newHPosition=GetScrollPos(Handle,SB_HORZ),
      newVPosition=GetScrollPos(Handle,SB_VERT) ;
  ScrollBy(oldHPosition-newHPosition,oldVPosition-newVPosition) ;
}
//---------------------------------------------------------------
void
ViewWindow::pictureTest(void)
{
  POINT cursor ;
  ::GetCursorPos(&cursor) ;
  ::ScreenToClient(Handle,&cursor) ;
  int viewX=GetScrollPos(Handle,SB_HORZ),
      viewY=GetScrollPos(Handle,SB_VERT) ;
  if( viewData )
    viewData->test(Point2D(cursor.x+viewX,cursor.y+viewY)) ;
}
//---------------------------------------------------------------
void __fastcall
ViewWindow::WMKeyPress(Messages::TWMKey& _message)
{
  if( viewData )
    viewData->keyPress(_message) ;
}
//---------------------------------------------------------------
