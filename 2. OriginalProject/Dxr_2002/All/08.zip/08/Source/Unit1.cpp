//---------------------------------------------------------------------------
// 5A6F726368 , ant@home.tula.net
//---------------------------------------------------------------------------
#include <vcl.h>
#include <vcl\inifiles.hpp>
#include <io.h>
#include <fcntl.h>
#include <share.h>
#pragma hdrstop

#include "Unit1.h"
#include "editor.hpp"
#include "container.hpp"
#include "ffile.hpp"
#include "view.hpp"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
//---------------------------------------------------------------------------
#define _SYNTAX_TAG_OPEN_     '<'
#define _SYNTAX_TAG_CLOSE_    '>'
#define _SYNTAX_EQUAL_        '='
#define _SYNTAX_DELIMITER_    ';'
#define _SYNTAX_TERM_         'T'
#define _SYNTAX_LINE_         'L'

#define _DEFAULT_LEFT_        0
#define _DEFAULT_TOP_         0
#define _DEFAULT_WIDTH_       100
#define _DEFAULT_HEIGHT_      25

#define _MARKER_SIZE_         3

#define _GRID_SIZE_           5

#define _LIMIT_VALUE_         16000

#define _SIMPLE_EDIT_HEIGHT_  25
#define _SIMPLE_LABEL_HEIGHT_ 20
//---------------------------------------------------------------------------

TForm1*          Form1 ;
ViewWindow* viewWindow=0 ;
Editor          editor ;

//---------------------------------------------------------------------------
Content::Content(void):
  content(0),nContent(0),nowContent(0),
  pointer(0),ptrSymbol(0)
{
}
//---------------------------------------------------------------------------
Content::~Content()
{
  clearArray(content,nContent) ;
}
//---------------------------------------------------------------------------
void
Content::clear(void)
{
  nowContent=0 ;
  pointer=0 ;
  ptrSymbol=0 ;
}
//---------------------------------------------------------------------------
inline void
Content::writeToFile(FormatFile& _file)
{
  ::writeToFile(_file,content,nowContent) ;
}
//---------------------------------------------------------------------------
inline void
Content::readFromFile(FormatFile& _file)
{
  int length=_file.length() ;
  resizeArray(content,nContent,length+1,0) ;
  ::readFromFile(_file,content,length) ;
  nowContent=length ;
  content[length]=0 ;
}
//---------------------------------------------------------------------------
inline void
Content::append(
  const char*  _value,
  int         _length)
{
  resizeArray(content,nContent,nowContent+_length,8192) ;
  strncpy(content+nowContent,_value,_length) ;
  nowContent+=_length ;
}
//---------------------------------------------------------------------------
inline void
Content::append(const char* _value)
{
  append(_value,strlen(_value)) ;
}
//---------------------------------------------------------------------------
inline void
Content::append(const AnsiString& _value)
{
  append(_value.c_str(),_value.Length()) ;
}
//---------------------------------------------------------------------------
bool
Content::scan(
  char&   _shape,
  char*&  _value,
  int&   _length)
{
  if( ptrSymbol )
    *ptrSymbol=symbol ;
  while( (pointer<nowContent)&&(strchr(" \r\n",content[pointer])) )
    pointer++ ;
  if( pointer>=nowContent )
    return false ;
  if( strchr("<>=;",content[pointer]) ) {
    _shape=content[pointer] ;
    _value=content+pointer ;
    _length=1 ;
    pointer++ ;
  }
  else if( content[pointer]=='"' ) {
    _shape=_SYNTAX_LINE_ ;
    _value=content+(++pointer) ;
    _length=strcspn(content+pointer,"\"") ;
    pointer+=_length+1 ;
    pointer+=strcspn(content+pointer," \r\n<>=;") ;
  }
  else {
    _shape=_SYNTAX_TERM_ ;
    _value=content+pointer ;
    _length=strcspn(content+pointer," \r\n<>=;") ;
    pointer+=_length ;
  }
  ptrSymbol=_value+_length ;
  symbol=*ptrSymbol ;
  *ptrSymbol='\0' ;
  return true ;
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
int Simple::nowSelected=0 ;
int Simple::countSelected=0 ;
int Simple::moveX1 ;
int Simple::moveY1 ;
int Simple::moveX2 ;
int Simple::moveY2 ;

char* Simple::types[]={
  "Button",
  "TextEdit",
  "Label",
  ""
} ;

char* Simple::properties[]={
  "Left",
  "Top",
  "Width",
  "Height",
  "Text",
  "Caption",
  ""
} ;

char Simple::buffer[255+1] ;
//---------------------------------------------------------------------------
Simple::Simple(void):
  selected(false),selectedOrder(0)
{
  text[255]=0 ;
}
//---------------------------------------------------------------------------
void
Simple::draw(
  HDC _dc,
  int  _x,
  int  _y)
{
  switch( type ) {
    case _button :
      ::DrawFrameControl(_dc,&Rect(location.x1+_x,location.y1+_y,location.x2+_x,location.y2+_y),DFC_BUTTON,DFCS_BUTTONPUSH) ;
      ::DrawText(_dc,text,-1,&Rect(location.x1+_x+2,location.y1+_y+2,location.x2+_x-2,location.y2+_y-2),DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS) ;
      break ;
    case   _edit :
      ::DeleteObject(::SelectObject(_dc,::CreateSolidBrush(ColorToRGB(clWindow)))) ;
      ::Rectangle(_dc,location.x1+_x,location.y1+_y+1,location.x2+_x,location.y2+_y-1) ;
      ::DrawText(_dc,text,-1,&Rect(location.x1+_x+3,location.y1+_y+4,location.x2+_x-3,location.y2+_y-4),DT_LEFT|DT_TOP|DT_SINGLELINE|DT_END_ELLIPSIS) ;
      ::DrawEdge(_dc,&Rect(location.x1+_x,location.y1+_y+1,location.x2+_x,location.y2+_y-1),EDGE_SUNKEN,BF_RECT) ;
      break ;
    case  _label :
      ::DeleteObject(::SelectObject(_dc,::CreateSolidBrush(RGB(0xE0,0xE0,0xE0)))) ;
      ::DeleteObject(::SelectObject(_dc,::CreatePen(PS_SOLID,1,ColorToRGB(clWindow)))) ;
      ::Rectangle(_dc,location.x1+_x,location.y1+_y,location.x2+_x,location.y2+_y) ;
      ::DrawText(_dc,text,-1,&Rect(location.x1+_x,location.y1+_y,location.x2+_x,location.y2+_y),DT_LEFT|DT_TOP|DT_SINGLELINE|DT_END_ELLIPSIS) ;
      break ;
  }
  if( selected )
    drawMarkers(_dc,_x,_y) ;
}
//---------------------------------------------------------------------------
inline void
Simple::drawMarker(
  HDC       _dc,
  int        _x,
  int        _y,
  HBRUSH _brush)
{
  FillRect(_dc,&Rect(_x-_MARKER_SIZE_,_y-_MARKER_SIZE_,_x+_MARKER_SIZE_,_y+_MARKER_SIZE_),_brush) ;
}
//---------------------------------------------------------------------------
void
Simple::drawMarkers(
  HDC _dc,
  int  _x,
  int  _y)
{
  HBRUSH brush=CreateSolidBrush(( nowSelected==1 )?RGB(0x00,0x00,0x00):RGB(0x80,0x80,0x80)) ;
  drawMarker(_dc,location.x1+_x+(( nowSelected==1 )?0:_MARKER_SIZE_),location.y1+_y+(( nowSelected==1 )?0:_MARKER_SIZE_),brush) ;
  if( type!=_edit )
    drawMarker(_dc,(location.x1+location.x2)/2+_x,location.y1+_y+(( nowSelected==1 )?0:_MARKER_SIZE_),brush) ;
  drawMarker(_dc,location.x2+_x-(( nowSelected==1 )?0:_MARKER_SIZE_),location.y1+_y+(( nowSelected==1 )?0:_MARKER_SIZE_),brush) ;
  drawMarker(_dc,location.x1+_x+(( nowSelected==1 )?0:_MARKER_SIZE_),(location.y1+location.y2)/2+_y,brush) ;
  drawMarker(_dc,location.x2+_x-(( nowSelected==1 )?0:_MARKER_SIZE_),(location.y1+location.y2)/2+_y,brush) ;
  drawMarker(_dc,location.x1+_x+(( nowSelected==1 )?0:_MARKER_SIZE_),location.y2+_y-(( nowSelected==1 )?0:_MARKER_SIZE_),brush) ;
  if( type!=_edit )
    drawMarker(_dc,(location.x1+location.x2)/2+_x,location.y2+_y-(( nowSelected==1 )?0:_MARKER_SIZE_),brush) ;
  drawMarker(_dc,location.x2+_x-(( nowSelected==1 )?0:_MARKER_SIZE_),location.y2+_y-(( nowSelected==1 )?0:_MARKER_SIZE_),brush) ;
  DeleteObject(brush) ;
}
//---------------------------------------------------------------------------
bool
Simple::test(Point2D _point)
{
  if( !(selected&&(nowSelected==1)) )
    return false ;
  if( (abs(location.x1-_point.x)<_MARKER_SIZE_)&&(abs(location.y1-_point.y)<_MARKER_SIZE_) )
    viewWindow->Cursor=crSizeNWSE	;
  else if( (type!=_edit)&&(abs((location.x1+location.x2)/2-_point.x)<_MARKER_SIZE_)&&(abs(location.y1-_point.y)<_MARKER_SIZE_) )
    viewWindow->Cursor=crSizeNS	;
  else if( (abs(location.x2-_point.x)<_MARKER_SIZE_)&&(abs(location.y1-_point.y)<_MARKER_SIZE_) )
    viewWindow->Cursor=crSizeNESW	;
  else if( (abs(location.x1-_point.x)<_MARKER_SIZE_)&&(abs(location.y2-_point.y)<_MARKER_SIZE_) )
    viewWindow->Cursor=crSizeNESW	;
  else if( (type!=_edit)&&(abs((location.x1+location.x2)/2-_point.x)<_MARKER_SIZE_)&&(abs(location.y2-_point.y)<_MARKER_SIZE_) )
    viewWindow->Cursor=crSizeNS	;
  else if( (abs(location.x2-_point.x)<_MARKER_SIZE_)&&(abs(location.y2-_point.y)<_MARKER_SIZE_) )
    viewWindow->Cursor=crSizeNWSE	;
  else if( (abs(location.x1-_point.x)<_MARKER_SIZE_)&&(abs((location.y1+location.y2)/2-_point.y)<_MARKER_SIZE_) )
    viewWindow->Cursor=crSizeWE	;
  else if( (abs(location.x2-_point.x)<_MARKER_SIZE_)&&(abs((location.y1+location.y2)/2-_point.y)<_MARKER_SIZE_) )
    viewWindow->Cursor=crSizeWE	;
  else
    return false ;
  return true ;
}
//---------------------------------------------------------------------------
inline void
Simple::setMode(void)
{
  moveX1=moveY1=moveX2=moveY2=1 ;
}
//---------------------------------------------------------------------------
inline void
Simple::alignMode(void)
{
  moveX1=moveY1=moveX2=moveY2=1 ;
}
//---------------------------------------------------------------------------
inline void
Simple::appendMode(void)
{
  moveX1=moveY1=0 ;
  moveX2=moveY2=1 ;
}
//---------------------------------------------------------------------------
void
Simple::select(bool _selected)
{
  if( selected!=_selected ) {
    countSelected++ ;
    nowSelected+=( _selected )?1:-1 ;
    selected=_selected ;
    selectedOrder=countSelected ;
  }
}
//---------------------------------------------------------------------------
bool
Simple::startMove(Point2D& _point)
{
  moveX1=moveY1=moveX2=moveY2=0 ;
  if( selected&&(nowSelected==1) ) {
    if( (abs(location.x1-_point.x)<_MARKER_SIZE_)&&(abs(location.y1-_point.y)<_MARKER_SIZE_) )
      moveX1=moveY1=1 ;
    else if( (abs((location.x1+location.x2)/2-_point.x)<_MARKER_SIZE_)&&(abs(location.y1-_point.y)<_MARKER_SIZE_) )
      moveY1=1 ;
    else if( (abs(location.x2-_point.x)<_MARKER_SIZE_)&&(abs(location.y1-_point.y)<_MARKER_SIZE_) )
      moveY1=moveX2=1 ;
    else if( (abs(location.x1-_point.x)<_MARKER_SIZE_)&&(abs(location.y2-_point.y)<_MARKER_SIZE_) )
      moveX1=moveY2=1 ;
    else if( (abs((location.x1+location.x2)/2-_point.x)<_MARKER_SIZE_)&&(abs(location.y2-_point.y)<_MARKER_SIZE_) )
      moveY2=1 ;
    else if( (abs(location.x2-_point.x)<_MARKER_SIZE_)&&(abs(location.y2-_point.y)<_MARKER_SIZE_) )
      moveY2=moveX2=1 ;
    else if( (abs(location.x1-_point.x)<_MARKER_SIZE_)&&(abs((location.y1+location.y2)/2-_point.y)<_MARKER_SIZE_) )
      moveX1=1 ;
    else if( (abs(location.x2-_point.x)<_MARKER_SIZE_)&&(abs((location.y1+location.y2)/2-_point.y)<_MARKER_SIZE_) )
      moveX2=1 ;
  }
  if( type==_edit )
    moveY1=moveY2=0 ;
  if( (!(moveX1+moveY1+moveX2+moveY2))&&location.contain(_point) )
    moveX1=moveY1=moveX2=moveY2=1 ;
  return moveX1+moveY1+moveX2+moveY2 ;
}
//---------------------------------------------------------------------------
void
Simple::move(
  int _deltaX,
  int _deltaY)
{
  location.x1=baseLocation.x1+moveX1*_deltaX ;
  location.y1=baseLocation.y1+moveY1*_deltaY ;
  location.x2=baseLocation.x2+moveX2*_deltaX ;
  location.y2=baseLocation.y2+moveY2*_deltaY ;
  if( type==_edit )
    location.y2=location.y1+_SIMPLE_EDIT_HEIGHT_ ;
  else if( (type==_label)&&(location.height()<_SIMPLE_LABEL_HEIGHT_) )
    location.y2=location.y1+_SIMPLE_LABEL_HEIGHT_ ;
  location.normalize() ;
}
//---------------------------------------------------------------------------
void
Simple::set(
  int   _left,
  int    _top,
  int  _width,
  int _height)
{
  location.x1=_left ;
  location.y1=_top ;
  location.x2=_left+_width ;
  location.y2=_top+_height ;
  if( type==_edit )
    location.y2=location.y1+_SIMPLE_EDIT_HEIGHT_ ;
  else if( (type==_label)&&(location.height()<_SIMPLE_LABEL_HEIGHT_) )
    location.y2=location.y1+_SIMPLE_LABEL_HEIGHT_ ;
}
//---------------------------------------------------------------------------
inline void
Simple::commit(void)
{
  baseLocation=location ;
}                                  
//---------------------------------------------------------------------------
inline void
Simple::rollback(void)
{
  location=baseLocation ;
}
//---------------------------------------------------------------------------
void
Simple::toText(Content& _content)
{
  strncpy(buffer,text,sizeof(buffer)-1) ;
  char* ptrBuffer=buffer ;
  while( (ptrBuffer=strchr(buffer,'"')) )
    *ptrBuffer++='\'' ;
  //
  _content.append(
    Format("<%s %s=\"%d\";%s=\"%d\";%s=\"%d\";%s=\"%d\";%s=\"%s\">\r\n",
    ARRAYOFCONST((types[type],
                  properties[0],location.x1,
                  properties[1],location.y1,
                  properties[2],location.width(),
                  properties[3],location.height(),
                  properties[(( type==_button )?5:4)],
                  buffer)))) ;
}
//---------------------------------------------------------------------------
void
Simple::toHTML(
  Content& _content,
  int        _hSpan,
  int        _vSpan)
{
  strncpy(buffer,text,sizeof(buffer)-1) ;
  char* ptrBuffer=buffer ;
  while( (ptrBuffer=strchr(buffer,'"')) )
    *ptrBuffer++='\'' ;
  //
  String spanStr ;
  if( _hSpan>1 )
    spanStr=spanStr+Format(" colspan=%d",ARRAYOFCONST((_hSpan))) ;
  if( _vSpan>1 )
    spanStr=spanStr+Format(" rowspan=%d",ARRAYOFCONST((_vSpan))) ;
  switch( type ) {
    case _button :
      _content.append(Format("<td%s>\r\n<input type=button width=%d height=%d style=\"width:%d;height:%d\" value=\"%s\"></td>",ARRAYOFCONST((spanStr,location.width(),location.height(),location.width(),location.height(),buffer)))) ;
      break ;
    case   _edit :
      _content.append(Format("<td%s>\r\n<input type=edit size=%d style=\"width:%d;height:%d\" value=\"%s\"></td>",ARRAYOFCONST((spanStr,max(1,int(float(location.width()-10)/9+.5f)),location.width(),location.height()-2,buffer)))) ;
      break ;
    case  _label :
      _content.append(Format("<td%s>\r\n<span style=\"width:%d;height:%d\">%s</span></td>",ARRAYOFCONST((spanStr,location.width(),location.height(),buffer)))) ;
      break ;
  }
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
Editor::Editor(void):
  ViewData(),
  simple(0),nSimple(0),nowSimple(0),
  insertType(-1),
  inMoveMode(false),
  nowProperties(0),
  simpleIndex(-1)
{
}
//---------------------------------------------------------------------------
Editor::~Editor()
{
  clearArray(simple,nSimple) ;
}
//---------------------------------------------------------------------------
void
Editor::draw(
  HDC           _dc,
  int         _viewX,
  int         _viewY,
  Location2D _window)
{
  for(int i=0;i<nowSimple;i++)
    if( !simple[i].selected )
      if( _window.cross(simple[i].location) )
        simple[i].draw(_dc,-_viewX,-_viewY) ;
  for(int i=0;i<nowSimple;i++)
    if( simple[i].selected )
      simple[i].draw(_dc,-_viewX,-_viewY) ;
  //
  if( inMoveMode&&Simple::nowSelected ) {
    //
    Location2D selectedLocation ;
    for(int i=0;i<nowSimple;i++)
      if( simple[i].selected )
        selectedLocation.include(simple[i].location) ;
    String hintPosition=Format("%d , %d",ARRAYOFCONST((selectedLocation.x1,selectedLocation.y1))),
               hintSize=Format("%d x %d",ARRAYOFCONST((selectedLocation.width(),selectedLocation.height()))) ;
    //
    POINT cursor ;
    ::GetCursorPos(&cursor) ;
    ::ScreenToClient(viewWindow->Handle,&cursor) ;
    int x=cursor.x+10,
        y=cursor.y+20 ;
    viewWindow->getFont()->lfHeight=13 ;
    ::DeleteObject(::SelectObject(_dc,::CreateSolidBrush(ColorToRGB(clInfoBk)))) ;
    ::DeleteObject(::SelectObject(_dc,::CreatePen(PS_SOLID,1,ColorToRGB(clWindowFrame)))) ;
    ::DeleteObject(::SelectObject(_dc,::CreateFontIndirect(viewWindow->getFont()))) ;
    TRect  rect(0,0,0,0) ;
    int   width=0 ;
    DrawText(_dc,hintPosition.c_str(),-1,&rect,DT_SINGLELINE|DT_CALCRECT) ;
    width=max(width,int(rect.right-1)) ;
    DrawText(_dc,hintSize.c_str(),-1,&rect,DT_SINGLELINE|DT_CALCRECT) ;
    width=max(width,int(rect.right-1)) ;
    RoundRect(_dc,x,y,x+4+4+width,y+32,5,5) ;
    TextOut(_dc,x+4,y+3,hintPosition.c_str(),hintPosition.Length()) ;
    TextOut(_dc,rect.left+x+4,y+12+3,hintSize.c_str(),hintSize.Length()) ;
  }
}
//---------------------------------------------------------------------------
void
Editor::keyDown(Word& _key,TShiftState _shift)
{
  if( _key==VK_DELETE )
    erase() ;
}
//---------------------------------------------------------------------------
void
Editor::keyPress(Messages::TWMKey& _message)
{
  if( nowProperties==5 ) {
    Form1->StringGrid1->SetFocus() ;
    Form1->StringGrid1->Row=4 ;
    SendMessage(Form1->StringGrid1->Handle,WM_CHAR,_message.CharCode,_message.KeyData) ;
  }
}
//---------------------------------------------------------------------------
void
Editor::clear(void)
{
  for(int i=0;i<nowSimple;i++)
    simple[i].select(false) ;
  nowSimple=0 ;
  update() ;
}
//---------------------------------------------------------------------------
void
Editor::append(
  int     _type,
  int     _left,
  int      _top,
  int    _width,
  int   _height,
  char*   _text)
{
  resizeArray(simple,nSimple,nowSimple+1) ;
  simple[nowSimple].type=_type ;
  simple[nowSimple].baseLocation.clear() ;
  simple[nowSimple].baseLocation.include(Point2D(_left,_top)) ;
  simple[nowSimple].baseLocation.include(Point2D(_left+_width,_top+_height)) ;
  simple[nowSimple].location=simple[nowSimple].baseLocation ;
  strncpy(simple[nowSimple].text,_text,sizeof(simple[nowSimple].text)-1) ;
  simple[nowSimple].selected=false ;
  nowSimple++ ;
}
//---------------------------------------------------------------------------
void
Editor::erase(void)
{
  for(int i=0;i<nowSimple;i++)
    if( simple[i].selected ) {
      simple[i].select(false) ;
      removeFromArray(simple,nowSimple,i--) ;
    }
  //
  viewWindow->pictureTest() ;
  update() ;
}
//---------------------------------------------------------------------------
void
Editor::test(Point2D& _point)
{
  Form1->labelX->Caption=IntToStr(_point.x) ;
  Form1->labelY->Caption=IntToStr(_point.y) ;
  //
  if( insertType!=-1 ) {
    viewWindow->Cursor=crDrag ;
    return ;
  }
  else
    for(int i=0;i<nowSimple;i++)
      if( simple[i].test(_point) )
        return ;
  viewWindow->Cursor=crArrow ;
}
//---------------------------------------------------------------------------
void
Editor::select(Location2D _rect)
{
  for(int i=0;i<nowSimple;i++)
    simple[i].select(simple[i].location.cross(_rect)) ;
  //
  update() ;
}
//---------------------------------------------------------------------------
bool
Editor::startMove(
  Point2D& _point,
  bool     _shift)
{
  deltaX=deltaY=0 ;
  Point2D point=_point ;
  if( Form1->buttonGrid->Down ) {
    point.x=(point.x+_GRID_SIZE_/2)/_GRID_SIZE_*_GRID_SIZE_ ;
    point.y=(point.y+_GRID_SIZE_/2)/_GRID_SIZE_*_GRID_SIZE_ ;
  }
  //
  if( insertType!=-1 )
    for(int i=0;i<nowSimple;i++)
      simple[i].select(false) ;
  //
  int selectedIndex=-1 ;
  for(int i=0;i<nowSimple;i++)
    if( simple[i].startMove(_point) ) {
      selectedIndex=i ;
      break ;
    }
  //
  if( (selectedIndex!=-1)&&(insertType!=-1) ) {
    insertType=-1 ;
    Form1->buttonAppendButton->Down=false ;
    Form1->buttonAppendEdit->Down=false ;
    Form1->buttonAppendLabel->Down=false ;
  }
  if( (selectedIndex==-1)&&(insertType!=-1) ) {
    selectedIndex=nowSimple ;
    append(insertType,point.x,point.y,_DEFAULT_WIDTH_,_DEFAULT_HEIGHT_,"") ;
    simple[selectedIndex].select(true) ;
    simple[selectedIndex].appendMode() ;
    deltaX=-_DEFAULT_WIDTH_ ;
    deltaY=-_DEFAULT_HEIGHT_ ;
  }
  //
  if( (!_shift)&&(!((selectedIndex!=-1)&&(simple[selectedIndex].selected))) )
    for(int i=0;i<nowSimple;i++)
      if( i!=selectedIndex )
        simple[i].select(false) ;
  if( selectedIndex!=-1 )
    simple[selectedIndex].select(( _shift )?(!simple[selectedIndex].selected):true) ;
  //
  test(_point) ;
  //
  inMoveMode=( selectedIndex!=-1 ) ;
  update() ;
  //
  return ( selectedIndex!=-1 ) ;
}
//---------------------------------------------------------------------------
void
Editor::move(
  int _deltaX,
  int _deltaY)
{
  if( Form1->buttonGrid->Down ) {
    _deltaX=(_deltaX+_GRID_SIZE_/2)/_GRID_SIZE_*_GRID_SIZE_ ;
    _deltaY=(_deltaY+_GRID_SIZE_/2)/_GRID_SIZE_*_GRID_SIZE_ ;
  }
  //
  for(int i=0;i<nowSimple;i++)
    if( simple[i].selected )
      simple[i].move(_deltaX+deltaX,_deltaY+deltaY) ;
  //
  viewWindow->Invalidate() ;
}
//---------------------------------------------------------------------------
void
Editor::endMove(
  int _deltaX,
  int _deltaY)
{
  if( Form1->buttonGrid->Down ) {
    _deltaX=(_deltaX+_GRID_SIZE_/2)/_GRID_SIZE_*_GRID_SIZE_ ;
    _deltaY=(_deltaY+_GRID_SIZE_/2)/_GRID_SIZE_*_GRID_SIZE_ ;
  }
  //
  Location2D tempLocation ;
  for(int i=0;i<nowSimple;i++)
    if( simple[i].selected )
      tempLocation.include(simple[i].location) ;
  if( (tempLocation.x1<0)||(tempLocation.y1<0) ) {
    int deltaX=_deltaX-min(tempLocation.x1,0),
        deltaY=_deltaY-min(tempLocation.y1,0) ;
    for(int i=0;i<nowSimple;i++)
      if( simple[i].selected )
        simple[i].move(deltaX,deltaY) ;
  }
  //
  bool crossed=!check() ;
  //
  if( (insertType!=-1)&&(simpleIndex!=-1)&&
      ((!simple[simpleIndex].location.width())||
       (!simple[simpleIndex].location.height())||crossed) ) {
    simple[simpleIndex].select(false) ;
    removeFromArray(simple,nowSimple,simpleIndex) ;
  }
  else {
    insertType=-1 ;
    Form1->buttonAppendButton->Down=false ;
    Form1->buttonAppendEdit->Down=false ;
    Form1->buttonAppendLabel->Down=false ;
  }
  //
  for(int i=0;i<nowSimple;i++)
    if( simple[i].selected )
      ( !crossed )?simple[i].commit():simple[i].rollback() ;
  //
  inMoveMode=false ;
  update() ;
}
//---------------------------------------------------------------------------
void
Editor::set(
  int    _left,
  int     _top,
  int   _width,
  int  _height,
  bool   _init)
{
  if( (!inMoveMode)&&Simple::nowSelected ) {
    if( Simple::nowSelected==1 )
      simple[simpleIndex].set(_left,_top,_width,_height) ;
    else {
      Location2D tempLocation ;
      for(int i=0;i<nowSimple;i++)
        if( simple[i].selected )
          tempLocation.include(simple[i].baseLocation) ;
      int deltaX=_left-tempLocation.x1,
          deltaY=_top-tempLocation.y1 ;
      simple[simpleIndex].setMode() ;
      for(int i=0;i<nowSimple;i++)
        if( simple[i].selected )
          simple[i].move(deltaX,deltaY) ;
    }
    bool crossed=!check() ;
    for(int i=0;i<nowSimple;i++)
      if( simple[i].selected )
        ( !crossed )?simple[i].commit():simple[i].rollback() ;
    //
    update(_init) ;
  }
}
//---------------------------------------------------------------------------
void
Editor::set(const String& _value)
{
  if( simpleIndex!=-1 ) {
    strncpy(simple[simpleIndex].text,_value.c_str(),sizeof(simple[simpleIndex].text)-1) ;
    //
    if( simple[simpleIndex].type!=Simple::_edit ) {
      HDC     tempdc=::GetDC(viewWindow->Handle) ;
      HFONT saveFont=::SelectObject(tempdc,::CreateFontIndirect(viewWindow->getFont())) ;
      TRect     rect(0,0,0,0) ;
      DrawText(tempdc,simple[simpleIndex].text,-1,&rect,DT_SINGLELINE|DT_CALCRECT) ;
      ::DeleteObject(::SelectObject(tempdc,saveFont)) ;
      ::ReleaseDC(viewWindow->Handle,tempdc) ;
      //
      rect.Right+=_GRID_SIZE_*2 ;
      if( Form1->buttonGrid->Down )
        rect.Right=rect.Right/_GRID_SIZE_*_GRID_SIZE_ ;
      if( rect.Right>simple[simpleIndex].location.width() )
        set(simple[simpleIndex].location.x1,simple[simpleIndex].location.y1,
            rect.Right,simple[simpleIndex].location.height(),false) ;
    }
    viewWindow->Invalidate() ;
  }
}
//---------------------------------------------------------------------------
void
Editor::align(int _mode)
{
  int targetIndex=-1 ;
  int targetOrder=Simple::countSelected+1 ;
  for(int i=0;i<nowSimple;i++)
    if( simple[i].selected&&(simple[i].selectedOrder<targetOrder) ) {
      targetIndex=i ;
      targetOrder=simple[i].selectedOrder ;
    }

  if( Simple::nowSelected>1 ) {
    int deltaX,
        deltaY ;
    simple[targetIndex].alignMode() ;
    for(int i=0;i<nowSimple;i++)
      if( simple[i].selected ) {
        switch( _mode ) {
          case   _hLeft :
            deltaX=simple[targetIndex].location.x1-simple[i].location.x1 ;
            deltaY=0 ;
            break ;
          case _hCenter :
            deltaX=(simple[targetIndex].location.x1+simple[targetIndex].location.x2-simple[i].location.x1-simple[i].location.x2)/2 ;
            deltaY=0 ;
            break ;
          case  _hRight :
            deltaX=simple[targetIndex].location.x2-simple[i].location.x2 ;
            deltaY=0 ;
            break ;
          case    _vTop :
            deltaX=0 ;
            deltaY=simple[targetIndex].location.y1-simple[i].location.y1 ;
            break ;
          case _vCenter :
            deltaX=0 ;
            deltaY=(simple[targetIndex].location.y1+simple[targetIndex].location.y2-simple[i].location.y1-simple[i].location.y2)/2 ;
            break ;
          case _vBottom :
            deltaX=0 ;
            deltaY=simple[targetIndex].location.y2-simple[i].location.y2 ;
            break ;
        }
        if( (simple[i].location.x1+deltaX)<0 )
          deltaX=-simple[i].location.x1 ;
        if( (simple[i].location.y1+deltaY)<0 )
          deltaY=-simple[i].location.y1 ;
        simple[i].move(deltaX,deltaY) ;
      }
    bool crossed=!check() ;
    for(int i=0;i<nowSimple;i++)
      if( simple[i].selected )
        ( !crossed )?simple[i].commit():simple[i].rollback() ;
  }
  update() ;
}
//---------------------------------------------------------------------------
bool
Editor::check(void)
{
  for(int i=0;i<nowSimple;i++)
    if( simple[i].selected ) {
      if( (simple[i].location.x1<0)||(simple[i].location.x1>_LIMIT_VALUE_)||
          (simple[i].location.y1<0)||(simple[i].location.y1>_LIMIT_VALUE_)||
          (simple[i].location.width()<=0)||(simple[i].location.width()>_LIMIT_VALUE_)||
          (simple[i].location.height()<=0)||(simple[i].location.height()>_LIMIT_VALUE_) )
        return false ;
      for(int j=0;j<nowSimple;j++)
        if( j!=i )
          if( simple[i].location.cross(simple[j].location) )
            return false ;
    }
  return true ;
}
//---------------------------------------------------------------------------
void
Editor::update(bool _init)
{
  location.clear() ;
  location.include(Point2D()) ;
  Location2D selectedLocation ;
  simpleIndex=-1 ;
  for(int i=0;i<nowSimple;i++) {
    location.include(simple[i].location) ;
    if( simple[i].selected ) {
      selectedLocation.include(simple[i].location) ;
      if( Simple::nowSelected==1 )
        simpleIndex=i ;
    }
  }
  if( viewWindow ) {
    viewWindow->updatePicture() ;
    viewWindow->Invalidate() ;
    //
    Form1->labelWidth->Caption=IntToStr(location.width()) ;
    Form1->labelHeight->Caption=IntToStr(location.height()) ;
    Form1->labelCount->Caption=IntToStr(nowSimple) ;
    Form1->labelSelectedCount->Caption=IntToStr(Simple::nowSelected) ;
    //
    if( Simple::nowSelected==0 ) {
      nowProperties=0 ;
    }
    else if( simpleIndex!=-1 ) {
      nowProperties=5 ;
      Form1->StringGrid1->Cells[0][0]=Simple::properties[0] ;
      Form1->StringGrid1->Cells[0][1]=Simple::properties[1] ;
      Form1->StringGrid1->Cells[0][2]=Simple::properties[2] ;
      Form1->StringGrid1->Cells[0][3]=Simple::properties[3] ;
      Form1->StringGrid1->Cells[0][4]=( simple[simpleIndex].type==Simple::_button )?Simple::properties[5]:Simple::properties[4] ;
      Form1->StringGrid1->Cells[1][0]=IntToStr(selectedLocation.x1) ;
      Form1->StringGrid1->Cells[1][1]=IntToStr(selectedLocation.y1) ;
      Form1->StringGrid1->Cells[1][2]=IntToStr(selectedLocation.width()) ;
      Form1->StringGrid1->Cells[1][3]=IntToStr(selectedLocation.height()) ;
      if( _init )
        Form1->StringGrid1->Cells[1][4]=simple[simpleIndex].text ;
    }
    else {
      nowProperties=2 ;
      Form1->StringGrid1->Cells[0][0]=String("* ")+Simple::properties[0] ;
      Form1->StringGrid1->Cells[0][1]=String("* ")+Simple::properties[1] ;
      Form1->StringGrid1->Cells[1][0]=IntToStr(selectedLocation.x1) ;
      Form1->StringGrid1->Cells[1][1]=IntToStr(selectedLocation.y1) ;
    }
    Form1->StringGrid1->RowCount=nowProperties ;
    Form1->StringGrid1->Height=max(0,nowProperties*(Form1->StringGrid1->DefaultRowHeight+1)-1) ;
    Form1->labelX->Caption="" ;
    Form1->labelY->Caption="" ;
  }
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
struct IntegerRef {

  int value ;

  IntegerRef(int _value):
    value(_value)
  {
  }

  int
  compare(int _value)
  {
    return value-_value ;
  }

} ;

inline void
appendLine(
  int*&    _line,
  int&    _nLine,
  int&  _nowLine,
  int     _value)
{
  int index ;
  if( !searchInArray(&IntegerRef(_value),index,_line,_nowLine) ) {
    resizeArray(_line,_nLine,_nowLine+1,255) ;
    insertInArray(_line,_nowLine,index) ;
    _line[index]=_value ;
  }
}

struct SimpleList {
  int  index ;
  int hLine1 ;
  int vLine1 ;
  int hLine2 ;
  int vLine2 ;
} ;

struct SimpleListRef {

  int hLine ;
  int vLine ;

  SimpleListRef(
    int _hLine,
    int _vLine):
    hLine(_hLine),vLine(_vLine)
  {
  }

  int
  compare(SimpleList& _simpleList)
  {
    int result=vLine-_simpleList.vLine1 ;
    return ( result )?result:(hLine-_simpleList.hLine1) ;
  }

} ;

void
Editor::toHTML(Content& _content)
{
  int*                hLine=0 ;
  int                nHLine=0 ;
  int              nowHLine=0 ;
  int*                vLine=0 ;
  int                nVLine=0 ;
  int              nowVLine=0 ;
  int              maxHLine=0 ;
  int              maxVLine=0 ;
  SimpleList*    simpleList=0 ;
  int           nSimpleList=0 ;
  int         nowSimpleList=0 ;
  char*               pixel=0 ;
  int             nowHPixel ;
  int             nowVPixel ;
  Location2D*   ptrLocation ;
  int                 index ;
  int                hLine1 ;
  int                vLine1 ;
  int                hLine2 ;
  int                vLine2 ;
  SimpleList* ptrSimpleList ;
  Simple*         ptrSimple ;
  int                pixelH ;
  int                pixelV ;
  char*            ptrPixel ;
  int                 tempH ;
  int                 tempV ;
  char*        tempPtrPixel ;
  int                 hSpan ;
  int                 vSpan ;
  bool             crossing,
                  hCrossing,
                  vCrossing ;
  String            spanStr ;
  // �����
  appendLine(hLine,nHLine,nowHLine,0) ;
  appendLine(vLine,nVLine,nowVLine,0) ;
  for(int i=0;i<nowSimple;i++) {
    ptrLocation=&(simple[i].location) ;
    if( ptrLocation->width()&&ptrLocation->height() ) {
      appendLine(hLine,nHLine,nowHLine,ptrLocation->x1) ;
      appendLine(vLine,nVLine,nowVLine,ptrLocation->y1) ;
      if( ptrLocation->x2>maxHLine )
        maxHLine=ptrLocation->x2 ;
      if( ptrLocation->y2>maxVLine )
        maxVLine=ptrLocation->y2 ;
    }
  }
  appendLine(hLine,nHLine,nowHLine,maxHLine) ;
  appendLine(vLine,nVLine,nowVLine,maxVLine) ;
  // ��������
  nowHPixel=nowHLine-1 ;
  nowVPixel=nowVLine-1 ;
  pixel=(char*)calloc(nowHPixel*nowVPixel,sizeof(*pixel)) ;
  //
  resizeArray(simpleList,nSimpleList,nowSimple) ;
  for(int i=0;i<nowSimple;i++) {
    ptrLocation=&(simple[i].location) ;
    if( ptrLocation->width()&&ptrLocation->height() ) {
      searchInArray(&IntegerRef(ptrLocation->x1),hLine1,hLine,nowHLine) ;
      searchInArray(&IntegerRef(ptrLocation->y1),vLine1,vLine,nowVLine) ;
      searchInArray(&IntegerRef(ptrLocation->x2),hLine2,hLine,nowHLine) ;
      searchInArray(&IntegerRef(ptrLocation->y2),vLine2,vLine,nowVLine) ;
      //
      searchInArray(&SimpleListRef(hLine1,vLine1),index,simpleList,nowSimpleList) ;
      insertInArray(simpleList,nowSimpleList,index) ;
      simpleList[index].index=i ;
      simpleList[index].hLine1=hLine1 ;
      simpleList[index].vLine1=vLine1 ;
      simpleList[index].hLine2=hLine2 ;
      simpleList[index].vLine2=vLine2 ;
      // �������
      for(tempV=vLine1;tempV<vLine2;tempV++) {
        tempPtrPixel=pixel+tempV*nowHPixel ;
        for(tempH=hLine1;tempH<hLine2;tempH++)
          tempPtrPixel[tempH]=1 ;
      }
      pixel[vLine1*nowHPixel+hLine1]=2 ;
    }
  }
  //
  for(int i=0;i<nowSimpleList;i++) {
    ptrSimpleList=simpleList+i ;
    hLine1=ptrSimpleList->hLine1 ;
    vLine1=ptrSimpleList->vLine1 ;
    hLine2=ptrSimpleList->hLine2 ;
    vLine2=ptrSimpleList->vLine2 ;
    //
    hCrossing=vCrossing=false ;
    while( (!hCrossing)||(!vCrossing) ) {
      // ������� �� �����������
      if( !hCrossing ) {
        if( hLine2<nowHPixel ) {
          for(tempV=vLine1;tempV<vLine2;tempV++)
            if( pixel[tempV*nowHPixel+hLine2] ) {
              hCrossing=true ;
              break ;
            }
          if( !hCrossing ) {
            for(tempV=vLine1;tempV<vLine2;tempV++)
              pixel[tempV*nowHPixel+hLine2]=1 ;
            hLine2++ ;
          }
        }
        else
          hCrossing=true ;
      }
      // ������� �� ���������
      if( !vCrossing ) {
        if( vLine2<nowVPixel ) {
          tempPtrPixel=pixel+vLine2*nowHPixel ;
          for(tempH=hLine1;tempH<hLine2;tempH++)
            if( tempPtrPixel[tempH] ) {
              vCrossing=true ;
              break ;
            }
          if( !vCrossing ) {
            for(tempH=hLine1;tempH<hLine2;tempH++)
              tempPtrPixel[tempH]=1 ;
            vLine2++ ;
          }
        }
        else
          vCrossing=true ;
      }
    }
    //
    ptrSimpleList->hLine1=hLine1 ;
    ptrSimpleList->vLine1=vLine1 ;
    ptrSimpleList->hLine2=hLine2 ;
    ptrSimpleList->vLine2=vLine2 ;
  }
  //
  _content.append(
    "<html>"
    "<title>Form Editor</title>"
    "<style>TD{vertical-align:top} INPUT{font-size:12;font-family:Tahoma} SPAN{font-size:12;font-family:Tahoma}</style>"
    "<body bgcolor=#FFFFFF>"
    "\r\n<form>"
    "<table border=0 cellspacing=0 cellpadding=0 width=100% height=100%><td align=center style=\"vertical-align:middle\">"
    "<table border=0 cellspacing=0 cellpadding=1 bgcolor=#000000><td>"
    "<table border=0 cellspacing=0 cellpadding=10 bgcolor=#E0E0E0><td>"
    "\r\n<table border=0 cellspacing=0 cellpadding=0>") ;
  // �������
  _content.append("<tr><td><image src=_.gif width=1 height=1></td>") ;
  for(int pixelH=0;pixelH<nowHPixel;pixelH++)
    _content.append(Format("<td><img src=_ width=%d height=1></td>",ARRAYOFCONST((hLine[pixelH+1]-hLine[pixelH])))) ;
  _content.append("</tr>") ;
  //
  for(pixelV=0;pixelV<nowVPixel;pixelV++) {
    ptrPixel=pixel+pixelV*nowHPixel ;
    // �������
    _content.append(Format("<tr><td><img src=_ width=1 height=%d></td>",ARRAYOFCONST((vLine[pixelV+1]-vLine[pixelV])))) ;
    for(pixelH=0;pixelH<nowHPixel;pixelH++) {
      if( ptrPixel[pixelH]==2 ) {
        // ������
        ptrSimpleList=searchInArray(&SimpleListRef(pixelH,pixelV),index,simpleList,nowSimpleList) ;
        hSpan=ptrSimpleList->hLine2-ptrSimpleList->hLine1 ;
        vSpan=ptrSimpleList->vLine2-ptrSimpleList->vLine1 ;
        ptrSimple=simple+ptrSimpleList->index ;
        // �������
        ptrSimple->toHTML(_content,hSpan,vSpan) ;
        //
        pixelH+=hSpan-1 ;
      }
      else if( !ptrPixel[pixelH] ) {
        // ������������
        hSpan=vSpan=1 ;
        crossing=false ;
        // ������� �� �����������
        while( (!ptrPixel[pixelH+hSpan])&&((pixelH+hSpan)<nowHPixel) )
          hSpan++ ;
        // ������� �� ���������
        while( (pixelV+vSpan)<nowVPixel ) {
          tempPtrPixel=pixel+(pixelV+vSpan)*nowHPixel ;
          for(tempH=pixelH+hSpan-1;tempH>=pixelH;tempH--)
            if( tempPtrPixel[tempH] ) {
              crossing=true ;
              break ;
            }
          if( crossing )
            break ;
          vSpan++ ;
        }
        // �������
        for(tempV=pixelV+vSpan-1;tempV>pixelV;tempV--) {
          tempPtrPixel=pixel+tempV*nowHPixel ;
          for(tempH=pixelH+hSpan-1;tempH>=pixelH;tempH--)
            tempPtrPixel[tempH]=1 ;
        }
        //
        pixelH+=hSpan-1 ;
        // �������
        spanStr="" ;
        if( hSpan>1 )
          spanStr=spanStr+Format(" colspan=%d",ARRAYOFCONST((hSpan))) ;
        if( vSpan>1 )
          spanStr=spanStr+Format(" rowspan=%d",ARRAYOFCONST((vSpan))) ;
        _content.append(Format("<td%s></td>",ARRAYOFCONST((spanStr)))) ;
      }
    }
    // �������
    _content.append("</tr>") ;
  }
  //
  _content.append(
    "\r\n</table>"
    "</td></table>"
    "</td></table>"
    "</td></table>"
    "\r\n</form>"
    "</body>"
    "</html>") ;
  //
  clearArray(hLine,nHLine) ;
  clearArray(vLine,nVLine) ;
  clearArray(simpleList,nowSimpleList) ;
  free(pixel) ;
}
//---------------------------------------------------------------------------
void
Editor::fromText(Content& _content)
{
  clear() ;
  //
  int      status=0 ;
  int        type ;
  int    property ;
  int        left,
              top,
            width,
           height ;
  String     text,
          caption ;
  //
  char      shape ;
  char*     value ;
  int      length ;
  //
  while( _content.scan(shape,value,length) )
    if( (shape==_SYNTAX_TAG_OPEN_)||(shape==_SYNTAX_TAG_CLOSE_) ) {
      if( ((status>1)&&(shape==_SYNTAX_TAG_OPEN_))||((status>0)&&(shape==_SYNTAX_TAG_CLOSE_)) ) {
        status=0 ;
        //
        if( type!=Simple::_none ) {
          if( (left<0)||(left>_LIMIT_VALUE_) )
            left=_DEFAULT_LEFT_ ;
          if( (top<0)||(top>_LIMIT_VALUE_) )
            top=_DEFAULT_TOP_ ;
          if( (width<=0)||(width>_LIMIT_VALUE_) )
            width=_DEFAULT_WIDTH_ ;
          if( (height<=0)||(height>_LIMIT_VALUE_) )
            height=_DEFAULT_HEIGHT_ ;
          append(type,left,top,width,height,(( type==Simple::_button )?caption.c_str():text.c_str())) ;
        }
        type=Simple::_none ;
        //
      }
      if( (status<=1)&&(shape==_SYNTAX_TAG_OPEN_) ) {
        status=1 ;
        //
        type=Simple::_none ;
        left=_DEFAULT_LEFT_ ;
        top=_DEFAULT_TOP_ ;
        width=_DEFAULT_WIDTH_ ;
        height=_DEFAULT_HEIGHT_ ;
        text="" ;
        caption="" ;
        //
      }
    }
    else if( (status==1)&&(shape==_SYNTAX_TERM_) ) {
      status=2 ;
      //
      for(int i=0;( (type==Simple::_none)&&(*Simple::types[i]) );i++)
        if( !strcmpi(Simple::types[i],value) )
          type=i ;
      //
    }
    else if( ((status==2)||(status==3))&&(shape==_SYNTAX_TERM_) ) {
      status=3 ;
      //
      property=-1 ;
      for(int i=0;( (property==-1)&&(*Simple::properties[i]) );i++)
        if( !strcmpi(Simple::properties[i],value) )
          property=i ;
      //
    }
    else if( (status==3)&&(shape==_SYNTAX_EQUAL_) )
      status=4 ;
    else if( (status==4)&&((shape==_SYNTAX_TERM_)||(shape==_SYNTAX_LINE_)) ) {
      status=2 ;
      //
      switch( property ) {
        case 0 :
          left=atoi(value) ;
          break ;
        case 1 :
          top=atoi(value) ;
          break ;
        case 2 :
          width=atoi(value) ;
          break ;
        case 3 :
          height=atoi(value) ;
          break ;
        case 4 :
          text=value ;
          break ;
        case 5 :
          caption=value ;
          break ;
      }
      //
    }
    else if( (status>0)&&(shape==_SYNTAX_DELIMITER_) )
      status=2 ;
    //else if( status>0 ) {
    //}
  //
  intersect() ;
  //
  if( viewWindow )
    update() ;
}
//---------------------------------------------------------------------------
void
Editor::intersect(void)
{
  SimpleList*    simpleList=0 ;
  int           nSimpleList=0 ;
  int         nowSimpleList=0 ;
  Location2D*   ptrLocation ;
  int                 index ;
  int                indexI ;
  int                indexJ ;
  //
  resizeArray(simpleList,nSimpleList,nowSimple) ;
  for(int i=0;i<nowSimple;i++) {
    ptrLocation=&(simple[i].location) ;
    searchInArray(&SimpleListRef(ptrLocation->x1,ptrLocation->y1),index,simpleList,nowSimpleList) ;
    insertInArray(simpleList,nowSimpleList,index) ;
    simpleList[index].index=i ;
    simpleList[index].hLine1=ptrLocation->x1 ;
    simpleList[index].vLine1=ptrLocation->y1 ;
  }
  //
  location.clear() ;
  for(int i=0;i<nowSimple;i++)
    location.include(simple[i].location) ;
  for(int i=0;i<nowSimple;i++) {
    indexI=simpleList[i].index ;
    for(int j=0;j<i;j++) {
      indexJ=simpleList[j].index ;
      if( simple[indexI].location.cross(simple[indexJ].location) ) {
        simple[indexI].location.moveTo(0,location.y2) ;
        location.include(simple[indexI].location) ;
        simple[indexI].commit() ;
        break ;
      }
    }
  }
  //
  clearArray(simpleList,nowSimpleList) ;
}
//---------------------------------------------------------------------------
void
Editor::toText(Content& _content)
{
  SimpleList*    simpleList=0 ;
  int           nSimpleList=0 ;
  int         nowSimpleList=0 ;
  Location2D*   ptrLocation ;
  int                 index ;
  //
  resizeArray(simpleList,nSimpleList,nowSimple) ;
  for(int i=0;i<nowSimple;i++) {
    ptrLocation=&(simple[i].location) ;
    if( ptrLocation->width()&&ptrLocation->height() ) {
      searchInArray(&SimpleListRef(ptrLocation->x1,ptrLocation->y1),index,simpleList,nowSimpleList) ;
      insertInArray(simpleList,nowSimpleList,index) ;
      simpleList[index].index=i ;
      simpleList[index].hLine1=ptrLocation->x1 ;
      simpleList[index].vLine1=ptrLocation->y1 ;
    }
  }
  for(int i=0;i<nowSimpleList;i++)
    simple[simpleList[i].index].toText(_content) ;
  //
  clearArray(simpleList,nowSimpleList) ;
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* _owner)
  : TForm(_owner)
{
  StringGrid1->Ctl3D=false ;
  StringGrid1->Height=0 ;
}
//---------------------------------------------------------------------------
void __fastcall
TForm1::FormCreate(TObject* _sender)
{
  TIniFile* iniFile=new TIniFile(ChangeFileExt(Application->ExeName,".ini")) ;
  Width=iniFile->ReadInteger("Window","width",Screen->Width-20) ;
  Height=iniFile->ReadInteger("Window","height",Screen->Height-20) ;
  Left=iniFile->ReadInteger("Window","left",10) ;
  Top=iniFile->ReadInteger("Window","top",10) ;
  Panel1->Width=iniFile->ReadInteger("Splitter","pos",Width/4) ;
  for(int i=0;i<ControlBar1->ControlCount;i++) {
    TControl* control=ControlBar1->Controls[i] ;
    int left=iniFile->ReadInteger(control->Name,"left",-1),
         top=iniFile->ReadInteger(control->Name,"top",-1) ;
    if( (left>=0)&&(top>=0) ) {
      control->Left=left ;
      control->Top=top ;
    }
  }
  delete iniFile ;
  //
  viewWindow=new ViewWindow(PanelView) ;
  viewWindow->Align=alClient ;
  viewWindow->setViewData(&editor) ;
  //
  editor.update() ;
}
//---------------------------------------------------------------------------
void __fastcall
TForm1::FormDestroy(TObject* _sender)
{
  TIniFile* iniFile=new TIniFile(ChangeFileExt(Application->ExeName,".ini")) ;
  iniFile->WriteInteger("Window","width",Width) ;
  iniFile->WriteInteger("Window","height",Height) ;
  iniFile->WriteInteger("Window","left",Left) ;
  iniFile->WriteInteger("Window","top",Top) ;
  iniFile->WriteInteger("Splitter","pos",Panel1->Width) ;
  for(int i=0;i<ControlBar1->ControlCount;i++) {
    TControl* control=ControlBar1->Controls[i] ;
    iniFile->WriteInteger(control->Name,"top",control->Top) ;
    iniFile->WriteInteger(control->Name,"left",control->Left) ;
  }
  delete iniFile ;
  //
  delete viewWindow ;
}
//---------------------------------------------------------------------------
void __fastcall
TForm1::FormResize(TObject* _sender)
{
  StringGrid1->ColWidths[1]=StringGrid1->ClientWidth-StringGrid1->ColWidths[0]-1 ;
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
void __fastcall
TForm1::StringGrid1DrawCell(
  TObject*       _sender,
  int               _col,
  int               _row,
  TRect&           _rect,
  TGridDrawState  _state)
{
  StringGrid1->Canvas->Font=Form1->Canvas->Font ;
  SetBkMode(StringGrid1->Canvas->Handle,TRANSPARENT) ;
  if( _col )
    StringGrid1->Canvas->FillRect(_rect) ;
  else
    DrawEdge(StringGrid1->Canvas->Handle,&_rect,BDR_RAISEDOUTER,BF_RECT|BF_SOFT|BF_MIDDLE) ;
  _rect.Left+=( _col )?2:10 ;
  _rect.Top+=2 ;
  _rect.Right-=4 ;
  _rect.Bottom-=2 ;
  DrawText(StringGrid1->Canvas->Handle,StringGrid1->Cells[_col][_row].c_str(),-1,&_rect,DT_LEFT) ;
}
//---------------------------------------------------------------------------
void __fastcall
TForm1::StringGrid1Click(TObject* _sender)
{
  int   left=atoi(StringGrid1->Cells[1][0].c_str()),
         top=atoi(StringGrid1->Cells[1][1].c_str()),
       width=atoi(StringGrid1->Cells[1][2].c_str()),
      height=atoi(StringGrid1->Cells[1][3].c_str()) ;
  editor.set(left,top,width,height,false) ;
}
//---------------------------------------------------------------------------
void __fastcall
TForm1::StringGrid1SetEditText(
  TObject*         _sender,
  int                 _col,
  int                 _row,
  const AnsiString  _value)
{
  if( _row==4 )
    editor.set(_value) ;
}
//---------------------------------------------------------------------------
void __fastcall
TForm1::StringGrid1KeyDown(
  TObject*    _sender,
  WORD&          _key,
  TShiftState  _shift)
{
  if( _key==VK_RETURN )
    StringGrid1Click(this) ;
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
void __fastcall
TForm1::buttonNewClick(TObject* _sender)
{
  editor.clear() ;
  Form1->Caption=Application->Title ;
}
//---------------------------------------------------------------------------
void __fastcall
TForm1::buttonOpenClick(TObject* _sender)
{
  TIniFile* iniFile=new TIniFile(ChangeFileExt(Application->ExeName,".ini")) ;
  OpenDialog1->FileName="" ;
  OpenDialog1->InitialDir=iniFile->ReadString(Name,"path",".") ;
  OpenDialog1->Filter=String("���� ������������ (*.dat)|*.dat") ;
  //
  if( OpenDialog1->Execute() ) {
    //
    iniFile->WriteString(Name,"path",ExtractFilePath(OpenDialog1->FileName)) ;
    //
    try {
      //
      Form1->Caption=Application->Title ;
      //
      FormatFile    file(OpenDialog1->FileName) ;
      Content    content ;
      file.openForRead() ;
      content.readFromFile(file) ;
      //
      editor.fromText(content) ;
      //
      Form1->Caption=Form1->Caption+String(" | ")+OpenDialog1->FileName ;
      //
    }
    catch(Exception& _exception) {
      ShowMessage(_exception.Message) ;
    }
    //
  }
  //
  delete iniFile ;
}
//---------------------------------------------------------------------------
void __fastcall
TForm1::buttonSaveClick(TObject* _sender)
{
  TIniFile* iniFile=new TIniFile(ChangeFileExt(Application->ExeName,".ini")) ;
  SaveDialog1->FileName="" ;
  SaveDialog1->InitialDir=iniFile->ReadString(Name,"path",".") ;
  SaveDialog1->Filter=String("���� ������������ (*.dat)|*.dat") ;
  //
  if( SaveDialog1->Execute() ) {
    //
    iniFile->WriteString(Name,"path",ExtractFilePath(SaveDialog1->FileName)) ;
    String fileExtension=".dat" ;
    String      fileName=SaveDialog1->FileName ;
    if( !(fileName.SubString(fileName.Length()-3,4)==fileExtension) )
      fileName=fileName+fileExtension ;
    //
    try {
      //
      FormatFile    file(fileName) ;
      Content    content ;
      file.openForWrite() ;
      //
      editor.toText(content) ;
      content.writeToFile(file) ;
      //
      Form1->Caption=Application->Title+String(" | ")+fileName ;
      //
    }
    catch(Exception& _exception) {
      ShowMessage(_exception.Message) ;
    }
    //
  }
  //
  delete iniFile ;
}
//---------------------------------------------------------------------------
void __fastcall
TForm1::buttonExportClick(TObject* _sender)
{
  TIniFile* iniFile=new TIniFile(ChangeFileExt(Application->ExeName,".ini")) ;
  SaveDialog1->FileName="" ;
  SaveDialog1->InitialDir=iniFile->ReadString(Name,"path",".") ;
  SaveDialog1->Filter=String("HTML �������� (*.html)|*.html") ;
  //
  if( SaveDialog1->Execute() ) {
    //
    iniFile->WriteString(Name,"path",ExtractFilePath(SaveDialog1->FileName)) ;
    String fileExtension=".html" ;
    String      fileName=SaveDialog1->FileName ;
    if( !(fileName.SubString(fileName.Length()-4,5)==fileExtension) )
      fileName=fileName+fileExtension ;
    //
    try {
      //
      FormatFile    file(fileName) ;
      Content    content ;
      file.openForWrite() ;
      //
      editor.toHTML(content) ;
      content.writeToFile(file) ;
      ShellExecute(0,"open",fileName.c_str(),0,0,SW_SHOW) ;
      //
    }
    catch(Exception& _exception) {
      ShowMessage(_exception.Message) ;
    }
    //
  }
  //
  delete iniFile ;
}
//---------------------------------------------------------------------------
void __fastcall
TForm1::buttonExitClick(TObject* _sender)
{
  Close() ;
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
void __fastcall
TForm1::buttonCancelClick(TObject* _sender)
{
  editor.insertType=-1 ;
  //
  buttonAppendButton->Down=false ;
  buttonAppendEdit->Down=false ;
  buttonAppendLabel->Down=false ;
}
//---------------------------------------------------------------------------
void __fastcall
TForm1::buttonAppendButtonClick(TObject* _sender)
{
  editor.insertType=Simple::_button ;
}
//---------------------------------------------------------------------------
void __fastcall
TForm1::buttonAppendEditClick(TObject* _sender)
{
  editor.insertType=Simple::_edit ;
}
//---------------------------------------------------------------------------
void __fastcall
TForm1::buttonAppendLabelClick(TObject* _sender)
{
  editor.insertType=Simple::_label ;
}
//---------------------------------------------------------------------------
void __fastcall
TForm1::buttonEraseClick(TObject* _sender)
{
  editor.erase() ;
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
void __fastcall
TForm1::buttonAlignHLeftClick(TObject* _sender)
{
  editor.align(Editor::_hLeft) ;
}
//---------------------------------------------------------------------------
void __fastcall
TForm1::buttonAlignHCenterClick(TObject* _sender)
{
  editor.align(Editor::_hCenter) ;
}
//---------------------------------------------------------------------------
void __fastcall
TForm1::buttonAlignHRightClick(TObject* _sender)
{
  editor.align(Editor::_hRight) ;
}
//---------------------------------------------------------------------------
void __fastcall
TForm1::buttonAlignVTopClick(TObject* _sender)
{
  editor.align(Editor::_vTop) ;
}
//---------------------------------------------------------------------------
void __fastcall
TForm1::buttonAlignVCenterClick(TObject* _sender)
{
  editor.align(Editor::_vCenter) ;
}
//---------------------------------------------------------------------------
void __fastcall
TForm1::buttonAlignVBottomClick(TObject* _sender)
{
  editor.align(Editor::_vBottom) ;
}
//---------------------------------------------------------------------------
void __fastcall
TForm1::buttonGridClick(TObject* _sender)
{
  buttonGrid->Down=!buttonGrid->Down ;
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
void __fastcall
TForm1::buttonHelpClick(TObject* _sender)
{
  Application->HelpFile=ChangeFileExt(Application->ExeName,".hlp") ;
  Application->HelpCommand(HELP_CONTENTS,0) ;
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
void
fromTextToHTML(
  String& _fileText,
  String& _fileHTML)
{
  try {
    //
    FormatFile fileText(_fileText) ;
    FormatFile fileHTML(_fileHTML) ;
    Content     content ;
    //
    fileText.openForRead() ;
    content.readFromFile(fileText) ;
    editor.fromText(content) ;
    content.clear() ;
    fileHTML.openForWrite() ;
    editor.toHTML(content) ;
    content.writeToFile(fileHTML) ;
    //
  }
  catch(Exception& _exception) {
    ::MessageBox(0,_exception.Message.c_str(),"Form Editor",MB_OK) ;
  }
}
//---------------------------------------------------------------------------







