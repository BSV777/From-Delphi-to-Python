//---------------------------------------------------------------------------
// 5A6F726368 , ant@home.tula.net
//---------------------------------------------------------------------------
#ifndef VIEW_HPP
#define VIEW_HPP
//---------------------------------------------------------------------------
#include <SysUtils.hpp>
#include <Controls.hpp>
#include <Classes.hpp>
#include <Forms.hpp>
#include <math.h>
//---------------------------------------------------------------------------
struct Point2D {
  int x,
      y ;

  Point2D(void):
    x(0),y(0)
  {
  }  

  Point2D(
    int _x,
    int _y):
    x(_x),y(_y)
  {
  }

} ;
//---------------------------------------------------------------------------
struct Location2D {

  int    x1,
         y1,
         x2,
         y2 ;
  bool init ;

  Location2D(void):
    init(false)
  {
  }

  Location2D(
    int _x1,
    int _y1,
    int _x2,
    int _y2):
    x1(_x1),y1(_y1),x2(_x2),y2(_y2),init(true)
  {
  }

  Location2D(
    int    _x,
    int    _y,
    int _size):
    x1(_x-_size),y1(_y-_size),x2(_x+_size),y2(_y+_size),init(true)
  {
  }

  void
  clear(void)
  {
    x1=y1=x2=y2=0 ;
    init=false ;
  }

  void
  include(Point2D _point)
  {
    if( !init ) {
      x1=x2=_point.x ;
      y1=y2=_point.y ;
      init=true ;
    }
    x1=min(x1,_point.x) ;
    y1=min(y1,_point.y) ;
    x2=max(x2,_point.x) ;
    y2=max(y2,_point.y) ;
  }

  void
  include(Location2D& _location)
  {
    if( _location.init ) {
      if( !init ) {
        x1=_location.x1 ;
        y1=_location.y1 ;
        x2=_location.x2 ;
        y2=_location.y2 ;
        init=true ;
      }
      else {
        if( _location.x1<x1 )
          x1=_location.x1 ;
        if( _location.y1<y1 )
          y1=_location.y1 ;
        if( _location.x2>x2 )
          x2=_location.x2 ;
        if( _location.y2>y2 )
          y2=_location.y2 ;
      }
    }
  }

  void
  moveTo(
    int _x,
    int _y)
  {
    if( init ) {
      x2=_x+x2-x1 ;
      y2=_y+y2-y1 ;
      x1=_x ;
      y1=_y ;
    }
  }

  void
  inflate(
    int _deltaX,
    int _deltaY)
  {
    x1-=_deltaX ;
    y1-=_deltaY ;
    x2+=_deltaX ;
    y2+=_deltaY ;
  }

  bool
  cross(Location2D& _location)
  {
    return ( (_location.x1<x2)&&(_location.x2>x1)&&
             (_location.y1<y2)&&(_location.y2>y1) ) ;
  }

  bool
  contain(Point2D& _point)
  {
    return ( (_point.x>=x1)&&(_point.x<=x2)&&
             (_point.y>=y1)&&(_point.y<=y2) ) ;
  }

  void
  normalize(void)
  {
    int temp ;
    if( x1>x2 ) {
      temp=x1 ;
      x1=x2 ;
      x2=temp ;
    }
    if( y1>y2 ) {
      temp=y1 ;
      y1=y2 ;
      y2=temp ;
    }
  }

  int
  width(void)
  {
    return ( init )?(x2-x1):0 ;
  }

  int
  height(void)
  {
    return ( init )?(y2-y1):0 ;
  }

  operator bool(void)
  {
    return init ;
  }

} ;
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
class ViewData {

  public:

    virtual void
    draw(
      HDC           _hdc,
      int         _viewX,
      int         _viewY,
      Location2D _window) ;

    virtual Location2D
    getLocation(void) ;

    virtual void
    test(Point2D& _point) ;

    virtual void
    select(Location2D _rect) ;

    virtual bool
    startMove(
      Point2D& _point,
      bool     _shift) ;

    virtual void
    move(
      int _deltaX,
      int _deltaY) ;

    virtual void
    endMove(
      int _deltaX,
      int _deltaY) ;

    virtual void
    keyDown(Word& _key,TShiftState _shift) ;

    virtual void
    keyPress(Messages::TWMKey& _message) ;

} ;
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
class ViewWindow : public TWinControl {

  class Region {

    public:

      HWND    hwnd ;
      HDC      hdc ;
      bool enabled ;
      int   startX,
            startY ;
      RECT    rect ;

      void
      enableSelection(
        HWND _hwnd,
        int     _x,
        int     _y)
      {
        hwnd=_hwnd ;
        hdc=::GetDC(hwnd) ;
        enabled=true ;
        startX=rect.left=rect.right=_x ;
        startY=rect.top=rect.bottom=_y ;
      }

      void
      disableSelection(void)
      {
        enabled=false ;
        ::DrawFocusRect(hdc,&rect) ;
        ::ReleaseDC(hwnd,hdc) ;
      }

      void
      select(
        int _x,
        int _y)
      {
        ::DrawFocusRect(hdc,&rect) ;
        rect.left=min(startX,_x) ;
        rect.top=min(startY,_y) ;
        rect.right=max(startX,_x) ;
        rect.bottom=max(startY,_y) ;
        ::DrawFocusRect(hdc,&rect) ;
      }

      void
      redraw(void)
      {
        ::DrawFocusRect(hdc,&rect) ;
      }

  } ;

  private:

    ViewData*      viewData ;

    HDC                 mdc ;
    int        mdcSaveIndex ;
    HBITMAP          bitmap ;
    HBRUSH            brush ;
    LOGFONT         logFont ;

    Region           region ;
    int         wmsizeLevel,
               oldHPosition,
               oldVPosition ;

    enum { _none,_select,_move,_scroll } ;
    int           mouseMode ;

    virtual void __fastcall CreateParams(TCreateParams& _params) ;

    MESSAGE void __fastcall WMPaint(Messages::TWMPaint& _message) ;
    MESSAGE void __fastcall WMEraseBkgnd(Messages::TWMEraseBkgnd& _message) ;
    MESSAGE void __fastcall WMSize(Messages::TWMSize& _message) ;
    MESSAGE void __fastcall WMTimeChange(Messages::TWMTimer& _message) ;
    MESSAGE void __fastcall WMHScroll(Messages::TWMScroll& _message) ;
    MESSAGE void __fastcall WMVScroll(Messages::TWMScroll& _message) ;
    MESSAGE void __fastcall WMKeyPress(Messages::TWMKey& _message) ;

  public:

    DYNAMIC void __fastcall KeyDown(Word& _key,TShiftState _shift) ;
    DYNAMIC void __fastcall MouseDown(TMouseButton _button,Classes::TShiftState _shift,int _x,int _y) ;
    DYNAMIC void __fastcall MouseMove(Classes::TShiftState _shift,int _x,int _y) ;
    DYNAMIC void __fastcall MouseUp(TMouseButton _button,Classes::TShiftState _shift,int _x,int _y) ;

    __fastcall
    ViewWindow(TWinControl* _owner) ;
    __fastcall
    ~ViewWindow() ;

    void
    mouseMove(void) ;

    void
    mouseSelect(void) ;

    void
    mouseScroll(void) ;

    void
    pictureTest(void) ;

    void
    setViewData(ViewData* _viewData) ;

    void
    updatePicture(void) ;

    void
    pictureScroll(
      int _deltaX,
      int _deltaY) ;

    LOGFONT*
    getFont(void)
    {
      return &logFont ;
    }

  BEGIN_MESSAGE_MAP
    VCL_MESSAGE_HANDLER(WM_PAINT,TWMPaint,WMPaint) ;
    VCL_MESSAGE_HANDLER(WM_ERASEBKGND,TWMEraseBkgnd,WMEraseBkgnd) ;
    VCL_MESSAGE_HANDLER(WM_SIZE,TWMSize,WMSize) ;
    VCL_MESSAGE_HANDLER(WM_TIMER,TWMTimer,WMTimeChange) ;
    VCL_MESSAGE_HANDLER(WM_HSCROLL,TWMScroll,WMHScroll) ;
    VCL_MESSAGE_HANDLER(WM_VSCROLL,TWMScroll,WMVScroll) ;
    VCL_MESSAGE_HANDLER(WM_CHAR,TWMKey,WMKeyPress) ;
  END_MESSAGE_MAP(TWinControl) ;

} ;
//---------------------------------------------------------------------------
#endif
