//---------------------------------------------------------------------------
// 5A6F726368 , ant@home.tula.net
//---------------------------------------------------------------------------
#include <string.h>
#include "ffile.hpp"
//---------------------------------------------------------------------------
FormatFile::FormatFile(const String& _name):
  fileName(_name),fileNumber(-1)
{
}
//---------------------------------------------------------------------------
FormatFile::~FormatFile()
{
	close() ;
}
//---------------------------------------------------------------------------
void
FormatFile::openForRead(void)
{
	if( (fileNumber=_rtl_open(fileName.c_str(),O_RDONLY|SH_DENYNO))==-1 )
		throw Exception(String("FormatFile:\n���������� ������� ����\n")+fileName) ;
}
//---------------------------------------------------------------------------
void
FormatFile::openForWrite(void)
{
	if( (fileNumber=_rtl_creat(fileName.c_str(),0))==-1 )
		throw Exception(String("FormatFile:\n���������� ������� ����\n")+fileName) ;
}
//---------------------------------------------------------------------------
void
FormatFile::close(void)
{
	_rtl_close(fileNumber) ;
  fileNumber=-1 ;
}
//---------------------------------------------------------------------------
int
FormatFile::length(void)
{
  return filelength(*this) ;
}
//---------------------------------------------------------------------------

