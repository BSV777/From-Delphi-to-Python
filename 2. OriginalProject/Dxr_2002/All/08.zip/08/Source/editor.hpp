//---------------------------------------------------------------------------
// 5A6F726368 , ant@home.tula.net
//---------------------------------------------------------------------------
#ifndef EDITOR_HPP
#define EDITOR_HPP
//---------------------------------------------------------------------------
#include "ffile.hpp"
#include "view.hpp"
//---------------------------------------------------------------------------
class Content {

  private:

    char*    content ;
    int     nContent ;
    int   nowContent ;

    int      pointer ;
    char*  ptrSymbol ;
    char      symbol ;

  public:

    Content(void) ;

    ~Content() ;

    void
    clear(void) ;

    void
    writeToFile(FormatFile& _file) ;

    void
    readFromFile(FormatFile& _file) ;

    void
    append(
      const char*  _value,
      int         _length) ;

    void
    append(const char* _value) ;

    void
    append(const AnsiString& _value) ;

    bool
    scan(
      char&   _shape,
      char*&  _value,
      int&   _length) ;

} ;
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
struct Simple {

  enum { _none=-1,_button=0,_edit=1,_label=2 } ;
  static char*       types[] ;
  static char*  properties[] ;

  static int   nowSelected ;
  static int countSelected ;
  static int        moveX1 ;
  static int        moveY1 ;
  static int        moveX2 ;
  static int        moveY2 ;

  static char       buffer[255+1] ;

  Location2D  baseLocation ;
  Location2D      location ;
  int                 type ;
  char                text[255+1] ;

  bool            selected ;
  int        selectedOrder ;

  Simple(void) ;

  void
  draw(
    HDC _dc,
    int  _x,
    int  _y) ;

  void
  drawMarker(
    HDC       _dc,
    int        _x,
    int        _y,
    HBRUSH _brush) ;

  void
  drawMarkers(
    HDC _dc,
    int  _x,
    int  _y) ;

  bool
  test(Point2D _point) ;

  void
  setMode(void) ;

  void
  alignMode(void) ;

  void
  appendMode(void) ;

  void
  select(bool _selected) ;

  bool
  startMove(Point2D& _point) ;

  void
  move(
    int _deltaX,
    int _deltaY) ;

  void
  set(
    int   _left,
    int    _top,
    int  _width,
    int _height) ;

  void
  commit(void) ;

  void
  rollback(void) ;

  void
  toText(Content& _content) ;

  void
  toHTML(
    Content& _content,
    int        _hSpan,
    int        _vSpan) ;

} ;
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
class Editor : public ViewData {

  public:

    enum { _hLeft,_hCenter,_hRight,_vTop,_vCenter,_vBottom } ;

    Simple*           simple ;
    int              nSimple ;
    int            nowSimple ;

    Location2D      location ;

    int           insertType ;
    bool          inMoveMode ;
    int        nowProperties ;
    int          simpleIndex ;

    int               deltaX,
                      deltaY ;

    Editor(void) ;

    ~Editor() ;

    Location2D
    getLocation(void)
    {
      return location ;
    }

    void
    draw(
      HDC           _hdc,
      int         _viewX,
      int         _viewY,
      Location2D _window) ;

    void
    keyDown(Word& _key,TShiftState _shift) ;

    void
    keyPress(Messages::TWMKey& _message) ;

    void
    clear(void) ;

    void
    append(
      int     _type,
      int     _left,
      int      _top,
      int    _width,
      int   _height,
      char*   _text) ;

    void
    erase(void) ;

    void
    test(Point2D& _point) ;

    void
    select(Location2D _rect) ;

    bool
    startMove(
      Point2D& _point,
      bool     _shift) ;

    void
    move(
      int _deltaX,
      int _deltaY) ;

    void
    endMove(
      int _deltaX,
      int _deltaY) ;

    void
    set(
      int    _left,
      int     _top,
      int   _width,
      int  _height,
      bool   _init=true) ;

    void
    set(const String& _value) ;

    void
    align(int _mode) ;

    bool
    check(void) ;

    void
    update(bool _init=true) ;

    void
    fromText(Content& _content) ;

    void
    intersect(void) ;

    void
    toText(Content& _content) ;

    void
    toHTML(Content& _content) ;

} ;
//---------------------------------------------------------------------------
#endif
