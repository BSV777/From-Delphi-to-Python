//---------------------------------------------------------------------------
// 5A6F726368 , ant@home.tula.net
//---------------------------------------------------------------------------
#ifndef CONTAINER_HPP
#define CONTAINER_HPP
//---------------------------------------------------------------------------
#include <sysutils.hpp>
#include <typeinfo.h>
//---------------------------------------------------------------------------
namespace ContainerSpace {

  inline void*
  operator new(
    size_t _size,
    void*   _ptr)
  {
    return _ptr ;
  }

}
//---------------------------------------------------------------------------
template <class Container> void
resizeArray(
  Container*&   _array,
  int&         _nArray,
  int         _newSize,
  int            _step=32)
{
  if( _newSize>_nArray ) {
    int nArray=max(_nArray+_step,_newSize) ;
    if( nArray>0 )
  		if( !(_array=(Container*)realloc((void*)_array,nArray*sizeof(Container))) )
  			throw Exception(String("resizeArray(")+typeid(Container).name()+","+IntToStr(_nArray)+","+IntToStr(_newSize)+","+IntToStr(_step)+")\nLow Memory") ;
    for(int i=_nArray;i<nArray;i++)
      ContainerSpace::new (_array+i) Container ;
    _nArray=nArray ;
  }
}
//---------------------------------------------------------------------------
template <class Container> void
clearArray(
  Container*&    _array,
  int&          _nArray)
{
  for(int i=0;i<_nArray;i++)
    _array[i].~Container() ;
  if( _array )
    free((void*)_array) ;
  _array=0 ;
  _nArray=0 ;
}
//---------------------------------------------------------------------------
template <class Reference,class Container> Container*
searchInArray(
  Reference* _reference,
  int&           _index,
  Container*     _array,
  int           _nArray)
{
  int     range=_nArray,
      halfRange,
         result ;
  _index=0 ;
  while( range>0 ) {
    halfRange=range>>1 ;
    result=_reference->compare(_array[_index+halfRange]) ;
    if( !result ) {
      _index+=halfRange ;
      return _array+_index ;
    }
    else if( result<0 )
      range=halfRange ;
    else {
      _index+=halfRange+1 ;
      range-=halfRange+1 ;
    }
  }
  return 0 ;
}
//---------------------------------------------------------------------------
template <class Container> Container*
insertInArray(
  Container*    _array,
  int&       _nowArray,
  int           _index)
{
  memmove((void*)(_array+_index+1),(void*)(_array+_index),(_nowArray-_index)*sizeof(Container)) ;
  _nowArray++ ;
  return _array+_index ;
}
//---------------------------------------------------------------------------
template <class Container> void
removeFromArray(
  Container*    _array,
  int&       _nowArray,
  int           _index)
{
  _nowArray-- ;
  memmove((void*)(_array+_index),(void*)(_array+_index+1),(_nowArray-_index)*sizeof(Container)) ;
}
//---------------------------------------------------------------------------
#endif

