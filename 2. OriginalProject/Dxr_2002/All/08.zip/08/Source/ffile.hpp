//---------------------------------------------------------------------------
// 5A6F726368 , ant@home.tula.net
//---------------------------------------------------------------------------
#ifndef FFILE_HPP
#define FFILE_HPP
//---------------------------------------------------------------------------
#include <sysutils.hpp>
#include <io.h>
#include <fcntl.h>
#include <share.h>
#include <dir.h>
//---------------------------------------------------------------------------
class FormatFile {

 	private:

		String   fileName ;
		int    fileNumber ;

	public:

		FormatFile(const String& _name) ;
		~FormatFile() ;

		void
		openForRead(void) ;
		void
		openForWrite(void) ;
		void
		close(void) ;
    int
    length(void) ;

		operator int(void)
		{
			if( fileNumber==-1 )
     		throw Exception(String("FormatFile:\n�������� � �������� ������\n")+fileName) ;
			return fileNumber ;
		}
		operator String&(void)
		{
			return fileName ;
		}

} ;
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
template <class Container> inline void
readFromFile(
	FormatFile&    _file,
	Container*  _pointer,
	int         _nowElem=1)
{
  int length=_nowElem*sizeof(Container) ;
	if( _rtl_read(_file,(void*)_pointer,length)!=length )
		throw Exception(String("FormatFile:\n������ ��� ������ �����\n")+_file) ;
}
//---------------------------------------------------------------------------
template <class Container> inline void
writeToFile(
	FormatFile&    _file,
	Container*  _pointer,
	int         _nowElem=1)
{
	int length=_nowElem*sizeof(Container) ;
	if( _rtl_write(_file,(void*)_pointer,length)!=length )
		throw Exception(String("FormatFile:\n������ ��� ������ �����\n")+_file) ;
}
//---------------------------------------------------------------------------
#endif
