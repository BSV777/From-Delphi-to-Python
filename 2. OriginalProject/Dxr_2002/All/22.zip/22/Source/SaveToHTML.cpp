//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "SaveToHTML.h"


//---------------------------------------------------------------------------
    APSaveToHTML::~APSaveToHTML()
{
    ClearObjects();
}
//---------------------------------------------------------------------------
void APSaveToHTML::ClearObjects(void)
{
    for(int i=0;i<Objects.Objects.Size;i++)
        delete Objects.Objects.Data[i];
    Objects.Objects.Resize(0);
}
//---------------------------------------------------------------------------
void APSaveToHTML::LoadObjects(AnsiString _FileName)
{
        FILE*stream = fopen(_FileName.c_str(), "r");
        if(!stream)
        {
            Application->MessageBox("�� ���� ������� ���� ��� ������", "������", MB_OK | MB_ICONSTOP);
            return;
        }

        ClearObjects();
        while(!feof(stream))
        {
            AnsiString Row = "";
            char str = 1;
            while(str != '\n' && !feof(stream) && Row.Length()<65535)
            {
                fscanf(stream,"%c", &str);
                Row += str;
            }
            Row = (Row.Trim()).SubString(2, Row.Length() - 3);
            Row.Trim();
//��������� ������ �������
            int SpacePos = Row.Pos(" ");
            if(SpacePos == 0)
                continue;
            AnsiString ClassName = (Row.SubString(1, SpacePos - 1)).LowerCase();
            Row = (Row.SubString(SpacePos + 1, Row.Length() - SpacePos)).Trim();

            AnsiString lRow = Row.LowerCase();
            if(ClassName == "label")
                Objects.AddObject(NULL, objLabel, 1, 1);
            else if(ClassName == "textedit")
                Objects.AddObject(NULL, objEdit, 1, 1);
            else if(ClassName == "button")
                Objects.AddObject(NULL, objButton, 1, 1);
            while(Row.Length() != 0)
            {
//����������� ��� ��������
                int Pos = Row.Pos("=");
                if(Pos == 0)
                    break;
                AnsiString PropertyName = (Row.SubString(1, Pos - 1)).Trim();
//����������� �������� ��������
                int Pos1 = Row.Pos("\"");
                if(Pos1 == 0)
                    break;
                Row = Row.SubString(Pos1 + 1, Row.Length() - Pos1);
                int Pos2 = Row.Pos("\"");
                if(Pos2 == 0)
                    break;
                AnsiString Value = Row.SubString(1, Pos2 - 1);
                Row = (Row.SubString(Pos2 + 1, Row.Length() - Pos2)).Trim();
                Pos = Row.Pos(";");
//�������� ��� ��������
                if(Pos != 0)
                    Row = (Row.SubString(Pos + 1, Row.Length() - Pos)).Trim();
                Objects.SetObjectProperty(Objects.Objects.Data[Objects.Objects.Size - 1], PropertyName, Value);
            }
        }
        fclose(stream);
}
//---------------------------------------------------------------------------
void APSaveToHTML::SaveToHTML(AnsiString _FileName)
{
    Objects.SaveToHTML(_FileName);
}
//---------------------------------------------------------------------------

#pragma package(smart_init)
