//---------------------------------------------------------------------------

#ifndef SaveToHTMLH
#define SaveToHTMLH
#include "Mathem.h"

//---------------------------------------------------------------------------
class APSaveToHTML {
public:
    APObjectData Objects;

    ~APSaveToHTML();
    void LoadObjects(AnsiString _FileName);
    void SaveToHTML(AnsiString _FileName);
private:
    void ClearObjects(void);
};
//---------------------------------------------------------------------------
#endif
