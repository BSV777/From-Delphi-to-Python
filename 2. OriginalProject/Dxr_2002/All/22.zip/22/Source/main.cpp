//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "main.h"
#include "Inspector.h"
#include <stdio.h>
#include "About.h"
#include "Option.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmMain *frmMain;
//---------------------------------------------------------------------------
__fastcall TfrmMain::TfrmMain(TComponent* Owner)
    : TForm(Owner)
{
    Application->OnHint = OnHint;
    for(int i=0;i<8;i++)
    {
        SelShape[i] = new TShape(pnlWorkspace);
        SelShape[i]->Visible = false;
        SelShape[i]->Width = 5;
        SelShape[i]->Height = 5;
        SelShape[i]->Brush->Color = clBlack;
        SelShape[i]->Parent = pnlWorkspace;
        SelShape[i]->OnMouseDown = SelShapeMouseDown;
        SelShape[i]->OnMouseUp = SelShapeMouseUp;
        SelShape[i]->OnMouseMove = SelShapeMouseMove;
    }
    SelShape[0]->Cursor = crSizeNWSE;
    SelShape[1]->Cursor = crSizeNS;
    SelShape[2]->Cursor = crSizeNESW;
    SelShape[3]->Cursor = crSizeWE;
    SelShape[4]->Cursor = crSizeNWSE;
    SelShape[5]->Cursor = crSizeNS;
    SelShape[6]->Cursor = crSizeNESW;
    SelShape[7]->Cursor = crSizeWE;
    Resize = false;
    Move = false;
    BegDrag = false;
    shpMain->Visible = false;
    CopyControl = NULL;
}
//---------------------------------------------------------------------------
//********���������� �������
//---------------------------------------------------------------------------
void __fastcall TfrmMain::pnlWorkspaceMouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
    if(!spdbtnArrow->Down)
    {
        if(spdbtnLabel->Down)
        {
            Objects.AddObject(pnlWorkspace, objLabel, X, Y);
            ((TLabel*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnClick = ObjectClick;
            ((TLabel*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseDown = ObjectMouseDown;
            ((TLabel*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseUp = ObjectMouseUp;
            ((TLabel*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseMove = ObjectMouseMove;
        }
        else if(spdbtnEdit->Down)
        {
            Objects.AddObject(pnlWorkspace, objEdit, X, Y);
            ((TEdit*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnClick = ObjectClick;
            ((TEdit*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseDown = ObjectMouseDown;
            ((TEdit*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseUp = ObjectMouseUp;
            ((TEdit*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseMove = ObjectMouseMove;
        }
        else if(spdbtnButton->Down)
        {
            Objects.AddObject(pnlWorkspace, objButton, X, Y);
            ((TButton*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnClick = ObjectClick;
            ((TButton*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseDown = ObjectMouseDown;
            ((TButton*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseUp = ObjectMouseUp;
            ((TButton*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseMove = ObjectMouseMove;
        }
        spdbtnArrow->Down = true;
        frmInspector->cmbObjects->Items->Add(Objects.Objects.Data[Objects.Objects.Size - 1]->Name);
        SelectObjectExecute(Objects.Objects.Data[Objects.Objects.Size - 1]);
        if(Objects.CorrectObjectPosition(Objects.Objects.Data[Objects.Objects.Size - 1]))
            ResizeMoveObjectExecute(NULL);
    }
    else
        ClearSelectedExecute(NULL);
}
//---------------------------------------------------------------------------
//********����� �������
//---------------------------------------------------------------------------
void TfrmMain::Selected(TControl* _SelControl)
{
    SelectedControl = _SelControl;
    if(SelectedControl->ClassNameIs("TEdit"))
    {
        SelShape[0]->Cursor = crArrow;
        SelShape[1]->Cursor = crArrow;
        SelShape[2]->Cursor = crArrow;
        SelShape[4]->Cursor = crArrow;
        SelShape[5]->Cursor = crArrow;
        SelShape[6]->Cursor = crArrow;
    }
    else
    {
        SelShape[0]->Cursor = crSizeNWSE;
        SelShape[1]->Cursor = crSizeNS;
        SelShape[2]->Cursor = crSizeNESW;
        SelShape[4]->Cursor = crSizeNWSE;
        SelShape[5]->Cursor = crSizeNS;
        SelShape[6]->Cursor = crSizeNESW;
    }
    ResizeMoveObjectExecute(NULL);
}
//---------------------------------------------------------------------------
//**********������ �� �������
//---------------------------------------------------------------------------
void __fastcall TfrmMain::ObjectClick(TObject *Sender)
{
    SelectObjectExecute(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::SelShapeMouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
    if(SelectedControl->ClassNameIs("TEdit"))
        if(Sender != SelShape[3] && Sender != SelShape[7])
            return;
    if(Button == mbLeft)
    {
        X0 = X;
        Y0 = Y;
        Resize = true;
        shpMain->Visible = true;
    }
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::SelShapeMouseUp(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
    Resize = false;
    SelectedControl->Top = shpMain->Top;
    SelectedControl->Left = shpMain->Left;
    if(shpMain->Height < 0)
    {
        SelectedControl->Height = -shpMain->Height;
        SelectedControl->Top = SelectedControl->Top - SelectedControl->Height;
    }
    else
        SelectedControl->Height = shpMain->Height;
    if(shpMain->Width < 0)
    {
        SelectedControl->Width = -shpMain->Width;
        SelectedControl->Left = SelectedControl->Left - SelectedControl->Width;
    }
    else
        SelectedControl->Width = shpMain->Width;
    Objects.CorrectObjectPosition(SelectedControl);
    ResizeMoveObjectExecute(NULL);
}
//---------------------------------------------------------------------------
//************��������� �������� �������
//---------------------------------------------------------------------------
void __fastcall TfrmMain::SelShapeMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
    if(Resize)
    {
        if(Sender == SelShape[0])
        {
            shpMain->Left += X - X0;
            shpMain->Width -= X - X0;
            shpMain->Height -= Y - Y0;
            shpMain->Top += Y - Y0;
            SelShape[1]->Top += Y - Y0;
            SelShape[2]->Top += Y - Y0;
            SelShape[0]->Left += X - X0;
            SelShape[0]->Top += Y - Y0;
            SelShape[6]->Left += X - X0;
            SelShape[7]->Left += X - X0;
            SelShape[5]->Left = shpMain->Left + shpMain->Width/2 - 2;
            SelShape[1]->Left = shpMain->Left + shpMain->Width/2 - 2;
            SelShape[7]->Top = shpMain->Top + shpMain->Height/2 - 2;
            SelShape[3]->Top = shpMain->Top + shpMain->Height/2 - 2;
        }
        else if(Sender == SelShape[1])
        {
            shpMain->Height -= Y - Y0;
            shpMain->Top += Y - Y0;
            SelShape[0]->Top += Y - Y0;
            SelShape[1]->Top += Y - Y0;
            SelShape[2]->Top += Y - Y0;
            SelShape[7]->Top = shpMain->Top + shpMain->Height/2 - 2;
            SelShape[3]->Top = shpMain->Top + shpMain->Height/2 - 2;
        }
        else if(Sender == SelShape[2])
        {
            shpMain->Top += Y - Y0;
            shpMain->Height -= Y - Y0;
            shpMain->Width += X - X0;
            SelShape[0]->Top += Y - Y0;
            SelShape[1]->Top += Y - Y0;
            SelShape[2]->Left += X - X0;
            SelShape[2]->Top += Y - Y0;
            SelShape[3]->Left += X - X0;
            SelShape[4]->Left += X - X0;
            SelShape[5]->Left = shpMain->Left + shpMain->Width/2 - 2;
            SelShape[1]->Left = shpMain->Left + shpMain->Width/2 - 2;
            SelShape[7]->Top = shpMain->Top + shpMain->Height/2 - 2;
            SelShape[3]->Top = shpMain->Top + shpMain->Height/2 - 2;
        }
        else if(Sender == SelShape[3])
        {
            shpMain->Width += X - X0;
            SelShape[2]->Left += X - X0;
            SelShape[3]->Left += X - X0;
            SelShape[4]->Left += X - X0;
            SelShape[5]->Left = shpMain->Left + shpMain->Width/2 - 2;
            SelShape[1]->Left = shpMain->Left + shpMain->Width/2 - 2;
        }
        else if(Sender == SelShape[4])
        {
            shpMain->Height += Y - Y0;
            shpMain->Width += X - X0;
            SelShape[2]->Left += X - X0;
            SelShape[3]->Left += X - X0;
            SelShape[4]->Left += X - X0;
            SelShape[4]->Top += Y - Y0;
            SelShape[5]->Top += Y - Y0;
            SelShape[5]->Left = shpMain->Left + shpMain->Width/2 - 2;
            SelShape[1]->Left = shpMain->Left + shpMain->Width/2 - 2;
            SelShape[7]->Top = shpMain->Top + shpMain->Height/2 - 2;
            SelShape[3]->Top = shpMain->Top + shpMain->Height/2 - 2;
            SelShape[6]->Top += Y - Y0;
        }
        else if(Sender == SelShape[5])
        {
            shpMain->Height += Y - Y0;
            SelShape[4]->Top += Y - Y0;
            SelShape[5]->Top += Y - Y0;
            SelShape[6]->Top += Y - Y0;
            SelShape[7]->Top = shpMain->Top + shpMain->Height/2 - 2;
            SelShape[3]->Top = shpMain->Top + shpMain->Height/2 - 2;
        }
        else if(Sender == SelShape[6])
        {
            shpMain->Left += X - X0;
            shpMain->Height += Y - Y0;
            shpMain->Width -= X - X0;
            SelShape[4]->Top += Y - Y0;
            SelShape[5]->Top += Y - Y0;
            SelShape[5]->Left = shpMain->Left + shpMain->Width/2 - 2;
            SelShape[1]->Left = shpMain->Left + shpMain->Width/2 - 2;
            SelShape[6]->Left += X - X0;
            SelShape[6]->Top += Y - Y0;
            SelShape[0]->Left += X - X0;
            SelShape[7]->Left += X - X0;
            SelShape[7]->Top = shpMain->Top + shpMain->Height/2 - 2;
            SelShape[3]->Top = shpMain->Top + shpMain->Height/2 - 2;
        }
        else if(Sender == SelShape[7])
        {
            shpMain->Width -= X - X0;
            shpMain->Left += X - X0;
            SelShape[0]->Left += X - X0;
            SelShape[6]->Left += X - X0;
            SelShape[7]->Left += X - X0;
            SelShape[5]->Left = shpMain->Left + shpMain->Width/2 - 2;
            SelShape[1]->Left = shpMain->Left + shpMain->Width/2 - 2;
        }
        if(shpMain->Height < 0 || shpMain->Width < 0)
            shpMain->Visible = false;
        else
            shpMain->Visible = true;
    }
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::ObjectMouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
    int ObjIndex = frmInspector->cmbObjects->Items->IndexOf(((TControl*)Sender)->Name);
    if(ObjIndex != -1)
        frmInspector->cmbObjects->ItemIndex = ObjIndex;
    SelectObjectExecute(Sender);
    Move = true;
    X0 = X;
    Y0 = Y;
    shpMain->Visible = true;
    HideSelectedShape();
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::ObjectMouseUp(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
    Move = false;
    if(Objects.CorrectObjectPosition((TControl*)Sender))
        ResizeMoveObjectExecute(NULL);
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::ObjectMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
    if(Move)
    {
        SelectedControl->Left += X - X0;
        SelectedControl->Top += Y - Y0;
        shpMain->Left += X - X0;
        shpMain->Top += Y - Y0;
    }
}
//---------------------------------------------------------------------------
void TfrmMain::DrawSelected(TControl* _SelControl)
{
    int CompLeft = _SelControl->Left;
    int CompTop = _SelControl->Top;
    int CompWidth = _SelControl->Width;
    int CompHeight = _SelControl->Height;

    SelShape[0]->Left = CompLeft - 2;
    SelShape[0]->Top = CompTop - 2;
    SelShape[1]->Left = CompLeft + CompWidth/2 - 2;
    SelShape[1]->Top = CompTop - 2;
    SelShape[2]->Left = CompLeft + CompWidth - 2;
    SelShape[2]->Top = CompTop - 2;
    SelShape[3]->Left = CompLeft + CompWidth - 2;
    SelShape[3]->Top = CompTop + CompHeight/2 - 2;
    SelShape[4]->Left = CompLeft + CompWidth - 2;
    SelShape[4]->Top = CompTop + CompHeight - 2;
    SelShape[5]->Left = CompLeft + CompWidth/2 - 2;
    SelShape[5]->Top = CompTop + CompHeight - 2;
    SelShape[6]->Left = CompLeft - 2;
    SelShape[6]->Top = CompTop + CompHeight - 2;
    SelShape[7]->Left = CompLeft - 2;
    SelShape[7]->Top = CompTop + CompHeight/2 - 2;
    shpMain->Top = CompTop;
    shpMain->Left = CompLeft;
    shpMain->Width = CompWidth;
    shpMain->Height = CompHeight;
    shpMain->Visible = false;
    for(int i=0;i<8;i++)
        SelShape[i]->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::ResizeMoveObjectExecute(TObject *Sender)
{
    if(SelectedControl)
    {
        DrawSelected(SelectedControl);
        frmInspector->LoadObjectPropeties(SelectedControl);
        CheckScrollBars();
    }
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::SelectObjectExecute(TObject *Sender)
{
    int ObjIndex = frmInspector->cmbObjects->Items->IndexOf(((TControl*)Sender)->Name);
    if(ObjIndex != -1)
        frmInspector->cmbObjects->ItemIndex = ObjIndex;
    EditCopy->Enabled = true;
    EditCut->Enabled = true;
    EditDelete->Enabled = true;
    tlbbtnCopy->Enabled = true;
    tlbbtnCut->Enabled = true;
    Selected((TControl*)Sender);
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::ClearSelectedExecute(TObject *Sender)
{
    SelectedControl = NULL;
    frmInspector->cmbObjects->ItemIndex = -1;
    shpMain->Visible = false;
    HideSelectedShape();
    frmInspector->grdProperty->RowCount = 0;
    frmInspector->grdProperty->Cells[0][0] = " ";
    frmInspector->grdProperty->Cells[1][0] = " ";
    EditCopy->Enabled = false;
    EditCut->Enabled = false;
    EditDelete->Enabled = false;
    tlbbtnCut->Enabled = false;
    tlbbtnCopy->Enabled = false;
}
//---------------------------------------------------------------------------
void TfrmMain::HideSelectedShape(void)
{
    for(int i=0;i<8;i++)
        SelShape[i]->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::ViewInspectorClick(TObject *Sender)
{
    frmInspector->Show();
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::EditCutClick(TObject *Sender)
{
    if(!SelectedControl)
        return;
    CopyObjectExecute(NULL);
    DeleteObjectExecute(NULL);
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::EditDeleteClick(TObject *Sender)
{
    if(SelectedControl)
        DeleteObjectExecute(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::DeleteObjectExecute(TObject *Sender)
{
    for(int i=0;i<Objects.Objects.Size;i++)
        if(Objects.Objects.Data[i] == SelectedControl)
        {
            Objects.Objects.Delete(i);
            delete SelectedControl;
            frmInspector->cmbObjects->Items->Delete(frmInspector->cmbObjects->ItemIndex);
            ClearSelectedExecute(Sender);
            frmInspector->cmbObjects->Refresh();
            break;
        }
    CheckScrollBars();
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::EditPasteClick(TObject *Sender)
{
    if(!CopyControl)
        return;
    Objects.AddObject((TWinControl*)pnlWorkspace, CopyControl);
    if(CopyControl->ClassNameIs("TLabel"))
    {
        ((TLabel*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnClick = ObjectClick;
        ((TLabel*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseDown = ObjectMouseDown;
        ((TLabel*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseUp = ObjectMouseUp;
        ((TLabel*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseMove = ObjectMouseMove;
    }
    else if(CopyControl->ClassNameIs("TEdit"))
    {
        ((TEdit*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnClick = ObjectClick;
        ((TEdit*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseDown = ObjectMouseDown;
        ((TEdit*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseUp = ObjectMouseUp;
        ((TEdit*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseMove = ObjectMouseMove;
    }
    else if(CopyControl->ClassNameIs("TButton"))
    {
        ((TButton*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnClick = ObjectClick;
        ((TButton*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseDown = ObjectMouseDown;
        ((TButton*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseUp = ObjectMouseUp;
        ((TButton*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseMove = ObjectMouseMove;
    }
    frmInspector->cmbObjects->Items->Add(Objects.Objects.Data[Objects.Objects.Size - 1]->Name);
    SelectObjectExecute(Objects.Objects.Data[Objects.Objects.Size - 1]);
    CheckScrollBars();
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::CopyObjectExecute(TObject *Sender)
{
    EditPaste->Enabled = true;
    tlbbtnPaste->Enabled = true;
//���������� �������
    if(CopyControl)
        delete CopyControl;
    if(SelectedControl->ClassNameIs("TLabel"))
    {
        TLabel *OldLabel = (TLabel*)SelectedControl;
        TLabel *NewLabel = new TLabel(this);
        NewLabel->Caption = OldLabel->Caption;
        NewLabel->Width = OldLabel->Width;
        NewLabel->Height = OldLabel->Height;
        NewLabel->Top = OldLabel->Top;
        NewLabel->Left = OldLabel->Left;
        NewLabel->Parent = NULL;
        CopyControl = (TControl*)NewLabel;
    }
    else if(SelectedControl->ClassNameIs("TEdit"))
    {
        TEdit *OldEdit = (TEdit*)SelectedControl;
        TEdit *NewEdit = new TEdit(this);
        NewEdit->Text = OldEdit->Text;
        NewEdit->Width = OldEdit->Width;
        NewEdit->Height = OldEdit->Height;
        NewEdit->Top = OldEdit->Top;
        NewEdit->Left = OldEdit->Left;
        NewEdit->Parent = NULL;
        CopyControl = (TControl*)NewEdit;
    }
    else if(SelectedControl->ClassNameIs("TButton"))
    {
        TButton *OldButton = (TButton*)SelectedControl;
        TButton *NewButton = new TButton(this);
        NewButton->Caption = OldButton->Caption;
        NewButton->Width = OldButton->Width;
        NewButton->Height = OldButton->Height;
        NewButton->Top = OldButton->Top;
        NewButton->Left = OldButton->Left;
        NewButton->Parent = NULL;
        CopyControl = (TControl*)NewButton;
    }
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::EditCopyClick(TObject *Sender)
{
    if(!SelectedControl)
        return;
    CopyObjectExecute(NULL);
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::SaveFileExecute(TObject *Sender)
{
    AnsiString FileName = "";
    if(SaveDialog->FileName != "")
        FileName = SaveDialog->FileName;
    else
    {
        if(SaveDialog->Execute())
            FileName = SaveDialog->FileName;
        else
            return;
    }
    SaveToFile(FileName);
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::FileExitClick(TObject *Sender)
{
    Application->Terminate();
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::NewFileExecute(TObject *Sender)
{
    SaveDialog->FileName = "";
    for(int i=0;i<Objects.Objects.Size;i++)
        delete Objects.Objects.Data[i];
    Objects.Objects.Resize(0);
    frmInspector->cmbObjects->Items->Clear();
    ClearSelectedExecute(Sender);
}
//---------------------------------------------------------------------------
void TfrmMain::SaveToFile(AnsiString FileName)
{
    FILE *stream = fopen(FileName.c_str(), "w");
    if(!stream)
    {
        Application->MessageBox("�� ���� ������� ����", "������", MB_OK | MB_ICONSTOP);
        return;
    }
    for(int i=0;i<Objects.Objects.Size;i++)
    {
        fprintf(stream,"<");
        if(Objects.Objects.Data[i]->ClassNameIs("TLabel"))
        {
            fprintf(stream,"Label left=\"%d\"; top=\"%d\"; width=\"%d\"; height=\"%d\"; text=\"%s\"; name=\"%s\"",
                    Objects.Objects.Data[i]->Left, Objects.Objects.Data[i]->Top,
                    Objects.Objects.Data[i]->Width, Objects.Objects.Data[i]->Height,
                    ((TLabel*)Objects.Objects.Data[i])->Caption.c_str(), Objects.Objects.Data[i]->Name.c_str());
        }
        else if(Objects.Objects.Data[i]->ClassNameIs("TEdit"))
        {
            fprintf(stream,"TextEdit left=\"%d\"; top=\"%d\"; width=\"%d\"; text=\"%s\"; name=\"%s\"",
                    Objects.Objects.Data[i]->Left, Objects.Objects.Data[i]->Top,
                    Objects.Objects.Data[i]->Width, ((TEdit*)Objects.Objects.Data[i])->Text.c_str(),
                    Objects.Objects.Data[i]->Name.c_str());
        }
        else if(Objects.Objects.Data[i]->ClassNameIs("TButton"))
        {
            fprintf(stream,"Button left=\"%d\"; top=\"%d\"; width=\"%d\"; height=\"%d\"; caption=\"%s\"; name=\"%s\"",
                    Objects.Objects.Data[i]->Left, Objects.Objects.Data[i]->Top,
                    Objects.Objects.Data[i]->Width, Objects.Objects.Data[i]->Height,
                    ((TButton*)Objects.Objects.Data[i])->Caption.c_str(), Objects.Objects.Data[i]->Name.c_str());
        }
        fprintf(stream,">\n");
    }
    fclose(stream);
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::FileSaveAsClick(TObject *Sender)
{
    if(SaveDialog->Execute())
        SaveToFile(SaveDialog->FileName);
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::LoadFileExecute(TObject *Sender)
{
    if(OpenDialog->Execute())
    {
        FILE*stream = fopen(OpenDialog->FileName.c_str(), "r");
        if(!stream)
        {
            Application->MessageBox("�� ���� ��������� ����", "������", MB_OK | MB_ICONSTOP);
            return;
        }
        NewFileExecute(Sender);
        SaveDialog->FileName = OpenDialog->FileName;
        while(!feof(stream))
        {
            AnsiString Row = "";
            char str = 1;
            while(str != '\n' && !feof(stream) && Row.Length()<65535)
            {
                fscanf(stream,"%c", &str);
                Row += str;
            }
            Row = (Row.Trim()).SubString(2, Row.Length() - 3);
            Row.Trim();
//��������� ������ �������
            int SpacePos = Row.Pos(" ");
            if(SpacePos == 0)
                continue;
            AnsiString ClassName = (Row.SubString(1, SpacePos - 1)).LowerCase();
            Row = (Row.SubString(SpacePos + 1, Row.Length() - SpacePos)).Trim();

            AnsiString lRow = Row.LowerCase();
            if(ClassName == "label")
            {
                Objects.AddObject(pnlWorkspace, objLabel, 1, 1);
                ((TLabel*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnClick = ObjectClick;
                ((TLabel*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseDown = ObjectMouseDown;
                ((TLabel*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseUp = ObjectMouseUp;
                ((TLabel*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseMove = ObjectMouseMove;
            }
            else if(ClassName == "textedit")
            {
                Objects.AddObject(pnlWorkspace, objEdit, 1, 1);
                ((TEdit*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnClick = ObjectClick;
                ((TEdit*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseDown = ObjectMouseDown;
                ((TEdit*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseUp = ObjectMouseUp;
                ((TEdit*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseMove = ObjectMouseMove;
            }
            else if(ClassName == "button")
            {
                Objects.AddObject(pnlWorkspace, objButton, 1, 1);
                ((TButton*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnClick = ObjectClick;
                ((TButton*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseDown = ObjectMouseDown;
                ((TButton*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseUp = ObjectMouseUp;
                ((TButton*)Objects.Objects.Data[Objects.Objects.Size - 1])->OnMouseMove = ObjectMouseMove;
            }
            while(Row.Length() != 0)
            {
//����������� ��� ��������
                int Pos = Row.Pos("=");
                if(Pos == 0)
                    break;
                AnsiString PropertyName = (Row.SubString(1, Pos - 1)).Trim();
//����������� �������� ��������
                int Pos1 = Row.Pos("\"");
                if(Pos1 == 0)
                    break;
                Row = Row.SubString(Pos1 + 1, Row.Length() - Pos1);
                int Pos2 = Row.Pos("\"");
                if(Pos2 == 0)
                    break;
                AnsiString Value = Row.SubString(1, Pos2 - 1);
                Row = (Row.SubString(Pos2 + 1, Row.Length() - Pos2)).Trim();
                Pos = Row.Pos(";");
//�������� ��� ��������
                if(Pos != 0)
                    Row = (Row.SubString(Pos + 1, Row.Length() - Pos)).Trim();
                Objects.SetObjectProperty(Objects.Objects.Data[Objects.Objects.Size - 1], PropertyName, Value);
            }
            frmInspector->cmbObjects->Items->Add(Objects.Objects.Data[Objects.Objects.Size - 1]->Name);
        }
        fclose(stream);
        CheckScrollBars();
    }
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::FileSaveToHTMLClick(TObject *Sender)
{
    if(SaveHTML->Execute())
        Objects.SaveToHTML(SaveHTML->FileName);
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::OnHint(TObject *Sender)
{
    StatusBar->SimpleText = GetLongHint(Application->Hint);
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::HelpAboutClick(TObject *Sender)
{
    frmAbout->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::OptionsClick(TObject *Sender)
{
    frmOptions->ShowModal();
    Objects.Method = frmOptions->rdgSaveToHTML->ItemIndex + 1;
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::FormResize(TObject *Sender)
{
    if(pnlWorkspace->Width < pnlMain->Width - 20)
    {
        pnlWorkspace->Width = pnlMain->Width - 20;
        scbHoriz->Enabled = false;
    }
    if(pnlWorkspace->Height < pnlMain->Height - 20)
    {
        pnlWorkspace->Height = pnlMain->Height - 20;
        scbVert->Enabled = false;
    }
}
//---------------------------------------------------------------------------
void TfrmMain::CheckScrollBars(void)
{
    int MaxX = Objects.GetMaxX() + 5;
    int MaxY = Objects.GetMaxY() + 5;
    if(MaxX != pnlWorkspace->Width && MaxX > pnlMain->ClientWidth)
    {
        pnlWorkspace->Width = MaxX;
        scbHoriz->Enabled = true;
        scbHoriz->Max = MaxX - pnlMain->ClientWidth;
        scbHoriz->LargeChange = scbHoriz->Max/5;
        scbHoriz->Position = 2 - pnlWorkspace->Left;
    }
    else if(MaxX <= pnlMain->ClientWidth)
    {
        scbHoriz->Position = 2;
        scbHoriz->Enabled = false;
        pnlWorkspace->Left = 2;
        pnlWorkspace->Width = pnlMain->Width;
    }
    if(MaxY != pnlWorkspace->Height && MaxY > pnlMain->ClientHeight)
    {
        pnlWorkspace->Height = MaxY;
        scbVert->Enabled = true;
        scbVert->Max = MaxY - pnlMain->ClientHeight;
        scbVert->LargeChange = scbVert->Max/5;
        scbVert->Position = 2 - pnlWorkspace->Top;
    }
    else if(MaxY <= pnlMain->ClientHeight)
    {
        scbVert->Position = 2;
        scbVert->Enabled = false;
        pnlWorkspace->Top = 2;
        pnlWorkspace->Height = pnlMain->Height;
    }
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::scbHorizChange(TObject *Sender)
{
    pnlWorkspace->Left = 2 - scbHoriz->Position;
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::scbVertChange(TObject *Sender)
{
    pnlWorkspace->Top = 2 - scbVert->Position;
}
//---------------------------------------------------------------------------
