//---------------------------------------------------------------------------

#include <vcl.h>
#include "SaveToHTML.h"
#pragma hdrstop
USERES("konkurs.res");
USEFORM("main.cpp", frmMain);
USEFORM("Inspector.cpp", frmInspector);
USEUNIT("Mathem.cpp");
USEUNIT("SaveToHTML.cpp");
USEFORM("About.cpp", frmAbout);
USEFORM("Option.cpp", frmOptions);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR cmdLine, int)
{
    try
    {
        AnsiString Line = cmdLine;
         if(Line.Length() > 0)
         {
            Line = Line.Trim();
            int PosSpace = Line.Pos(" ");
            AnsiString DataFile = Line.SubString(1, PosSpace), HTMLFile = "";
            Line = (Line.SubString(PosSpace + 1, Line.Length() - PosSpace)).Trim();
            PosSpace = Line.Pos(" ");
            if(PosSpace != 0)
                HTMLFile = Line.SubString(1, PosSpace);
            else
                HTMLFile = Line;
            if(DataFile.Length() == 0 || HTMLFile.Length() == 0)
                Application->MessageBox("������� �������� ��������� � ��������� ������","������", MB_OK | MB_ICONSTOP);
            else
            {
                APSaveToHTML *SaveToHTML = new APSaveToHTML;
                SaveToHTML->LoadObjects(DataFile);
                SaveToHTML->SaveToHTML(HTMLFile);
                delete SaveToHTML;
            }
            Application->Terminate();
         }
         Application->Initialize();
         Application->CreateForm(__classid(TfrmMain), &frmMain);
         Application->CreateForm(__classid(TfrmInspector), &frmInspector);
         Application->CreateForm(__classid(TfrmAbout), &frmAbout);
         Application->CreateForm(__classid(TfrmOptions), &frmOptions);
         Application->Run();
    }
    catch (Exception &exception)
    {
         Application->ShowException(&exception);
    }
    return 0;
}
//---------------------------------------------------------------------------




