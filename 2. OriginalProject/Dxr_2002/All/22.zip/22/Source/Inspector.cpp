//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Inspector.h"
#include "main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmInspector *frmInspector;
//---------------------------------------------------------------------------
__fastcall TfrmInspector::TfrmInspector(TComponent* Owner)
    : TForm(Owner)
{
    SelRow = -1;
    Modify = false;
    Show();
}
//---------------------------------------------------------------------------
void __fastcall TfrmInspector::cmbObjectsChange(TObject *Sender)
{
//����������� ���������� �������
    for(int i=0;i<frmMain->Objects.Objects.Size;i++)
        if(frmMain->Objects.Objects.Data[i]->Name == cmbObjects->Text)
        {
            frmMain->SelectObjectExecute(frmMain->Objects.Objects.Data[i]);
            break;
        }

}
//---------------------------------------------------------------------------
void TfrmInspector::LoadObjectPropeties(TControl *_Control)
{
    if(_Control->ClassNameIs("TLabel"))
        LoadLabelProperties((TLabel*)_Control);
    else if(_Control->ClassNameIs("TEdit"))
        LoadEditProperties((TEdit*)_Control);
    else if(_Control->ClassNameIs("TButton"))
        LoadButtonProperties((TButton*)_Control);
    else
    {
        grdProperty->RowCount = 0;
        grdProperty->Cells[0][0] = " ";
        grdProperty->Cells[1][0] = " ";
    }
}
//---------------------------------------------------------------------------
void TfrmInspector::LoadButtonProperties(TButton *_Button)
{
    grdProperty->RowCount = 6;
    grdProperty->Cells[0][0] = "Caption";
    grdProperty->Cells[0][1] = "Height";
    grdProperty->Cells[0][2] = "Left";
    grdProperty->Cells[0][3] = "Name";
    grdProperty->Cells[0][4] = "Top";
    grdProperty->Cells[0][5] = "Width";
    grdProperty->Cells[1][0] = _Button->Caption;
    grdProperty->Cells[1][1] = _Button->Height;
    grdProperty->Cells[1][2] = _Button->Left;
    grdProperty->Cells[1][3] = _Button->Name;
    grdProperty->Cells[1][4] = _Button->Top;
    grdProperty->Cells[1][5] = _Button->Width;
}
//---------------------------------------------------------------------------
void TfrmInspector::LoadLabelProperties(TLabel *_Label)
{
    grdProperty->RowCount = 6;
    grdProperty->Cells[0][0] = "Height";
    grdProperty->Cells[0][1] = "Left";
    grdProperty->Cells[0][2] = "Name";
    grdProperty->Cells[0][3] = "Text";
    grdProperty->Cells[0][4] = "Top";
    grdProperty->Cells[0][5] = "Width";
    grdProperty->Cells[1][0] = _Label->Height;
    grdProperty->Cells[1][1] = _Label->Left;
    grdProperty->Cells[1][2] = _Label->Name;
    grdProperty->Cells[1][3] = _Label->Caption;
    grdProperty->Cells[1][4] = _Label->Top;
    grdProperty->Cells[1][5] = _Label->Width;
}
//---------------------------------------------------------------------------
void TfrmInspector::LoadEditProperties(TEdit *_Edit)
{
    grdProperty->RowCount = 5;
    grdProperty->Cells[0][0] = "Left";
    grdProperty->Cells[0][1] = "Name";
    grdProperty->Cells[0][2] = "Text";
    grdProperty->Cells[0][3] = "Top";
    grdProperty->Cells[0][4] = "Width";
    grdProperty->Cells[1][0] = _Edit->Left;
    grdProperty->Cells[1][1] = _Edit->Name;
    grdProperty->Cells[1][2] = _Edit->Text;
    grdProperty->Cells[1][3] = _Edit->Top;
    grdProperty->Cells[1][4] = _Edit->Width;
}
//---------------------------------------------------------------------------
void __fastcall TfrmInspector::grdPropertySetEditText(TObject *Sender,
      int ACol, int ARow, const AnsiString Value)
{
    SelRow = ARow;
    Modify = true;
    return;
}
//---------------------------------------------------------------------------
void __fastcall TfrmInspector::grdPropertyKeyDown(TObject *Sender,
      WORD &Key, TShiftState Shift)
{
    if(Modify && (Key == VK_RETURN || Key == VK_TAB || Key == VK_UP ||
       Key == VK_DOWN))
    {
        AnsiString NewValue = grdProperty->Cells[1][SelRow];
        if(!frmMain->Objects.SetObjectProperty(frmMain->SelectedControl, grdProperty->Cells[0][SelRow], NewValue))
        {
            Application->MessageBox("������������ ��������","������",MB_OK | MB_ICONSTOP);
            grdProperty->Cells[1][SelRow] = NewValue;
        }
        if(grdProperty->Cells[0][SelRow] == "Name")
        {
            int Index = cmbObjects->ItemIndex;
            cmbObjects->Items->Strings[Index] = NewValue;
            cmbObjects->ItemIndex = Index;
        }
        frmMain->ResizeMoveObjectExecute(frmMain->SelectedControl);
        Modify = false;
    }
}
//---------------------------------------------------------------------------
void __fastcall TfrmInspector::grdPropertyMouseWheelDown(TObject *Sender,
      TShiftState Shift, TPoint &MousePos, bool &Handled)
{
    if(Modify)
    {
        AnsiString NewValue = grdProperty->Cells[1][SelRow];
        if(!frmMain->Objects.SetObjectProperty(frmMain->SelectedControl, grdProperty->Cells[0][SelRow], NewValue))
        {
            Application->MessageBox("������������ ��������","������",MB_OK | MB_ICONSTOP);
            grdProperty->Cells[1][SelRow] = NewValue;
        }
        if(grdProperty->Cells[0][SelRow] == "Name")
        {
            int Index = cmbObjects->ItemIndex;
            cmbObjects->Items->Strings[Index] = NewValue;
            cmbObjects->ItemIndex = Index;
        }
        frmMain->ResizeMoveObjectExecute(frmMain->SelectedControl);
        Modify = false;
    }
}
//---------------------------------------------------------------------------
void __fastcall TfrmInspector::grdPropertyMouseWheelUp(TObject *Sender,
      TShiftState Shift, TPoint &MousePos, bool &Handled)
{
    if(Modify)
    {
        AnsiString NewValue = grdProperty->Cells[1][SelRow];
        if(!frmMain->Objects.SetObjectProperty(frmMain->SelectedControl, grdProperty->Cells[0][SelRow], NewValue))
        {
            Application->MessageBox("������������ ��������","������",MB_OK | MB_ICONSTOP);
            grdProperty->Cells[1][SelRow] = NewValue;
        }
        if(grdProperty->Cells[0][SelRow] == "Name")
        {
            int Index = cmbObjects->ItemIndex;
            cmbObjects->Items->Strings[Index] = NewValue;
            cmbObjects->ItemIndex = Index;
        }
        frmMain->ResizeMoveObjectExecute(frmMain->SelectedControl);
        Modify = false;
    }
}
//---------------------------------------------------------------------------
void __fastcall TfrmInspector::grdPropertyExit(TObject *Sender)
{
    if(Modify)
    {
        AnsiString NewValue = grdProperty->Cells[1][SelRow];
        if(!frmMain->Objects.SetObjectProperty(frmMain->SelectedControl, grdProperty->Cells[0][SelRow], NewValue))
        {
            Application->MessageBox("������������ ��������","������",MB_OK | MB_ICONSTOP);
            grdProperty->Cells[1][SelRow] = NewValue;
        }
        if(grdProperty->Cells[0][SelRow] == "Name")
        {
            int Index = cmbObjects->ItemIndex;
            cmbObjects->Items->Strings[Index] = NewValue;
            cmbObjects->ItemIndex = Index;
        }
        frmMain->ResizeMoveObjectExecute(frmMain->SelectedControl);
        Modify = false;
    }
}
//---------------------------------------------------------------------------
void __fastcall TfrmInspector::FormDeactivate(TObject *Sender)
{
    if(Modify)
    {
        AnsiString NewValue = grdProperty->Cells[1][SelRow];
        if(!frmMain->Objects.SetObjectProperty(frmMain->SelectedControl, grdProperty->Cells[0][SelRow], NewValue))
        {
            Application->MessageBox("������������ ��������","������",MB_OK | MB_ICONSTOP);
            grdProperty->Cells[1][SelRow] = NewValue;
        }
        if(grdProperty->Cells[0][SelRow] == "Name")
        {
            int Index = cmbObjects->ItemIndex;
            cmbObjects->Items->Strings[Index] = NewValue;
            cmbObjects->ItemIndex = Index;
        }
        frmMain->ResizeMoveObjectExecute(frmMain->SelectedControl);
        Modify = false;
    }
}
//---------------------------------------------------------------------------

