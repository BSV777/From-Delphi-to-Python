//---------------------------------------------------------------------------
#ifndef ad_matrixH
#define ad_matrixH

#define AD_INCORRECTROW throw("Incorrect row")
#define AD_INCORRECTCOL throw("Incorrect column")
#define AD_ERRORMULTIPLY throw("Matrix sizes don't match")
#define AD_ERRORPOW throw("Matrix row and column count doesn't match")
#define AD_INCORRECTSIZE throw("Incorrect vector size")

#define AD_SETNEWDATA(pF,pD,nR,nC,Class) \
   	pD=new Class[(nR)*(nC)]; \
	pF=new Class*[nR]; \
	pF[0]=pD; \
	for(ad_index i=1;i<(nR);i++) \
       pF[i]=pF[i-1]+(nC)
#define AD_APPLYNEWDATA(pF,pD) \
    if(FRowFirst) delete [] FRowFirst; \
    FRowFirst = pF; \
    if(FData) delete [] FData; \
    FData = pD

#include "ad_vector.h"
#include "ad_matharray.h"
//---------------------------------------------------------------------------
template <class T> class ADMatrix
	: public ADMathArray<T>
{
private:
	void __fastcall SetData(ad_index _Row, ad_index _Col, T value);
	T __fastcall GetData(ad_index _Row, ad_index _Col) const;
	ad_index __fastcall GetFindCol(void) const;
	ad_index __fastcall GetFindRow(void) const;
	ADVector<T> __fastcall GetCol(ad_index _Col) const;
	ADVector<T> __fastcall GetRow(ad_index _Row) const;
	void __fastcall SetCol(ad_index _Col, const ADVector<T>& _Value);
	void __fastcall SetRow(ad_index _Row, const ADVector<T>& _Value);
	void __fastcall SetColCount(ad_size value);
   	void __fastcall SetRowCount(ad_size value);
protected:
	T** FRowFirst;
	ad_size FRowCount;
	ad_size FColCount;
public:
    //------------------------------------------
	__property ad_size ColCount={read=GetM,write=SetColCount};
	__property ad_size RowCount={read=GetN,write=SetRowCount};
	__property T Data[ad_index _Row][ad_index _Col]={read=GetData,write=SetData};
	__property ADVector<T> Col[ad_index _Col]={read=GetCol,write=SetCol};
	__property ADVector<T> Row[ad_index _Row]={read=GetRow,write=SetRow};
	__property ad_index FindCol={read=GetFindCol};
	__property ad_index FindRow={read=GetFindRow};
    //------------------------------------------
	T** GetRowFirstAddress(void) const;
	ad_size GetN(void) const;
	ad_size GetM(void) const;
    //------------------------------------------
	__fastcall ADMatrix(const ADMatrix<T>& _X);
	__fastcall ADMatrix(ad_size _Rows=0,ad_size _Cols=0);
	__fastcall ~ADMatrix(void);
    //------------------------------------------
	virtual void Erase(void);
	virtual void Resize(ad_size _Rows, ad_size _Cols);
	virtual void InsertCol(ad_index _Col);
	virtual void InsertRow(ad_index _Row);
	virtual void InsertCol(ad_index _Col, const ADVector<T>& _X);
	virtual void InsertRow(ad_index _Row, const ADVector<T>& _X);
	virtual ad_index AddCol(void);
	virtual ad_index AddRow(void);
	virtual ad_index AddCol(const ADVector<T>& _X);
	virtual ad_index AddRow(const ADVector<T>& _X);
	virtual void DeleteCol(ad_index _Col);
	virtual void DeleteRow(ad_index _Row);
    //------------------------------------------
    virtual void operator =  (const ADMatrix<T>& _X);
	virtual bool operator == (const ADMatrix<T>& _X) const;
	virtual bool operator != (const ADMatrix<T>& _X) const;
    virtual bool operator >  (const ADMatrix<T>& _X) const;
    virtual bool operator >= (const ADMatrix<T>& _X) const;
    virtual bool operator <  (const ADMatrix<T>& _X) const;
    virtual bool operator <= (const ADMatrix<T>& _X) const;
    //------------------------------------------
    virtual ADMatrix<T> operator + (const ADMatrix<T>& _X) const;
    virtual ADMatrix<T> operator - (const ADMatrix<T>& _X) const;
    virtual void operator += (const ADMatrix<T>& _X);
    virtual void operator -= (const ADMatrix<T>& _X);
    virtual ADMatrix<T> operator + (T _Value) const;
    virtual ADMatrix<T> operator - (T _Value) const;
    virtual ADMatrix<T> operator * (T _Value) const;
    virtual ADMatrix<T> operator / (T _Value) const;
    virtual ADMatrix<T> operator * (const ADMatrix<T>& _X) const;
    virtual void operator *= (const ADMatrix<T>& _X);
    virtual ADMatrix<T> operator ^ (int _Pow) const;
    virtual void operator ^= (int _Pow);
    //------------------------------------------
	void SwapRows(ad_index _Row1, ad_index _Row2);
	void SwapCols(ad_index _Col1, ad_index _Col2);
    //------------------------------------------
};
//---------------------------------------------------------------------------
typedef ADMatrix<double> DMatrix;
typedef ADMatrix<int> IMatrix;
typedef ADMatrix<bool> BMatrix;
//---------------------------------------------------------------------------
AD_TEMP __fastcall ADMatrix<T>::~ADMatrix(void)
{
    if(FData)
    	delete [] FData;
    if(FRowFirst)
        delete [] FRowFirst;
}
//---------------------------------------------------------------------------
AD_TEMP __fastcall ADMatrix<T>::ADMatrix(ad_size _Rows,ad_size _Cols)
{
	FRowCount=0;
    FColCount=0;
    FRowFirst=NULL;
	if(_Rows>0 || _Cols>0)
    {
    	Resize(_Rows,_Cols);
    }
}
//---------------------------------------------------------------------------
AD_TEMP __fastcall ADMatrix<T>::ADMatrix(const ADMatrix<T>& _X)
{
	FRowCount=0;
    FColCount=0;
    FRowFirst=NULL;
	if(_X.RowCount>0 || _X.ColCount>0)
    {
    	FDefault=_X.Default;
        Resize(_X.RowCount,_X.ColCount);
        CopyData(FData,_X.GetDataAddress(),FRowCount*FColCount);
    }
}
//---------------------------------------------------------------------------
AD_TEMP void __fastcall ADMatrix<T>::SetData(ad_index _Row, ad_index _Col, T value)
{
	if(_Row>=0 && _Col>=0 && _Row<FRowCount && _Col<FColCount)
    	*(FRowFirst[_Row]+_Col)=value;
    else
    	AD_INCORRECTINDEX;
}
//---------------------------------------------------------------------------
AD_TEMP T __fastcall ADMatrix<T>::GetData(ad_index _Row, ad_index _Col) const
{
	if(_Row>=0 && _Col>=0 && _Row<FRowCount && _Col<FColCount)
    	return *(FRowFirst[_Row]+_Col);
    else
    	AD_INCORRECTINDEX;
}
//---------------------------------------------------------------------------
AD_TEMP void __fastcall ADMatrix<T>::SetRowCount(ad_size value)
{
	Resize(value,FColCount);
}
//---------------------------------------------------------------------------
AD_TEMP void __fastcall ADMatrix<T>::SetColCount(ad_size value)
{
	Resize(FRowCount,value);
}
//---------------------------------------------------------------------------
AD_TEMP ad_index ADMatrix<T>::GetN(void) const
{
	return FRowCount;
}
//---------------------------------------------------------------------------
AD_TEMP ad_size ADMatrix<T>::GetM(void) const
{
	return FColCount;
}
//---------------------------------------------------------------------------
AD_TEMP ad_index __fastcall ADMatrix<T>::GetFindCol(void) const
{
	if(FLastPos!=NOT_FOUND)
		return FLastPos%FRowCount;
    else
    	return NOT_FOUND;
}
//---------------------------------------------------------------------------
AD_TEMP ad_index __fastcall ADMatrix<T>::GetFindRow(void) const
{
	if(FLastPos!=NOT_FOUND)
		return FLastPos/FRowCount;
    else
    	return NOT_FOUND;
}
//---------------------------------------------------------------------------
AD_TEMP void __fastcall ADMatrix<T>::SetCol(ad_index _Col, const ADVector<T>& _Value)
{
	if(FRowCount!=_Value.Size)
    	AD_INCORRECTSIZE;
	if(_Col>=0 && _Col<FColCount)
    {
    	T* VData=_Value.GetDataAddress();
    	for(ad_index i=0;i<FRowCount;i++)
    		*(FRowFirst[i]+_Col)=VData[i];
    }
    else
    	AD_INCORRECTINDEX;
}
//---------------------------------------------------------------------------
AD_TEMP void __fastcall ADMatrix<T>::SetRow(ad_index _Row, const ADVector<T>& _Value)
{
	if(FColCount!=_Value.Size)
    	AD_INCORRECTSIZE;
	if(_Row>=0 && _Row<FRowCount)
    {
    	T* VData=_Value.GetDataAddress();
    	for(ad_index i=0;i<FColCount;i++)
    		*(FRowFirst[_Row]+i)=VData[i];
    }
    else
    	AD_INCORRECTINDEX;
}
//---------------------------------------------------------------------------
AD_TEMP ADVector<T> __fastcall ADMatrix<T>::GetCol(ad_index _Col) const
{
	if(_Col>=0 && _Col<FColCount)
    {
		ADVector<T> Rez;
	    Rez.Resize(FRowCount);
    	T* RezData=Rez.GetDataAddress();
    	for(ad_index i=0;i<FRowCount;i++)
    		RezData[i]=*(FRowFirst[i]+_Col);
	    return Rez;
    }
    else
    	AD_INCORRECTINDEX;
}
//---------------------------------------------------------------------------
AD_TEMP ADVector<T> __fastcall ADMatrix<T>::GetRow(ad_index _Row) const
{
	if(_Row>=0 && _Row<FRowCount)
    {
		ADVector<T> Rez;
	    Rez.Resize(FColCount);
    	T* RezData=Rez.GetDataAddress();
    	for(ad_index i=0;i<FColCount;i++)
    		RezData[i]=*(FRowFirst[_Row]+i);
	    return Rez;
    }
    else
    	AD_INCORRECTINDEX;
}
//---------------------------------------------------------------------------
AD_TEMP T** ADMatrix<T>::GetRowFirstAddress(void) const
{
	return FRowFirst;
}
//---------------------------------------------------------------------------
AD_TEMP void ADMatrix<T>::Erase(void)
{
	FRowCount=0;
    FColCount=0;
    FSize=0;
    FLastPos=AD_NOTFOUND;
    FFindLast=FDefault;
    if(FRowFirst) delete [] FRowFirst;
    if(FData) delete [] FData;
    FRowFirst=NULL;
    FData=NULL;
}
//---------------------------------------------------------------------------
AD_TEMP void ADMatrix<T>::Resize(ad_size _Rows, ad_size _Cols)
{
    T* Temp;
    T** First;
    if(_Rows<0 || _Cols<0 || (_Rows==FRowCount && _Cols==FColCount))
    	return;
    try
    {
        AD_SETNEWDATA(First,Temp,_Rows,_Cols,T);
		for(ad_index i=0;i<_Rows && i<FRowCount;i++)
        {
        	CopyData(First[i],FRowFirst[i],min(_Cols,FColCount));
            for(ad_index j=FColCount;j<_Cols;j++)
            	*(First[i]+j)=FDefault;
        }
        for(ad_index i=FRowCount;i<_Rows;i++)
        	for(ad_index j=0;j<_Cols;j++)
            	*(First[i]+j)=FDefault;

        delete [] FRowFirst;
        FRowFirst = First;
        delete [] FData;
        FData = Temp;
//        AD_APPLYNEWDATA(First,Temp);
        FRowCount=_Rows;
        FColCount=_Cols;
        FSize=FRowCount*FColCount;
    }
    catch(...)
    {
		AD_ERRORMEMORY;
    }
}
//---------------------------------------------------------------------------
AD_TEMP void ADMatrix<T>::InsertCol(ad_index _Col, const ADVector<T>& _X)
{
    T* Temp;
    T** First;
    T* XData=_X.GetDataAddress();
    if(_Col<0 || _Col>FColCount)
    	AD_INCORRECTINDEX;
	if(_X.Size!=FRowCount)
    	AD_INCORRECTSIZE;
    try
    {
        AD_SETNEWDATA(First,Temp,FRowCount,FColCount+1,T);
		for(ad_index i=0;i<FRowCount;i++)
        {
        	CopyData(First[i],FRowFirst[i],_Col);
            *(First[i]+_Col)=XData[i];
            CopyData(First[i]+_Col+1,FRowFirst[i]+_Col,FColCount-_Col);
        }
        AD_APPLYNEWDATA(First,Temp);
        FColCount++;
        FSize=FRowCount*FColCount;
    }
    catch(...)
    {
		AD_ERRORMEMORY;
	}
}
//---------------------------------------------------------------------------
AD_TEMP void ADMatrix<T>::InsertRow(ad_index _Row, const ADVector<T>& _X)
{
    T* Temp;
    T** First;
    T* XData=_X.GetDataAddress();
    if(_Row<0 || _Row>FRowCount)
    	AD_INCORRECTINDEX;
	if(_X.Size!=FColCount)
    	AD_INCORRECTSIZE;
    try
    {
        AD_SETNEWDATA(First,Temp,FRowCount+1,FColCount,T);
        CopyData(First[0],FRowFirst[0],_Row*FColCount);
        CopyData(First[_Row],XData,FColCount);
        CopyData(First[_Row+1],FRowFirst[_Row],(FRowCount-_Row)*FColCount);
        AD_APPLYNEWDATA(First,Temp);
        FRowCount++;
        FSize=FRowCount*FColCount;
    }
    catch(...)
    {
		AD_ERRORMEMORY;
    }
}
//---------------------------------------------------------------------------
AD_TEMP void ADMatrix<T>::InsertCol(ad_index _Col)
{
    T* Temp;
    T** First;
    if(_Col<0 || _Col>FColCount)
    	AD_INCORRECTINDEX;
    try
    {
        AD_SETNEWDATA(First,Temp,FRowCount,FColCount+1,T);
		for(ad_index i=0;i<FRowCount;i++)
        {
        	CopyData(First[i],FRowFirst[i],_Col);
            *(First[i]+_Col)=FDefault;
            CopyData(First[i]+_Col+1,FRowFirst[i]+_Col,FColCount-_Col);
        }
        AD_APPLYNEWDATA(First,Temp);
        FColCount++;
        FSize=FRowCount*FColCount;
    }
    catch(...)
    {
		AD_ERRORMEMORY;
    }
}
//---------------------------------------------------------------------------
AD_TEMP void ADMatrix<T>::InsertRow(ad_index _Row)
{
    T* Temp;
    T** First;
    if(_Row<0 || _Row>FRowCount)
    	AD_INCORRECTINDEX;
    try
    {
        AD_SETNEWDATA(First,Temp,FRowCount+1,FColCount,T);
        CopyData(First[0],FRowFirst[0],_Row*FColCount);
        for(ad_index j=0;j<FColCount;j++)
        	*(First[_Row]+j)=FDefault;
        CopyData(First[_Row+1],FRowFirst[_Row],(FRowCount-_Row)*FColCount);
        AD_APPLYNEWDATA(First,Temp);
        FRowCount++;
        FSize=FRowCount*FColCount;
    }
    catch(...)
	{
		AD_ERRORMEMORY;
    }
}
//---------------------------------------------------------------------------
AD_TEMP void ADMatrix<T>::DeleteRow(ad_index _Row)
{
    T* Temp;
    T** First;
    if(_Row<0 || _Row>=FRowCount)
    	AD_INCORRECTINDEX;
    try
    {
		AD_SETNEWDATA(First,Temp,FRowCount-1,FColCount,T);
        CopyData(First[0],FRowFirst[0],_Row*FColCount);
        CopyData(First[_Row],FRowFirst[_Row+1],(FRowCount-_Row-1)*FColCount);
        AD_APPLYNEWDATA(First,Temp);
        FRowCount--;
        FSize=FRowCount*FColCount;
    }
    catch(...)
    {
		AD_ERRORMEMORY;
    }
}
//---------------------------------------------------------------------------
AD_TEMP void ADMatrix<T>::DeleteCol(ad_index _Col)
{
    T* Temp;
    T** First;
    if(_Col<0 || _Col>=FColCount)
    	AD_INCORRECTINDEX;
    try
    {
        AD_SETNEWDATA(First,Temp,FRowCount,FColCount-1,T);
		for(ad_index i=0;i<FRowCount;i++)
        {
        	CopyData(First[i],FRowFirst[i],_Col);
            CopyData(First[i]+_Col,FRowFirst[i]+_Col+1,FColCount-_Col-1);
        }
        AD_APPLYNEWDATA(First,Temp);
        FColCount--;
        FSize=FRowCount*FColCount;
    }
    catch(...)
    {
		AD_ERRORMEMORY;
    }
}
//---------------------------------------------------------------------------
AD_TEMP ad_index ADMatrix<T>::AddCol(void)
{
	InsertCol(FColCount);
    return FColCount-1;
}
//---------------------------------------------------------------------------
AD_TEMP ad_index ADMatrix<T>::AddRow(void)
{
	InsertRow(FRowCount);
    return FRowCount-1;
}
//---------------------------------------------------------------------------
AD_TEMP ad_index ADMatrix<T>::AddCol(const ADVector<T>& _X)
{
	InsertCol(FColCount,_X);
    return FColCount-1;
}
//---------------------------------------------------------------------------
AD_TEMP ad_index ADMatrix<T>::AddRow(const ADVector<T>& _X)
{
	InsertRow(FRowCount,_X);
    return FRowCount-1;
}
//---------------------------------------------------------------------------
AD_TEMP void ADMatrix<T>::operator = (const ADMatrix<T>& _X)
{
	Resize(_X.RowCount,_X.ColCount);
    CopyData(FData,_X.GetDataAddress(),FRowCount*FColCount);
}
//---------------------------------------------------------------------------
AD_TEMP bool ADMatrix<T>::operator == (const ADMatrix<T>& _X) const
{
	T* XData=_X.GetDataAddress();
	if(FRowCount!=_X.RowCount || FColCount!=_X.ColCount)
    	return false;
	for(ad_index i=0;i<FSize;i++)
    	if(FData[i]!=XData[i])
        	return false;
    return true;
}
//---------------------------------------------------------------------------
AD_TEMP bool ADMatrix<T>::operator != (const ADMatrix<T>& _X) const
{
	T* XData=_X.GetDataAddress();
	if(FRowCount!=_X.RowCount || FColCount!=_X.ColCount)
    	return true;
	for(ad_index i=0;i<FSize;i++)
    	if(FData[i]==XData[i])
        	return false;
    return true;
}
//---------------------------------------------------------------------------
AD_TEMP bool ADMatrix<T>::operator > (const ADMatrix<T>& _X) const
{
    ad_index i;
    ad_size n;
    T* XData=_X.GetDataAddress();
    n=_X.GetSize();
    for(i=0;i<n && i<FSize;i++)
        if(FData[i]<=XData[i])
            return false;
    return true;
}
//---------------------------------------------------------------------------
AD_TEMP bool ADMatrix<T>::operator >= (const ADMatrix<T>& _X) const
{
    ad_index i;
    ad_size n;
    T* XData=_X.GetDataAddress();
    n=_X.GetSize();
    for(i=0;i<n && i<FSize;i++)
        if(FData[i]<XData[i])
            return false;
    return true;
}
//---------------------------------------------------------------------------
AD_TEMP bool ADMatrix<T>::operator < (const ADMatrix<T>& _X) const
{
    ad_index i;
    ad_size n;
    T* XData=_X.GetDataAddress();
    n=_X.GetSize();
    for(i=0;i<n && i<FSize;i++)
        if(FData[i]>=XData[i])
            return false;
    return true;
}
//---------------------------------------------------------------------------
AD_TEMP bool ADMatrix<T>::operator <= (const ADMatrix<T>& _X) const
{
    ad_index i;
    ad_size n;
    T* XData=_X.GetDataAddress();
    n=_X.GetSize();
    for(i=0;i<n && i<FSize;i++)
        if(FData[i]>XData[i])
            return false;
    return true;
}
//---------------------------------------------------------------------------
AD_TEMP ADMatrix<T> ADMatrix<T>::operator + (const ADMatrix<T>& _X) const
{
	ADMatrix<T> Y;
    ad_index i;
    if(FRowCount!=_X.RowCount || FColCount!=_X.ColCount)
        return Y;
    Y.Resize(FRowCount,FColCount);
    T* XData=_X.GetDataAddress();
    T* YData=Y.GetDataAddress();
    for(i=0;i<FSize;i++)
        YData[i]=FData[i]+XData[i];
    return Y;
}
//---------------------------------------------------------------------------
AD_TEMP ADMatrix<T> ADMatrix<T>::operator - (const ADMatrix<T>& _X) const
{
	ADMatrix<T> Y;
    ad_index i;
    if(FRowCount!=_X.RowCount || FColCount!=_X.ColCount)
        return Y;
    Y.Resize(FRowCount,FColCount);
    T* XData=_X.GetDataAddress();
    T* YData=Y.GetDataAddress();
    for(i=0;i<FSize;i++)
        YData[i]=FData[i]-XData[i];
    return Y;
}
//---------------------------------------------------------------------------
AD_TEMP void ADMatrix<T>::operator += (const ADMatrix<T>& _X)
{
    ad_index i;
    if(FRowCount!=_X.RowCount || FColCount!=_X.ColCount)
        return;
    T* XData=_X.GetDataAddress();
    for(i=0;i<FSize;i++)
        FData[i]=FData[i]+XData[i];
}
//---------------------------------------------------------------------------
AD_TEMP void ADMatrix<T>::operator -= (const ADMatrix<T>& _X)
{
    ad_index i;
    if(FRowCount!=_X.RowCount || FColCount!=_X.ColCount)
        return;
    T* XData=_X.GetDataAddress();
    for(i=0;i<FSize;i++)
        FData[i]=FData[i]-XData[i];
}
//---------------------------------------------------------------------------
AD_TEMP ADMatrix<T> ADMatrix<T>::operator + (T _Value) const
{
	ADMatrix<T> Y;
    ad_index i;
    Y.Resize(FRowCount,FColCount);
    T* YData=Y.GetDataAddress();
    for(i=0;i<FSize;i++)
        YData[i]=FData[i]+_Value;
    return Y;
}
//---------------------------------------------------------------------------
AD_TEMP ADMatrix<T> ADMatrix<T>::operator - (T _Value) const
{
	ADMatrix<T> Y;
    ad_index i;
    Y.Resize(FRowCount,FColCount);
    T* YData=Y.GetDataAddress();
    for(i=0;i<FSize;i++)
        YData[i]=FData[i]-_Value;
    return Y;
}
//---------------------------------------------------------------------------
AD_TEMP ADMatrix<T> ADMatrix<T>::operator * (T _Value) const
{
	ADMatrix<T> Y;
    ad_index i;
    Y.Resize(FRowCount,FColCount);
    T* YData=Y.GetDataAddress();
    for(i=0;i<FSize;i++)
        YData[i]=FData[i]*_Value;
    return Y;
}
//---------------------------------------------------------------------------
AD_TEMP ADMatrix<T> ADMatrix<T>::operator / (T _Value) const
{
	ADMatrix<T> Y;
    ad_index i;
    Y.Resize(FRowCount,FColCount);
    T* YData=Y.GetDataAddress();
    for(i=0;i<FSize;i++)
        YData[i]=FData[i]/_Value;
    return Y;
}
//---------------------------------------------------------------------------
AD_TEMP ADMatrix<T> ADMatrix<T>::operator * (const ADMatrix<T>& _X) const
{
    ad_index i, j, k;
    ad_size n=_X.ColCount;
    ADMatrix<T> A;
    if(FColCount!=_X.RowCount || !FData)
        AD_ERRORMULTIPLY;
    A.Resize(FRowCount, n);
    T** XData=_X.GetRowFirstAddress();
    T** AData=A.GetRowFirstAddress();
    for(i=0;i<FRowCount;i++)
        for(j=0;j<n;j++)
        {
            *(AData[i]+j)=0;
            for(k=0;k<FColCount;k++)
                *(AData[i]+j)=*(AData[i]+j)+(*(FRowFirst[i]+k))*(*(XData[k]+j));
        }
    return A;
}
//---------------------------------------------------------------------------
AD_TEMP void ADMatrix<T>::operator *= (const ADMatrix<T>& _X)
{
    ad_index i, j, k;
    ad_size n=_X.ColCount;
    ADMatrix<T> A;
    if(FColCount!=_X.RowCount || !FData)
        AD_ERRORMULTIPLY;
    A.Resize(FRowCount, n);
    T** XData=_X.GetRowFirstAddress();
    T** AData=A.GetRowFirstAddress();
    for(i=0;i<FRowCount;i++)
        for(j=0;j<n;j++)
        {
            *(AData[i]+j)=0;
            for(k=0;k<FColCount;k++)
                *(AData[i]+j)=*(AData[i]+j)+(*(FRowFirst[i]+k))*(*(XData[k]+j));
        }
    Resize(FRowCount, n);
    CopyData(A.GetDataAddress(),FData,FRowCount*n);
}
//---------------------------------------------------------------------------
AD_TEMP ADMatrix<T> ADMatrix<T>::operator ^ (int _Pow) const
{
    int i;
    ADMatrix<T> A;
    if(FRowCount!=FColCount || FSize<1)
    	AD_ERRORPOW;
    A=(*this);
    for(i=1;i<_Pow;i++)
        A=A*(*this);
    return A;
}
//---------------------------------------------------------------------------
AD_TEMP void ADMatrix<T>::operator ^= (int _Pow)
{
    int i;
    ADMatrix<T> A;
    if(FRowCount!=FColCount || FSize<1)
    	AD_ERRORPOW;
    A=(*this);
    for(i=1;i<_Pow;i++)
        A=A*(*this);
    CopyData(A.GetDataAddress(),FData,FRowCount*FColCount);
}
//---------------------------------------------------------------------------
AD_TEMP void ADMatrix<T>::SwapRows(ad_index _Row1, ad_index _Row2)
{
	T Temp;
    for(ad_index i=0;i<FColCount;i++)
    {
    	T=*(FRowFirst[_Row1]+i);
        *(FRowFirst[_Row1]+i)=*(FRowFirst[_Row2]+i);
        *(FRowFirst[_Row2]+i)=T;
    }
}
//---------------------------------------------------------------------------
AD_TEMP void ADMatrix<T>::SwapCols(ad_index _Col1, ad_index _Col2)
{
	T Temp;
    for(ad_index i=0;i<FRowCount;i++)
    {
    	T=*(FRowFirst[i]+_Col1);
        *(FRowFirst[i]+_Col1)=*(FRowFirst[i]+_Col2);
        *(FRowFirst[i]+_Col2)=T;
    }
}
//---------------------------------------------------------------------------
#endif