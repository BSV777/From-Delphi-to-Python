//---------------------------------------------------------------------------
// ClassExplorer Pro generated header file
// Created by Vladimir A. Alexeyev on 23.10.2001, 9:42:54
//---------------------------------------------------------------------------
#ifndef ad_arrayoneH
#define ad_arrayoneH

#include "ad_array.h"
//---------------------------------------------------------------------------
template <class T> class ADArrayOne
	: public ADArray<T>
{
private:
	void __fastcall SetData(int _Index, T value);
	T __fastcall GetData(int _Index) const;
	ad_index __fastcall GetFindIndex(void) const;
protected:
public:
    //------------------------------------------
	__property T Data[int _Index] = { read = GetData, write = SetData };
	__property ad_index FindIndex = { read = GetFindIndex };
    //------------------------------------------
	__fastcall ADArrayOne(ADArrayOne<T>& X);
	__fastcall ADArrayOne(ad_size _Size=0);
	__fastcall ~ADArrayOne(void);
    //------------------------------------------
    virtual void operator = (const ADArrayOne<T>& X);
    //------------------------------------------
	virtual void Resize(ad_size _NewSize);
	virtual void Insert(ad_index _Pos, T _Value);
	virtual void Delete(ad_index _Pos);
	virtual void Insert(ad_index _Pos);
	virtual ad_index Add(T _Value);
	virtual ad_index Add(void);
    //------------------------------------------
	void Swap(ad_index _Index1, ad_index _Index2);
    //------------------------------------------
	T& operator [] (int _Index);
    //------------------------------------------
};
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
AD_TEMP T __fastcall ADArrayOne<T>::GetData(int _Index) const
{
	if(_Index>=0 && _Index<FSize)
    	return FData[_Index];
    else
    	AD_INCORRECTINDEX;
}
//---------------------------------------------------------------------------
AD_TEMP void __fastcall ADArrayOne<T>::SetData(int _Index, T _value)
{
	if(_Index>=0 && _Index<FSize)
    	FData[_Index]=_value;
    else
    	AD_INCORRECTINDEX;
}
//---------------------------------------------------------------------------
AD_TEMP __fastcall ADArrayOne<T>::ADArrayOne(ADArrayOne<T>& _X)
	:ADArray<T>(_X)
{
}
//---------------------------------------------------------------------------
AD_TEMP __fastcall ADArrayOne<T>::~ADArrayOne(void)
{

}
//---------------------------------------------------------------------------
AD_TEMP __fastcall ADArrayOne<T>::ADArrayOne(ad_size _Size)
	:ADArray<T>()
{
	if(_Size>0)
    	Resize(_Size);
}
//---------------------------------------------------------------------------
AD_TEMP void ADArrayOne<T>::Insert(ad_index _Pos, T _Value)
{
    T *temp;
    if(_Pos<0 || _Pos>FSize)
		AD_INCORRECTINDEX;
    try
    {
        temp = new T[FSize+1];
        CopyData(temp,FData,_Pos);
		CopyData(temp+_Pos+1,FData+_Pos,FSize-_Pos);
        temp[_Pos] = _Value;
        FSize++;
        if(FData)
            delete [] FData;
        FData = temp;
    }
    catch(...)
    {
		AD_ERRORMEMORY;
    }
}
//---------------------------------------------------------------------------
AD_TEMP void ADArrayOne<T>::Insert(ad_index _Pos)
{
	Insert(_Pos,FDefault);
}
//---------------------------------------------------------------------------
AD_TEMP void ADArrayOne<T>::Resize(ad_size _NewSize)
{
    T *temp;
    try
    {
        temp = new T[_NewSize];
		CopyData(temp,FData,min(FSize,_NewSize));
        for(ad_index i=FSize;i<_NewSize;i++)
            temp[i] = FDefault;
        if(FData)
            delete [] FData;
        FData = temp;
        FSize=_NewSize;
    }
    catch(...)
    {
		AD_ERRORMEMORY;
    }
}
//---------------------------------------------------------------------------
AD_TEMP ad_index ADArrayOne<T>::Add(T _Value)
{
	Insert(FSize,_Value);
   	return FSize-1;
}
//---------------------------------------------------------------------------
AD_TEMP ad_index ADArrayOne<T>::Add(void)
{
	Insert(FSize,FDefault);
   	return FSize-1;
}
//---------------------------------------------------------------------------
AD_TEMP void ADArrayOne<T>::Delete(ad_index _Pos)
{
    T *temp;
    if(_Pos<0 || _Pos>=FSize)
		AD_INCORRECTINDEX;
    try
    {
        temp = new T[FSize-1];
        FSize--;
        CopyData(temp,FData,_Pos);
        CopyData(temp+_Pos,FData+_Pos+1,FSize-_Pos);
        if(FData)
            delete [] FData;
        FData = temp;
    }
    catch(...)
    {
		AD_ERRORMEMORY;
    }
}
//---------------------------------------------------------------------------
AD_TEMP T& ADArrayOne<T>::operator [](int _Index)
{
	if(_Index>=0 || _Index<FSize)
    	return FData[_Index];
    else
    	AD_INCORRECTINDEX;
}
//---------------------------------------------------------------------------
AD_TEMP void ADArrayOne<T>::Swap(ad_index _Index1, ad_index _Index2)
{
	if(_Index1>=0 && _Index1<FSize && _Index2>=0 && _Index2<FSize
    	&& _Index1!=_Index2)
    {
    	T Temp=FData[_Index1];
        FData[_Index1]=FData[_Index2];
        FData[_Index2]=Temp;
    }
}
//---------------------------------------------------------------------------
AD_TEMP ad_index __fastcall ADArrayOne<T>::GetFindIndex(void) const
{
	return FLastPos;
}
//---------------------------------------------------------------------------
AD_TEMP void ADArrayOne<T>::operator = (const ADArrayOne<T>& X)
{
	Resize(X.Size);
    CopyData(FData,X.GetDataAddress(),FSize);
}
//---------------------------------------------------------------------------
#endif
