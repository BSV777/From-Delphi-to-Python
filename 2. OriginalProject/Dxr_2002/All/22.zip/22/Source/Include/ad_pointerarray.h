//---------------------------------------------------------------------------
// ClassExplorer Pro generated header file
// Created by Vladimir A. Alexeyev on 24.10.2001, 20:39:28
//---------------------------------------------------------------------------
#ifndef ad_PointerArrayH
#define ad_PointerArrayH

#define AD_PTEMP template <class T,class Origin>

#include "ad_arrayone.h"
//---------------------------------------------------------------------------
template <class T,class Origin> class ADPointerArray
	: public ADArrayOne<T> 
{
private:
protected:
public:
    //------------------------------------------
	__fastcall ~ADPointerArray(void);
	__fastcall ADPointerArray(ADPointerArray< T, Origin>& _X);
	__fastcall ADPointerArray(ad_size _Size=0);
    //------------------------------------------
	virtual void Resize(ad_size _NewSize);
	virtual void Delete(ad_index _Pos);
	virtual void Insert(ad_index _Pos);
	virtual ad_index Add(void);
    virtual void Erase(void);
    //------------------------------------------
};
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
AD_PTEMP __fastcall ADPointerArray<T,Origin>::~ADPointerArray(void)
{
	for(ad_index i=0;i<FSize;i++)
    	delete FData[i];
}
//---------------------------------------------------------------------------
AD_PTEMP __fastcall ADPointerArray<T,Origin>::ADPointerArray(ad_size _Size)
	:ADArrayOne<T>(_Size)
{
	FDefault=NULL;
	for(ad_index i=0;i<FSize;i++)
    	FData[i]=new Origin();
}
//---------------------------------------------------------------------------
AD_PTEMP __fastcall ADPointerArray<T,Origin>::ADPointerArray(ADPointerArray<T,Origin>& _X)
	:ADArrayOne<T>(_X)
{
	FDefault=NULL;
}
//---------------------------------------------------------------------------
AD_PTEMP void ADPointerArray<T,Origin>::Resize(ad_size _NewSize)
{
	ad_size OldSize;
    if(FSize==_NewSize)
    	return;
   	for(ad_index i=_NewSize;i<FSize;i++)
    	delete FData[i];
    OldSize=FSize;
    ADArrayOne<T>::Resize(_NewSize);
    for(ad_index i=OldSize;i<FSize;i++)
    	FData[i]=new Origin();
}
//---------------------------------------------------------------------------
AD_PTEMP void ADPointerArray<T,Origin>::Insert(ad_index _Pos)
{
	ADArrayOne<T>::Insert(_Pos,new Origin());
}
//---------------------------------------------------------------------------
AD_PTEMP ad_index ADPointerArray<T,Origin>::Add(void)
{
	ADArrayOne<T>::Insert(FSize,new Origin());
   	return FSize-1;
}
//---------------------------------------------------------------------------
AD_PTEMP void ADPointerArray<T,Origin>::Delete(ad_index _Pos)
{
	if(_Pos<0 || _Pos>=FSize)
    	return;
    delete FData[_Pos];
	ADArrayOne<T>::Delete(_Pos);
}
//---------------------------------------------------------------------------
AD_PTEMP void ADPointerArray<T,Origin>::Erase(void)
{
	for(int i=0;i<FSize;i++)
    	delete FData[i];
    ADArrayOne<T>::Erase();
}
//---------------------------------------------------------------------------
#endif
