//---------------------------------------------------------------------------
#ifndef ad_matharrayH
#define ad_matharrayH

#define AD_TEMP template <class T>

#define AD_INCORRECTINDEX throw("Incorrect index")
#define AD_ERRORMEMORY throw("Error allocating memory")
#define AD_NOTFOUND -1

#include <math.h>

typedef int ad_size;
typedef int ad_index;
//---------------------------------------------------------------------------
template <class T> class ADMathArray
{
private:
	T __fastcall GetDefault(void) const;
	void __fastcall SetDefault(T value);
protected:
	T* FData;
	ad_size FSize;
	T FDefault;
    char FOneSize;

    T FFindLast;
    ad_index FLastPos;

    virtual void CopyData(T* _Dest,T* _Source,ad_size _Count);
public:
    //------------------------------------------
	__property T Default={read=GetDefault,write=SetDefault};
	__property ad_size Size={read=GetSize};
    //------------------------------------------
	__fastcall ADMathArray(void);
    //------------------------------------------
	T* GetDataAddress(void) const;
	ad_size __fastcall GetSize(void) const;
    //------------------------------------------
	virtual void Clear(T _Value);
	virtual bool FindNext(void);
	virtual bool FindFirst(T _Value);
    //------------------------------------------
	virtual bool operator == (T _Value) const;
	virtual bool operator != (T _Value) const;
    virtual bool operator >  (T _Value) const;
    virtual bool operator >= (T _Value) const;
    virtual bool operator <  (T _Value) const;
    virtual bool operator <= (T _Value) const;
    //------------------------------------------
    virtual void operator += (T _Value);
    virtual void operator -= (T _Value);
    virtual void operator *= (T _Value);
    virtual void operator /= (T _Value);
    //------------------------------------------
	virtual void Pow(T _Pow);
    virtual T GetMax(void);
    virtual T GetMin(void);
    virtual ad_size GetLess(T _Value, bool _Eq=false) const;
    virtual ad_size GetGreater(T _Value, bool _Eq=false) const;
    virtual ad_size GetEqual(T _Value) const;
	virtual ad_size GetBetween(T _Value1,T _Value2, bool _Eq=false) const;
    virtual T Summ(void) const;
    //------------------------------------------
};
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
AD_TEMP __fastcall ADMathArray<T>::ADMathArray(void)
{
	FSize=0;
    FData=NULL;
    FLastPos=AD_NOTFOUND;
    FOneSize=sizeof(T);
}
//---------------------------------------------------------------------------
AD_TEMP void __fastcall ADMathArray<T>::SetDefault(T value)
{
	FDefault=value;
}
//---------------------------------------------------------------------------
AD_TEMP T __fastcall ADMathArray<T>::GetDefault(void) const
{
	return FDefault;
}
//---------------------------------------------------------------------------
AD_TEMP ad_size __fastcall ADMathArray<T>::GetSize(void) const
{
	return FSize;
}
//---------------------------------------------------------------------------
AD_TEMP void ADMathArray<T>::CopyData(T* _Dest,T* _Source,ad_size _Count)
{
	memcpy(_Dest,_Source,_Count*FOneSize);
}
//---------------------------------------------------------------------------
AD_TEMP T* ADMathArray<T>::GetDataAddress(void) const
{
	return FData;
}
//---------------------------------------------------------------------------
AD_TEMP void ADMathArray<T>::Clear(T _Value)
{
	ad_index i;
    for(i=0;i<FSize;i++)
    	FData[i]=_Value;
}
//---------------------------------------------------------------------------
AD_TEMP bool ADMathArray<T>::FindNext(void)
{
    ad_index i;
    if(FSize<1 || FLastPos==AD_NOTFOUND)
        return false;
    for(i=FLastPos+1;i<FSize;i++)
        if(FData[i]==FFindLast)
        {
            FLastPos=i;
            return true;
        }
    FLastPos=AD_NOTFOUND;
    return false;
}
//---------------------------------------------------------------------------
AD_TEMP bool ADMathArray<T>::FindFirst(T _Value)
{
	ad_index i;
    if(FSize<1)
        return false;
    for(i=0;i<FSize;i++)
        if(FData[i]==_Value)
        {
            FLastPos=i;
            FFindLast=_Value;
            return true;
        }
    FLastPos=AD_NOTFOUND;
    return false;
}
//---------------------------------------------------------------------------
AD_TEMP bool ADMathArray<T>::operator == (T _Value) const
{
	for(ad_index i=0;i<FSize;i++)
    	if(FData[i]!=_Value)
        	return false;
    return true;
}
//---------------------------------------------------------------------------
AD_TEMP bool ADMathArray<T>::operator != (T _Value) const
{
	for(ad_index i=0;i<FSize;i++)
    	if(FData[i]==_Value)
        	return false;
    return true;
}
//---------------------------------------------------------------------------
AD_TEMP bool ADMathArray<T>::operator > (T _Value) const
{
    ad_index i;
    for(i=0;i<FSize;i++)
        if(FData[i]<=_Value)
            return false;
    return true;
}
//---------------------------------------------------------------------------
AD_TEMP bool ADMathArray<T>::operator >= (T _Value) const
{
    ad_index i;
    for(i=0;i<FSize;i++)
        if(FData[i]<_Value)
            return false;
    return true;
}
//---------------------------------------------------------------------------
AD_TEMP bool ADMathArray<T>::operator < (T _Value) const
{
    ad_index i;
    for(i=0;i<FSize;i++)
        if(FData[i]>=_Value)
            return false;
    return true;
}
//---------------------------------------------------------------------------
AD_TEMP bool ADMathArray<T>::operator <= (T _Value) const
{
    ad_index i;
    for(i=0;i<FSize;i++)
        if(FData[i]>_Value)
            return false;
    return true;
}
//---------------------------------------------------------------------------
AD_TEMP void ADMathArray<T>::operator += (T _Value)
{
    ad_index i;
    for(i=0;i<FSize;i++)
        FData[i]=FData[i]+_Value;
}
//---------------------------------------------------------------------------
AD_TEMP void ADMathArray<T>::operator -= (T _Value)
{
    ad_index i;
    for(i=0;i<FSize;i++)
        FData[i]=FData[i]-_Value;
}
//---------------------------------------------------------------------------
AD_TEMP void ADMathArray<T>::operator *= (T _Value)
{
    ad_index i;
    for(i=0;i<FSize;i++)
        FData[i]=FData[i]*_Value;
}
//---------------------------------------------------------------------------
AD_TEMP void ADMathArray<T>::operator /= (T _Value)
{
    ad_index i;
    for(i=0;i<FSize;i++)
        FData[i]=FData[i]/_Value;
}
//---------------------------------------------------------------------------
AD_TEMP void ADMathArray<T>::Pow(T _Pow)
{
    ad_index i;
    for(i=0;i<FSize;i++)
        FData[i]=pow(FData[i],_Pow);
}
//---------------------------------------------------------------------------
AD_TEMP T ADMathArray<T>::GetMax(void)
{
    if(FSize<1)
    {
    	FLastPos=AD_NOTFOUND;
        return FDefault;
    }
    T Max=FData[0];
    FLastPos=0;
    for(ad_index i=1;i<FSize;i++)
        if(Max<FData[i])
        {
            Max=FData[i];
            FLastPos=i;
        }
    return Max;
}
//---------------------------------------------------------------------------
AD_TEMP T ADMathArray<T>::GetMin(void)
{
    if(FSize<1)
    {
    	FLastPos=AD_NOTFOUND;
        return FDefault;
    }
    T Min=FData[0];
    FLastPos=0;
    for(ad_index i=1;i<FSize;i++)
        if(Min>FData[i])
        {
            Min=FData[i];
            FLastPos=i;
        }
    return Min;
}
//---------------------------------------------------------------------------
AD_TEMP ad_size ADMathArray<T>::GetLess(T _Value, bool _Eq) const
{
	ad_size Count=0;
    if(_Eq)
    {
    	for(ad_index i=0;i<FSize;i++)
    		if(FData[i]<=_Value)
        		Count++;
    }
    else
	{
    	for(ad_index i=0;i<FSize;i++)
    		if(FData[i]<_Value)
        		Count++;
    }
    return Count;
}
//---------------------------------------------------------------------------
AD_TEMP ad_size ADMathArray<T>::GetGreater(T _Value, bool _Eq) const
{
	ad_size Count=0;
    if(_Eq)
    {
		for(ad_index i=0;i<FSize;i++)
    		if(FData[i]>=_Value)
        		Count++;
    }
    else
	{
		for(ad_index i=0;i<FSize;i++)
    		if(FData[i]>_Value)
        		Count++;
    }
    return Count;
}
//---------------------------------------------------------------------------
AD_TEMP ad_size ADMathArray<T>::GetEqual(T _Value) const
{
	ad_size Count=0;
	for(ad_index i=0;i<FSize;i++)
    	if(FData[i]==_Value)
        	Count++;
    return Count;
}
//---------------------------------------------------------------------------
AD_TEMP ad_size ADMathArray<T>::GetBetween(T _Value1,T _Value2, bool _Eq) const
{
	ad_size Count=0;
    if(_Eq)
    {
		for(ad_index i=0;i<FSize;i++)
    		if(FData[i]>=_Value1 && FData[i]<=_Value2)
        		Count++;
    }
    else
    {
		for(ad_index i=0;i<FSize;i++)
    		if(FData[i]>_Value1 && FData[i]<_Value2)
        		Count++;
    }
    return Count;
}
//---------------------------------------------------------------------------
AD_TEMP T ADMathArray<T>::Summ(void) const
{
	T Rez;
    Rez=(T)0;
    for(ad_size i=0;i<FSize;i++)
    	Rez=Rez+FData[i];
    return Rez;
}
//---------------------------------------------------------------------------
#endif
