//---------------------------------------------------------------------------
#ifndef ad_vectorH
#define ad_vectorH

#include "ad_matharray.h"
//---------------------------------------------------------------------------
template <class T> class ADVector
	: public ADMathArray<T>
{
private:
	void __fastcall SetData(ad_index _Index, T value);
	T __fastcall GetData(ad_index _Index) const;
	ad_index __fastcall GetFindIndex(void) const;
protected:
public:
    //------------------------------------------
	__property T Data[ad_index _Index]={read=GetData,write=SetData};
	__property ad_index FindIndex={read=GetFindIndex };
    //------------------------------------------
	__fastcall ~ADVector(void);
	__fastcall ADVector(const ADVector<T>& _X);
	__fastcall ADVector(ad_size _Size=0);
    //------------------------------------------
    virtual void Erase(void);
	virtual void Resize(ad_size _NewSize);
	virtual void Insert(ad_index _Pos, T _Value);
	virtual void Delete(ad_index _Pos);
	virtual void Insert(ad_index _Pos);
	virtual ad_index Add(T _Value);
	virtual ad_index Add(void);
    //------------------------------------------
	T& operator [] (ad_index _Index);
    //------------------------------------------
    virtual void operator = (const ADVector<T>& _X);
	virtual bool operator == (const ADVector<T>& _X) const;
	virtual bool operator != (const ADVector<T>& _X) const;
    //------------------------------------------
    virtual bool operator > (const ADVector<T>& _X) const;
    virtual bool operator >= (const ADVector<T>& _X) const;
    virtual bool operator < (const ADVector<T>& _X) const;
    virtual bool operator <= (const ADVector<T>& _X) const;
    //------------------------------------------
    virtual ADVector<T> operator + (const ADVector<T>& _X) const;
    virtual ADVector<T> operator - (const ADVector<T>& _X) const;
    virtual void operator += (const ADVector<T>& _X);
    virtual void operator -= (const ADVector<T>& _X);
    virtual ADVector<T> operator + (T _Value) const;
    virtual ADVector<T> operator - (T _Value) const;
    virtual ADVector<T> operator * (T _Value) const;
    virtual ADVector<T> operator / (T _Value) const;
    //------------------------------------------
	void Swap(ad_index _Index1, ad_index _Index2);
    virtual void SortDirect(void);
    virtual void SortReverse(void);
    //------------------------------------------
    T Moment(int _Pow) const;
    T Average(void) const;
    T Var(int _DivDec=0) const;
    T CenterMoment(int _Pow) const;
    T Asimmetrion(void) const;
    T Eccess(void) const;
    T Variation(void) const;
    //------------------------------------------
};
//---------------------------------------------------------------------------
typedef ADVector<double> DVector;
typedef ADVector<int> IVector;
typedef ADVector<bool> BVector;
//---------------------------------------------------------------------------
AD_TEMP __fastcall ADVector<T>::~ADVector(void)
{
	delete [] FData;
}
//---------------------------------------------------------------------------
AD_TEMP __fastcall ADVector<T>::ADVector(ad_size _Size)
{
	if(_Size>0)
    	Resize(_Size);
}
//---------------------------------------------------------------------------
AD_TEMP __fastcall ADVector<T>::ADVector(const ADVector<T>& _X)
{
	FDefault=_X.Default;
	if(_X.Size>0)
    {
    	Resize(_X.Size);
        CopyData(FData,_X.GetDataAddress(),FSize);
    }
}
//---------------------------------------------------------------------------
AD_TEMP T __fastcall ADVector<T>::GetData(ad_index _Index) const
{
	if(_Index>=0 && _Index<FSize)
    	return FData[_Index];
    else
    	AD_INCORRECTINDEX;
}
//---------------------------------------------------------------------------
AD_TEMP void __fastcall ADVector<T>::SetData(ad_index _Index, T _value)
{
	if(_Index>=0 && _Index<FSize)
    	FData[_Index]=_value;
    else
    	AD_INCORRECTINDEX;
}
//---------------------------------------------------------------------------
AD_TEMP T& ADVector<T>::operator [](ad_index _Index)
{
	if(_Index>=0 || _Index<FSize)
    	return FData[_Index];
    else
    	AD_INCORRECTINDEX;
}
//---------------------------------------------------------------------------
AD_TEMP ad_index __fastcall ADVector<T>::GetFindIndex(void) const
{
	return FLastPos;
}
//---------------------------------------------------------------------------
AD_TEMP void ADVector<T>::Erase(void)
{
    FSize=0;
    delete [] FData;
    FData=NULL;
    FLastPos=AD_NOTFOUND;
    FFindLast=FDefault;
}
//---------------------------------------------------------------------------
AD_TEMP void ADVector<T>::Insert(ad_index _Pos, T _Value)
{
    T *temp;
    if(_Pos<0 || _Pos>FSize)
		AD_INCORRECTINDEX;
    try
    {
        temp = new T[FSize+1];
        CopyData(temp,FData,_Pos);
		CopyData(temp+_Pos+1,FData+_Pos,FSize-_Pos);
        temp[_Pos] = _Value;
        FSize++;
        delete [] FData;
        FData = temp;
    }
    catch(...)
    {
		AD_ERRORMEMORY;
    }
}
//---------------------------------------------------------------------------
AD_TEMP void ADVector<T>::Insert(ad_index _Pos)
{
	Insert(_Pos,FDefault);
}
//---------------------------------------------------------------------------
AD_TEMP void ADVector<T>::Resize(ad_size _NewSize)
{
    T *temp;
    try
    {
        temp = new T[_NewSize];
		CopyData(temp,FData,min(FSize,_NewSize));
        for(ad_index i=FSize;i<_NewSize;i++)
            temp[i] = FDefault;
        delete [] FData;
        FData = temp;
        FSize=_NewSize;
    }
    catch(...)
    {
		AD_ERRORMEMORY;
    }
}
//---------------------------------------------------------------------------
AD_TEMP ad_index ADVector<T>::Add(T _Value)
{
	Insert(FSize,_Value);
   	return FSize-1;
}
//---------------------------------------------------------------------------
AD_TEMP ad_index ADVector<T>::Add(void)
{
	Insert(FSize,FDefault);
   	return FSize-1;
}
//---------------------------------------------------------------------------
AD_TEMP void ADVector<T>::Delete(ad_index _Pos)
{
    T *temp;
    if(_Pos<0 || _Pos>=FSize)
		AD_INCORRECTINDEX;
    try
    {
        temp = new T[FSize-1];
        FSize--;
        CopyData(temp,FData,_Pos);
        CopyData(temp+_Pos,FData+_Pos+1,FSize-_Pos);
        delete [] FData;
        FData = temp;
    }
    catch(...)
    {
		AD_ERRORMEMORY;
    }
}
//---------------------------------------------------------------------------
AD_TEMP void ADVector<T>::Swap(ad_index _Index1, ad_index _Index2)
{
	if(_Index1>=0 && _Index1<FSize && _Index2>=0 && _Index2<FSize
    	&& _Index1!=_Index2)
    {
    	T Temp=FData[_Index1];
        FData[_Index1]=FData[_Index2];
        FData[_Index2]=Temp;
    }
}
//---------------------------------------------------------------------------
AD_TEMP void ADVector<T>::SortDirect(void)
{
    ad_index i,j;
    T temp;
    if(FSize<2)
        return;
    for(i=0;i<FSize;i++)
        for(j=i+1;j<FSize;j++)
            if(FData[i]>FData[j])
            {
                temp=FData[i];
                FData[i]=FData[j];
                FData[j]=temp;
            }
}
//---------------------------------------------------------------------------
AD_TEMP void ADVector<T>::SortReverse(void)
{
    ad_index i,j;
    T temp;
    if(FSize<2)
        return;
    for(i=0;i<FSize;i++)
        for(j=i+1;j<FSize;j++)
            if(FData[i]<FData[j])
            {
                temp=FData[i];
                FData[i]=FData[j];
                FData[j]=temp;
            }
}
//---------------------------------------------------------------------------
AD_TEMP T ADVector<T>::Moment(int _Pow) const
{
    T Rez=0;
    for(ad_index i=0;i<FSize;i++)
        Rez+=pow(FData[i],_Pow);
    return Rez;
}
//---------------------------------------------------------------------------
AD_TEMP T ADVector<T>::Average(void) const
{
	if(FSize==0)
    	return 0;
    return Summ()/(T)FSize;
}
//---------------------------------------------------------------------------
AD_TEMP T ADVector<T>::Var(int _DivDec) const
{
    T Rez,M;
    if(FSize-_DivDec<1)
    	return 0;
    M=Summ()/(T)FSize;
    Rez=0;
    for(ad_index i=0;i<FSize;i++)
        Rez+=(FData[i]-M)*(FData[i]-M);
    return Rez/(T)(FSize-_DivDec);
}
//---------------------------------------------------------------------------
AD_TEMP T ADVector<T>::CenterMoment(int _Pow) const
{
	T M,Rez;
    if(FSize==0)
    	return 0;
    M=Summ()/(T)FSize;
    Rez=0;
    for(ad_index i=0;i<FSize;i++)
    	Rez+=pow(FData[i]-M,_Pow);
    return Rez;
}
//---------------------------------------------------------------------------
AD_TEMP T ADVector<T>::Asimmetrion(void) const
{
	T SO;
	if(FSize==0)
    	return 0;
	SO=sqrt(Var());
    if(SO==0)
    	return 0;
	return CenterMoment(3)/pow(SO,3);
}
//---------------------------------------------------------------------------
AD_TEMP T ADVector<T>::Eccess(void) const
{
	T SO;
	if(FSize==0)
    	return 0;
	SO=Var();
    if(SO==0)
    	return 0;
	return CenterMoment(4)/pow(SO,2)-3.0;
}
//---------------------------------------------------------------------------
AD_TEMP T ADVector<T>::Variation(void) const
{
    T M;
    M=Average();
    if(M!=(T)0)
    	return sqrt(Var(1))/Average();
    else
        return (T)0;
}
//---------------------------------------------------------------------------
AD_TEMP void ADVector<T>::operator = (const ADVector<T>& _X)
{
	Resize(_X.Size);
    CopyData(FData,_X.GetDataAddress(),FSize);
}
//---------------------------------------------------------------------------
AD_TEMP bool ADVector<T>::operator == (const ADVector<T>& _X) const
{
	T* XData=_X.GetDataAddress();
	if(FSize!=_X.Size)
    	return false;
	for(ad_index i=0;i<FSize;i++)
    	if(FData[i]!=XData[i])
        	return false;
    return true;
}
//---------------------------------------------------------------------------
AD_TEMP bool ADVector<T>::operator != (const ADVector<T>& _X) const
{
	T* XData=_X.GetDataAddress();
	if(FSize!=_X.Size)
    	return true;
	for(ad_index i=0;i<FSize;i++)
    	if(FData[i]==XData[i])
        	return false;
    return true;
}
//---------------------------------------------------------------------------
AD_TEMP bool ADVector<T>::operator > (const ADVector<T>& _X) const
{
    ad_index i;
    ad_size n;
    T* XData=_X.GetDataAddress();
    n=_X.GetSize();
    for(i=0;i<n && i<FSize;i++)
        if(FData[i]<=XData[i])
            return false;
    return true;
}
//---------------------------------------------------------------------------
AD_TEMP bool ADVector<T>::operator >= (const ADVector<T>& _X) const
{
    ad_index i;
    ad_size n;
    T* XData=_X.GetDataAddress();
    n=_X.GetSize();
    for(i=0;i<n && i<FSize;i++)
        if(FData[i]<XData[i])
            return false;
    return true;
}
//---------------------------------------------------------------------------
AD_TEMP bool ADVector<T>::operator < (const ADVector<T>& _X) const
{
    ad_index i;
    ad_size n;
    T* XData=_X.GetDataAddress();
    n=_X.GetSize();
    for(i=0;i<n && i<FSize;i++)
        if(FData[i]>=XData[i])
            return false;
    return true;
}
//---------------------------------------------------------------------------
AD_TEMP bool ADVector<T>::operator <= (const ADVector<T>& _X) const
{
    ad_index i;
    ad_size n;
    T* XData=_X.GetDataAddress();
    n=_X.GetSize();
    for(i=0;i<n && i<FSize;i++)
        if(FData[i]>XData[i])
            return false;
    return true;
}
//---------------------------------------------------------------------------
AD_TEMP ADVector<T> ADVector<T>::operator + (const ADVector<T>& _X) const
{
	ADVector<T> Y;
    ad_index i;
    if(FSize!=_X.GetSize())
        return Y;
    Y.Resize(FSize);
    T* XData=_X.GetDataAddress();
    T* YData=Y.GetDataAddress();
    for(i=0;i<FSize;i++)
        YData[i]=FData[i]+XData[i];
    return Y;
}
//---------------------------------------------------------------------------
AD_TEMP ADVector<T> ADVector<T>::operator - (const ADVector<T>& _X) const
{
	ADVector<T> Y;
    ad_index i;
    if(FSize!=_X.GetSize())
        return Y;
    Y.Resize(FSize);
    T* XData=_X.GetDataAddress();
    T* YData=Y.GetDataAddress();
    for(i=0;i<FSize;i++)
        YData[i]=FData[i]-XData[i];
    return Y;
}
//---------------------------------------------------------------------------
AD_TEMP void ADVector<T>::operator += (const ADVector<T>& _X)
{
    ad_index i;
    if(FSize!=_X.GetSize())
        return;
    T* XData=_X.GetDataAddress();
    for(i=0;i<FSize;i++)
        FData[i]=FData[i]+XData[i];
}
//---------------------------------------------------------------------------
AD_TEMP void ADVector<T>::operator -= (const ADVector<T>& _X)
{
    ad_index i;
    if(FSize!=_X.GetSize())
        return;
    T* XData=_X.GetDataAddress();
    for(i=0;i<FSize;i++)
        FData[i]=FData[i]-XData[i];
}
//---------------------------------------------------------------------------
AD_TEMP ADVector<T> ADVector<T>::operator + (T _Value) const
{
	ADVector<T> Y;
    ad_index i;
    Y.Resize(FSize);
    T* YData=Y.GetDataAddress();
    for(i=0;i<FSize;i++)
        YData[i]=FData[i]+_Value;
    return Y;
}
//---------------------------------------------------------------------------
AD_TEMP ADVector<T> ADVector<T>::operator - (T _Value) const
{
	ADVector<T> Y;
    ad_index i;
    Y.Resize(FSize);
    T* YData=Y.GetDataAddress();
    for(i=0;i<FSize;i++)
        YData[i]=FData[i]-_Value;
    return Y;
}
//---------------------------------------------------------------------------
AD_TEMP ADVector<T> ADVector<T>::operator * (T _Value) const
{
	ADVector<T> Y;
    ad_index i;
    Y.Resize(FSize);
    T* YData=Y.GetDataAddress();
    for(i=0;i<FSize;i++)
        YData[i]=FData[i]*_Value;
    return Y;
}
//---------------------------------------------------------------------------
AD_TEMP ADVector<T> ADVector<T>::operator / (T _Value) const
{
	ADVector<T> Y;
    ad_index i;
    Y.Resize(FSize);
    T* YData=Y.GetDataAddress();
    for(i=0;i<FSize;i++)
        YData[i]=FData[i]/_Value;
    return Y;
}
//---------------------------------------------------------------------------
#endif