//---------------------------------------------------------------------------

#ifndef MathemH
#define MathemH

#include <AD_ArrayOne.h>
#include <AD_PointerArray.h>
#include <stdio.h>
#include <AD_Vector.h>
#include <AD_Matrix.h>
#define INIT -9999
//---------------------------------------------------------------------------
enum APObjectType {objLabel = 1, objEdit, objButton};
enum APSortType {srtHorizontal = 1, srtVertical};
//---------------------------------------------------------------------------
struct APColsInfo {
    IVector ColCount;
    IVector RowCount;
    IVector ObjectIndex;
};
//---------------------------------------------------------------------------
struct APBlock {
private:
    APSortType FSortType;
public:
    ADPointerArray <APBlock*, APBlock> *Blocks;
    ADArrayOne <TControl*> *Objects;
    int Bottom;
    int Right;
    int Top;
    int Left;
    __property int Width = {read = GetWidth};
    __property int Height = {read = GetHeight};
    __property APSortType SortType = {read = GetSortType};
    APBlock(void);
    ~APBlock(void);
    void AddObject(TControl *_Control);
    void SortObjects(APSortType _SortType);
    void FillBlocks(int _ColPrev);

protected:
    APSortType __fastcall GetSortType(void)
    {
        return FSortType;
    }
    int __fastcall GetWidth(void)
    {
        return (Right - Left);
    }
    int __fastcall GetHeight(void)
    {
        return (Bottom - Top);
    }
};
//---------------------------------------------------------------------------
class APObjectData {
public:
    APObjectData(void);
    ~APObjectData(void);
    bool AddObject(TWinControl* _Parent, APObjectType _Type, int _X, int _Y);
    bool AddObject(TWinControl* _Parent, TControl *_Control);
    bool SetObjectProperty(TControl* _Control, AnsiString _PropName, AnsiString &_Value);
    bool CorrectObjectPosition(TControl *_Control);
    void SaveToHTML(AnsiString _FileName);
    int GetMaxX(void);
    int GetMaxY(void);

    ADArrayOne <TControl*> Objects;
    int Method;
private:
    int FLabelCount;
    int FEditCount;
    int FButtonCount;
    APBlock *FBlocks;

    bool TestName(TControl* _Control, AnsiString _ControlName);
    void SortObjectsByBlock(void);
    void DrawBlock(FILE* stream, APBlock* Block, int _Top, int _Left);
    void DrawObject(FILE* stream, TControl* Block);
    void Method1(FILE* stream);
    void Method2(FILE* stream);
};
//---------------------------------------------------------------------------
#endif
