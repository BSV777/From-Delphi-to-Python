//---------------------------------------------------------------------------

#ifndef InspectorH
#define InspectorH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TfrmInspector : public TForm
{
__published:	// IDE-managed Components
    TPanel *Panel1;
    TComboBox *cmbObjects;
    TPageControl *PageControl1;
    TTabSheet *tbsLabel;
    TPanel *Panel2;
    TStringGrid *grdProperty;
    void __fastcall cmbObjectsChange(TObject *Sender);
    void __fastcall grdPropertySetEditText(TObject *Sender, int ACol,
          int ARow, const AnsiString Value);
    void __fastcall grdPropertyKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
    void __fastcall grdPropertyMouseWheelDown(TObject *Sender,
          TShiftState Shift, TPoint &MousePos, bool &Handled);
    void __fastcall grdPropertyMouseWheelUp(TObject *Sender,
          TShiftState Shift, TPoint &MousePos, bool &Handled);
    void __fastcall grdPropertyExit(TObject *Sender);
    void __fastcall FormDeactivate(TObject *Sender);
private:	// User declarations
    int SelRow;
    bool Modify;
public:		// User declarations
    __fastcall TfrmInspector(TComponent* Owner);
    void LoadObjectPropeties(TControl *_Control);
    void LoadButtonProperties(TButton *_Button);
    void LoadLabelProperties(TLabel *_Label);
    void LoadEditProperties(TEdit *_Edit);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmInspector *frmInspector;
//---------------------------------------------------------------------------
#endif
