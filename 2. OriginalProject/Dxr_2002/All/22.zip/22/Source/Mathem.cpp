//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Mathem.h"

//---------------------------------------------------------------------------
    APBlock::APBlock(void)
{
    Right = INIT;
    Bottom = INIT;
    Left = INIT;
    Top = INIT;
    FSortType = srtVertical;
    Objects = new ADArrayOne <TControl*>;
    Blocks = NULL;
}
//---------------------------------------------------------------------------
    APBlock::~APBlock(void)
{
    if(Objects)
        delete Objects;
    if(Blocks)
        delete Blocks;
}
//---------------------------------------------------------------------------
void APBlock::AddObject(TControl *_Control)
{
    if(Left == INIT)
        Left = _Control->Left;
    else if(_Control->Left < Left)
        Left = _Control->Left;
    if(Top == INIT)
        Top = _Control->Top;
    else if(_Control->Top < Top)
        Top = _Control->Top;
    if(Right == INIT)
        Right = _Control->Left + _Control->Width;
    else if(_Control->Left + _Control->Width > Right)
        Right = _Control->Left + _Control->Width;
    if(Bottom == INIT)
        Bottom = _Control->Top + _Control->Height;
    else if(_Control->Top + _Control->Height > Bottom)
        Bottom = _Control->Top + _Control->Height;
    Objects->Add(_Control);
}
//---------------------------------------------------------------------------
void APBlock::SortObjects(APSortType _SortType)
{
    for(int i=0;i<Objects->Size;i++)
    {
        bool swap = false;
        for(int j=0;j<Objects->Size - 1;j++)
            switch(_SortType)
            {
                case srtVertical:   {
                                        if(Objects->Data[j]->Top > Objects->Data[j + 1]->Top)
                                        {
                                            Objects->Swap(j, j + 1);
                                            swap = true;
                                        }
                                        break;
                                    }
                case srtHorizontal: {
                                        if(Objects->Data[j]->Left > Objects->Data[j + 1]->Left)
                                        {
                                            Objects->Swap(j, j + 1);
                                            swap = true;
                                        }
                                        break;
                                    }
            }
        if(!swap)
            break;
    }
    FSortType = _SortType;
}
//---------------------------------------------------------------------------
void APBlock::FillBlocks(int _ColPrev)
{
    if(Objects->Size < 1)
        return;
    if(Blocks)
        delete Blocks;
    Blocks = new ADPointerArray <APBlock*, APBlock>;
    int BlockIndex = Blocks->Add();
    Blocks->Data[BlockIndex]->AddObject(Objects->Data[0]);

    for(int j=1;j<Objects->Size;j++)
    {
        switch(FSortType)
        {
            case srtVertical:   {
                                    if(Objects->Data[j]->Top > Blocks->Data[BlockIndex]->Bottom)
                                        BlockIndex = Blocks->Add();
                                    break;
                                }
            case srtHorizontal: {
                                    if(Objects->Data[j]->Left > Blocks->Data[BlockIndex]->Right)
                                        BlockIndex = Blocks->Add();
                                    break;
                                }
        }
        Blocks->Data[BlockIndex]->AddObject(Objects->Data[j]);
    }
    Objects->Resize(0);
//���������� ������������ ������
    for(int i=0;i<Blocks->Size;i++)
        switch(FSortType)
        {
            case srtVertical:   {
                                    Blocks->Data[i]->SortObjects(srtHorizontal);
                                    break;
                                }
            case srtHorizontal: {
                                    Blocks->Data[i]->SortObjects(srtVertical);
                                    break;
                                }
        }
//���������� ������������ ������ �� ������������
    if(Blocks->Size == 1 && _ColPrev == 1)
        return;
    for(int i=0;i<Blocks->Size;i++)
        Blocks->Data[i]->FillBlocks(Blocks->Size);
}
//---------------------------------------------------------------------------
    APObjectData::APObjectData(void)
{
    FLabelCount = 0;
    FButtonCount = 0;
    FEditCount = 0;
    FBlocks = NULL;
    Method = 1;
}
//---------------------------------------------------------------------------
    APObjectData::~APObjectData(void)
{
    for(int i=0;i<Objects.Size;i++)
        delete Objects.Data[i];
    if(FBlocks)
        delete FBlocks;
}
//---------------------------------------------------------------------------
bool APObjectData::AddObject(TWinControl* _Parent, APObjectType _Type, int _X, int _Y)
{
    TControl *NewComponent = NULL;
    switch(_Type)
    {
        case objLabel:  {
                            TLabel* NewLabel = new TLabel(_Parent);
                            NewLabel->AutoSize = true;
                            NewLabel->Font->Size = 10;
                            FLabelCount++;
                            NewLabel->Caption = "����� " + IntToStr(FLabelCount);
                            NewLabel->Name = "Label" + IntToStr(FLabelCount);
                            NewComponent = NewLabel;
                            break;
                        }
        case objEdit:  {
                            TEdit* NewEdit = new TEdit(_Parent);
                            NewEdit->ReadOnly = true;
                            NewEdit->Font->Size = 10;
                            FEditCount++;
                            NewEdit->Text = "���� ����� " + IntToStr(FEditCount);
                            NewEdit->Name = "Edit" + IntToStr(FEditCount);
                            NewComponent = NewEdit;
                            break;
                        }
        case objButton:  {
                            TButton* NewButton = new TButton(_Parent);
                            FButtonCount++;
                            NewButton->Caption = "������ " + IntToStr(FButtonCount);
                            NewButton->Name = "Button" + IntToStr(FButtonCount);
                            NewButton->Font->Size = 10;
                            NewComponent = NewButton;
                            break;
                        }
    }
    NewComponent->Left = _X;
    NewComponent->Top = _Y;
    NewComponent->Parent = _Parent;
    NewComponent->Visible = true;
    NewComponent->Cursor = crArrow;
    Objects.Add(NewComponent);
    return true;
}
//---------------------------------------------------------------------------
bool APObjectData::SetObjectProperty(TControl* _Control, AnsiString _PropName, AnsiString &_Value)
{
    _PropName = _PropName.LowerCase();
    if(_PropName == "name")
    {
        AnsiString OldName = _Control->Name;
        try
        {
            if(!TestName(_Control, _Value))
                throw(1);
            _Control->Name = _Value;
        }
        catch(...)
        {
            _Control->Name = OldName;
            _Value = OldName;
            return false;
        }
    }
    else if(_PropName == "left")
    {
        int NewLeft = 0;
        try
        {
            NewLeft = StrToInt(_Value);
            _Control->Left = NewLeft;
        }
        catch(...)
        {
            _Value = IntToStr(_Control->Left);
            return false;
        }
    }
    else if(_PropName == "top")
    {
        int NewTop = 0;
        try
        {
            NewTop = StrToInt(_Value);
            _Control->Top = NewTop;
        }
        catch(...)
        {
            _Value = IntToStr(_Control->Top);
            return false;
        }
    }
    else if(_PropName == "width")
    {
        int NewWidth = 0;
        try
        {
            NewWidth = StrToInt(_Value);
            if(NewWidth < 1)
                throw(1);
            _Control->Width = NewWidth;
        }
        catch(...)
        {
            _Value = IntToStr(_Control->Width);
            return false;
        }
    }
    else if(_PropName == "height")
    {
        int NewHeight = 0;
        try
        {
            NewHeight = StrToInt(_Value);
            if(NewHeight < 1)
                throw(1);
            _Control->Height = NewHeight;
        }
        catch(...)
        {
            _Value = IntToStr(_Control->Height);
            return false;
        }
    }
    else if(_PropName == "caption")
    {

        ((TButton*)_Control)->Caption = _Value.SubString(1, 255);
        _Value = _Value.SubString(1, 255);
        if(_Value.Length() > 255)
        {
            _Value = _Value.SubString(1, 255);
            return false;
        }
    }
    else if(_PropName == "text")
    {
        if(_Control->ClassNameIs("TLabel"))
            ((TLabel*)_Control)->Caption = _Value.SubString(1, 255);
        else if(_Control->ClassNameIs("TEdit"))
            ((TEdit*)_Control)->Text = _Value.SubString(1, 255);
        if(_Value.Length() > 255)
        {
            _Value = _Value.SubString(1, 255);
            return false;
        }
    }
    CorrectObjectPosition(_Control);
    return true;
}
//---------------------------------------------------------------------------
bool APObjectData::CorrectObjectPosition(TControl *_Control)
{
    int Top = _Control->Top;
    int Left = _Control->Left;
    int Width = _Control->Width;
    int Height = _Control->Height;

    for(int i=0;i<Objects.Size;i++)
    {
        bool Move = false;
        for(int i=0;i<Objects.Size;i++)
        {
            if(Objects.Data[i] == _Control)
                continue;
            int X1 = Objects.Data[i]->Left;
            int Y1 = Objects.Data[i]->Top;
            int X2 = Objects.Data[i]->Left + Objects.Data[i]->Width;
            int Y4 = Objects.Data[i]->Top + Objects.Data[i]->Height;
            if(Top >= Y1 && Top <= Y4 && Left >= X1 && Left <= X2)
            {
                Top = Y4 + 1;
                Move = true;
            }
            else if((Top + Height) >= Y1 && (Top + Height) <= Y4 && Left >= X1 && Left <= X2)
            {
                Top = Y4 + 1;
                Move = true;
            }
            else if(Top >= Y1 && Top <= Y4 && (Left + Width) >= X1 && (Left + Width) <= X2)
            {
                Top = Y4 + 1;
                Move = true;
            }
            else if((Top + Height) >= Y1 && (Top + Height) <= Y4 && (Left + Width) >= X1 && (Left + Width) <= X2)
            {
                Top = Y4 + 1;
                Move = true;
            }
            else if(Top < Y1 && Top + Height > Y4 && Left >= X1 && Left <= X2)
            {
                Left = X2 + 1;
                Move = true;
            }
            else if(Top < Y1 && Top + Height > Y4 && Left + Width >= X1 && Left + Width <= X2)
            {
                Left = X2 + 1;
                Move = true;
            }
            else if(Top >= Y1 && Top <= Y4 && Left < X1 && Left + Width > X2)
            {
                Top = Y4 + 1;
                Move = true;
            }
            else if(Top + Height >= Y1 && Top + Height <= Y4 && Left < X1 && Left + Width > X2)
            {
                Top = Y4 + 1;
                Move = true;
            }
            else if(Top < Y1 && Top + Height > Y4 && Left < X1 && Left + Width > X2)
            {
                Top = Y4 + 1;
                Move = true;
            }
        }
        if(!Move)
            break;
    }
    if(Top != _Control->Top || Left != _Control->Left)
    {
        _Control->Top = Top;
        _Control->Left = Left;
        return true;
    }
    return false;
}
//---------------------------------------------------------------------------
bool APObjectData::AddObject(TWinControl* _Parent, TControl *_Control)
{
    TControl *NewComponent = NULL;
    if(_Control->ClassNameIs("TLabel"))
    {
        TLabel *OldLabel = (TLabel*)_Control;
        TLabel* NewLabel = new TLabel(_Parent);
        NewLabel->AutoSize = true;
        NewLabel->Caption = OldLabel->Caption;
        NewLabel->Width = OldLabel->Width;
        NewLabel->Height = OldLabel->Height;
        NewLabel->Top = OldLabel->Top;
        NewLabel->Left = OldLabel->Left;
        FLabelCount++;
        NewLabel->Name = "Label" + IntToStr(FLabelCount);
        NewComponent = NewLabel;
    }
    else if(_Control->ClassNameIs("TEdit"))
    {
        TEdit *OldEdit = (TEdit*)_Control;
        TEdit* NewEdit = new TEdit(_Parent);
        NewEdit->Text = OldEdit->Text;
        NewEdit->ReadOnly = true;
        NewEdit->Width = OldEdit->Width;
        NewEdit->Height = OldEdit->Height;
        NewEdit->Top = OldEdit->Top;
        NewEdit->Left = OldEdit->Left;
        FEditCount++;
        NewEdit->Name = "Edit" + IntToStr(FEditCount);
        NewComponent = NewEdit;
    }
    else if(_Control->ClassNameIs("TButton"))
    {
        TButton* OldButton = (TButton*)_Control;
        TButton* NewButton = new TButton(_Parent);
        NewButton->Caption = OldButton->Caption;
        NewButton->Width = OldButton->Width;
        NewButton->Height = OldButton->Height;
        NewButton->Top = OldButton->Top;
        NewButton->Left = OldButton->Left;
        FButtonCount++;
        NewButton->Name = "Button" + IntToStr(FButtonCount);
        NewComponent = NewButton;
    }
    NewComponent->Parent = _Parent;
    NewComponent->Visible = true;
    NewComponent->Cursor = crArrow;
    Objects.Add(NewComponent);
    return true;
}
//---------------------------------------------------------------------------
void APObjectData::SaveToHTML(AnsiString _FileName)
{
    FILE *stream = fopen(_FileName.c_str(), "w");
    if(!stream)
    {
        Application->MessageBox("�� ���� ������� ���� �� ������.", "������", MB_OK | MB_ICONSTOP);
        return;
    }
    fprintf(stream,"<html><body>\n");
    if(Objects.Size < 1)
    {
        fprintf(stream,"\n</body></html>");
        fclose(stream);
        return;
    }
    switch(Method)
    {
        case 1: {
                    Method1(stream);
                    break;
                }
        case 2: {
                    Method2(stream);
                    break;
                }
    }
    fprintf(stream,"\n</body></html>");
    fclose(stream);
}
//---------------------------------------------------------------------------
void APObjectData::SortObjectsByBlock(void)
{
    if(FBlocks)
        delete FBlocks;
    FBlocks = new APBlock;
//�������� ���� �������� � ����
    for(int i=0;i<Objects.Size;i++)
        FBlocks->AddObject(Objects.Data[i]);
    FBlocks->SortObjects(srtVertical);
    FBlocks->FillBlocks(0);
}
//---------------------------------------------------------------------------
void APObjectData::DrawBlock(FILE* stream, APBlock* Block, int _Top, int _Left)
{
    if(Block->Blocks && Block->Blocks->Size==1)
    {
        if(!Block->Blocks->Data[0]->Blocks)
        {
            DrawBlock(stream, Block->Blocks->Data[0], _Top, _Left);
            return;
        }
    }
    switch(Block->SortType)
    {
        case srtVertical:   {
                                fprintf(stream,"\n<table cellspacing=\"0\" cellpadding=\"0\" width=\"%d\">",
                                               Block->Right - _Left);
                                if(!Block->Blocks)
                                {
                                    for(int i=0;i<Block->Objects->Size;)
                                    {
                                        int cellHeight = Block->Objects->Data[i]->Top - _Top;
                                        //������ ������
                                        if(cellHeight > 2)
                                            fprintf(stream,"\n<tr><td height=\"%d\"></td></tr>", cellHeight);
                                        _Top = Block->Objects->Data[i]->Top;
                                        fprintf(stream,"\n<tr valign=\"top\" halign=\"left\">\n<td>");
                                        int cellWidth = Block->Objects->Data[i]->Left - _Left;
                                        if(cellWidth > 2)
                                            fprintf(stream,"<table cellspacing=\"0\" cellpadding=\"0\"><tr><td width = \"%d\"></td><td>",cellWidth);
                                        DrawObject(stream, Block->Objects->Data[i]);
                                        if(cellWidth > 2)
                                            fprintf(stream,"</td></tr></table>");
                                        fprintf(stream,"\n</td>\n</tr>");
                                        _Top += Block->Objects->Data[i]->Height;
                                        if(Block->Objects->Size > 1)
                                        {
                                            Block->Objects->Delete(i);
                                            Block->SortObjects(Block->SortType);
                                            Block->FillBlocks(0);
                                            fprintf(stream,"\n<tr><td>");
                                            DrawBlock(stream, Block, _Top, _Left);
                                            fprintf(stream,"\n</td></tr>");
                                        }
                                        else
                                            break;
                                    }
                                }
                                else
                                {
                                    for(int i=0;i<Block->Blocks->Size;i++)
                                    {
                                        int cellHeight = Block->Blocks->Data[i]->Top - _Top;
                                        //������ ������
                                        if(cellHeight > 2)
                                            fprintf(stream,"\n<tr><td height=\"%d\"></td></tr>", cellHeight);
                                        _Top = Block->Blocks->Data[i]->Top;
                                        fprintf(stream,"\n<tr valign=\"top\">\n<td>");
                                        DrawBlock(stream, Block->Blocks->Data[i], _Top, _Left);
                                        fprintf(stream,"\n</td>\n</tr>");
                                        _Top = Block->Blocks->Data[i]->Bottom;
                                    }
                                }
                                fprintf(stream,"\n</table>");
                                break;
                            }
        case srtHorizontal: {
                                fprintf(stream,"\n<table cellspacing=\"0\" cellpadding=\"0\" width=\"%d\">\n<tr valign=\"top\" halign=\"left\">",
                                        Block->Right - _Left);
                                if(!Block->Blocks)
                                {
                                    for(int i=0;i<Block->Objects->Size;)
                                    {
                                        int cellWidth = Block->Objects->Data[i]->Left - _Left;
                                        //������ ������
                                        if(cellWidth > 2)
                                            fprintf(stream,"\n<td width=\"%d\"></td>", cellWidth);
                                        _Left = Block->Objects->Data[i]->Left;
                                        fprintf(stream,"\n<td>");
                                        int cellHeight = Block->Objects->Data[i]->Top - _Top;
                                        if(cellHeight > 2)
                                            fprintf(stream,"<table cellspacing=\"0\" cellpadding=\"0\"><tr height = \"%d\"><td></td><tr><td>",cellHeight);
                                        DrawObject(stream, Block->Objects->Data[i]);
                                        if(cellWidth > 2)
                                            fprintf(stream,"</td></tr></table>");
                                        fprintf(stream,"\n</td>");
                                        _Left += Block->Objects->Data[i]->Width;
                                        if(Block->Objects->Size > 1)
                                        {
                                            Block->Objects->Delete(i);
                                            Block->SortObjects(Block->SortType);
                                            Block->FillBlocks(0);
                                            fprintf(stream,"\n<td>");
                                            DrawBlock(stream, Block, _Top, _Left);
                                            fprintf(stream,"\n</td>");
                                        }
                                        else
                                            break;
                                    }
                                }
                                else
                                {
                                    for(int i=0;i<Block->Blocks->Size;i++)
                                    {
                                        int cellWidth = Block->Blocks->Data[i]->Left - _Left;
                                        //������ ������
                                        if(cellWidth > 2)
                                            fprintf(stream,"\n<td width=\"%d\"></td>", cellWidth);
                                        _Left = Block->Blocks->Data[i]->Left;
                                        fprintf(stream,"\n<td>");
                                        DrawBlock(stream, Block->Blocks->Data[i], _Top, _Left);
                                        fprintf(stream,"\n</td>");
                                        _Left = Block->Blocks->Data[i]->Right;
                                    }
                                }
                                fprintf(stream,"\n</tr>\n</table>");
                                break;
                            }
    }
}
//---------------------------------------------------------------------------
void APObjectData::DrawObject(FILE* stream, TControl* _Control)
{
    if(_Control->ClassNameIs("TLabel"))
        fprintf(stream,"\n<div>%s</div>",((TLabel*)_Control)->Caption.c_str());
    else if(_Control->ClassNameIs("TEdit"))
        fprintf(stream,
            "\n<input type=\"text\" name=\"%s\" value=\"%s\" alt=\"TextField\" style=\"width: %d; height: %d\">",
            _Control->Name.c_str(),
            ((TEdit*)_Control)->Text.c_str(),
            _Control->Width,
            _Control->Height);
    else if(_Control->ClassNameIs("TButton"))
    {
        fprintf(stream,
            "\n<input type=\"button\" name=\"%s\" value=\"%s\" alt=\"Button\" style=\"width: %d; height: %d\">",
            _Control->Name.c_str(),
            ((TEdit*)_Control)->Text.c_str(),
            _Control->Width,
            _Control->Height);
    }
}
//---------------------------------------------------------------------------
bool APObjectData::TestName(TControl* _Control, AnsiString _ControlName)
{
    for(int i=0;i<Objects.Size;i++)
    {
        if(Objects.Data[i] == _Control)
            continue;
        if(Objects.Data[i]->Name == _ControlName)
            return false;
    }
    return true;
}
//---------------------------------------------------------------------------
void APObjectData::Method1(FILE* stream)
{
//���������� ����������� ����� �� ���� X � Y
    IVector XPoints(0), YPoints(0);
    XPoints.Add(0);
    YPoints.Add(0);
    for(int i=0;i<Objects.Size;i++)
    {
        int Left = Objects.Data[i]->Left;
        int Right = Objects.Data[i]->Left + Objects.Data[i]->Width;
        int Top = Objects.Data[i]->Top;
        int Bottom = Objects.Data[i]->Top + Objects.Data[i]->Height;
        if(!XPoints.FindFirst(Left))
            XPoints.Add(Left);
        if(!XPoints.FindFirst(Right))
            XPoints.Add(Right);
        if(!YPoints.FindFirst(Top))
            YPoints.Add(Top);
        if(!YPoints.FindFirst(Bottom))
            YPoints.Add(Bottom);
    }
//���������� ����������� �����
    XPoints.SortDirect();
    YPoints.SortDirect();
//�������� ������� ������������ �����
    IMatrix Cells(XPoints.Size-1, YPoints.Size-1);
    Cells.Clear(0);
//����������� ��������� ������� � ������� �����
    for(int i=0;i<Objects.Size;i++)
    {
        int Left = Objects.Data[i]->Left;
        int Right = Objects.Data[i]->Left + Objects.Data[i]->Width;
        int Top = Objects.Data[i]->Top;
        int Bottom = Objects.Data[i]->Top + Objects.Data[i]->Height;
        int X1 = 0, X2 = 0, Y1 = 0, Y2 = 0;
        XPoints.FindFirst(Left);
        X1 = XPoints.FindIndex;
        YPoints.FindFirst(Top);
        Y1 = YPoints.FindIndex;
        XPoints.FindFirst(Right);
        X2 = XPoints.FindIndex;
        YPoints.FindFirst(Bottom);
        Y2 = YPoints.FindIndex;
        for(int j=Y1;j<Y2;j++)
            for(int k=X1;k<X2;k++)
                Cells.Data[j][k] = i + 1;
    }
//�������� ����� ����� � ��������
    for(int i=1;i<XPoints.Size;i++)
        if(XPoints.Data[i] - XPoints.Data[i-1] <= 1)
        {
            XPoints.Delete(i-1);
            Cells.DeleteCol(i-1);
            i--;
        }
    for(int i=1;i<YPoints.Size;i++)
        if(YPoints.Data[i] - YPoints.Data[i-1] <= 1)
        {
            YPoints.Delete(i-1);
            Cells.DeleteRow(i-1);
            i--;
        }
//������������ ������� ��� ����� � �����. ��������
    ADPointerArray <APColsInfo*, APColsInfo> Rows(YPoints.Size - 1);
    for(int i=0;i<Cells.RowCount;i++)
    {
        int OldVal = 0;
        for(int j=0;j<Cells.ColCount;)
        {
            OldVal = Cells.Data[i][j];
            int ColCount = 0, RowCount = 1;
            int Beg = j;
            while(j<Cells.ColCount && OldVal == Cells.Data[i][j])
            {
                Cells.Data[i][j] = -1;
                ColCount++;
                j++;
            }
            if(OldVal != -1 && OldVal != 0)
            {
                int k = i+1;
                while(k<Cells.RowCount && OldVal == Cells.Data[k][Beg])
                {
                    RowCount++;
                    k++;
                }
                for(int ii=i;ii<k;ii++)
                    for(int jj=Beg;jj<j;jj++)
                        Cells.Data[ii][jj] = -1;
            }
            if(OldVal != -1)
            {
                Rows.Data[i]->ColCount.Add(ColCount);
                Rows.Data[i]->RowCount.Add(RowCount);
                Rows.Data[i]->ObjectIndex.Add(OldVal);
            }
        }
    }
//������ ����� � ����� �����
    for(int i=XPoints.Size-1;i>0;i--)
        XPoints.Data[i] = XPoints.Data[i] - XPoints.Data[i-1] - 1;
    for(int i=YPoints.Size-1;i>0;i--)
        YPoints.Data[i] = YPoints.Data[i] - YPoints.Data[i-1] - 1;
    YPoints.Data[1] = YPoints.Data[1] - 15;
//������ HTML
    int MaxX = GetMaxX();
    fprintf(stream,"\n<table cellspacing=\"0\" cellpadding=\"0\" width=\"%d\">", MaxX);
    for(int i=0;i<Rows.Size;i++)
    {
        fprintf(stream,"\n<tr valign=\"top\" halign=\"left\">");
        for(int j=0;j<Rows.Data[i]->ObjectIndex.Size;j++)
        {
            if(j==0)
            {
                if(Rows.Data[i]->RowCount.Data[j] == 1)
                    fprintf(stream,"\n\t<td height=\"%d\" colspan=\"%d\">",YPoints.Data[i+1],
                        Rows.Data[i]->ColCount.Data[j]);
                else
                    fprintf(stream,"\n\t<td height=\"%d\" colspan=\"%d\" rowspan=\"%d\">",YPoints.Data[i+1],
                        Rows.Data[i]->ColCount.Data[j], Rows.Data[i]->RowCount.Data[j]);
            }
            else
            {
                if(Rows.Data[i]->RowCount.Data[j] == 1)
                    fprintf(stream,"\n\t<td colspan=\"%d\">",Rows.Data[i]->ColCount.Data[j]);
                else
                    fprintf(stream,"\n\t<td colspan=\"%d\" rowspan=\"%d\">",Rows.Data[i]->ColCount.Data[j],
                        Rows.Data[i]->RowCount.Data[j]);
            }
            if(Rows.Data[i]->ObjectIndex.Data[j]!= 0)
                DrawObject(stream, Objects.Data[Rows.Data[i]->ObjectIndex.Data[j] - 1]);
            fprintf(stream,"</td>");
        }
        fprintf(stream,"\n</tr>");
    }
//����� ��������� ������
    fprintf(stream,"\n<tr>\n\t<td height=\"%d\" width=\"%d\"></td>", 2, XPoints.Data[1]);
    for(int i=2;i<XPoints.Size;i++)
        fprintf(stream,"\n\t<td width=\"%d\"></td>", XPoints.Data[i]);
    fprintf(stream,"\n</tr>");
    fprintf(stream,"\n</table>");
}
//---------------------------------------------------------------------------
void APObjectData::Method2(FILE* stream)
{
    SortObjectsByBlock();
    int Top = 15;
    int Left = 0;
    DrawBlock(stream, FBlocks, Top, Left);
}
//---------------------------------------------------------------------------
int APObjectData::GetMaxX(void)
{
    int MaxX = 0;
    for(int i=0;i<Objects.Size;i++)
        if(Objects.Data[i]->Left + Objects.Data[i]->Width > MaxX)
            MaxX = Objects.Data[i]->Left + Objects.Data[i]->Width;
    return MaxX;
}
//---------------------------------------------------------------------------
int APObjectData::GetMaxY(void)
{
    int MaxY = 0;
    for(int i=0;i<Objects.Size;i++)
        if(Objects.Data[i]->Top + Objects.Data[i]->Height > MaxY)
            MaxY = Objects.Data[i]->Top + Objects.Data[i]->Height;
    return MaxY;
}
//---------------------------------------------------------------------------
#pragma package(smart_init)
