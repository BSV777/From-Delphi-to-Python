//---------------------------------------------------------------------------

#ifndef mainH
#define mainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <ToolWin.hpp>
#include <Menus.hpp>

#include "Mathem.h"
#include <ActnList.hpp>
#include <ImgList.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TfrmMain : public TForm
{
__published:	// IDE-managed Components
    TStatusBar *StatusBar;
    TMainMenu *MainMenu;
    TMenuItem *File;
    TMenuItem *FileNew;
    TMenuItem *FileOpen;
    TMenuItem *FileSave;
    TMenuItem *FileSaveAs;
    TMenuItem *N5;
    TMenuItem *FileExit;
    TMenuItem *Help;
    TMenuItem *HelpAbout;
    TControlBar *ControlBar;
    TToolBar *tlbFile;
    TToolButton *tlbtnNew;
    TToolButton *tlbtnOpen;
    TToolButton *tlbtnSave;
    TPageControl *pgeComponents;
    TTabSheet *tbsStandart;
    TSpeedButton *spdbtnArrow;
    TSpeedButton *spdbtnLabel;
    TSpeedButton *spdbtnEdit;
    TSpeedButton *spdbtnButton;
    TActionList *ActionList;
    TAction *ResizeMoveObject;
    TAction *SelectObject;
    TAction *ClearSelected;
    TImageList *EnableImageList;
    TMenuItem *View;
    TMenuItem *ViewInspector;
    TMenuItem *Edit;
    TMenuItem *EditDelete;
    TMenuItem *EditCut;
    TMenuItem *EditCopy;
    TMenuItem *EditPaste;
    TAction *DeleteObject;
    TAction *CopyObject;
    TSaveDialog *SaveDialog;
    TAction *SaveFile;
    TOpenDialog *OpenDialog;
    TAction *LoadFile;
    TAction *NewFile;
    TToolBar *tlbEdit;
    TToolButton *tlbbtnCut;
    TToolButton *tlbbtnCopy;
    TToolButton *tlbbtnPaste;
    TMenuItem *N1;
    TMenuItem *FileSaveToHTML;
    TSaveDialog *SaveHTML;
    TMenuItem *Options;
    TPanel *pnlMain;
    TPanel *pnlWorkspace;
    TShape *shpMain;
    TScrollBar *scbVert;
    TScrollBar *scbHoriz;
    void __fastcall pnlWorkspaceMouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall ResizeMoveObjectExecute(TObject *Sender);
    void __fastcall SelectObjectExecute(TObject *Sender);
    void __fastcall ClearSelectedExecute(TObject *Sender);
    void __fastcall ViewInspectorClick(TObject *Sender);
    void __fastcall EditCutClick(TObject *Sender);
    void __fastcall EditDeleteClick(TObject *Sender);
    void __fastcall DeleteObjectExecute(TObject *Sender);
    void __fastcall EditPasteClick(TObject *Sender);
    void __fastcall CopyObjectExecute(TObject *Sender);
    void __fastcall EditCopyClick(TObject *Sender);
    void __fastcall SaveFileExecute(TObject *Sender);
    void __fastcall FileExitClick(TObject *Sender);
    void __fastcall NewFileExecute(TObject *Sender);
    void __fastcall FileSaveAsClick(TObject *Sender);
    void __fastcall LoadFileExecute(TObject *Sender);
    void __fastcall FileSaveToHTMLClick(TObject *Sender);
    void __fastcall HelpAboutClick(TObject *Sender);
    void __fastcall OptionsClick(TObject *Sender);
    void __fastcall FormResize(TObject *Sender);
    void __fastcall scbHorizChange(TObject *Sender);
    void __fastcall scbVertChange(TObject *Sender);
private:	// User declarations
    TControl *CopyControl;
    bool BegDrag;
public:		// User declarations
    __fastcall TfrmMain(TComponent* Owner);
    void __fastcall OnHint(TObject *Sender);
    void Selected(TControl* _SelControl);
    void DrawSelected(TControl* _SelControl);
    void HideSelectedShape(void);
    void __fastcall ObjectClick(TObject *Sender);
    void __fastcall SelShapeMouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall SelShapeMouseUp(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall SelShapeMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y);
    void __fastcall ObjectMouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall ObjectMouseUp(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall ObjectMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y);
    void SaveToFile(AnsiString FileName);
    void CheckScrollBars(void);

    TShape *SelShape[8];
    TControl *SelectedControl;
    APObjectData Objects;
    int X0, Y0;
    bool Resize, Move;
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmMain *frmMain;
//---------------------------------------------------------------------------
#endif
