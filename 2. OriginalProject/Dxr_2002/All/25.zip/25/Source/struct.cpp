// struct.cpp: implementation of the SMainFormOptions class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "XMLEd.h"
#include "struct.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

static const char* strFileName = "XMLEd.ini";
static const char* strNull = "<<GROUP>>";

//////////////////////////////////////////////////////////////////////
// SMainOptions

void SMainOptions::SaveToINI()
{
	CString str;

	str.Format("%d", bShowGrid);
	WritePrivateProfileString("Ruler'n'Grid", "Show_grid", str, strFileName);

	str.Format("%d", bShowNumbers);
	WritePrivateProfileString("Ruler'n'Grid", "Show_scale", str, strFileName);

	str.Format("%d", bShowMousePos);
	WritePrivateProfileString("Ruler'n'Grid", "Show_mouse_position", str, strFileName);

	str.Format("%d", iSnapType);
	WritePrivateProfileString("Snap'n'Glue", "Snap_type", str, strFileName);

	str.Format("%d", iIntersection);
	WritePrivateProfileString("Snap'n'Glue", "Intersection", str, strFileName);

	str.Format("%d", bStyleIDE);
	WritePrivateProfileString("Environment", "IDE_drawing", str, strFileName);

	str.Format("%d", iLeftSize);
	WritePrivateProfileString("Environment", "Inspector", str, strFileName);

	str.Format("%d", iRectSize);
	WritePrivateProfileString("Environment", "Resize_rect_size", str, strFileName);

	str.Format("%d", bDeleteOnIns);
	WritePrivateProfileString("Environment", "Delete_on_insert", str, strFileName);

	str.Format("%d", bShowFProp);
	WritePrivateProfileString("Environment", "Fill_prop_on_load", str, strFileName);

	str.Format("%d", bHTMLGrid);
	WritePrivateProfileString("Environment", "HTML_grid", str, strFileName);
}

void SMainOptions::LoadFromINI()
{
	char buff[25];

	GetPrivateProfileString("Ruler'n'Grid", "Show_grid", "1", buff, 25, strFileName);
	if (buff[0] == '0') bShowGrid = false;
	else bShowGrid = true;

	GetPrivateProfileString("Ruler'n'Grid", "Show_scale", "1", buff, 25, strFileName);
	if (buff[0] == '0') bShowNumbers = false;
	else bShowNumbers = true;

	GetPrivateProfileString("Ruler'n'Grid", "Show_mouse_position", "1", buff, 25, strFileName);
	if (buff[0] == '0') bShowMousePos = false;
	else bShowMousePos = true;

	GetPrivateProfileString("Snap'n'Glue", "Snap_type", "1", buff, 25, strFileName);
	iSnapType = atoi(buff);

	GetPrivateProfileString("Snap'n'Glue", "Intersection", "1", buff, 25, strFileName);
	iIntersection = atoi(buff);

	GetPrivateProfileString("Environment", "IDE_drawing", "1", buff, 25, strFileName);
	if (buff[0] == '0') bStyleIDE = false;
	else bStyleIDE = true;

	GetPrivateProfileString("Environment", "Inspector", "1", buff, 25, strFileName);
	iLeftSize = atoi(buff);

	GetPrivateProfileString("Environment", "Resize_rect_size", "5", buff, 25, strFileName);
	iRectSize = atoi(buff);

	GetPrivateProfileString("Environment", "Delete_on_insert", "0", buff, 25, strFileName);
	if (buff[0] == '0') bDeleteOnIns = false;
	else bDeleteOnIns = true;

	GetPrivateProfileString("Environment", "Fill_prop_on_load", "1", buff, 25, strFileName);
	if (buff[0] == '0') bShowFProp = false;
	else bShowFProp = true;

	GetPrivateProfileString("Environment", "HTML_grid", "1", buff, 25, strFileName);
	if (buff[0] == '0') bHTMLGrid = false;
	else bHTMLGrid = true;
}

//////////////////////////////////////////////////////////////////////
// SShape

void SShape::Reset()
{
	rectPos.SetRectEmpty();
	strName		= "";
	bBorder		= true;
	bLocked		= false;
	iAlig		= DT_CENTER | DT_VCENTER;
	iID			= -1;
	eType		= tShape;
	eState		= stNormal;
	eSnap		= snNone;
	bNameNull	= false;
}

SShape& SShape::operator =(SPropData &d)
{
	CString strCmp(strNull);
	if (!d.m_bNameNull) strName = d.m_strName;

	if (d.m_iSnap != snNull)
		switch (d.m_iSnap)
		{
		case 1: eSnap = snTopLeft; break;
		case 2: eSnap = snCenter; break;
		default: eSnap = snNone;
		}

	CRect rectNew;
	rectNew.left = d.m_iLeft;
	rectNew.top = d.m_iTop;
	rectNew.right = rectNew.left + d.m_iWidth - 1;
	rectNew.bottom = rectNew.top + d.m_iHeight - 1;
	if (rectNew != CRect(0, 0, 19, 19))
		rectPos = rectNew;

	if (d.GetBorderInt() != 3)
		bBorder = d.GetBorder();
	if (d.GetLockedInt() != 3)
		bLocked = d.GetLocked();

	iAlig = 0;
	switch (d.m_iHAlig)
	{
	case 1: iAlig |= DT_CENTER; break;
	case 2: iAlig |= DT_RIGHT; break;
	default: iAlig |= DT_LEFT;
	}

	switch (d.m_iVAlig)
	{
	case 1: iAlig |= DT_VCENTER; break;
	case 2: iAlig |= DT_BOTTOM; break;
	default: iAlig |= DT_TOP;
	}

	return *this;
}

void SShape::operator+=(SShape& d)
{
	if (!rectPos.IsRectNull())
		if (rectPos != d.GetRect())
			rectPos.SetRectEmpty();

	if (strName	!= strNull)
		if (strName != d.strName)
		{
			strName = strNull;
			bNameNull = true;
		}

	if (bBorder	!= 3)
		if (bBorder != d.bBorder)
			bBorder = 3;

	if (bLocked	!= 3)
		if (bLocked != d.bLocked)
			bLocked = 3;

	if (iAlig != -1)
		if (iAlig != d.iAlig)
			iAlig = -1;

	if (iID != -1)
		if (iID != d.iID)
			iID = -1;

	if (eType != tShape)
		if (eType != d.eType)
			eType = tShape;

	if (eSnap != snNull)
		if (eSnap != d.eSnap)
			eSnap = snNull;
}

//////////////////////////////////////////////////////////////////////
// SPropData

SPropData::SPropData()
{
	m_strName	= _T("Shape");
	m_strType	= _T("Rectangle");
	m_iID		= -1;
	m_iSnap		= 0;
	m_iHeight	= 0;
	m_iWidth	= 0;
	m_iLeft		= 0;
	m_iTop		= 0;
	m_iVAlig	= 1;
	m_iHAlig	= 1;
	m_bBorder	= true;
	m_bLocked	= false;
}

SPropData& SPropData::operator=(SShape& d)
{
	m_strName = d.strName;

	switch (d.eType)
	{
	case SShape::tLabel: m_strType = _T("Label"); break;
	case SShape::tEdit: m_strType = _T("Edit"); break;
	case SShape::tButton: m_strType = _T("Button"); break;
	case SShape::tTable: m_strType = _T("Table"); break;
	default: m_strType = _T("Unknown type");
	}
	
	m_iID = d.iID;

	switch (d.eSnap)
	{
//	case SShape::snNone: m_iSnap = 0; break;
	case SShape::snTopLeft: m_iSnap = 1; break;
	case SShape::snCenter: m_iSnap = 2; break;
	default: m_iSnap = 0;
	}

	CRect rectShape = d.GetRect();
	m_iHeight	= rectShape.Height() + 1;
	m_iWidth	= rectShape.Width() + 1;
	m_iLeft		= rectShape.left;
	m_iTop		= rectShape.top;

	if (d.iAlig & DT_VCENTER) m_iVAlig = 1;
	else if (d.iAlig & DT_BOTTOM) m_iVAlig = 2;
		else m_iVAlig = 0;

	if (d.iAlig & DT_CENTER) m_iHAlig = 1;
	else if (d.iAlig & DT_RIGHT) m_iHAlig = 2;
		else m_iHAlig = 0;

	m_bBorder	= d.GetBorderInt();
	m_bLocked	= d.GetLockedInt();
	m_bNameNull = d.bNameNull;

	return *this;
}

//////////////////////////////////////////////////////////////////////
// SDataManager

// CPMListSnap
BEGIN_LIST_ITEM_DATA_TYPE(CPMListSnap)
	LPCTSTR_STRING_ITEM_DATA(_T("[0] No Snap")),
	LPCTSTR_STRING_ITEM_DATA(_T("[1] Corners")),
	LPCTSTR_STRING_ITEM_DATA(_T("[2] Center"))
END_LIST_ITEM_DATA_TYPE(CPMListSnap)

//CPMListVAlig
BEGIN_LIST_ITEM_DATA_TYPE(CPMListVAlig)
	LPCTSTR_STRING_ITEM_DATA(_T("[0] Top")),
	LPCTSTR_STRING_ITEM_DATA(_T("[1] Center")),
	LPCTSTR_STRING_ITEM_DATA(_T("[2] Bottom"))
END_LIST_ITEM_DATA_TYPE(CPMListVAlig)

//CPMListHAlig
BEGIN_LIST_ITEM_DATA_TYPE(CPMListHAlig)
	LPCTSTR_STRING_ITEM_DATA(_T("[0] Left")),
	LPCTSTR_STRING_ITEM_DATA(_T("[1] Center")),
	LPCTSTR_STRING_ITEM_DATA(_T("[2] Right"))
END_LIST_ITEM_DATA_TYPE(CPMListHAlig)

SDataManager::SDataManager()
{
	BEGIN_PROPERTY_TAB(_T("Appearance"), true)
		PROPERTY_ITEM(ID_PM_BORD,	CPropertyItemBool,
			_T("Border"),		true)
		PROPERTY_ITEM(ID_PM_ID,		CPropertyItemInt,
			_T("ID"),			false)
		PROPERTY_ITEM(ID_PM_LOCK,	CPropertyItemBool,
			_T("Locked"),		true)
		PROPERTY_ITEM(ID_PM_NAME,	CPropertyItemString,
			_T("Name"),			true)
		PROPERTY_ITEM(ID_PM_SNAP,	CPMListSnap,
			_T("Snap type"),	true)
		PROPERTY_ITEM(ID_PM_TYPE,	CPropertyItemString,
			_T("Shape type"),	false)
	END_PROPERTY_TAB()

	BEGIN_PROPERTY_TAB(_T("Size and positon"), true)
		PROPERTY_ITEM(ID_PM_HALIG,	CPMListHAlig,
			_T("Horz.alignment"),true)
		PROPERTY_ITEM(ID_PM_VALIG,	CPMListVAlig,
			_T("Vert.alignment"),true)
		PROPERTY_ITEM(ID_PM_COL,	CPropertyItemInt,
			_T("Left"),			true)
		PROPERTY_ITEM(ID_PM_ROW,	CPropertyItemInt,
			_T("Top"),			true)
		PROPERTY_ITEM(ID_PM_LEN,	CPropertyItemInt,
			_T("Width"),		true)
		PROPERTY_ITEM(ID_PM_HGT,	CPropertyItemInt,
			_T("Height"),		true)
	END_PROPERTY_TAB()
}

SDataManager::~SDataManager()
{
}

bool SDataManager::GetData(CObject *pData) const
{
	SPropData* pMyData = static_cast<SPropData*>(pData);

	BEGIN_ITERATE_PROPERTY_ITEMS()
		GET_ITEM_BOOL(ID_PM_BORD,	pMyData->m_bBorder)
		GET_ITEM_INT(ID_PM_ID,		pMyData->m_iID)
		GET_ITEM_BOOL(ID_PM_LOCK,	pMyData->m_bLocked)
		GET_ITEM_STRING(ID_PM_NAME,	pMyData->m_strName)
		GET_ITEM_LIST(ID_PM_SNAP,	pMyData->m_iSnap)
		GET_ITEM_STRING(ID_PM_TYPE,	pMyData->m_strType)
		GET_ITEM_INT(ID_PM_COL,		pMyData->m_iLeft)
		GET_ITEM_INT(ID_PM_ROW,		pMyData->m_iTop)
		GET_ITEM_INT(ID_PM_LEN,		pMyData->m_iWidth)
		GET_ITEM_INT(ID_PM_HGT,		pMyData->m_iHeight)
		GET_ITEM_LIST(ID_PM_HALIG,	pMyData->m_iHAlig)
		GET_ITEM_LIST(ID_PM_VALIG,	pMyData->m_iVAlig)
	END_ITERATE_PROPERTY_ITEMS()

	return true;
}

bool SDataManager::SetData(const CObject *pData)
{
	const SPropData* pMyData = static_cast<const SPropData*>(pData);

	BEGIN_ITERATE_PROPERTY_ITEMS()
		SET_ITEM_BOOL(ID_PM_BORD,	pMyData->m_bBorder)
		SET_ITEM_INT(ID_PM_ID,		pMyData->m_iID)
		SET_ITEM_BOOL(ID_PM_LOCK,	pMyData->m_bLocked)
		SET_ITEM_STRING(ID_PM_NAME,	pMyData->m_strName)
		SET_ITEM_LIST(ID_PM_SNAP,	pMyData->m_iSnap)
		SET_ITEM_STRING(ID_PM_TYPE,	pMyData->m_strType)
		SET_ITEM_INT(ID_PM_COL,		pMyData->m_iLeft)
		SET_ITEM_INT(ID_PM_ROW,		pMyData->m_iTop)
		SET_ITEM_INT(ID_PM_LEN,		pMyData->m_iWidth)
		SET_ITEM_INT(ID_PM_HGT,		pMyData->m_iHeight)
		SET_ITEM_LIST(ID_PM_HALIG,	pMyData->m_iHAlig)
		SET_ITEM_LIST(ID_PM_VALIG,	pMyData->m_iVAlig)
	END_ITERATE_PROPERTY_ITEMS()

	return true;
}
