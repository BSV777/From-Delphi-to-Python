// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "XMLEd.h"

#include "MainFrm.h"
#include "MainOptDlg.h"
#include "ChildFrm.h"
#include "LeftView.h"
#include "XMLEdView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_VIEW_CONTROLSTOOLBAR, OnViewControls)
	ON_WM_INITMENUPOPUP()
	ON_COMMAND(ID_TOOLS_OPTIONS, OnToolsOptions)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
//	ID_INDICATOR_POS,
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM
};

static const int iLogoID = 100;

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar_Main.CreateEx(this, TBSTYLE_FLAT,
		WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_GRIPPER |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar_Main.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create main toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndToolBar_Ctrl.CreateEx(this, TBSTYLE_FLAT,
		WS_CHILD | WS_VISIBLE | CBRS_RIGHT | CBRS_GRIPPER |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar_Ctrl.LoadToolBar(IDR_OBJ_BAR))
	{
		TRACE0("Failed to create control toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	
//	int iID = m_wndStatusBar.CommandToIndex(ID_INDICATOR_POS);
//	m_wndStatusBar.SetPaneInfo(iID, ID_INDICATOR_POS, SBPS_NORMAL, 100);

	ResetCtrlBar();
	
	m_wndToolBar_Main.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar_Ctrl.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar_Main);
	DockControlBar(&m_wndToolBar_Ctrl);

/*	CControlBar* pTopDockBar = GetControlBar(AFX_IDW_DOCKBAR_TOP);
	if (!pTopDockBar || !m_wndLogo.Create(NULL, WS_CHILD | WS_VISIBLE |
		BS_OWNERDRAW, CRect(0,0,0,0), pTopDockBar, IDC_LOGO_TIP))
	{	
		TRACE0("Failed to create logo\n");
		return -1;      // fail to create
	} else {
		m_wndLogo.LoadBitmaps(IDB_LOGO, IDB_LOGO_SEL);
		m_wndLogo.SizeToContent(); 
	}*/

	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

void CMainFrame::OnViewControls() 
{
	CMenu* mMenu = GetMenu();

	UINT uState = mMenu->GetMenuState(ID_VIEW_CONTROLSTOOLBAR, MF_BYCOMMAND);
	ASSERT(uState != 0xFFFFFFFF);

	if (uState & MF_CHECKED)
		ShowControlBar(&m_wndToolBar_Ctrl, false, false);
	else ShowControlBar(&m_wndToolBar_Ctrl, true, false);
}

void CMainFrame::ResetCtrlBar()
{
	int iID = m_wndToolBar_Ctrl.CommandToIndex(ID_INSERT_DRAW);
	m_wndToolBar_Ctrl.SetButtonStyle(iID, TBBS_CHECKGROUP |
		TBBS_CHECKED);
	iID = m_wndToolBar_Ctrl.CommandToIndex(ID_INSERT_LABEL);
	m_wndToolBar_Ctrl.SetButtonStyle(iID, TBBS_CHECKGROUP);
	iID = m_wndToolBar_Ctrl.CommandToIndex(ID_INSERT_EDIT);
	m_wndToolBar_Ctrl.SetButtonStyle(iID, TBBS_CHECKGROUP);
	iID = m_wndToolBar_Ctrl.CommandToIndex(ID_INSERT_BUTTON);
	m_wndToolBar_Ctrl.SetButtonStyle(iID, TBBS_CHECKGROUP);
	iID = m_wndToolBar_Ctrl.CommandToIndex(ID_INSERT_TABLE);
	m_wndToolBar_Ctrl.SetButtonStyle(iID, TBBS_CHECKGROUP);
}

void CMainFrame::SetPaneText(const CString *strText)
{
	int iIndex = m_wndStatusBar.CommandToIndex(ID_SEPARATOR);
//	int iIndex = m_wndStatusBar.CommandToIndex(ID_INDICATOR_POS);
	int iRet = m_wndStatusBar.SetPaneText(iIndex, *strText, TRUE);
//	m_wndStatusBar.Invalidate();
//	m_wndStatusBar.RedrawWindow();
}

void CMainFrame::OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu) 
{
	if (m_wndToolBar_Ctrl.IsWindowVisible())
		pPopupMenu->CheckMenuItem(ID_VIEW_CONTROLSTOOLBAR, MF_CHECKED | MF_BYCOMMAND);
	else pPopupMenu->CheckMenuItem(ID_VIEW_CONTROLSTOOLBAR, MF_UNCHECKED | MF_BYCOMMAND);

	CMDIFrameWnd::OnInitMenuPopup(pPopupMenu, nIndex, bSysMenu);
}

void CMainFrame::OnToolsOptions() 
{
	CMainOptDlg dlg;
	
	CChildFrame* pFrame = (CChildFrame*)MDIGetActive();
	CLeftView* pView = (CLeftView*)pFrame->GetSpliter()->GetPane(0, 0);
	GetApp()->GetOpt()->iLeftSize = pView->GetWidth();

	dlg.SetData(GetApp()->GetOpt());

	if (dlg.DoModal() == IDOK)
	{
		dlg.GetData(GetApp()->GetOpt());
	}

	if (MDIGetActive())
	{
		pView->SetWidth(GetApp()->GetOpt()->iLeftSize, true);
		pFrame->Invalidate();
		pFrame->UpdateWindow();
	}
}

CXMLEdApp* CMainFrame::GetApp()
{
	return (CXMLEdApp*)AfxGetApp();
}

void CMainFrame::OnFileOpen() 
{
	POSITION pos = GetApp()->GetFirstDocTemplatePosition();
	CDocTemplate *pDocT = GetApp()->GetNextDocTemplate(pos);
	CDocument *pDoc = pDocT->CreateNewDocument();
	CChildFrame *pFrame = (CChildFrame*)pDocT->CreateNewFrame(pDoc, NULL);
	CSplitterWnd *pSplitter = pFrame->GetSpliter();
	CXMLEdView *pView = (CXMLEdView*)pSplitter->GetPane(0, 1);
	pView->OnFileOpen();
}
