//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by XMLEd.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_XMLEDTYPE                   129
#define IDB_BOTTOM_BAR                  130
#define IDR_OBJ_BAR                     131
#define IDD_DIALOG_SIZE                 133
#define IDB_ART                         134
#define IDD_DIALOG_OPT                  135
#define IDB_ART_DLG                     140
#define IDB_LOGO                        143
#define IDC_FORM_NAME                   1000
#define IDC_FORM_CAPT                   1001
#define IDC_SIZE_SMALL                  1002
#define IDC_SIZE_MEDIUM                 1003
#define IDC_SIZE_HUGE                   1004
#define IDC_SIZE_CUSTOM                 1005
#define IDC_SIZE_WIDTH                  1006
#define IDC_SIZE_HEIGHT                 1007
#define IDC_SHOW_GRID                   1007
#define IDC_SHOW_SCALE                  1008
#define IDC_SHOW_MOUSE                  1009
#define IDC_SNAP_TYPE                   1010
#define IDC_INTERSECTION                1011
#define IDC_STYLE_INSPECTOR             1012
#define IDC_STYLE_IDE                   1015
#define IDC_STYLE_RECT                  1016
#define IDC_STYLE_DELINS                1017
#define IDC_SPIN_RECT                   1018
#define IDC_STYLE_FILLPROP              1019
#define IDC_STYLE_HTML                  1020
#define IDC_STYLE_LEFT                  1022
#define IDC_SPIN_LEFT                   1023
#define IDS_LOCK_TIP                    10000
#define IDS_PROP_TIP                    10001
#define IDS_POS_TIP                     10002
#define IDS_SNAP_TIP                    10003
#define IDS_LOGO_TIP                    10004
#define IDS_SAVE_MASK                   10005
#define IDS_LOAD_MASK                   10006
#define ID_INSERT_DRAW                  32771
#define ID_INSERT_LABEL                 32772
#define ID_INSERT_EDIT                  32773
#define ID_INSERT_BUTTON                32774
#define ID_INSERT_TABLE                 32775
#define ID_KEY_DELETE                   32779
#define ID_FILE_OPTIONS                 57605
#define ID_INDICATOR_POS                59142
#define ID_VIEW_CONTROLSTOOLBAR         59394
#define ID_SELECT_ALL                   59395
#define ID_TOOLS_OPTIONS                61300
#define ID_FORMAT_LOCKALL               61310
#define ID_FORMAT_UNLOCKALL             61311
#define ID_FORMAT_OPTIONS               61312
#define ID_FORMAT_PROPERTIES            61312
#define ID_FORMAT_INTERS                61313

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        147
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
