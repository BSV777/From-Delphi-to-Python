// InPlaceCheckBox.cpp : implementation file
//

#include "stdafx.h"
#include "InPlaceCheckBox.h"

#include "UserMessageID.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInPlaceCheckBox

IMPLEMENT_DYNAMIC(CInPlaceCheckBoxImp, CWnd)

CInPlaceCheckBoxImp::CInPlaceCheckBoxImp()
{
	m_bValue = true;
}

CInPlaceCheckBoxImp* CInPlaceCheckBoxImp::CreateInPlaceCheckBox(bool bData, CWnd* pWndParent, CRect& rect)
{	
	CInPlaceCheckBoxImp* pInPlaceCheckBox = (CInPlaceCheckBoxImp*)new CInPlaceCheckBoxImp;
	
	pInPlaceCheckBox->Create(NULL, "", WS_VISIBLE|WS_CHILD, rect, pWndParent, 1);
	pInPlaceCheckBox->SetData(bData);

	return pInPlaceCheckBox;
}

BEGIN_MESSAGE_MAP(CInPlaceCheckBoxImp, CWnd)
	//{{AFX_MSG_MAP(CInPlaceCheckBox)
		ON_WM_PAINT()
		ON_WM_LBUTTONUP()
		ON_WM_SETFOCUS()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CInPlaceCheckBox message handlers

void CInPlaceCheckBoxImp::MoveControl(CRect& rect)
{
	CRect prevRect;
	GetClientRect(prevRect);

	CWnd* pParent = GetParent();

	ClientToScreen(prevRect);
	pParent->ScreenToClient(prevRect);
	pParent->InvalidateRect(prevRect);

	MoveWindow(rect, FALSE);

	pParent->ClientToScreen(rect);
	pParent = pParent->GetParent();	
	pParent->ScreenToClient(rect);
}

void CInPlaceCheckBoxImp::OnPaint()
{
	CPaintDC dc(this);
	
	CRect rect;
	GetClientRect(rect);
	
	CRect rectCheck;
	rectCheck.SetRect(rect.left, rect.top + 1, rect.left +
		rect.Height() - 2, rect.bottom - 1);
	rect.left += rect.Height() + 2;

#if 1
	UINT nState = DFCS_BUTTONCHECK;
#else
	UINT nState = DFCS_BUTTONCHECK | DFCS_FLAT;
#endif
	if (m_bValue) nState |= DFCS_CHECKED;
	dc.DrawFrameControl(rectCheck, DFC_BUTTON, nState);
	dc.FillSolidRect(rect, ::GetSysColor(COLOR_WINDOW));

	bool bFocus = GetFocus() == this;
	dc.SelectStockObject(DEFAULT_GUI_FONT);
	CString strText = m_bValue ? "True" : "False";

	COLORREF clrOldBk, clrOldText;
	if (bFocus)
	{
		clrOldBk = dc.SetBkColor(::GetSysColor(COLOR_HIGHLIGHT));
		clrOldText = dc.SetTextColor(::GetSysColor(COLOR_HIGHLIGHTTEXT));
	}

	dc.DrawText(strText, &rect, DT_SINGLELINE|DT_VCENTER);

	if (bFocus)
	{
		dc.SetBkColor(clrOldBk);
		dc.SetTextColor(clrOldText);
	}
}

void CInPlaceCheckBoxImp::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CWnd::OnLButtonUp(nFlags, point);

	CRect rect;
	GetClientRect(rect);

	if (rect.PtInRect(point)) Check();
}

void CInPlaceCheckBoxImp::OnSetFocus(CWnd* /*pOldWnd*/)
{
	Invalidate();
	UpdateWindow();
}

BOOL CInPlaceCheckBoxImp::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN)
	{
		switch(pMsg->wParam)
		{
		case VK_ESCAPE:	case VK_RETURN:	case VK_TAB:
			::PeekMessage(pMsg, NULL, NULL, NULL, PM_REMOVE);
			GetParent()->SetFocus();
			Invalidate();
			UpdateWindow();
		return TRUE;

		case VK_PRIOR: case VK_NEXT: case VK_UP: case VK_DOWN:
			Check();
		return TRUE;

		default: ;
		}
	}
	
	return CWnd::PreTranslateMessage(pMsg);
}

void CInPlaceCheckBoxImp::Check()
{
	m_bValue = !m_bValue;
	GetOwner()->SendMessage(WM_USER_SET_DATA);

	Invalidate();
	UpdateWindow();
}
