#if !defined(AFX_INPLACESPINEDITIMP_H__09C929A0_3E5C_11D6_AAF3_B0CC49B24F7E__INCLUDED_)
#define AFX_INPLACESPINEDITIMP_H__09C929A0_3E5C_11D6_AAF3_B0CC49B24F7E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// InPlaceSpinEditImp.h : header file
//
#include "InPlaceEditPropItemString.h"

/////////////////////////////////////////////////////////////////////////////
// CInPlaceSpinEditImp window

class CInPlaceSpinEditImp : public CWnd
{
	CInPlaceSpinEditImp(const CInPlaceSpinEditImp& d);
	CInPlaceSpinEditImp operator=(const CInPlaceSpinEditImp& d);

protected:
	DECLARE_DYNAMIC(CInPlaceSpinEditImp)

public:
	CInPlaceSpinEditImp();
	virtual ~CInPlaceSpinEditImp();

// Attributes
	int GetPos() const;
	void SetPos(const int iNewPos);
public:

// Operations
public:
	static CInPlaceSpinEditImp* CreateInPlaceSpinEdit(int iValue, CWnd* pWndParent, CRect& rect);

	void GetMinMax(int *iMin, int *iMax);
	void SetMinMax(int iMin, int iMax);

	void MoveControl(CRect& rect);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInPlaceSpinEditImp)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation

	// Generated message map functions
protected:
	//{{AFX_MSG(CInPlaceSpinEditImp)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnChangeSpin(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg LRESULT OnEdit(WPARAM wParam, LPARAM lParam);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Data
private:
	CSpinButtonCtrl				m_wndSpin;
	CInPlaceEditPropItemString	m_wndEdit;
};

inline CInPlaceSpinEditImp::~CInPlaceSpinEditImp()
{
}

inline void CInPlaceSpinEditImp::SetPos(const int iNewPos)
{
	m_wndSpin.SetPos(iNewPos);
}

inline int CInPlaceSpinEditImp::GetPos() const
{
	char cBuf[25];
	m_wndEdit.GetWindowText(cBuf, 25);
	return atoi(cBuf);
//	return m_wndSpin.GetPos();
}

inline void CInPlaceSpinEditImp::SetMinMax(int iMin, int iMax)
{
	m_wndSpin.SetRange(iMin, iMax);
}

inline void CInPlaceSpinEditImp::GetMinMax(int *iMin, int *iMax)
{
	m_wndSpin.GetRange(*iMin, *iMax);
}

////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INPLACESPINEDITIMP_H__09C929A0_3E5C_11D6_AAF3_B0CC49B24F7E__INCLUDED_)
