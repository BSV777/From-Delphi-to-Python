// PropertyItem.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////
//
// Copyright � 1999, Stefan Belopotocan, http://welcome.to/StefanBelopotocan
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PropertyItem.h"

#include "InPlaceEditPropItemString.h"
#include "InPlaceComboBoxImp.h"
#include "InPlaceCheckBox.h"
#include "InPlaceSpinEditImp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropertyItem

IMPLEMENT_DYNAMIC(CPropertyItem, CObject)

bool CPropertyItem::SetEnabled(bool bEnable)
{
	bool bChanged = m_bEnabled != bEnable;
	m_bEnabled = bEnable;

	return bChanged;
}

void CPropertyItem::CreateInPlaceControl(CWnd* /*pWndParent*/, CRect& /*rect*/, CWnd*& pWndInPlaceControl)
{
	DestroyInPlaceControl(pWndInPlaceControl);
}

void CPropertyItem::DestroyInPlaceControl(CWnd*& pWndInPlaceControl)
{
	if(pWndInPlaceControl != NULL)
	{
		delete pWndInPlaceControl;
		pWndInPlaceControl = NULL;
	}
}

/////////////////////////////////////////////////////////////////////////////
// CPropertyItemCategory

IMPLEMENT_DYNAMIC(CPropertyItemCategory, CPropertyItem)

int CPropertyItemCategory::GetNumberEnabledItems() const
{
	int nNumberEnabledItems = 0;
	POSITION pos = m_listPropertyItems.GetHeadPosition();

	while(pos != NULL)
	{
		if(m_listPropertyItems.GetNext(pos)->GetEnabled())
			nNumberEnabledItems++;
	}

	return nNumberEnabledItems;
}

CPropertyItem* CPropertyItemCategory::GetPropertyItem(int nPropertyID)
{
	POSITION pos = m_listPropertyItems.GetHeadPosition();

	while(pos != NULL)
	{
		CPropertyItem* pPropertyItem = m_listPropertyItems.GetNext(pos);

		if(pPropertyItem->GetPropertyID() == nPropertyID)
			return pPropertyItem;
	}

	return NULL;
}


/////////////////////////////////////////////////////////////////////////////
// CPropertyItemString

IMPLEMENT_DYNAMIC(CPropertyItemString, CPropertyItem)

void CPropertyItemString::CreateInPlaceControl(CWnd* pWndParent, CRect& rect, CWnd*& pWndInPlaceControl)
{
	if (GetEnabled())
	{
		if(pWndInPlaceControl != NULL && pWndInPlaceControl->IsKindOf(RUNTIME_CLASS(CInPlaceEditPropItemString)))
			((CInPlaceEditPropItemString*)pWndInPlaceControl)->MoveControl(rect);
		else	
		{
			DestroyInPlaceControl(pWndInPlaceControl);

			pWndInPlaceControl = CInPlaceEditPropItemString::CreateInPlaceEditPropItemString(m_strText, pWndParent, rect);
		}

		((CInPlaceEditPropItemString*)pWndInPlaceControl)->SetText(m_strText);
	}
}

void CPropertyItemString::SetData(CWnd* pWndInPlaceControl)
{
	pWndInPlaceControl->GetWindowText(m_strText);
}

/////////////////////////////////////////////////////////////////////////////
// CPropertyItemList

IMPLEMENT_DYNAMIC(CPropertyItemList, CPropertyItem)

void CPropertyItemList::CreateInPlaceControl(CWnd* pWndParent, CRect& rect, CWnd*& pWndInPlaceControl)
{
	if (GetEnabled())
	{
		if(pWndInPlaceControl != NULL && pWndInPlaceControl->IsKindOf(RUNTIME_CLASS(CInPlaceComboBoxImp)))
		{
			((CInPlaceComboBoxImp*)pWndInPlaceControl)->MoveControl(rect);
			((CInPlaceComboBoxImp*)pWndInPlaceControl)->ResetContent();
		}
		else
		{
			DestroyInPlaceControl(pWndInPlaceControl);
		
			pWndInPlaceControl = (CWnd*)CInPlaceComboBoxImp::CreateInPlaceComboBox(pWndParent, rect);
		}

		SetItemListData((CInPlaceComboBoxImp*)pWndInPlaceControl);
		((CInPlaceComboBoxImp*)pWndInPlaceControl)->SetCurSel(m_nItem, false);
		((CInPlaceComboBoxImp*)pWndInPlaceControl)->ResetListBoxHeight();
	}
}

void CPropertyItemList::SetData(CWnd* pWndInPlaceControl)
{
	m_nItem = ((CInPlaceComboBoxImp*)pWndInPlaceControl)->GetCurrentSelection();
}

void CPropertyItemList::SetItemListData(CInPlaceComboBoxImp* pWndInPlaceControl)
{
	LPCTSTR pStrText;

	for(int i = 0; (pStrText = GetItemData(i)) != NULL; i++)
		pWndInPlaceControl->AddString(pStrText);
}

/////////////////////////////////////////////////////////////////////////////
// CPropertyItemBool

IMPLEMENT_DYNAMIC(CPropertyItemBool, CPropertyItem)

void CPropertyItemBool::CreateInPlaceControl(CWnd* pWndParent, CRect& rect, CWnd*& pWndInPlaceControl)
{
	if (GetEnabled())
	{
		if(pWndInPlaceControl != NULL && pWndInPlaceControl->IsKindOf(RUNTIME_CLASS(CInPlaceCheckBoxImp)))
			((CInPlaceCheckBoxImp*)pWndInPlaceControl)->MoveControl(rect);
		else	
		{
			DestroyInPlaceControl(pWndInPlaceControl);

			pWndInPlaceControl = CInPlaceCheckBoxImp::CreateInPlaceCheckBox(m_bValue, pWndParent, rect);
		}

		((CInPlaceCheckBoxImp*)pWndInPlaceControl)->SetData(m_bValue);
	}
}

void CPropertyItemBool::SetData(CWnd* pWndInPlaceControl)
{
	m_bValue = ((CInPlaceCheckBoxImp*)pWndInPlaceControl)->GetData();
}

void CPropertyItemBool::DrawValue(CDC* pDC, CRect& rect)
{
	rect.left -= 2;
	pDC->FillSolidRect(rect, RGB(208, 224, 239));
	rect.left += 2;
	
	CRect rectCheck;
	rectCheck.SetRect(rect.left, rect.top + 1, rect.left +
		rect.Height() - 2, rect.bottom - 1);
	rect.left += rect.Height() + 2;

#if 1
	UINT nState = DFCS_BUTTONCHECK;
#else
	UINT nState = DFCS_BUTTONCHECK | DFCS_FLAT;
#endif
	if (m_bValue) nState |= DFCS_CHECKED;
	pDC->DrawFrameControl(rectCheck, DFC_BUTTON, nState);

	CString strText = m_bValue ? "True" : "False";
	pDC->DrawText(strText, &rect, DT_SINGLELINE|DT_VCENTER);
}

/////////////////////////////////////////////////////////////////////////////
// CPropertyItemInt

IMPLEMENT_DYNAMIC(CPropertyItemInt, CPropertyItem)

void CPropertyItemInt::CreateInPlaceControl(CWnd* pWndParent, CRect& rect, CWnd*& pWndInPlaceControl)
{
	if (GetEnabled())
	{
		if(pWndInPlaceControl != NULL && pWndInPlaceControl->IsKindOf(RUNTIME_CLASS(CInPlaceSpinEditImp)))
			((CInPlaceSpinEditImp*)pWndInPlaceControl)->MoveControl(rect);
		else	
		{
			DestroyInPlaceControl(pWndInPlaceControl);

			pWndInPlaceControl = CInPlaceSpinEditImp::CreateInPlaceSpinEdit(m_iValue, pWndParent, rect);
		}
	
		CInPlaceSpinEditImp *pControl = (CInPlaceSpinEditImp*)pWndInPlaceControl;
		pControl->SetMinMax(m_iMin, m_iMax);
		pControl->SetPos(m_iValue);
	}
}

void CPropertyItemInt::SetData(CWnd* pWndInPlaceControl)
{
	int iValue = ((CInPlaceSpinEditImp*)pWndInPlaceControl)->GetPos();

	if (iValue > m_iMax) iValue = m_iMax;
	else if (iValue < m_iMin) iValue = m_iMin;

	m_iValue = iValue;
}

void CPropertyItemInt::DrawValue(CDC* pDC, CRect& rect)
{
	rect.left -= 2;
	pDC->FillSolidRect(rect, RGB(208, 224, 239));
	rect.left += 2;
	
	CString strText;
	strText.Format("%d", m_iValue);
	pDC->DrawText(strText, &rect, DT_SINGLELINE|DT_VCENTER);
}