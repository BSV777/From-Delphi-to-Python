#if !defined(AFX_INPLACECHECKBOX_H__C56484A0_3E3B_11D6_AAF3_B56C4AFF7C7E__INCLUDED_)
#define AFX_INPLACECHECKBOX_H__C56484A0_3E3B_11D6_AAF3_B56C4AFF7C7E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// InPlaceCheckBox.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CInPlaceCheckBox window

class CInPlaceCheckBoxImp : public CWnd
{
	CInPlaceCheckBoxImp(const CInPlaceCheckBoxImp& d);
	CInPlaceCheckBoxImp operator=(const CInPlaceCheckBoxImp& d);

protected:
	DECLARE_DYNAMIC(CInPlaceCheckBoxImp)

public:
	CInPlaceCheckBoxImp();
	virtual ~CInPlaceCheckBoxImp();

	// Attributes
public:
	bool GetData() const;
	void SetData(const bool bNewVal);

	// Operations
public:
	static CInPlaceCheckBoxImp* CreateInPlaceCheckBox(bool bData, CWnd* pWndParent, CRect& rect);

	void MoveControl(CRect& rect);

private:
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInPlaceCheckBoxImp)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

	// Generated message map functions
protected:
	void Check();
	//{{AFX_MSG(CInPlaceCheckBoxImp)
	afx_msg void OnPaint();
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	// Data
private:
	bool m_bValue;
};

inline CInPlaceCheckBoxImp::~CInPlaceCheckBoxImp()
{
}

inline bool CInPlaceCheckBoxImp::GetData() const
{
	return m_bValue;
}

inline void CInPlaceCheckBoxImp::SetData(const bool bNewVal)
{
	m_bValue = bNewVal;
}

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INPLACECHECKBOX_H__C56484A0_3E3B_11D6_AAF3_B56C4AFF7C7E__INCLUDED_)
