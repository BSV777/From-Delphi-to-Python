// InPlaceSpinEditImp.cpp : implementation file
//

#include "stdafx.h"
#include "propertylistctrl.h"
#include "InPlaceSpinEditImp.h"

#include "UserMessageID.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInPlaceSpinEditImp

IMPLEMENT_DYNAMIC(CInPlaceSpinEditImp, CWnd)

CInPlaceSpinEditImp::CInPlaceSpinEditImp() :
	m_wndEdit("0")
{
}

BEGIN_MESSAGE_MAP(CInPlaceSpinEditImp, CWnd)
	//{{AFX_MSG_MAP(CInPlaceSpinEditImp)
	ON_WM_CREATE()
	ON_NOTIFY(UDN_DELTAPOS, 2, OnChangeSpin)
	ON_MESSAGE(WM_USER_SET_DATA, OnEdit)	
	ON_WM_SETFOCUS()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CInPlaceSpinEditImp message handlers

int CInPlaceSpinEditImp::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	CRect rectClient, rectControl;
	GetClientRect(rectClient);
	rectClient.DeflateRect(0, 1);
	rectControl = rectClient;
	rectControl.DeflateRect(1, 1);
	rectControl.left = rectControl.right - ::GetSystemMetrics(SM_CYVSCROLL);

	CWnd* pParent = GetParent();
	ASSERT(pParent != NULL);

	CFont* pFont = pParent->GetFont();

	m_wndSpin.Create(WS_CHILD | WS_VISIBLE | UDS_ARROWKEYS |
		UDS_SETBUDDYINT, rectControl, this, 2);
	m_wndSpin.SetOwner(this);
	m_wndSpin.SetFont(pFont);

	rectControl = rectClient;
	rectControl.right -= ::GetSystemMetrics(SM_CYVSCROLL);
	
	m_wndEdit.Create(WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL | ES_NUMBER,
		rectControl, this, 3);
	m_wndEdit.SetOwner(this);
	m_wndEdit.SetFont(pFont);

	m_wndSpin.SetBuddy(&m_wndEdit);

	return 0;
}

void CInPlaceSpinEditImp::MoveControl(CRect &rect)
{
	CRect prevRect;
	GetClientRect(prevRect);

	CWnd* pParent = GetParent();

	ClientToScreen(prevRect);
	pParent->ScreenToClient(prevRect);
	pParent->InvalidateRect(prevRect);

	MoveWindow(rect, FALSE);

	pParent->ClientToScreen(rect);
	pParent = pParent->GetParent();	
	pParent->ScreenToClient(rect);

//	m_wndList.SetWindowPos(NULL, rect.left, rect.bottom + 1, 0, 0, SWP_NOZORDER|SWP_NOSIZE);
}

CInPlaceSpinEditImp* CInPlaceSpinEditImp::CreateInPlaceSpinEdit(int iValue,
	CWnd* pWndParent, CRect& rect)
{
	CInPlaceSpinEditImp* pInPlaceSpinEdit = (CInPlaceSpinEditImp*)new CInPlaceSpinEditImp;
	
	pInPlaceSpinEdit->Create(NULL, "", WS_VISIBLE|WS_CHILD, rect, pWndParent, 1);
	pInPlaceSpinEdit->SetPos(iValue);

	return pInPlaceSpinEdit;
}

void CInPlaceSpinEditImp::OnChangeSpin(NMHDR* pNMHDR, LRESULT* pResult)
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	m_wndSpin.SetPos(pNMUpDown->iPos + pNMUpDown->iDelta);
	pNMUpDown->iDelta = 0;

	GetOwner()->SendMessage(WM_USER_SET_DATA);

	*pResult = 0;
}

LRESULT CInPlaceSpinEditImp::OnEdit(WPARAM /*wParam*/, LPARAM /*lParam*/)
{
	GetOwner()->SendMessage(WM_USER_SET_DATA);

	return TRUE;
}

BOOL CInPlaceSpinEditImp::PreTranslateMessage(MSG* pMsg) 
{
	if(pMsg->message == WM_KEYDOWN)
	{
		switch(pMsg->wParam)
		{
		case VK_NEXT:
			m_wndSpin.SetPos(m_wndSpin.GetPos() - 1);
		return TRUE;

		case VK_PRIOR:
			m_wndSpin.SetPos(m_wndSpin.GetPos() + 1);
		return TRUE;

		case VK_ESCAPE: case VK_RETURN: case VK_TAB:
			::PeekMessage(pMsg, NULL, NULL, NULL, PM_REMOVE);
			GetParent()->SetFocus();
		return TRUE;

		default:;
		}
	}
	
	return CWnd::PreTranslateMessage(pMsg);
}

void CInPlaceSpinEditImp::OnSetFocus(CWnd* pOldWnd) 
{
	CWnd::OnSetFocus(pOldWnd);
	
	m_wndEdit.SetFocus();
}

void CInPlaceSpinEditImp::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);

	int iSpinWidth = ::GetSystemMetrics(SM_CYVSCROLL);
	m_wndEdit.SetWindowPos(NULL, 0, 0, cx - iSpinWidth, cy,
		SWP_NOZORDER | SWP_NOMOVE);
	m_wndSpin.SetWindowPos(NULL, cx - iSpinWidth, 0,
		iSpinWidth, cy, SWP_NOZORDER);
}
