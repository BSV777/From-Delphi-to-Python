#if !defined(AFX_MAINOPTDLG_H__12A08684_2F44_11D6_9DAE_A9FB3615C54F__INCLUDED_)
#define AFX_MAINOPTDLG_H__12A08684_2F44_11D6_9DAE_A9FB3615C54F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MainOptDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMainOptDlg dialog

class CMainOptDlg : public CDialog
{
// Construction
public:
	CMainOptDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMainOptDlg)
	enum { IDD = IDD_DIALOG_OPT };
	//}}AFX_DATA

	void GetData(SMainOptions *data) {*data = m_Options;};
	void SetData(SMainOptions *data) {m_Options = *data;};

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainOptDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	SMainOptions	m_Options;
	CImageList		m_imgArt;

	// Generated message map functions
	//{{AFX_MSG(CMainOptDlg)
	afx_msg void OnPaint();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSelchangeIntersection();
	afx_msg void OnSelchangeSnapType();
	afx_msg void OnCheck();
//	afx_msg void OnChangeSpin(NMHDR* pNMHDR, LRESULT* pResult);
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINOPTDLG_H__12A08684_2F44_11D6_9DAE_A9FB3615C54F__INCLUDED_)
