// BottomBarWnd.cpp : implementation file
//

#include "stdafx.h"
#include "XMLEd.h"
#include "BottomBarWnd.h"
#include "XMLEdView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static const int iImageWidth = 10;
static const COLORREF clrTransparent = RGB (255, 0, 255);

/////////////////////////////////////////////////////////////////////////////
// CBottomBarWnd

CBottomBarWnd::CBottomBarWnd()
{
	m_bProp		= false;
	m_bLocked	= false;
	m_bEnabled	= false;
	m_iSnapType = 0;

	m_rectShape.SetRect(0, 0, 0, 0);
}

CBottomBarWnd::~CBottomBarWnd()
{
}


BEGIN_MESSAGE_MAP(CBottomBarWnd, CWnd)
	//{{AFX_MSG_MAP(CBottomBarWnd)
	ON_WM_PAINT()
	ON_WM_CREATE()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CBottomBarWnd message handlers

BOOL CBottomBarWnd::Create(const RECT& rect, CWnd* pParentWnd, UINT nID) 
{
	if (m_strClassName.IsEmpty ())
	{
		m_strClassName = ::AfxRegisterWndClass (0);
	}

	ASSERT_KINDOF (CXMLEdView, pParentWnd);
	m_pParentWnd = (CXMLEdView*) pParentWnd;

	return CWnd::Create (m_strClassName, _T(""), WS_CHILD | WS_VISIBLE,
		rect, pParentWnd, nID);
}

void CBottomBarWnd::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	CRect rectClient;
	GetClientRect(&rectClient);

	dc.FillSolidRect(rectClient, ::GetSysColor(COLOR_BTNFACE));
	dc.Draw3dRect(&rectClient, ::GetSysColor (COLOR_3DHILIGHT),
		::GetSysColor (COLOR_3DDKSHADOW));

	int iNum, iPicTop = (rectClient.Height() - 10) / 2 + 1,
		iButBot = rectClient.bottom - 2;
	
	if (m_bEnabled) iNum = (m_bLocked ? 0 : 1);
	else iNum = 2;
	m_imgButtons.Draw (&dc, iNum, CPoint(4, iPicTop), ILD_NORMAL);
	dc.Draw3dRect(CRect(2, 2, 16, iButBot), m_bLocked ?
		::GetSysColor(COLOR_3DDKSHADOW) : ::GetSysColor(COLOR_3DHILIGHT),
		m_bLocked ? ::GetSysColor(COLOR_3DHILIGHT) :
		::GetSysColor(COLOR_3DDKSHADOW));

	if (m_bEnabled) iNum = (m_bProp ? 3 : 4);
	else iNum = 5;
	m_imgButtons.Draw (&dc, iNum, CPoint(19, iPicTop), ILD_NORMAL);
	dc.Draw3dRect(CRect(17, 2, 31, iButBot), ::GetSysColor(COLOR_3DHILIGHT),
		::GetSysColor(COLOR_3DDKSHADOW));

	if (m_bEnabled) iNum = 10 + m_iSnapType;
	else iNum = 13;
	m_imgButtons.Draw (&dc, iNum, CPoint(34, iPicTop), ILD_NORMAL);
	dc.Draw3dRect(CRect(32, 2, 46, iButBot),
		::GetSysColor(COLOR_3DHILIGHT),	::GetSysColor(COLOR_3DDKSHADOW));
		
	//----------------
	// Size & position
	//----------------
	iNum = m_bEnabled ? 8 : 9;
	m_imgButtons.Draw (&dc, iNum, CPoint(52, iPicTop), ILD_NORMAL);

	CRect rectText(65, 2, 196, rectClient.bottom - 2);
	CString str;

	if (m_bEnabled)
	{
		dc.SelectStockObject(DEFAULT_GUI_FONT); 
		dc.SetTextColor(::GetSysColor(COLOR_WINDOWTEXT));
		dc.SetBkColor(::GetSysColor(COLOR_BTNFACE));

		str.Format("%d, %d", m_rectShape.left, m_rectShape.top);
		dc.DrawText(str, &rectText, DT_CALCRECT | DT_VCENTER | DT_SINGLELINE);
		dc.DrawText(str, &rectText, DT_VCENTER | DT_SINGLELINE);

		iNum = rectText.right + 6;
		rectText.right = 196;
		rectText.left = iNum;
	}

	iNum = m_bEnabled ? 6 : 7;
	m_imgButtons.Draw (&dc, iNum, CPoint(rectText.left, iPicTop),
		ILD_NORMAL);

	if (m_bEnabled)
	{
		rectText.left += 15;
		str.Format("%d, %d", m_rectShape.Width() + 1, m_rectShape.Height() + 1);
		dc.DrawText(str, &rectText, DT_VCENTER | DT_SINGLELINE);
	}
}

int CBottomBarWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	if (!m_imgButtons.Create(IDB_BOTTOM_BAR, 10, 0, clrTransparent))
	{
		TRACE (_T ("CBottomBarWnd: Can't load imagelist!\n"));
		return -1;
	}

	CRect rectEmpty (0, 0, 0, 0);
	
	if (m_ToolTip.Create (this, TTS_ALWAYSTIP) && 
		m_ToolTip.AddTool (this, IDS_LOCK_TIP, CRect(2, 2, 16, 16), 1) &&
		m_ToolTip.AddTool (this, IDS_PROP_TIP, CRect(17, 2, 31, 16), 2) &&
		m_ToolTip.AddTool (this, IDS_SNAP_TIP, CRect(32, 2, 46, 16), 3) &&
		m_ToolTip.AddTool (this, IDS_POS_TIP, CRect(50, 2, 198, 16), 4))
	{
		m_ToolTip.SendMessage (TTM_SETMAXTIPWIDTH, 0, SHRT_MAX);
		m_ToolTip.SendMessage (TTM_SETDELAYTIME, TTDT_AUTOPOP, SHRT_MAX);
		m_ToolTip.SendMessage (TTM_SETDELAYTIME, TTDT_INITIAL, 500);
		m_ToolTip.SendMessage (TTM_SETDELAYTIME, TTDT_RESHOW, 500);
	}
	else
	{
		TRACE(_T ("CBottomBarWnd: Error in creating ToolTip"));
	}

	return 0;
}

void CBottomBarWnd::OnLButtonDown(UINT nFlags, CPoint point) 
{
	RelayEvent (WM_LBUTTONUP, (WPARAM)nFlags, MAKELPARAM(
		LOWORD(point.x), LOWORD(point.y)));

	if (m_bEnabled)
	{
		CRect rectButton;
		bool bRedraw = false;

		rectButton.SetRect(2, 2, 16, 16);
		if (rectButton.PtInRect(point))
		{
			m_bLocked = !m_bLocked;
			bRedraw = true;
		}

		rectButton.SetRect(17, 2, 31, 16);
		if (rectButton.PtInRect(point))
		{
			m_bProp = !m_bProp;
			bRedraw = true;
		}

		rectButton.SetRect(32, 2, 46, 16);
		if (rectButton.PtInRect(point))
		{
			m_iSnapType++;
			if (m_iSnapType == 3) m_iSnapType = 0;
			bRedraw = true;
		}

		if (bRedraw)
		{
			m_pParentWnd->OnBottomBarChanged(m_bLocked,
				m_bProp, m_iSnapType);

			Invalidate(false);
			UpdateWindow();
		}
	}

	CWnd::OnLButtonDown(nFlags, point);
}

void CBottomBarWnd::RelayEvent(UINT message, WPARAM wParam, LPARAM lParam)
{
	if (m_ToolTip.m_hWnd != NULL)
	{
         MSG msg;

         msg.hwnd= m_hWnd;
         msg.message= message;
         msg.wParam= wParam;
         msg.lParam= lParam;
         msg.time= 0;
         msg.pt.x= LOWORD (lParam);
         msg.pt.y= HIWORD (lParam);

         m_ToolTip.RelayEvent(&msg);
     }
}

void CBottomBarWnd::OnMouseMove(UINT nFlags, CPoint point) 
{
	RelayEvent(WM_MOUSEMOVE, (WPARAM)nFlags, MAKELPARAM(
		LOWORD(point.x), LOWORD(point.y)));

	CWnd::OnMouseMove(nFlags, point);
}

BOOL CBottomBarWnd::OnEraseBkgnd(CDC* pDC) 
{
	return true;
}

void CBottomBarWnd::SetRect(const CRect* rect, const CPoint* pntOfs)
{
	m_rectShape.top = pntOfs->y + min(rect->top, rect->bottom);
	m_rectShape.bottom = pntOfs->y + max(rect->top, rect->bottom);
	m_rectShape.left = pntOfs->x + min(rect->left, rect->right);
	m_rectShape.right = pntOfs->x + max(rect->left, rect->right);

	Invalidate(false);
	UpdateWindow();
}

void CBottomBarWnd::SetRect(const CRect* rect)
{
	m_rectShape = *rect;

	Invalidate(false);
	UpdateWindow();
}

void CBottomBarWnd::Enable(bool bLocked, int iSnapType)
{
	m_bEnabled = true;
	m_bLocked = bLocked;
	m_iSnapType = iSnapType;

	Invalidate(false);
	UpdateWindow();
}