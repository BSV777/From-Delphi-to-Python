// LeftView.cpp : implementation file
//

#include "stdafx.h"
#include "XMLEd.h"
#include "LeftView.h"
#include "XMLEdView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static const int iListID = 1;
static const COLORREF clrTransparent = RGB (255, 0, 255);
static const COLORREF clrBorder = RGB (72, 92, 248);
static const COLORREF clrPaper = RGB (136, 148, 255);

/////////////////////////////////////////////////////////////////////////////
// CLeftView

IMPLEMENT_DYNCREATE(CLeftView, CView)

CLeftView::CLeftView()
{
}

CLeftView::~CLeftView()
{
}


BEGIN_MESSAGE_MAP(CLeftView, CView)
	//{{AFX_MSG_MAP(CLeftView)
	ON_WM_CREATE()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_MESSAGE(WM_USER_SET_DATA, OnChangeData)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLeftView drawing

void CLeftView::OnDraw(CDC* pDC)
{
	CRect rectClient;
	GetClientRect(rectClient);

	pDC->FillSolidRect(rectClient, clrPaper);

	CPoint pntLogo = rectClient.TopLeft();
	for (int n = 0; n < 3; n++)
	{
		m_imgArt.Draw(pDC, n, pntLogo, ILD_NORMAL);
		pntLogo.x += 22;
	}

	int num = 3;
	for (pntLogo.x; pntLogo.x < rectClient.right; pntLogo.x += 22)
	{
		m_imgArt.Draw(pDC, num, pntLogo, ILD_NORMAL);
		num++;
		if (num == 5) num = 3;
	}
}

/////////////////////////////////////////////////////////////////////////////
// CLeftView diagnostics

#ifdef _DEBUG
void CLeftView::AssertValid() const
{
	CView::AssertValid();
}

void CLeftView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CLeftView message handlers

int CLeftView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_imgArt.Create(IDB_LOGO, 22, 0, clrPaper))
	{
		TRACE (_T ("LeftView: Can't load imagelist!\n"));
		return -1;
	}

	CRect rectControl;
	GetClientRect(rectControl);
	rectControl.left += 22;
	if (!m_wndList.Create(WS_VISIBLE | WS_CHILD, rectControl,
		this, iListID))
	{
		TRACE (_T ("LeftView: Can't create property list!\n"));
		return -1;
	}

	CPaintDC dc(this);
	dc.SelectStockObject(DEFAULT_GUI_FONT);
	m_wndList.SetFont(dc.GetCurrentFont(), false);

	m_sManager.SetParent(this);
	m_sManager.SetData(&m_sData);
	m_wndList.SetPropertyItemManager(&m_sManager);

	SetWidth(GetApp()->GetOpt()->iLeftSize, false);

	return 0;
}

BOOL CLeftView::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
}

void CLeftView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);

	CRect rectClient;
	GetClientRect(rectClient);

	m_wndList.SetWindowPos(NULL, rectClient.left,
		rectClient.top + 22, rectClient.Width(),
		rectClient.Height() - 22, SWP_NOZORDER);
}

void CLeftView::UpdateData()
{
	m_wndList.ResetContent();
	m_sManager.SetData(&m_sData);
	m_wndList.SetPropertyItemManager(&m_sManager);
	ResetItems();
}

LRESULT CLeftView::OnChangeData(WPARAM /*wParam*/, LPARAM /*lParam*/)
{
	m_sManager.GetData(&m_sData);
	GetMainView()->UpdateShapeData(&m_sData);
	return TRUE;
}

CXMLEdView* CLeftView::GetMainView()
{
	CSplitterWnd* pParent = (CSplitterWnd*)GetParent();
	return (CXMLEdView*)pParent->GetPane(0, 1);
}

void CLeftView::SetWidth(int iNewWidth, bool bUpdate)
{
	CSplitterWnd* pParent = (CSplitterWnd*)GetParent();
	pParent->SetColumnInfo(0, iNewWidth, 100);
	if (bUpdate) pParent->RecalcLayout();
}

int CLeftView::GetWidth()
{
	CSplitterWnd* pParent = (CSplitterWnd*)GetParent();
	int iWidth, iMin;
	pParent->GetColumnInfo(0, iWidth, iMin);
	return iWidth;
}

CXMLEdApp* CLeftView::GetApp()
{
	return (CXMLEdApp*)AfxGetApp();
}

void CLeftView::ResetItems()
{
	int iCount = m_wndList.GetCount();
	if (iCount == LB_ERR) return;

	int iWidth = 20 * GetMainView()->GetFormOpt()->iWidth,
		iHeight = 20 * GetMainView()->GetFormOpt()->iHeight;
	bool bRectNull = m_sData.m_iHeight != 1 && m_sData.m_iWidth != 1;

	for (int n = 0; n < iCount; n++)
	{
		CPropertyItem *pItem = m_wndList.GetPropertyItem(n);
		int iItemID = pItem->GetPropertyID();
		CPropertyItemInt *pIntItem;

		switch (iItemID)
		{
		case ID_PM_BORD:
			pItem->SetEnabled(m_sData.GetBorderInt() != 3);
		break;

		case ID_PM_ID:
			pItem->SetEnabled(false); 
		break;

		case ID_PM_LOCK:
			pItem->SetEnabled(m_sData.GetLockedInt() != 3);
		break;

		case ID_PM_NAME:
			pItem->SetEnabled(m_sData.m_bNameNull);
		break;

		case ID_PM_SNAP:
			pItem->SetEnabled(m_sData.m_iSnap != -1);
		break;

		case ID_PM_TYPE:
			pItem->SetEnabled(false);
		break;

		case ID_PM_COL:
			pItem->SetEnabled(bRectNull); 
			pIntItem = (CPropertyItemInt*)pItem;
			pIntItem->SetMinMax(0, iWidth);
		break;

		case ID_PM_ROW:
			pItem->SetEnabled(bRectNull);
			pIntItem = (CPropertyItemInt*)pItem;
			pIntItem->SetMinMax(0, iHeight);
		break;

		case ID_PM_LEN:
			pItem->SetEnabled(bRectNull);
			pIntItem = (CPropertyItemInt*)pItem;
			pIntItem->SetMinMax(20, iWidth);
		break;

		case ID_PM_HGT:
			pItem->SetEnabled(bRectNull);
			pIntItem = (CPropertyItemInt*)pItem;
			pIntItem->SetMinMax(20, iHeight);
		break;

		case ID_PM_HALIG:
			pItem->SetEnabled(m_sData.m_iVAlig != -1);
		break;

		case ID_PM_VALIG:
			pItem->SetEnabled(m_sData.m_iHAlig != -1);
		break;
		}
	}

}

void CLeftView::OnFileOpen() 
{
	GetMainView()->OnFileOpen();	
}

void CLeftView::OnFileSave() 
{
	GetMainView()->OnFileSave();
}

void CLeftView::OnFileSaveAs() 
{
	GetMainView()->OnFileSaveAs();
}
