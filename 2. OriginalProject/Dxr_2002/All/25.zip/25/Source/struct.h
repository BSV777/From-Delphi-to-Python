// struct.h: interface for the SMainFormOptions class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STRUCT_H__9EA9EAEA_2F85_11D6_9DAE_EFD57CA5DB49__INCLUDED_)
#define AFX_STRUCT_H__9EA9EAEA_2F85_11D6_9DAE_EFD57CA5DB49__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "afxtempl.h"
#include "PropList\PropertyListCtrl.h"

//////////////////////////////////////////////////////////////////////
// SFormOptions - document options structue

struct SFormOptions
{
	CString	strName;
	CString strCaption;
	int		iHeight;
	int		iWidth;

	SFormOptions() : strName("Form #"), strCaption(""),
		iHeight(50), iWidth(20) {};
};

//////////////////////////////////////////////////////////////////////
// SMainOptions - application options structue

class SMainOptions
{
public:
	SMainOptions() : bShowGrid(true), bShowNumbers(false),
		bShowMousePos(false), iSnapType(0), bStyleIDE(false),
		iLeftSize(160), iRectSize(3), bDeleteOnIns(false),
		bShowFProp(true), bHTMLGrid(true) {};

	int bShowGrid;
	int bShowNumbers;
	int bShowMousePos;
	int bStyleIDE;
	int bDeleteOnIns;
	int bShowFProp;
	int	bHTMLGrid;
	int iSnapType;
	int iIntersection;
	int iRectSize;
	int iLeftSize;

	void SaveToINI();
	void LoadFromINI();
};

//////////////////////////////////////////////////////////////////////
// SShape - document object options structue

class SPropData;

class SShape
{
public:
	SShape() {Reset();};

	SShape& operator=(SPropData& d);
	void operator+= (SShape& d);
		// *** used for create group properies
		// *** look definition

	enum Type {tShape, tLabel, tEdit, tButton, tTable};
	enum State {stNormal, stSelected, stSelGroup};
	enum Snap {snNone, snTopLeft, snCenter, snNull};
	
	CString			strName;
	int				iAlig;
	int				iID;
	Type			eType;
	Snap			eSnap;
	bool			bNameNull;

	void Reset();
	bool GetBorder()				{return bBorder != 0;};
	int	 GetBorderInt()				{return bBorder;};
	void SetBorder(bool bNewVal)	{bBorder = bNewVal;};
	bool GetLocked()				{return bLocked != 0;};
	int	 GetLockedInt()				{return bLocked;};
	void SetLocked(bool bNewVal)	{bLocked = bNewVal;};
	State GetState()				{return eState;};
	void SetState(State eNewState)	{eState = eNewState;};
	CRect& GetRect()				{return rectPos;};
	void SetRect(CRect& rectNew)	{rectPos = rectNew;};

protected:
	int				bBorder;
	int				bLocked;
	State			eState;
	CRect			rectPos;
};

typedef CList<SShape*, SShape*&> ShapeList;

//////////////////////////////////////////////////////////////////////
// SPropData - document object property list structue

class SDataManager;

class SPropData : public CObject
{
	SPropData(const SPropData& d);
	SPropData& operator=(const SPropData& d);

public:
	SPropData();
	~SPropData();
	SPropData& operator=(SShape& d);

	CString	m_strName;
	CString m_strType;
	int		m_iID;
	int		m_iSnap;
	int		m_iHeight;
	int		m_iWidth;
	int		m_iLeft;
	int		m_iTop;
	int		m_iVAlig;
	int		m_iHAlig;
	bool	m_bNameNull;

	bool GetBorder()				{return m_bBorder != 0;};
	int	 GetBorderInt()				{return m_bBorder;};
	void SetBorder(bool bNewVal)	{m_bBorder = bNewVal;};
	bool GetLocked()				{return m_bLocked != 0;};
	int	 GetLockedInt()				{return m_bLocked;};
	void SetLocked(bool bNewVal)	{m_bLocked = bNewVal;};

protected:
	int		m_bBorder;
	int		m_bLocked;

	friend SDataManager;
};

inline SPropData::~SPropData()
{
}

//////////////////////////////////////////////////////////////////////
// SDataManager - property list manager

#define ID_PM_BORD	1
#define ID_PM_ID	2
#define ID_PM_LOCK	3
#define ID_PM_NAME	4
#define ID_PM_SNAP	5
#define ID_PM_TYPE	6
#define ID_PM_COL	7
#define ID_PM_ROW	8
#define ID_PM_LEN	9
#define ID_PM_HGT	10
#define ID_PM_HALIG	11
#define ID_PM_VALIG	12


class SDataManager : public CPropertyItemManager
{
	SDataManager(const SDataManager& d);
	SDataManager& operator=(const SDataManager& d);

public:
	SDataManager();
	~SDataManager();

	bool SetData(const CObject* pData);
	bool GetData(CObject* pData) const;
};

//////////////////////////////////////////////////////////////////////
// SSaveItem - html table cell

struct SSaveItem
{
	enum State {stNone, stHerder, stInvisible};

	State	eState;
	SShape* pLink;
	int iRowSpan;
	int iColSpan;
};

#endif // !defined(AFX_STRUCT_H__9EA9EAEA_2F85_11D6_9DAE_EFD57CA5DB49__INCLUDED_)
