#if !defined(AFX_BOTTOMBARWND_H__7A21A541_2DEE_11D6_9DAE_DEF3E9C1CB4D__INCLUDED_)
#define AFX_BOTTOMBARWND_H__7A21A541_2DEE_11D6_9DAE_DEF3E9C1CB4D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// BottomBarWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBottomBarWnd window

class CXMLEdView;

class CBottomBarWnd : public CWnd
{
// Construction
public:
	CBottomBarWnd();

// Attributes
public:

// Operations
public:
	void Enable(bool bLocked, int iSnapType);
	void Disable()					{m_bEnabled = false;};
	void SetRect(const CRect* rect, const CPoint* pntOfs);
	void SetRect(const CRect* rect);
	CRect* GetRect()				{return &m_rectShape;};
	bool IsLocked()					{return m_bLocked;};

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBottomBarWnd)
	public:
	virtual BOOL Create(const RECT& rect, CWnd* pParentWnd, UINT nID);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CBottomBarWnd();

	// Generated message map functions
protected:
	void RelayEvent(UINT message, WPARAM wParam, LPARAM lParam);
	
	int				m_iSnapType;
	CRect			m_rectShape;
	bool			m_bProp;
	bool			m_bLocked;
	bool			m_bEnabled;
	CXMLEdView*		m_pParentWnd;
	CString			m_strClassName;
	CImageList		m_imgButtons;
	CToolTipCtrl	m_ToolTip;

	//{{AFX_MSG(CBottomBarWnd)
	afx_msg void OnPaint();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BOTTOMBARWND_H__7A21A541_2DEE_11D6_9DAE_DEF3E9C1CB4D__INCLUDED_)
