// MainOptDlg.cpp : implementation file
//

#include "stdafx.h"
#include "XMLEd.h"
#include "MainOptDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static const COLORREF clrTransparent = RGB (255, 0, 255);
static const int iRectMin = 3;
static const int iRectMax = 10;
static const int iLeftMin = 100;
static const int iLeftMax = 400;

/////////////////////////////////////////////////////////////////////////////
// CMainOptDlg dialog


CMainOptDlg::CMainOptDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMainOptDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMainOptDlg)
	//}}AFX_DATA_INIT
}


void CMainOptDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMainOptDlg)
	DDX_Check		(pDX, IDC_SHOW_GRID,		m_Options.bShowGrid);
	DDX_Check		(pDX, IDC_SHOW_SCALE,		m_Options.bShowNumbers);
	DDX_Check		(pDX, IDC_SHOW_MOUSE,		m_Options.bShowMousePos);
	DDX_CBIndex		(pDX, IDC_SNAP_TYPE,		m_Options.iSnapType);
	DDX_CBIndex		(pDX, IDC_INTERSECTION,		m_Options.iIntersection);
	DDX_Check		(pDX, IDC_STYLE_IDE,		m_Options.bStyleIDE);
	DDX_Text		(pDX, IDC_STYLE_LEFT,		m_Options.iLeftSize);
	DDV_MinMaxInt	(pDX, m_Options.iLeftSize,	iLeftMin, iLeftMax);
	DDX_Text		(pDX, IDC_STYLE_RECT,		m_Options.iRectSize);
	DDV_MinMaxInt	(pDX, m_Options.iRectSize,	iRectMin, iRectMax);
	DDX_Check		(pDX, IDC_STYLE_DELINS,		m_Options.bDeleteOnIns);
	DDX_Check		(pDX, IDC_STYLE_FILLPROP,	m_Options.bShowFProp);
	DDX_Check		(pDX, IDC_STYLE_HTML,		m_Options.bHTMLGrid);
	//}}AFX_DATA_MAP

}

BEGIN_MESSAGE_MAP(CMainOptDlg, CDialog)
	//{{AFX_MSG_MAP(CMainOptDlg)
	ON_WM_PAINT()
	ON_WM_CREATE()
	ON_CBN_SELCHANGE(IDC_INTERSECTION, OnSelchangeIntersection)
	ON_CBN_SELCHANGE(IDC_SNAP_TYPE, OnSelchangeSnapType)
	ON_BN_CLICKED(IDC_SHOW_GRID, OnCheck)
//	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN, OnChangeSpin)
	ON_BN_CLICKED(IDC_SHOW_SCALE, OnCheck)
	ON_BN_CLICKED(IDC_SHOW_MOUSE, OnCheck)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainOptDlg message handlers

void CMainOptDlg::OnPaint() 
{
	CPaintDC dc(this);
	CComboBox *cb = (CComboBox*)GetDlgItem(IDC_INTERSECTION);
	CRect rectCB;

	cb->GetWindowRect(rectCB);
	ScreenToClient(rectCB);

	int iTop = rectCB.top - (32 - rectCB.Height()) / 2;
	m_imgArt.Draw (&dc, m_Options.iIntersection, CPoint(8, iTop), ILD_NORMAL);

	cb = (CComboBox*)GetDlgItem(IDC_SNAP_TYPE);
	cb->GetWindowRect(rectCB);
	ScreenToClient(rectCB);

	iTop = rectCB.top - (32 - rectCB.Height()) / 2;
	m_imgArt.Draw (&dc, m_Options.iSnapType + 3, CPoint(8, iTop), ILD_NORMAL);

	CButton *but = (CButton*)GetDlgItem(IDC_SHOW_MOUSE);
	but->GetWindowRect(rectCB);
	ScreenToClient(rectCB);

	iTop = rectCB.top - (32 - rectCB.Height()) / 2;
	m_imgArt.Draw (&dc, 6, CPoint(8, iTop), ILD_NORMAL);

	if (m_Options.bShowGrid)
		m_imgArt.Draw (&dc, 7, CPoint(8, iTop), ILD_NORMAL);

	if (m_Options.bShowNumbers)
		m_imgArt.Draw (&dc, 8, CPoint(8, iTop), ILD_NORMAL);

	if (m_Options.bShowMousePos)
		m_imgArt.Draw (&dc, 9, CPoint(8, iTop), ILD_NORMAL);
}

int CMainOptDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_imgArt.Create(IDB_ART_DLG, 32, 0, clrTransparent))
	{
		TRACE (_T ("MaiOptDlg: Can't load imagelist!\n"));
		return -1;
	}
	
	return 0;
}

void CMainOptDlg::OnSelchangeIntersection() 
{
	CComboBox *cb = (CComboBox*)GetDlgItem(IDC_INTERSECTION);
	m_Options.iIntersection = cb->GetCurSel();

	Invalidate();
	UpdateWindow();
}

void CMainOptDlg::OnSelchangeSnapType() 
{
	CComboBox *cb = (CComboBox*)GetDlgItem(IDC_SNAP_TYPE);
	m_Options.iSnapType = cb->GetCurSel();

	Invalidate();
	UpdateWindow();
}

void CMainOptDlg::OnCheck() 
{
	UpdateData();
	Invalidate(false);
	UpdateWindow();
}

/*void CMainOptDlg::OnChangeSpin(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	
	if (pNMUpDown->iDelta > 0)
	{
		if (m_Options.iRectSize < iMax) m_Options.iRectSize++;
	} else if (pNMUpDown->iDelta < 0)
	{
		if (m_Options.iRectSize > iMin) m_Options.iRectSize--;
	}

	m_wndSpin.SetPos(50);

	UpdateData(false);

	*pResult = 0;
}*/

BOOL CMainOptDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	CSpinButtonCtrl* pSpin = (CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_LEFT);
	pSpin->SetRange(iLeftMin, iLeftMax);
	pSpin->SetPos(m_Options.iLeftSize);

	pSpin = (CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_RECT);
	pSpin->SetRange(iRectMin, iRectMax);
	pSpin->SetPos(m_Options.iRectSize);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
