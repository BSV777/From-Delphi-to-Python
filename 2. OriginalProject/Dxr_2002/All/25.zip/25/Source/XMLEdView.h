// XMLEdView.h : interface of the CXMLEdView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_XMLEDVIEW_H__7A21A52F_2DEE_11D6_9DAE_DEF3E9C1CB4D__INCLUDED_)
#define AFX_XMLEDVIEW_H__7A21A52F_2DEE_11D6_9DAE_DEF3E9C1CB4D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BottomBarWnd.h"

class CMainFrame;
class CXMLEdDoc;
class CLeftView;

class CXMLEdView : public CView
{
protected: // create from serialization only
	CXMLEdView();
	DECLARE_DYNCREATE(CXMLEdView)

public:
	void UpdateShapeData(SPropData* sData);
	void OnBottomBarChanged(bool bLocked, bool bInsp, int iSnapType);
	CXMLEdDoc* GetDocument();
	SFormOptions* GetFormOpt()	{return &m_FormOpt;};

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CXMLEdView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

	virtual ~CXMLEdView();

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	void LoadXML(CString *strPath);
	void SaveXML(CString *strPath);
	void CreateSaveData(SSaveItem *pArray, int cy, int cx);
	void SaveHTML(const CString *strPath);
	void UpdateLeftViewData(SShape* sShape);
	CLeftView* GetLeftView();
	void MoveSelection(CPoint *pntFrom,  CPoint *pntTo);
		// *** From - Global; To - Local ***
	void CountDragRect(CRect *rect, ShapeList* list);
	bool CheckSelGroup();
	void SetResetSelection(SShape* sShape);
	void SelectRect(CRect *rect);
	void DeleteAll();
	void DeleteShape(int iID);
	void RemoveSelection();
	void HitTest(CPoint pntMousePos);
	void Intersect(CRect *rect, CRect *rectInters);
	bool CheckIntersect(SShape *sShape);
	int SnapInt(int iValue);
	void SnapRect(CRect *rect, int iSnapType);
	void DrawTable(CDC *pDC, CRect *rect, SShape *sShape);
	void DrawButton(CDC *pDC, CRect *rect, SShape* sShape);
	void DrawEdit(CDC *pDC, CRect *rect, SShape* sShape);
	void DrawLabel(CDC *pDC, CRect *rect, SShape* sShape);
	void DrawClientArea(CDC *pDC);
	void ResizeControls();
	bool CountVisiblePart(CRect *Line, CRect *Frame);
	void CountOfs(CPoint* pntOfs);
	void SetPaneText(const CString*);
	CMainFrame* GetMainFrame();
	CXMLEdApp* GetApp();
	void DrawTopRuler(CDC *dc, CRect *rect);
	void DrawLeftRuler(CDC *dc, CRect *rect);
	bool Scroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);

	enum eState {stNormal, stSelect, stDraw, stLabel, stEdit,
		stButton, stTable};
	
	int				m_iBarWidth;
	int				m_iShapeCounter;
	bool			m_bIsTimerSet;
	CImageList		m_imgArt;
	CPoint			m_pntMousePos;
	CRect			m_rectLeftRuler;
	CRect			m_rectTopRuler;
	CRect			m_rectRulerBut;
	CRect			m_rectSelect;
	CRect			m_rectClient;
	CRectTracker	m_rectTracker;
	CScrollBar		m_wndVertScroll;
	CScrollBar		m_wndHorzScroll;
	CBottomBarWnd	m_wndBottomBar;
	SFormOptions	m_FormOpt;
	eState			m_eState;
	SShape*			m_sShape;
	SShape*			m_sTrackedShape;
	SShape			m_sSelData;
	ShapeList		m_listShape;
	ShapeList		m_listSelected;

	//{{AFX_MSG(CXMLEdView)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnFileOptions();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnInsertDraw();
	afx_msg void OnInsertLabel();
	afx_msg void OnInsertEdit();
	afx_msg void OnInsertButton();
	afx_msg void OnInsertTable();
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnLockAll();
	afx_msg void OnUnlockAll();
	afx_msg void OnDestroy();
	afx_msg void OnKeyDelete();
	afx_msg void OnSelectAll();
//	afx_msg void OnEditCopy();
//	afx_msg void OnEditPaste();
//	afx_msg void OnEditCut();
	afx_msg void OnFormatInters();
public:
	afx_msg void OnFileSave();
	afx_msg void OnFileSaveAs();
	afx_msg void OnFileOpen();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in XMLEdView.cpp
inline CXMLEdDoc* CXMLEdView::GetDocument()
   { return (CXMLEdDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_XMLEDVIEW_H__7A21A52F_2DEE_11D6_9DAE_DEF3E9C1CB4D__INCLUDED_)
