#if !defined(AFX_FORMOPTDLG_H__F280DD41_2EB8_11D6_9DAE_E25D263D3B49__INCLUDED_)
#define AFX_FORMOPTDLG_H__F280DD41_2EB8_11D6_9DAE_E25D263D3B49__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FormOptDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFormOptDlg dialog

class CFormOptDlg : public CDialog
{
// Construction
public:
	CFormOptDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFormOptDlg)
	enum { IDD = IDD_DIALOG_SIZE };
	//}}AFX_DATA

	void SetData(SFormOptions &data) {m_Options = data;};
	void GetData(SFormOptions &data) {data = m_Options;};

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFormOptDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	SFormOptions m_Options;

	// Generated message map functions
	//{{AFX_MSG(CFormOptDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSizeSmall();
	afx_msg void OnSizeMedium();
	afx_msg void OnSizeHuge();
	afx_msg void OnSizeCustom();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FORMOPTDLG_H__F280DD41_2EB8_11D6_9DAE_E25D263D3B49__INCLUDED_)
