// XMLEd.h : main header file for the XMLED application
//

#if !defined(AFX_XMLED_H__7A21A525_2DEE_11D6_9DAE_DEF3E9C1CB4D__INCLUDED_)
#define AFX_XMLED_H__7A21A525_2DEE_11D6_9DAE_DEF3E9C1CB4D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "Struct.h"			// Added by ClassView

/////////////////////////////////////////////////////////////////////////////
// CXMLEdApp:
// See XMLEd.cpp for the implementation of this class
//

class CXMLEdApp : public CWinApp
{
public:
	CXMLEdApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CXMLEdApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CXMLEdApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
	void ClearBufer();
	SMainOptions* GetOpt()	{return &m_MainOpt;};
	ShapeList* GetBufer()	{return &m_listBufer;};

protected:
	SMainOptions				m_MainOpt;
	ShapeList					m_listBufer;
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_XMLED_H__7A21A525_2DEE_11D6_9DAE_DEF3E9C1CB4D__INCLUDED_)
