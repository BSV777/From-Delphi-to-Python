// FormOptDlg.cpp : implementation file
//

#include "stdafx.h"
#include "XMLEd.h"
#include "FormOptDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFormOptDlg dialog

static const int iSmallHeight = 50;
static const int iSmallWidth = 20;
static const int iMediumHeight = 70;
static const int iMediumWidth = 30;
static const int iHugeHeight = 100;
static const int iHugeWidth = 50;

CFormOptDlg::CFormOptDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFormOptDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFormOptDlg)
	//}}AFX_DATA_INIT
}


void CFormOptDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFormOptDlg)
	DDX_Text(pDX, IDC_FORM_CAPT, m_Options.strCaption);
	DDX_Text(pDX, IDC_FORM_NAME, m_Options.strName);
	DDX_Text(pDX, IDC_SIZE_HEIGHT, m_Options.iHeight);
	DDV_MinMaxInt(pDX, m_Options.iHeight, 50, 200);
	DDX_Text(pDX, IDC_SIZE_WIDTH, m_Options.iWidth);
	DDV_MinMaxInt(pDX, m_Options.iWidth, 20, 100);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFormOptDlg, CDialog)
	//{{AFX_MSG_MAP(CFormOptDlg)
	ON_BN_CLICKED(IDC_SIZE_SMALL, OnSizeSmall)
	ON_BN_CLICKED(IDC_SIZE_MEDIUM, OnSizeMedium)
	ON_BN_CLICKED(IDC_SIZE_HUGE, OnSizeHuge)
	ON_BN_CLICKED(IDC_SIZE_CUSTOM, OnSizeCustom)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFormOptDlg message handlers

BOOL CFormOptDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	int iButtonID = IDC_SIZE_CUSTOM;

	if (m_Options.iHeight == iSmallHeight && m_Options.iWidth == iSmallWidth)
		iButtonID = IDC_SIZE_SMALL;
	else if (m_Options.iHeight == iMediumHeight &&
		m_Options.iWidth == iMediumWidth) iButtonID = IDC_SIZE_MEDIUM;
		else if (m_Options.iHeight == iHugeHeight &&
			m_Options.iWidth == iHugeWidth) iButtonID = IDC_SIZE_HUGE;

	CButton *Button = (CButton*)GetDlgItem(iButtonID);
	if (Button) Button->SetCheck(1);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CFormOptDlg::OnSizeSmall()
{
	m_Options.iWidth = iSmallWidth;
	m_Options.iHeight = iSmallHeight;

	CEdit *edit = (CEdit*)GetDlgItem(IDC_SIZE_HEIGHT);
	if (edit) edit->ModifyStyle(NULL, WS_DISABLED);
	edit = (CEdit*)GetDlgItem(IDC_SIZE_WIDTH);
	if (edit) edit->ModifyStyle(NULL, WS_DISABLED);
	
	UpdateData(false);
}

void CFormOptDlg::OnSizeMedium()
{
	m_Options.iWidth = iMediumWidth;
	m_Options.iHeight = iMediumHeight;

	CEdit *edit = (CEdit*)GetDlgItem(IDC_SIZE_HEIGHT);
	if (edit) edit->ModifyStyle(NULL, WS_DISABLED);
	edit = (CEdit*)GetDlgItem(IDC_SIZE_WIDTH);
	if (edit) edit->ModifyStyle(NULL, WS_DISABLED);
	
	UpdateData(false);
}

void CFormOptDlg::OnSizeHuge()
{
	m_Options.iWidth = iHugeWidth;
	m_Options.iHeight = iHugeHeight;

	CEdit *edit = (CEdit*)GetDlgItem(IDC_SIZE_HEIGHT);
	if (edit) edit->ModifyStyle(NULL, WS_DISABLED);
	edit = (CEdit*)GetDlgItem(IDC_SIZE_WIDTH);
	if (edit) edit->ModifyStyle(NULL, WS_DISABLED);
	
	UpdateData(false);
}

void CFormOptDlg::OnSizeCustom()
{
	CEdit *edit = (CEdit*)GetDlgItem(IDC_SIZE_HEIGHT);
	if (edit) edit->ModifyStyle(WS_DISABLED, NULL);
	edit = (CEdit*)GetDlgItem(IDC_SIZE_WIDTH);
	if (edit) 
	{
		edit->ModifyStyle(WS_DISABLED, NULL);
		edit->SetFocus();
	}
}

