// XMLEdView.cpp : implementation of the CXMLEdView class
//

#include "stdafx.h"
#include "XMLEd.h"

#include "XMLEdDoc.h"
#include "XMLEdView.h"
#include "LeftView.h"
#include "FormOptDlg.h"
#include "MainFrm.h"

#include "utf8.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static const int iToolBarWidth = 200;
static const int iVertScrollID = 1;
static const int iHorzScrollID = 2;
static const int iBottomBarID = 3;
static const int iBase = 100;
static const int iMoveTimerID = 1;
static const int iSlowTimerDuration = 300;
static const int iFastTimerDuration = 100;

static const COLORREF clrTransparent = RGB (255, 0, 255);
static const COLORREF clrShadow = RGB (128, 128, 128);
static const COLORREF clrLight = RGB (192, 192, 192);
static const COLORREF clrWhite = RGB (255, 255, 255);
static const COLORREF clrRed = RGB (255, 0, 0);
static const COLORREF clrBlack = RGB (0, 0, 0);

/////////////////////////////////////////////////////////////////////////////
// CXMLEdView

IMPLEMENT_DYNCREATE(CXMLEdView, CView)

BEGIN_MESSAGE_MAP(CXMLEdView, CView)
	//{{AFX_MSG_MAP(CXMLEdView)
	ON_WM_SIZE()
	ON_WM_CREATE()
	ON_COMMAND(ID_FILE_OPTIONS, OnFileOptions)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_WM_ERASEBKGND()
	ON_COMMAND(ID_INSERT_DRAW, OnInsertDraw)
	ON_COMMAND(ID_INSERT_LABEL, OnInsertLabel)
	ON_COMMAND(ID_INSERT_EDIT, OnInsertEdit)
	ON_COMMAND(ID_INSERT_BUTTON, OnInsertButton)
	ON_COMMAND(ID_INSERT_TABLE, OnInsertTable)
	ON_WM_LBUTTONUP()
	ON_WM_TIMER()
	ON_WM_SETCURSOR()
	ON_COMMAND(ID_FORMAT_LOCKALL, OnLockAll)
	ON_COMMAND(ID_FORMAT_UNLOCKALL, OnUnlockAll)
	ON_WM_DESTROY()
	ON_COMMAND(ID_KEY_DELETE, OnKeyDelete)
	ON_COMMAND(ID_SELECT_ALL, OnSelectAll)
//	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
//	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
//	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_COMMAND(ID_FORMAT_INTERS, OnFormatInters)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CXMLEdView construction/destruction

CXMLEdView::CXMLEdView()
{
	m_eState			= stNormal;
	m_bIsTimerSet		= false;
	m_iShapeCounter		= 0;
	m_sTrackedShape		= NULL;
	m_pntMousePos		= CPoint(100, 100);
	
	m_rectTracker.m_nStyle = CRectTracker::solidLine |
		CRectTracker::resizeInside;
	m_rectTracker.m_sizeMin = CSize(20, 20);
}

CXMLEdView::~CXMLEdView()
{
}

BOOL CXMLEdView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CXMLEdView drawing

void CXMLEdView::OnDraw(CDC* pDC)
{
	CRect rectClient;
	GetClientRect(&rectClient);

	CDC*		dc = pDC;
	BOOL		bMemDC = FALSE;
	CDC			dcMem;
	CBitmap		bmp;
	CBitmap*	pOldBmp = NULL;

	if (dcMem.CreateCompatibleDC (pDC) && bmp.CreateCompatibleBitmap (pDC,
		rectClient.Width (), rectClient.Height ()))
	{
		bMemDC = TRUE;
		pOldBmp = dcMem.SelectObject (&bmp);
		dc = &dcMem;
	}	

	dc->SelectStockObject(DEFAULT_GUI_FONT);
	
	dc->FillSolidRect(rectClient, clrLight);

	int iOfsX = (m_rectRulerBut.Width() - 15) / 2,
		iOfsY = (m_rectRulerBut.Height() - 15) / 2;

	m_imgArt.Draw(dc, 0, CPoint(m_rectRulerBut.left + iOfsX,
		m_rectRulerBut.top + iOfsY), ILD_NORMAL);

	DrawLeftRuler(dc, &rectClient);
	DrawTopRuler(dc, &rectClient);
	DrawClientArea(dc);

	if (m_eState == stDraw || m_eState == stSelect) 
	{
		int iPenStyle = m_eState == stDraw ? PS_SOLID : PS_DOT;

		CPen penSelect(iPenStyle, 1, clrBlack), *penOld;
		penOld = dc->SelectObject(&penSelect);

		CRect rectLine;

		rectLine.SetRect(m_rectSelect.left, m_rectSelect.top,
			m_rectSelect.right, m_rectSelect.top);
		if (CountVisiblePart(&rectLine, &m_rectClient))
		{
			dc->MoveTo(rectLine.TopLeft());
			dc->LineTo(rectLine.BottomRight());
		}

		rectLine.SetRect(m_rectSelect.right, m_rectSelect.top,
			m_rectSelect.right, m_rectSelect.bottom);
		if (CountVisiblePart(&rectLine, &m_rectClient))
		{
			dc->MoveTo(rectLine.TopLeft());
			dc->LineTo(rectLine.BottomRight());
		}

		rectLine.SetRect(m_rectSelect.right, m_rectSelect.bottom,
			m_rectSelect.left, m_rectSelect.bottom);
		if (CountVisiblePart(&rectLine, &m_rectClient))
		{
			dc->MoveTo(rectLine.TopLeft());
			dc->LineTo(rectLine.BottomRight());
		}

		rectLine.SetRect(m_rectSelect.left, m_rectSelect.top,
			m_rectSelect.left, m_rectSelect.bottom);
		if (CountVisiblePart(&rectLine, &m_rectClient))
		{
			dc->MoveTo(rectLine.TopLeft());
			dc->LineTo(rectLine.BottomRight());
		}

		dc->SelectObject(penOld);
	}
	
	//-------------
	// Apply result
	//-------------
	if (bMemDC)
	{
		CRect rect;
		pDC->GetClipBox(rect);
		pDC->BitBlt(rect.left, rect.top, rect.Width(), rect.Height(),
			&dcMem, rect.left, rect.top, SRCCOPY);

		dcMem.SelectObject(pOldBmp);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CXMLEdView diagnostics

#ifdef _DEBUG
void CXMLEdView::AssertValid() const
{
	CView::AssertValid();
}

void CXMLEdView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CXMLEdDoc* CXMLEdView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CXMLEdDoc)));
	return (CXMLEdDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CXMLEdView message handlers

void CXMLEdView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	ResizeControls();
}

int CXMLEdView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rectScroll;

	if (!m_wndVertScroll.Create(SBS_VERT | WS_CHILD, rectScroll,
		this, iVertScrollID))
	{
		TRACE (_T ("XMLEdView: Can't create vertical scroll bar!\n"));
		return -1;
	}
	
	if (!m_wndHorzScroll.Create(SBS_HORZ | WS_CHILD, rectScroll,
		this, iHorzScrollID))
	{
		TRACE (_T ("XMLEdView: Can't create horizontal scroll bar!\n"));
		return -1;
	}

	if (!m_wndBottomBar.Create(rectScroll, this, iBottomBarID))
	{
		TRACE (_T ("XMLEdView: Can't create bottombar!\n"));
		return -1;
	}

	if (!m_imgArt.Create(IDB_ART, 16, 0, clrTransparent))
	{
		TRACE (_T ("XMLEdView: Can't load imagelist!\n"));
		return -1;
	}

	//-----------------------
	// Count bottombar height
	//-----------------------
	
	CClientDC dc (this);
	CFont* pOldFont = (CFont*)dc.SelectStockObject(DEFAULT_GUI_FONT);

	TEXTMETRIC tm;
	dc.GetTextMetrics(&tm);

	m_iBarWidth = tm.tmHeight + 6;
	if (::GetSystemMetrics(SM_CYVSCROLL) > m_iBarWidth)
		m_iBarWidth = ::GetSystemMetrics(SM_CYVSCROLL);

	dc.SelectObject (pOldFont); 

	m_rectRulerBut.SetRect(0, 0, m_iBarWidth,
		m_iBarWidth);

//	GetLeftView()->ResetItems();

	return 0;
}

void CXMLEdView::OnFileOptions() 
{
	CFormOptDlg dlg;
	
	dlg.SetData(m_FormOpt);

	if (dlg.DoModal() == IDOK)
	{
		dlg.GetData(m_FormOpt);
		GetDocument()->SetTitle(m_FormOpt.strName + " \"" +
			m_FormOpt.strCaption + '"');
		ResizeControls();
	}
}

void CXMLEdView::DrawLeftRuler(CDC *dc, CRect *rect)
{
	CPen	penShadow(PS_SOLID, 1, clrShadow),
			penLight(PS_SOLID, 1, clrWhite),
			penRed(PS_SOLID, 1, clrRed),
			*penOld;

	m_imgArt.Draw(dc, 3, CPoint(m_rectLeftRuler.left,
		m_rectLeftRuler.top), ILD_NORMAL);
	m_imgArt.Draw(dc, 4, CPoint(m_rectLeftRuler.left,
		m_rectLeftRuler.bottom - 16), ILD_NORMAL);

	penOld = dc->SelectObject(&penLight);
	dc->MoveTo(m_rectLeftRuler.left, m_rectLeftRuler.top + 16);
	dc->LineTo(m_rectLeftRuler.left, m_rectLeftRuler.bottom - 16);

	dc->MoveTo(m_rectLeftRuler.left + 1, m_rectLeftRuler.top + 16);
	dc->LineTo(m_rectLeftRuler.left + 1, m_rectLeftRuler.bottom - 16);

	dc->MoveTo(m_rectLeftRuler.left + 16, m_rectLeftRuler.top);
	dc->LineTo(m_rectLeftRuler.right - 1, m_rectLeftRuler.top);

	dc->MoveTo(m_rectLeftRuler.left + 16, m_rectLeftRuler.top + 1);
	dc->LineTo(m_rectLeftRuler.right - 2, m_rectLeftRuler.top + 1);

	dc->SelectObject(penOld);
	dc->MoveTo(m_rectLeftRuler.right - 1, m_rectLeftRuler.top + 1);
	dc->LineTo(m_rectLeftRuler.right - 1, m_rectLeftRuler.bottom);

	dc->MoveTo(m_rectLeftRuler.right, m_rectLeftRuler.top);
	dc->LineTo(m_rectLeftRuler.right, m_rectLeftRuler.bottom);

	dc->MoveTo(m_rectLeftRuler.left + 16, m_rectLeftRuler.bottom - 2);
	dc->LineTo(m_rectLeftRuler.right - 2, m_rectLeftRuler.bottom - 2);

	dc->MoveTo(m_rectLeftRuler.left + 16, m_rectLeftRuler.bottom - 1);
	dc->LineTo(m_rectLeftRuler.right - 2, m_rectLeftRuler.bottom - 1);

	CRect rectText;
	CString str;
	int iNum = (m_wndVertScroll.GetScrollPos() - 1) * 2;
	for (int n = m_rectLeftRuler.top + 20; n < m_rectLeftRuler.bottom - 3; n += 19)
	{
		dc->SelectObject(penOld);
		dc->MoveTo(m_rectLeftRuler.right - 5, n);
		dc->LineTo(m_rectLeftRuler.right - 2, n);

		if (GetApp()->GetOpt()->bShowGrid)
		{
			dc->SelectObject(&penShadow);
			dc->MoveTo(m_rectLeftRuler.right + 1, n);
			dc->LineTo(rect->right -
			::GetSystemMetrics(SM_CXVSCROLL) - 3, n);
		}

		n++;

		dc->SelectObject(&penLight);
		dc->MoveTo(m_rectLeftRuler.right - 5, n);
		dc->LineTo(m_rectLeftRuler.right - 2, n);

		iNum += 2;
		if (GetApp()->GetOpt()->bShowNumbers)
		{
			str.Format("%d", iNum);
			rectText.SetRect(m_rectLeftRuler.left + 2, n + 1,
				m_rectLeftRuler.right - 2, n + 19);
			if (rectText.bottom < m_rectLeftRuler.bottom - 15)
				dc->DrawText(str, rectText, DT_CENTER |
					DT_TOP | DT_SINGLELINE);
		}
	}

	if (GetApp()->GetOpt()->bShowMousePos)
	{
		dc->SelectObject(&penRed);
		dc->MoveTo(m_rectLeftRuler.right - 2, m_pntMousePos.y);
		dc->LineTo(m_rectLeftRuler.left + 2, m_pntMousePos.y);
	}

	dc->SelectObject(penOld);
}

void CXMLEdView::DrawTopRuler(CDC *dc, CRect *rect)
{
	CPen	penShadow(PS_SOLID, 1, clrShadow),
			penLight(PS_SOLID, 1, clrWhite),
			penRed(PS_SOLID, 1, clrRed),
			*penOld;

	m_imgArt.Draw(dc, 1, CPoint(m_rectTopRuler.left,
		m_rectTopRuler.top), ILD_NORMAL);
	m_imgArt.Draw(dc, 2, CPoint(m_rectTopRuler.right - 16,
		m_rectTopRuler.top), ILD_NORMAL);

	penOld = dc->SelectObject(&penLight);
	dc->MoveTo(m_rectTopRuler.left + 16, m_rectTopRuler.top);
	dc->LineTo(m_rectTopRuler.right - 17, m_rectTopRuler.top);

	dc->MoveTo(m_rectTopRuler.left + 16, m_rectTopRuler.top + 1);
	dc->LineTo(m_rectTopRuler.right - 17, m_rectTopRuler.top + 1);

	dc->MoveTo(m_rectTopRuler.left, m_rectTopRuler.top + 16);
	dc->LineTo(m_rectTopRuler.left, m_rectTopRuler.bottom - 1);

	dc->MoveTo(m_rectTopRuler.left + 1, m_rectTopRuler.top + 16);
	dc->LineTo(m_rectTopRuler.left + 1, m_rectTopRuler.bottom - 2);

	dc->SelectObject(penOld);

	dc->MoveTo(m_rectTopRuler.left + 1, m_rectTopRuler.bottom - 1);
	dc->LineTo(m_rectTopRuler.right, m_rectTopRuler.bottom - 1);

	dc->MoveTo(m_rectTopRuler.left, m_rectTopRuler.bottom);
	dc->LineTo(m_rectTopRuler.right, m_rectTopRuler.bottom);

	dc->MoveTo(m_rectTopRuler.right - 2, m_rectTopRuler.top + 16);
	dc->LineTo(m_rectTopRuler.right - 2, m_rectTopRuler.bottom - 1);

	dc->MoveTo(m_rectTopRuler.right - 1, m_rectTopRuler.top + 16);
	dc->LineTo(m_rectTopRuler.right - 1, m_rectTopRuler.bottom - 1);

	CRect rectText;
	CString str;
	int iNum = (m_wndHorzScroll.GetScrollPos() - 1) * 2;
	for (int n = m_rectTopRuler.left + 20; n < m_rectTopRuler.right - 3; n += 19)
	{
		dc->SelectObject(penOld);
		dc->MoveTo(n, m_rectTopRuler.bottom - 5);
		dc->LineTo(n, m_rectTopRuler.bottom - 1);

		if (GetApp()->GetOpt()->bShowGrid)
		{
			dc->SelectObject(&penShadow);
			dc->MoveTo(n, m_rectTopRuler.bottom + 1);
			dc->LineTo(n, rect->bottom - 
				::GetSystemMetrics(SM_CYVSCROLL) - 3);
		}

		n++;
		
		dc->SelectObject(&penLight);
		dc->MoveTo(n, m_rectTopRuler.bottom - 5);
		dc->LineTo(n, m_rectTopRuler.bottom - 1);

		iNum += 2;
		if (GetApp()->GetOpt()->bShowNumbers)
		{
			str.Format("%d", iNum);
			rectText.SetRect(n + 1, m_rectTopRuler.top + 2,
				n + 19, m_rectTopRuler.bottom - 2);
			if (rectText.right < m_rectTopRuler.right - 15)
				dc->DrawText(str, rectText, DT_LEFT |
					DT_VCENTER | DT_SINGLELINE);
		}
	}
	
	if (GetApp()->GetOpt()->bShowMousePos)
	{
		dc->SelectObject(&penRed);
		dc->MoveTo(m_pntMousePos.x, m_rectTopRuler.bottom - 2);
		dc->LineTo(m_pntMousePos.x, m_rectTopRuler.top + 2);
	}
	
	dc->SelectObject(penOld);
}

void CXMLEdView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if (m_rectRulerBut.PtInRect(point))
	{
		OnFileOptions();
		return;
	}

	bool	bInRect = m_rectClient.PtInRect(point) != 0,
			bInShape = m_sTrackedShape != NULL,
			bShift = (nFlags & MK_SHIFT) != 0,
			bSelGroup = bInShape ? m_sTrackedShape->GetState() == SShape::stSelGroup : false;

	if (m_eState == stNormal && bInRect && !bInShape)
	{
		m_eState = stSelect;
		m_rectSelect.SetRect(point, point);
		return;
	}

	if (m_eState == stNormal && bInShape && !bShift && !bSelGroup)
	{
		if (m_sTrackedShape->GetState() == SShape::stSelected)
		{
			if (m_sTrackedShape->GetLocked()) return;

			CRect rectView, rectTrack;
			CPoint pntOfs;
			CountOfs(&pntOfs);

			BOOL bRet = FALSE;

			m_rectTracker.m_rect = m_sTrackedShape->GetRect() -
				pntOfs;
			bRet = m_rectTracker.Track(this, point);

			if (!bRet) return;

			rectView = m_rectTracker.m_rect & m_rectClient;
			if (!rectView.IsRectEmpty())
			{
				rectTrack = m_rectTracker.m_rect + pntOfs;
				SnapRect(&rectTrack, m_sTrackedShape->eSnap);

				if (m_sTrackedShape->eType == SShape::tEdit)
					rectTrack.bottom = rectTrack.top + m_iBarWidth;

				m_sTrackedShape->SetRect(rectTrack);

				if (GetApp()->GetOpt()->iIntersection)
					CheckIntersect(m_sTrackedShape);

				m_wndBottomBar.SetRect(&m_sTrackedShape->GetRect());
			}
		} else {
			RemoveSelection();
			m_sTrackedShape->SetState(bShift ? SShape::stSelGroup : 
				SShape::stSelected);

			m_listSelected.AddTail(m_sTrackedShape);

			m_wndBottomBar.SetRect(&m_sTrackedShape->GetRect());
			m_wndBottomBar.Enable(m_sTrackedShape->GetLocked(),
				m_sTrackedShape->eSnap);
		}

		UpdateLeftViewData(m_sTrackedShape);
		Invalidate(false);		
		UpdateWindow();
		return;
	}

	if (m_eState == stNormal && bInRect && bInShape && bShift)
	{
		SetResetSelection(m_sTrackedShape);
		return;
	}

	if (m_eState == stNormal && bSelGroup)
	{
		CPoint pntOfs;
		CountOfs(&pntOfs);
		CRect rectSelect, rectNew;
		CountDragRect(&rectSelect, &m_listSelected);

		m_rectTracker.m_rect = rectSelect - pntOfs;
		m_rectTracker.Track(this, point);
		rectNew = m_rectTracker.m_rect;

		SnapRect(&rectNew, GetApp()->GetOpt()->iSnapType);
		MoveSelection(&rectSelect.TopLeft(), &rectNew.TopLeft());

		Invalidate(false);		
		UpdateWindow();
		return;
	}

	if (m_eState == stLabel || m_eState == stEdit ||
		m_eState == stButton || m_eState == stTable &&
		bInRect)
	{
		m_sShape = new SShape;
		m_sShape->eSnap = (SShape::Snap)GetApp()->GetOpt()->iSnapType;
	
		switch (m_eState)
		{
		case stLabel:
			m_sShape->eType = SShape::tLabel;
			m_sShape->strName = "Label";
		break;

		case stEdit:
			m_sShape->eType = SShape::tEdit;
			m_sShape->strName = "Edit";
		break;

		case stButton:
			m_sShape->eType = SShape::tButton;
			m_sShape->strName = "Button";
		break;

		case stTable:
			m_sShape->eType = SShape::tTable;
			m_sShape->strName = "Table";
		break;
		}

		m_iShapeCounter++;
		CString str;
		str.Format(" %d", m_iShapeCounter);
		m_sShape->strName += str;
		m_sShape->iID = iBase + m_iShapeCounter;

		m_eState = stDraw;
		m_rectSelect.SetRect(point, point);

		return;
	}

	CView::OnLButtonDown(nFlags, point);
}

void CXMLEdView::OnMouseMove(UINT nFlags, CPoint point) 
{
	bool	bInRect = m_rectClient.PtInRect(point) != 0,
			bState = m_eState == stDraw || m_eState == stSelect,
			bRedraw = false;

	CRect rectNoMove = m_rectClient;
	rectNoMove.DeflateRect(m_iBarWidth, m_iBarWidth);
	
	CPoint pntOfs;
	CountOfs(&pntOfs);
	
	if (bState && bInRect)
	{
		m_rectSelect.right = point.x;
		m_rectSelect.bottom = point.y;

		m_wndBottomBar.SetRect(&m_rectSelect, &pntOfs);

		InvalidateRect(m_rectClient, false);
		bRedraw = true;
	}

	if (bState && !rectNoMove.PtInRect(point))
		if (!m_bIsTimerSet)
		{
			SetTimer(iMoveTimerID, iSlowTimerDuration, NULL);
			m_bIsTimerSet = true;
		}

	if (GetApp()->GetOpt()->bShowMousePos && bInRect)
	{
		m_pntMousePos = point;
		
//		CString strHint;
//		strHint.Format("%d, %d", point.x + pntOfs.x,
//			point.y + pntOfs.y);
//		SetPaneText(&strHint);
		
		InvalidateRect(m_rectLeftRuler, false);
		InvalidateRect(m_rectTopRuler, false);
		bRedraw = true;
	}

	if (m_eState == stNormal && bInRect)
	{
		HitTest(point);
	}

	if (bRedraw) UpdateWindow();

	CView::OnMouseMove(nFlags, point);
}

void CXMLEdView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	bool	bRedraw = false,
			bDraw = m_eState == stDraw;
	
	if (bDraw || m_eState == stSelect) 
	{
		CRect rectShape = *m_wndBottomBar.GetRect();
		if (bDraw)
		{
			SnapRect(&rectShape, m_sShape->eSnap);
			m_wndBottomBar.SetRect(&rectShape);

			if (m_sShape->eType == SShape::tEdit)
				rectShape.bottom = rectShape.top + m_iBarWidth;
			
			m_sShape->SetRect(rectShape);
			m_sShape->SetState(SShape::stSelected);

			if (GetApp()->GetOpt()->iIntersection)
				CheckIntersect(m_sShape);

			RemoveSelection();
			m_listShape.AddTail(m_sShape);
			m_listSelected.AddTail(m_sShape);

			UpdateLeftViewData(m_sShape);
			m_wndBottomBar.Enable(m_sShape->GetLocked(), m_sShape->eSnap);
		} else SelectRect(&rectShape);

		m_eState = stNormal;
		m_rectSelect.SetRect(0, 0, 0, 0);
		bRedraw = true;

		if (bDraw) if (GetApp()->GetOpt()->bStyleIDE)
			GetMainFrame()->ResetCtrlBar();
		else switch (m_sShape->eType)
		{
			case SShape::tLabel: m_eState = stLabel; break;
			case SShape::tEdit: m_eState = stEdit; break;
			case SShape::tButton: m_eState = stButton; break;
			case SShape::tTable: m_eState = stTable; break;
		}
	}

	if (bRedraw) 
	{
		InvalidateRect(m_rectClient, false);
		UpdateWindow();
	}

	CView::OnLButtonUp(nFlags, point);
}

int CXMLEdView::SnapInt(int iValue)
{
	int iMod = iValue % 20, iRet;

	if (iMod > 9) iRet = iValue + (20 - iMod);
	else iRet = iValue - iMod;

	if (iRet < 0) iRet = 0;

	return iRet;
}

void CXMLEdView::SnapRect(CRect *rect, int iSnapType)
{
	int iLen, iHgt;
	CPoint pntCenter;

	switch (iSnapType)
	{
	case 1: //Top-left
		iLen = rect->Width();
		iHgt = rect->Height();

		rect->top = SnapInt(rect->top);
		rect->left = SnapInt(rect->left);
		rect->right = rect->left + SnapInt(iLen) - 1;
		rect->bottom = rect->top + SnapInt(iHgt) - 1;
	break;

	case 2: //Center
		pntCenter = rect->CenterPoint();
		iLen = pntCenter.x - SnapInt(pntCenter.x);
		iHgt = pntCenter.y - SnapInt(pntCenter.y);

		rect->left -= iLen;
		rect->right -= iLen;
		rect->top -= iHgt;
		rect->bottom -= iHgt;
	break;
	}
}

CXMLEdApp* CXMLEdView::GetApp()
{
	return (CXMLEdApp*)AfxGetApp();
}

CMainFrame* CXMLEdView::GetMainFrame()
{
	CXMLEdApp *aApp = (CXMLEdApp*)::AfxGetApp();
	return (CMainFrame*)aApp->m_pMainWnd;
}

CLeftView* CXMLEdView::GetLeftView()
{
	CSplitterWnd* pParent = (CSplitterWnd*)GetParent();
	return (CLeftView*)pParent->GetPane(0, 0);
}

void CXMLEdView::SetPaneText(const CString* strText)
{
	CMainFrame* pFrame = (CMainFrame*)GetApp()->m_pMainWnd;
	pFrame->SetPaneText(strText);
}

void CXMLEdView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	if (Scroll(nSBCode, nPos, pScrollBar))
	{
		Invalidate(false);
		UpdateWindow();
	}

	CView::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CXMLEdView::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	if (Scroll(nSBCode, nPos, pScrollBar))
	{
		Invalidate(false);
		UpdateWindow();
	}

	CView::OnVScroll(nSBCode, nPos, pScrollBar);
}

bool CXMLEdView::Scroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	int iMinPos, iMaxPos;
	pScrollBar->GetScrollRange(&iMinPos, &iMaxPos); 

	int iCurPos = pScrollBar->GetScrollPos();
	bool bRet = false;

	switch (nSBCode)
	{
	case SB_LEFT: iCurPos = iMinPos; break;

	case SB_RIGHT: iCurPos = iMaxPos; break;

	case SB_ENDSCROLL: break;

	case SB_LINELEFT: case SB_PAGELEFT:
		if (iCurPos > iMinPos)
		{
			iCurPos--;
			bRet = true;
		}
	break;

	case SB_LINERIGHT: case SB_PAGERIGHT:
		if (iCurPos < iMaxPos)
		{
			iCurPos++;
			bRet = true;
		}
	break;

	case SB_THUMBPOSITION: iCurPos = nPos; bRet = true; break;

	case SB_THUMBTRACK: iCurPos = nPos; bRet = true; break;
	}

	pScrollBar->SetScrollPos(iCurPos);

	return bRet;
}

BOOL CXMLEdView::OnEraseBkgnd(CDC* pDC) 
{
	return true;
}

void CXMLEdView::OnInsertDraw() 
{
	m_eState = stNormal;
}

void CXMLEdView::OnInsertLabel() 
{
	m_eState = stLabel;
}

void CXMLEdView::OnInsertEdit() 
{
	m_eState = stEdit;
}

void CXMLEdView::OnInsertButton() 
{
	m_eState = stButton;
}

void CXMLEdView::OnInsertTable() 
{
	m_eState = stTable;
}

void CXMLEdView::CountOfs(CPoint *pntOfs)
{
	pntOfs->x = (m_wndHorzScroll.GetScrollPos() - 1) * 20 -
		m_iBarWidth;
	pntOfs->y = (m_wndVertScroll.GetScrollPos() - 1) * 20 -
		m_iBarWidth;
}

void CXMLEdView::OnTimer(UINT nIDEvent) 
{
	if (nIDEvent != iMoveTimerID) return;

	CRect rectNoMove = m_rectClient;
	rectNoMove.DeflateRect(m_iBarWidth, m_iBarWidth);
	
	KillTimer(iMoveTimerID);

	if (m_eState == stDraw || m_eState == stSelect &&
		!rectNoMove.PtInRect(m_pntMousePos))
	{
		int iPos = m_wndHorzScroll.GetScrollPos(),
			iMax, iMin, iOldPos = iPos, iChange;
		m_wndHorzScroll.GetScrollRange(&iMin, &iMax);

		if (m_pntMousePos.x < rectNoMove.left && iPos > iMin) iPos--;
		else if (m_pntMousePos.x > rectNoMove.right && iPos < iMax) iPos++;

		iChange = iPos - iOldPos;
		if (iChange)
		{
			m_wndHorzScroll.SetScrollPos(iPos, false);
			m_rectSelect.left -= 20 * iChange;
		}

		bool bRedraw = (iChange != 0);
				
		iPos = m_wndVertScroll.GetScrollPos();
		iOldPos = iPos;
		m_wndVertScroll.GetScrollRange(&iMin, &iMax);

		if (m_pntMousePos.y < rectNoMove.top && iPos > iMin) iPos--;
		else if (m_pntMousePos.y > rectNoMove.bottom && iPos < iMax) iPos++;

		iChange = iPos - iOldPos;
		if (iChange)
		{
			m_wndVertScroll.SetScrollPos(iPos, false);
			m_rectSelect.top -= 20 * iChange;
		}

		bRedraw = bRedraw || (iChange != 0);
				
		if (bRedraw)
		{
			CPoint pntOfs;
			CountOfs(&pntOfs);
			m_wndBottomBar.SetRect(&m_rectSelect, &pntOfs);

			Invalidate();
			UpdateWindow();
		}

		SetTimer(iMoveTimerID, iFastTimerDuration, NULL);
		return;
	} else m_bIsTimerSet = false;

	CView::OnTimer(nIDEvent);
}

bool CXMLEdView::CountVisiblePart(CRect *Line, CRect *Frame)
{
	if (!Frame->PtInRect(Line->TopLeft()) && 
		!Frame->PtInRect(Line->BottomRight()))
		return false;
	
	CRect rectNorm;

	rectNorm.top = min(Line->top, Line->bottom);
	rectNorm.bottom = max(Line->top, Line->bottom);
	rectNorm.left = min(Line->left, Line->right);
	rectNorm.right = max(Line->left, Line->right);

	if (rectNorm.top < Frame->top) rectNorm.top = Frame->top;
	if (rectNorm.left < Frame->left) rectNorm.left = Frame->left;
	if (rectNorm.right > Frame->right) rectNorm.right = Frame->right;
	if (rectNorm.bottom > Frame->bottom) rectNorm.bottom = Frame->bottom;

	*Line = rectNorm;

	return true;
}

void CXMLEdView::ResizeControls()
{
	CRect rectClient;
	GetClientRect(&rectClient);

	int iScrollX = ::GetSystemMetrics(SM_CXVSCROLL),
		iScrollY = ::GetSystemMetrics(SM_CYVSCROLL);

	m_rectLeftRuler.SetRect(0, m_iBarWidth, m_iBarWidth,
		rectClient.bottom - m_iBarWidth);

	m_rectTopRuler.SetRect(m_iBarWidth, 0, rectClient.right -
		::GetSystemMetrics(SM_CYVSCROLL), m_iBarWidth);

	m_rectClient.SetRect(m_iBarWidth + 1, m_iBarWidth + 1,
		rectClient.right - iScrollX - 1, rectClient.bottom -
		m_iBarWidth - 1);

	int iScrollMax = (m_FormOpt.iHeight - (rectClient.Height() -
		m_rectTopRuler.Height() - m_iBarWidth) / 10 - 6) / 2;

	m_wndVertScroll.SetWindowPos(NULL, rectClient.right - iScrollX,
		0, iScrollX, rectClient.bottom - m_iBarWidth, SWP_NOZORDER);

	if (iScrollMax > 0) 
	{		
		m_wndVertScroll.SetScrollRange(1, iScrollMax, false);
		m_wndVertScroll.EnableScrollBar();
	} else {
		m_wndVertScroll.SetScrollRange(1, 1, false);
		m_wndVertScroll.EnableScrollBar(ESB_DISABLE_BOTH);
	}

	m_wndVertScroll.ShowWindow(SW_SHOW);

	iScrollMax = (m_FormOpt.iWidth - (rectClient.Width() -
		m_rectLeftRuler.Width() - iScrollX) / 10 - 6) / 2;

	m_wndHorzScroll.SetWindowPos(NULL, iToolBarWidth,
		rectClient.bottom - m_iBarWidth, rectClient.right -
		iToolBarWidth -	iScrollY, iScrollY, SWP_NOZORDER);

	if (iScrollMax > 0) 
	{
		m_wndHorzScroll.SetScrollRange(1, iScrollMax, false);
		m_wndHorzScroll.EnableScrollBar();
	} else {
		m_wndHorzScroll.SetScrollRange(1, 1, false);
		m_wndHorzScroll.EnableScrollBar(ESB_DISABLE_BOTH);
	}

	m_wndHorzScroll.ShowWindow(SW_SHOW);

	m_wndBottomBar.SetWindowPos(NULL, 0, rectClient.bottom - 
		m_iBarWidth, iToolBarWidth, m_iBarWidth,
		SWP_NOZORDER);
	m_wndBottomBar.ShowWindow(SW_SHOW);
}

void CXMLEdView::DrawClientArea(CDC *pDC)
{
	POSITION pos = m_listShape.GetHeadPosition();
	int	iCount = m_listShape.GetCount(),
		iRectSize = GetApp()->GetOpt()->iRectSize;
	SShape *sShapeCur;
	CPoint pntOfs;
	CountOfs(&pntOfs);
	CRect rectView;

	for (int n = 0; n < iCount; n++)
	{
		sShapeCur = m_listShape.GetNext(pos);

		rectView = sShapeCur->GetRect();
		rectView -= pntOfs;
		rectView &= m_rectClient;

		if (pDC->RectVisible(rectView))
		{
			if (sShapeCur->GetState() == SShape::stSelected)
			{
				m_rectTracker.m_rect = rectView;
				m_rectTracker.m_nHandleSize = iRectSize;
				m_rectTracker.Draw(pDC);

				rectView.DeflateRect(iRectSize - 1, iRectSize - 1,
					iRectSize, iRectSize);
			} else if (sShapeCur->GetState() == SShape::stSelGroup)
			{
				pDC->Rectangle(rectView);
				rectView.DeflateRect(iRectSize - 1, iRectSize - 1,
					iRectSize, iRectSize);
			}

			switch (sShapeCur->eType)
			{
			case SShape::tLabel: 
				DrawLabel(pDC, &rectView, sShapeCur);
			break;

			case SShape::tEdit: 
				DrawEdit(pDC, &rectView, sShapeCur);
			break;

			case SShape::tButton: 
				DrawButton(pDC, &rectView, sShapeCur);
			break;

			case SShape::tTable: 
				DrawTable(pDC, &rectView, sShapeCur);
			break;

			default:
				COLORREF clrOld = pDC->SetBkColor(clrWhite);

				pDC->Rectangle(rectView);

				rectView.DeflateRect(2, 2);
				pDC->DrawText(sShapeCur->strName, rectView,
					sShapeCur->iAlig | DT_SINGLELINE);
			}
		}
	}
	
	pDC->SetBkColor(clrLight);
}

void CXMLEdView::DrawLabel(CDC *pDC, CRect *rect, SShape* sShape)
{
	pDC->FillSolidRect(rect, clrShadow);

	CRect rectText = *rect;

	if (sShape->GetBorder())
	{
		pDC->MoveTo(rectText.left, rectText.top);
		pDC->LineTo(rectText.right, rectText.top);
		pDC->LineTo(rectText.right, rectText.bottom);
		pDC->LineTo(rectText.left, rectText.bottom);
		pDC->LineTo(rectText.left, rectText.top);
	}

	rectText.DeflateRect(2, 2);	

	if (rectText.Height() > 40 && rectText.Width() > 20)
	{
		bool bBottomRight = sShape->iAlig & DT_BOTTOM && sShape->iAlig & DT_RIGHT;
		if (sShape->GetLocked() && !bBottomRight) m_imgArt.Draw(pDC, 5, rectText.BottomRight() -
			CSize(16, 16), ILD_NORMAL);
		
		bool bTopLeft = sShape->iAlig == 0;
		if (!bTopLeft) if (sShape->GetState() == SShape::stSelected) m_imgArt.Draw(pDC, 6,
			rectText.TopLeft(), ILD_NORMAL);
		else if (sShape->GetState() == SShape::stSelGroup) m_imgArt.Draw(pDC,
			7, rectText.TopLeft(), ILD_NORMAL);
	}

	pDC->DrawText(sShape->strName, rectText, sShape->iAlig | DT_SINGLELINE);
}

void CXMLEdView::DrawEdit(CDC *pDC, CRect *rect, SShape* sShape)
{
	pDC->FillSolidRect(rect, clrWhite);

	CRect rectText = *rect;

	rectText.DeflateRect(0, 0, -1, -1);

	if (sShape->GetBorder())
	{
		pDC->Draw3dRect(rectText, clrBlack, clrWhite);
		rectText.DeflateRect(1, 1);
		pDC->Draw3dRect(rectText, clrShadow, clrLight);
	}
	
	pDC->SetBkColor(clrWhite);
	rectText.DeflateRect(2, 2);

	if (rectText.Height() > 40 && rectText.Width() > 20)
	{
		bool bBottomRight = sShape->iAlig & DT_BOTTOM && sShape->iAlig & DT_RIGHT;
		if (sShape->GetLocked() && !bBottomRight) m_imgArt.Draw(pDC, 5, rectText.BottomRight() -
			CSize(16, 16), ILD_NORMAL);
		
		bool bTopLeft = sShape->iAlig == 0;
		if (!bTopLeft) if (sShape->GetState() == SShape::stSelected) m_imgArt.Draw(pDC, 6,
			rectText.TopLeft(), ILD_NORMAL);
		else if (sShape->GetState() == SShape::stSelGroup) m_imgArt.Draw(pDC,
			7, rectText.TopLeft(), ILD_NORMAL);
	}

	pDC->DrawText(sShape->strName, rectText, sShape->iAlig | DT_SINGLELINE);
}

void CXMLEdView::DrawButton(CDC *pDC, CRect *rect, SShape *sShape)
{
	pDC->FillSolidRect(rect, clrLight);

	CRect rectText = *rect;

	rectText.DeflateRect(0, 0, -1, -1);

	if (sShape->GetBorder())
	{
		pDC->Draw3dRect(rectText, clrWhite, clrBlack);
		rectText.DeflateRect(1, 1);
		pDC->Draw3dRect(rectText, clrWhite, clrBlack);
	}
	
	pDC->SetBkColor(clrLight);
	rectText.DeflateRect(2, 2);

	if (rectText.Height() > 40 && rectText.Width() > 20)
	{
		bool bBottomRight = sShape->iAlig & DT_BOTTOM && sShape->iAlig & DT_RIGHT;
		if (sShape->GetLocked() && !bBottomRight) m_imgArt.Draw(pDC, 5, rectText.BottomRight() -
			CSize(16, 16), ILD_NORMAL);
		
		bool bTopLeft = sShape->iAlig == 0;
		if (!bTopLeft) if (sShape->GetState() == SShape::stSelected) m_imgArt.Draw(pDC, 6,
			rectText.TopLeft(), ILD_NORMAL);
		else if (sShape->GetState() == SShape::stSelGroup) m_imgArt.Draw(pDC,
			7, rectText.TopLeft(), ILD_NORMAL);
	}

	pDC->DrawText(sShape->strName, rectText, sShape->iAlig | DT_SINGLELINE);
}

void CXMLEdView::DrawTable(CDC *pDC, CRect *rect, SShape *sShape)
{
	pDC->FillSolidRect(rect, clrWhite);

	CRect rectText = *rect;

	if (sShape->GetBorder())
	{
		pDC->MoveTo(rectText.left, rectText.top);
		pDC->LineTo(rectText.right, rectText.top);
		pDC->LineTo(rectText.right, rectText.bottom);
		pDC->LineTo(rectText.left, rectText.bottom);
		pDC->LineTo(rectText.left, rectText.top);
	}
	
	int iCenterX = rectText.left + rectText.Width() / 2,
		iCenterY = rectText.top + rectText.Height() / 2;

	pDC->MoveTo(iCenterX, rectText.top + 1);
	pDC->LineTo(iCenterX, rectText.bottom - 1);

	pDC->MoveTo(rectText.left + 1, iCenterY);
	pDC->LineTo(rectText.right - 1, iCenterY);

	pDC->SetBkColor(clrWhite);
	rectText.DeflateRect(2, 2);

	if (rectText.Height() > 40 && rectText.Width() > 20)
	{
		bool bBottomRight = sShape->iAlig & DT_BOTTOM && sShape->iAlig & DT_RIGHT;
		if (sShape->GetLocked() && !bBottomRight) m_imgArt.Draw(pDC, 5, rectText.BottomRight() -
			CSize(16, 16), ILD_NORMAL);
		
		bool bTopLeft = sShape->iAlig == 0;
		if (!bTopLeft) if (sShape->GetState() == SShape::stSelected) m_imgArt.Draw(pDC, 6,
			rectText.TopLeft(), ILD_NORMAL);
		else if (sShape->GetState() == SShape::stSelGroup) m_imgArt.Draw(pDC,
			7, rectText.TopLeft(), ILD_NORMAL);
	}

	pDC->DrawText(sShape->strName, rectText, sShape->iAlig | DT_SINGLELINE);
}

bool CXMLEdView::CheckIntersect(SShape *sShape)
{
	POSITION pos = m_listShape.GetHeadPosition();
	int iCount = m_listShape.GetCount();
	SShape *sShapeCur;
	CRect rectIntersect;

	for (int n = 0; n < iCount; n++)
	{
		sShapeCur = m_listShape.GetNext(pos);

		if (sShapeCur->iID != sShape->iID)
		{
			rectIntersect.IntersectRect(sShapeCur->GetRect(), sShape->GetRect());
			if (!rectIntersect.IsRectEmpty())
			{
				if (GetApp()->GetOpt()->iIntersection == 1)
				{
					MessageBox("Intersection of \"" + sShape->strName +
						"\" and \"" + sShapeCur->strName + "\" found!",
						"Warning", MB_OK | MB_ICONWARNING);
					return true;
				}

				if (rectIntersect == sShapeCur->GetRect())
					Intersect(&sShape->GetRect(), &rectIntersect);
				else Intersect(&sShapeCur->GetRect(), &rectIntersect);
			}
		}
	}

	return false;
}

void CXMLEdView::Intersect(CRect *rect, CRect *rectInters)
{
	CRect rectTop;
	if (rect->top != rectInters->top)
		rectTop.SetRect(rect->left, rect->top, rect->right,
			rectInters->top - 1);
	else rectTop.SetRectEmpty();

	CRect rectBot;
	if (rect->bottom != rectInters->bottom)
		rectBot.SetRect(rect->left, rectInters->bottom + 1, rect->right,
			rect->bottom);
	else rectBot.SetRectEmpty();

	CRect rectLeft;
	if (rect->left != rectInters->left)
		rectLeft.SetRect(rect->left, rect->top, rectInters->left - 1,
			rect->bottom);
	else rectLeft.SetRectEmpty();

	CRect rectRight;
	if (rect->right != rectInters->right)
		rectRight.SetRect(rectInters->right + 1, rect->top, rect->right,
			rect->bottom);
	else rectRight.SetRectEmpty();

	int iSizeTop = rectTop.Width() * rectTop.Height(),
		iSizeBot = rectBot.Width() * rectBot.Height(),
		iSizeLeft = rectLeft.Width() * rectLeft.Height(),
		iSizeRight = rectRight.Width() * rectRight.Height();

	if (iSizeTop >= iSizeBot && iSizeTop >= iSizeLeft && iSizeTop >= iSizeRight)
		*rect = rectTop;
	else if (iSizeBot >= iSizeTop && iSizeBot >= iSizeLeft && 
		iSizeBot >= iSizeRight) *rect = rectBot;
		else if (iSizeLeft >= iSizeTop && iSizeLeft >= iSizeBot &&
			iSizeLeft >= iSizeRight) *rect = rectLeft;
			else *rect = rectRight;

	if (rect->IsRectEmpty())
	{
		rect->bottom = rect->top + 20;
		rect->right = rect->left + 20;

		MessageBox("Inetrsection can not be removed manualy", "Warning", MB_OK |
			MB_ICONWARNING);
	}
}

BOOL CXMLEdView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	if (m_sTrackedShape)
		if (pWnd == this && m_sTrackedShape->GetState() == SShape::stSelected)
			return m_rectTracker.SetCursor(pWnd, nHitTest);;

	return CView::OnSetCursor(pWnd, nHitTest, message);
}

void CXMLEdView::HitTest(CPoint pntMousePos)
{
	CPoint pntOfs;
	CountOfs(&pntOfs);
	CRect rectShape;

	if (m_sTrackedShape) 
	{
		rectShape = m_sTrackedShape->GetRect() - pntOfs;
		if (rectShape.PtInRect(pntMousePos))
			return;
	}

	POSITION pos = m_listShape.GetHeadPosition();
	int iCount = m_listShape.GetCount();
	int iShapeID = m_sTrackedShape ? m_sTrackedShape->iID : 0;
	SShape *sShapeCur;

	if (iCount)	for (int n = 0; n < iCount; n++)
	{
		sShapeCur = m_listShape.GetNext(pos);

		if (sShapeCur->iID != iShapeID)
		{
			rectShape = sShapeCur->GetRect();
			rectShape -= pntOfs;
			rectShape &= m_rectClient;

			if (rectShape.PtInRect(pntMousePos))
			{
				m_sTrackedShape = sShapeCur;
				SetPaneText(&sShapeCur->strName);
				return;
			}
		}
	}

	m_sTrackedShape = NULL;
	SetPaneText(&CString("No shape"));
}

void CXMLEdView::RemoveSelection()
{
	POSITION pos = m_listShape.GetHeadPosition();
	int iCount = m_listShape.GetCount();
	int iShapeID = m_sTrackedShape ? m_sTrackedShape->iID : 0;
	SShape *sShapeCur;
	bool bRet = false;

	if (iCount)	for (int n = 0; n < iCount; n++)
	{
		sShapeCur = m_listShape.GetNext(pos);

		if (sShapeCur->iID != iShapeID)
		{
			if (sShapeCur->GetState() == SShape::stSelected)
				bRet = true;

			sShapeCur->SetState(SShape::stNormal);

			if (bRet) break;
		}
	}

	m_listSelected.RemoveAll();
	m_wndBottomBar.Disable();
}

void CXMLEdView::OnBottomBarChanged(bool bLocked, bool bInsp, int iSnapType)
{
	POSITION pos = m_listSelected.GetHeadPosition();
	int iCount = m_listSelected.GetCount();
	SShape *sShapeCur;

	if (iCount)	for (int n = 0; n < iCount; n++)
	{
		sShapeCur = m_listSelected.GetNext(pos);
		sShapeCur->SetLocked(bLocked);
		sShapeCur->eSnap = (SShape::Snap)iSnapType;
	}

	if (iCount == 1)
		UpdateLeftViewData(m_listSelected.GetHead());

	if (bInsp) GetLeftView()->SetWidth(10);
	else GetLeftView()->SetWidth(GetApp()->GetOpt()->iLeftSize);

	Invalidate(false);
	UpdateWindow();
}

void CXMLEdView::OnLockAll() 
{
	POSITION pos = m_listShape.GetHeadPosition();
	int iCount = m_listShape.GetCount();
	SShape *sShapeCur;

	if (iCount)	for (int n = 0; n < iCount; n++)
	{
		sShapeCur = m_listShape.GetNext(pos);
		sShapeCur->SetLocked(true);
	}

	Invalidate(false);
	UpdateWindow();
}

void CXMLEdView::OnUnlockAll() 
{
	POSITION pos = m_listShape.GetHeadPosition();
	int iCount = m_listShape.GetCount();
	SShape *sShapeCur;

	if (iCount)	for (int n = 0; n < iCount; n++)
	{
		sShapeCur = m_listShape.GetNext(pos);
		sShapeCur->SetLocked(false);
	}

	Invalidate(false);
	UpdateWindow();
}

void CXMLEdView::OnDestroy() 
{
	CView::OnDestroy();
	DeleteAll();	
}

void CXMLEdView::OnKeyDelete() 
{
	POSITION pos = m_listSelected.GetHeadPosition();
	SShape *sShapeCur;

	while (pos)
	{
		sShapeCur = m_listSelected.GetNext(pos);
		DeleteShape(sShapeCur->iID);
	}

	m_listSelected.RemoveAll();

	Invalidate(false);
	UpdateWindow();
}

void CXMLEdView::DeleteShape(int iID)
{
	POSITION pos = m_listShape.GetHeadPosition(), posPrev;
	SShape *sShapeCur;

	while (pos)
	{
		posPrev = pos;
		sShapeCur = m_listShape.GetNext(pos);

		if (sShapeCur->iID == iID)
		{
			delete sShapeCur;
			m_listShape.RemoveAt(posPrev);
			break;
		}
	}
}

void CXMLEdView::DeleteAll()
{
	POSITION pos = m_listShape.GetHeadPosition(), posPrev;
	SShape *sShapeCur;

	while (pos)
	{
		posPrev = pos;
		sShapeCur = m_listShape.GetNext(pos);
		delete sShapeCur;
	}

	m_listShape.RemoveAll();
	m_listSelected.RemoveAll();
	m_iShapeCounter = 0;
}

void CXMLEdView::SelectRect(CRect *rect)
{
	RemoveSelection();

	POSITION pos = m_listShape.GetHeadPosition(), posPrev;
	SShape *sShapeCur;
	CRect rectIntersect;
	bool bReset = true;

	while (pos)
	{
		posPrev = pos;
		sShapeCur = m_listShape.GetNext(pos);
		rectIntersect = *rect & sShapeCur->GetRect();

		if (bReset) 
		{
			m_sSelData = *sShapeCur;
			bReset = false;
		} else m_sSelData += *sShapeCur;
		
		if (rectIntersect.Width() > 20 ||
			rectIntersect.Height() > 20)
		{
			sShapeCur->SetState(SShape::stSelGroup);
			m_listSelected.AddTail(sShapeCur);
		}
	}

	if (CheckSelGroup()) UpdateLeftViewData(&m_sSelData);

	Invalidate(false);
	UpdateWindow();
}

void CXMLEdView::OnSelectAll() 
{
	RemoveSelection();

	POSITION pos = m_listShape.GetHeadPosition();
	SShape *sShapeCur;
	CRect rectIntersect;

	while (pos)
	{
		sShapeCur = m_listShape.GetNext(pos);
		
		sShapeCur->SetState(SShape::stSelGroup);
		m_listSelected.AddTail(sShapeCur);
	}

	CheckSelGroup();

	Invalidate(false);
	UpdateWindow();
}

void CXMLEdView::SetResetSelection(SShape* sShape)
{
	POSITION pos = m_listSelected.GetHeadPosition(), posPrev;
	SShape *sShapeCur;
	int iID = sShape->iID;
	bool bReset = false;

	while (pos)
	{
		posPrev = pos;
		sShapeCur = m_listShape.GetNext(pos);

		if (sShapeCur->iID == iID)
		{
			if (sShapeCur->GetState() == SShape::stSelGroup)
			{
				sShapeCur->SetState(SShape::stNormal);
				m_listSelected.RemoveAt(posPrev);
			}

			bReset = true;
			break;
		}
	}

	if (!bReset)
	{
		if (m_listSelected.GetCount() == 1)
		{
			sShapeCur = m_listSelected.GetHead();
			sShapeCur->SetState(SShape::stSelGroup);
		}

		pos = m_listShape.GetHeadPosition();

		while(pos)
		{
			sShapeCur = m_listShape.GetNext(pos);

			if (sShapeCur->iID == iID)
			{
				sShapeCur->SetState(SShape::stSelGroup);
				m_listSelected.AddTail(sShapeCur);
				break;
			}
		}
	}

	if (CheckSelGroup()) m_sSelData += *sShapeCur;
	else m_sSelData = *sShapeCur;
	UpdateLeftViewData(&m_sSelData);

	Invalidate(false);
	UpdateWindow();
}

bool CXMLEdView::CheckSelGroup()
{
	SShape *sShape;

	if (m_listSelected.GetCount() != 1) return true;

	sShape = m_listSelected.GetHead();
	sShape->SetState(SShape::stSelected);

	m_wndBottomBar.SetRect(&sShape->GetRect());
	m_wndBottomBar.Enable(sShape->GetLocked(), sShape->eSnap);
	return false;
}

void CXMLEdView::CountDragRect(CRect *rect, ShapeList* list)
{
	POSITION pos = list->GetHeadPosition();
	SShape *sShapeCur;
	CRect rectCur;

	if (!pos) 
	{
		rect->SetRectEmpty();
		return;
	}

	sShapeCur = list->GetNext(pos);
	*rect = sShapeCur->GetRect();

	while (pos)
	{
		sShapeCur = list->GetNext(pos);
		rectCur = sShapeCur->GetRect();

		if (rectCur.left < rect->left) rect->left = rectCur.left;
		if (rectCur.top < rect->top) rect->top = rectCur.top;
		if (rectCur.right > rect->right) rect->right = rectCur.right;
		if (rectCur.bottom > rect->bottom) rect->bottom = rectCur.bottom;
	}
}

void CXMLEdView::MoveSelection(CPoint *pntFrom, CPoint *pntTo)
// *** From - Global; To - Local ***
{
	POSITION pos = m_listSelected.GetHeadPosition();
	SShape *sShapeCur;
	CRect rectCur;
	CPoint pntOfs;
	CountOfs(&pntOfs);

	while (pos)
	{
		sShapeCur = m_listSelected.GetNext(pos);
		rectCur = sShapeCur->GetRect();
		rectCur += pntOfs + *pntTo - *pntFrom;
		sShapeCur->SetRect(rectCur);
		if (GetApp()->GetOpt()->iIntersection)
			CheckIntersect(sShapeCur);
	}
}
/*
void CXMLEdView::OnEditCopy() 
{
	SetPaneText(&CString("Copy operation in progress..."));

	ShapeList *listBufer = GetApp()->GetBufer();
	GetApp()->ClearBufer();

	POSITION pos = m_listSelected.GetHeadPosition();
	SShape *sShapeCur, *sShapeBufer;

	while (pos)
	{
		sShapeCur = m_listSelected.GetNext(pos);
		sShapeBufer = new SShape(*sShapeCur);
		listBufer->AddTail(sShapeBufer);
	}

	SetPaneText(&CString("Redy"));
}

void CXMLEdView::OnEditPaste() 
{
	if (GetApp()->GetOpt()->bDeleteOnIns) OnKeyDelete();
	else RemoveSelection();

	ShapeList *listBufer = GetApp()->GetBufer();
	POSITION pos = listBufer->GetHeadPosition();
	SShape *sShapeCur;
	CPoint	pntCenter = m_rectClient.CenterPoint(),
			pntOfs, pntOfsInsert;
	CountOfs(&pntOfs);
	CRect rectShapeCur, rectSeletcion;
	CountDragRect(&rectSeletcion, listBufer);

	while (pos)
	{
		sShapeCur = listBufer->GetNext(pos);

		m_iShapeCounter++;
		sShapeCur->iID = m_iShapeCounter;

		rectShapeCur = sShapeCur->GetRect();
		pntOfsInsert = rectSeletcion.CenterPoint() -
			rectShapeCur.TopLeft();	
		rectShapeCur -= rectShapeCur.TopLeft();
		rectShapeCur += pntOfs + pntCenter + pntOfsInsert;
		sShapeCur->SetRect(rectShapeCur);

		sShapeCur->SetState(SShape::stNormal);

		m_listShape.AddTail(sShapeCur);
		if (GetApp()->GetOpt()->iIntersection)
			CheckIntersect(sShapeCur);
	}

	Invalidate(false);
	UpdateWindow();
}

void CXMLEdView::OnEditCut() 
{
	ShapeList *listBufer = GetApp()->GetBufer();
	GetApp()->ClearBufer();

	POSITION pos = m_listSelected.GetHeadPosition();
	SShape *sShapeCur, *sShapeBufer;

	while (pos)
	{
		sShapeCur = m_listSelected.GetNext(pos);
		sShapeBufer = new SShape(*sShapeCur);
		listBufer->AddTail(sShapeBufer);
		DeleteShape(sShapeCur->iID);
	}

	m_listSelected.RemoveAll();

	Invalidate(false);
	UpdateWindow();
}
*/
void CXMLEdView::UpdateLeftViewData(SShape *sShape)
{
	CLeftView* pLeftView = GetLeftView();
	*pLeftView->GetDataPtr() = *sShape;
	pLeftView->UpdateData();
}

void CXMLEdView::UpdateShapeData(SPropData *sData)
{
	if (m_listSelected.GetCount() == 1)
	{
		SShape* sShape = m_listSelected.GetHead();
		*sShape = *sData;

		m_wndBottomBar.Enable(sShape->GetLocked(), sShape->eSnap);
	} else {
		POSITION pos = m_listSelected.GetHeadPosition();
		SShape *sShapeCur;
	
		while (pos)
		{
			sShapeCur = m_listSelected.GetNext(pos);
			*sShapeCur = *sData;
		}
	}

	Invalidate();
	UpdateWindow();
}

void CXMLEdView::OnFormatInters() 
{
	POSITION pos = m_listShape.GetHeadPosition();
	SShape *sShapeCur;
	int iOldStyle = GetApp()->GetOpt()->iIntersection;
	GetApp()->GetOpt()->iIntersection = 1;

	while (pos)
	{
		sShapeCur = m_listSelected.GetNext(pos);
		if (CheckIntersect(sShapeCur)) 
		{
			GetApp()->GetOpt()->iIntersection = iOldStyle;
			return;
		}
	}

	GetApp()->GetOpt()->iIntersection = iOldStyle;
	Invalidate();
	UpdateWindow();
	MessageBox("Intersecttions not found!", "Check Intersections",
		MB_OK | MB_ICONINFORMATION);
}

void CXMLEdView::OnFileSave() 
{
	CString strPath = GetDocument()->GetPathName();
	switch (GetDocument()->GetFType())
	{
	case CXMLEdDoc::ftXML: SaveXML(&strPath); break;
	case CXMLEdDoc::ftHTML: SaveHTML(&strPath); break;
	default: OnFileSaveAs();
	}
}

void CXMLEdView::SaveHTML(const CString *strPath)
{
	FILE *pFile;
	pFile = fopen(*strPath, "w");
	if (!pFile) return;
	
	const int cx = m_FormOpt.iWidth,
			  cy = m_FormOpt.iHeight;
	SSaveItem *pSaveData = new SSaveItem[cy * cx];
	CreateSaveData(pSaveData, cy, cx);

	fprintf(pFile, "<HTML>\n<HEAD>\n<TITLE>%s</TITLE>\n</HEAD>\n<BODY>\n",
		m_FormOpt.strCaption);
	fprintf(pFile, "<LINK REV=\"made\" HREF=\"mailto:kolam@uic.tula.ru\">\n\n");

	CString strFormat(""), strPrint;;
	if (GetApp()->GetOpt()->bHTMLGrid) strFormat = " BORDER=\"1\"";
	fprintf(pFile, "<TABLE%s>\n<CAPTION>%s</CAPTION>\n\n",
		strFormat, m_FormOpt.strCaption);

	for (int n=0; n < cy; n++)
	{
		fprintf(pFile, "<TR>\n");

		for (int m = 0; m < cx; m++)
		{
			bool bVisible = pSaveData->eState != SSaveItem::stInvisible;

			if (pSaveData->eState == SSaveItem::stHerder)
			{
				SShape *pShape = pSaveData->pLink;
				strPrint = "\t<TD";

				if (pSaveData->iColSpan > 1)
				{
					strFormat.Format(" COLSPAN=\"%d\"", pSaveData->iColSpan);
					strPrint += strFormat;
				}

				if (pSaveData->iRowSpan > 1)
				{
					strFormat.Format(" ROWSPAN=\"%d\"", pSaveData->iRowSpan);
					strPrint += strFormat;
				}

				if (pShape->iAlig & DT_CENTER) strPrint += " ALIGN=\"CENTER\"";
				else if (pShape->iAlig & DT_RIGHT) strPrint += " ALIGN=\"RIGHT\"";

				if (!(pShape->iAlig & DT_VCENTER)) 
					if (pShape->iAlig & DT_BOTTOM)
					strPrint += " VALIGN=\"BOTTOM\"";
				else strPrint += " VALIGN=\"TOP\"";

				strPrint += '>';
				fprintf(pFile, strPrint);

				switch (pShape->eType)
				{
				case SShape::tEdit:
					fprintf(pFile, "<INPUT NAME=\"%d\" VALUE=\"%s\" SIZE=\"%d\">",
						pShape->iID, pShape->strName, 3 * pSaveData->iColSpan);
				break;

				case SShape::tButton:
					fprintf(pFile, "<INPUT TYPE=\"BUTTON\" NAME=\"%d\" VALUE=\"%s\">",
						pShape->iID, pShape->strName);
				break;

				default: fprintf(pFile, "%s", pShape->strName);
				}
			} else if (bVisible) fprintf(pFile, "   <TD>&nbsp");
			pSaveData++;

			if (bVisible) fprintf(pFile, "</TD>\n");
		}

		fprintf(pFile, "</TR>\n\n");
	}

	fprintf(pFile, "</TABLE>\n");

	fprintf(pFile, "</BODY>\n</HTML>\n");

	fclose(pFile);
}

void CXMLEdView::OnFileSaveAs() 
{
	CString strMask;
	strMask.LoadString(IDS_SAVE_MASK);
	CFileDialog dlg(false, "xml", m_FormOpt.strName,
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, strMask);

	if (dlg.DoModal() == IDOK) 
	{
		strMask = dlg.GetFileExt();
		strMask.MakeLower();
		if (strMask == "html" || strMask == "htm")
		{
			SaveHTML(&dlg.GetPathName());
			GetDocument()->SetFType(CXMLEdDoc::ftHTML);
		} else {
			SaveXML(&dlg.GetPathName());
			GetDocument()->SetFType(CXMLEdDoc::ftXML);
		}
		GetDocument()->SetPathName(dlg.GetPathName());
	}
}

void CXMLEdView::CreateSaveData(SSaveItem *pArray, int cy, int cx)
{
	POSITION pos = m_listShape.GetHeadPosition();
	SShape *sShapeCur;
	CRect rectShape;
	int iLength = cx * cy;
	
	while (pos)
	{
		sShapeCur = m_listShape.GetNext(pos);
		rectShape = sShapeCur->GetRect();

		int iOfs = rectShape.left / 20 + cx * rectShape.top / 20;
		if (iOfs >= iLength) continue;
		SSaveItem *pCur = pArray + iOfs;

		pCur->iColSpan = (rectShape.Width() + 1) / 20;
		if (!pCur->iColSpan) pCur->iColSpan = 1;
		pCur->iRowSpan = (rectShape.Height() + 1) / 20;
		if (!pCur->iRowSpan) pCur->iRowSpan = 1;

		for (int n = 0; n < pCur->iRowSpan; n++)
		{
			int iOfsCur = iOfs + n * cx;
			if (iOfsCur >= iLength) continue;
			SSaveItem *pItemCur = pArray + iOfsCur;

			for (int m = 0; m < pCur->iColSpan; m++)
			{
				pItemCur->eState = SSaveItem::stInvisible;
				pItemCur++;
			}
		}

		pCur->eState = SSaveItem::stHerder;
		pCur->pLink = sShapeCur;
	}

}

void CXMLEdView::SaveXML(CString *strPath)
{
	xmlDocPtr xmlDoc = xmlNewDoc((xmlChar*)"1.0");
	if (!xmlDoc) return;
	xmlDoc->charset = 1;

	xmlNodePtr xmlNode;
	char strDat[8];

	xmlNode = xmlDoc->children = xmlNewDocNode(xmlDoc, 0, (xmlChar*)"FORM", 0);
	xmlSetProp(xmlNode, (xmlChar*)"Name", (xmlChar*)(LPCSTR)m_FormOpt.strName);
	xmlSetProp(xmlNode, (xmlChar*)"Caption", (xmlChar*)(LPCSTR)m_FormOpt.strCaption);
	itoa(m_listShape.GetCount(), strDat, 8);
	xmlSetProp(xmlNode, (xmlChar*)"Objects", (xmlChar*)strDat);

	POSITION pos = m_listShape.GetHeadPosition();
	SShape *sShapeCur;
	xmlNodePtr xmlPrev = xmlNode;
	bool bAddChild = true;
	
	while (pos)
	{
		sShapeCur = m_listShape.GetNext(pos);

		switch (sShapeCur->eType)
		{
		case SShape::tLabel: strcpy(strDat, "LABEL"); break;
		case SShape::tEdit: strcpy(strDat, "EDIT"); break;
		case SShape::tButton: strcpy(strDat, "BUTTON"); break;
		case SShape::tTable: strcpy(strDat, "TABLE"); break;
		default: strcpy(strDat, "SHAPE"); break;
		}

		xmlNode = xmlNewNode(0, (xmlChar*)strDat);
		xmlNodeSetContent(xmlNode, (xmlChar*)(LPCSTR)sShapeCur->strName);
		
		itoa(sShapeCur->GetBorder(), strDat, 8);
		xmlSetProp(xmlNode, (xmlChar*)"Br", (xmlChar*)strDat);
		itoa(sShapeCur->iAlig, strDat, 8);
		xmlSetProp(xmlNode, (xmlChar*)"Al", (xmlChar*)strDat);

		CRect rectShape = sShapeCur->GetRect();
		itoa(rectShape.left, strDat, 10);
		xmlSetProp(xmlNode, (xmlChar*)"Left", (xmlChar*)strDat);
		itoa(rectShape.top, strDat, 10);
		xmlSetProp(xmlNode, (xmlChar*)"Top", (xmlChar*)strDat);
		itoa(rectShape.Width() + 1, strDat, 10);
		xmlSetProp(xmlNode, (xmlChar*)"Width", (xmlChar*)strDat);
		itoa(rectShape.Height() + 1, strDat, 10);
		xmlSetProp(xmlNode, (xmlChar*)"Height", (xmlChar*)strDat);

		if (bAddChild)
		{
			xmlPrev = xmlAddChild(xmlPrev, xmlNode);
			bAddChild = false;
		} else xmlPrev = xmlAddSibling(xmlPrev, xmlNode);
	}

	if (xmlSaveFile(*strPath, xmlDoc) == -1) return;
	xmlFreeDoc(xmlDoc);
}

void CXMLEdView::OnFileOpen() 
{
	CString strMask;
	strMask.LoadString(IDS_LOAD_MASK);
	CFileDialog dlg(true, "xml", NULL, OFN_HIDEREADONLY |
		OFN_OVERWRITEPROMPT, strMask);

	if (dlg.DoModal() == IDOK) 
	{
		DeleteAll();
		LoadXML(&dlg.GetPathName());

		GetDocument()->SetFType(CXMLEdDoc::ftXML);
		GetDocument()->SetPathName(dlg.GetPathName());
		GetDocument()->SetTitle(m_FormOpt.strName + " \"" +
			m_FormOpt.strCaption + '"');
		ResizeControls();

		Invalidate();
		UpdateWindow();
		if (GetApp()->GetOpt()->bShowFProp) OnFileOptions();
	}
}

void CXMLEdView::LoadXML(CString *strPath)
{
	xmlDocPtr xmlDoc;
	SShape *pNewShape = NULL;
	int iMaxHgt = 0, iMaxLen = 0;

	try 
	{
		xmlDoc = xmlParseFile(*strPath);
		if (!xmlDoc) throw 0;

		xmlNodePtr xmlNode = xmlDocGetRootElement(xmlDoc);
		if (!xmlNode) throw 1;

		if (xmlStrcmp(xmlNode->name, (xmlChar*)"FORM"))
			throw 1;

		xmlAttrPtr xmlAttr = xmlHasProp(xmlNode, (xmlChar*)"Name");
		if (xmlAttr) m_FormOpt.strName =
			xmlGetProp(xmlNode, (xmlChar*)"Name");
		else m_FormOpt.strName = "Form #";

		xmlAttr = xmlHasProp(xmlNode, (xmlChar*)"Caption");
		if (xmlAttr) m_FormOpt.strCaption =
			xmlGetProp(xmlNode, (xmlChar*)"Caption");
		else m_FormOpt.strName = "";

		int iCount = 0;
		xmlAttr = xmlHasProp(xmlNode, (xmlChar*)"Objects");
		if (xmlAttr) iCount = atoi((char*)xmlGetProp(xmlNode,
			(xmlChar*)"Objects"));

		if (iCount)
		{
			xmlNode = xmlNode->xmlChildrenNode;
			if (!xmlNode) throw 1;

			for (; xmlNode; xmlNode = xmlNode->next)
			{
				if (!xmlStrcmp(xmlNode->name, (xmlChar*)"text")) continue;

				pNewShape = new SShape;
				m_iShapeCounter++;
				pNewShape->iID = iBase + m_iShapeCounter;
				pNewShape->eSnap = (SShape::Snap)GetApp()->GetOpt()->iSnapType;
				pNewShape->strName = xmlNodeGetContent(xmlNode);

				if (!xmlStrcmp(xmlNode->name, (xmlChar*)"LABEL"))
					pNewShape->eType = SShape::tLabel;
				else if (!xmlStrcmp(xmlNode->name, (xmlChar*)"EDIT"))
					pNewShape->eType = SShape::tEdit;
					else if (!xmlStrcmp(xmlNode->name, (xmlChar*)"BUTTON"))
						pNewShape->eType = SShape::tButton;
						else if (!xmlStrcmp(xmlNode->name, (xmlChar*)"TABLE"))
							pNewShape->eType = SShape::tTable;
							else throw 1;

				CRect rectShape;
				xmlAttrPtr attr = xmlHasProp(xmlNode, (xmlChar*)"Left");
				if (attr) rectShape.left = atoi((char*)xmlGetProp(xmlNode,
					(xmlChar*)"Left"));
				else throw 1;
				attr = xmlHasProp(xmlNode, (xmlChar*)"Top");
				if (attr) rectShape.top = atoi((char*)xmlGetProp(xmlNode,
					(xmlChar*)"Top"));
				else throw 1;
				attr = xmlHasProp(xmlNode, (xmlChar*)"Width");
				if (attr) rectShape.right = rectShape.left + atoi((char*)
					xmlGetProp(xmlNode, (xmlChar*)"Width")) - 1;
				else throw 1;
				if (rectShape.right > iMaxLen) iMaxLen = rectShape.right;
				attr = xmlHasProp(xmlNode, (xmlChar*)"Height");
				if (attr) rectShape.bottom = rectShape.top + atoi((char*)
					xmlGetProp(xmlNode, (xmlChar*)"Height")) - 1;
				else throw 1;
				if (rectShape.bottom > iMaxHgt) iMaxHgt = rectShape.bottom;
//				SnapRect(&rectShape, GetApp()->GetOpt()->iSnapType);
				pNewShape->SetRect(rectShape);

				attr = xmlHasProp(xmlNode, (xmlChar*)"Al");
				if (attr) pNewShape->iAlig = atoi((char*)
					xmlGetProp(xmlNode, (xmlChar*)"Al"));
				else pNewShape->iAlig = 0;
				attr = xmlHasProp(xmlNode, (xmlChar*)"Br");
				if (attr) pNewShape->SetBorder(atoi((char*)
					xmlGetProp(xmlNode, (xmlChar*)"Br")) != 0);
				else pNewShape->SetBorder(true);

				m_listShape.AddTail(pNewShape);
			}
		}
	} catch (int iNum) {
		if (iNum) xmlFreeDoc(xmlDoc);
		if (pNewShape) delete pNewShape;
		DeleteAll();
		MessageBox("XML file corrupted", "Error", MB_OK | MB_ICONSTOP);
		return;
	}

	m_FormOpt.iHeight = iMaxHgt / 20 + 1;
	if (m_FormOpt.iHeight < 50) m_FormOpt.iHeight = 50;
	m_FormOpt.iWidth = iMaxLen / 20 + 1;
	if (m_FormOpt.iWidth < 20) m_FormOpt.iWidth = 20;
}
