// EditorView.cpp : implementation of the CEditorView class
//

#include "stdafx.h"
#include "Editor.h"

#include "EditorDoc.h"
#include "EditorView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
#define PRE_NONE 0
#define PRE_LEFT 1
#define PRE_RIGHT 2
#define PRE_TOP 3
#define PRE_BOTTOM 4
#define PRE_TEXT 5
#define PRE_WIDTH 6
#define PRE_HEIGHT 7

#define T_NONE 0
#define T_BUTTON 1
#define T_TEXTEDIT 2
#define T_TEXT 3
#define T_BLOCKED 4

#define M_NONE 0
#define M_MOVE 1
#define M_WIDTH 2
#define M_HEIGHT 3
#define M_EDIT 4

#define TEXT_STYLE (ES_MULTILINE | ES_WANTRETURN)

const int max_items=200;
RECT but_rect[max_items],
	edit_rect[max_items],
	text_rect[max_items];//���������� ��������
CString but_text[max_items],
	text_text[max_items],
	edit_text[max_items],//������ ��������
	default_but_text,
	default_edit_text,
	default_text_text;//�������� �� ���������
CButton but[max_items];//������� Button
CEdit edit[max_items];//������� Textedit
CEdit text[max_items];//������� Text (Label)
BOOL RB_go=FALSE;//=1 ���� � ������ ������ �����-������ ������� ����������������
int but_kol,edit_kol,text_kol;//���������� ���������
int mode,mode_type,mode_num;
/*mode - ������� �����:
	 M_NONE - �������
	 M_MOVE - ����� ������������ ��������
	 M_WIDTH - ����� ��������� ������ ��������
	 M_HEIGHT - ����� ��������� ������ ��������
	 M_EDIT - ����� �������������� Textedit'�

  mode_type - ��� �������, � ������� ��� ����������:
	 T_BUTTON.T_TEXTEDIT,T_TEXT

  mode_num - ���������� ����� ����� �������
*/

int lost_num=0,lost_type=T_NONE;//��������� ������������ ������

BOOL lost_file=FALSE;
char lost_file_name[200];

HCURSOR cursor;

BOOL buf=FALSE;//������� � ������ ����-����
int buf_type;//��� ������� � ������
CString buf_text;//����� ������� � ������
RECT buf_rect;//���������� ������� � ������

struct for_init {
	int type,left,right,top,bottom,start,pre;
	CString text;
} init;//��� �������� �����
CString words[10000];//�����,��������� �� �����
int words_kol=0;//���-�� ���� ����

CFile f;
int mouse_x,mouse_y,lmouse_x,lmouse_y;//������� � ������� ���������� �����

struct for_table {
	int type,colspan,rowspan,num;
	int is;//is - ���� ������ �������������, �� ��� ��� �������������?
	/* type - ��� ��������� � ������ (button,textedit,...)
	   colspan - ������ (� �������)
	   rowspan - ������ (� �������)
	   num - ���������� ����� ��������
	*/
} table[30][20];//������� 19x12 (30x20 - ����� �� �������)
// CEditorView

IMPLEMENT_DYNCREATE(CEditorView, CView)

BEGIN_MESSAGE_MAP(CEditorView, CView)
	//{{AFX_MSG_MAP(CEditorView)
	ON_WM_PAINT()
	ON_WM_CREATE()
	ON_UPDATE_COMMAND_UI(ID_NEW_BUTTON, OnUpdateNewButton)
	ON_COMMAND(ID_NEW_BUTTON, OnNewButton)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_TIMER()
	ON_WM_RBUTTONDOWN()
	ON_UPDATE_COMMAND_UI(ID_BUTTON_EXPORT, OnUpdateButtonExport)
	ON_COMMAND(ID_BUTTON_EXPORT, OnButtonExport)
	ON_WM_DESTROY()
	ON_UPDATE_COMMAND_UI(ID_EDIT_CUT, OnUpdateEditCut)
	ON_WM_ERASEBKGND()
	ON_WM_SHOWWINDOW()
	ON_UPDATE_COMMAND_UI(ID_BUTTON_PROPERTY, OnUpdateButtonProperty)
	ON_COMMAND(ID_BUTTON_PROPERTY, OnButtonProperty)
	ON_UPDATE_COMMAND_UI(ID_NEW_EDIT, OnUpdateNewEdit)
	ON_COMMAND(ID_NEW_EDIT, OnNewEdit)
	ON_UPDATE_COMMAND_UI(ID_NEW_TEXT, OnUpdateNewText)
	ON_COMMAND(ID_NEW_TEXT, OnNewText)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE, OnUpdateEditDelete)
	ON_COMMAND(ID_EDIT_DELETE, OnEditDelete)
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopy)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, OnUpdateEditPaste)
	ON_UPDATE_COMMAND_UI(ID_EDIT_MOVE, OnUpdateEditMove)
	ON_COMMAND(ID_EDIT_MOVE, OnEditMove)
	ON_UPDATE_COMMAND_UI(ID_EDIT_HEIGHT, OnUpdateEditHeight)
	ON_COMMAND(ID_EDIT_HEIGHT, OnEditHeight)
	ON_UPDATE_COMMAND_UI(ID_EDIT_WIDTH, OnUpdateEditWidth)
	ON_COMMAND(ID_EDIT_WIDTH, OnEditWidth)
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_OPTIONS, OnUpdateToolsOptions)
	ON_COMMAND(ID_TOOLS_OPTIONS, OnToolsOptions)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditorView construction/destruction

CEditorView::CEditorView()
{
	// TODO: add construction code here

}

CEditorView::~CEditorView()
{
}

BOOL CEditorView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	cs.x=0;
	cs.y=0;
	cs.cx=800-5;
	cs.cy=600-30;

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CEditorView drawing

void CEditorView::OnDraw(CDC* pDC)
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	SetCursor(cursor);
}

/////////////////////////////////////////////////////////////////////////////
// CEditorView diagnostics

#ifdef _DEBUG
void CEditorView::AssertValid() const
{
	CView::AssertValid();
}

void CEditorView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CEditorDoc* CEditorView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CEditorDoc)));
	return (CEditorDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CEditorView message handlers

void CEditorView::OnPaint() 
{
	if(GetCaretBlinkTime()==577)
	{
		but_kol=edit_kol=text_kol=0;
		SetCaretBlinkTime(500);
		char a[200];
		CWnd* cwnd=GetParentOwner();
		sprintf(a,"Editor : Untitled");
		cwnd->SetWindowText(a);
	}
	int q;
	SetCursor(cursor);

	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	for(q=0;q<but_kol;q++)
	{
		but[q].UpdateWindow();
	}//q
	for(q=0;q<edit_kol;q++)
	{
		edit[q].UpdateWindow();
	}//q
	for(q=0;q<text_kol;q++)
	{
		text[q].UpdateWindow();
		text[q].SetWindowText(text_text[q]);
	}//q
	CBrush newbrush,*oldbrush;

	newbrush.CreateSolidBrush(RGB(0,0,0));
	oldbrush=dc.SelectObject(&newbrush);

	dc.Rectangle(0,0,800,600);

	dc.SelectObject(oldbrush);
	newbrush.DeleteObject();
	// Do not call CView::OnPaint() for painting messages
}

int CEditorView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	// TODO: Add your specialized creation code here
	int q,w;
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	cursor=LoadCursor(NULL,IDC_ARROW);	

	LoadConfig();

	but_kol=edit_kol=text_kol=0;
	mode=M_NONE;
	ren_dlg.Create(IDD_DIALOG1,GetParentOwner());
	prop_dlg.Create(IDD_DIALOG2,GetParentOwner());
	text_dlg.Create(IDD_DIALOG3,GetParentOwner());
	exp_dlg.Create(IDD_DIALOG6,GetParentOwner());
	options_dlg.Create(IDD_DIALOG_OPTIONS,GetParentOwner());
	options_dlg.SetDlgItemText(IDC_EDIT_BUTTON,default_but_text);
	options_dlg.SetDlgItemText(IDC_EDIT_TEXTEDIT,default_edit_text);
	options_dlg.SetDlgItemText(IDC_EDIT_TEXT,default_text_text);

	for(w=0;w<12;w++)
	for(q=0;q<19;q++)
		table[q][w].colspan=1,
		table[q][w].num=0,
		table[q][w].rowspan=1,
		table[q][w].type=T_NONE;
	SetTimer(0,100,NULL);
	SetCaretBlinkTime(500);

	return 0;
}

void CEditorView::OnUpdateNewButton(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable();
	
}

void CEditorView::OnNewButton() 
{
	int q;
	// TODO: Add your command handler code here
	//������� Button
	if(but_kol==max_items) return;
	if(mode==M_EDIT)
		edit[mode_num].GetWindowText(edit_text[mode_num]),
		edit[mode_num].BeginModalState(),
		mode=M_NONE;

	if(mode==M_MOVE)
	{
		switch(mode_type)
		{
		case T_BUTTON:
			if(mode_num==but_kol-1)
			{
				but[mode_num].DestroyWindow();
				but_kol-=1;
			}
			else 
			{
				for(q=0;q<but_kol;q++)
					but[q].DestroyWindow();
				SwapButtons(mode_num,but_kol-1);
				but_kol-=1;
				for(q=0;q<but_kol;q++)
				{
					but[q].Create(but_text[q],0,but_rect[q],GetParentOwner(),q);
					but[q].CloseWindow();
					but[q].BeginModalState();
					but[q].SetButtonStyle(WS_DISABLED);
					but[q].ShowWindow(SW_NORMAL);
					but[q].BringWindowToTop();
					but[q].UpdateWindow();
				}//q
			}
			break;
		case T_TEXTEDIT:
			if(mode_num==edit_kol-1)
			{
				edit[mode_num].DestroyWindow();
				edit_kol-=1;
			}
			else 
			{
				for(q=0;q<edit_kol;q++)
					edit[q].DestroyWindow();
				SwapTextedits(mode_num,edit_kol-1);
				edit_kol-=1;
				for(q=0;q<edit_kol;q++)
				{
					edit[q].Create(0,but_rect[q],GetParentOwner(),q);
					edit[q].CloseWindow();
					edit[q].BeginModalState();
					edit[q].ShowWindow(SW_NORMAL);
					edit[q].BringWindowToTop();
					edit[q].UpdateWindow();
				}//q
			}
			break;
		case T_TEXT:
			if(mode_num==text_kol-1)
			{
				text[mode_num].DestroyWindow();
				text_kol-=1;
			}
			else 
			{
				for(q=0;q<text_kol;q++)
					text[q].DestroyWindow();
				SwapTexts(mode_num,text_kol-1);
				text_kol-=1;
				for(q=0;q<text_kol;q++)
				{
					text[q].Create(TEXT_STYLE,text_rect[q],GetParentOwner(),q);
					text[q].ShowWindow(SW_NORMAL);
					text[q].UpdateWindow();
				}//q
			}
			break;
		}//switch mode_type
	}
	if(mouse_x>50 && mouse_x<750)
		but_rect[but_kol].left=mouse_x-19,
		but_rect[but_kol].right=mouse_x+20;
	else
		but_rect[but_kol].left=401,
		but_rect[but_kol].right=440;
	but_rect[but_kol].top=31;
	but_rect[but_kol].bottom=70;//69
	but_text[but_kol]=default_but_text;
	but[but_kol].Create(but_text[but_kol],0,but_rect[but_kol],GetParentOwner(),but_kol);
	but[but_kol].CloseWindow();
	but[but_kol].BeginModalState();
	but[but_kol].ShowWindow(SW_NORMAL);
	but[but_kol].UpdateWindow();
	mode=M_MOVE;
	mode_type=T_BUTTON;
	mode_num=but_kol;
	lost_num=but_kol;
	lost_type=T_BUTTON;
	but_kol+=1;
	
}

void CEditorView::OnMouseMove(UINT nFlags, CPoint point) 
{
	int q;
	// TODO: Add your message handler code here and/or call default
	int x1,x2,y1,y2,width,lwidth,lheight,ly1,ly2;
	int ok;
	lmouse_x=mouse_x;
	lmouse_y=mouse_y;
	mouse_x=point.x;
	mouse_y=point.y;
	int cursor_changed;

	switch(mode)
	{
	case M_MOVE:
		switch(mode_type)
		{
		case T_BUTTON:
			but_rect[mode_num].bottom+=mouse_y-lmouse_y;
			but_rect[mode_num].top+=mouse_y-lmouse_y;
			but_rect[mode_num].left+=mouse_x-lmouse_x;
			but_rect[mode_num].right+=mouse_x-lmouse_x;
			if( but_rect[mode_num].left<5   ||
				but_rect[mode_num].right>790 ||
				but_rect[mode_num].top<30    ||
				but_rect[mode_num].bottom>525)
			{
				but_rect[mode_num].bottom-=mouse_y-lmouse_y;
				but_rect[mode_num].top-=mouse_y-lmouse_y;
				but_rect[mode_num].left-=mouse_x-lmouse_x;
				but_rect[mode_num].right-=mouse_x-lmouse_x;
			}//if
			if(mouse_x-lmouse_x!=0 || mouse_y-lmouse_y!=0)
				RedrawButton(mode_num);
			SendMessage(WM_PAINT);
			cursor=LoadCursor(NULL,IDC_SIZEALL);cursor_changed=1;
			break;
		case T_TEXTEDIT:
			edit_rect[mode_num].bottom+=mouse_y-lmouse_y;
			edit_rect[mode_num].top+=mouse_y-lmouse_y;
			edit_rect[mode_num].left+=mouse_x-lmouse_x;
			edit_rect[mode_num].right+=mouse_x-lmouse_x;
			if( edit_rect[mode_num].left<5   ||
				edit_rect[mode_num].right>790 ||
				edit_rect[mode_num].top<30    ||
				edit_rect[mode_num].bottom>525)
			{
				edit_rect[mode_num].bottom-=mouse_y-lmouse_y;
				edit_rect[mode_num].top-=mouse_y-lmouse_y;
				edit_rect[mode_num].left-=mouse_x-lmouse_x;
				edit_rect[mode_num].right-=mouse_x-lmouse_x;
			}//if
			if(mouse_x-lmouse_x!=0 || mouse_y-lmouse_y!=0)
				RedrawTextedit(mode_num);
			SendMessage(WM_PAINT);
			cursor=LoadCursor(NULL,IDC_SIZEALL);cursor_changed=1;
			break;
		case T_TEXT:
			text_rect[mode_num].bottom+=mouse_y-lmouse_y;
			text_rect[mode_num].top+=mouse_y-lmouse_y;
			text_rect[mode_num].left+=mouse_x-lmouse_x;
			text_rect[mode_num].right+=mouse_x-lmouse_x;
			if( text_rect[mode_num].left<5   ||
				text_rect[mode_num].right>790 ||
				text_rect[mode_num].top<30    ||
				text_rect[mode_num].bottom>525)
			{
				text_rect[mode_num].bottom-=mouse_y-lmouse_y;
				text_rect[mode_num].top-=mouse_y-lmouse_y;
				text_rect[mode_num].left-=mouse_x-lmouse_x;
				text_rect[mode_num].right-=mouse_x-lmouse_x;
			}//if
			if(mouse_x-lmouse_x!=0 || mouse_y-lmouse_y!=0)
				RedrawText(mode_num);
			SendMessage(WM_PAINT);
			cursor=LoadCursor(NULL,IDC_SIZEALL);cursor_changed=1;
			break;
		}//switch mode_type
		break;
	case M_WIDTH:
		cursor=LoadCursor(NULL,IDC_SIZEWE);cursor_changed=1;
		switch(mode_type)
		{
		case T_BUTTON:
				lwidth=(but_rect[mode_num].right-but_rect[mode_num].left)/40+1;
				x1=(but_rect[mode_num].left-5)/40;
				x2=(but_rect[mode_num].right-5)/40;
				y1=(but_rect[mode_num].top-30)/40;
				y2=(but_rect[mode_num].bottom-30)/40;
				but_rect[mode_num].right+=mouse_x-lmouse_x;
				ok=1;
				if( but_rect[mode_num].right-but_rect[mode_num].left<15 ||
					(but_rect[mode_num].right-5)/40>18)
						ok=0;
				width=(but_rect[mode_num].right-but_rect[mode_num].left)/40+1;
				if(width>lwidth)
				for(q=y1;q<=y2;q++)
					if(table[x2+1][q].type!=T_NONE)
						ok=0;
				if(ok==0)
				{
					but_rect[mode_num].right-=mouse_x-lmouse_x;
				}
			AlignButton(mode_num);
			if(mouse_x-lmouse_x!=0 || mouse_y-lmouse_y!=0)
				RedrawButton(mode_num);
			SendMessage(WM_PAINT);
			break;
		case T_TEXTEDIT:
				lwidth=(edit_rect[mode_num].right-edit_rect[mode_num].left)/40+1;
				x1=(edit_rect[mode_num].left-5)/40;
				x2=(edit_rect[mode_num].right-5)/40;
				y1=(edit_rect[mode_num].top-30)/40;
				y2=(edit_rect[mode_num].bottom-30)/40;
				edit_rect[mode_num].right+=mouse_x-lmouse_x;
				ok=1;
				if( edit_rect[mode_num].right-edit_rect[mode_num].left<15 ||
					(edit_rect[mode_num].right-5)/40>18)
						ok=0;
				width=(edit_rect[mode_num].right-edit_rect[mode_num].left)/40+1;
				if(width>lwidth)
				for(q=y1;q<=y2;q++)
					if(table[x2+1][q].type!=T_NONE)
						ok=0;
				if(ok==0)
				{
					edit_rect[mode_num].right-=mouse_x-lmouse_x;
				}
			if(mouse_x-lmouse_x!=0 || mouse_y-lmouse_y!=0)
				RedrawTextedit(mode_num);
			SendMessage(WM_PAINT);
			break;
		case T_TEXT:
				lwidth=(text_rect[mode_num].right-text_rect[mode_num].left)/40+1;
				x1=(text_rect[mode_num].left-5)/40;
				x2=(text_rect[mode_num].right-5)/40;
				y1=(text_rect[mode_num].top-30)/40;
				y2=(text_rect[mode_num].bottom-30)/40;
				text_rect[mode_num].right+=mouse_x-lmouse_x;
				ok=1;
				if( text_rect[mode_num].right-text_rect[mode_num].left<15 ||
					(text_rect[mode_num].right-5)/40>18)
						ok=0;
				width=(text_rect[mode_num].right-text_rect[mode_num].left)/40+1;
				if(width>lwidth)
				for(q=y1;q<=y2;q++)
					if(table[x2+1][q].type!=T_NONE)
						ok=0;
				if(ok==0)
				{
					text_rect[mode_num].right-=mouse_x-lmouse_x;
				}
			AlignText(mode_num);
			if(mouse_x-lmouse_x!=0 || mouse_y-lmouse_y!=0)
				RedrawText(mode_num);
			SendMessage(WM_PAINT);
			break;
		}//switch mode_type
		break;
	case M_HEIGHT:
		cursor=LoadCursor(NULL,IDC_SIZENS);cursor_changed=1;
		switch(mode_type)
		{
		case T_BUTTON:
			x1=(but_rect[mode_num].left-5)/40;
			x2=(but_rect[mode_num].right-5)/40;
			ly1=(but_rect[mode_num].top-30)/40;
			ly2=(but_rect[mode_num].bottom-30)/40;
			lwidth=x2-x1+1;
			lheight=ly2-ly1+1;
			but_rect[mode_num].bottom+=mouse_y-lmouse_y;
			if( but_rect[mode_num].bottom-but_rect[mode_num].top<15 ||
				(but_rect[mode_num].bottom+10)/40>12)
				but_rect[mode_num].bottom-=(mouse_y-lmouse_y);
			y2=(but_rect[mode_num].bottom-30)/40;
			if(y2>ly2)
			{
				ok=1;
				for(q=x1;q<=x2;q++)
					if(table[q][y2].type!=T_NONE)
						ok=0;
				if(ok==0)
				{
					but_rect[mode_num].bottom=(ly2+1)*40+29;
				}
			}//to smart
			if(mouse_x-lmouse_x!=0 || mouse_y-lmouse_y!=0)
				RedrawButton(mode_num);
			SendMessage(WM_PAINT);
			break;
		case T_TEXT:
			x1=(text_rect[mode_num].left-5)/40;
			x2=(text_rect[mode_num].right-5)/40;
			ly1=(text_rect[mode_num].top-30)/40;
			ly2=(text_rect[mode_num].bottom-30)/40;
			lwidth=x2-x1+1;
			lheight=ly2-ly1+1;
				text_rect[mode_num].bottom+=mouse_y-lmouse_y;
				if( text_rect[mode_num].bottom-text_rect[mode_num].top<20 ||
					(text_rect[mode_num].bottom+10)/40>12)
					text_rect[mode_num].bottom-=(mouse_y-lmouse_y);
				y2=(text_rect[mode_num].bottom-30)/40;
				if(y2>ly2)
				{
					ok=1;
					for(q=x1;q<=x2;q++)
						if(table[q][y2].type!=T_NONE)
							ok=0;
					if(ok==0)
						text_rect[mode_num].bottom-=mouse_y-lmouse_y;
				}//to smart
			if(mouse_x-lmouse_x!=0 || mouse_y-lmouse_y!=0)
				RedrawText(mode_num);
			SendMessage(WM_PAINT);
			break;
		}//switch mode_type
		break;
	}//switch mode
	UpdateTable();
	SendMessage(WM_PAINT);

	cursor_changed=0;
	for(q=0;q<but_kol;q++)
	{
		if( mouse_x+5 >but_rect[q].left+5  &&
			mouse_x+5<but_rect[q].right-5 &&
			mouse_y+30>but_rect[q].top+5   &&
			mouse_y+30<but_rect[q].bottom-5)
				cursor=LoadCursor(NULL,IDC_SIZEALL),cursor_changed=1;
		if( mouse_x+5>=but_rect[q].left  &&
			mouse_x+5<=but_rect[q].right &&
			mouse_y+30>=but_rect[q].top   &&
			mouse_y+30<=but_rect[q].top+4 ||
			mouse_x+5>=but_rect[q].left  &&
			mouse_x+5<=but_rect[q].right &&
			mouse_y+30>=but_rect[q].bottom-4   &&
			mouse_y+30<=but_rect[q].bottom)
				cursor=LoadCursor(NULL,IDC_SIZENS),cursor_changed=1;
		if( mouse_x+5>=but_rect[q].left  &&
			mouse_x+5<=but_rect[q].left+4 &&
			mouse_y+30>=but_rect[q].top   &&
			mouse_y+30<=but_rect[q].bottom ||
			mouse_x+5>=but_rect[q].right-4  &&
			mouse_x+5<=but_rect[q].right &&
			mouse_y+30>=but_rect[q].top   &&
			mouse_y+30<=but_rect[q].bottom)
				cursor=LoadCursor(NULL,IDC_SIZEWE),cursor_changed=1;
	}//for q
	for(q=0;q<edit_kol;q++)
	{
		if( mouse_x+5 >edit_rect[q].left+5  &&
			mouse_x+5<edit_rect[q].right-5 &&
			mouse_y+30>edit_rect[q].top   &&
			mouse_y+30<edit_rect[q].bottom)
				cursor=LoadCursor(NULL,IDC_SIZEALL),cursor_changed=1;
		if( mouse_x+5>=edit_rect[q].left  &&
			mouse_x+5<=edit_rect[q].left+4 &&
			mouse_y+30>=edit_rect[q].top   &&
			mouse_y+30<=edit_rect[q].bottom ||
			mouse_x+5>=edit_rect[q].right-4  &&
			mouse_x+5<=edit_rect[q].right &&
			mouse_y+30>=edit_rect[q].top   &&
			mouse_y+30<=edit_rect[q].bottom)
				cursor=LoadCursor(NULL,IDC_SIZEWE),cursor_changed=1;
	}//for q
	for(q=0;q<text_kol;q++)
	{
		if( mouse_x+5 >text_rect[q].left+5  &&
			mouse_x+5<text_rect[q].right-5 &&
			mouse_y+30>text_rect[q].top+5   &&
			mouse_y+30<text_rect[q].bottom-5)
				cursor=LoadCursor(NULL,IDC_SIZEALL),cursor_changed=1;
		if( mouse_x+5>=text_rect[q].left  &&
			mouse_x+5<=text_rect[q].left+4 &&
			mouse_y+30>=text_rect[q].top   &&
			mouse_y+30<=text_rect[q].bottom ||
			mouse_x+5>=text_rect[q].right-4  &&
			mouse_x+5<=text_rect[q].right &&
			mouse_y+30>=text_rect[q].top   &&
			mouse_y+30<=text_rect[q].bottom)
				cursor=LoadCursor(NULL,IDC_SIZEWE),cursor_changed=1;
		if( mouse_x+5>=text_rect[q].left  &&
			mouse_x+5<=text_rect[q].right &&
			mouse_y+30>=text_rect[q].top   &&
			mouse_y+30<=text_rect[q].top+4 ||
			mouse_x+5>=text_rect[q].left  &&
			mouse_x+5<=text_rect[q].right &&
			mouse_y+30>=text_rect[q].bottom-4   &&
			mouse_y+30<=text_rect[q].bottom)
				cursor=LoadCursor(NULL,IDC_SIZENS),cursor_changed=1;
	}
	if(!cursor_changed)
		for(q=0;q<edit_kol;q++)
			if( mouse_x+5 >=edit_rect[q].left+5  &&
				mouse_x+5<=edit_rect[q].right-5 &&
				mouse_y+30>=edit_rect[q].top+5   &&
				mouse_y+30<=edit_rect[q].bottom-5)
					cursor=LoadCursor(NULL,IDC_SIZEALL),cursor_changed=1;
	if(!cursor_changed)
		cursor=LoadCursor(NULL,IDC_ARROW);

	CView::OnMouseMove(nFlags, point);
}

void CEditorView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	int q,w;
	// TODO: Add your message handler code here and/or call default
	if(mode==M_EDIT)
		edit[mode_num].GetWindowText(edit_text[mode_num]),
		edit[mode_num].BeginModalState(),
		mode=M_NONE;
	BOOL release=TRUE;
	int x=0,y=0,width=0,height=0,width_px,height_px,ok=0;
	x=(mouse_x-5)/40;
	y=(mouse_y)/40;
	if(y>11) y=11;
	if(x>18) x=18;

	switch(mode)
	{
	case M_WIDTH:
	case M_HEIGHT:
		mode=M_NONE;
		break;
	case M_NONE:
		for(q=0;q<but_kol;q++)
		{
		if( mouse_x+5 >but_rect[q].left+5  &&
			mouse_x+5<but_rect[q].right-5 &&
			mouse_y+30>but_rect[q].top+5   &&
			mouse_y+30<but_rect[q].bottom-5)
		{
			width=(but_rect[mode_num].right-but_rect[mode_num].left)/40+1;
			height=(but_rect[mode_num].bottom-but_rect[mode_num].top)/40+1;

			mode=M_MOVE;
			mode_type=T_BUTTON;
			mode_num=q;
			lost_num=q;
			lost_type=T_BUTTON;
			break;
		}//MOVE
		if( mouse_x+5>=but_rect[q].left  &&
			mouse_x+5<=but_rect[q].left+4 &&
			mouse_y+30>=but_rect[q].top   &&
			mouse_y+30<=but_rect[q].bottom ||
			mouse_x+5>=but_rect[q].right-4  &&
			mouse_x+5<=but_rect[q].right &&
			mouse_y+30>=but_rect[q].top   &&
			mouse_y+30<=but_rect[q].bottom)
		{
			mode=M_WIDTH;
			mode_type=T_BUTTON;
			mode_num=q;
			lost_num=q;
			lost_type=T_BUTTON;
			break;
		}//WIDTH
		if( mouse_x+5>=but_rect[q].left  &&
			mouse_x+5<=but_rect[q].right &&
			mouse_y+30>=but_rect[q].top   &&
			mouse_y+30<=but_rect[q].top+4 ||
			mouse_x+5>=but_rect[q].left  &&
			mouse_x+5<=but_rect[q].right &&
			mouse_y+30>=but_rect[q].bottom-4   &&
			mouse_y+30<=but_rect[q].bottom)
		{
			mode=M_HEIGHT;
			mode_type=T_BUTTON;
			mode_num=q;
			lost_num=q;
			lost_type=T_BUTTON;
			break;
		}//HEIGHT
		}//for
		for(q=0;q<edit_kol;q++)
		{
		if( mouse_x+5 >edit_rect[q].left+5  &&
			mouse_x+5<edit_rect[q].right-5 &&
			mouse_y+30>edit_rect[q].top   &&
			mouse_y+30<edit_rect[q].bottom)
		{
			width=(edit_rect[mode_num].right-edit_rect[mode_num].left+1)/40+1;
			height=(edit_rect[mode_num].bottom-edit_rect[mode_num].top+1)/40+1;

			mode=M_MOVE;
			mode_type=T_TEXTEDIT;
			mode_num=q;
			lost_num=q;
			lost_type=T_TEXTEDIT;
			for(w=y;w<y+height;w++)
			for(q=x;q<x+width;q++)
				table[q][w].type=T_NONE;
			break;
		}//MOVE
		if( mouse_x+5>=edit_rect[q].left  &&
			mouse_x+5<=edit_rect[q].left+5 &&
			mouse_y+30>=edit_rect[q].top   &&
			mouse_y+30<=edit_rect[q].bottom ||
			mouse_x+5>=edit_rect[q].right-5  &&
			mouse_x+5<=edit_rect[q].right &&
			mouse_y+30>=edit_rect[q].top   &&
			mouse_y+30<=edit_rect[q].bottom)
		{
			mode=M_WIDTH;
			mode_type=T_TEXTEDIT;
			mode_num=q;
			lost_num=q;
			lost_type=T_TEXTEDIT;
			break;
		}//WIDTH
		}//for
		for(q=0;q<text_kol;q++)
		{
		if( mouse_x+5 >text_rect[q].left+5  &&
			mouse_x+5<text_rect[q].right-5 &&
			mouse_y+30>text_rect[q].top+5   &&
			mouse_y+30<text_rect[q].bottom-5)
		{
			width=(text_rect[mode_num].right-text_rect[mode_num].left+1)/40+1;
			height=(text_rect[mode_num].bottom-text_rect[mode_num].top+1)/40+1;

			mode=M_MOVE;
			mode_type=T_TEXT;
			mode_num=q;
			lost_num=q;
			lost_type=T_TEXT;
			for(w=y;w<y+height;w++)
			for(q=x;q<x+width;q++)
				table[q][w].type=T_NONE;
			break;
		}//MOVE
		if( mouse_x+5>=text_rect[q].left  &&
			mouse_x+5<=text_rect[q].left+5 &&
			mouse_y+30>=text_rect[q].top   &&
			mouse_y+30<=text_rect[q].bottom ||
			mouse_x+5>=text_rect[q].right-5  &&
			mouse_x+5<=text_rect[q].right &&
			mouse_y+30>=text_rect[q].top   &&
			mouse_y+30<=text_rect[q].bottom)
		{
			mode=M_WIDTH;
			mode_type=T_TEXT;
			mode_num=q;
			lost_num=q;
			lost_type=T_TEXT;
			break;
		}//WIDTH
		if( mouse_x+5>=text_rect[q].left  &&
			mouse_x+5<=text_rect[q].right &&
			mouse_y+30>=text_rect[q].top   &&
			mouse_y+30<=text_rect[q].top+4 ||
			mouse_x+5>=text_rect[q].left  &&
			mouse_x+5<=text_rect[q].right &&
			mouse_y+30>=text_rect[q].bottom-4   &&
			mouse_y+30<=text_rect[q].bottom)
		{
			mode=M_HEIGHT;
			mode_type=T_TEXT;
			mode_num=q;
			lost_num=q;
			lost_type=T_TEXT;
			break;
		}//HEIGHT
		}//for
		break;

	case M_MOVE:
		switch(mode_type)
		{
		case T_BUTTON:
			width=(but_rect[mode_num].right-but_rect[mode_num].left+1)/40+1;
			height=(but_rect[mode_num].bottom-but_rect[mode_num].top+1)/40+1;
			width_px=but_rect[mode_num].right-but_rect[mode_num].left+1;
			height_px=but_rect[mode_num].bottom-but_rect[mode_num].top+1;
			ok=1;
			if((mouse_x-5)/40>19-width)
				ok=0;
			if((mouse_y-30)/40>12-height-1)
				ok=0;
			for(w=y;w<y+height;w++)
			for(q=x;q<x+width;q++)
				if(table[q][w].type!=T_NONE)
					ok=0;
			if(ok==1)
			{
				table[x][y].colspan=width;
				table[x][y].rowspan=height;
				table[x][y].num=mode_num;
				table[x][y].type=T_BUTTON;
				but[mode_num].DestroyWindow();
				but_rect[mode_num].left=x*40+5;
				but_rect[mode_num].right=x*40+5+width_px-1;
				but_rect[mode_num].top=y*40+30;
				but_rect[mode_num].bottom=y*40+30+height_px-1;

				AlignButton(mode_num);

				RedrawButton(mode_num);
				lost_num=mode_num;
				lost_type=T_BUTTON;

				for(w=y;w<y+height-1;w++)
				for(q=x;q<x+width-1;q++)
					table[q][w].type=T_BLOCKED;
				table[x][y].colspan=width;
				table[x][y].rowspan=height;
				table[x][y].num=mode_num;
				table[x][y].type=T_BUTTON;

				mode=M_NONE;
				mode_type=T_NONE;
				mode_num=0;
			}//if
			break;
		case T_TEXTEDIT:
			width=(edit_rect[mode_num].right-edit_rect[mode_num].left+1)/40+1;
			height=(edit_rect[mode_num].bottom-edit_rect[mode_num].top+1)/40+1;
			width_px=edit_rect[mode_num].right-edit_rect[mode_num].left+1;
			height_px=edit_rect[mode_num].bottom-edit_rect[mode_num].top+1;
			ok=1;
			if((mouse_x-5)/40>19-width)
				ok=0;
			if((mouse_y-30)/40>12-height-1)
				ok=0;
			for(w=y;w<y+height;w++)
			for(q=x;q<x+width;q++)
				if(table[q][w].type!=T_NONE)
					ok=0;
			if(ok==1)
			{
				table[x][y].colspan=width;
				table[x][y].rowspan=height;
				table[x][y].num=mode_num;
				table[x][y].type=T_BUTTON;
				edit[mode_num].DestroyWindow();
				edit_rect[mode_num].left=x*40+5;
				edit_rect[mode_num].right=x*40+5+width_px-1;
				edit_rect[mode_num].top=y*40+30;
				edit_rect[mode_num].bottom=y*40+30+height_px-1;

				AlignTextedit(mode_num);

				RedrawTextedit(mode_num);
				lost_num=mode_num;
				lost_type=T_TEXTEDIT;

				for(w=y;w<y+height-1;w++)
				for(q=x;q<x+width-1;q++)
					table[q][w].type=T_BLOCKED;
				table[x][y].colspan=width;
				table[x][y].rowspan=height;
				table[x][y].num=mode_num;
				table[x][y].type=T_TEXTEDIT;

				mode=M_NONE;
				mode_type=T_NONE;
				mode_num=0;
			}//if
			break;
		case T_TEXT:
			width=(text_rect[mode_num].right-text_rect[mode_num].left+1)/40+1;
			height=(text_rect[mode_num].bottom-text_rect[mode_num].top+1)/40+1;
			width_px=text_rect[mode_num].right-text_rect[mode_num].left+1;
			height_px=text_rect[mode_num].bottom-text_rect[mode_num].top+1;
			ok=1;
			if((mouse_x-5)/40>19-width)
				ok=0;
			if((mouse_y-30)/40>12-height-1)
				ok=0;
			for(w=y;w<y+height;w++)
			for(q=x;q<x+width;q++)
				if(table[q][w].type!=T_NONE)
					ok=0;
			if(ok==1)
			{
				table[x][y].colspan=width;
				table[x][y].rowspan=height;
				table[x][y].num=mode_num;
				table[x][y].type=T_BUTTON;
				text_rect[mode_num].left=x*40+5;
				text_rect[mode_num].right=x*40+5+width_px-1;
				text_rect[mode_num].top=y*40+30;
				text_rect[mode_num].bottom=y*40+30+height_px-1;

				AlignText(mode_num);

				RedrawText(mode_num);
				SendMessage(WM_PAINT);
				lost_num=mode_num;
				lost_type=T_TEXT;

				for(w=y;w<y+height-1;w++)
				for(q=x;q<x+width-1;q++)
					table[q][w].type=T_BLOCKED;
				table[x][y].colspan=width;
				table[x][y].rowspan=height;
				table[x][y].num=mode_num;
				table[x][y].type=T_TEXT;

				mode=M_NONE;
				mode_type=T_NONE;
				mode_num=0;
			}//if
			break;
		}//switch mode_type
	}//switch mode
	
	CView::OnLButtonDown(nFlags, point);
}

void CEditorView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	int q,w;
	// TODO: Add your message handler code here and/or call default
	if(mode==M_EDIT)
		edit[mode_num].GetWindowText(edit_text[mode_num]),
		edit[mode_num].BeginModalState(),
		mode=M_NONE;
	BOOL release=TRUE;
	int x=0,y=0,width=0,height=0,width_px,height_px,ok=0;
	x=(mouse_x-5)/40;
	y=(mouse_y)/40;
	if(y>11) y=11;
	if(x>18) x=18;

	switch(mode)
	{
	case M_MOVE:
		switch(mode_type)
		{
		case T_BUTTON:
			width=(but_rect[mode_num].right-but_rect[mode_num].left)/40+1;
			height=(but_rect[mode_num].bottom-but_rect[mode_num].top)/40+1;
			width_px=but_rect[mode_num].right-but_rect[mode_num].left+1;
			height_px=but_rect[mode_num].bottom-but_rect[mode_num].top+1;
			ok=1;
			if((mouse_x-5)/40>19-width)
				ok=0;
			if((mouse_y)/40>12-height)
				ok=0;
			for(w=y;w<y+height;w++)
			for(q=x;q<x+width;q++)
				if(table[q][w].type!=T_NONE)
					ok=0;
			if((mouse_x-5)/40>19)
				break;
			if(ok==0)
				break;
			if(ok==1)
			{
				table[x][y].colspan=width;
				table[x][y].rowspan=height;
				table[x][y].num=mode_num;
				table[x][y].type=T_BUTTON;
				but[mode_num].DestroyWindow();
				but_rect[mode_num].left=x*40+5;
				but_rect[mode_num].right=x*40+5+width_px-1;
				but_rect[mode_num].top=y*40+30;
				but_rect[mode_num].bottom=y*40+30+height_px-1;
		
				AlignButton(mode_num);

				RedrawButton(mode_num);
				lost_num=mode_num;
				lost_type=T_BUTTON;

				mode=M_NONE;
				mode_type=T_NONE;
				mode_num=0;
			}//if
			break;
		case T_TEXTEDIT:
			width=(edit_rect[mode_num].right-edit_rect[mode_num].left)/40+1;
			height=(edit_rect[mode_num].bottom-edit_rect[mode_num].top)/40+1;
			width_px=edit_rect[mode_num].right-edit_rect[mode_num].left+1;
			height_px=edit_rect[mode_num].bottom-edit_rect[mode_num].top+1;
			ok=1;
			if((mouse_x-5)/40>19-width)
				ok=0;
			if((mouse_y)/40>12-height)
				ok=0;
			for(w=y;w<y+height;w++)
			for(q=x;q<x+width;q++)
				if(table[q][w].type!=T_NONE)
					ok=0;
			if(ok==1)
			{
				table[x][y].colspan=width;
				table[x][y].rowspan=height;
				table[x][y].num=mode_num;
				table[x][y].type=T_TEXTEDIT;
				edit[mode_num].DestroyWindow();
				edit_rect[mode_num].left=x*40+5;
				edit_rect[mode_num].right=x*40+5+width_px-1;
				edit_rect[mode_num].top=y*40+30;
				edit_rect[mode_num].bottom=y*40+30+height_px-1;
		
				AlignTextedit(mode_num);

				RedrawTextedit(mode_num);
				lost_num=mode_num;
				lost_type=T_TEXTEDIT;

				for(w=y;w<y+height-1;w++)
				for(q=x;q<x+width-1;q++)
					table[q][w].type=T_BLOCKED;
				table[x][y].colspan=width;
				table[x][y].rowspan=height;
				table[x][y].num=mode_num;
				table[x][y].type=T_TEXTEDIT;

				mode=M_NONE;
				mode_type=T_NONE;
				mode_num=0;
			}//if
			break;
		case T_TEXT:
			width=(text_rect[mode_num].right-text_rect[mode_num].left)/40+1;
			height=(text_rect[mode_num].bottom-text_rect[mode_num].top)/40+1;
			width_px=text_rect[mode_num].right-text_rect[mode_num].left+1;
			height_px=text_rect[mode_num].bottom-text_rect[mode_num].top+1;
			ok=1;
			if((mouse_x-5)/40>19-width)
				ok=0;
			if((mouse_y)/40>12-height)
				ok=0;
			for(w=y;w<y+height;w++)
			for(q=x;q<x+width;q++)
				if(table[q][w].type!=T_NONE)
					ok=0;
			if(ok==1)
			{
				table[x][y].colspan=width;
				table[x][y].rowspan=height;
				table[x][y].num=mode_num;
				table[x][y].type=T_TEXT;
				text_rect[mode_num].left=x*40+5;
				text_rect[mode_num].right=x*40+5+width_px-1;
				text_rect[mode_num].top=y*40+30;
				text_rect[mode_num].bottom=y*40+30+height_px-1;
		
				AlignText(mode_num);

				RedrawText(mode_num);
				lost_num=mode_num;
				lost_type=T_TEXT;

				for(w=y;w<y+height-1;w++)
				for(q=x;q<x+width-1;q++)
					table[q][w].type=T_BLOCKED;
				table[x][y].colspan=width;
				table[x][y].rowspan=height;
				table[x][y].num=mode_num;
				table[x][y].type=T_TEXT;

				mode=M_NONE;
				mode_type=T_NONE;
				mode_num=0;
			}//if
			break;
		}//switch mode_type
		break;
	case M_WIDTH:
		switch(mode_type)
		{
		case T_BUTTON:
		case T_TEXTEDIT:
		case T_TEXT:
			mode=M_NONE;
			break;
		}//switch mode_type
		break;
	case M_HEIGHT:
		switch(mode_type)
		{
		case T_BUTTON:
		case T_TEXT:
			mode=M_NONE;
			break;
		}//switch mode_type
		break;
	}//switch mode
	
	CView::OnLButtonUp(nFlags, point);
}

void CEditorView::SwapButtons(int a, int b)
{
	//�������� ������� Button � ������� a � b
	static RECT z;
	static CString x;
	z.bottom=but_rect[a].bottom;
	z.left=but_rect[a].left;
	z.right=but_rect[a].right;
	z.top=but_rect[a].top;
	x=but_text[a];
	but_rect[a].bottom=but_rect[b].bottom;
	but_rect[a].left=but_rect[b].left;
	but_rect[a].right=but_rect[b].right;
	but_rect[a].top=but_rect[b].top;
	but_text[a]=but_text[b];
	but_rect[b].bottom=z.bottom;
	but_rect[b].left=z.left;
	but_rect[b].right=z.right;
	but_rect[b].top=z.top;
	but_text[b]=x;
}

void CEditorView::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	//������� ������ '��������'
	int q;
	// TODO: Add your message handler code here and/or call default
	if(mode==M_EDIT)
		edit[mode_num].GetWindowText(edit_text[mode_num]),
		edit[mode_num].BeginModalState(),
		mode=M_NONE;
	if(mode==M_MOVE) return;

	for(q=0;q<but_kol;q++)
	if( mouse_x+5 >=but_rect[q].left  &&
		mouse_x+5<=but_rect[q].right &&
		mouse_y+30>=but_rect[q].top   &&
		mouse_y+30<=but_rect[q].bottom)
	{
		ren_dlg.ShowWindow(SW_NORMAL);
		ren_dlg.UpdateWindow();
		ren_dlg.SetDlgItemText(IDC_EDIT1,but_text[q]);
		ren_dlg.MoveWindow(5,30,5+280,30+65);
		lost_num=q;
		lost_type=T_BUTTON;
	}

	for(q=0;q<edit_kol;q++)
	if( mouse_x+5 >=edit_rect[q].left  &&
		mouse_x+5<=edit_rect[q].right &&
		mouse_y+30>=edit_rect[q].top   &&
		mouse_y+30<=edit_rect[q].bottom)
	{
		mode=M_EDIT;
		mode_num=q;
		mode_type=T_TEXTEDIT;
		lost_num=q;
		lost_type=T_TEXTEDIT;
		edit[q].EndModalState();
		edit[q].SetWindowText(edit_text[q]);
	}
	for(q=0;q<text_kol;q++)
	if( mouse_x+5 >=text_rect[q].left  &&
		mouse_x+5<=text_rect[q].right &&
		mouse_y+30>=text_rect[q].top   &&
		mouse_y+30<=text_rect[q].bottom)
	{
		text_dlg.ShowWindow(SW_NORMAL);
		text_dlg.UpdateWindow();
		text_dlg.SetDlgItemText(IDC_EDIT1,text_text[q]);
		text_dlg.MoveWindow(5,30,5+405,30+240);
		lost_num=q;
		lost_type=T_TEXT;
	}
	
	CView::OnLButtonDblClk(nFlags, point);
}

void CEditorView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	SetCursor(cursor);
	if(GetCaretBlinkTime()==573)
	{
		//������� ����
		SetCaretBlinkTime(500);
		CFile f;
		char* st=new char[200],qw,aa=0;
		f.Open("editor.sw1",CFile::modeRead);
		while(f.GetPosition()<f.GetLength())
		{
			f.Read(&qw,1);
			st[aa++]=qw;
		}
		st[aa]=0;
		f.Close();
			mode=M_NONE;
		OpenFromFile(st);
		char a[200];
		CWnd* cwnd=GetParentOwner();
		sprintf(a,"%s\0",&st);
		for(UINT q=0;q<strlen(a);q++)
			lost_file_name[q]=a[q];
		sprintf(a,"Editor : %s",st);
		cwnd->SetWindowText(a);
		delete st;
	}//open
	if(GetCaretBlinkTime()==575)
	{
		//��������� � ����
		SetCaretBlinkTime(500);
		CFile f;
		char* st=new char[200],qw,aa=0;
		f.Open("editor.sw1",CFile::modeRead);
		while(f.GetPosition()<f.GetLength())
		{
			f.Read(&qw,1);
			st[aa++]=qw;
		}
		st[aa]=0;
		f.Close();
			mode=M_NONE;
		SaveToFile(st);
		char a[200];
		CWnd* cwnd=GetParentOwner();
		sprintf(a,"%s\0",&st);
		for(UINT q=0;q<strlen(a);q++)
			lost_file_name[q]=a[q];
		sprintf(a,"Editor : %s",st);
		cwnd->SetWindowText(a);
		strcpy(lost_file_name,st);
		delete st;
	}//open

	if(GetCaretBlinkTime()==577)
	{
		//����� ����
		SetCaretBlinkTime(500);
		but_kol=edit_kol=text_kol=0;
		char a[200];
		CWnd* cwnd=GetParentOwner();
		strcpy(lost_file_name,"\0");
		sprintf(a,"Editor : Untitled");
		cwnd->SetWindowText(a);
	}

	if(ren_dlg.renaming==1)
	{
		//��� �������� ������� '��������'
		ren_dlg.renaming=0;
		ren_dlg.GetDlgItemText(IDC_EDIT1,but_text[lost_num]);
		if(but_text[lost_num].GetLength()>255)
			but_text[lost_num]=but_text[lost_num].Left(255);
		AlignButton(lost_num);
		RedrawButton(lost_num);
	}//rename button
	if(prop_dlg.propertying==1)
	{
		//��� �������� ������� '��������'
		prop_dlg.propertying=0;
		AlignTextedit(lost_num);
		RedrawTextedit(lost_num);
	}//rename button
	if(text_dlg.texting==1)
	{
		//��� �������� ������� '��������'
		text_dlg.texting=0;
		text_dlg.GetDlgItemText(IDC_EDIT1,text_text[lost_num]);
		if(text_text[lost_num].GetLength()>255)
			text_text[lost_num]=text_text[lost_num].Left(255);
		AlignText(lost_num);
		RedrawText(lost_num);
	}//rename button

	if(options_dlg.change_options==-1)
	{
		//��� �������� ������� '�����'
		options_dlg.change_options=0;
		options_dlg.GetDlgItemText(IDC_EDIT_BUTTON,default_but_text);
		options_dlg.GetDlgItemText(IDC_EDIT_TEXTEDIT,default_edit_text);
		options_dlg.GetDlgItemText(IDC_EDIT_TEXT,default_text_text);
	}//options changed

	UpdateTable();
	
	CView::OnTimer(nIDEvent);
}

void CEditorView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	//�������
	int q,w,e;
	// TODO: Add your message handler code here and/or call default
	if(mode==M_EDIT)
		edit[mode_num].GetWindowText(edit_text[mode_num]),
		edit[mode_num].BeginModalState(),
		mode=M_NONE;
	int x1,x2,y1,y2;
	if(mode==M_MOVE)
	{
		switch(mode_type){
		case T_BUTTON:
			but[mode_num].DestroyWindow();
			SwapButtons(mode_num,but_kol-1);
			but_kol-=1;
			mode=M_NONE;
			for(w=0;w<but_kol;w++)
				RedrawButton(w);
			SendMessage(WM_PAINT);
			return;
			break;
		case T_TEXTEDIT:
			edit[mode_num].DestroyWindow();
			SwapTextedits(mode_num,edit_kol-1);
			edit_kol-=1;
			mode=M_NONE;
			for(w=0;w<edit_kol;w++)
				RedrawTextedit(w);
			SendMessage(WM_PAINT);
			return;
			break;
		case T_TEXT:
			text[mode_num].DestroyWindow();

			SwapTexts(mode_num,text_kol-1);
			text_kol-=1;
			mode=M_NONE;
			for(w=0;w<text_kol;w++)
				RedrawText(w);
			SendMessage(WM_PAINT);
			return;
			break;
		}//switch mode_type
	}
	for(q=0;q<but_kol;q++)
	if( mouse_x+5 >=but_rect[q].left  &&
		mouse_x+5<=but_rect[q].right &&
		mouse_y+30>=but_rect[q].top   &&
		mouse_y+30<=but_rect[q].bottom)
	{
		x1=(but_rect[q].left-5)/40;
		x2=(but_rect[q].right-5)/40;
		y1=(but_rect[q].top-30)/40;
		y2=(but_rect[q].bottom-30)/40;
		RB_go=1;
		for(w=0;w<but_kol;w++)
			but[w].DestroyWindow();
		SwapButtons(q,but_kol-1);
		but_kol-=1;
		for(w=0;w<but_kol;w++)
		{
			but[w].Create(but_text[w],0,but_rect[w],GetParentOwner(),w);
			but[w].CloseWindow();
			but[w].BeginModalState();
			but[w].SetButtonStyle(WS_DISABLED);
			but[w].ShowWindow(SW_NORMAL);
			but[w].BringWindowToTop();
			but[w].UpdateWindow();
		}//q
		RB_go=0;
		for(w=y1;w<=y2;w++)
		for(e=x1;e<=x2;e++)
			table[e][w].type=T_NONE;
		mode=M_NONE;
	}//for q
	for(q=0;q<edit_kol;q++)
	if( mouse_x+5 >=edit_rect[q].left  &&
		mouse_x+5<=edit_rect[q].right &&
		mouse_y+30>=edit_rect[q].top   &&
		mouse_y+30<=edit_rect[q].bottom)
	{
		x1=(edit_rect[q].left-5)/40;
		x2=(edit_rect[q].right-5)/40;
		y1=(edit_rect[q].top-30)/40;
		y2=(edit_rect[q].bottom-30)/40;
		RB_go=1;
		for(w=0;w<edit_kol;w++)
			edit[w].DestroyWindow();
		SwapTextedits(q,edit_kol-1);
		edit_kol-=1;
		for(w=0;w<edit_kol;w++)
		{
			edit[w].Create(0,edit_rect[w],GetParentOwner(),w);
			edit[w].CloseWindow();
			edit[w].BeginModalState();
			edit[w].SetWindowText(edit_text[w]);
			edit[w].ShowWindow(SW_NORMAL);
			edit[w].BringWindowToTop();
			edit[w].UpdateWindow();
		}//q
		RB_go=0;
		for(w=y1;w<=y2;w++)
		for(e=x1;e<=x2;e++)
			table[e][w].type=T_NONE;
		mode=M_NONE;
	}//for q
	for(q=0;q<text_kol;q++)
	if( mouse_x+5 >=text_rect[q].left  &&
		mouse_x+5<=text_rect[q].right &&
		mouse_y+30>=text_rect[q].top   &&
		mouse_y+30<=text_rect[q].bottom)
	{
		x1=(text_rect[q].left-5)/40;
		x2=(text_rect[q].right-5)/40;
		y1=(text_rect[q].top-30)/40;
		y2=(text_rect[q].bottom-30)/40;
		RB_go=1;
		for(w=0;w<text_kol;w++)
			text[w].DestroyWindow();
		SwapTexts(q,text_kol-1);
		text_kol-=1;
		for(w=0;w<text_kol;w++)
		{
			text[w].Create(TEXT_STYLE,text_rect[w],GetParentOwner(),w);
			text[w].ShowWindow(SW_NORMAL);
			text[w].UpdateWindow();
			text[w].SetWindowText(text_text[w]);
		}//q
		RB_go=0;
		for(w=y1;w<=y2;w++)
		for(e=x1;e<=x2;e++)
			table[e][w].type=T_NONE;
		mode=M_NONE;
	}//for q

	ren_dlg.ShowWindow(SW_HIDE);

	
	CView::OnRButtonDown(nFlags, point);
}

void CEditorView::RedrawButton(int a)
{
	//������������ Button (������������,����� ���������� ����������)
	if(RB_go==1) return;
	RB_go=1;
	but[a].DestroyWindow();
	but[a].Create(but_text[a],0,but_rect[a],GetParentOwner(),a);
	but[a].CloseWindow();
	but[a].BeginModalState();
	but[a].SetButtonStyle(WS_DISABLED);
	but[a].ShowWindow(SW_NORMAL);
	but[a].BringWindowToTop();
	but[a].UpdateWindow();
	RB_go=0;
}

void CEditorView::UpdateTable()
{
	//�������� �������
	int q,w,e;
	static x1,x2,y1,y2;

	for(w=0;w<20;w++)
	for(q=0;q<20;q++)
		table[q][w].type=T_NONE,
		table[q][w].is=T_NONE;
	for(q=0;q<but_kol;q++)
	{
		if(!(mode==M_MOVE && mode_type==T_BUTTON && mode_num==q))
		{
		x1=(but_rect[q].left-5)/40;
		x2=(but_rect[q].right-5)/40;
		y1=(but_rect[q].top-30)/40;
		y2=(but_rect[q].bottom-30)/40;
		for(w=y1;w<=y2;w++)
		for(e=x1;e<=x2;e++)
			table[e][w].type=T_BLOCKED,
			table[e][w].is=T_BUTTON;
		table[x1][y1].type=T_BUTTON;
		table[x1][y1].colspan=x2-x1+1;
		table[x1][y1].rowspan=y2-y1+1;
		table[x1][y1].num=q;
		}
	}//for w
	for(q=0;q<edit_kol;q++)
	{
		if(!(mode==M_MOVE && mode_type==T_TEXTEDIT && mode_num==q))
		{
		x1=(edit_rect[q].left-5)/40;
		x2=(edit_rect[q].right-5)/40;
		y1=(edit_rect[q].top-30)/40;
		y2=(edit_rect[q].bottom-30)/40;
		for(e=x1;e<=x2;e++)
			table[e][y1].type=T_BLOCKED,
			table[e][y1].is=T_TEXTEDIT;
		table[x1][y1].type=T_TEXTEDIT;
		table[x1][y1].colspan=x2-x1+1;
		table[x1][y1].rowspan=y2-y1+1;
		table[x1][y1].num=q;
		}
	}//for q
	for(q=0;q<text_kol;q++)
	{
		if(!(mode==M_MOVE && mode_type==T_TEXT && mode_num==q))
		{
		x1=(text_rect[q].left-5)/40;
		x2=(text_rect[q].right-5)/40;
		y1=(text_rect[q].top-30)/40;
		y2=(text_rect[q].bottom-30)/40;
		for(w=y1;w<=y2;w++)
		for(e=x1;e<=x2;e++)
			table[e][w].type=T_BLOCKED,
			table[e][w].is=T_TEXT;
		table[x1][y1].type=T_TEXT;
		table[x1][y1].colspan=x2-x1+1;
		table[x1][y1].rowspan=y2-y1+1;
		table[x1][y1].num=q;
		}
	}//for q
}

void CEditorView::OnUpdateButtonExport(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable();
	
}

void CEditorView::OnButtonExport() 
{
	//�������������� � HTML
	int q,w,e;
	exp_dlg.ShowWindow(SW_NORMAL);
	// TODO: Add your command handler code here
	if(mode==M_EDIT)//���� ������ ������������� textedit
		edit[mode_num].GetWindowText(edit_text[mode_num]),
		edit[mode_num].BeginModalState(),
		mode=M_NONE;
	CFile f;
	CString name;
	name="Export.html";
	char* a;
	a=new char[5000];
	if(f.Open(name,CFile::modeWrite | CFile::modeCreate)==FALSE)
	{
		name="Export.html";
		f.Open(name,CFile::modeWrite | CFile::modeCreate);
	}
	sprintf(a,"<HTML>\r\n<BODY>\r\n<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0>");
	f.Write(a,strlen(a));

	sprintf(a,"<TR>\r\n <TD WIDTH=1 HEIGHT=1></TD>\r\n");
	f.Write(a,strlen(a));
	for(q=0;q<19;q++)
	{
		sprintf(a,"<TD WIDTH=40 HEIGHT=1></TD>");
		f.Write(a,strlen(a));
	}//q

	for(w=0;w<12;w++)
	{
		sprintf(a,"<TR><TD WIDTH=1 HEIGHT=40></TD>");
		f.Write(a,strlen(a));
	for(q=0;q<19;q++)
	{
		switch(table[q][w].type)
		{
		case T_BUTTON:
			sprintf(a,"\r\n<TD COLSPAN=%u ROWSPAN=%u ",
				table[q][w].colspan,
				table[q][w].rowspan
				);
			f.Write(a,strlen(a));
				sprintf(a,"ALIGN=LEFT ");
			f.Write(a,strlen(a));
				sprintf(a,"VALIGN=TOP>");
			f.Write(a,strlen(a));
			sprintf(a,"<INPUT TYPE=\"BUTTON\" STYLE=\"WIDTH:%u;HEIGHT:%u\" VALUE=\"",
				but_rect[table[q][w].num].right-but_rect[table[q][w].num].left+1,
				but_rect[table[q][w].num].bottom-but_rect[table[q][w].num].top+1);
			f.Write(a,strlen(a));
			for(e=0;e<but_text[table[q][w].num].GetLength();e++)
			{
				if(but_text[table[q][w].num].Mid(e,1)==' ')
					if(e==but_text[table[q][w].num].GetLength()-1)
						sprintf(a,"&nbsp ");
					else
						if(but_text[table[q][w].num].Mid(e+1,1)==' ')
							sprintf(a,"&nbsp");
						else
							sprintf(a,"&nbsp ");
				else
					sprintf(a,"%s",but_text[table[q][w].num].Mid(e,1));
				f.Write(a,strlen(a));
			}
			sprintf(a,"\"></TD>\r\n");
			f.Write(a,strlen(a));
			break;
		case T_TEXTEDIT:
			sprintf(a,"\r\n<TD COLSPAN=%u ROWSPAN=1 ",
				table[q][w].colspan);
			f.Write(a,strlen(a));
				sprintf(a,"ALIGN=LEFT ");
			f.Write(a,strlen(a));
				sprintf(a,"VALIGN=TOP>");
			f.Write(a,strlen(a));
			sprintf(a,"<INPUT STYLE=\"WIDTH: %u; HEIGHT: %u\" VALUE=\"",
				edit_rect[table[q][w].num].right-edit_rect[table[q][w].num].left+1,
				edit_rect[table[q][w].num].bottom-edit_rect[table[q][w].num].top+1);
			f.Write(a,strlen(a));
			for(e=0;e<edit_text[table[q][w].num].GetLength();e++)
			{
				if(edit_text[table[q][w].num].Mid(e,1)==' ')
					if(e==edit_text[table[q][w].num].GetLength()-1)
						sprintf(a,"&nbsp ");
					else
						if(edit_text[table[q][w].num].Mid(e+1,1)==' ')
							sprintf(a,"&nbsp");
						else
							sprintf(a,"&nbsp ");
				else
					sprintf(a,"%s",edit_text[table[q][w].num].Mid(e,1));
				f.Write(a,strlen(a));
			}
			sprintf(a,"\"></TD>\r\n");
			f.Write(a,strlen(a));
			break;
		case T_TEXT:
			sprintf(a,"\r\n<TD COLSPAN=%u ROWSPAN=%u ",
				table[q][w].colspan,
				table[q][w].rowspan);
			f.Write(a,strlen(a));
				sprintf(a,"ALIGN=LEFT ");
			f.Write(a,strlen(a));
				sprintf(a,"VALIGN=TOP>");
			f.Write(a,strlen(a));
			for(e=0;e<text_text[table[q][w].num].GetLength();e++)
			{
				if(text_text[table[q][w].num].Mid(e,1)==13)
				{
					e++;
					sprintf(a,"<BR>");
					f.Write(a,strlen(a));
				}
				else
				if(text_text[table[q][w].num].Mid(e,1)==' ')
					if(e==text_text[table[q][w].num].GetLength()-1)
						sprintf(a,"&nbsp ");
					else
						if(text_text[table[q][w].num].Mid(e+1,1)==' ')
							sprintf(a,"&nbsp");
						else
							sprintf(a,"&nbsp ");
				else
					sprintf(a,"%s",text_text[table[q][w].num].Mid(e,1));
				f.Write(a,strlen(a));
			}
			sprintf(a,"</TD>\r\n");
			f.Write(a,strlen(a));
			break;
		case T_NONE:
			sprintf(a,"\r\n<TD WIDTH=40 HEIGHT=40></TD>");
			f.Write(a,strlen(a));
			break;
		}//switch
	}//q
		sprintf(a,"\r\n</TR>");
		f.Write(a,strlen(a));
	}//w

	sprintf(a,"\r\n</TR>\r\n");
	f.Write(a,strlen(a));

	sprintf(a,"</TABLE>\r\n</BODY>\r\n</HTML>");
	f.Write(a,strlen(a));
	f.Close();
	delete a;
	exp_dlg.ShowWindow(SW_HIDE);
	
}

void CEditorView::AlignButton(int a)
{
	//������������ ��������� ��� �������
		int dx;
			dx=(but_rect[a].left-5)/40;
			dx=dx*40+5;
			dx-=but_rect[a].left;
			but_rect[a].left+=dx;
			but_rect[a].right+=dx;
			dx=(but_rect[a].top-30)/40;
			dx=dx*40+30;
			dx-=but_rect[a].top;
			but_rect[a].top+=dx;
			but_rect[a].bottom+=dx;

}

void CEditorView::OnDestroy() 
{
	int q;
	for(q=0;q<but_kol;q++)
		but[q].DestroyWindow();
	for(q=0;q<edit_kol;q++)
		edit[q].DestroyWindow();
	for(q=0;q<text_kol;q++)
		text[q].DestroyWindow();
	ren_dlg.DestroyWindow();
	exp_dlg.DestroyWindow();
	prop_dlg.DestroyWindow();
	text_dlg.DestroyWindow();
	DeleteFile("editor.swp");
	DeleteFile("Editor.sw1");
	DeleteFile("Editor.sw2");
	SaveConfig();


	CView::OnDestroy();
	
	// TODO: Add your message handler code here
}

void CEditorView::OnUpdateEditCut(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable();
	
}

BOOL CEditorView::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	SetCursor(cursor);
	
	return CView::OnEraseBkgnd(pDC);
}

void CEditorView::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CView::OnShowWindow(bShow, nStatus);
	
	// TODO: Add your message handler code here
	SetCursor(cursor);
	
}

void CEditorView::OnUpdateButtonProperty(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable();
	
}

void CEditorView::OnButtonProperty() 
{
	//������ ������ Property (�������� ��������)
	// TODO: Add your command handler code here
	if(mode==M_EDIT)
		edit[mode_num].GetWindowText(edit_text[mode_num]),
		edit[mode_num].BeginModalState(),
		mode=M_NONE;
	if(mode==M_MOVE) return;
	if(lost_num<but_kol && lost_type==T_BUTTON)
	{
		ren_dlg.ShowWindow(SW_NORMAL);
		ren_dlg.UpdateWindow();
		ren_dlg.SetDlgItemText(IDC_EDIT1,but_text[lost_num]);
		ren_dlg.MoveWindow(5,30,5+280,30+65);
	}
	if(lost_num<edit_kol && lost_type==T_TEXTEDIT)
	{
		mode=M_EDIT;
		mode_num=lost_num;
		mode_type=T_TEXTEDIT;
		edit[lost_num].EndModalState();
		edit[lost_num].SetWindowText(edit_text[lost_num]);
	}
	if(lost_num<text_kol && lost_type==T_TEXT)
	{
		text_dlg.ShowWindow(SW_NORMAL);
		text_dlg.UpdateWindow();
		text_dlg.SetDlgItemText(IDC_EDIT1,text_text[lost_num]);
		text_dlg.MoveWindow(5,30,5+405,30+240);
	}
	
}

void CEditorView::OnUpdateNewEdit(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable();
}

void CEditorView::OnNewEdit() 
{
	int q;
	// TODO: Add your command handler code here
	//������� Textedit
	if(edit_kol>=max_items) return;
	if(mode==M_EDIT)
		edit[mode_num].GetWindowText(edit_text[mode_num]),
		edit[mode_num].BeginModalState(),
		mode=M_NONE;

	if(mode==M_MOVE)
	{
		switch(mode_type)
		{
		case T_BUTTON:
			if(mode_num==but_kol-1)
			{
				but[mode_num].DestroyWindow();
				but_kol-=1;
			}
			else 
			{
				for(q=0;q<but_kol;q++)
					but[q].DestroyWindow();
				SwapButtons(mode_num,but_kol-1);
				but_kol-=1;
				for(q=0;q<but_kol;q++)
				{
					but[q].Create(but_text[q],0,but_rect[q],GetParentOwner(),q);
					but[q].CloseWindow();
					but[q].BeginModalState();
					but[q].SetButtonStyle(WS_DISABLED);
					but[q].ShowWindow(SW_NORMAL);
					but[q].BringWindowToTop();
					but[q].UpdateWindow();
				}//q
			}
			break;
		case T_TEXTEDIT:
			if(mode_num==edit_kol-1)
			{
				edit[mode_num].DestroyWindow();
				edit_kol-=1;
			}
			else 
			{
				for(q=0;q<edit_kol;q++)
					edit[q].DestroyWindow();
				SwapTextedits(mode_num,edit_kol-1);
				edit_kol-=1;
				for(q=0;q<edit_kol;q++)
				{
					edit[q].Create(0,edit_rect[q],GetParentOwner(),q);
					edit[q].CloseWindow();
					edit[q].BeginModalState();
					edit[q].ShowWindow(SW_NORMAL);
					edit[q].BringWindowToTop();
					edit[q].UpdateWindow();
				}//q
			}
			break;
		case T_TEXT:
			if(mode_num==text_kol-1)
			{
				text[mode_num].DestroyWindow();
				text_kol-=1;
			}
			else 
			{
				for(q=0;q<text_kol;q++)
					text[q].DestroyWindow();
				SwapTexts(mode_num,text_kol-1);
				text_kol-=1;
				for(q=0;q<text_kol;q++)
				{
					text[q].Create(TEXT_STYLE,text_rect[q],GetParentOwner(),q);
					text[q].ShowWindow(SW_NORMAL);
					text[q].UpdateWindow();
				}//q
			}
			break;
		}//switch mode_type
	}
	if(mouse_x>50 && mouse_x<750)
		edit_rect[edit_kol].left=mouse_x-19,
		edit_rect[edit_kol].right=mouse_x+20;
	else
		edit_rect[edit_kol].left=401,
		edit_rect[edit_kol].right=440;
	edit_rect[edit_kol].top=31;
	edit_rect[edit_kol].bottom=51;//69
	edit_text[edit_kol]=default_edit_text;
	edit[edit_kol].Create(0,edit_rect[edit_kol],GetParentOwner(),edit_kol);
	edit[edit_kol].CloseWindow();
	edit[edit_kol].BeginModalState();
	edit[edit_kol].SetForegroundWindow();
	edit[edit_kol].ShowWindow(SW_NORMAL);
	edit[edit_kol].SetWindowText(edit_text[edit_kol]);
	mode=M_MOVE;
	mode_type=T_TEXTEDIT;
	mode_num=edit_kol;
	lost_num=edit_kol;
	lost_type=T_TEXTEDIT;
	edit_kol+=1;

}

void CEditorView::SwapTextedits(int a, int b)
{
	//�������� ������� Textedit � ������� a � b
	static RECT z;
	static CString x;
	z.bottom=edit_rect[a].bottom;
	z.left=edit_rect[a].left;
	z.right=edit_rect[a].right;
	z.top=edit_rect[a].top;
	x=edit_text[a];
	edit_rect[a].bottom=edit_rect[b].bottom;
	edit_rect[a].left=edit_rect[b].left;
	edit_rect[a].right=edit_rect[b].right;
	edit_rect[a].top=edit_rect[b].top;
	edit_text[a]=edit_text[b];
	edit_rect[b].bottom=z.bottom;
	edit_rect[b].left=z.left;
	edit_rect[b].right=z.right;
	edit_rect[b].top=z.top;
	edit_text[b]=x;
}

void CEditorView::RedrawTextedit(int a)
{
	//������������ Textedit (������������,����� ���������� ����������)
	if(RB_go) return;
	RB_go=TRUE;
	edit[a].DestroyWindow();
	edit[a].Create(0,edit_rect[a],GetParentOwner(),a);
	edit[a].CloseWindow();
	edit[a].BeginModalState();
	edit[a].ShowWindow(SW_NORMAL);
	edit[a].SetWindowText(edit_text[a]);
	edit[a].BringWindowToTop();
	edit[a].UpdateWindow();
	RB_go=FALSE;
}

void CEditorView::AlignTextedit(int a)
{
	//������������ ��������� ��� �������
	int dx;
			dx=(edit_rect[a].left-5)/40;
			dx=dx*40+5;
			dx-=edit_rect[a].left;
			edit_rect[a].left+=dx;
			edit_rect[a].right+=dx;
			dx=(edit_rect[a].top-30)/40;
			dx=dx*40+30;
			dx-=edit_rect[a].top;
			edit_rect[a].top+=dx;
			edit_rect[a].bottom+=dx;
}

void CEditorView::OnUpdateNewText(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable();
	
}

void CEditorView::OnNewText()
{
	int q;
	// TODO: Add your command handler code here
	//������� Label
	if(text_kol>=max_items) return;
	if(mode==M_EDIT)
		edit[mode_num].GetWindowText(edit_text[mode_num]),
		edit[mode_num].BeginModalState(),
		mode=M_NONE;

	if(mode==M_MOVE)
	{
		switch(mode_type)
		{
		case T_BUTTON:
			if(mode_num==but_kol-1)
			{
				but[mode_num].DestroyWindow();
				but_kol-=1;
			}
			else 
			{
				for(q=0;q<but_kol;q++)
					but[q].DestroyWindow();
				SwapButtons(mode_num,but_kol-1);
				but_kol-=1;
				for(q=0;q<but_kol;q++)
				{
					but[q].Create(but_text[q],0,but_rect[q],GetParentOwner(),q);
					but[q].CloseWindow();
					but[q].BeginModalState();
					but[q].SetButtonStyle(WS_DISABLED);
					but[q].ShowWindow(SW_NORMAL);
					but[q].BringWindowToTop();
					but[q].UpdateWindow();
				}//q
			}
			break;
		case T_TEXTEDIT:
			if(mode_num==edit_kol-1)
			{
				edit[mode_num].DestroyWindow();
				edit_kol-=1;
			}
			else 
			{
				for(q=0;q<edit_kol;q++)
					edit[q].DestroyWindow();
				SwapTextedits(mode_num,edit_kol-1);
				edit_kol-=1;
				for(q=0;q<edit_kol;q++)
				{
					edit[q].Create(0,edit_rect[q],GetParentOwner(),q);
					edit[q].CloseWindow();
					edit[q].BeginModalState();
					edit[q].ShowWindow(SW_NORMAL);
					edit[q].BringWindowToTop();
					edit[q].UpdateWindow();
				}//q
			}
			break;
		case T_TEXT:
			if(mode_num==text_kol-1)
			{
				text[mode_num].DestroyWindow();
				text_kol-=1;
			}
			else 
			{
				for(q=0;q<text_kol;q++)
					text[q].DestroyWindow();
				SwapTexts(mode_num,text_kol-1);
				text_kol-=1;
				for(q=0;q<text_kol;q++)
				{
					text[q].Create(TEXT_STYLE,text_rect[q],GetParentOwner(),q);
					text[q].ShowWindow(SW_NORMAL);
					text[q].UpdateWindow();
				}//q
			}
			break;
		}//switch mode_type
	}
	if(mouse_x>50 && mouse_x<750)
		text_rect[text_kol].left=mouse_x-19,
		text_rect[text_kol].right=mouse_x+20;
	else
		text_rect[text_kol].left=401,
		text_rect[text_kol].right=440;
	text_rect[text_kol].top=31;
	text_rect[text_kol].bottom=70;
	text_text[text_kol]=default_text_text;
	text[text_kol].Create(TEXT_STYLE,text_rect[text_kol],GetParentOwner(),text_kol);

	mode=M_MOVE;
	mode_type=T_TEXT;
	mode_num=text_kol;
	lost_num=text_kol;
	lost_type=T_TEXT;
	text_kol+=1;
	RedrawText(text_kol-1);	
}

void CEditorView::SwapTexts(int a, int b)
{
	//�������� ������� Text (Label) � ������� a � b
	static RECT z;
	static CString x;
	z.bottom=text_rect[a].bottom;
	z.left=text_rect[a].left;
	z.right=text_rect[a].right;
	z.top=text_rect[a].top;
	x=text_text[a];
	text_rect[a].bottom=text_rect[b].bottom;
	text_rect[a].left=text_rect[b].left;
	text_rect[a].right=text_rect[b].right;
	text_rect[a].top=text_rect[b].top;
	text_text[a]=text_text[b];
	text_rect[b].bottom=z.bottom;
	text_rect[b].left=z.left;
	text_rect[b].right=z.right;
	text_rect[b].top=z.top;
	text_text[b]=x;
}

void CEditorView::RedrawText(int a)
{
	//������������ Text(Label) (������������,����� ���������� ����������)
	if(RB_go) return;
	RB_go=TRUE;
	text[a].DestroyWindow();
	text[a].Create(TEXT_STYLE,text_rect[a],GetParentOwner(),a);
	text[a].SetWindowText(text_text[a]);
	text[a].ShowWindow(SW_NORMAL);
	text[a].UpdateWindow();

	RB_go=FALSE;
}

void CEditorView::AlignText(int a)
{
	//������������ ��������� ��� �������
		int dx;
			dx=(text_rect[a].left-5)/40;
			dx=dx*40+5;
			dx-=text_rect[a].left;
			text_rect[a].left+=dx;
			text_rect[a].right+=dx;
			dx=(text_rect[a].top-30)/40;
			dx=dx*40+30;
			dx-=text_rect[a].top;
			text_rect[a].top+=dx;
			text_rect[a].bottom+=dx;

}

void CEditorView::OnUpdateEditDelete(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}

void CEditorView::OnEditDelete() 
{
	int w;
	// TODO: Add your command handler code here
	//�������
	switch(lost_type)
	{
	case T_BUTTON:
		if(mode==M_MOVE)
		{
			but[mode_num].DestroyWindow();
			SwapButtons(mode_num,but_kol-1);
			but_kol-=1;
			mode=M_NONE;
			for(w=0;w<but_kol;w++)
				RedrawButton(w);
			SendMessage(WM_PAINT);
		}
		else
		{
		RB_go=1;
		for(w=0;w<but_kol;w++)
			but[w].DestroyWindow();
		SwapButtons(lost_num,but_kol-1);
		but_kol-=1;
		for(w=0;w<but_kol;w++)
		{
			but[w].Create(but_text[w],0,but_rect[w],GetParentOwner(),w);
			but[w].CloseWindow();
			but[w].BeginModalState();
			but[w].SetButtonStyle(WS_DISABLED);
			but[w].ShowWindow(SW_NORMAL);
			but[w].BringWindowToTop();
			but[w].UpdateWindow();
		}//q
		RB_go=0;
		mode=M_NONE;
		}
		break;
	case T_TEXTEDIT:
		if(mode==M_MOVE)
		{
			edit[mode_num].DestroyWindow();
			SwapTextedits(mode_num,edit_kol-1);
			edit_kol-=1;
			mode=M_NONE;
			for(w=0;w<edit_kol;w++)
				RedrawTextedit(w);
			SendMessage(WM_PAINT);
		}
		else
		{
		RB_go=1;
		for(w=0;w<edit_kol;w++)
			edit[w].DestroyWindow();
		SwapTextedits(lost_num,edit_kol-1);
		edit_kol-=1;
		for(w=0;w<edit_kol;w++)
		{
			edit[w].Create(0,edit_rect[w],GetParentOwner(),w);
			edit[w].CloseWindow();
			edit[w].BeginModalState();
			edit[w].SetWindowText(edit_text[w]);
			edit[w].ShowWindow(SW_NORMAL);
			edit[w].BringWindowToTop();
			edit[w].UpdateWindow();
		}//q
		RB_go=0;
		mode=M_NONE;
		}
		break;
	case T_TEXT:
		if(mode==M_MOVE)
		{
			text[mode_num].DestroyWindow();
			SwapTexts(mode_num,text_kol-1);
			text_kol-=1;
			mode=M_NONE;
			for(w=0;w<text_kol;w++)
				RedrawText(w);
			SendMessage(WM_PAINT);
		}
		else
		{
		RB_go=1;
		for(w=0;w<text_kol;w++)
			text[w].DestroyWindow();
		SwapTexts(lost_num,text_kol-1);
		text_kol-=1;
		for(w=0;w<text_kol;w++)
		{
			text[w].Create(TEXT_STYLE,text_rect[w],GetParentOwner(),w);
			text[w].ShowWindow(SW_NORMAL);
			text[w].UpdateWindow();
			text[w].SetWindowText(text_text[w]);
		}//q
		RB_go=0;
		mode=M_NONE;
		}
		break;
	}//case type
	lost_type=T_NONE;
	
}

void CEditorView::OnEditCut() 
{
	int w;
	// TODO: Add your command handler code here
	//����������� � ����� � �������
	switch(lost_type)
	{
	case T_BUTTON:
		if(mode==M_MOVE)
		{
			but[mode_num].DestroyWindow();
			SwapButtons(mode_num,but_kol-1);
			but_kol-=1;
			mode=M_NONE;
			buf=TRUE;
			buf_type=T_BUTTON;
			buf_rect.bottom=but_rect[mode_num].bottom;
			buf_rect.left=but_rect[mode_num].left;
			buf_rect.right=but_rect[mode_num].right;
			buf_rect.top=but_rect[mode_num].top;
			buf_text=but_text[mode_num];
			for(w=0;w<but_kol;w++)
				RedrawButton(w);
			SendMessage(WM_PAINT);
		}
		else
		{
		RB_go=1;
		
		buf=TRUE;
		buf_type=T_BUTTON;
		buf_rect.bottom=but_rect[lost_num].bottom;
		buf_rect.left=but_rect[lost_num].left;
		buf_rect.right=but_rect[lost_num].right;
		buf_rect.top=but_rect[lost_num].top;
		buf_text=but_text[lost_num];
	
		for(w=0;w<but_kol;w++)
			but[w].DestroyWindow();
		SwapButtons(lost_num,but_kol-1);
		but_kol-=1;
		for(w=0;w<but_kol;w++)
		{
			but[w].Create(but_text[w],0,but_rect[w],GetParentOwner(),w);
			but[w].CloseWindow();
			but[w].BeginModalState();
			but[w].SetButtonStyle(WS_DISABLED);
			but[w].ShowWindow(SW_NORMAL);
			but[w].BringWindowToTop();
			but[w].UpdateWindow();
		}//q
		RB_go=0;
		mode=M_NONE;
		}
		break;
	case T_TEXTEDIT:
		if(mode==M_MOVE)
		{
			edit[mode_num].DestroyWindow();
			buf=TRUE;
			buf_type=T_TEXTEDIT;
			buf_rect.bottom=edit_rect[mode_num].bottom;
			buf_rect.left=edit_rect[mode_num].left;
			buf_rect.right=edit_rect[mode_num].right;
			buf_rect.top=edit_rect[mode_num].top;
			buf_text=edit_text[mode_num];
			SwapTextedits(mode_num,edit_kol-1);
			edit_kol-=1;
			mode=M_NONE;
			for(w=0;w<edit_kol;w++)
				RedrawTextedit(w);
			SendMessage(WM_PAINT);
		}
		else
		{
		RB_go=1;
		for(w=0;w<edit_kol;w++)
			edit[w].DestroyWindow();
		buf=TRUE;
		buf_type=T_TEXTEDIT;
		buf_rect.bottom=edit_rect[lost_num].bottom;
		buf_rect.left=edit_rect[lost_num].left;
		buf_rect.right=edit_rect[lost_num].right;
		buf_rect.top=edit_rect[lost_num].top;
		buf_text=edit_text[lost_num];
		SwapTextedits(lost_num,edit_kol-1);
		edit_kol-=1;
		for(w=0;w<edit_kol;w++)
		{
			edit[w].Create(0,edit_rect[w],GetParentOwner(),w);
			edit[w].CloseWindow();
			edit[w].BeginModalState();
			edit[w].SetWindowText(edit_text[w]);
			edit[w].ShowWindow(SW_NORMAL);
			edit[w].BringWindowToTop();
			edit[w].UpdateWindow();
		}//q
		RB_go=0;
		mode=M_NONE;
		}
		break;
	case T_TEXT:
		if(mode==M_MOVE)
		{
			text[mode_num].DestroyWindow();
			buf=TRUE;
			buf_type=T_TEXT;
			buf_rect.bottom=text_rect[mode_num].bottom;
			buf_rect.left=text_rect[mode_num].left;
			buf_rect.right=text_rect[mode_num].right;
			buf_rect.top=text_rect[mode_num].top;
			buf_text=text_text[mode_num];
			SwapTexts(mode_num,text_kol-1);
			text_kol-=1;
			mode=M_NONE;
			for(w=0;w<text_kol;w++)
				RedrawText(w);
			SendMessage(WM_PAINT);
		}
		else
		{
		RB_go=1;
		for(w=0;w<text_kol;w++)
			text[w].DestroyWindow();
		buf_type=T_TEXT;
		buf_rect.bottom=text_rect[lost_num].bottom;
		buf_rect.left=text_rect[lost_num].left;
		buf_rect.right=text_rect[lost_num].right;
		buf_rect.top=text_rect[lost_num].top;
		buf_text=text_text[lost_num];
		SwapTexts(lost_num,text_kol-1);
		text_kol-=1;
		for(w=0;w<text_kol;w++)
		{
			text[w].Create(TEXT_STYLE,text_rect[w],GetParentOwner(),w);
			text[w].ShowWindow(SW_NORMAL);
			text[w].UpdateWindow();
			text[w].SetWindowText(text_text[w]);
		}//q
		RB_go=0;
		mode=M_NONE;
		}
		break;
	}//case type
	lost_type=T_NONE;
	
}

void CEditorView::OnUpdateEditCopy(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}

void CEditorView::OnEditCopy() 
{
	// TODO: Add your command handler code here
	//��������� � �����
	buf=FALSE;
	switch(lost_type)
	{
	case T_BUTTON:
		buf=TRUE;
		buf_type=T_BUTTON;
		buf_rect.bottom=but_rect[lost_num].bottom;
		buf_rect.left=but_rect[lost_num].left;
		buf_rect.right=but_rect[lost_num].right;
		buf_rect.top=but_rect[lost_num].top;
		buf_text=but_text[lost_num];
		break;
	case T_TEXTEDIT:
		buf=TRUE;
		buf_type=T_TEXTEDIT;
		buf_rect.bottom=edit_rect[lost_num].bottom;
		buf_rect.left=edit_rect[lost_num].left;
		buf_rect.right=edit_rect[lost_num].right;
		buf_rect.top=edit_rect[lost_num].top;
		buf_text=edit_text[lost_num];
		break;
	case T_TEXT:
		buf=TRUE;
		buf_type=T_TEXT;
		buf_rect.bottom=text_rect[lost_num].bottom;
		buf_rect.left=text_rect[lost_num].left;
		buf_rect.right=text_rect[lost_num].right;
		buf_rect.top=text_rect[lost_num].top;
		buf_text=text_text[lost_num];
		break;
	}
	
}

void CEditorView::OnEditPaste() 
{
	int q;
	// TODO: Add your command handler code here
	//�������� �� ������
	if(buf==FALSE) return;
	switch(buf_type)
	{
	case T_BUTTON:

	// TODO: Add your command handler code here
	if(but_kol==max_items) return;
	if(mode==M_EDIT)
		edit[mode_num].GetWindowText(edit_text[mode_num]),
		edit[mode_num].BeginModalState(),
		mode=M_NONE;

	if(mode==M_MOVE)
	{
		switch(mode_type)
		{
		case T_BUTTON:
			if(mode_num==but_kol-1)
			{
				but[mode_num].DestroyWindow();
				but_kol-=1;
			}
			else 
			{
				for(q=0;q<but_kol;q++)
					but[q].DestroyWindow();
				SwapButtons(mode_num,but_kol-1);
				but_kol-=1;
				for(q=0;q<but_kol;q++)
				{
					but[q].Create(but_text[q],0,but_rect[q],GetParentOwner(),q);
					but[q].CloseWindow();
					but[q].BeginModalState();
					but[q].SetButtonStyle(WS_DISABLED);
					but[q].ShowWindow(SW_NORMAL);
					but[q].BringWindowToTop();
					but[q].UpdateWindow();
				}//q
			}
			break;
		case T_TEXTEDIT:
			if(mode_num==edit_kol-1)
			{
				edit[mode_num].DestroyWindow();
				edit_kol-=1;
			}
			else 
			{
				for(q=0;q<edit_kol;q++)
					edit[q].DestroyWindow();
				SwapTextedits(mode_num,edit_kol-1);
				edit_kol-=1;
				for(q=0;q<edit_kol;q++)
				{
					edit[q].Create(0,but_rect[q],GetParentOwner(),q);
					edit[q].CloseWindow();
					edit[q].BeginModalState();
					edit[q].ShowWindow(SW_NORMAL);
					edit[q].BringWindowToTop();
					edit[q].UpdateWindow();
				}//q
			}
			break;
		case T_TEXT:
			if(mode_num==text_kol-1)
			{
				text[mode_num].DestroyWindow();
				text_kol-=1;
			}
			else 
			{
				for(q=0;q<text_kol;q++)
					text[q].DestroyWindow();
				SwapTexts(mode_num,text_kol-1);
				text_kol-=1;
				for(q=0;q<text_kol;q++)
				{
					text[q].Create(TEXT_STYLE,text_rect[q],GetParentOwner(),q);
					text[q].ShowWindow(SW_NORMAL);
					text[q].UpdateWindow();
				}//q
			}
			break;
		}//switch mode_type
	}
	but_rect[but_kol].left=buf_rect.left,
	but_rect[but_kol].right=buf_rect.right;
	but_rect[but_kol].top=buf_rect.top;
	but_rect[but_kol].bottom=buf_rect.bottom;//69
	but_text[but_kol]=buf_text;
	but[but_kol].Create(but_text[but_kol],0,but_rect[but_kol],GetParentOwner(),but_kol);
	but[but_kol].CloseWindow();
	but[but_kol].BeginModalState();
	but[but_kol].ShowWindow(SW_NORMAL);
	but[but_kol].UpdateWindow();
	mode=M_MOVE;
	mode_type=T_BUTTON;
	mode_num=but_kol;
	lost_num=but_kol;
	lost_type=T_BUTTON;
	but_kol+=1;
		
		break;
	case T_TEXTEDIT:

	// TODO: Add your command handler code here
	if(edit_kol>=max_items) return;
	if(mode==M_EDIT)
		edit[mode_num].GetWindowText(edit_text[mode_num]),
		edit[mode_num].BeginModalState(),
		mode=M_NONE;

	if(mode==M_MOVE)
	{
		switch(mode_type)
		{
		case T_BUTTON:
			if(mode_num==but_kol-1)
			{
				but[mode_num].DestroyWindow();
				but_kol-=1;
			}
			else 
			{
				for(q=0;q<but_kol;q++)
					but[q].DestroyWindow();
				SwapButtons(mode_num,but_kol-1);
				but_kol-=1;
				for(q=0;q<but_kol;q++)
				{
					but[q].Create(but_text[q],0,but_rect[q],GetParentOwner(),q);
					but[q].CloseWindow();
					but[q].BeginModalState();
					but[q].SetButtonStyle(WS_DISABLED);
					but[q].ShowWindow(SW_NORMAL);
					but[q].BringWindowToTop();
					but[q].UpdateWindow();
				}//q
			}
			break;
		case T_TEXTEDIT:
			if(mode_num==edit_kol-1)
			{
				edit[mode_num].DestroyWindow();
				edit_kol-=1;
			}
			else 
			{
				for(q=0;q<edit_kol;q++)
					edit[q].DestroyWindow();
				SwapTextedits(mode_num,edit_kol-1);
				edit_kol-=1;
				for(q=0;q<edit_kol;q++)
				{
					edit[q].Create(0,edit_rect[q],GetParentOwner(),q);
					edit[q].CloseWindow();
					edit[q].BeginModalState();
					edit[q].ShowWindow(SW_NORMAL);
					edit[q].BringWindowToTop();
					edit[q].UpdateWindow();
				}//q
			}
			break;
		case T_TEXT:
			if(mode_num==text_kol-1)
			{
				text[mode_num].DestroyWindow();
				text_kol-=1;
			}
			else 
			{
				for(q=0;q<text_kol;q++)
					text[q].DestroyWindow();
				SwapTexts(mode_num,text_kol-1);
				text_kol-=1;
				for(q=0;q<text_kol;q++)
				{
					text[q].Create(TEXT_STYLE,text_rect[q],GetParentOwner(),q);
					text[q].ShowWindow(SW_NORMAL);
					text[q].UpdateWindow();
				}//q
			}
			break;
		}//switch mode_type
	}
	edit_rect[edit_kol].left=buf_rect.left,
	edit_rect[edit_kol].right=buf_rect.right;
	edit_rect[edit_kol].top=buf_rect.top;
	edit_rect[edit_kol].bottom=buf_rect.bottom;//69
	edit_text[edit_kol]=buf_text;
	edit[edit_kol].Create(0,edit_rect[edit_kol],GetParentOwner(),edit_kol);
	edit[edit_kol].CloseWindow();
	edit[edit_kol].BeginModalState();
	edit[edit_kol].SetForegroundWindow();
	edit[edit_kol].ShowWindow(SW_NORMAL);
	edit[edit_kol].SetWindowText(edit_text[edit_kol]);
	mode=M_MOVE;
	mode_type=T_TEXTEDIT;
	mode_num=edit_kol;
	lost_num=edit_kol;
	lost_type=T_TEXTEDIT;
	edit_kol+=1;

		break;
	case T_TEXT:

	// TODO: Add your command handler code here
	if(text_kol>=max_items) return;
	if(mode==M_EDIT)
		edit[mode_num].GetWindowText(edit_text[mode_num]),
		edit[mode_num].BeginModalState(),
		mode=M_NONE;

	if(mode==M_MOVE)
	{
		switch(mode_type)
		{
		case T_BUTTON:
			if(mode_num==but_kol-1)
			{
				but[mode_num].DestroyWindow();
				but_kol-=1;
			}
			else 
			{
				for(q=0;q<but_kol;q++)
					but[q].DestroyWindow();
				SwapButtons(mode_num,but_kol-1);
				but_kol-=1;
				for(q=0;q<but_kol;q++)
				{
					but[q].Create(but_text[q],0,but_rect[q],GetParentOwner(),q);
					but[q].CloseWindow();
					but[q].BeginModalState();
					but[q].SetButtonStyle(WS_DISABLED);
					but[q].ShowWindow(SW_NORMAL);
					but[q].BringWindowToTop();
					but[q].UpdateWindow();
				}//q
			}
			break;
		case T_TEXTEDIT:
			if(mode_num==edit_kol-1)
			{
				edit[mode_num].DestroyWindow();
				edit_kol-=1;
			}
			else 
			{
				for(q=0;q<edit_kol;q++)
					edit[q].DestroyWindow();
				SwapTextedits(mode_num,edit_kol-1);
				edit_kol-=1;
				for(q=0;q<edit_kol;q++)
				{
					edit[q].Create(0,edit_rect[q],GetParentOwner(),q);
					edit[q].CloseWindow();
					edit[q].BeginModalState();
					edit[q].ShowWindow(SW_NORMAL);
					edit[q].BringWindowToTop();
					edit[q].UpdateWindow();
				}//q
			}
			break;
		case T_TEXT:
			if(mode_num==text_kol-1)
			{
				text[mode_num].DestroyWindow();
				text_kol-=1;
			}
			else 
			{
				for(q=0;q<text_kol;q++)
					text[q].DestroyWindow();
				SwapTexts(mode_num,text_kol-1);
				text_kol-=1;
				for(q=0;q<text_kol;q++)
				{
					text[q].Create(TEXT_STYLE,text_rect[q],GetParentOwner(),q);
					text[q].ShowWindow(SW_NORMAL);
					text[q].UpdateWindow();
				}//q
			}
			break;
		}//switch mode_type
	}
	text_rect[text_kol].left=buf_rect.left,
	text_rect[text_kol].right=buf_rect.right;
	text_rect[text_kol].top=buf_rect.top;
	text_rect[text_kol].bottom=buf_rect.bottom;//69
	text_text[text_kol]=buf_text;
	text[text_kol].Create(TEXT_STYLE,text_rect[text_kol],GetParentOwner(),text_kol);
	text[text_kol].CloseWindow();
	text[text_kol].SetForegroundWindow();
	text[text_kol].ShowWindow(SW_NORMAL);
	text[text_kol].UpdateWindow();
	text[text_kol].SetWindowText(text_text[text_kol]);

	mode=M_MOVE;
	mode_type=T_TEXT;
	mode_num=text_kol;
	lost_num=text_kol;
	lost_type=T_TEXT;
	text_kol+=1;

		break;
	}//switch buf_type
	
}

void CEditorView::OnUpdateEditPaste(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}

int CEditorView::SaveToFile(CString name)
{
	//��������� � ����
	int q;
	if(name.GetLength()==0)
	{
		MessageBox("Illegal file name.","Error!",MB_ICONSTOP);
		return -1;
	}
	int ok;
	ok=1;
	CFile f;
	char* a=new char[1000];
	if(f.Open(name,CFile::modeCreate | CFile::modeWrite)==FALSE)
	{
		MessageBox("Error",NULL,MB_ICONSTOP);
		return -1;
	}

	for(q=0;q<but_kol;q++)
	{
		if(mode==M_MOVE && mode_type==T_BUTTON && mode_num==q) continue;
		sprintf(a,"<Button left=\"%u\";top=\"%u\";bottom=\"%u\";right=\"%u\";Caption=\"%s\">\n",
			but_rect[q].left,
			but_rect[q].top,
			but_rect[q].bottom,
			but_rect[q].right,
			but_text[q]);
		f.Write(a,strlen(a));
	}//buttons
	for(q=0;q<edit_kol;q++)
	{
		if(mode==M_MOVE && mode_type==T_TEXTEDIT && mode_num==q) continue;
		sprintf(a,"<Textedit left=\"%u\";top=\"%u\";bottom=\"%u\";right=\"%u\";Text=\"%s\">\n",
			edit_rect[q].left,
			edit_rect[q].top,
			edit_rect[q].bottom,
			edit_rect[q].right,
			edit_text[q]);
		f.Write(a,strlen(a));
	}//textedits
	for(q=0;q<text_kol;q++)
	{
		if(mode==M_MOVE && mode_type==T_TEXT && mode_num==q) continue;
		sprintf(a,"<Label left=\"%u\";top=\"%u\";bottom=\"%u\";right=\"%u\";Text=\"%s\">\n",
			text_rect[q].left,
			text_rect[q].top,
			text_rect[q].bottom,
			text_rect[q].right,
			text_text[q]);
		f.Write(a,strlen(a));
	}//labels

	f.Close();
	lost_file=TRUE;
	strcpy(lost_file_name,name);
	return 1;
}

void CEditorView::OpenFromFile(CString name)
{
	//������� ����
	int q,w,e;
	if(name.GetLength()==0)
	{
		MessageBox("Illegal file name.","Error!",MB_ICONSTOP);
		return;
	}
	int ok,x1,x2,y1,y2;
	CString z;
	ok=1;
	char* a=new char[1000];
	if(f.Open(name,CFile::modeRead)==FALSE)
	{
		MessageBox("Error!",NULL,MB_ICONSTOP);
		return;
	}
	RB_go=1;
	for(q=0;q<max_items;q++)
		but_rect[q].bottom=0,
		but_rect[q].left=0,
		but_rect[q].right=0,
		but_rect[q].top=0;
	for(q=0;q<max_items;q++)
		edit_rect[q].bottom=0,
		edit_rect[q].left=0,
		edit_rect[q].right=0,
		edit_rect[q].top=0;
	for(q=0;q<max_items;q++)
		text_rect[q].bottom=0,
		text_rect[q].left=0,
		text_rect[q].right=0,
		text_rect[q].top=0;

	ok=1;
	mode=M_NONE;
	lost_type=T_NONE;

	init.bottom=init.left=init.right=init.start=init.top=0;
	init.text.Empty();
	init.type=T_NONE;init.pre=PRE_NONE;
	
	GetWordFromFile();
	ClearAll();
	UpdateTable();
	for(q=0;q<words_kol;q++)
	{
		if(words[q]=='<')
		{
			init.start=1;
			init.bottom=init.left=init.right=init.start=init.top=0;
			init.text.Empty();
			init.type=T_NONE;init.pre=PRE_NONE;
		}
		if(words[q].CompareNoCase("BUTTON")==0)
			init.type=T_BUTTON;
		if(words[q].CompareNoCase("TEXTEDIT")==0)
			init.type=T_TEXTEDIT;
		if(words[q].CompareNoCase("LABEL")==0)
			init.type=T_TEXT;
		if(words[q].CompareNoCase("LEFT")==0)
			init.pre=PRE_LEFT;
		if(words[q].CompareNoCase("RIGHT")==0)
			init.pre=PRE_RIGHT;
		if(words[q].CompareNoCase("TOP")==0)
			init.pre=PRE_TOP;
		if(words[q].CompareNoCase("BOTTOM")==0)
			init.pre=PRE_BOTTOM;
		if(words[q].CompareNoCase("WIDTH")==0)
			init.pre=PRE_WIDTH;
		if(words[q].CompareNoCase("HEIGHT")==0)
			init.pre=PRE_HEIGHT;
		if(words[q].CompareNoCase("CAPTION")==0)
			init.pre=PRE_TEXT;
		if(words[q].CompareNoCase("TEXT")==0)
			init.pre=PRE_TEXT;
		if(words[q].Mid(0,1)=='\"')
		{
			words[q].Delete(0);
			words[q].Delete(words[q].GetLength()-1);
			switch(init.pre)
			{
			case PRE_LEFT:
				init.left=atoi(words[q]);
				break;
			case PRE_RIGHT:
				init.right=atoi(words[q]);
				break;
			case PRE_WIDTH:
				if(init.left>=5 && init.left<=764)
					init.right=init.left+atoi(words[q])+1;
				else
					if(init.right>=5 && init.right<=764)
						init.left=init.right+atoi(words[q])+1;
				break;
			case PRE_HEIGHT:
				if(init.top>=30 && init.top<=509)
					init.bottom=init.top+atoi(words[q])+1;
				else
					if(init.bottom>=30 && init.bottom<=509)
						init.top=init.bottom+atoi(words[q])+1;
				break;
			case PRE_TOP:
				init.top=atoi(words[q]);
				break;
			case PRE_BOTTOM:
				init.bottom=atoi(words[q]);
				break;
			case PRE_TEXT:
				init.text=words[q];
				break;
			}//switch
		}//=
		if(words[q]=='>')
		{
			init.start=0;
			if(init.right-init.left<15)
				if(init.right<5 || init.right>764)
					init.right=init.left+39;
				else
					init.left=init.right-39;
			if(init.left<5 || init.left>764)
				init.left=init.right-39;
			if(init.right<5 || init.right>764)
				init.right=init.left+39;
			if(init.left>init.right)
				swap(&init.left,&init.right);
			if(init.top>init.bottom)
				swap(&init.bottom,&init.top);
			switch(init.type)
			{
			case T_BUTTON:
				if(init.bottom-init.top<15)
					if(init.top<30 || init.top>509)
						init.top=init.bottom-39;
					else
						init.bottom=init.top+39;
				if(init.bottom-init.top<15)
					init.bottom=init.top+10;
				if(!(init.left>=5 && init.right<=764))
					break;
				if(!(init.top>=30 && init.bottom<=509))
					break;
				if(init.top<30 || init.top>509)
					init.top=init.bottom-39;
				if(init.bottom<30 || init.bottom>509)
					init.bottom=init.top+39;
				else
					if(init.text.GetLength()>255)
						but_text[but_kol]=init.text.Left(255);
					else
						but_text[but_kol]=init.text;
				but_rect[but_kol].top=init.top;
				but_rect[but_kol].bottom=init.bottom;
				but_rect[but_kol].left=init.left;
				but_rect[but_kol].right=init.right;
				x1=(but_rect[but_kol].left-5)/40;
				x2=(but_rect[but_kol].right-5)/40;
				y1=(but_rect[but_kol].top-30)/40;
				y2=(but_rect[but_kol].bottom-30)/40;
				ok=1;
				for(w=y1;w<=y2;w++)
				for(int q1=x1;q1<=x2;q1++)
					if(table[q1][w].type!=T_NONE)
						ok=0,q1=1000,w=1000;
				if(ok==0)
					break;
				AlignButton(but_kol);
				RB_go=1;
				but_kol+=1;
				UpdateTable();
				break;
			case T_TEXTEDIT:
				if(init.bottom-init.top!=20)
					if(init.top<30 || init.top>509)
						init.top=init.bottom-20;
					else
						init.bottom=init.top+20;
				if(!(init.left>=5 && init.right<=764))
					break;
				if(!(init.top>=30 && init.bottom<=509))
					break;
				if(init.top<30 || init.top>509)
					init.top=init.bottom-20;
				if(init.bottom<30 || init.bottom>509)
					init.bottom=init.top+20;
				else
					if(init.text.GetLength()>255)
						edit_text[edit_kol]=init.text.Left(255);
					else
						edit_text[edit_kol]=init.text;
				edit_rect[edit_kol].top=init.top;
				edit_rect[edit_kol].bottom=init.bottom;
				edit_rect[edit_kol].left=init.left;
				edit_rect[edit_kol].right=init.right;
				x1=(edit_rect[edit_kol].left-5)/40;
				x2=(edit_rect[edit_kol].right-5)/40;
				y1=(edit_rect[edit_kol].top-30)/40;
				y2=(edit_rect[edit_kol].bottom-30)/40;
				ok=1;
				for(e=y1;e<=y2;e++)
				for(w=x1;w<=x2;w++)
					if( table[w][e].type!=T_NONE ||
						table[w][e].is!=T_NONE)
						ok=0,w=1000;
				if(ok==0)
					break;
				AlignTextedit(edit_kol);
				RB_go=0;
				RB_go=1;
				edit_kol+=1;
				UpdateTable();
				break;
			case T_TEXT:
				if(init.bottom-init.top<20)
					if(init.top<30 || init.top>509)
						init.top=init.bottom-39;
					else
						init.bottom=init.top+39;
				if(init.bottom-init.top<15)
					init.bottom=init.top+10;
				if(!(init.left>=5 && init.right<=764))
					break;
				if(!(init.top>=30 && init.bottom<=509))
					break;
				if(init.top<30 || init.top>509)
					init.top=init.bottom-39;
				if(init.bottom<30 || init.bottom>509)
					init.bottom=init.top+39;
				else
					if(init.text.GetLength()>255)
						text_text[text_kol]=init.text.Left(255);
					else
						text_text[text_kol]=init.text;
				text_rect[text_kol].top=init.top;
				text_rect[text_kol].bottom=init.bottom;
				text_rect[text_kol].left=init.left;
				text_rect[text_kol].right=init.right;
				x1=(text_rect[text_kol].left-5)/40;
				x2=(text_rect[text_kol].right-5)/40;
				y1=(text_rect[text_kol].top-30)/40;
				y2=(text_rect[text_kol].bottom-30)/40;
				ok=1;
				for(w=y1;w<=y2;w++)
				for(int q1=x1;q1<=x2;q1++)
					if(table[q1][w].type!=T_NONE)
						ok=0,q1=1000,w=1000;
				if(ok==0)
					break;
				AlignText(text_kol);
				RB_go=0;
				RB_go=1;
				text_kol+=1;
				UpdateTable();
				break;
			}//switch type
		}//create
	}//for q

	f.Close();
	for(q=0;q<but_kol;q++)
	{
		but[q].Create(but_text[q],0,but_rect[q],GetParentOwner(),q);
		but[q].CloseWindow();
		but[q].BeginModalState();
		but[q].ShowWindow(SW_NORMAL);
		but[q].UpdateWindow();
	}//q
	for(w=0;w<edit_kol;w++)
	{
		edit[w].Create(0,edit_rect[w],GetParentOwner(),w);
		edit[w].CloseWindow();
		edit[w].BeginModalState();
		edit[w].SetForegroundWindow();
		edit[w].ShowWindow(SW_NORMAL);
		edit[w].SetWindowText(edit_text[w]);
	}
	for(q=0;q<text_kol;q++)
	{
		text[q].Create(TEXT_STYLE,text_rect[q],GetParentOwner(),q);
		text[q].SetForegroundWindow();
		text[q].ShowWindow(SW_NORMAL);
		text[q].UpdateWindow();
		text[q].SetWindowText(text_text[q]);
	}
	RB_go=0;
	CString q1q;
}

void CEditorView::GetWordFromFile()
{
	//��������� �����(<,Button,Text,=,"New",;,>) �� ��� ���������
	//����� f
	//� ���������� �� � ������ words; words_kol - ���������� ����
	int q;
	char z;
	int ok,len=0;
	ok=1;

	for(q=0;q<1000;q++)
		words[q].Empty();
	words_kol=0;
	int in_kovichki=0;//=1 ���� ������� ����� ��������� � ��������


	while(ok)
	{
		ok=0;
		if(f.GetPosition()==f.GetLength())
			break;
		f.Read(&z,1);
		switch((UCHAR)z)
		{
		case '\"':
			if(in_kovichki==1)
			{
				in_kovichki=0;
				words[words_kol++]+=z;
				ok=1;
			}
			else
			{
				in_kovichki=1;
				words[++words_kol]=z;
				ok=1;
			}
			break;
		case 13:
		case 10:
		case ' ':
		case '<':
		case '>':
		case '=':
		case ';':
			if(in_kovichki==1)
			{
				words[words_kol]+=z;
				ok=1;
			}
			else
			{
				if(words[words_kol].GetLength()==0)
					words[words_kol++]+=z;
				else
					words[++words_kol]+=z,
					words_kol++;
				ok=1;
			}
			break;
		default:
			words[words_kol]+=z;
			ok=1;
			break;
		}//switch z
		
	}//while ok
	words_kol+=1;

}

void CEditorView::ClearAll()
{
	//������� ��� ��������
	int q;
	for(q=0;q<max_items;q++)
		but[q].DestroyWindow();
	for(q=0;q<max_items;q++)
		edit[q].DestroyWindow();
	for(q=0;q<max_items;q++)
		text[q].DestroyWindow();
	but_kol=edit_kol=text_kol=0;

}

template <class q>
void CEditorView::swap(q* a,q* b)
{
	q* c;
	c=a;
	a=b;
	b=c;
}

void CEditorView::OnUpdateEditMove(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}

void CEditorView::OnEditMove() 
{
	// TODO: Add your command handler code here
	//������ ������ Edit->Move
	switch(lost_type)
	{
	case T_BUTTON:
		mode=M_MOVE;
		mode_num=lost_num;
		mode_type=T_BUTTON;
		break;
	case T_TEXTEDIT:
		mode=M_MOVE;
		mode_num=lost_num;
		mode_type=T_TEXTEDIT;
		break;
	case T_TEXT:
		mode=M_MOVE;
		mode_num=lost_num;
		mode_type=T_TEXT;
		break;
	}//switch type
	
}

void CEditorView::OnUpdateEditHeight(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}

void CEditorView::OnEditHeight() 
{
	// TODO: Add your command handler code here
	//������ ������ Edit->Height
	switch(lost_type)
	{
	case T_BUTTON:
		mode=M_HEIGHT;
		mode_num=lost_num;
		mode_type=T_BUTTON;
		break;
	case T_TEXT:
		mode=M_HEIGHT;
		mode_num=lost_num;
		mode_type=T_TEXT;
		break;
	}//switch type
	
}

void CEditorView::OnUpdateEditWidth(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}

void CEditorView::OnEditWidth() 
{
	// TODO: Add your command handler code here
	//������ ������ Edit->Move
	switch(lost_type)
	{
	case T_BUTTON:
		mode=M_WIDTH;
		mode_num=lost_num;
		mode_type=T_BUTTON;
		break;
	case T_TEXTEDIT:
		mode=M_WIDTH;
		mode_num=lost_num;
		mode_type=T_TEXTEDIT;
		break;
	case T_TEXT:
		mode=M_WIDTH;
		mode_num=lost_num;
		mode_type=T_TEXT;
		break;
	}//switch type
	
}

void CEditorView::OnFileNew() 
{
	// TODO: Add your command handler code here
	//������� ����� ������
 	int q;
 	if(mode==M_EDIT)
 		edit[mode_num].GetWindowText(edit_text[mode_num]),
 		edit[mode_num].BeginModalState(),
 		mode=M_NONE;
 	if(but_kol==0 && edit_kol==0 && text_kol==0)
 	{
 		mode=M_NONE;
 		for(q=0;q<but_kol;q++)
 			but[q].DestroyWindow();
 		for(q=0;q<edit_kol;q++)
 			edit[q].DestroyWindow();
 		for(q=0;q<text_kol;q++)
 			text[q].DestroyWindow();
 		but_kol=edit_kol=text_kol=0;
 		mode=M_NONE;
 		lost_file=FALSE;
 		SendMessage(WM_PAINT);
 	}//new
 	else
 	{
 			for(q=0;q<but_kol;q++)
 				but[q].DestroyWindow();
 			for(q=0;q<edit_kol;q++)
 				edit[q].DestroyWindow();
 			for(q=0;q<text_kol;q++)
 				text[q].DestroyWindow();
 			but_kol=edit_kol=text_kol=0;
 			lost_file=FALSE;
 			mode=M_NONE;
 	}//save and new
	
}

void CEditorView::OnUpdateToolsOptions(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable();
	
}

void CEditorView::OnToolsOptions() 
{
	// TODO: Add your command handler code here
	options_dlg.ShowWindow(SW_RESTORE);
	
}

void CEditorView::LoadConfig()
{
	//��������� ������������ ���������
	default_but_text.Empty();
	default_edit_text.Empty();
	default_text_text.Empty();
	char a[200];
	long q;
	int config_type=T_NONE;
	if(f.Open("Editor.ini",CFile::modeRead)==FALSE)
	{
		f.Open("Editor.ini",CFile::modeCreate | CFile::modeWrite);
		sprintf(a,"Button=\"New\"\r\nTextedit=\"New\"\r\nLabel=\"New\"");
		f.Write(a,strlen(a));
		f.Close();
		default_but_text.Insert(0,"New");
		default_edit_text.Insert(0,"New");
		default_text_text.Insert(0,"New");
	}//Editor.ini not found
	else
	{
		GetWordFromFile();
		for(q=0;q<words_kol;q++)
		{
			if(words[q].CompareNoCase("BUTTON")==0)
				config_type=T_BUTTON;
			if(words[q].CompareNoCase("TEXTEDIT")==0)
				config_type=T_TEXTEDIT;
			if(words[q].CompareNoCase("LABEL")==0)
				config_type=T_TEXT;
			if(words[q].Mid(0,1)=='\"')
			{
				words[q].Delete(0);
				words[q].Delete(words[q].GetLength()-1);
				switch(config_type)
				{
				case T_BUTTON:
					default_but_text.Insert(0,words[q]);
					break;
				case T_TEXTEDIT:
					default_edit_text.Insert(0,words[q]);
					break;
				case T_TEXT:
					default_text_text.Insert(0,words[q]);
					break;
				}//switch type
				config_type=T_NONE;
			}//if ""
		}//for q
	f.Close();
	}//read Editor.ini

}

void CEditorView::SaveConfig()
{
	//��������� ������������
	char a[200];
	f.Open("Editor.ini",CFile::modeCreate | CFile::modeWrite);
	sprintf(a,"Button=\"%s\";\r\nTextedit=\"%s\";\r\nLabel=\"%s\";",
		default_but_text,
		default_edit_text,
		default_text_text);
	f.Write(a,strlen(a));
	f.Close();
}
