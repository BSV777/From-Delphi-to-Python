// Options_Dialog.cpp : implementation file
//

#include "stdafx.h"
#include "editor.h"
#include "Options_Dialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Options_Dialog dialog


Options_Dialog::Options_Dialog(CWnd* pParent /*=NULL*/)
	: CDialog(Options_Dialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(Options_Dialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void Options_Dialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Options_Dialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Options_Dialog, CDialog)
	//{{AFX_MSG_MAP(Options_Dialog)
	ON_EN_MAXTEXT(IDC_EDIT_BUTTON, OnMaxtextEditButton)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_OPTIONS, OnUpdateToolsOptions)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Options_Dialog message handlers

void Options_Dialog::OnMaxtextEditButton() 
{
	// TODO: Add your control notification handler code here
	
}
void Options_Dialog::OnUpdateToolsOptions(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable();
	
}
