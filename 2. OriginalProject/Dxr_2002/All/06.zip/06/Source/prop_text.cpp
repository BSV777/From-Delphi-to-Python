// prop_text.cpp : implementation file
//

#include "stdafx.h"
#include "Editor.h"
#include "prop_text.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// prop_text dialog


prop_text::prop_text(CWnd* pParent /*=NULL*/)
	: CDialog(prop_text::IDD, pParent)
{
	//{{AFX_DATA_INIT(prop_text)
	//}}AFX_DATA_INIT
}


void prop_text::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(prop_text)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(prop_text, CDialog)
	//{{AFX_MSG_MAP(prop_text)
	ON_WM_CLOSE()
	ON_WM_MOUSEMOVE()
	ON_WM_SHOWWINDOW()
	ON_WM_TIMER()
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// prop_text message handlers

void prop_text::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	texting=1;
	KillTimer(22);
	
	CDialog::OnClose();
}

void prop_text::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	static RECT zx;
	GetWindowRect(&zx);
	if( point.x>=zx.left &&
		point.x<=zx.right &&
		point.y>=zx.top &&
		point.y<=zx.bottom)
			LoadCursor(NULL,IDC_ARROW);
	
	CDialog::OnMouseMove(nFlags, point);
}

void prop_text::OnOK() 
{
	// TODO: Add extra validation here
	texting=1;
	KillTimer(22);
	
	CDialog::OnOK();
}

void prop_text::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	// TODO: Add your message handler code here
	if(nStatus==SW_HIDE) KillTimer(22),	texting=1;
	
}

void prop_text::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	KillTimer(22);
	static RECT zx;
	static CPoint point;
	GetCursorPos(&point);
	GetWindowRect(&zx);
	if( point.x>=zx.left &&
		point.x<=zx.right &&
		point.y>=zx.top &&
		point.y<=zx.bottom)
			LoadCursor(NULL,IDC_ARROW);
	SetTimer(22,10,NULL);
	
	CDialog::OnTimer(nIDEvent);
}

int prop_text::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	texting=0;
	
	return 0;
}
