// prop_edit.cpp : implementation file
//

#include "stdafx.h"
#include "Editor.h"
#include "prop_edit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// prop_edit dialog


prop_edit::prop_edit(CWnd* pParent /*=NULL*/)
	: CDialog(prop_edit::IDD, pParent)
{
	//{{AFX_DATA_INIT(prop_edit)
	//}}AFX_DATA_INIT
}


void prop_edit::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(prop_edit)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(prop_edit, CDialog)
	//{{AFX_MSG_MAP(prop_edit)
	ON_WM_CLOSE()
	ON_WM_SHOWWINDOW()
	ON_WM_MOUSEMOVE()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// prop_edit message handlers

void prop_edit::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	propertying=1;
	KillTimer(11);
	
	CDialog::OnClose();
}

void prop_edit::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	// TODO: Add your message handler code here
	if(nStatus==SW_HIDE) KillTimer(11),	propertying=1;
	
}

void prop_edit::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	static RECT zx;
	GetWindowRect(&zx);
	if( point.x>=zx.left &&
		point.x<=zx.right &&
		point.y>=zx.top &&
		point.y<=zx.bottom)
			LoadCursor(NULL,IDC_ARROW);
	
	CDialog::OnMouseMove(nFlags, point);
}

void prop_edit::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	KillTimer(11);
	static RECT zx;
	static CPoint point;
	GetCursorPos(&point);
	GetWindowRect(&zx);
	if( point.x>=zx.left &&
		point.x<=zx.right &&
		point.y>=zx.top &&
		point.y<=zx.bottom)
			LoadCursor(NULL,IDC_ARROW);
	SetTimer(11,10,NULL);
	
	CDialog::OnTimer(nIDEvent);
}

void prop_edit::OnOK() 
{
	// TODO: Add extra validation here
	propertying=1;
	KillTimer(11);
	
	CDialog::OnOK();
}
