// export.cpp : implementation file
//

#include "stdafx.h"
#include "editor.h"
#include "export.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// export dialog


export::export(CWnd* pParent /*=NULL*/)
	: CDialog(export::IDD, pParent)
{
	//{{AFX_DATA_INIT(export)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void export::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(export)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(export, CDialog)
	//{{AFX_MSG_MAP(export)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// export message handlers
