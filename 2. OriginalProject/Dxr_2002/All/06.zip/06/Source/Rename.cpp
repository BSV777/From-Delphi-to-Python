// Rename.cpp : implementation file
//

#include "stdafx.h"
#include "Editor.h"
#include "Rename.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Rename dialog


Rename::Rename(CWnd* pParent /*=NULL*/)
	: CDialog(Rename::IDD, pParent)
{
	//{{AFX_DATA_INIT(Rename)
	//}}AFX_DATA_INIT
}


void Rename::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Rename)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Rename, CDialog)
	//{{AFX_MSG_MAP(Rename)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	ON_WM_SHOWWINDOW()
	ON_WM_MOUSEMOVE()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Rename message handlers

int Rename::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here

	renaming=0;
	SetTimer(312,30,NULL);
	//m_gorizontal.SetDlgItemInt);
//	if(m_bottom)
//	{
		
//	}
	
	return 0;
}

void Rename::OnOK() 
{
	// TODO: Add extra validation here
	renaming=1;
	KillTimer(312);
	
	CDialog::OnOK();
}

void Rename::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	renaming=1;
	KillTimer(312);
	
	CDialog::OnClose();
}

void Rename::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	// TODO: Add your message handler code here
	if(nStatus==SW_HIDE) KillTimer(312);
}

void Rename::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
//	SetCursor(LoadCursor(NULL,IDC_ARROW));
	static RECT zx;
	GetWindowRect(&zx);
	if( point.x>=zx.left &&
		point.x<=zx.right &&
		point.y>=zx.top &&
		point.y<=zx.bottom)
			LoadCursor(NULL,IDC_ARROW);
	
	CDialog::OnMouseMove(nFlags, point);
}

void Rename::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	KillTimer(312);
	static RECT zx;
	static CPoint point;
	GetCursorPos(&point);
	GetWindowRect(&zx);
	if( point.x>=zx.left &&
		point.x<=zx.right &&
		point.y>=zx.top &&
		point.y<=zx.bottom)
			LoadCursor(NULL,IDC_ARROW);
	SetTimer(312,10,NULL);

	
	CDialog::OnTimer(nIDEvent);
}
