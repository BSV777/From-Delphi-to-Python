// options.cpp : implementation file
//

#include "stdafx.h"
#include "editor.h"
#include "options.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// options dialog


options::options(CWnd* pParent /*=NULL*/)
	: CDialog(options::IDD, pParent)
{
	//{{AFX_DATA_INIT(options)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void options::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(options)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(options, CDialog)
	//{{AFX_MSG_MAP(options)
	ON_WM_CREATE()
	ON_COMMAND(ID_APP_EXIT, OnAppExit)
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// options message handlers

int options::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	
	return 0;
}

void options::OnOK() 
{
	// TODO: Add extra validation here
	change_options=-1;	
	CDialog::OnOK();
}

void options::OnCancel() 
{
	// TODO: Add extra cleanup here
	change_options=-1;
	CDialog::OnCancel();
}

void options::OnAppExit() 
{
	// TODO: Add your command handler code here
	change_options=-1;
}

void options::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	// TODO: Add your message handler code here
	if(bShow==SW_RESTORE)
		change_options=1;
	
}
