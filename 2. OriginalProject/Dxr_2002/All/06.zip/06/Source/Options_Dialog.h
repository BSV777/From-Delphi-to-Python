#if !defined(AFX_OPTIONS_DIALOG_H__180050A1_3F6C_11D6_A9F3_B98D2A86EB3D__INCLUDED_)
#define AFX_OPTIONS_DIALOG_H__180050A1_3F6C_11D6_A9F3_B98D2A86EB3D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Options_Dialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Options_Dialog dialog

class Options_Dialog : public CDialog
{
// Construction
public:
	Options_Dialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(Options_Dialog)
	enum { IDD = IDD_DIALOG_OPTIONS };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Options_Dialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(Options_Dialog)
	afx_msg void OnMaxtextEditButton();
	afx_msg void OnUpdateToolsOptions(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTIONS_DIALOG_H__180050A1_3F6C_11D6_A9F3_B98D2A86EB3D__INCLUDED_)
