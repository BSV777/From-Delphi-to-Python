// EditorView.h : interface of the CEditorView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_EDITORVIEW_H__DDD7D66E_378B_11D6_A9F3_82AE65FDD919__INCLUDED_)
#define AFX_EDITORVIEW_H__DDD7D66E_378B_11D6_A9F3_82AE65FDD919__INCLUDED_

#include "Options_Dialog.h"	// Added by ClassView
#include "export.h"	// Added by ClassView
#include "Rename.h"	// Added by ClassView
#include "prop_edit.h"	// Added by ClassView
#include "prop_text.h"	// Added by ClassView
#include "FileNew.h"	// Added by ClassView
#include "options.h"	// Added by ClassView
#include "EditorDoc.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CEditorView : public CView
{
protected: // create from serialization only
	CEditorView();
	DECLARE_DYNCREATE(CEditorView)

// Attributes
public:
	CEditorDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditorView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	void SaveConfig();
	void LoadConfig();
	options options_dlg;
	export exp_dlg;
	template <class q>
	void swap(q* a,q* b);
	void ClearAll();
	void GetWordFromFile();
	void OpenFromFile(CString name);
	int SaveToFile(CString name);
	prop_text text_dlg;
	void AlignText(int a);
	void RedrawText(int a);
	void SwapTexts(int a,int b);
	prop_edit prop_dlg;
	void AlignTextedit(int a);
	void RedrawTextedit(int a);
	void SwapTextedits(int a,int b);
	void AlignButton(int a);
	void UpdateTable();
	void RedrawButton(int a);
	Rename ren_dlg;
	void SwapButtons(int a,int b);
	virtual ~CEditorView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CEditorView)
	afx_msg void OnPaint();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnUpdateNewButton(CCmdUI* pCmdUI);
	afx_msg void OnNewButton();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnUpdateButtonExport(CCmdUI* pCmdUI);
	afx_msg void OnButtonExport();
	afx_msg void OnDestroy();
	afx_msg void OnUpdateEditCut(CCmdUI* pCmdUI);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnUpdateButtonProperty(CCmdUI* pCmdUI);
	afx_msg void OnButtonProperty();
	afx_msg void OnUpdateNewEdit(CCmdUI* pCmdUI);
	afx_msg void OnNewEdit();
	afx_msg void OnUpdateNewText(CCmdUI* pCmdUI);
	afx_msg void OnNewText();
	afx_msg void OnUpdateEditDelete(CCmdUI* pCmdUI);
	afx_msg void OnEditDelete();
	afx_msg void OnEditCut();
	afx_msg void OnUpdateEditCopy(CCmdUI* pCmdUI);
	afx_msg void OnEditCopy();
	afx_msg void OnEditPaste();
	afx_msg void OnUpdateEditPaste(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditMove(CCmdUI* pCmdUI);
	afx_msg void OnEditMove();
	afx_msg void OnUpdateEditHeight(CCmdUI* pCmdUI);
	afx_msg void OnEditHeight();
	afx_msg void OnUpdateEditWidth(CCmdUI* pCmdUI);
	afx_msg void OnEditWidth();
	afx_msg void OnFileNew();
	afx_msg void OnUpdateToolsOptions(CCmdUI* pCmdUI);
	afx_msg void OnToolsOptions();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in EditorView.cpp
inline CEditorDoc* CEditorView::GetDocument()
   { return (CEditorDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITORVIEW_H__DDD7D66E_378B_11D6_A9F3_82AE65FDD919__INCLUDED_)
