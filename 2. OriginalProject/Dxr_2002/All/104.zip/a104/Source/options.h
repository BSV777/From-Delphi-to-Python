#if !defined(AFX_OPTIONS_H__EB80C001_3CE1_11D6_A9F3_FF6F64134609__INCLUDED_)
#define AFX_OPTIONS_H__EB80C001_3CE1_11D6_A9F3_FF6F64134609__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// options.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// options dialog

class options : public CDialog
{
// Construction
public:
	int change_options;
	options(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(options)
	enum { IDD = IDD_DIALOG5 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(options)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(options)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnAppExit();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTIONS_H__EB80C001_3CE1_11D6_A9F3_FF6F64134609__INCLUDED_)
