// FileNew.cpp : implementation file
//

#include "stdafx.h"
#include "Editor.h"
#include "FileNew.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// FileNew dialog


FileNew::FileNew(CWnd* pParent /*=NULL*/)
	: CDialog(FileNew::IDD, pParent)
{
	//{{AFX_DATA_INIT(FileNew)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void FileNew::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(FileNew)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(FileNew, CDialog)
	//{{AFX_MSG_MAP(FileNew)
	ON_WM_SHOWWINDOW()
	ON_COMMAND(ID_APP_EXIT, OnAppExit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// FileNew message handlers

void FileNew::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	// TODO: Add your message handler code here
	//if(bShow==SW_RESTORE)
		saving=0;
}

void FileNew::OnOK() 
{
	// TODO: Add extra validation here
	saving=1;	
	CDialog::OnOK();
}

void FileNew::OnCancel() 
{
	// TODO: Add extra cleanup here
	saving=-2;	
	CDialog::OnCancel();
}

void FileNew::OnAppExit() 
{
	// TODO: Add your command handler code here
	saving=1;	
}
