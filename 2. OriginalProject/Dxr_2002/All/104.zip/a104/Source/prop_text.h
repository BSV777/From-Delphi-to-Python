#if !defined(AFX_PROP_TEXT_H__3B45FE20_3B7A_11D6_A9F3_E2758220E61C__INCLUDED_)
#define AFX_PROP_TEXT_H__3B45FE20_3B7A_11D6_A9F3_E2758220E61C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// prop_text.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// prop_text dialog

class prop_text : public CDialog
{
// Construction
public:
	int texting;
	prop_text(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(prop_text)
	enum { IDD = IDD_DIALOG3 };
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(prop_text)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(prop_text)
	afx_msg void OnClose();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	virtual void OnOK();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROP_TEXT_H__3B45FE20_3B7A_11D6_A9F3_E2758220E61C__INCLUDED_)
