//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Editor.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_EDITORTYPE                  129
#define IDD_DIALOG1                     130
#define IDC_CURSOR1                     131
#define IDD_DIALOG2                     132
#define IDD_DIALOG3                     133
#define IDD_DIALOG4                     136
#define IDI_ICON1                       139
#define IDD_DIALOG5                     141
#define IDD_DIALOG6                     142
#define IDD_DIALOG_OPTIONS              143
#define IDC_EDIT1                       1000
#define IDC_RADIO_LEFT                  1008
#define IDC_RADIO_CENTER                1009
#define IDC_RADIO_RIGHT                 1010
#define IDC_RADIO_TOP                   1011
#define IDC_RADIO_MIDDLE                1013
#define IDC_RADIO_BOTTOM                1015
#define IDC_EDIT_FILENAME               1016
#define IDC_EDIT_BUTTON                 1019
#define IDC_EDIT_TEXTEDIT               1020
#define IDC_EDIT_TEXT                   1021
#define ID_NEW_BUTTON                   32771
#define ID_BUTTON_EXPORT                32772
#define ID_EDIT_DELETE                  32773
#define ID_BUTTON_PROPERTY              32776
#define ID_NEW_EDIT                     32777
#define ID_NEW_TEXT                     32779
#define ID_EDIT_MOVE                    32781
#define ID_EDIT_WIDTH                   32782
#define ID_EDIT_HEIGHT                  32783
#define ID_OPTIONS                      32785
#define ID_TOOLS_OPTIONS                32787

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        144
#define _APS_NEXT_COMMAND_VALUE         32788
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
