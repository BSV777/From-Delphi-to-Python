// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Editor.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
#define PRE_NONE 0
#define PRE_LEFT 1
#define PRE_RIGHT 2
#define PRE_TOP 3
#define PRE_BOTTOM 4
#define PRE_TEXT 5
#define PRE_WIDTH 6
#define PRE_HEIGHT 7

#define T_NONE 0
#define T_BUTTON 1
#define T_TEXTEDIT 2
#define T_TEXT 3
#define T_BLOCKED 4

#define TEXTEDIT_STYLE (ES_MULTILINE | ES_WANTRETURN)

CString words1[10000];
//int words_kol=0;
BOOL RUNALL=TRUE;
CFile f1;
const int max_items1=200;
int but_kol1,edit_kol1,text_kol1;
RECT but_rect1[max_items1],
	edit_rect1[max_items1],
	text_rect1[max_items1];
CString but_text1[max_items1],
	text_text1[max_items1],
	edit_text1[max_items1];
CButton but1[max_items1];
CEdit edit1[max_items1];
CEdit text1[max_items1];
struct for_init1 {
	int type1,left1,right1,top1,bottom1,start1,pre1;
	CString text1;
} init1;
struct for_table1 {
	int type1,colspan1,rowspan1,num1;
	int is1;
} table1[30][20];//19x12
int words_kol1=0;
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	exp_dlg.Create(IDD_DIALOG6,GetParentOwner());
	exp_dlg.ShowWindow(SW_NORMAL);
	exp_dlg.UpdateWindow();
	int q=ReadCommandLine();
	switch(q)
	{
	case -1:
		RUNALL=FALSE;
		break;
	case 1:
	case 0:
		RUNALL=TRUE;
		break;
	}
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	exp_dlg.ShowWindow(SW_HIDE);
	cs.x=0;
	cs.y=0;
	cs.cx=800;
	cs.cy=600-25;
	cs.style=
			 WS_OVERLAPPED |
			 WS_CAPTION |
			 WS_SYSMENU |
			 WS_MAXIMIZE |
			 WS_MINIMIZEBOX;
	if( !CMDIFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	return RUNALL;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	//return ok;
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

int CMainFrame::ReadCommandLine()
{

	LPTSTR tmp1;
	CString line1,ret1;
	CFile fout1;
	char a1[300];
	char zz1;
	int q1,ok1,len1=0;
	int in_kovichki1=0;
	
	line1=(tmp1=GetCommandLine());
	f1.Open("editor.swp",CFile::modeWrite | CFile::modeCreate);
	sprintf(a1,"%s",line1);
	f1.Write(a1,strlen(a1));
	f1.Close();
	f1.Open("editor.swp",CFile::modeRead);

	ret1.Empty();

	for(q1=0;q1<10000;q1++)
		words1[q1].Empty();
	ok1=1;

	while(ok1)
	{
		ok1=0;
		if(f1.GetPosition()==f1.GetLength())
			break;
		f1.Read(&zz1,1);
		switch((UCHAR)zz1)
		{
		case '\"':
			if(in_kovichki1==1)
			{
				in_kovichki1=0;
				words1[words_kol1++]+=zz1;
				ok1=1;
			}
			else
			{
				in_kovichki1=1;
				words1[++words_kol1]=zz1;
				ok1=1;
			}
			break;
		case ' ':
			if(in_kovichki1==1)
			{
				words1[words_kol1]+=zz1;
				ok1=1;
			}
			else
			{
				if(words1[words_kol1].GetLength()==0)
					words1[words_kol1++]+=zz1;
				else
					words1[++words_kol1]+=zz1,
					words_kol1++;
				//return &ret;
				ok1=1;
			}
			break;
		default:
			words1[words_kol1]+=zz1;
			ok1=1;
			break;
		}//switch zz
		
	}//while ok
	words_kol1+=1;

	f1.Close();

	if(words1[3].GetLength()==0 || words1[5].GetLength()==0)
		return 0;

	if(f1.Open(words1[3],CFile::modeRead)==FALSE)
	{
		MessageBox("File not found.","Error!",MB_ICONSTOP);
		return -1;
	}
	if(fout1.Open(words1[5],CFile::modeWrite | CFile::modeCreate)==FALSE)
	{
		MessageBox("Illegal file name.","Error!",MB_ICONSTOP);
		return -1;
	}
//read file
	int w,e;
	int x1,x2,y1,y2;
	CString z;
	ok1=1;
	for(q1=0;q1<max_items1;q1++)
		but_rect1[q1].bottom=0,
		but_rect1[q1].left=0,
		but_rect1[q1].right=0,
		but_rect1[q1].top=0;
	for(q1=0;q1<max_items1;q1++)
		edit_rect1[q1].bottom=0,
		edit_rect1[q1].left=0,
		edit_rect1[q1].right=0,
		edit_rect1[q1].top=0;
	for(q1=0;q1<max_items1;q1++)
		text_rect1[q1].bottom=0,
		text_rect1[q1].left=0,
		text_rect1[q1].right=0,
		text_rect1[q1].top=0;

	ok1=1;

	init1.bottom1=init1.left1=init1.right1=init1.start1=init1.top1=0;
	init1.text1.Empty();
	init1.type1=T_NONE;init1.pre1=PRE_NONE;
	
	GetWordFromFile();
	but_kol1=edit_kol1=text_kol1=0;
	UpdateTable();
	for(q1=0;q1<words_kol1;q1++)
	{
		if(words1[q1]=='<')
		{
			init1.start1=1;
			init1.bottom1=init1.left1=init1.right1=init1.start1=init1.top1=0;
			init1.text1.Empty();
			init1.type1=T_NONE;init1.pre1=PRE_NONE;
		}
		if(words1[q1].CompareNoCase("BUTTON")==0)
			init1.type1=T_BUTTON;
		if(words1[q1].CompareNoCase("TEXTEDIT")==0)
			init1.type1=T_TEXTEDIT;
		if(words1[q1].CompareNoCase("LABEL")==0)
			init1.type1=T_TEXT;
		if(words1[q1].CompareNoCase("LEFT")==0)
			init1.pre1=PRE_LEFT;
		if(words1[q1].CompareNoCase("RIGHT")==0)
			init1.pre1=PRE_RIGHT;
		if(words1[q1].CompareNoCase("TOP")==0)
			init1.pre1=PRE_TOP;
		if(words1[q1].CompareNoCase("BOTTOM")==0)
			init1.pre1=PRE_BOTTOM;
		if(words1[q1].CompareNoCase("WIDTH")==0)
			init1.pre1=PRE_WIDTH;
		if(words1[q1].CompareNoCase("HEIGHT")==0)
			init1.pre1=PRE_HEIGHT;
		if(words1[q1].CompareNoCase("CAPTION")==0)
			init1.pre1=PRE_TEXT;
		if(words1[q1].CompareNoCase("TEXT")==0)
			init1.pre1=PRE_TEXT;
		if(words1[q1].Mid(0,1)=='\"')
		{
			words1[q1].Delete(0);
			words1[q1].Delete(words1[q1].GetLength()-1);
			switch(init1.pre1)
			{
			case PRE_LEFT:
				init1.left1=atoi(words1[q1]);
				break;
			case PRE_RIGHT:
				init1.right1=atoi(words1[q1]);
				break;
			case PRE_TOP:
				init1.top1=atoi(words1[q1]);
				break;
			case PRE_BOTTOM:
				init1.bottom1=atoi(words1[q1]);
				break;
			case PRE_WIDTH:
				if(init1.left1>=5 && init1.left1<=764)
					init1.right1=init1.left1+atoi(words1[q1])+1;
				else
					if(init1.right1>=5 && init1.right1<=764)
						init1.left1=init1.right1+atoi(words1[q1])+1;
				break;
			case PRE_HEIGHT:
				if(init1.top1>=30 && init1.top1<=509)
					init1.bottom1=init1.top1+atoi(words1[q1])+1;
				else
					if(init1.bottom1>=30 && init1.bottom1<=509)
						init1.top1=init1.bottom1+atoi(words1[q1])+1;
				break;
			case PRE_TEXT:
				init1.text1=words1[q1];
				break;
			}//switch
		}//=
		if(words1[q1]=='>')
		{
			int w1;
			init1.start1=0;
			if(init1.right1-init1.left1<15)
				if(init1.right1<5 || init1.right1>764)
					init1.right1=init1.left1+39;
				else
					init1.left1=init1.right1-39;
			if(init1.left1<5 || init1.left1>764)
				init1.left1=init1.right1-39;
			if(init1.right1<5 || init1.right1>764)
				init1.right1=init1.left1+39;
			if(init1.left1>init1.right1)
				swap(&init1.left1,&init1.right1);
			if(init1.top1>init1.bottom1)
				swap(&init1.bottom1,&init1.top1);
			switch(init1.type1)
			{
			case T_BUTTON:
				if(init1.bottom1-init1.top1<15)
					if(init1.top1<30 || init1.top1>509)
						init1.top1=init1.bottom1-39;
					else
						init1.bottom1=init1.top1+39;
				if(!(init1.left1>=5 && init1.right1<=764))
					break;
				if(!(init1.top1>=30 && init1.bottom1<=509))
					break;
				if(init1.top1<30 || init1.top1>509)
					init1.top1=init1.bottom1-39;
				if(init1.bottom1<30 || init1.bottom1>509)
					init1.bottom1=init1.top1+39;
				else
					if(init1.text1.GetLength()>255)
						but_text1[but_kol1]=init1.text1.Left(255);
					else
						but_text1[but_kol1]=init1.text1;
				but_rect1[but_kol1].top=init1.top1;
				but_rect1[but_kol1].bottom=init1.bottom1;
				but_rect1[but_kol1].left=init1.left1;
				but_rect1[but_kol1].right=init1.right1;
				x1=(but_rect1[but_kol1].left-5)/40;
				x2=(but_rect1[but_kol1].right-5)/40;
				y1=(but_rect1[but_kol1].top-30)/40;
				y2=(but_rect1[but_kol1].bottom-30)/40;
				ok1=1;
				for(w1=y1;w1<=y2;w1++)
				for(int q11=x1;q11<=x2;q11++)
					if(table1[q11][w1].type1!=T_NONE)
						ok1=0,q11=1000,w1=1000;
				if(ok1==0)
					break;
				AlignButton(but_kol1);
				but_kol1+=1;
				UpdateTable();
				break;
			case T_TEXTEDIT:
				if(init1.bottom1-init1.top1!=20)
					if(init1.top1<30 || init1.top1>509)
						init1.top1=init1.bottom1-20;
					else
						init1.bottom1=init1.top1+20;
				if(!(init1.left1>=5 && init1.right1<=764))
					break;
				if(!(init1.top1>=30 && init1.bottom1<=509))
					break;
				if(init1.top1<30 || init1.top1>509)
					init1.top1=init1.bottom1-20;
				if(init1.bottom1<30 || init1.bottom1>509)
					init1.bottom1=init1.top1+20;
//				if(init1.text1.GetLength()==0)
//					edit_text1[edit_kol1]="New";
				else
					if(init1.text1.GetLength()>255)
						edit_text1[edit_kol1]=init1.text1.Left(255);
					else
						edit_text1[edit_kol1]=init1.text1;
				edit_rect1[edit_kol1].top=init1.top1;
				edit_rect1[edit_kol1].bottom=init1.bottom1;
				edit_rect1[edit_kol1].left=init1.left1;
				edit_rect1[edit_kol1].right=init1.right1;
				x1=(edit_rect1[edit_kol1].left-5)/40;
				x2=(edit_rect1[edit_kol1].right-5)/40;
				y1=(edit_rect1[edit_kol1].top-30)/40;
				y2=(edit_rect1[edit_kol1].bottom-30)/40;
				ok1=1;
				for(e=y1;e<=y2;e++)
				for(w1=x1;w1<=x2;w1++)
					if( table1[w1][e].type1!=T_NONE ||
						table1[w1][e].is1!=T_NONE)
						ok1=0,w1=e=1000;
				if(ok1==0)
					break;
				//but[but_kol].DestroyWindow();
				/*but[but_kol].Create(but_text[but_kol],0,but_rect[but_kol],GetParentOwner(),but_kol);
				but[but_kol].CloseWindow();
				but[but_kol].BeginModalState();
				but[but_kol].ShowWindow(SW_NORMAL);
				but[but_kol].UpdateWindow();*/
				AlignTextedit(edit_kol1);
				//RedrawButton(but_kol);
				edit_kol1+=1;
				UpdateTable();
				break;
			case T_TEXT:
				if(init1.bottom1-init1.top1<20)
					if(init1.top1<30 || init1.top1>509)
						init1.top1=init1.bottom1-39;
					else
						init1.bottom1=init1.top1+39;
				if(!(init1.left1>=5 && init1.right1<=764))
					break;
				if(!(init1.top1>=30 && init1.bottom1<=509))
					break;
				if(init1.top1<30 || init1.top1>509)
					init1.top1=init1.bottom1-38;
				if(init1.bottom1<30 || init1.bottom1>509)
					init1.bottom1=init1.top1+38;
//				if(init1.text1.GetLength()==0)
//					text_text1[text_kol1]="New";
				else
					if(init1.text1.GetLength()>255)
						text_text1[text_kol1]=init1.text1.Left(255);
					else
						text_text1[text_kol1]=init1.text1;
				text_rect1[text_kol1].top=init1.top1;
				text_rect1[text_kol1].bottom=init1.bottom1;
				text_rect1[text_kol1].left=init1.left1;
				text_rect1[text_kol1].right=init1.right1;
				x1=(text_rect1[text_kol1].left-5)/40;
				x2=(text_rect1[text_kol1].right-5)/40;
				y1=(text_rect1[text_kol1].top-30)/40;
				y2=(text_rect1[text_kol1].bottom-30)/40;
				ok1=1;
				for(w=y1;w<=y2;w++)
				for(int q1=x1;q1<=x2;q1++)
					if(table1[q1][w].type1!=T_NONE)
						ok1=0,q1=1000,w=1000;
				if(ok1==0)
					break;
				//but[but_kol].DestroyWindow();
				/*but[but_kol].Create(but_text[but_kol],0,but_rect[but_kol],GetParentOwner(),but_kol);
				but[but_kol].CloseWindow();
				but[but_kol].BeginModalState();
				but[but_kol].ShowWindow(SW_NORMAL);
				but[but_kol].UpdateWindow();*/
				AlignText(text_kol1);
				//RedrawButton(but_kol);
				text_kol1+=1;
				UpdateTable();
				break;
			}//switch type
		}//create
	}//for q
//end of reading file
	f1.Close();
//export
	sprintf(a1,"<HTML>\r\n<BODY>\r\n<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0>");
	fout1.Write(a1,strlen(a1));

	sprintf(a1,"<TR>\r\n <TD WIDTH=1 HEIGHT=1></TD>\r\n");
	fout1.Write(a1,strlen(a1));
	for(q1=0;q1<19;q1++)
	{
		sprintf(a1,"<TD WIDTH=40 HEIGHT=1></TD>");
		fout1.Write(a1,strlen(a1));
	}//q

	for(w=0;w<12;w++)
	{
		sprintf(a1,"<TR><TD WIDTH=1 HEIGHT=40></TD>");
		fout1.Write(a1,strlen(a1));
	for(q1=0;q1<19;q1++)
	{
		switch(table1[q1][w].type1)
		{
		case T_BUTTON:
			sprintf(a1,"\r\n<TD COLSPAN=%u ROWSPAN=%u ",
				table1[q1][w].colspan1,
				table1[q1][w].rowspan1);
			fout1.Write(a1,strlen(a1));
			sprintf(a1,"ALIGN=LEFT ");
			fout1.Write(a1,strlen(a1));
			sprintf(a1,"VALIGN=TOP>");
			fout1.Write(a1,strlen(a1));
			sprintf(a1,"<INPUT TYPE=\"BUTTON\" STYLE=\"WIDTH:%u;HEIGHT:%u\" VALUE=\"",
				but_rect1[table1[q1][w].num1].right-but_rect1[table1[q1][w].num1].left+1,
				but_rect1[table1[q1][w].num1].bottom-but_rect1[table1[q1][w].num1].top+1);
			//	but_text[table[q][w].num]
//				);
			fout1.Write(a1,strlen(a1));
			for(e=0;e<but_text1[table1[q1][w].num1].GetLength();e++)
			{
				if(but_text1[table1[q1][w].num1].Mid(e,1)==' ')
					if(e==but_text1[table1[q1][w].num1].GetLength()-1)
						sprintf(a1,"&nbsp ");
					else
						if(but_text1[table1[q1][w].num1].Mid(e+1,1)==' ')
							sprintf(a1,"&nbsp");
						else
							sprintf(a1,"&nbsp ");
				else
					sprintf(a1,"%s",but_text1[table1[q1][w].num1].Mid(e,1));
				fout1.Write(a1,strlen(a1));
			}
			sprintf(a1,"\"></TD>\r\n");
			fout1.Write(a1,strlen(a1));
			break;
		case T_TEXTEDIT:
			sprintf(a1,"\r\n<TD COLSPAN=%u ROWSPAN=1 ",
				table1[q1][w].colspan1);
			fout1.Write(a1,strlen(a1));
				sprintf(a1,"ALIGN=LEFT ");
			fout1.Write(a1,strlen(a1));
				sprintf(a1,"VALIGN=TOP>");
			fout1.Write(a1,strlen(a1));
			sprintf(a1,"<INPUT STYLE=\"WIDTH: %u; HEIGHT: %u\" VALUE=\"",
				edit_rect1[table1[q1][w].num1].right-edit_rect1[table1[q1][w].num1].left+1,
				edit_rect1[table1[q1][w].num1].bottom-edit_rect1[table1[q1][w].num1].top+1);
			fout1.Write(a1,strlen(a1));
			for(e=0;e<edit_text1[table1[q1][w].num1].GetLength();e++)
			{
				if(edit_text1[table1[q1][w].num1].Mid(e,1)==' ')
					if(e==edit_text1[table1[q1][w].num1].GetLength()-1)
						sprintf(a1,"&nbsp ");
					else
						if(edit_text1[table1[q1][w].num1].Mid(e+1,1)==' ')
							sprintf(a1,"&nbsp");
						else
							sprintf(a1,"&nbsp ");
				else
					sprintf(a1,"%s",edit_text1[table1[q1][w].num1].Mid(e,1));
				fout1.Write(a1,strlen(a1));
			}
			sprintf(a1,"\"></TD>\r\n");
			fout1.Write(a1,strlen(a1));
			break;
		case T_TEXT:
			sprintf(a1,"\r\n<TD COLSPAN=%u ROWSPAN=%u ",
				table1[q1][w].colspan1,
				table1[q1][w].rowspan1);
			fout1.Write(a1,strlen(a1));
				sprintf(a1,"ALIGN=LEFT ");
			fout1.Write(a1,strlen(a1));
				sprintf(a1,"VALIGN=TOP>");
			fout1.Write(a1,strlen(a1));
			//sprintf(a,"%s",text_text[table[q][w].num]);
			//f.Write(a,strlen(a));
			for(e=0;e<text_text1[table1[q1][w].num1].GetLength();e++)
			{
				if(text_text1[table1[q1][w].num1].Mid(e,1)==' ')
					if(e==text_text1[table1[q1][w].num1].GetLength()-1)
						sprintf(a1,"&nbsp ");
					else
						if(text_text1[table1[q1][w].num1].Mid(e+1,1)==' ')
							sprintf(a1,"&nbsp");
						else
							sprintf(a1,"&nbsp ");
				else
					sprintf(a1,"%s",text_text1[table1[q1][w].num1].Mid(e,1));
				fout1.Write(a1,strlen(a1));
			}
			sprintf(a1,"</TD>\r\n");
			fout1.Write(a1,strlen(a1));
			break;
		case T_NONE:
			sprintf(a1,"\r\n<TD WIDTH=40 HEIGHT=40></TD>");
			fout1.Write(a1,strlen(a1));
			break;
		}//switch
	}//q
		sprintf(a1,"\r\n</TR>");
		fout1.Write(a1,strlen(a1));
	}//w

	sprintf(a1,"\r\n</TR>\r\n");
	fout1.Write(a1,strlen(a1));

	sprintf(a1,"</TABLE>\r\n</BODY>\r\n</HTML>");
	fout1.Write(a1,strlen(a1));
	fout1.Close();

//end export

	DeleteFile("editor.swp");
	return -1;

}

CString* CMainFrame::GetWordFromFile()
{
	int q;
	static CString ret;
	char z;
	int ok,len=0;
	ok=1;
	ret.Empty();

	for(q=0;q<1000;q++)
		words1[q].Empty();
	words_kol1=0;
	int in_kovichki=0;


	while(ok)
	{
		//ok=0;
		if(f1.GetPosition()==f1.GetLength())
			break;
		f1.Read(&z,1);
		switch((UCHAR)z)
		{
		case '\"':
			if(in_kovichki==1)
			{
				in_kovichki=0;
				words1[words_kol1++]+=z;
				ok=1;
			}
			else
			{
				in_kovichki=1;
				words1[++words_kol1]=z;
				ok=1;
			}
			ok=1;
			break;
		case '>':
		case 13:
		case 10:
		case ' ':
		case '<':
		case '=':
		case ';':
			if(in_kovichki==1)
			{
				words1[words_kol1]+=z;
				ok=1;
			}
			else
			{
				if(words1[words_kol1].GetLength()==0)
					words1[words_kol1++]+=z,
					ok=1;
				else
					words1[++words_kol1]+=z,
					words_kol1++;
				//return &ret;
				ok=1;
			}
			break;
		default:
			words1[words_kol1]+=z;
			ok=1;
			break;
		}//switch z
		
	}//while ok
	words_kol1+=1;
	/*CFile f1;
	f1.Open("1.1",CFile::modeCreate | CFile::modeWrite);
	char qw[500];

	sprintf(qw,"%u\r\n",words_kol);
	f1.Write(qw,strlen(qw));
	for(q=0;q<words_kol;q++)
	{
		/*if(words[q].Mid(0,1)=='\"')
		{
			words[q].Delete(0);
			words[q].Delete(words[q].GetLength()-1);
		}//=
		sprintf(qw,"%s\r\n",words[q]);
		f1.Write(qw,strlen(qw));
	}

	f1.Close();*/

	return &ret;

}

void CMainFrame::UpdateTable()
{
	int q,w,e;
	static x1,x2,y1,y2;

	for(w=0;w<20;w++)
	for(q=0;q<20;q++)
		table1[q][w].type1=T_NONE,
		table1[q][w].is1=T_NONE;
	for(q=0;q<but_kol1;q++)
	{
		x1=(but_rect1[q].left-5)/40;
		x2=(but_rect1[q].right-5)/40;
		y1=(but_rect1[q].top-30)/40;
		y2=(but_rect1[q].bottom-30)/40;
		for(w=y1;w<=y2;w++)
		for(e=x1;e<=x2;e++)
			table1[e][w].type1=T_BLOCKED,
			table1[e][w].is1=T_BUTTON;
		table1[x1][y1].type1=T_BUTTON;
		table1[x1][y1].colspan1=x2-x1+1;
		table1[x1][y1].rowspan1=y2-y1+1;
		table1[x1][y1].num1=q;
	}//for w
	for(q=0;q<edit_kol1;q++)
	{
		x1=(edit_rect1[q].left-5)/40;
		x2=(edit_rect1[q].right-5)/40;
		y1=(edit_rect1[q].top-30)/40;
		y2=(edit_rect1[q].bottom-30)/40;
		//for(w=y1;w<=y2;w++)
		for(e=x1;e<=x2;e++)
			table1[e][y1].type1=T_BLOCKED,
			table1[e][y1].is1=T_TEXTEDIT;
		table1[x1][y1].type1=T_TEXTEDIT;
		table1[x1][y1].colspan1=x2-x1+1;
		table1[x1][y1].rowspan1=y2-y1+1;
		table1[x1][y1].num1=q;
	}//for q
	for(q=0;q<text_kol1;q++)
	{
		x1=(text_rect1[q].left-5)/40;
		x2=(text_rect1[q].right-5)/40;
		y1=(text_rect1[q].top-30)/40;
		y2=(text_rect1[q].bottom-30)/40;
		for(w=y1;w<=y2;w++)
		for(e=x1;e<=x2;e++)
			table1[e][w].type1=T_BLOCKED,
			table1[e][w].is1=T_TEXT;
		table1[x1][y1].type1=T_TEXT;
		table1[x1][y1].colspan1=x2-x1+1;
		table1[x1][y1].rowspan1=y2-y1+1;
		table1[x1][y1].num1=q;
	}//for q

}

template <class qw>
void CMainFrame::swap(qw* a,qw* b)
{
	qw* e;
	e=a;
	a=b;
	b=e;
}

void CMainFrame::AlignButton(int a)
{
		int dx;
			dx=(but_rect1[a].left-5)/40;
			dx=dx*40+5;
			dx-=but_rect1[a].left;
			but_rect1[a].left+=dx;
			but_rect1[a].right+=dx;
			dx=(but_rect1[a].top-30)/40;
			dx=dx*40+30;
			dx-=but_rect1[a].top;
			but_rect1[a].top+=dx;
			but_rect1[a].bottom+=dx;

}

void CMainFrame::AlignText(int a)
{
		int dx;
			dx=(text_rect1[a].left-5)/40;
			dx=dx*40+5;
			dx-=text_rect1[a].left;
			text_rect1[a].left+=dx;
			text_rect1[a].right+=dx;
			dx=(text_rect1[a].top-30)/40;
			dx=dx*40+30;
			dx-=text_rect1[a].top;
			text_rect1[a].top+=dx;
			text_rect1[a].bottom+=dx;

}

void CMainFrame::AlignTextedit(int a)
{
	int dx;
			dx=(edit_rect1[a].left-5)/40;
			dx=dx*40+5;
			dx-=edit_rect1[a].left;
			edit_rect1[a].left+=dx;
			edit_rect1[a].right+=dx;
			dx=(edit_rect1[a].top-30)/40;
			dx=dx*40+30;
			dx-=edit_rect1[a].top;
			edit_rect1[a].top+=dx;
			edit_rect1[a].bottom+=dx;

}