// CtrlEditor.h : main header file for the CTRLEDITOR application
//

#if !defined(AFX_CTRLEDITOR_H__720AABEC_34BB_11D6_B977_00104B27A57C__INCLUDED_)
#define AFX_CTRLEDITOR_H__720AABEC_34BB_11D6_B977_00104B27A57C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CCtrlEditorApp:
// See CtrlEditor.cpp for the implementation of this class
//
class CCtrlEditorApp : public CWinApp
{
private:
    void LoadCursors();
    int RunCmdLine();
public:
	CCtrlEditorApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCtrlEditorApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CCtrlEditorApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
#define IDX_NONE        0
#define IDX_ARROW       1
#define IDX_CROSS       2
#define IDX_SIZEALL     3
#define IDX_SIZEN       4
#define IDX_SIZES       5
#define IDX_SIZEE       6
#define IDX_SIZEW       7
#define IDX_SIZENE      8
#define IDX_SIZESW      9
#define IDX_SIZENW      10
#define IDX_SIZESE      11


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CTRLEDITOR_H__720AABEC_34BB_11D6_B977_00104B27A57C__INCLUDED_)
