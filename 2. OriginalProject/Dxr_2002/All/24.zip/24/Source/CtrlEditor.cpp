// CtrlEditor.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "CtrlEditor.h"

#include "MainFrm.h"
#include "CtrlEditorDoc.h"
#include "CtrlEditorView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

HCURSOR mouseCursors[12];
/////////////////////////////////////////////////////////////////////////////
// CCtrlEditorApp

BEGIN_MESSAGE_MAP(CCtrlEditorApp, CWinApp)
	//{{AFX_MSG_MAP(CCtrlEditorApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCtrlEditorApp construction

CCtrlEditorApp::CCtrlEditorApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CCtrlEditorApp object

CCtrlEditorApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CCtrlEditorApp initialization

void CCtrlEditorApp::LoadCursors()
{
    mouseCursors[IDX_ARROW]=::LoadCursor(0,IDC_ARROW);
    mouseCursors[IDX_CROSS]=::LoadCursor(0,IDC_CROSS);
    mouseCursors[IDX_SIZEALL]=::LoadCursor(0,IDC_SIZEALL);
    mouseCursors[IDX_SIZESW]=::LoadCursor(0,IDC_SIZENESW);
    mouseCursors[IDX_SIZENE]=::LoadCursor(0,IDC_SIZENESW);
    mouseCursors[IDX_SIZEN]=::LoadCursor(0,IDC_SIZENS);
    mouseCursors[IDX_SIZES]=::LoadCursor(0,IDC_SIZENS);
    mouseCursors[IDX_SIZESE]=::LoadCursor(0,IDC_SIZENWSE);
    mouseCursors[IDX_SIZENW]=::LoadCursor(0,IDC_SIZENWSE);
    mouseCursors[IDX_SIZEW]=::LoadCursor(0,IDC_SIZEWE);
    mouseCursors[IDX_SIZEE]=::LoadCursor(0,IDC_SIZEWE);
}

BOOL CCtrlEditorApp::InitInstance()
{
#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

    // �������� ���������� ������
    if (RunCmdLine())
        return FALSE;
    
	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

    LoadCursors();
	// Register document templates

    
	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CCtrlEditorDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CCtrlEditorView));
	AddDocTemplate(pDocTemplate);

	// Enable DDE Execute open
	EnableShellOpen();
	RegisterShellFileTypes(TRUE);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();

	// Enable drag/drop open
	m_pMainWnd->DragAcceptFiles();

	return TRUE;
}
int CCtrlEditorApp::RunCmdLine()
{
    char inpFName[200],outpFName[200];
    int res=sscanf(m_lpCmdLine,"%s%s",inpFName,outpFName);
    if (res!=2)
        return FALSE;
    FILE *outpf=fopen(outpFName,"wt");
    if (!outpf)
        return FALSE;
    CFile inpf;
    if (!inpf.Open(inpFName,CFile::modeRead))
        return FALSE;
    CArchive arr(&inpf,CArchive::load);
    CCtrlEditorDoc tempDoc;
    tempDoc.LoadForm(arr);
    tempDoc.SaveHtml(outpf);

    inpf.Close();
    fclose(outpf);

    return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CCtrlEditorApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CCtrlEditorApp message handlers

