// CtrlEditorView.cpp : implementation of the CCtrlEditorView class
//

#include "stdafx.h"
#include "CtrlEditor.h"

#include "CtrlEditorDoc.h"
#include "CtrlEditorView.h"
#include "PropDlg.h"

#include "myobject.h"
#include "LoadDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CStatusBar  m_wndStatusBar;
extern HCURSOR mouseCursors[7];
extern CLoadDlg *outConsole;

CPropDlg *propDlg;

CView *viewWnd;
/////////////////////////////////////////////////////////////////////////////
// CCtrlEditorView

IMPLEMENT_DYNCREATE(CCtrlEditorView, CView)

BEGIN_MESSAGE_MAP(CCtrlEditorView, CView)
	//{{AFX_MSG_MAP(CCtrlEditorView)
	ON_WM_CREATE()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
	ON_COMMAND(ID_PROP, OnProp)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MESSAGE, OnUpdateViewMessage)
	ON_COMMAND(ID_VIEW_MESSAGE, OnViewMessage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCtrlEditorView construction/destruction

CCtrlEditorView::CCtrlEditorView()
{
    outConsole=new CLoadDlg;
    propDlg=new CPropDlg;
}

CCtrlEditorView::~CCtrlEditorView()
{
    if (outConsole)
        delete outConsole;
    if (propDlg)
        delete propDlg;
}

BOOL CCtrlEditorView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CCtrlEditorView drawing

void CCtrlEditorView::OnDraw(CDC* pDC)
{
	CCtrlEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

    pDoc->DrawObjects(pDC);
}

/////////////////////////////////////////////////////////////////////////////
// CCtrlEditorView diagnostics

#ifdef _DEBUG
void CCtrlEditorView::AssertValid() const
{
	CView::AssertValid();
}

void CCtrlEditorView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CCtrlEditorDoc* CCtrlEditorView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCtrlEditorDoc)));
	return (CCtrlEditorDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCtrlEditorView message handlers

int CCtrlEditorView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	CCtrlEditorDoc* pDoc = GetDocument();
    CClientDC dc(this);

    SetClassLong(m_hWnd,GCL_HBRBACKGROUND,(long)GetStockObject(WHITE_BRUSH));
    SetClassLong(m_hWnd,GCL_HCURSOR,0);
    Invalidate();
    UpdateWindow();

    SetCursor(mouseCursors[IDX_ARROW]);
    viewWnd=this;
    
    propDlg->Create(IDD_PROPDIALOG);
//    propDlg->ShowWindow(SW_SHOW);

    outConsole->Create(IDD_LOADDIALOG);
//    outConsole->ShowWindow(SW_SHOW);

	return 0;
}

void CCtrlEditorView::OnMouseMove(UINT nFlags, CPoint point) 
{
	CCtrlEditorDoc* pDoc = GetDocument();
    CString buff;
    int idx;
    buff.Format("mouse coordinate: x = %d ,  y = %d",point.x,point.y);
    m_wndStatusBar.SetPaneText(1,buff);

    if (pDoc->createObj)
    {
        m_wndStatusBar.SetPaneText(0,"�������� ����� ������� ���� ��� �������� �������");
        SetCursor(mouseCursors[IDX_CROSS]);
    }
    else
    {
        if (pDoc->workFlag)
        {
            if (pDoc->ChangeObject(point-prevPoint))
                prevPoint=point;
            SetCursor(mouseCursors[pDoc->workFlag]);
        }
        else
            if (idx=pDoc->GetStatusMove(point,buff))
            {
                m_wndStatusBar.SetPaneText(0,buff);
                SetCursor(mouseCursors[idx]);
            }
            else
            {
                m_wndStatusBar.SetPaneText(0,"Ready");
                SetCursor(mouseCursors[IDX_ARROW]);
            }
    }
	CView::OnMouseMove(nFlags, point);
}

void CCtrlEditorView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CCtrlEditorDoc* pDoc = GetDocument();

    pDoc->LeftClick(point);
    prevPoint=point;
    if (pDoc->workFlag)
    {
        pDoc->selObj->OkChange();
        SetCursor(mouseCursors[pDoc->workFlag]);
        SetCapture();
    }
    else
        propDlg->ShowWindow(SW_HIDE);
	
	CView::OnLButtonDown(nFlags, point);
}

void CCtrlEditorView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CCtrlEditorDoc* pDoc = GetDocument();
    if (pDoc->workFlag)
    {
        ReleaseCapture();
        pDoc->workFlag=0;
    }
	
	CView::OnLButtonUp(nFlags, point);
}

void CCtrlEditorView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	CCtrlEditorDoc* pDoc = GetDocument();
    CMyObject *curObj;

    if (!pDoc->createObj)
    {
        if (curObj=pDoc->RightClick(point))
        {
            propDlg->obj=curObj;
            propDlg->m_editPropCtrl.SetWindowText(curObj->GetText());
            propDlg->m_editPropCtrl.SetFocus();
            propDlg->m_editPropCtrl.SetSel(0,-1);
            propDlg->ShowWindow(SW_SHOW);
        }
        else
            propDlg->ShowWindow(SW_HIDE);
    }
	
	CView::OnRButtonDown(nFlags, point);
}

void CCtrlEditorView::OnProp() 
{
	CCtrlEditorDoc* pDoc = GetDocument();
    propDlg->obj=pDoc->selObj;
    propDlg->m_editPropCtrl.SetWindowText(pDoc->selObj->GetText());
    propDlg->m_editPropCtrl.SetFocus();
    propDlg->m_editPropCtrl.SetSel(0,-1);
    propDlg->ShowWindow(SW_SHOW);
}

void CCtrlEditorView::OnUpdateViewMessage(CCmdUI* pCmdUI) 
{   
    pCmdUI->SetCheck(outConsole!=NULL);
}

void CCtrlEditorView::OnViewMessage() 
{
	if (outConsole)
    {
        outConsole->DestroyWindow();
        outConsole=0;
    }
    else
    {
        outConsole=new CLoadDlg;
        outConsole->Create(IDD_LOADDIALOG);
    }
}
