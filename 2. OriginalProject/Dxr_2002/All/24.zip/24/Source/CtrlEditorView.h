// CtrlEditorView.h : interface of the CCtrlEditorView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CTRLEDITORVIEW_H__720AABF4_34BB_11D6_B977_00104B27A57C__INCLUDED_)
#define AFX_CTRLEDITORVIEW_H__720AABF4_34BB_11D6_B977_00104B27A57C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//class CPropDlg;

class CCtrlEditorView : public CView
{
protected: // create from serialization only
	CCtrlEditorView();
	DECLARE_DYNCREATE(CCtrlEditorView)

// Attributes
public:
	CCtrlEditorDoc* GetDocument();
    CPoint prevPoint;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCtrlEditorView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCtrlEditorView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CCtrlEditorView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnProp();
	afx_msg void OnUpdateViewMessage(CCmdUI* pCmdUI);
	afx_msg void OnViewMessage();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in CtrlEditorView.cpp
inline CCtrlEditorDoc* CCtrlEditorView::GetDocument()
   { return (CCtrlEditorDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CTRLEDITORVIEW_H__720AABF4_34BB_11D6_B977_00104B27A57C__INCLUDED_)
