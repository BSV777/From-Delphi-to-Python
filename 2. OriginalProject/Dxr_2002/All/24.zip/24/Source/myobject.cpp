#include "myobject.h"
#include "CtrlEditor.h"

extern CView *viewWnd;

////////////////////////////////////////CMyObject/////////////////////////
#define VIEW_X_SPACE  0
#define VIEW_Y_SPACE  0

#define SELECT_BOX_WIDTH 6

CMyObject::CMyObject()
{
   x=y=0;
   cx=DEFAULT_WIDTH;
   cy=DEFAULT_HEIGHT;
   visibleFlag=FALSE;
   selectFlag=FALSE;
}

void CMyObject::Create(int x_,int y_,int cx_,int cy_)
{
    x=x_;
    cx=cx_;
    y=y_;
    cy=cy_;
    CalcRects();
}
void CMyObject::CreateDefault(CPoint &point)
{
    x=point.x-DEFAULT_WIDTH/2;
    cx=DEFAULT_WIDTH;
    y=point.y-DEFAULT_HEIGHT/2;
    cy=DEFAULT_HEIGHT;
    CalcRects();
}

void CMyObject::CalcRects()
{
    int cx1=x+cx/2-SELECT_BOX_WIDTH/2,cy1=y+cy/2-SELECT_BOX_WIDTH/2;
    mainRect.SetRect(x,y,x+cx,y+cy);
    fieldRect.SetRect(x+2,y+2,x+cx-2,y+cy-2);
    selectRect.SetRect(x-SELECT_BOX_WIDTH,y-SELECT_BOX_WIDTH,
                       x+cx+SELECT_BOX_WIDTH,y+cy+SELECT_BOX_WIDTH);

    leftRect.SetRect(x-SELECT_BOX_WIDTH,cy1,x,cy1+SELECT_BOX_WIDTH);
    rightRect.SetRect(x+cx,cy1,x+cx+SELECT_BOX_WIDTH,cy1+SELECT_BOX_WIDTH);
    topRect.SetRect(cx1,y-SELECT_BOX_WIDTH,cx1+SELECT_BOX_WIDTH,y);
    bottomRect.SetRect(cx1,y+cy,cx1+SELECT_BOX_WIDTH,y+cy+SELECT_BOX_WIDTH);
    leftUpRect.SetRect(x-SELECT_BOX_WIDTH,y-SELECT_BOX_WIDTH,x,y);
    leftBottomRect.SetRect(x-SELECT_BOX_WIDTH,y+cy,x,y+cy+SELECT_BOX_WIDTH);
    rightUpRect.SetRect(x+cx,y-SELECT_BOX_WIDTH,x+cx+SELECT_BOX_WIDTH,y);
    rightBottomRect.SetRect(x+cx,y+cy,x+cx+SELECT_BOX_WIDTH,y+cy+SELECT_BOX_WIDTH);
}

CRect& CMyObject::Show(int show)
{
    if (show==MO_SHOW)
        visibleFlag=1;
    if (show==MO_CLEAR)
        visibleFlag=0;
    if (selectFlag)
        return selectRect;
    else
        return mainRect;
}

CRect& CMyObject::Select(BOOL selFlag)
{
    selectFlag=selFlag;
    return selectRect;
}
CRect& CMyObject::Change(CSize &delta,int workFlag)
{
    switch (workFlag) {
        case IDX_SIZEALL:
            x=x1+delta.cx;
            y=y1+delta.cy;
            break;
        case IDX_SIZEW:
            x=x1+delta.cx;
            cx=cx1-delta.cx;
            break;
        case IDX_SIZEE:
            cx=cx1+delta.cx;
            break;
        case IDX_SIZES:
            y=y1+delta.cy;
            cy=cy1-delta.cy;
            break;
        case IDX_SIZEN:
            cy=cy1+delta.cy;
            break;
        case IDX_SIZESE:
            x=x1+delta.cx;
            y=y1+delta.cy;
            cx=cx1-delta.cx;
            cy=cy1-delta.cy;
            break;
        case IDX_SIZENW:
            cx=cx1+delta.cx;
            cy=cy1+delta.cy;
            break;
        case IDX_SIZESW:
            x=x1+delta.cx;
            cx=cx1-delta.cx;
            cy=cy1+delta.cy;
            break;
        case IDX_SIZENE:
            y=y1+delta.cy;
            cx=cx1+delta.cx;
            cy=cy1-delta.cy;
            break;
    }
    CalcRects();
    updateRect.UnionRect(oldDrawRect,selectRect);
    return updateRect;
}
void CMyObject::OkChange()
{
    oldDrawRect=selectRect;
    x1=x;
    y1=y;
    cx1=cx;
    cy1=cy;
}

void CMyObject::Update()
{
    CRect updateRect;
    if (visibleFlag)
    {
        if (selectFlag)
            updateRect=selectRect;
        else
            updateRect=mainRect;
        viewWnd->InvalidateRect(updateRect);
        viewWnd->UpdateWindow();
    }
}

void CMyObject::Draw(CDC *dc)
{
    if (visibleFlag)
    {
        CBrush brush;
        brush.CreateSysColorBrush(COLOR_WINDOW);
        CBrush *oldbrush=dc->SelectObject(&brush);
        dc->Rectangle(mainRect);
        dc->SelectObject(oldbrush);
        if (selectFlag)
            DrawSelectBox(dc);
    }
}

void CMyObject::DrawSelectBox(CDC *dc)
{
    COLORREF selColor=GetSysColor(COLOR_HIGHLIGHT);
    CPen selPen;
    selPen.CreatePen(PS_DOT,1,selColor);
    CPen *oldpen=dc->SelectObject(&selPen);
    int oldbkmode=dc->SetBkMode(TRANSPARENT);
        
    dc->MoveTo(x-SELECT_BOX_WIDTH+1,y-SELECT_BOX_WIDTH+1);
    dc->LineTo(x+cx-1+SELECT_BOX_WIDTH-1,y-SELECT_BOX_WIDTH+1);
    dc->LineTo(x+cx-1+SELECT_BOX_WIDTH-1,y+cy-1+SELECT_BOX_WIDTH-1);
    dc->LineTo(x-SELECT_BOX_WIDTH+1,y+cy-1+SELECT_BOX_WIDTH-1);
    dc->LineTo(x-SELECT_BOX_WIDTH+1,y-SELECT_BOX_WIDTH+1);

    dc->SetBkMode(oldbkmode);
    dc->SelectObject(oldpen);

    dc->FillSolidRect(leftRect,selColor);
    dc->FillSolidRect(rightRect,selColor);
    dc->FillSolidRect(topRect,selColor);
    dc->FillSolidRect(bottomRect,selColor);
    dc->FillSolidRect(leftUpRect,selColor);
    dc->FillSolidRect(leftBottomRect,selColor);
    dc->FillSolidRect(rightUpRect,selColor);
    dc->FillSolidRect(rightBottomRect,selColor);
}

int CMyObject::TestPoint(CPoint &point)
{
    if (visibleFlag)
    {
        if (selectFlag)
        {
            if (leftRect.PtInRect(point))
                return IDX_SIZEW;
            if (rightRect.PtInRect(point))
                return IDX_SIZEE;
            if (topRect.PtInRect(point))
                return IDX_SIZES;
            if (bottomRect.PtInRect(point))
                return IDX_SIZEN;
            if (leftUpRect.PtInRect(point))
                return IDX_SIZESE;
            if (rightBottomRect.PtInRect(point))
                return IDX_SIZENW;
            if (leftBottomRect.PtInRect(point))
                return IDX_SIZESW;
            if (rightUpRect.PtInRect(point))
                return IDX_SIZENE;
            if (selectRect.PtInRect(point))
                return IDX_SIZEALL;
        }
        if (mainRect.PtInRect(point))
            return IDX_CROSS;
    }
    return IDX_NONE;
}
BOOL CMyObject::Intersect(CMyObject *obj)
{
    if (obj==this || !obj->IsVisible())
        return FALSE;
    CRect temp;
    return temp.IntersectRect(mainRect,obj->mainRect);
}
BOOL CMyObject::InView()
{
    return (x>=VIEW_X_SPACE && y>=VIEW_Y_SPACE &&
            cx>=MIN_WIDTH && cy>=MIN_HEIGHT);
}
void CMyObject::MoveToX(CMyObject *obj)
{
    int t;
    if (obj==this || !obj->IsVisible())
        return;
    if ((t=obj->GetRight())>x)
        x=t;
    CalcRects();
}
void CMyObject::MoveToY(CMyObject *obj)
{
    int t;
    if (obj==this || !obj->IsVisible())
        return;
    if ((t=obj->GetBottom())>y)
        y=t;
    CalcRects();
}

////////////////////////////////////////CMyButton/////////////////////////
CMyButton::CMyButton()
{}

void CMyButton::Create(int x_,int y_,int cx_,int cy_,char *capt)
{
    x=x_;
    cx=cx_;
    y=y_;
    cy=cy_;
    caption=capt;
    CalcRects();
}
void CMyButton::Draw(CDC *dc)
{
    if (visibleFlag)
    {
        CBrush brush;
        brush.CreateSysColorBrush(COLOR_BTNFACE);
        CBrush *oldbrush=dc->SelectObject(&brush);
        
        CPen penShadow(PS_SOLID,1,GetSysColor(COLOR_3DDKSHADOW));
        CPen penLShadow(PS_SOLID,1,GetSysColor(COLOR_3DSHADOW));
        CPen penLight(PS_SOLID,1,GetSysColor(COLOR_3DHILIGHT));
        CPen *oldpen=dc->SelectObject(&penLight);

        dc->Rectangle(mainRect);
        dc->SelectObject(&penShadow);
        dc->MoveTo(x,y+cy-1);
        dc->LineTo(x+cx-1,y+cy-1);
        dc->LineTo(x+cx-1,y-1);
        dc->SelectObject(&penLShadow);
        dc->MoveTo(x+1,y+cy-2);
        dc->LineTo(x+cx-2,y+cy-2);
        dc->LineTo(x+cx-2,y);

        dc->SelectObject(oldbrush);
        dc->SelectObject(oldpen);

        if (!caption.IsEmpty())
        {
            CFont capFont;
            capFont.CreateFont(FONT_HEIGHT,0,0,0,FW_NORMAL,0,0,0,
                                DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,
                                CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,
                                DEFAULT_PITCH,"MS Sans Serif");
            CFont *oldfont=dc->SelectObject(&capFont);
            COLORREF oldtextcolor=dc->SetTextColor(GetSysColor(COLOR_BTNTEXT));
            int oldbkmode=dc->SetBkMode(TRANSPARENT);

            dc->DrawText(caption,fieldRect,DT_SINGLELINE|DT_VCENTER|DT_CENTER|DT_WORDBREAK);

            dc->SetTextColor(oldtextcolor);
            dc->SetBkMode(oldbkmode);
            dc->SelectObject(oldfont);
        }
        if (selectFlag)
            DrawSelectBox(dc);
    }
}

/////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////CMyEditText/////////////////////////

CMyEditText::CMyEditText()
{}

void CMyEditText::Create(int x_,int y_,int cx_,int cy_,char *text_)
{
    x=x_;
    cx=cx_;
    y=y_;
    cy=DEFAULT_HEIGHT;
    text=text_;
    CalcRects();
}
void CMyEditText::UpdateDrawText(CDC *dc)
{
    CFont textFont;
    textFont.CreateFont(FONT_HEIGHT,0,0,0,FW_NORMAL,0,0,0,
                        DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,
                        CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,
                        DEFAULT_PITCH,"MS Sans Serif");
    CFont *oldfont=dc->SelectObject(&textFont);

    drawText=text;
    CSize tSize=dc->GetTextExtent(drawText);
    while (tSize.cx > (cx-2*2-GOR_SPACE*2) )
    {
        drawText=drawText.Left(drawText.GetLength()-1);
        tSize=dc->GetTextExtent(drawText);
    }
    dc->SelectObject(oldfont);
}
BOOL CMyEditText::InView()
{
    return (x>=VIEW_X_SPACE && y>=VIEW_Y_SPACE &&
            cx>=MIN_WIDTH && cy==DEFAULT_HEIGHT);
}

void CMyEditText::Draw(CDC *dc)
{
    if (visibleFlag)
    {
        CBrush brush;
        brush.CreateSysColorBrush(COLOR_WINDOW);
        CBrush *oldbrush=dc->SelectObject(&brush);
        
        CPen penLight(PS_SOLID,1,GetSysColor(COLOR_3DHILIGHT));
        CPen penShadow(PS_SOLID,1,GetSysColor(COLOR_3DDKSHADOW));
        CPen penLShadow(PS_SOLID,1,GetSysColor(COLOR_3DSHADOW));
        CPen penDLight(PS_SOLID,1,GetSysColor(COLOR_3DLIGHT));
        CPen *oldpen=dc->SelectObject(&penLShadow);

        dc->Rectangle(mainRect);
        dc->SelectObject(&penLight);
        dc->MoveTo(x,y+cy-1);
        dc->LineTo(x+cx-1,y+cy-1);
        dc->LineTo(x+cx-1,y-1);
        dc->SelectObject(&penDLight);
        dc->MoveTo(x+1,y+cy-2);
        dc->LineTo(x+cx-2,y+cy-2);
        dc->LineTo(x+cx-2,y);
        dc->SelectObject(&penShadow);
        dc->MoveTo(x+cx-3,y+1);
        dc->LineTo(x+1,y+1);
        dc->LineTo(x+1,y+cy-2);

        dc->SelectObject(oldbrush);
        dc->SelectObject(oldpen);

        if (!text.IsEmpty())
        {
            UpdateDrawText(dc);
            CFont textFont;
            CRect tRect(x+2+GOR_SPACE,y+2+VERT_SPACE,x+cx-3-GOR_SPACE,y+cy-3-VERT_SPACE);
            textFont.CreateFont(FONT_HEIGHT,0,0,0,FW_NORMAL,0,0,0,
                                DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,
                                CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,
                                DEFAULT_PITCH,"MS Sans Serif");
            CFont *oldfont=dc->SelectObject(&textFont);
            COLORREF oldtextcolor=dc->SetTextColor(GetSysColor(COLOR_BTNTEXT));
            int oldbkmode=dc->SetBkMode(TRANSPARENT);

            dc->DrawText(drawText,tRect,DT_SINGLELINE|DT_TOP|DT_LEFT|DT_WORDBREAK);

            dc->SetTextColor(oldtextcolor);
            dc->SetBkMode(oldbkmode);
            dc->SelectObject(oldfont);
        }
        if (selectFlag)
            DrawSelectBox(dc);
    }
}

/////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////CMyStaticText/////////////////////////

CMyStaticText::CMyStaticText()
{}

void CMyStaticText::Create(int x_,int y_,int cx_,int cy_,char *text_)
{
    x=x_;
    cx=cx_;
    y=y_;
    cy=cy_;
    text=text_;
    CalcRects();
}

void CMyStaticText::Draw(CDC *dc)
{
    if (visibleFlag)
    {
        dc->FillSolidRect(mainRect,GetSysColor(COLOR_BTNFACE));

        if (!text.IsEmpty())
        {
            CFont textFont;
            textFont.CreateFont(FONT_HEIGHT,0,0,0,FW_NORMAL,0,0,0,
                                DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,
                                CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,
                                DEFAULT_PITCH,"MS Sans Serif");
            CFont *oldfont=dc->SelectObject(&textFont);
            COLORREF oldtextcolor=dc->SetTextColor(GetSysColor(COLOR_BTNTEXT));
            int oldbkmode=dc->SetBkMode(TRANSPARENT);

            dc->DrawText(text,mainRect,DT_SINGLELINE|DT_TOP|DT_LEFT|DT_WORDBREAK);

            dc->SetTextColor(oldtextcolor);
            dc->SetBkMode(oldbkmode);
            dc->SelectObject(oldfont);
        }
        if (selectFlag)
            DrawSelectBox(dc);
    }
}

