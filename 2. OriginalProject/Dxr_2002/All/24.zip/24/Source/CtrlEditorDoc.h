// CtrlEditorDoc.h : interface of the CCtrlEditorDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CTRLEDITORDOC_H__720AABF2_34BB_11D6_B977_00104B27A57C__INCLUDED_)
#define AFX_CTRLEDITORDOC_H__720AABF2_34BB_11D6_B977_00104B27A57C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "myobject.h"

/////////////////////����� ��� ������� ������� ������ ����������
class CMyScaner;

struct Td_tag
{
    int objType;
    int rowspan;
    int colspan;
};

class CCtrlEditorDoc : public CDocument
{
protected: // create from serialization only
	DECLARE_DYNCREATE(CCtrlEditorDoc)

// Attributes
public:
    int workFlag;
    
    CMyButton button;
    CMyEditText editText;
    CMyStaticText label;
    CMyObject *selObj,*createObj;

///////// HTML covert vars 
    int numRows,numColumns;
    int rowsArray[5],columnsArray[5];
    int tableWidth,tableHeight;
    Td_tag HtmlTable[4][4];
    int objTableCoord[3][3]; // 0,1 - ���������� � �������, 2 - ������ � ��������
    int columnHeightFlag;
    int rowWidthFlag;
    int createFormFlag;
// Operations
public:
    void DrawObjects(CDC *dc);
    void CreateObject(CPoint &point);
    void SelectObject(CMyObject *obj);
    BOOL ChangeObject(CSize &delta);
    void LeftClick(CPoint &point);
    CMyObject* RightClick(CPoint &point);
    int GetStatusMove(CPoint &point,CString &buff);
    void SaveForm(CArchive& ar);
    void LoadForm(CArchive& ar);
    void LoadObj(CMyScaner *scan);
    CString ConvertStr(CString);

    void SaveHtml(FILE*);
    void CalcTable();
    void OptimizeTable();
    void SetSizeCells();
    void AddObjFromTable(CMyObject*,int&,int&);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCtrlEditorDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	CCtrlEditorDoc();
	virtual ~CCtrlEditorDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CCtrlEditorDoc)
	afx_msg void OnUpdateButton(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEdittext(CCmdUI* pCmdUI);
	afx_msg void OnUpdateLabel(CCmdUI* pCmdUI);
	afx_msg void OnButton();
	afx_msg void OnEdittext();
	afx_msg void OnLabel();
	afx_msg void OnUpdateProp(CCmdUI* pCmdUI);
	afx_msg void OnDelete();
	afx_msg void OnUpdateDelete(CCmdUI* pCmdUI);
	afx_msg void OnExport();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CTRLEDITORDOC_H__720AABF2_34BB_11D6_B977_00104B27A57C__INCLUDED_)
