// CtrlEditorDoc.cpp : implementation of the CCtrlEditorDoc class
//

#include "stdafx.h"
#include "CtrlEditor.h"

#include "CtrlEditorDoc.h"
#include "scaner.h"
#include "LoadDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CStatusBar  m_wndStatusBar;
extern HCURSOR mouseCursors[7];
extern CView *viewWnd;

CLoadDlg *outConsole=0;
/////////////////////////////////////////////////////////////////////////////
// CCtrlEditorDoc

IMPLEMENT_DYNCREATE(CCtrlEditorDoc, CDocument)

BEGIN_MESSAGE_MAP(CCtrlEditorDoc, CDocument)
	//{{AFX_MSG_MAP(CCtrlEditorDoc)
	ON_UPDATE_COMMAND_UI(ID_BUTTON, OnUpdateButton)
	ON_UPDATE_COMMAND_UI(ID_EDITTEXT, OnUpdateEdittext)
	ON_UPDATE_COMMAND_UI(ID_LABEL, OnUpdateLabel)
	ON_COMMAND(ID_BUTTON, OnButton)
	ON_COMMAND(ID_EDITTEXT, OnEdittext)
	ON_COMMAND(ID_LABEL, OnLabel)
	ON_UPDATE_COMMAND_UI(ID_PROP, OnUpdateProp)
	ON_COMMAND(ID_DELETE, OnDelete)
	ON_UPDATE_COMMAND_UI(ID_DELETE, OnUpdateDelete)
	ON_COMMAND(ID_EXPORT, OnExport)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCtrlEditorDoc construction/destruction

CCtrlEditorDoc::CCtrlEditorDoc()
{
    selObj=0;
}

CCtrlEditorDoc::~CCtrlEditorDoc()
{
}

BOOL CCtrlEditorDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

    createObj=0;
    if (selObj)
    {
        selObj->Select(FALSE);
        selObj=0;
    }
    workFlag=0;
    button.Show(MO_CLEAR);
    editText.Show(MO_CLEAR);
    label.Show(MO_CLEAR);

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CCtrlEditorDoc serialization

CString CCtrlEditorDoc::ConvertStr(CString str)
{
    for (int i=0;i<str.GetLength();i++)
        if (str[i]=='"' || str[i]=='\\')
        {
            str.Insert(i,'\\');
            i+=1;
        }
    return str;
}
void CCtrlEditorDoc::SaveForm(CArchive& ar)
{
    CString buff;
    int x,y,cx,cy;
    if (button.IsVisible())
    {
        button.GetParam(x,y,cx,cy);
        buff.Format("<Button left=\"%d\"; top=\"%d\"; right=\"%d\"; bottom=\"%d\"; "
                    "Caption=\"%s\">\r\n",x,y,x+cx,y+cy,
                    ConvertStr(button.GetText()));
        ar.WriteString(buff);
    }
    if (editText.IsVisible())
    {
        editText.GetParam(x,y,cx,cy);
        buff.Format("<TextEdit left=\"%d\"; top=\"%d\"; right=\"%d\"; bottom=\"%d\"; "
                    "Text=\"%s\">\r\n",x,y,x+cx,y+cy,
                    ConvertStr(editText.GetText()));
        ar.WriteString(buff);
    }
    if (label.IsVisible())
    {
        label.GetParam(x,y,cx,cy);
        buff.Format("<Label left=\"%d\"; top=\"%d\"; right=\"%d\"; bottom=\"%d\"; "
                    "Text=\"%s\">\r\n",x,y,x+cx,y+cy,
                    ConvertStr(label.GetText()));
        ar.WriteString(buff);
    }
    ar.WriteString("\r\n");
}
void CCtrlEditorDoc::LoadForm(CArchive& ar)
{
    CString str;
    CMyScaner scaner;
    int res;
    
    if (outConsole)
    {
        outConsole->m_outStr.Empty();
        outConsole->ShowWindow(SW_SHOW);
    }
    do {
        res=ar.ReadString(str);
        scaner.ScanString(str);
        LoadObj(&scaner);
    } while (res);
    scaner.EndMessage();
}

void CCtrlEditorDoc::LoadObj(CMyScaner *scan)
{
    CMyObject *curObj=0;
    if (scan->curObjType)
    {
        if (scan->curObjType==NAME_BUTTON)
            if (button.IsVisible())
                scan->Warning(WARNING_OBJ_ALREADY,"button");
            else
                curObj=&button;
        if (scan->curObjType==NAME_LABEL)
            if (label.IsVisible())
                scan->Warning(WARNING_OBJ_ALREADY,"label");
            else
                curObj=&label;
        if (scan->curObjType==NAME_EDITTEXT)
            if (editText.IsVisible())
                scan->Warning(WARNING_OBJ_ALREADY,"textedit");
            else
                curObj=&editText;
    }
    if (curObj)
    {
        curObj->Create(scan->left,scan->top,
                       scan->right-scan->left,scan->bottom-scan->top);
        curObj->SetText(scan->text);
        curObj->Show(MO_SHOW);
        if (curObj->Intersect(&button) || 
            curObj->Intersect(&editText) || 
            curObj->Intersect(&label))
        {
            if (!scan->xSetFlag)
            {
                scan->Warning(WARNING_OBJ_INTERSECT,"");
                curObj->MoveToX(&button);
                curObj->MoveToX(&editText);
                curObj->MoveToX(&label);
                return;
            }
            if (!scan->ySetFlag)
            {
                scan->Warning(WARNING_OBJ_INTERSECT,"");
                curObj->MoveToY(&button);
                curObj->MoveToY(&editText);
                curObj->MoveToY(&label);
                return;
            }
            scan->Error(ERROR_OBJ_INTERSECT,"");
            curObj->Show(MO_CLEAR);
        }
    }
}


void CCtrlEditorDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
        SaveForm(ar);
	else
    {
        OnNewDocument();
        LoadForm(ar);
    }
}

/////////////////////////////////////////////////////////////////////////////
// CCtrlEditorDoc diagnostics

#ifdef _DEBUG
void CCtrlEditorDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CCtrlEditorDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCtrlEditorDoc commands

void CCtrlEditorDoc::CreateObject(CPoint &point)
{
    createObj->CreateDefault(point);
    if (createObj->InView() && 
        !createObj->Intersect(&button) && 
        !createObj->Intersect(&editText) && 
        !createObj->Intersect(&label))
    {
        m_wndStatusBar.SetPaneText(0,"Ready");
        SetCursor(mouseCursors[IDX_ARROW]);
        viewWnd->InvalidateRect(createObj->Show(MO_SHOW));
        viewWnd->UpdateWindow();
        SelectObject(createObj);
        createObj=0;
    }
    else
        m_wndStatusBar.SetPaneText(0,"������ �������� �� ������� ���� ��� ������������ � ������ ��������");
}

void CCtrlEditorDoc::DrawObjects(CDC *dc)
{
    if (!button.IsSelected()) button.Draw(dc);
    if (!editText.IsSelected()) editText.Draw(dc);
    if (!label.IsSelected()) label.Draw(dc);
    if (selObj) selObj->Draw(dc);
}

int CCtrlEditorDoc::GetStatusMove(CPoint &point,CString &buff)
{
    int ret=0,selret=0;
    if (!button.IsSelected()) ret=button.TestPoint(point);
    if (!editText.IsSelected() && !ret) ret=editText.TestPoint(point);
    if (!label.IsSelected() && !ret) ret=label.TestPoint(point);
    if (selObj) selret=selObj->TestPoint(point);
    if (selret) ret=selret;

    switch (ret) {
        case IDX_CROSS: buff="�������� ����� ������� ���� ��� ��������� �������, ������ ������� ��� ����� ������"; break;
        case IDX_SIZEALL: buff="�������� ����� ������� ���� ��� ����������� �������, ������ ������� ��� ����� ������"; break;
        case IDX_SIZEN:
        case IDX_SIZES:
        case IDX_SIZEE:
        case IDX_SIZEW:
        case IDX_SIZENE:
        case IDX_SIZESW:
        case IDX_SIZENW:
        case IDX_SIZESE: buff="�������� ����� ������� ���� ��� ��������� �������� �������, ������ ������� ��� ����� ������"; break;
    }
    return ret;
}
void CCtrlEditorDoc::SelectObject(CMyObject *obj)
{
    if (selObj)
        viewWnd->InvalidateRect(selObj->Select(FALSE));
    selObj=obj;
    viewWnd->InvalidateRect(selObj->Select(TRUE));
    viewWnd->UpdateWindow();
}

CMyObject* CCtrlEditorDoc::RightClick(CPoint &point)
{
    if (button.TestPoint(point))
        return &button;
    if (editText.TestPoint(point))
        return &editText;
    if (label.TestPoint(point))
        return &label;
    return 0;
}
void CCtrlEditorDoc::LeftClick(CPoint &point)
{
    if (createObj)
        CreateObject(point);
    else
    {
        if (selObj) 
            if (workFlag=selObj->TestPoint(point))
                return;
        if (!button.IsSelected())
            if (button.TestPoint(point))
            {
                SelectObject(&button);
                workFlag=IDX_SIZEALL;
                return;
            }
        if (!editText.IsSelected())
            if (editText.TestPoint(point))
            {
                SelectObject(&editText);
                workFlag=IDX_SIZEALL;
                return;
            }
        if (!label.IsSelected()) 
            if (label.TestPoint(point))
            {
                SelectObject(&label);
                workFlag=IDX_SIZEALL;
                return;
            }
        if (selObj) 
        {
            viewWnd->InvalidateRect(selObj->Select(FALSE));
            viewWnd->UpdateWindow();
            selObj=0;
        }
    }
}

BOOL CCtrlEditorDoc::ChangeObject(CSize &delta)
{
    CRect rect;

    rect=selObj->Change(delta,workFlag);
    if (!selObj->InView() || 
        selObj->Intersect(&button) || 
        selObj->Intersect(&editText) || 
        selObj->Intersect(&label))
    {
        delta.cx=0;
        delta.cy=0;
        selObj->Change(delta,workFlag);
        m_wndStatusBar.SetPaneText(0,"������ �� ����� ������������ � ������ �������� � �������� �� ������� 0");
        return FALSE;
    }
    else
    {
        CString s;
        int x,y,cx,cy;
        selObj->GetParam(x,y,cx,cy);

        s.Format("left=%d top=%d right=%d bottom=%d",x,y,x+cx,y+cy);
        m_wndStatusBar.SetPaneText(0,s);

        selObj->OkChange();
        viewWnd->InvalidateRect(rect);
        viewWnd->UpdateWindow();
        return TRUE;
    }
}

void CCtrlEditorDoc::OnButton() 
{
    if (createObj==&button)
    {   createObj=0;return; }

    if (button.IsVisible())
    {
        viewWnd->InvalidateRect(button.Show(MO_CLEAR));
        viewWnd->UpdateWindow();
        if (button.IsSelected())
            button.Select(FALSE);
    }
    else
        createObj=&button;
}
void CCtrlEditorDoc::OnEdittext() 
{
    if (createObj==&editText)
    {   createObj=0;return; }

    if (editText.IsVisible())
    {
        viewWnd->InvalidateRect(editText.Show(MO_CLEAR));
        viewWnd->UpdateWindow();
        if (editText.IsSelected())
            editText.Select(FALSE);
    }
    else
        createObj=&editText;
}
void CCtrlEditorDoc::OnLabel() 
{
    if (createObj==&editText)
    {   createObj=0;return; }

    if (label.IsVisible())
    {
        viewWnd->InvalidateRect(label.Show(MO_CLEAR));
        viewWnd->UpdateWindow();
        if (label.IsSelected())
            label.Select(FALSE);
    }
    else
        createObj=&label;
}


void CCtrlEditorDoc::OnUpdateButton(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck(button.IsVisible() || createObj==&button);
}
void CCtrlEditorDoc::OnUpdateEdittext(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck(editText.IsVisible() || createObj==&editText);
}
void CCtrlEditorDoc::OnUpdateLabel(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck(label.IsVisible() || createObj==&label);
}


void CCtrlEditorDoc::OnUpdateProp(CCmdUI* pCmdUI) 
{
    pCmdUI->Enable((selObj!=0));
}

void CCtrlEditorDoc::OnDelete() 
{
    if (selObj)
    {
        viewWnd->InvalidateRect(selObj->Show(MO_CLEAR));
        viewWnd->UpdateWindow();
        selObj=0;
    }
}

void CCtrlEditorDoc::OnUpdateDelete(CCmdUI* pCmdUI) 
{
    pCmdUI->Enable((selObj!=0));
}

///////////////////////////////// ������� � html-������ //////////////////////
void CCtrlEditorDoc::OnExport() 
{
    CFileDialog expDlg(FALSE,"html","form",OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
                       "HTML Files (*.html,*.htm)|*.html;*.htm|All Files (*.*)|*.*||");
    if (expDlg.DoModal()==IDOK)
    {
        FILE *htmFile=fopen(expDlg.GetPathName( ),"wt");
        if (htmFile)
        {
            SaveHtml(htmFile);
            fclose(htmFile);
        }

    }
}

//////////////////////////////////////////////////////////////////
#define HEIGHT_COLUMN_NAME  4
#define WIDTH_ROW_NAME      8
#define SKIP_NAME           -1

void CCtrlEditorDoc::SaveHtml(FILE *htmFile)
{
    fprintf(htmFile,"<HTML>\n"
                    "<HEAD>\n"
                    "<TITLE>CtrlEditor form export</TITLE>\n"
                    "<META content=\"text/html; charset=windows-1251\" http-equiv=Content-Type>\n"
                    "</HEAD>\n"
                    "<BODY topmargin=0 leftmargin=0 marginwidth=0 marginheight=0 BGCOLOR=\"#ffffff\" TEXT=\"#000000\">\n"
                    "\n");
    CalcTable();
    OptimizeTable();

    int i,j;
    if (numRows>1)
    {
        if (createFormFlag)
            fprintf(htmFile,"<FORM action=\"\" method=\"post\">\n");
        fprintf(htmFile,"<TABLE WIDTH=\"%d\" cellPadding=0 cellSpacing=0 BORDER=0>\n",tableWidth);
        for (i=0;i<numRows;i++)
        {
            fprintf(htmFile,"<TR VALIGN=\"TOP\">\n");
            for (j=0;j<numColumns;j++)
            {
                if (HtmlTable[i][j].objType!=SKIP_NAME)
                {
                    fprintf(htmFile,"   <TD");
                    if (HtmlTable[i][j].objType&WIDTH_ROW_NAME)
                        fprintf(htmFile," WIDTH=\"%d\"",columnsArray[j+1]-columnsArray[j]);
                    if (HtmlTable[i][j].rowspan)
                        fprintf(htmFile," ROWSPAN=\"%d\"",HtmlTable[i][j].rowspan);
                    if (HtmlTable[i][j].colspan)
                        fprintf(htmFile," COLSPAN=\"%d\"",HtmlTable[i][j].colspan);
                    fprintf(htmFile,">");

                    switch (HtmlTable[i][j].objType&0x7) {
                        case HEIGHT_COLUMN_NAME:
                            fprintf(htmFile,"<IMG SRC=\"1.gif\" WIDTH=\"1\" HEIGHT=\"%d\">",
                                                rowsArray[i+1]-rowsArray[i]);
                            break;
                        case NAME_BUTTON:
                            fprintf(htmFile,"<INPUT TYPE=\"Submit\" VALUE=\"%s\" "
                                            "STYLE=\"height: %d;  width: %d\">",
                                    button.GetText(),button.GetHeight(),button.GetWidth());
                            break;
                        case NAME_EDITTEXT:
                            fprintf(htmFile,"<INPUT TYPE=\"text\" VALUE=\"%s\" "
                                            "SIZE=\"%d\" STYLE=\"height: %d; width: %d\">",
                                        editText.GetText(),editText.GetWidth()/9,
                                        editText.GetHeight(),editText.GetWidth());
                            break;
                        case NAME_LABEL:
                            fprintf(htmFile,"%s",label.GetText());
                            break;
    /*                        default:
                                fprintf(htmFile,"&nbsp");*/
                    }
                    fprintf(htmFile,"</TD>\n");
                }
            }
            fprintf(htmFile,"</TR>\n");
        }
        fprintf(htmFile,"</TABLE>\n");
        if (createFormFlag)
            fprintf(htmFile,"</FORM>\n");
    }
    fprintf(htmFile,"</HEAD>\n"
                    "</HTML>\n");
}

void CCtrlEditorDoc::AddObjFromTable(CMyObject *obj,int &objy,int &objx)
{
    int i=0,j;
    int x=obj->GetLeft(),y=obj->GetTop(),
        x1=obj->GetRight(),y1=obj->GetBottom();
    objy=-1;
    int skipFlag=0;

    for (i=0;i<numRows;i++)
    {
        if (y<rowsArray[i])
        {
            for (j=numRows;j>i;j--)
                rowsArray[j]=rowsArray[j-1];
            for (j=0;j<3;j++)
                if (objTableCoord[j][0]>=i+1)
                    objTableCoord[j][0]++;
            rowsArray[i]=y;
            objy=i+1;
            break;
        }
        if (y==rowsArray[i])
        {
            if (!y)
                rowWidthFlag=1;
            skipFlag=1;
            objy=i+1;
            break;
        }
    }
    if (objy==-1 && !skipFlag)
    {
        rowsArray[i]=y;
        objy=i+1;
    }
    if (!skipFlag)
        numRows++;
    if (y1>tableHeight)
        tableHeight=y1;

    objx=-1;
    skipFlag=0;
    for (i=0;i<numColumns;i++)
    {
        if (x<columnsArray[i])
        {
            for (j=numColumns;j>i;j--)
                columnsArray[j]=columnsArray[j-1];
            for (j=0;j<3;j++)
                if (objTableCoord[j][1]>=i+1)
                    objTableCoord[j][1]++;
            columnsArray[i]=x;
            objx=i+1;
            break;
        }
        if (x==columnsArray[i])
        {
            if (!x)
                columnHeightFlag=1;
            skipFlag=1;
            objx=i+1;
            break;
        }
    }
    if (objx==-1 && !skipFlag)
    {
        columnsArray[i]=x;
        objx=i+1;
    }
    if (!skipFlag)
        numColumns++;
    if (x1>tableWidth)
        tableWidth=x1;
}
void CCtrlEditorDoc::SetSizeCells()
{
    int i;

    if (columnHeightFlag && numColumns)
    {
        for (i=0;i<numRows;i++)
            HtmlTable[i][numColumns].objType|=HEIGHT_COLUMN_NAME;
        numColumns++;
        columnsArray[numColumns]=columnsArray[numColumns-1];
    }else
        for (i=0;i<numRows;i++)
            HtmlTable[i][0].objType|=HEIGHT_COLUMN_NAME;

    if (rowWidthFlag && numRows)
    {
        for (i=0;i<numColumns;i++)
            HtmlTable[numRows][i].objType|=WIDTH_ROW_NAME;
        numRows++;
        rowsArray[numRows]=rowsArray[numRows-1];
    }else
        for (i=0;i<numColumns;i++)
            HtmlTable[0][i].objType|=WIDTH_ROW_NAME;
}

void CCtrlEditorDoc::CalcTable()
{
    numRows=1;numColumns=1;
    tableWidth=0;tableHeight=0;
    columnHeightFlag=0;
    rowWidthFlag=0;
    createFormFlag=0;
    memset(&rowsArray,0,5*sizeof(int));
    memset(&columnsArray,0,5*sizeof(int));
    memset(&objTableCoord,0,3*3*sizeof(int));
    memset(&HtmlTable,0,4*4*sizeof(Td_tag));

    if (button.IsVisible())
    {
        AddObjFromTable(&button,objTableCoord[NAME_BUTTON-1][0],
                                objTableCoord[NAME_BUTTON-1][1]);
        objTableCoord[NAME_BUTTON-1][2]=button.GetHeight();
        createFormFlag=1;
    }
    if (editText.IsVisible())
    {
        AddObjFromTable(&editText,objTableCoord[NAME_EDITTEXT-1][0],
                                  objTableCoord[NAME_EDITTEXT-1][1]);
        objTableCoord[NAME_EDITTEXT-1][2]=editText.GetHeight();
        createFormFlag=1;
    }
    if (label.IsVisible())
    {
        AddObjFromTable(&label,objTableCoord[NAME_LABEL-1][0],
                               objTableCoord[NAME_LABEL-1][1]);
        objTableCoord[NAME_LABEL-1][2]=label.GetHeight();
    }
    columnsArray[numColumns]=tableWidth;
    rowsArray[numRows]=tableHeight;
    if (button.IsVisible())
        HtmlTable[objTableCoord[NAME_BUTTON-1][0]-1]
                 [objTableCoord[NAME_BUTTON-1][1]-1].objType=NAME_BUTTON;
    if (editText.IsVisible())
        HtmlTable[objTableCoord[NAME_EDITTEXT-1][0]-1]
                 [objTableCoord[NAME_EDITTEXT-1][1]-1].objType=NAME_EDITTEXT;
    if (label.IsVisible())
        HtmlTable[objTableCoord[NAME_LABEL-1][0]-1]
                 [objTableCoord[NAME_LABEL-1][1]-1].objType=NAME_LABEL;
    SetSizeCells();
}
void CCtrlEditorDoc::OptimizeTable()
{
    int i,j,i1,j1,x,y,h,dh;
    int numColSpan;
    int flag;
    // ������� ������ �������� � �������
    for (i=0;i<3;i++)
    {
        x=objTableCoord[i][1]-1;
        j=y=objTableCoord[i][0]-1;
        h=objTableCoord[i][2];
        if (!h)
            continue;
        dh=rowsArray[j+1]-rowsArray[j];
        while (dh<h)
        {
            dh+=rowsArray[++j+1]-rowsArray[j];
            HtmlTable[j][x].objType=SKIP_NAME;
        }
        j-=y;
        if (j) HtmlTable[y][x].rowspan=j+1;
    }
    // �������� ����� ��� ������� � ��������
    for (i=0;i<3;i++)
    {
        j1=x=objTableCoord[i][1]-1;
        y=objTableCoord[i][0]-1;
        j=HtmlTable[y][x].rowspan-1;
        if (j==-1) j=0;
        flag=1;
        numColSpan=0;
        while(flag)
        {
            if (++j1>=numColumns)
            { flag=0; break; }
            for(i1=y;i1<=y+j;i1++)
                if (HtmlTable[i1][j1].objType)
                { flag=0;break; }
            if (flag)
            {
                for(i1=y;i1<=y+j;i1++)
                    HtmlTable[i1][j1].objType=SKIP_NAME;
                numColSpan++;
            }
        }
        if (numColSpan) HtmlTable[y][x].colspan=numColSpan+1;
    }
    // ���������� ������ ������
    // �� �����������
    for (i=0,j=0;i<numRows;i++,j=0)
    {
        if ((rowWidthFlag && i==numRows-1) ||
            (!rowWidthFlag && !i))
            continue;
        while (j<numColumns)
        {
            while ( HtmlTable[i][j].objType!=0 && 
                    (HtmlTable[i][j].objType)!=HEIGHT_COLUMN_NAME &&
                    j<numColumns) j++;
            if (j<numColumns)
            {
                x=j;
                do 
                    j++;
                while (HtmlTable[i][j].objType==0 && j<numColumns);
                numColSpan=j-x;
                if (numColSpan>1)
                {
                    for (j=x+1;j<x+numColSpan;j++)
                        HtmlTable[i][j].objType=SKIP_NAME;
                    HtmlTable[i][x].colspan=numColSpan;
                }
            }
        }
    }
}
