// PropDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CtrlEditor.h"
#include "PropDlg.h"
#include "myobject.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropDlg dialog


CPropDlg::CPropDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPropDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPropDlg)
	//}}AFX_DATA_INIT
}


void CPropDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropDlg)
	DDX_Control(pDX, IDC_EDITPROP, m_editPropCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropDlg, CDialog)
	//{{AFX_MSG_MAP(CPropDlg)
	ON_EN_CHANGE(IDC_EDITPROP, OnChangeEditprop)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropDlg message handlers

void CPropDlg::OnChangeEditprop() 
{
    CString tstr;
    m_editPropCtrl.GetWindowText(tstr);
    obj->SetText(tstr);
    obj->Update();
}
