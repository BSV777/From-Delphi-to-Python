//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CtrlEditor.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_CTRLEDTYPE                  129
#define IDD_PROPDIALOG                  130
#define IDD_LOADDIALOG                  132
#define IDC_EDIT1                       1003
#define IDC_CONSOLE                     1003
#define IDC_BUTTON1                     1004
#define IDC_EDITPROP                    1005
#define ID_EDITPROP                     32770
#define ID_NEW_BUTTON                   32771
#define ID_BUTTON                       32772
#define ID_LABEL                        32777
#define ID_EDITTEXT                     32778
#define ID_PROP                         32779
#define ID_DELETE                       32780
#define ID_EXPORT                       32781
#define ID_VIEW_MESSAGE                 32782

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32783
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
