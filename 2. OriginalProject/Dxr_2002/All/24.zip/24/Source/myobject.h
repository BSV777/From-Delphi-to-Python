#ifndef _MYOBJECT_
#define _MYOBJECT_

#include "stdafx.h"

#define MO_CLEAR    0
#define MO_SHOW     1

#define FONT_HEIGHT 13

#define VERT_SPACE  4
#define GOR_SPACE  2

#define DEFAULT_HEIGHT (FONT_HEIGHT+VERT_SPACE*2+2*2)
#define DEFAULT_WIDTH (FONT_HEIGHT*5+GOR_SPACE*2+2*2)
#define MIN_HEIGHT (VERT_SPACE*2+2*2)
#define MIN_WIDTH (GOR_SPACE*2+2*2)

////////////////////////////// ������� ����� ////////////////////////////
class CMyObject
{
private:
    CRect updateRect;
protected:
    int x1,y1,cx1,cy1;
    int x,y,cx,cy;

    BOOL visibleFlag;
    BOOL selectFlag;

    CRect oldDrawRect;  

    CRect mainRect;
    CRect fieldRect;
    CRect selectRect;  
    CRect leftRect;
    CRect rightRect;
    CRect topRect;
    CRect bottomRect;
    CRect leftUpRect;
    CRect leftBottomRect;
    CRect rightUpRect;
    CRect rightBottomRect;

    void CalcRects();
public:

    int GetLeft() {return x;}
    int GetTop() {return y;}
    int GetRight() {return x+cx;}
    int GetBottom() {return y+cy;}
    int GetWidth() {return cx;}
    int GetHeight() {return cy;}
    CMyObject();
    CRect& Show(int);
    CRect& Select(BOOL);
    CRect& Change(CSize &delta,int);
    void OkChange();
    BOOL IsSelected() {return selectFlag;}
    BOOL IsVisible() {return visibleFlag;}
    void GetParam(int &x_,int &y_,int &cx_,int &cy_)
        {x_=x; y_=y; cx_=cx; cy_=cy; }

    void Create(int,int,int,int);
    void CreateDefault(CPoint &point);
    void Update();
    virtual void Draw(CDC*);
    virtual void DrawSelectBox(CDC*);
    virtual int TestPoint(CPoint &point);
    BOOL Intersect(CMyObject *obj);
    void MoveToX(CMyObject *obj);
    void MoveToY(CMyObject *obj);
    virtual BOOL InView();
    virtual CString& GetText()=0;
    virtual void SetText(CString &str)=0;
};


///////////////////////////////////// ����������� ������/////////////////
class CMyButton: public CMyObject
{
public:
    CString caption;

    CMyButton();
    void Create(int,int,int,int,char*);
    void Draw(CDC*);
    CString& GetText() {return caption;}
    void SetText(CString &str) {caption=str;}
};


class CMyEditText: public CMyObject
{
public:
    CString text;
    CString drawText;

    CMyEditText();
    void UpdateDrawText(CDC*);
    void Create(int,int,int,int,char*);
    void Draw(CDC*);
    BOOL InView();
    CString& GetText() {return text;}
    void SetText(CString &str) {text=str;}
};

class CMyStaticText: public CMyObject
{
public:
    CString text;

    CMyStaticText();
    void Create(int,int,int,int,char*);
    void Draw(CDC*);
    CString& GetText() {return text;}
    void SetText(CString &str) {text=str;}
};


#endif
