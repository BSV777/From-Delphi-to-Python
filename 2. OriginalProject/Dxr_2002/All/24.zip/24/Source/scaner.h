#ifndef _MYSCANER_
#define _MYSCANER_

#include "stdafx.h"



////////////////////////////// CMyScaner////////////////////////////
class CMyScaner
{
private:
    CString inpBuff;
    int idx;
    int numLine;
    int numError,numWarning;
    char curCh;
    CString curLiter;

private:
    void Init();

    int GetChar();
    void BackChar();
    int GetName();
    int GetStr();
    int GetLiter();

    int LoadParam();
    int FindObjName();
    int SetObj(int);
    int FindParamName();
    void SetParam(int);
    void SetTextParam();
    void SetCaptionParam();
    void SetLeftParam();
    void SetRightParam();
    void SetTopParam();
    void SetBottomParam();

public:
    int curObjType;
    int left,top,right,bottom;
    CString text;
    int paramSetFlags;
    BOOL xSetFlag,ySetFlag;
public:
    CMyScaner();

    int ScanString(CString &inpStr);
    void Error(int code,LPCSTR comment);
    void Warning(int code,LPCSTR comment);
    void EndMessage();
};

////////////////////////////////���������
// ���� ��������
#define ERROR_NAME      0
#define NAME_BUTTON     1
#define NAME_EDITTEXT   2
#define NAME_LABEL      3

// ���� ������
#define NUM_ERROR_TYPE  12      // ���������� ����� ������
#define ERROR_STR_LITER         0
#define ERROR_NOT_BEGIN_LITER   1
#define ERROR_NOT_FOUND_NAME    2
#define ERROR_NOT_FOUND_PARAM   3
#define ERROR_NOT_NAME          4
#define ERROR_NOT_FOUND_EQU     5
#define ERROR_NOT_FOUND_STR     6
#define ERROR_NOT_END_LITER     7
#define ERROR_PARAM_INT_L_ZERRO 8
#define ERROR_XSIZE             9
#define ERROR_YSIZE             10
#define ERROR_OBJ_INTERSECT     11

// ���� ��������������
#define NUM_WARNING_TYPE  8       // ���������� ����� ��������������
#define WARNING_LIT_AFTER_END       0
#define WARNING_UNDEF_SYMBOL        1
#define WARNING_BUTTON_TEXT         2
#define WARNING_NOBUTTON_CAPTION    3
#define WARNING_PARAM_ALREADY_SET   4
#define WARNING_PARAM_INT_E_ZERRO   5
#define WARNING_OBJ_ALREADY         6
#define WARNING_OBJ_INTERSECT       7

#endif
