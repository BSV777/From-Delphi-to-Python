import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;


interface VisualContainer {
          int WRAP_LEFT   = 0;
          int WRAP_RIGHT  = 1;
          int WRAP_TOP    = 2;
          int WRAP_BOTTOM = 3;

          /* return TRUE if this visual component intersect other component
           */
          boolean isIntersect(TaskVisualObject item);
          boolean isIntersect(TaskVisualObject item, Rectangle bounds);
          /* create new item
           */
          void    createItem();
          /* make item bounds instance
           */
          void    instanceItem(TaskVisualObject item);
          /* temporary place item in its like bounds
           */
          void    relocateItem(TaskVisualObject item);
          /* remove item from screen and collection
           */
          void    removeItem(TaskVisualObject item);
          /* Show current cursor location in absolute coordinates
           */
          void    showCursorPos(int x, int y);
          /* Show current item bounds in absolute coordinates
           */
          void    showBounds(Rectangle bounds);
          /* Show current focused item
           */
          void    showFocused(TaskVisualObject item, boolean enable);
          /* Possibly all items at this item
           */
          void    wrapAtItem(TaskVisualObject item, int mode);
          /* Get hidden part from scrollbars
           */
          Point   getOffs();
};

public class TaskVisualObject extends JTextField implements DocumentListener, KeyListener, FocusListener {
       /* Width of trigger zone at X axis, activated dragging/moving operation when mouse
          cursor come in
        */
       final static int TRIGGER_WIDTH    = 4;
       /* Height of trigger zone at Y axis, activated dragging/moving operation when mouse
          cursor come in
        */
       final static int TRIGGER_HEIGHT   = 4;

       /* Bitvector of dragging/moving operation.
          DRAG_DUMMY    - dragging/moving disable
          DRAG_MOVE     - activated moving mode
          DRAG_RESIZEX  - activated width resizing mode
          DRAG_RESIZEY  - activating height resizing mode
        */
       final static int DRAG_DUMMY       = 0;
       final static int DRAG_MOVE        = 1;
       final static int DRAG_RESIZEX     = 2;
       final static int DRAG_RESIZEY     = 4;


       final static String[] PropertiesOptionNames = { "Ok", "Cancel" };
       final static String   PropertiesTitle       = "Properties...";

       /* Container, which owning this element
        */
       VisualContainer container      = null;
       /* Object, linked this visual representation
        */
       TaskAbstractObject item        = null;
       /* Stored previous bounds of this element
        */
       Rectangle       obounds        = null;
       /* Position, where mouse was pressed at
        */
       Point           pressedAt      = null;
       /* Position, where mouse placed now
        */
       Point           lastAt         = null;
       /* Temporary mouse cursor name. It changed when mouse enter trigger zone.
        */
       int             tmpCursor      = Cursor.DEFAULT_CURSOR;
       /* Stored original cursor, changed by drag/resize cursor
        */
       Cursor          ocursor        = null;
       /* Current drugging/resizing mode
        */
       int            dragmode        = DRAG_DUMMY;
       /* Indicator of storing item
        */
       boolean        stored          = false;
       /* Popup menu, selected for this item
        */
       JPopupMenu        popup        = null;

       public TaskVisualObject(VisualContainer container, TaskAbstractObject item) throws Exception {
              super("");
              if (item == null)
                 throw new Exception("Item not defined for visual representation...");
              this.container = container;
              this.item      = item;
              item.setRepresentation(this);
              getDocument().addDocumentListener(this);
              addKeyListener(this);
              addFocusListener(this);
       }
       /* Mouse operation dispatcher
          When mouse button pressed at trigger zone, activating dragging/resizing mode until
          mouse button not released. At this time activating mouse motion dispatcher, which
          change size and position of element.
        */
       protected void processMouseEvent(MouseEvent e) {
                 boolean dispatch = true;
                 switch (e.getID())
                 {case MouseEvent.MOUSE_PRESSED:
                       // System.out.println("Pressed ["+e.getButton()+"] at <"+e.getX()+","+e.getY()+">");
                       if (e.getButton() == MouseEvent.BUTTON1 && popup == null)
                          { if ((dragmode = checkCursorPos(e.getX(),e.getY())) > DRAG_DUMMY)
                               { pressedAt = lastAt = absoluteLocation(e.getX(),e.getY());
                                 obounds   = new Rectangle(item.getBounds());
                                 dispatch  = false;
                               }
                          }
                       else
                       if (e.isPopupTrigger())
                          { processPopupMenu(e.getX(),e.getY());
                            dispatch = false;
                          }

                       break;
                  case MouseEvent.MOUSE_RELEASED:
                       if (dragmode != DRAG_DUMMY)
                          { setBorder(item.getValidBorder());
                            container.instanceItem(this);
                            dispatch = false;
                          }
                       else
                       if (e.isPopupTrigger())
                          { processPopupMenu(e.getX(),e.getY());
                            dispatch = false;
                          }
                       dragmode  = DRAG_DUMMY;
                       pressedAt = lastAt = null;
                       obounds   = null;
                       // System.out.println("Released at <"+e.getX()+","+e.getY()+">");
                       break;
                  case MouseEvent.MOUSE_ENTERED:
                       // System.out.println("Entered...");
                       if (dragmode != DRAG_DUMMY)
                          break;
                       if (checkCursorPos(e.getX(),e.getY()) != DRAG_DUMMY)
                          dispatch = false;
                       break;
                  case MouseEvent.MOUSE_EXITED:
                       // System.out.println("Exited...");
                       if (dragmode == DRAG_DUMMY)
                          unsetTmpCursor();
                       break;

                 }
                 showCursorLocation(e.getX(),e.getY());
                 if (dispatch)
                    super.processMouseEvent(e);
       };
       /* Mouse motion dispatcher.
          It change location/size of element, when dragmode activating. In idle dragmode,
          it inform container about mouse location.
        */
       protected void processMouseMotionEvent(MouseEvent e) {
                 boolean dispatch = true;
                 if (dragmode != DRAG_DUMMY && e.getID() == MouseEvent.MOUSE_DRAGGED && pressedAt != null)
                    { lastAt = absoluteLocation(e.getX(),e.getY());
                      changeBounds();
                      if (container.isIntersect(this))
                         setBorder(item.getInvalidBorder());
                      else
                         setBorder(item.getValidBorder());
                      container.relocateItem(this);
                    }
                 else
                 if (e.getID() == MouseEvent.MOUSE_MOVED)
                    { checkCursorPos(e.getX(),e.getY());
                      // System.out.println("Moved at <"+e.getX()+","+e.getY()+">");
                    }
                 showCursorLocation(e.getX(),e.getY());
                 if (dispatch)
                    super.processMouseMotionEvent(e);
       };
       /* Return absolute location on screen, using container scrolled part.
        */
       public Point absoluteLocation(int dx, int dy) {
              Point loc = new Point(getLocationOnScreen());
              loc.x += dx;
              loc.y += dy;
              if (container != null)
                 { loc.x += container.getOffs().x;
                   loc.y += container.getOffs().y;
                 }
              return loc;
       }
       /* Return absolutely bounds of this element.
        */
       public Rectangle likeBounds() {
              return new Rectangle(item.getBounds());
       }
       /* Return maximum X coordinate of element.
        */
       public int getMaxX() {
              return item.getMaxX();
       }
       /* Return maximum Y coordinate of element.
        */
       public int getMaxY() {
              return item.getMaxY();
       }
       /* Restore previous bounds, which was stored before resizing/moving this element, if it
          intersects other element after operation finished.
        */
       public void restoreBounds() throws Exception {
              if (obounds != null)
                 { item.setBounds(obounds);
                   obounds = null;
                 }
              else
                 throw new Exception("Cannot restore privious bounds...");
       }
       /* return item, linked this visual representation
        */
       public TaskAbstractObject getTaskObject() {
              return item;
       }

       public void makeBounds(Rectangle bounds) {
              obounds = new Rectangle(item.getBounds());
              item.setBounds(bounds);
       }
       public boolean needStoring() {
              item.getRepresentation(this);
              return !stored || !item.getStored();
       }
       public void wasStored() {
              item.setStored();
              stored = true;
       }
       //
       public void insertUpdate(DocumentEvent e) {
              item.getRepresentation(this);
       }
       public void removeUpdate(DocumentEvent e) {
              item.getRepresentation(this);
       }
       public void changedUpdate(DocumentEvent e) {
              item.getRepresentation(this);
       }
       //
       public void  keyTyped(KeyEvent e) {
       }
       public void  keyPressed(KeyEvent e) {
              switch(e.getKeyCode())
              { case KeyEvent.VK_F9:
                     processPopupMenu(0,0);
                     break;
                case KeyEvent.VK_C:
                     if (!e.isControlDown())
                        return;
                     copy();
                     break;
                case KeyEvent.VK_V:
                     if (!e.isControlDown())
                        return;
                     paste();
                     break;
                case KeyEvent.VK_INSERT:
                     if (e.isControlDown())
                        copy();
                     else
                     if (e.isShiftDown())
                        paste();
                     else
                        return;
                     break;
                case KeyEvent.VK_DELETE:
                     if (e.isControlDown() || e.isShiftDown())
                        cut();
                     else
                        return;
                     break;
                case KeyEvent.VK_UP:
                     if (!e.isAltDown())
                        return;
                     if (e.isShiftDown())
                        grow(0,e.isControlDown() ? -10 : -1);
                     else
                        scroll(0,e.isControlDown() ? -10 : -1);
                     break;
                case KeyEvent.VK_DOWN:
                     if (!e.isAltDown())
                        return;
                     if (e.isShiftDown())
                        grow(0,e.isControlDown() ? 10 : 1);
                     else
                        scroll(0,e.isControlDown() ? 10 : 1);
                     break;
                case KeyEvent.VK_LEFT:
                     if (!e.isAltDown())
                        return;
                     if (e.isShiftDown())
                        grow(e.isControlDown() ? -10 : -1,0);
                     else
                        scroll(e.isControlDown() ? -10 : -1,0);
                     break;
                case KeyEvent.VK_RIGHT:
                     if (!e.isAltDown())
                        return;
                     if (e.isShiftDown())
                        grow(e.isControlDown() ? 10 : 1,0);
                     else
                        scroll(e.isControlDown() ? 10 : 1,0);
                     break;
                default:
                     return;
              }
              e.consume();
       }
       public void  keyReleased(KeyEvent e) {
       }
       //
       public void  focusGained(FocusEvent e) {
              container.showFocused(this,true);
       }
       public void  focusLost(FocusEvent e) {
              container.showFocused(this,false);
       }
       public void setProperties() {
              JPanel propertiesPanel = item.getPropertiesPanel();
              
              if (propertiesPanel == null)
                 return;
              item.getRepresentation(this);
              if (JOptionPane.showOptionDialog(null, propertiesPanel, PropertiesTitle,
                                               JOptionPane.DEFAULT_OPTION, 
                                               JOptionPane.INFORMATION_MESSAGE,
                                               null, 
                                               PropertiesOptionNames, PropertiesOptionNames[0]) == 0) 
                 { obounds = new Rectangle(item.getBounds());
                   item.setPropertiesPanel(propertiesPanel);
                   setText(item.getText());
                   container.relocateItem(this);
                   container.instanceItem(this);
                 }
       }
       //
       private void scroll(int dx, int dy) {
               Rectangle bounds = new Rectangle(item.getBounds());
               obounds = new Rectangle(bounds);
               bounds.x = Math.max(bounds.x + dx, 0);
               bounds.y = Math.max(bounds.y + dy, 0);
               if (bounds.equals(obounds) || container.isIntersect(this,bounds))
                  { obounds = null;
                    return;
                  }
               item.setBounds(bounds);
               container.relocateItem(this);
       }
       private void grow(int dx, int dy) {
               Rectangle bounds = new Rectangle(item.getBounds());
               obounds = new Rectangle(bounds);
               bounds.width  = Math.max(item.getMinSize().width,Math.min(item.getMaxSize().width,bounds.width + dx));
               bounds.height = Math.max(item.getMinSize().height,Math.min(item.getMaxSize().height,bounds.height + dy));
               if (bounds.equals(obounds) || container.isIntersect(this,bounds))
                  { obounds = null;
                    return;
                  }
               item.setBounds(bounds);
               container.relocateItem(this);
       }
       private void changeBounds() {
               if (obounds == null || lastAt == null || pressedAt == null || dragmode == DRAG_DUMMY)
                  return;
               if (lastAt.equals(pressedAt))
                  return;
               Rectangle bounds = new Rectangle(obounds);
               int dx = lastAt.x - pressedAt.x;
               int dy = lastAt.y - pressedAt.y;
               if ((dragmode & DRAG_MOVE) == DRAG_MOVE)
                  { bounds.x = Math.max(0,bounds.x + dx);
                    bounds.y = Math.max(0,bounds.y + dy);
                  }
               if ((dragmode & DRAG_RESIZEX) == DRAG_RESIZEX)
                  { if ((bounds.width += dx) < 0)
                       { bounds.x    += bounds.width;
                         bounds.width = -bounds.width;
                         if (bounds.x < 0)
                            { bounds.width = Math.max(0,bounds.width+bounds.x);
                              bounds.x     = 0;
                            }
                       }
                    bounds.width = Math.min(Math.max(bounds.width,item.getMinSize().width),
                                            item.getMaxSize().width);
                  }
               if ((dragmode & DRAG_RESIZEY) == DRAG_RESIZEY)
                  {if ((bounds.height += dy) < 0)
                      { bounds.y     += bounds.height;
                        bounds.height = -bounds.height;
                        if (bounds.y < 0)
                           { bounds.height = Math.max(0,bounds.height+bounds.y);
                             bounds.y     = 0;
                           }
                      }
                    bounds.height = Math.min(Math.max(bounds.height,item.getMinSize().height),
                                             item.getMaxSize().height);
                  }
               item.setBounds(bounds);
       }
       private int checkCursorPos (int x, int y) {
               Rectangle rect = item.getBounds();
               int       mode = DRAG_DUMMY;
               boolean   growx = false, growy = false, move = false;

               if ( x + TRIGGER_WIDTH >= rect.width )
                  { if (item.isGrowableX())
                       growx = true;
                    if ( y + TRIGGER_HEIGHT >= rect.height && item.isGrowableY() )
                       growy = true;
                  }
               else
               if ( y + TRIGGER_HEIGHT >= rect.height)
                  { if (item.isGrowableY())
                       growy = true;
                  }
               else
               if ( y <= TRIGGER_HEIGHT)
                  { move = true;
                  }

               if (growx || growy)
                  { if (growx && growy)
                       { mode = DRAG_RESIZEX | DRAG_RESIZEY;
                         setTmpCursor(Cursor.SE_RESIZE_CURSOR);
                       }
                    else
                    if (growy)
                       { mode = DRAG_RESIZEY;
                         setTmpCursor(Cursor.S_RESIZE_CURSOR);
                       }
                    else
                       { mode = DRAG_RESIZEX;
                         setTmpCursor(Cursor.E_RESIZE_CURSOR);
                       }
                  }
               else
               if (move)
                  { mode = DRAG_MOVE;
                    setTmpCursor(Cursor.MOVE_CURSOR);
                  }
               else
                  unsetTmpCursor();

               return mode;
       }
       private void setTmpCursor(int tmp) {
               if (ocursor == null)
                  ocursor = getCursor();
               if (tmpCursor != tmp)
                  { tmpCursor = tmp;
                    setCursor(Cursor.getPredefinedCursor(tmp));
                  }
       }
       private void unsetTmpCursor() {
               if (ocursor != null)
                  setCursor(ocursor);
               ocursor   = null;
               tmpCursor = Cursor.DEFAULT_CURSOR;
       }
       private void processPopupMenu(int x, int y) {
               popup = new JPopupMenu();
               JMenuItem mi = new JMenuItem("Delete");
               mi.addActionListener(new ActionListener() {
                     public void actionPerformed(ActionEvent e) {
                            container.removeItem(TaskVisualObject.this);
                     }
                  });
               popup.add(mi);
               mi = new JMenuItem("Properties...");
               mi.addActionListener(new ActionListener() {
                     public void actionPerformed(ActionEvent e) {
                            setProperties();
                     }
                  });
               popup.add(mi);
               popup.addSeparator();

               mi = new JMenuItem("Cut");
               mi.addActionListener(new ActionListener() {
                     public void actionPerformed(ActionEvent e) {
                            cut();
                     }
                  });
               popup.add(mi);
               mi = new JMenuItem("Copy");
               mi.addActionListener(new ActionListener() {
                     public void actionPerformed(ActionEvent e) {
                            copy();
                     }
                  });
               popup.add(mi);
               mi = new JMenuItem("Paste");
               mi.addActionListener(new ActionListener() {
                     public void actionPerformed(ActionEvent e) {
                            paste();
                     }
                  });
               popup.add(mi);
               popup.addSeparator();

               mi = new JMenuItem("Justify left...");
               mi.addActionListener(new ActionListener() {
                     public void actionPerformed(ActionEvent e) {
                            container.wrapAtItem(TaskVisualObject.this,VisualContainer.WRAP_LEFT);
                     }
                  });
               popup.add(mi);
               mi = new JMenuItem("Justify top...");
               mi.addActionListener(new ActionListener() {
                     public void actionPerformed(ActionEvent e) {
                            container.wrapAtItem(TaskVisualObject.this,VisualContainer.WRAP_TOP);
                     }
                  });
               popup.add(mi);
               mi = new JMenuItem("Justify right...");
               mi.addActionListener(new ActionListener() {
                     public void actionPerformed(ActionEvent e) {
                            container.wrapAtItem(TaskVisualObject.this,VisualContainer.WRAP_RIGHT);
                     }
                  });
               popup.add(mi);
               mi = new JMenuItem("Justify bottom...");
               mi.addActionListener(new ActionListener() {
                     public void actionPerformed(ActionEvent e) {
                            container.wrapAtItem(TaskVisualObject.this,VisualContainer.WRAP_BOTTOM);
                     }
                  });
               popup.add(mi);

               popup.addPopupMenuListener(new PopupMenuListener(){
                        public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
                        }
                        public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
                               popup = null;
                        }
                        public void popupMenuCanceled(PopupMenuEvent e) {
                               popup = null;
                        }
                     });
               popup.show(this, x, y);
       }
       private void showCursorLocation(int x, int y) {
               if (dragmode == DRAG_DUMMY)
                  { container.showCursorPos(item.getBounds().x + x, item.getBounds().y + y);
                  }
               else
                  { container.showBounds(item.getBounds());
                  }
       }
};