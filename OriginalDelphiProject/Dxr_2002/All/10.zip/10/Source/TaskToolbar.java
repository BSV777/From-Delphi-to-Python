import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.net.*;

public class TaskToolbar extends JPanel {

       static String dataTools[][] = {
              {"images/new.gif",TaskPanel.CM_NEW,"Create new panel"},
              {"images/open.gif",TaskPanel.CM_OPEN,"Open source file"},
              {"images/save_t.gif",TaskPanel.CM_SAVE_TABLE,"Save <table> </table>"},
              {"images/save_c.gif",TaskPanel.CM_SAVE_CSS,"Save \"position: absolute;\""},
              {"images/save_s.gif",TaskPanel.CM_SAVE_TMP,"Save source"},
              {"images/cut.gif",TaskPanel.CM_CUT,"Cut"},
              {"images/copy.gif",TaskPanel.CM_COPY,"Copy"},
              {"images/paste.gif",TaskPanel.CM_PASTE,"Paste"},
              {"images/insert.gif",TaskPanel.CM_INSERT,"Insert object"},
              {"images/delete.gif",TaskPanel.CM_DELETE,"Delete object"},
              {"images/properties.gif",TaskPanel.CM_PROPERTIES,"Change properties"},
              {"images/lwrap.gif",TaskPanel.CM_LEFT_WRAP,"Justify by left border"},
              {"images/twrap.gif",TaskPanel.CM_TOP_WRAP,"Justify by top border"},
              {"images/rwrap.gif",TaskPanel.CM_RIGHT_WRAP,"Justify by right border"},
              {"images/bwrap.gif",TaskPanel.CM_BOTTOM_WRAP,"Justify by bottom border"}
       };

       public TaskToolbar(ActionListener listener) {
              super();
              setLayout(new BoxLayout(this,BoxLayout.X_AXIS));
              makeButtons(listener);
              setBorder(new BevelBorder(BevelBorder.RAISED,Color.gray,Color.gray));
       }

       private void makeButtons(ActionListener listener) {
               if (dataTools.length == 0)
                  return;
               URLClassLoader urlLoader = (URLClassLoader)getClass().getClassLoader();
               
               for (int i = 0; i < dataTools.length; i++)
                   { 
                     URL fileLoc = urlLoader.findResource(dataTools[i][0]);
	                 Image image   = getToolkit().createImage(fileLoc);
                     MediaTracker tracker = new MediaTracker(this);
                     tracker.addImage(image, 0);
                     try { tracker.waitForID(0);
                           if (tracker.isErrorAny()) 
                              { System.out.println("Error loading image "+dataTools[i][0]+"...");
                                continue;
                              }
                         } 
                     catch (Exception ex) 
                         { ex.printStackTrace(); 
                         }
                     ImageIcon icon = new ImageIcon(image); // (dataTools[i][0]);
                   
                     JButton mb = new JButton("",icon);
                     mb.setActionCommand(dataTools[i][1]);
                     mb.addActionListener(listener);
                     mb.setMargin(new Insets(0,0,0,0));
                     mb.setToolTipText(dataTools[i][2]);
                     add(mb);
                   }
       }
};