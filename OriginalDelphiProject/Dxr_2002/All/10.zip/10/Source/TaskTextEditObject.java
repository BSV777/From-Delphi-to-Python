import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;

public class TaskTextEditObject extends TaskLabelObject {
       public static final String NAME = "TextEdit";
       public static final String FIELDWIDTH = "size";
       /* Initial element width, when created */
       final static int DEFAULT_WIDTH    = 80;
       /* Initial element height, when created */
       final static int DEFAULT_HEIGHT   = 24;
       /* Initial element input size, when created */
       final static int DEFAULT_SIZE     = 20;
       /* Minimal and maximal values for width and height */
       final static int MIN_WIDTH        = 24;
       final static int MIN_HEIGHT       = 24;
       final static int MAX_WIDTH        = 1024;
       final static int MAX_HEIGHT       = 24;
       final static int MIN_SIZE         = 1;
       final static int MAX_SIZE         = 255;

       protected final static int PARAM_LAST = TaskLabelObject.PARAM_LAST + 1;
       protected final static int PARAM_SIZE = PARAM_LAST;

       final static Color FORE_COLOR           = new Color(Color.black.getRGB());
       final static Color BACK_COLOR           = new Color(Color.white.getRGB());
       final static Color BORDER_VALID_COLOR   = new Color(Color.green.getRGB());
       final static Color BORDER_INVALID_COLOR = new Color(Color.red.getRGB());


       int   size  = DEFAULT_SIZE;
       int   ssize = -1;

       public TaskTextEditObject(Rectangle bounds, String text) throws Exception {
              super(bounds,text);
              if (this.bounds.width < MIN_WIDTH || this.bounds.height < MIN_HEIGHT)
                 throw new Exception("Text edit size too low...");
              this.bounds.width  = Math.min(this.bounds.width,MAX_WIDTH);
              this.bounds.height = Math.min(this.bounds.height,MAX_HEIGHT);
       }
       public TaskTextEditObject() {
              super();
              bounds = new Rectangle(-1,-1,DEFAULT_WIDTH,DEFAULT_HEIGHT);
       }
       public static Dimension getDefSize() {
              return new Dimension(DEFAULT_WIDTH,DEFAULT_HEIGHT);
       }
       public void setParamName(String pname) {
              if (pname.equalsIgnoreCase(FIELDWIDTH))
                 sparam = PARAM_SIZE;
              else
                 super.setParamName(pname);
       }
       public void setParamValue(String pvalue) {
              switch(sparam)
              {case PARAM_SIZE:
                    try { int i = Integer.decode(pvalue.trim()).intValue();
                          size  = Math.max(MIN_SIZE,Math.min(i,MAX_SIZE));
                        }
                    catch (NumberFormatException e)
                        {
                        }
                    break;
               default:
                    super.setParamValue(pvalue);
                    break;
              }
              sparam = PARAM_NONE;
       }
       //
       public boolean getStored() {
              if (ssize != size)
                 return false;
              return super.getStored();
       }
       public void setStored() {
              ssize = size;
              super.setStored();
       }
       public void putAsTable(PrintWriter os) {
              os.println("   "+strMarker()+">");
       }
       public void putAsCSS(PrintWriter os) {
              os.println(" "+strMarker()+strCSS()+">");
       }
       public boolean isGrowableX() {
              return true;
       }
       public boolean isGrowableY() {
              return false;
       }
       public Dimension getMinSize() {
              return new Dimension(MIN_WIDTH,MIN_HEIGHT);
       }
       public Dimension getMaxSize() {
              return new Dimension(MAX_WIDTH,MAX_HEIGHT);
       }
       public Border getValidBorder() {
              return new BevelBorder(BevelBorder.LOWERED,Color.gray,Color.gray);
                         //  LineBorder(BORDER_VALID_COLOR,2);
       }
       public Border getInvalidBorder() {
              return new LineBorder(BORDER_INVALID_COLOR,2);
       }
       public void setText(String text) {
              this.text   = new String(text == null ? "" : text);
       }
       public void setRepresentation(JTextField view) {
              view.setForeground(FORE_COLOR);
              view.setBackground(BACK_COLOR);
              view.setBorder(getValidBorder());
              view.setText(text);
       }
       public void getRepresentation(JTextField view) {
              setText(view.getText());
       }
       public boolean isEmpty() {
              return false;
       }
       public String getTemporary() {
              return HEAD+NAME+
                          strParam(LEFT,bounds.x)+MORE+strParam(TOP,bounds.y)+MORE+
                          strParam(WIDTH,bounds.width)+MORE+strParam(HEIGHT,bounds.height)+MORE+
                          strParam(FIELDWIDTH,size)+
                          (text == null || text.length() == 0 ? "" : MORE+strParam(TEXT,text))+
                     TAIL;
       }
       public String  getName() {
              return NAME;
       };
       public String  fullInfo() {
              return NAME + " at " + strBounds() + strParam(FIELDWIDTH,size)+strParam(TEXT,text);
       };
       public JPanel getPropertiesPanel() {
              return new TextEditObjectProperties();
       }
      //
       private String strMarker() {
               return "<input name = \"text"+id+"\""+
                            " type = \"text\""+
                            " size = \""+size+"\""+
                            ( text == null || text.length() == 0 ? "" : " value = \""+text+"\"" );
       }
       public class TextEditObjectProperties extends TaskAbstractObject.ObjectProperties {
             JLabel      dataSizeLabel;
             JTextField  dataSizeField;

             public TextEditObjectProperties() {
                    super();
                    dataSizeLabel = new JLabel("Size", JLabel.LEFT);
                    dataSizeField = new JTextField(Integer.toString(size));
                    labelPanel.add(dataSizeLabel);
                    fieldPanel.add(dataSizeField);
             }

             public void copyData() {
                    try { int s = Integer.decode(dataSizeField.getText().trim()).intValue();
                          size  = Math.max(MIN_SIZE,Math.min(MAX_SIZE,s));
                        }
                    catch (NumberFormatException e)
                        {
                        }
                    super.copyData();
             }
    }
}