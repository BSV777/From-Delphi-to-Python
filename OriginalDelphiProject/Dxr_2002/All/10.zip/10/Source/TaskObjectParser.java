import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class TaskObjectParser {
       final static char VALUE_START_CHAR  = '"';
       final static char VALUE_STOP_CHAR   = '"';
       final static char DIRECT_PUT_CHAR   = '\\';
       final static char OBJECT_START_CHAR = TaskAbstractObject.HEAD;
       final static char OBJECT_STOP_CHAR  = TaskAbstractObject.TAIL;
       final static int  STACK_SIZE        = 20;

       final static int  DUMMY             = 0;
       final static int  WAIT_OBJECT_NAME  = 1;
       final static int  WAIT_PARAM_NAME   = 2;
       final static int  WAIT_PARAM_VALUE  = 3;

       private Reader reader             = null;
       private int    cpushed            = 0;
       private int    pushed[]           = new int[STACK_SIZE];
       private boolean is_comment        = false;
       private boolean is_done           = false;
       private boolean is_newline        = true;
       private int     mode              = DUMMY;
       private int     line              = 1;
       private TaskAbstractObject object = null;

       public  TaskObjectParser(Reader is) throws IOException {
               if (is == null)
                  throw new IOException("Absent reader...");
               reader = is;
       }

       private boolean isLF(int c) {
               return c == '\n';
       }
       private boolean isWhitespace(int c) {
               return isLF(c) || c == ' ' || c == 0x08;
       }
       private boolean isNextChar(int c) {
               return c == ';' || c == ',';
       }
       private boolean isNameChar(int c) {
               return ('A' <= c && c <= 'Z') || ('a' <= c && c <= 'z');
       }
       private boolean isParamChar(int c) {
               return isNameChar(c);
       }
       private boolean isEqualChar(int c) {
               return c == '=' || c == ':';
       }
       private boolean isComment(int c) {
               return c == ';' || c == '#';
       }
       private int readc(boolean summary) throws IOException {
               int c = -1;
               if (cpushed > 0)
                  c = pushed[--cpushed];
               else
               if (reader != null)
                  c = reader.read();
               else
                  throw new IllegalStateException();
               if (isLF(c) && summary)
                  { line++;
                    is_newline = true;
                  }
               return c;
       }
       private int read() throws IOException {
               boolean skipEol = false;
               while (true)
                     { int c = readc(true);
                       if (c < 0)
                          return c;
                       if (is_comment)
                          { if (c == '*')
                               { int cn = readc(false);
                                 if (cn == '/')
                                    { is_comment = false;
                                      continue;
                                    }
                                 push(cn);
                               }
                            continue;
                          }
                       if ( isComment(c) && is_newline )
                          { skipEol = true;
                            continue;
                          }
                       if (isLF(c))
                          { skipEol = false;
                            continue;
                          }
                       if (skipEol)
                          continue;
                       if ( c == '/')
                          { int cn = readc(false);
                            if (cn == '*')
                               { is_comment = true;
                                 continue;
                               }
                            else
                            if (cn == '/')
                               { skipEol = true;
                                 continue;
                               }
                            push(cn);
                          }
                       if (!isWhitespace(c))
                          is_newline = false;
                       return c;
                     }
       }
       private void push(int c) throws IOException {
               if (cpushed >= STACK_SIZE)
                  throw new IOException("Stack overflow...");
               pushed[cpushed++] = c;
       }
       private void startObjectMode() {
               object           = null;
               mode             = WAIT_OBJECT_NAME;
       }
       private void maybeError(boolean destroyed) {
               if (mode != DUMMY)
                  { if (object == null)
                       System.out.println("Line "+line+" warning: unknown object type, skipped...");
                    else
                    if (destroyed)
                       System.out.println("Line "+line+" warning: object "+object.getName()+" out of data, skipped...");
                  }
       }
       private TaskAbstractObject stopObjectMode() {
               maybeError(false);
               TaskAbstractObject rc = object;
               object                = null;
               mode                  = DUMMY;
               return rc;
       }
       private TaskAbstractObject allDone() {
               maybeError(true);
               is_done = true;
               mode    = DUMMY;
               object  = null;
               return null;
       }
       private void setObjectName(String oname) {
               if (oname.equalsIgnoreCase(TaskLabelObject.NAME))
                  { object = new TaskLabelObject();
                  }
               else
               if (oname.equalsIgnoreCase(TaskButtonObject.NAME))
                  { object = new TaskButtonObject();
                  }
               else
               if (oname.equalsIgnoreCase(TaskTextEditObject.NAME))
                  { object = new TaskTextEditObject();
                  }
               else
                  object = null;
               if (object != null)
                  mode = WAIT_PARAM_NAME;
               else
                  stopObjectMode();
       }
       private void setParamName(String pname) {
               if (object == null)
                  { stopObjectMode();
                    return;
                  }
               object.setParamName(pname);
               mode = WAIT_PARAM_VALUE;
       }
       private void setParamValue(String pvalue) {
               if (object == null)
                  { stopObjectMode();
                    return;
                  }
               object.setParamValue(pvalue);
               mode = WAIT_PARAM_NAME;
       }

       public int getLine() {
              return line;
       }
       public boolean hasMore() {
              return reader != null && !is_done;
       }
       public TaskAbstractObject nextObject() throws IOException {
              MAIN:
              while (true)
                    { if (is_done)
                         return null;
                      int c = 0;
                      c = read();
                      if (c < 0)
                         return allDone();
                      if (c == OBJECT_START_CHAR)
                         { if (mode == DUMMY)
                              { startObjectMode();
                                continue;
                              }
                         }
                      else
                      if (c == OBJECT_STOP_CHAR)
                         { if (mode != DUMMY)
                              return stopObjectMode();
                         }
                      if (mode == DUMMY)
                         continue;
                      if (isWhitespace(c))
                         continue;
                      if (mode == WAIT_OBJECT_NAME)
                         { String oname = "";
                           while (true)
                                 { if (isWhitespace(c))
                                      break;
                                   if (!isNameChar(c))
                                      { mode = DUMMY;
                                        continue MAIN;
                                      }
                                   oname += (char)c;
                                   c = read();
                                   if (c < 0)
                                      return allDone();
                                   if (c == OBJECT_STOP_CHAR)
                                      { push(c);
                                        break;
                                      }
                                 }
                            setObjectName(oname);
                         }
                      else
                      if (mode == WAIT_PARAM_NAME)
                         { String pname = "";
                           while (true)
                                 { if (isWhitespace(c))
                                      break;
                                   if (isEqualChar(c))
                                      break;
                                   if (isNextChar(c))
                                      continue MAIN;
                                   if (!isNameChar(c))
                                      continue MAIN;
                                   pname += (char)c;
                                   c = read();
                                   if (c < 0)
                                      return allDone();
                                   if (c == OBJECT_STOP_CHAR)
                                      { push(c);
                                        break;
                                      }
                                 }
                           setParamName(pname);
                         }
                      else
                      if (mode == WAIT_PARAM_VALUE)
                         { if (isNextChar(c))
                              { mode = WAIT_PARAM_NAME;
                                continue;
                              }
                           if (c != VALUE_START_CHAR)
                              continue;
                           String pvalue = "";
                           while (true)
                                 { c = readc(true);
                                   if (c < 0)
                                      return allDone();
                                   if (c == DIRECT_PUT_CHAR)
                                      { c = readc(true);
                                        if (isLF(c))
                                           continue;
                                        if (c < 0)
                                           return allDone();
                                      }
                                   else
                                   if (c == VALUE_STOP_CHAR)
                                       break;
                                   pvalue += (char)c;
                                 }
                           setParamValue(pvalue);
                         }
                    }
       }
}