import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;


public abstract class TaskAbstractObject  {
       public final static char   HEAD   = '<';
       public final static char   TAIL   = '>';
       public final static String TOP    = "top";
       public final static String LEFT   = "left";
       public final static String WIDTH  = "width";
       public final static String HEIGHT = "height";
       public final static String MORE   = ";";

       protected final static int PARAM_NONE   = 0;
       protected final static int PARAM_TOP    = 1;
       protected final static int PARAM_LEFT   = 2;
       protected final static int PARAM_WIDTH  = 3;
       protected final static int PARAM_HEIGHT = 4;
       protected final static int PARAM_LAST   = PARAM_HEIGHT;

       protected Rectangle bounds  = null;
       protected String    text    = null;
       protected Rectangle sbounds = null;
       protected String    stext   = null;
       protected int           id  = -1;
       protected int       sparam  = PARAM_NONE;

       private static int   idNumber = -1;

       protected TaskAbstractObject(Rectangle bounds, String text) {
              this.bounds = new Rectangle(bounds);
              id = ++idNumber;
              setText(text);
       }
       protected TaskAbstractObject() {
              id = ++idNumber;
       }

       public Rectangle getBounds() {
              return bounds;
       }
       public void setBounds(Rectangle bounds) {
              this.bounds = new Rectangle(bounds);
       }
       public String getText() {
              return text == null ? "" : text;
       }
       public int getMaxX() {
              return bounds.x + bounds.width;
       }
       public int getMaxY() {
              return bounds.y + bounds.height;
       }
       public void setStored() {
              sbounds = new Rectangle(bounds);
              stext   = new String(getText());
       }
       public boolean getStored() {
              if (sbounds == null || !sbounds.equals(bounds))
                 return false;
              if (stext == null || !stext.equals(text))
                 return false;
              return true;
       }
       public void setParamName(String pname) {
              if (pname.equalsIgnoreCase(TOP))
                 sparam = PARAM_TOP;
              else
              if (pname.equalsIgnoreCase(LEFT))
                 sparam = PARAM_LEFT;
              else
              if (pname.equalsIgnoreCase(WIDTH))
                 sparam = PARAM_WIDTH;
              else
              if (pname.equalsIgnoreCase(HEIGHT))
                 sparam = PARAM_HEIGHT;
              else
                 sparam = PARAM_NONE;
       }
       public void setParamValue(String pvalue) {
              switch(sparam)
              {case PARAM_TOP:
                    try { int i = Integer.decode(pvalue.trim()).intValue();
                          bounds.y = Math.max(0,i);
                        }
                    catch (NumberFormatException e)
                        {
                        }
                    break;
               case PARAM_LEFT:
                    try { int i = Integer.decode(pvalue.trim()).intValue();
                          bounds.x = Math.max(0,i);
                        }
                    catch (NumberFormatException e)
                        {
                        }
                    break;
               case PARAM_WIDTH:
                    try { int i = Integer.decode(pvalue.trim()).intValue();
                          bounds.width = Math.max(getMinSize().width,Math.min(i,getMaxSize().width));
                        }
                    catch (NumberFormatException e)
                        {
                        }
                    break;
               case PARAM_HEIGHT:
                    try { int i = Integer.decode(pvalue.trim()).intValue();
                          bounds.height = Math.max(getMinSize().height,Math.min(i,getMaxSize().height));
                        }
                    catch (NumberFormatException e)
                        {
                        }
                    break;
              }
              sparam = PARAM_NONE;
       }
       public Point getOrigin() {
              return new Point(bounds.x,bounds.y);
       }
       public void setOrigin(int ox, int oy) {
              if (ox >= 0) bounds.x = ox;
              if (oy >= 0) bounds.y = oy;
       }
       public Point getLast() {
              return new Point(bounds.x + bounds.width - 1, bounds.y + bounds.height - 1);
       }
       public JPanel getPropertiesPanel() {
              return new ObjectProperties();
       }
       public void setPropertiesPanel(JPanel panel) {
              if (panel instanceof ObjectProperties)
                 ((ObjectProperties)panel).copyData();
       }
       //
       protected String strParam(String name, int value) {
                 return " "+name+" = \""+value+'"';
       }
       protected String strParam(String name, String value) {
                 String ivalue = "";
                 if (value != null) 
                    { for (int i = 0; i < value.length(); i++)
                          { char c = value.charAt(i);
                            if (c == TaskObjectParser.VALUE_STOP_CHAR || c == TaskObjectParser.DIRECT_PUT_CHAR)
                               ivalue += TaskObjectParser.DIRECT_PUT_CHAR;
                            ivalue += c;
                          }
                    }
                 return " "+name+" = \""+ivalue+'"';
       }
       protected String strCSS() {
                 return " style = \"position: absolute"+
                                   "; top: "+bounds.y+
                                   "; left: "+bounds.x+
                                   "; width: "+bounds.width+
                                   "; height: "+bounds.height+
                                   "\"";
       }
       protected String strBounds() {
                 return "["+"("+bounds.x+","+bounds.y+"):("+getLast().x+","+getLast().y+")]";
       }

       public abstract void putAsTable(PrintWriter os);
       public abstract void putAsCSS(PrintWriter os);
       public abstract void setText(String text);
       public abstract Border    getValidBorder();
       public abstract Border    getInvalidBorder();
       public abstract boolean   isGrowableX();
       public abstract boolean   isGrowableY();
       public abstract Dimension getMinSize();
       public abstract Dimension getMaxSize();
       public abstract void      setRepresentation(JTextField view);
       public abstract void      getRepresentation(JTextField view);
       public abstract boolean   isEmpty();
       public abstract String    getTemporary();
       public abstract String    fullInfo();
       public abstract String    getName();
       public abstract String    getTextAbbr();



       //
       public class ObjectProperties extends JPanel {
             protected JLabel      dataTypeLabel;
             protected JLabel      dataTypeField;
             protected JLabel      dataTextLabel;
             protected JTextField  dataTextField;
             protected JLabel      dataXLabel;
             protected JTextField  dataXField;
             protected JLabel      dataYLabel;
             protected JTextField  dataYField;
             protected JLabel      dataWLabel;
             protected JTextField  dataWField;
             protected JLabel      dataHLabel;
             protected JTextField  dataHField;
             protected JPanel      labelPanel;
             protected JPanel      fieldPanel;

             public ObjectProperties() {
                    super();
                    dataTypeLabel = new JLabel("Type", JLabel.LEFT);
                    dataTypeField = new JLabel(TaskAbstractObject.this.getName(), JLabel.LEFT);
                    dataTextLabel = new JLabel(getTextAbbr(), JLabel.LEFT);
                    dataTextField = new JTextField(getText());
                    dataXLabel    = new JLabel("X", JLabel.LEFT);
                    dataXField    = new JTextField(Integer.toString(bounds.x));
                    dataYLabel    = new JLabel("Y", JLabel.LEFT);
                    dataYField    = new JTextField(Integer.toString(bounds.y));
                    dataWLabel    = new JLabel("Width", JLabel.LEFT);
                    dataWField    = new JTextField(Integer.toString(bounds.width));
                    dataHLabel    = new JLabel("Height", JLabel.LEFT);
                    dataHField    = new JTextField(Integer.toString(bounds.height));
	                setLayout(new BoxLayout(this,BoxLayout.X_AXIS));
                    labelPanel    = new JPanel(false);
                    labelPanel.setLayout(new GridLayout(0, 1));
                    labelPanel.add(dataTypeLabel);
                   	labelPanel.add(dataTextLabel);
                    labelPanel.add(dataXLabel);
                    labelPanel.add(dataYLabel);
                    labelPanel.add(dataWLabel);
                    labelPanel.add(dataHLabel);

                    fieldPanel = new JPanel(false);
                    fieldPanel.setLayout(new GridLayout(0, 1));
                    fieldPanel.add(dataTypeField);
                    fieldPanel.add(dataTextField);
                    fieldPanel.add(dataXField);
                    fieldPanel.add(dataYField);
                    fieldPanel.add(dataWField);
                    fieldPanel.add(dataHField);

	                add(labelPanel);
                    add(fieldPanel);
             }
             public void copyData() {
                    setText(dataTextField.getText());
                    int x = -1, y = -1, w = -1, h = -1;
                    try { x = Integer.decode(dataXField.getText().trim()).intValue();
                          if (x < 0)
                             x = 0;
                        }
                    catch (NumberFormatException e)
                        {
                        }
                    try { y = Integer.decode(dataYField.getText().trim()).intValue();
                          if (y < 0)
                             y = 0;
                        }
                    catch (NumberFormatException e)
                        {
                        }
                    try { w = Integer.decode(dataWField.getText().trim()).intValue();
                          w = Math.max(getMinSize().width,Math.min(getMaxSize().width,w));
                        }
                    catch (NumberFormatException e)
                        {}
                    try { h = Integer.decode(dataHField.getText().trim()).intValue();
                          h = Math.max(getMinSize().height,Math.min(getMaxSize().height,h));
                        }
                    catch (NumberFormatException e)
                        {}
                    if (x == -1 || y == -1)
                       { x = bounds.x;
                         y = bounds.y;
                       }
                    if (w == -1 || h == -1)
                       { w = bounds.width;
                         h = bounds.height;
                       }
                    if ( x != bounds.x || y != bounds.y || w != bounds.width || h != bounds.height )
                       TaskAbstractObject.this.setBounds(new Rectangle(x,y,w,h));
             }
    }
};