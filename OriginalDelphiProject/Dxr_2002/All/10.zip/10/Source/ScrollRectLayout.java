import  java.io.ObjectInputStream;
import  java.io.IOException;
import  java.awt.*;
import  java.awt.event.*;
import  java.util.Hashtable;
import  javax.swing.*;


public class ScrollRectLayout extends RectLayout {
       private final static int SCROLLBAR_WIDTH = 20;

       protected JScrollBar   vsb = null;
       protected JScrollBar   hsb = null;
       protected Container parent = null;

       protected Dimension want = new Dimension(0,0);
       protected Point     offs = new Point(0,0);

       ScrollRectLayout()
             { super();
             }
       ScrollRectLayout(Container owner)
             { super();
               parent = owner;
             }
       ScrollRectLayout(int w, int h, Container owner)
             { super(w,h);
               parent = owner;
             }

       public void removeLayoutComponent(Component comp)
              { super.removeComponent(comp);
                if (comp == vsb)
                   vsb.setVisible(false);
                if (comp == hsb)
                   hsb.setVisible(false);
              }

       class VsbListener implements AdjustmentListener {
             public void adjustmentValueChanged(AdjustmentEvent e)
                    {if (parent != null)
                        { setOffs(new Point(offs.x,e.getValue()));
                        }
                    }
       };
       class HsbListener implements AdjustmentListener {
             public void adjustmentValueChanged(AdjustmentEvent e)
                    {if (parent != null)
                        { setOffs(new Point(e.getValue(),offs.y));
                        }
                    }
       };
       public Point getOffs()
              { return new Point(offs.x,offs.y);
              }
       public void setOffs(Point soffs)
              { boolean redraw = false;
                if (soffs == null)
                   return;
                int ox = Math.max(0,soffs.x);
                int oy = Math.max(0,soffs.y);
                if (ox != offs.x)
                   { offs.x  = ox;
                     redraw  = true;
                   }
                if (oy != offs.y)
                   { offs.y = oy;
                     redraw = true;
                   }
                if (redraw && parent != null)
                   layoutContainer(parent);
              }
       public void layoutContainer(Container target)
          { synchronized (target.getTreeLock())
                { // System.out.println("ScrollRectLayout::layoutContainer() message: start");
                  if (target instanceof RootPaneContainer)
                     target = ((RootPaneContainer)target).getContentPane();
                  int nmembers       = target.getComponentCount();
                  // default maximum panel size
                  Dimension dim      = target.getPreferredSize();
                  // insets - internal bounds for panel
                  Insets insets      = target.getInsets();


                  want = new Dimension(Math.max(0,dim.width), Math.max(0,dim.height));
                  // Pass #1 - detect maximum width
                  for (int i = 0 ; i < nmembers ; i++)
                      { Component       m    = target.getComponent(i);
                        ObjectRectangle rect = (ObjectRectangle)rectangles.get(m);
                        if (!m.isVisible() || rect == null)
                           continue;
                        int x = rect.actual.x+insets.left,
                            y = rect.actual.y+insets.top,
                            w = rect.actual.width,
                            h = rect.actual.height;
                        want.width  = Math.max(want.width,x+w-1);
                        want.height = Math.max(want.height,y+h-1);
                      }

                  // Pass #2 - optimize bounds
                  Rectangle bounds   = target.getBounds();
                  Dimension visible  = new Dimension(bounds.width - (insets.left+insets.right),
                                                     bounds.height - (insets.top+insets.bottom));
                  boolean     insvsb = false,
                              inshsb = false;

                  if (want.width > visible.width || offs.x != 0)
                     {visible.height -= SCROLLBAR_WIDTH;
                      inshsb          = true;
                     }
                  if (want.height > visible.height || offs.y != 0)
                     {visible.width  -= SCROLLBAR_WIDTH;
                      insvsb          = true;
                     }
                  if (want.width > visible.width || offs.x != 0)
                     {if (!inshsb)
                         visible.height -= SCROLLBAR_WIDTH;
                      inshsb          = true;
                     }
                  if (want.height > visible.height || offs.y != 0)
                     {if (!insvsb)
                         visible.width  -= SCROLLBAR_WIDTH;
                      insvsb          = true;
                     }

                  if (!inshsb)
                     {offs.x = 0;
                      if (hsb != null)
                         hsb.setVisible(false);
                     }
                  else
                     {if (offs.x == 0)
                         {if (hsb == null)
                             {Container panel = target;
                              if (panel instanceof RootPaneContainer)
                                 {panel = ((RootPaneContainer)panel).getContentPane();
                                 }
                              hsb = new JScrollBar(JScrollBar.HORIZONTAL,0,0,0,0);
                              hsb.addAdjustmentListener(new HsbListener());
                              panel.add(hsb,new ObjectRectangle(0,0,0,0));
                             }
                         }
                      hsb.setVisible(true);
                      hsb.setValue(offs.x);
                      hsb.setUnitIncrement(1);
                      hsb.setBlockIncrement((want.width - visible.width + 9) / 10);
                      hsb.setMinimum(0);
                      hsb.setVisibleAmount(visible.width);
                      hsb.setMaximum(want.width);
                      // System.out.println("=== Set horisontal ("+visible.width+":"+want.width+")===");
                     }

                  if (!insvsb)
                     {offs.y = 0;
                      if (vsb != null)
                         vsb.setVisible(false);
                     }
                  else
                     {if (offs.y == 0)
                         {if (vsb == null)
                             {Container panel = target;
                              if (panel instanceof RootPaneContainer)
                                 {panel = ((RootPaneContainer)panel).getContentPane();
                                 }
                              vsb = new JScrollBar(JScrollBar.VERTICAL,0,0,0,0);
                              vsb.addAdjustmentListener(new VsbListener());
                              panel.add(vsb,new ObjectRectangle(0,0,0,0));
                             }
                          }
                      vsb.setVisible(true);
                      vsb.setValue(offs.y);
                      vsb.setUnitIncrement(1);
                      vsb.setBlockIncrement((want.height - visible.height + 9) / 10);
                      vsb.setMinimum(0);
                      vsb.setVisibleAmount(visible.height);
                      vsb.setMaximum(want.height);
                      // System.out.println("=== Set vertical ("+visible.height+":"+want.height+") ===");
                     }
                  nmembers  = target.getComponentCount();
                  for (int i = 0 ; i < nmembers ; i++)
                      { Component       m    = target.getComponent(i);
                        ObjectRectangle rect = (ObjectRectangle)rectangles.get(m);
                        if (!m.isVisible())
                           {continue;
                           }
                        if (rect == null)
                           {continue;
                           }
                        if (m == vsb)
                           {m.setBounds(bounds.width-SCROLLBAR_WIDTH,
                                        //insets.left+insets.right+visible.width,
                                        insets.top,
                                        SCROLLBAR_WIDTH,
                                        visible.height);
                            // System.out.println("*** Show vertical "+vsb.getBounds());
                            continue;
                           }
                        if (m == hsb)
                           {m.setBounds(insets.left,
                                        bounds.height-SCROLLBAR_WIDTH,
                                        //insets.top+insets.bottom+visible.height,
                                        visible.width,
                                        SCROLLBAR_WIDTH);
                            // System.out.println("*** Show horizontal "+hsb.getBounds());
                            continue;
                           }
                        if (insets.left + rect.actual.x - offs.x >= visible.width  ||
                            insets.top  + rect.actual.y - offs.y >= visible.height
                           )
                           {rect.current.setBounds(0,0,0,0);
                           }
                        else
                           {int x = insets.left + rect.actual.x - offs.x,
                                y = insets.top+rect.actual.y - offs.y,
                                w = rect.actual.width,
                                h = rect.actual.height;
                            if (x + w >= visible.width)
                               w = (visible.width - x);
                            if (y + h >= visible.height)
                               h = (visible.height - y);
                            rect.current.setBounds(x,y,w,h);
                            if (rect.current.isEmpty())
                               rect.current.setBounds(0,0,0,0);
                           }
                        /*System.out.println("Set : " + rect.current + " from " + want +
                                             "\n" +
                                             "Visible : "+visible);
                         */
                        m.setBounds(rect.current);
                        if (m instanceof Container)
                           {Container panel = (Container)m;
                            if (panel instanceof RootPaneContainer)
                               panel = ((RootPaneContainer)panel).getContentPane();
                            LayoutManager theLayout = panel.getLayout();
                            if (theLayout != null)
                               theLayout.layoutContainer(panel);
                           }
                      }
                 target.repaint();
                 // System.out.println("ScrollRectLayout::layoutContainer() message: stop");
                }
            }
       public boolean relocate(Object comp, Rectangle bounds) {
              if (rectangles == null)
                 return false;
              ObjectRectangle rect = (ObjectRectangle)rectangles.get(comp);
              if (rect == null)
                 return false;
              rect.actual = bounds;
              return true;
       }
};