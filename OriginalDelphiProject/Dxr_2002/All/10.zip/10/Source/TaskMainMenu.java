import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TaskMainMenu extends JMenuBar {

       static Object dataFile[][] = {
              {"New",TaskPanel.CM_NEW,new Integer(KeyEvent.VK_V)},
              {"Open",TaskPanel.CM_OPEN,new Integer(KeyEvent.VK_O)},
              {"Save HTML table",TaskPanel.CM_SAVE_TABLE,new Integer(KeyEvent.VK_T)},
              {"Save HTML table as...",TaskPanel.CM_SAVE_TABLE_AS,new Integer(KeyEvent.VK_A)},
              {"Save HTML TEXT/CSS",TaskPanel.CM_SAVE_CSS,new Integer(KeyEvent.VK_C)},
              {"Save HTML TEXT/CSS as...",TaskPanel.CM_SAVE_CSS_AS,new Integer(KeyEvent.VK_S)},
              {"Save source file",TaskPanel.CM_SAVE_TMP,new Integer(KeyEvent.VK_F)},
              {null,null,null},
              {"Exit",TaskPanel.CM_QUIT,new Integer(KeyEvent.VK_X)}
       };
       static Object dataEdit[][] = {
              /* {"Undo",TaskPanel.CM_UNDO,new Integer(KeyEvent.VK_U)},
              {null,null,null}, */
              {"Cut",TaskPanel.CM_CUT,new Integer(KeyEvent.VK_T)},
              {"Copy",TaskPanel.CM_COPY,new Integer(KeyEvent.VK_C)},
              {"Paste",TaskPanel.CM_PASTE,new Integer(KeyEvent.VK_P)}
       };
       static Object dataAction[][] = {
              {"Insert...",TaskPanel.CM_INSERT,new Integer(KeyEvent.VK_I)},
              {"Delete",TaskPanel.CM_DELETE,new Integer(KeyEvent.VK_D)},
              {"Properties",TaskPanel.CM_PROPERTIES,new Integer(KeyEvent.VK_P)},
              {null,null,null},
              {"Justify left...",TaskPanel.CM_LEFT_WRAP,new Integer(KeyEvent.VK_L)},
              {"Justify top...",TaskPanel.CM_TOP_WRAP,new Integer(KeyEvent.VK_T)},
              {"Justify right...",TaskPanel.CM_RIGHT_WRAP,new Integer(KeyEvent.VK_R)},
              {"Justify bottom...",TaskPanel.CM_BOTTOM_WRAP,new Integer(KeyEvent.VK_B)}
       };
       TaskMainMenu(ActionListener listener) {
           addMenuSystem("File",KeyEvent.VK_F,dataFile,listener);
           addMenuSystem("Edit",KeyEvent.VK_E,dataEdit,listener);
           addMenuSystem("Action",KeyEvent.VK_A,dataAction,listener);
       }

       private void addMenuSystem(String name, int mnemonic, final Object[][] submenu, ActionListener listener) {
               try { JMenu menu = new JMenu(name);
                     makeSubmenu(menu,submenu,listener);
                     menu.setMnemonic(mnemonic);
                     add(menu);
                   }
               catch (SubmenuException e)
                   { System.out.println ("Wrong data for <<"+name+">> submenu...");
                     System.exit(1);
                   }
       }

       private void makeSubmenu(JMenu parent,final Object data[][],ActionListener listener) throws SubmenuException {
               if (parent == null)
                  throw new SubmenuException("Out of submenu parent...");
               if (data.length == 0)
                  throw new SubmenuException("Out of submenu data...");
               for (int i = 0; i < data.length; i++)
                   {if (data[i][0] == null || !(data[i][0] instanceof String))
                       parent.addSeparator();
                    else
                       { JMenuItem item = new JMenuItem((String)data[i][0]);
                         if (data[i][1] != null && (data[i][1] instanceof String))
                            item.setActionCommand((String)data[i][1]);
                         if (data[i][2] != null && (data[i][2] instanceof Integer))
                            { int c = ((Integer)data[i][2]).intValue();
                              if (c > 0)
                                 item.setMnemonic(c);
                            }
                         item.addActionListener(listener);
                         parent.add(item);
                       }
                   }
       }

       class SubmenuException extends Exception {
             SubmenuException() {
                    super();
             }
             SubmenuException(String msg) {
                    super(msg);
             }
       }

};