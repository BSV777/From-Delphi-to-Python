import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

interface TaskPanelOwner {
          void showInfo(String info);
          void quit();
};

public class TaskPanel extends JPanel implements VisualContainer, ActionListener {
       public final static int     DEFAULT_WIDTH   = 600;
       public final static int     DEFAULT_HEIGHT  = 400;
       public final static int     INSETS_RIGHT    = 20;
       public final static int     INSETS_BOTTOM   = 15;
       public final static int    INTERSECT_BOTH   = 0;
       public final static int    INTERSECT_WIDTH  = 1;
       public final static int    INTERSECT_HEIGHT = 2;

       public final static String CM_NEW           = "cmNew";
       public final static String CM_OPEN          = "cmOpen";
       public final static String CM_SAVE_TABLE    = "cmSaveTable";
       public final static String CM_SAVE_TABLE_AS = "cmSaveTableAs";
       public final static String CM_SAVE_CSS      = "cmSaveCSS";
       public final static String CM_SAVE_CSS_AS   = "cmSaveCSSAs";
       public final static String CM_SAVE_TMP      = "cmSaveTmp";
       public final static String CM_QUIT          = "cmQuit";
       public final static String CM_UNDO          = "cmUndo";
       public final static String CM_COPY          = "cmCopy";
       public final static String CM_CUT           = "cmCut";
       public final static String CM_PASTE         = "cmPaste";
       public final static String CM_INSERT        = "cmInsert";
       public final static String CM_DELETE        = "cmDelete";
       public final static String CM_PROPERTIES    = "cmProperties";
       public final static String CM_LEFT_WRAP     = "cmLWrap";
       public final static String CM_TOP_WRAP      = "cmTWrap";
       public final static String CM_RIGHT_WRAP    = "cmRWrap";
       public final static String CM_BOTTOM_WRAP   = "cmBWrap";

       public final static int    TMP_SAVED        = 0x00000001;
       public final static int    TABLE_SAVED      = 0x00000002;
       public final static int    CSS_SAVED        = 0x00000004;

       final static int    INSERT_DUMMY            = 0;
       final static int    INSERT_BUTTON           = 1;
       final static int    INSERT_LABEL            = 2;
       final static int    INSERT_TEXT             = 3;

       final static int    UNDEF                   = 0;
       final static int    LESS                    = 1;
       final static int    INSIDE                  = 2;

       final static int    NOTHING_SAVE            = -1;

       final static String[] HTML_EXTS = {"htm","html"};
       final static String[] SRC_EXTS  = {"src"};

       Dimension               psize   = new Dimension(DEFAULT_WIDTH,DEFAULT_HEIGHT);
       Dimension               isize   = new Dimension(0,0);
       TaskObjectsList         items   = new TaskObjectsList();
       TaskPanelOwner       mainWindow = null;
       int           intersectOption   = INTERSECT_BOTH;
       int                     saved   = TMP_SAVED|TABLE_SAVED|CSS_SAVED;
       String               tablefname = null;
       String               cssfname   = null;
       String               srcfname   = null;

       TaskVisualObject    focus_info  = null;
       TaskVisualObject    focus_last  = null;
       Rectangle           bounds_info = null;
       Point               cursor_info = null;

       File                curDirectory = null;

       class TaskPanelMouseAdapter extends MouseAdapter {
             public void mousePressed(MouseEvent e)
                    { if (e.isPopupTrigger())
                         { processPopupMenu(e);
                           e.consume();
                         }
                    }
             public void mouseReleased(MouseEvent e)
                    { if (e.isPopupTrigger())
                         { processPopupMenu(e);
                           e.consume();
                         }
                    }
       };
       class TaskPanelMouseMotionAdapter extends MouseMotionAdapter {
       };

       TaskPanel(TaskObjectsList list) {
           super();
           setLayout(new ScrollRectLayout(this));
           addMouseListener(new TaskPanelMouseAdapter());
           addMouseMotionListener(new TaskPanelMouseMotionAdapter());
           clearAll();
           newList(list);
       }
       public void linkMainWindow (TaskPanelOwner mainWindow) {
              this.mainWindow = mainWindow;
       }
       public Dimension getPreferredSize() {
              return psize;
       }
       protected void processKeyEvent(KeyEvent e) {
                 System.out.println(e);
                 super.processKeyEvent(e);
       };
       protected void processMouseEvent(MouseEvent e) {
                 showCursorPos(e.getX(),e.getY());
                 super.processMouseEvent(e);
       };
       protected void processMouseMotionEvent(MouseEvent e) {
                 showCursorPos(e.getX(),e.getY());
                 super.processMouseMotionEvent(e);
       };
       public void invalidate() {
              synchronized (getTreeLock())
                  { LayoutManager theLayout = getLayout();
                    if (theLayout != null)
                       { definePreferredSize();
                         theLayout.layoutContainer(this);
                       }
                  }
       }
       // interface VisualContainer {
       public void createItem() {
              synchronized (getTreeLock())
                  { int offsx = getOffs().x;
                    int offsy = Math.max(0,isize.height - getWidth() / 2);
                    setOffs(offsx,offsy);
                    int x = 0;
                    int y = isize.height - getOffs().y;
                    MouseEvent evt = new MouseEvent(this,MouseEvent.MOUSE_PRESSED,0,0,x,y,1,false);
                    processPopupMenu(evt);
                  }
       }
       public void relocateItem(TaskVisualObject item) {
              synchronized (getTreeLock())
                  { ScrollRectLayout theLayout = (ScrollRectLayout)getLayout();
                    theLayout.relocate(item,item.likeBounds());
                    invalidate();
                  }
       }
       public void instanceItem(TaskVisualObject item) {
              synchronized (getTreeLock())
                  { if (isIntersect(item))
                       { try { item.restoreBounds();
                               relocateItem(item);
                             }
                         catch (Exception e)
                             { removeItem(item);
                               invalidate();
                             }
                       }
                    else
                       { invalidate();
                       }
                    putOnScreen(item);
                  }
       }
       public void removeItem(TaskVisualObject item) {
              synchronized (getTreeLock())
                  { if (focus_last == item)
                       focus_last = null;
                    remove(item);
                    items.remove(item.getTaskObject());
                    invalidate();
                    saved = 0;
                  }
       }
       public void wrapAtItem(TaskVisualObject item, int mode) {
              synchronized (getTreeLock())
                  { Rectangle r = item.likeBounds();
                    for (int i = 0; i < getComponentCount(); i++)
                        { TaskVisualObject o = (getComponent(i) instanceof TaskVisualObject) ?
                                               (TaskVisualObject)getComponent(i) : null;
                          if (o == null || o == item)
                             continue;
                          Rectangle b = new Rectangle(o.likeBounds());
                          switch (mode)
                          { case WRAP_LEFT:
                                 if (b.x < r.x || b.x > r.x + r.width / 2)
                                    continue;
                                 b.x = r.x;
                                 break;
                            case WRAP_TOP:
                                 if (b.y < r.y || b.y > r.y + r.height / 2)
                                    continue;
                                 b.y = r.y;
                                 break;
                            case WRAP_RIGHT:
                                 if (b.x + b.width < r.x + r.width / 2 ||
                                     b.x + b.width  > r.x + r.width)
                                    continue;
                                 b.x = r.x + r.width - b.width;
                                 if (b.x < 0)
                                    continue;
                                 break;
                            case WRAP_BOTTOM:
                                 if (b.y + b.height < r.y + r.height / 2 ||
                                     b.y + b.height > r.y + r.height)
                                    continue;
                                 b.y = r.y + r.height - b.height;
                                 if (b.y < 0)
                                    continue;
                                 break;
                          }
                          if (!isIntersect(o,b))
                             { o.makeBounds(b);
                               relocateItem(o);
                             }
                        }
                    invalidate();
                  }
       }
       public boolean isIntersect(TaskVisualObject item) {
              synchronized (getTreeLock())
                  { return items.isIntersect(item.getTaskObject(),null);
                  }
       }
       public boolean isIntersect(TaskVisualObject item, Rectangle bounds) {
              synchronized (getTreeLock())
                  { return items.isIntersect(item.getTaskObject(),bounds);
                  }
       }
       public Point getOffs() {
              synchronized (getTreeLock())
                  { RectLayout theLayout = (RectLayout)getLayout();
                    return theLayout.getOffs();
                  }
       }
       public void setOffs(int x, int y) {
              synchronized (getTreeLock())
                  { ((RectLayout)getLayout()).setOffs(new Point(x,y));
                  }
       }
       public void showCursorPos(int x, int y) {
              synchronized (getTreeLock())
                  { cursor_info = new Point(Math.max(0,x + getOffs().x),Math.max(0,y + getOffs().y));
                    bounds_info = null;
                    showInfo();
                  }
       }
       public void showBounds(Rectangle bounds) {
              synchronized (getTreeLock())
                  { bounds_info = bounds;
                    cursor_info = null;
                    showInfo();
                  }
       }
       public void showFocused(TaskVisualObject focus, boolean enable) {
              synchronized (getTreeLock())
                  { if (enable)
                       { focus_info = focus;
                         focus_last = focus;
                       }
                    else
                    if (focus_info == focus)
                       focus_info = null;
                    showInfo();
                  }

       }
       public void setSrcfname(String filename) {
              srcfname  = filename;
              saved    |= filename != null ? TMP_SAVED : 0;
       }
       // };
       class TaskFileFilter extends javax.swing.filechooser.FileFilter {
             private Hashtable filters = null;
             private String description = null;
             private String fullDescription = null;
             private boolean useExtensionsInDescription = true;
             public TaskFileFilter() {
                    this.filters = new Hashtable();
             }
             public TaskFileFilter(String extension) {
                    this(extension,null);
             }
             public TaskFileFilter(String extension, String description) {
                    this();
                    if (extension!=null)
                       addExtension(extension);
                    if (description!=null)
                       setDescription(description);
             }
             public TaskFileFilter(String[] filters) {
                    this(filters, null);
             }
             public TaskFileFilter(String[] filters, String description) {
                    this();
                    for (int i = 0; i < filters.length; i++)
                        { addExtension(filters[i]);
                        }
                    if (description!=null)
                       setDescription(description);
             }
             public boolean accept(File f) {
                    if (f != null)
                       { if (f.isDirectory())
                            { return true;
                            }
                         String extension = getExtension(f);
                         if (extension != null && filters.get(getExtension(f)) != null)
                            { return true;
                            };
                       }
                    return false;
             }
             public String getExtension(File f) {
                    if (f != null)
                       { String filename = f.getName();
                         int i = filename.lastIndexOf('.');
                         if ( i > 0 && i < filename.length()-1 )
                            { return filename.substring(i+1).toLowerCase();
                            };
                       }
                    return null;
             }
             public void addExtension(String extension) {
                    if (filters == null)
                       { filters = new Hashtable(5);
                       }
                    filters.put(extension.toLowerCase(), this);
                    fullDescription = null;
             }
             public String getDescription() {
                    if (fullDescription == null)
                       { if (description == null || isExtensionListInDescription())
                            { fullDescription = description==null ? "(" : description + " (";
                              Enumeration extensions = filters.keys();
                              if (extensions != null)
                                 { fullDescription += "." + (String) extensions.nextElement();
                                   while (extensions.hasMoreElements())
                                         {fullDescription += ", ." + (String) extensions.nextElement();
                                         }
                                 }
                              fullDescription += ")";
                            }
                         else
                            { fullDescription = description;
                            }
                      }
                   return fullDescription;
             }
             public void setDescription(String description) {
                    this.description = description;
                    fullDescription = null;
             }
             public void setExtensionListInDescription(boolean b) {
                    useExtensionsInDescription = b;
                    fullDescription = null;
             }
             public boolean isExtensionListInDescription() {
                    return useExtensionsInDescription;
             }
       }
       public boolean mayDestroy(String info) {
              int rc = needStoring();
              if ( rc == NOTHING_SAVE ||
                  ((saved & (TABLE_SAVED | CSS_SAVED)) > 0 && (saved & (TMP_SAVED)) > 0)
                 )
                 return true;
              rc = JOptionPane.showOptionDialog(null,
                                                "Data not saved !"+(info == null ? "" : "\n"+info),
                                                "WARNING",
                                                JOptionPane.YES_NO_CANCEL_OPTION,
                                                JOptionPane.WARNING_MESSAGE,
                                                null,null,null);
               return rc == 0;
       }
       public void saveTable() {
              if (tablefname != null)
                 saveData("",null,tmpSaveAs(true));
              else
                 saveTableAs();
       }

       public int getSaved() {
              return saved;
       }
       public void saveTableAs() {
              if (needStoring() != NOTHING_SAVE)
                 { String filename = selectSaveFile(HTML_EXTS,"HTML files");
                   if (filename != null)
                      { saveData(filename,null,tmpSaveAs(true));
                      }
                 }
       }
       public void saveCSS() {
              if (cssfname != null)
                 saveData(null,"",tmpSaveAs(false));
              else
                 saveCSSAs();
       }
       public void saveCSSAs() {
              if (needStoring() != NOTHING_SAVE)
                 { String filename = selectSaveFile(HTML_EXTS,"HTML files");
                   if (filename != null)
                      { saveData(null,filename,tmpSaveAs(false));
                      }
                 }
       }
       public void saveTmp() {
              if (needStoring() != NOTHING_SAVE)
                 { if (srcfname != null)
                      saveData(null,null,srcfname);
                   else
                      { String filename = selectSaveFile(SRC_EXTS,"Source files");
                        if (filename != null)
                           { saveData(null,null,filename);
                           }
                      }
                 }
       }
       public int needStoring() {
              int count = NOTHING_SAVE;
              if (items.isStorable())
                 { ++count;
                   for (int i = 0; i < getComponentCount(); i++)
                       { Component         c = getComponent(i);
                         if (c instanceof TaskVisualObject)
                            {TaskVisualObject    visual = (TaskVisualObject)c;
                             if (visual.needStoring())
                                count++;
                            }
                       }
                 }
              switch (count)
              { case NOTHING_SAVE:
                     saved = TMP_SAVED|TABLE_SAVED|CSS_SAVED;
                case NOTHING_SAVE + 1:
                     break;
                default:
                     saved = 0;
              }
              return count;
       }
       public void actionPerformed(ActionEvent e) {
                   String cmd = e.getActionCommand();
                   if (cmd.equals(CM_NEW))
                      { newPanel();
                      }
                   else
                   if (cmd.equals(CM_OPEN))
                      { newFile();
                      }
                   else
                   if (cmd.equals(CM_SAVE_TABLE))
                      { saveTable();
                      }
                   else
                   if (cmd.equals(CM_SAVE_TABLE_AS))
                      { saveTableAs();
                      }
                   else
                   if (cmd.equals(CM_SAVE_CSS))
                      { saveCSS();
                      }
                   else
                   if (cmd.equals(CM_SAVE_CSS_AS))
                      { saveCSSAs();
                      }
                   else
                   if (cmd.equals(CM_SAVE_TMP))
                      { saveTmp();
                      }
                   else
                   if (cmd.equals(CM_INSERT))
                      { createItem();
                      }
                   else
                   if (cmd.equals(CM_QUIT))
                      { doQuit();
                      }

                   if (focus_last == null)
                      return;
                   if (cmd.equals(CM_COPY))
                      { focus_last.copy();
                      }
                   else
                   if (cmd.equals(CM_CUT))
                      { focus_last.cut();
                      }
                   else
                   if (cmd.equals(CM_PASTE))
                      { focus_last.paste();
                      }
                   else
                   if (cmd.equals(CM_DELETE))
                      { removeItem(focus_last);
                      }
                   else
                   if (cmd.equals(CM_PROPERTIES))
                      { focus_last.setProperties();
                        focus_last.requestFocus();
                      }
                   else
                   if (cmd.equals(CM_LEFT_WRAP))
                      { wrapAtItem(focus_last,WRAP_LEFT);
                      }
                   else
                   if (cmd.equals(CM_TOP_WRAP))
                      { wrapAtItem(focus_last,WRAP_TOP);
                      }
                   else
                   if (cmd.equals(CM_RIGHT_WRAP))
                      { wrapAtItem(focus_last,WRAP_RIGHT);
                      }
                   else
                   if (cmd.equals(CM_BOTTOM_WRAP))
                      { wrapAtItem(focus_last,WRAP_BOTTOM);
                      }



       }
       //
       private void signalThenStored() {
              for (int i = 0; i < getComponentCount(); i++)
                  { Component         c = getComponent(i);
                    if (c instanceof TaskVisualObject)
                       {TaskVisualObject visual = (TaskVisualObject)c;
                        visual.wasStored();
                       }
                 }
       }
       private void clearAll() {
               saved       = TABLE_SAVED | CSS_SAVED | TMP_SAVED;
               tablefname  = null;
               cssfname    = null;
               srcfname    = null;
               focus_info  = null;
               focus_last  = null;
               bounds_info = null;
               cursor_info = null;
               psize       = new Dimension(DEFAULT_WIDTH,DEFAULT_HEIGHT);
               isize       = new Dimension(0,0);
               removeAll();
               items.clear();
               setOffs(0,0);
       }
       private void newList(TaskObjectsList list) {
               if (list != null)
                  { for (int i = 0; i < list.size(); i++)
                        { try { TaskVisualObject visual = new TaskVisualObject(this,(TaskAbstractObject) list.get(i));
                                insertItem(visual);
                              }
                          catch ( Exception e)
                              {
                              }
                         }
                    setOffs(0,0);
                    list.clear();
                    list = null;
                    if (items.size() > 0)
                       { signalThenStored();
                         saved = TMP_SAVED;
                       }
                  }
       }
       private void newPanel() {
               if (mayDestroy("Clear anymore ?"))
                  { clearAll();
                    newList(null);
                  }
       }
       private void newFile() {
               if (mayDestroy("Load new data without saving ?"))
                  { String filename = selectOpenFile(SRC_EXTS,"Source files");

                    if (filename != null)
                       { TaskObjectsList list = null;
                         try { BufferedReader is = new BufferedReader(new FileReader(filename));
                               try { list = new TaskObjectsList(is);
                                   }
                               catch (IOException e)
                                   { JOptionPane.showMessageDialog(null,"Error reading file...");
                                     return;
                                   }
                             }
                         catch (IOException e)
                             { JOptionPane.showMessageDialog(null,"File\n"+filename+"\nnot found...");
                               return;
                             }
                         if (list == null || list.size() == 0)
                            { JOptionPane.showMessageDialog(null,"File\n"+filename+"\nis empty...");
                              return;
                            }
                         clearAll();
                         newList(list);
                         setSrcfname(filename);
                       }
                  }
       }
       private void doQuit() {
               if (mayDestroy("Quit anymore ?"))
                  { mainWindow.quit();
                  }
       }
       private String tmpSaveAs(boolean main) {
               String filename = (saved & TMP_SAVED) != 0 ? null :
                                 (srcfname == null ? "" : new String(srcfname));
               return filename;
       }
       private String selectOpenFile(String extensions[], String desc) {
              JFileChooser file     = new JFileChooser();
              TaskFileFilter filter = new TaskFileFilter(extensions,desc);
              file.setFileFilter(filter);
              file.setCurrentDirectory(curDirectory);
              String retval = null;
              if (file.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
                 { curDirectory = file.getCurrentDirectory();
                   retval       = file.getSelectedFile().getPath();
                 }
              return retval;
       }
       private String selectSaveFile(String extensions[], String desc) {
              JFileChooser file     = new JFileChooser();
              TaskFileFilter filter = new TaskFileFilter(extensions,desc);
              file.setFileFilter(filter);
              file.setCurrentDirectory(curDirectory);
              String retval = null;
              if (file.showSaveDialog(this) == JFileChooser.APPROVE_OPTION)
                 { curDirectory = file.getCurrentDirectory();
                   retval       = file.getSelectedFile().getPath();
                 }
              return retval;
       }
       private void saveData(String tfname, String cfname, String tmfname) {
               if (needStoring() == NOTHING_SAVE)
                  return;
               if (tfname != null)
                  { if (tfname.length() == 0)
                       tfname = tablefname == null ? null : new String(tablefname);
                    if (tfname != null)
                       { if (items.storeHtml(tfname,TaskObjectsList.STORE_TABLE))
                            { saved |= TABLE_SAVED;
                              tablefname = new String(tfname);
                              JOptionPane.showMessageDialog(null,tfname+" saved...");
                            }
                         else
                            { saved &= ~TABLE_SAVED;
                              JOptionPane.showMessageDialog(null,"Error saving "+tfname);
                            }
                       }
                  }
               if (cfname != null)
                  { if (cfname.length() == 0)
                       cfname = cssfname == null ? null : new String(cssfname);
                    if (cfname != null)
                       { if (items.storeHtml(cfname,TaskObjectsList.STORE_CSS))
                            { saved |= CSS_SAVED;
                              cssfname = new String(cfname);
                              JOptionPane.showMessageDialog(null,cfname+" saved...");
                            }
                         else
                            { saved &= ~CSS_SAVED;
                              JOptionPane.showMessageDialog(null,"Error saving "+cfname);
                            }
                       }
                  }
               if (tmfname != null)
                  { boolean rename = true;
                    if (tmfname.length() == 0)
                       { rename = false;
                         tmfname = tablefname == null ? ( cssfname == null ? null :
                                                           new String(cssfname) ) :
                                                           new String(tablefname);
                         if (tmfname != null)
                            { File tmp = new File(tmfname);
                              tmfname  = new String(tmp.getPath());
                              int fpos = tmfname.lastIndexOf('.');
                              int spos = tmfname.lastIndexOf(tmp.separatorChar);
                              if (fpos > spos)
                                 tmfname = tmfname.substring(0,fpos);
                              tmfname += ".src";
                            }
                       }
                    if (tmfname != null)
                       { if (items.storeTmp(tmfname))
                            { saved |= TMP_SAVED;
                              srcfname = rename ? new String(tmfname) : srcfname;
                              JOptionPane.showMessageDialog(null,tmfname+" saved...");
                            }
                         else
                            { saved &= ~TMP_SAVED;
                              JOptionPane.showMessageDialog(null,"Error saving "+tmfname);
                            }
                       }
                  }
               if ( (saved & (CSS_SAVED | TABLE_SAVED)) != 0 )
                  signalThenStored();
       }
       private void showInfo() {
               if (mainWindow != null)
                  { String info = "";
                    if (focus_info != null)
                       { Rectangle r = focus_info.getTaskObject().getBounds();
                         info += "Focused "+focus_info.getTaskObject().getName()+" at ("+r.x+","+r.y+"):("+
                                            (r.x+r.width-1)+","+(r.y+r.height-1)+") |";

                       }
                    if (bounds_info != null)
                       info += "Relocate to : ("+bounds_info.x+","+bounds_info.y+")"+":"+
                                              "("+(bounds_info.x+bounds_info.width-1)+","+(bounds_info.y+bounds_info.height-1)+")";
                    else
                    if (cursor_info != null)
                       info += "Cursor at "+cursor_info.x+":"+cursor_info.y;
                    mainWindow.showInfo(info);
                  }
       }
       private void insertItem(TaskVisualObject item) {
              synchronized (getTreeLock())
                  { items.add(item.getTaskObject());
                    add(item, new ObjectRectangle(item.likeBounds()));
                    instanceItem(item);
                    item.requestFocus();
                  }
       }
       private void definePreferredSize() {
               psize.width  = DEFAULT_WIDTH;
               psize.height = DEFAULT_HEIGHT;
               isize.width  = 0;
               isize.height = 0;
               for (int i = 0; i < items.size(); i++)
                   { TaskAbstractObject obj = (TaskAbstractObject)items.get(i);
                     isize.width  = Math.max(isize.width, obj.getMaxX());
                     isize.height = Math.max(isize.height, obj.getMaxY());
                   }
               psize.width  = Math.max(psize.width, isize.width + INSETS_RIGHT);
               psize.height = Math.max(psize.height, isize.height + INSETS_BOTTOM);
       }
       private Rectangle intersectRect(Rectangle bounds) {
               for (int i = 0; i < items.size(); i++)
                   { TaskAbstractObject o = (TaskAbstractObject)items.get(i);
                     Rectangle obounds    = o.getBounds();
                     int       xpos = UNDEF, ypos = UNDEF;
                     if (!bounds.intersects(obounds))
                        continue;
                     if (obounds.x <= bounds.x)
                        { if (bounds.x < obounds.x + obounds.width)
                             xpos = INSIDE;
                        }
                     else
                        xpos = LESS;
                     if (obounds.y <= bounds.y)
                        { if (bounds.y < obounds.y + obounds.height)
                             ypos = INSIDE;
                        }
                     else
                        ypos = LESS;
                     if ((xpos == INSIDE) && (ypos == INSIDE))
                        return null;
                     if (intersectOption == INTERSECT_WIDTH)
                        { if (xpos == LESS)
                             { bounds.width = Math.min(bounds.width,obounds.x - bounds.x);
                               continue;
                             }
                        }
                     if (intersectOption == INTERSECT_HEIGHT)
                        { if (ypos == LESS)
                             { bounds.height = Math.min(bounds.height,obounds.y - bounds.y);
                               continue;
                             }
                        }
                     if (xpos == LESS)
                        bounds.width = Math.min(bounds.width,obounds.x - bounds.x);
                     if (ypos == LESS)
                        bounds.height = Math.min(bounds.height,obounds.y - bounds.y);
                   }
               return bounds.isEmpty() ? null : bounds;
       }

       class TaskPanelPopupActionListener implements ActionListener {
             Point origin = null;
             int   mode   = INSERT_DUMMY;

             TaskPanelPopupActionListener(int mode, int x, int y) {
                 this.mode = mode;
                 origin    = new Point(x,y);
             }

             public void actionPerformed(ActionEvent e) {
                    Rectangle bounds = null;
                    switch (mode)
                    { case INSERT_LABEL:
                           bounds = intersectRect(new Rectangle(origin.x,origin.y,TaskLabelObject.getDefSize().width,TaskLabelObject.getDefSize().height));
                           break;
                      case INSERT_TEXT:
                           bounds = intersectRect(new Rectangle(origin.x,origin.y,TaskTextEditObject.getDefSize().width,TaskTextEditObject.getDefSize().height));
                           break;
                      case INSERT_BUTTON:
                           bounds = intersectRect(new Rectangle(origin.x,origin.y,TaskButtonObject.getDefSize().width,TaskButtonObject.getDefSize().height));
                           break;
                    }
                    if (bounds != null)
                       { try { TaskAbstractObject item = null;
                               switch (mode)
                               { case INSERT_LABEL:
                                      item = new TaskLabelObject(bounds,"");
                                      break;
                                 case INSERT_TEXT:
                                      item = new TaskTextEditObject(bounds,"");
                                      break;
                                 case INSERT_BUTTON:
                                      item = new TaskButtonObject(bounds,"");
                                      break;
                               }
                               TaskVisualObject visual = new TaskVisualObject(TaskPanel.this,item);
                               insertItem(visual);
                             }
                         catch (Exception ex)
                               {
                               }
                       }
             }
       }
       private void processPopupMenu(MouseEvent e) {
               JPopupMenu popup = new JPopupMenu();
               JMenuItem mi = new JMenuItem("Button");
               mi.addActionListener(new TaskPanelPopupActionListener(INSERT_BUTTON,e.getX()+getOffs().x,e.getY()+getOffs().y));
               popup.add(mi);

               mi = new JMenuItem("Text field");
               mi.addActionListener(new TaskPanelPopupActionListener(INSERT_TEXT,e.getX()+getOffs().x,e.getY()+getOffs().y));
               popup.add(mi);

               mi = new JMenuItem("Label");
               mi.addActionListener(new TaskPanelPopupActionListener(INSERT_LABEL,e.getX()+getOffs().x,e.getY()+getOffs().y));
               popup.add(mi);

               popup.show(this, e.getX(), e.getY());
       }
       private void putOnScreen(TaskVisualObject item) {
               synchronized (getTreeLock())
                   { Rectangle ibounds = item.likeBounds();
                     Rectangle vbounds = new Rectangle(getOffs().x,getOffs().y,getWidth(),getHeight());
                     int offsx = 0, offsy = 0;
                     if ( ibounds.intersects(vbounds) )
                        return;
                     offsx = Math.max(0, ibounds.x - getWidth() / 2);
                     offsy = Math.max(0, ibounds.y - getHeight() / 2);
                     setOffs(offsx,offsy);
                   }
       }

};