import  java.io.ObjectInputStream;
import  java.io.IOException;
import  java.awt.*;
import  java.awt.event.*;
import  java.util.*;
import  javax.swing.*;


public class RectLayout implements LayoutManager2, java.io.Serializable {
     private   static final long serialVersionUID = -7262534875583282631L;
     protected Hashtable rectangles = null;
     protected int width;
     protected int height;

     public RectLayout()
            { this(0,0);
            }
     public RectLayout(int w, int h)
            { rectangles = new Hashtable();
              width  = w;
              height = h;
            }
    protected void setComponent(Component comp, ObjectRectangle rect)
            { rectangles.put(comp,rect.clone());
            }
    protected void removeComponent(Component comp)
            { rectangles.remove(comp);
            }
    public void addLayoutComponent(String name, Component comp)
           {
           }
    public void addLayoutComponent(Component comp, Object constraints)
           {if (constraints instanceof ObjectRectangle)
               { setComponent(comp, (ObjectRectangle)constraints);
               }
            else
            if (constraints != null)
               { throw new IllegalArgumentException("cannot add to layout: constraints must be a ObjectRectangle");
               }
           }
    public void removeLayoutComponent(Component comp)
           { removeComponent(comp);
           }
    public Dimension minimumLayoutSize(Container target)
           { synchronized (target.getTreeLock())
                { Dimension dim = new Dimension(width, height);
                  if (dim.width == 0 || dim.height == 0)
                     return preferredLayoutSize(target);
                  return dim;
                 }
           }
    public Dimension preferredLayoutSize(Container target)
           { synchronized (target.getTreeLock())
                { Dimension dim = new Dimension(0, 0);
                  int nmembers  = target.getComponentCount();
                  for (int i = 0 ; i < nmembers; i++)
                      {Component        comp = target.getComponent(i);
                       ObjectRectangle  rect = (ObjectRectangle)rectangles.get(comp);
                       if (rect == null || !comp.isVisible())
                          continue;
                       dim.height = Math.max(dim.height, rect.actual.y + rect.actual.height);
                       dim.width  = Math.max(dim.width,  rect.actual.x + rect.actual.width);
                      }
                  return dim;
                 }
           }
    public Dimension maximumLayoutSize(Container target)
           { synchronized (target.getTreeLock())
                { Dimension dim = new Dimension(2000, 2000);
                  return dim;
                 }
           }
    public Point getOffs()
           { return new Point(0,0);
           }
    public void setOffs(Point offs)
           {
           }
    public float getLayoutAlignmentX(Container target)
           { return 0.0f;
           }
    public float getLayoutAlignmentY(Container target)
           { return 0.0f;
           }
    public void invalidateLayout(Container target)
           {
           }
    public void layoutContainer(Container target)
           { synchronized (target.getTreeLock())
                { if (target instanceof RootPaneContainer)
                     target = ((RootPaneContainer)target).getContentPane();
                  Insets insets    = target.getInsets();
                  Rectangle bounds = target.getBounds();
                  Rectangle visible = new Rectangle(bounds.x+insets.left,
                                                    bounds.y+insets.top,
                                                    bounds.width-(insets.left+insets.right),
                                                    bounds.height-(insets.top+insets.bottom));
                  int nmembers  = target.getComponentCount();
                  for (int i = 0 ; i < nmembers ; i++)
                      { Component       m    = target.getComponent(i);
                        ObjectRectangle rect = (ObjectRectangle)rectangles.get(m);
                        if (!m.isVisible() || rect == null)
                           continue;
                        if (insets.left + rect.actual.x >= visible.width  ||
                            insets.top  + rect.actual.y >= visible.height
                           )
                           {rect.current.setBounds(0,0,0,0);
                           }
                        else
                           {int x = insets.left+rect.actual.x,
                                y = insets.top+rect.actual.y,
                                w = rect.actual.width,
                                h = rect.actual.height;
                            if (x + w >= visible.width)
                               w = (visible.width - x);
                            if (y + h >= visible.height)
                               h = (visible.height - y);
                            rect.current.setBounds(x,y,w,h);
                            if (rect.current.isEmpty())
                               rect.current.setBounds(0,0,0,0);
                           }
                        m.setBounds(rect.current);
                      }
                }
           }
    public String toString()
           { return getClass().getName() + "[x=" + width + ",h=" + height + "]";
           }
    public float getAlignmentX()
           { // System.out.println("TestPhrase::getAlignmentX() message");
             return 0.0f;
           }
    public float getAlignmentY()
           { // System.out.println("TestPhrase::getAlignmentY() message");
             return 0.0f;
           }
}