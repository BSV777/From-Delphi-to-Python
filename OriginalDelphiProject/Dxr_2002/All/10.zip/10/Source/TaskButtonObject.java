import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;

public class TaskButtonObject extends TaskLabelObject {
       public static final String NAME = "Button";
       public static final String TEXT = "caption";
       /* Initial element width, when created */
       final static int DEFAULT_WIDTH    = 80;
       /* Initial element height, when created */
       final static int DEFAULT_HEIGHT   = 24;
       /* Minimal and maximal values for width and height */
       final static int MIN_WIDTH        = 24;
       final static int MIN_HEIGHT       = 24;
       final static int MAX_WIDTH        = 1024;
       final static int MAX_HEIGHT       = 128;

       final static Color FORE_COLOR           = new Color(Color.black.getRGB());
       final static Color BACK_COLOR           = new Color(Color.lightGray.getRGB());
       final static Color BORDER_VALID_COLOR   = new Color(Color.green.getRGB());
       final static Color BORDER_INVALID_COLOR = new Color(Color.red.getRGB());

       public TaskButtonObject(Rectangle bounds, String text) throws Exception {
           super(bounds,text);
           if (this.bounds.width < MIN_WIDTH || this.bounds.height < MIN_HEIGHT)
              throw new Exception("Button size too low...");
           this.bounds.width  = Math.min(this.bounds.width,MAX_WIDTH);
           this.bounds.height = Math.min(this.bounds.height,MAX_HEIGHT);
       }
       public TaskButtonObject() {
              super();
              bounds = new Rectangle(-1,-1,DEFAULT_WIDTH,DEFAULT_HEIGHT);
       }
       public static Dimension getDefSize() {
              return new Dimension(DEFAULT_WIDTH,DEFAULT_HEIGHT);
       }
       public void setParamName(String pname) {
              if (pname.equalsIgnoreCase(TEXT))
                 sparam = PARAM_TEXT;
              else
                 super.setParamName(pname);
       }
       //
       public void putAsTable(PrintWriter os) {
              os.println("   "+strMarker()+">");
       }
       public void putAsCSS(PrintWriter os) {
              os.println(" "+strMarker()+strCSS()+">");
       }
       public boolean isGrowableX() {
              return true;
       }
       public boolean isGrowableY() {
              return true;
       }
       public Dimension getMinSize() {
              return new Dimension(MIN_WIDTH,MIN_HEIGHT);
       }
       public Dimension getMaxSize() {
              return new Dimension(MAX_WIDTH,MAX_HEIGHT);
       }
       public Border getValidBorder() {
              return new BevelBorder(BevelBorder.RAISED,Color.gray,Color.gray); 
                             // LineBorder(BORDER_VALID_COLOR,2,true);
       }
       public Border getInvalidBorder() {
              return new LineBorder(BORDER_INVALID_COLOR,1);
       }
       public void setText(String text) {
              this.text   = new String(text == null ? "" : text);
       }
       public void setRepresentation(JTextField view) {
              view.setForeground(FORE_COLOR);
              view.setBackground(BACK_COLOR);
              view.setBorder(getValidBorder());
              view.setText(text);
       }
       public void getRepresentation(JTextField view) {
              setText(view.getText());
       }
       public boolean isEmpty() {
              if (text == null || text.length() == 0)
                 return true;
              return false;
       }
       public String getTemporary() {
              return HEAD+NAME+
                          strParam(LEFT,bounds.x)+MORE+strParam(TOP,bounds.y)+MORE+
                          strParam(WIDTH,bounds.width)+MORE+strParam(HEIGHT,bounds.height)+
                          (text == null || text.length() == 0 ? "" : MORE+strParam(TEXT,text))+
                     TAIL;
       }
       public String  fullInfo() {
              return  NAME + " at " + strBounds() + strParam(TEXT,text);
       };
       public String  getName() {
              return  NAME;
       };
       public String  getTextAbbr() {
              return  TEXT;
       }
      //
       private String strMarker() {
               return "<input name = \"button"+id+"\""+
                            " type = \"button\""+
                            ( text == null || text.length() == 0 ? "" : " value = \""+text+"\"" );
       }
}