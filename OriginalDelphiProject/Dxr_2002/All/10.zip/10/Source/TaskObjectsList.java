import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;

public class TaskObjectsList extends ArrayList {
       final public static int STORE_TABLE = 0;
       final public static int STORE_CSS   = 1;

       public TaskObjectsList() {
              super();
       };
       public TaskObjectsList(Reader is) throws IOException {
              TaskObjectParser    parser = new TaskObjectParser(is);
              TaskAbstractObject  last   = null;
              int                 errors = 0;
              while (parser.hasMore())
                    { TaskAbstractObject newest = parser.nextObject();
                      if (newest != null)
                         { if (newest.getOrigin().x < 0)
                              { if (newest.getOrigin().y < 0)
                                   newest.setOrigin(last == null ? 0 : last.getLast().x+1,
                                                    last == null ? 0 : last.getOrigin().y);
                                else
                                   newest.setOrigin(last == null ? 0 : last.getOrigin().x, -1);
                              }
                           else
                           if (newest.getOrigin().y < 0)
                              newest.setOrigin(-1,last == null ? 0 : last.getOrigin().y);
                           if (isIntersect(newest,newest.getBounds()))
                              { System.out.println("Line "+parser.getLine()+": object "+newest.fullInfo()+" intersected - skipped...");
                                errors++;
                                continue;
                              }
                           else
                              System.out.println("Insert new : "+newest.fullInfo());
                           last = newest;
                           add(last);
                         }
                    }
              if (errors > 0)
                 System.out.println("Found "+errors+(errors == 1 ? "error" : "errors"));
              else
              if (size() == 0)
                 System.out.println("List is empty...");
              else
                 System.out.println("Found "+size()+" object(s)...");
       }
       public boolean isIntersect(TaskAbstractObject item, Rectangle bounds) {
              Rectangle rect = bounds == null ? item.getBounds() : bounds;
              for (int i = 0; i < size(); i++)
                  { TaskAbstractObject o = (TaskAbstractObject)get(i);
                    if (o == item)
                       continue;
                    if (rect.intersects(o.getBounds()))
                       return true;
                  }
              return false;
       }
       public boolean isStorable() {
              return size() > 0;
       }
       public boolean storeHtml(String fname, int mode) {
              boolean  error = false;
              PrintWriter os = null;
              try {os = new PrintWriter(new BufferedWriter(new FileWriter(fname)));
                   try { putHTMLHeader(os);
                         if (mode == STORE_CSS)
                            { putHTMLCSSData(os);
                            }
                         else
                            { putHTMLTableData(os);
                            }
                         putHTMLTail(os);
                       }
                   catch (IOException ex)
                       { System.out.println("Exception \""+ex.getMessage()+"\"\n"+ex.getStackTrace());
                         error = true;
                       }
                   os.close();
                  }
              catch (IOException e)
                  { System.out.println("Cannot open file "+fname+" for output...");
                    error = true;
                  }
              return !error;
       }
       public boolean storeTmp(String fname) {
              boolean  error = false;
              PrintWriter os = null;
              try {os = new PrintWriter(new BufferedWriter(new FileWriter(fname)));
                   try { putTmpData(os);
                       }
                   catch (IOException ex)
                       { System.out.println("Exception \""+ex.getMessage()+"\"\n"+ex.getStackTrace());
                         error = true;
                       }
                   os.close();
                  }
              catch (IOException e)
                  { System.out.println("Cannot open file "+fname+" for output...");
                    error = true;
                  }
              return !error;
       }

       //
       private void putHTMLHeader(PrintWriter os) {
               os.println("<HTML>");
               os.println("<!-- Created by HTML Form Builder by D.Litsa -->");
               os.println("<head>");
               os.println(" <title></title>");
               os.println(" <meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1251\">");
               os.println("</head>");
               os.println("<body>");
       }
       private void putHTMLTail(PrintWriter os) {
               os.println("</body>");
               os.println("</HTML>");
       }

       boolean sortError;

       class TaskAbstractObjectComparator implements Comparator {
             public int compare(Object o1, Object o2)  {
                    Rectangle b1 = ((TaskAbstractObject)o1).getBounds();
                    Rectangle b2 = ((TaskAbstractObject)o2).getBounds();

                    if (b1.y < b2.y)
                       return -1;
                    if (b1.y > b2.y)
                       return 1;
                    if (b1.x < b2.x)
                       return -1;
                    if (b1.x > b2.x)
                       return 1;
                    sortError = true;
                    return 0;
             }
       }

       private void putHTMLCSSData(PrintWriter os) throws IOException {
               Object si[] = toArray();
               sortError = false;
               Arrays.sort(si, new TaskAbstractObjectComparator());
               if (sortError)
                  throw new IOException("Error sorting objects...");
               for (int i = 0; i < si.length; i++)
                   ((TaskAbstractObject)si[i]).putAsCSS(os);
       }

       private void putTmpData(PrintWriter os) throws IOException {
               Object si[] = toArray();
               sortError = false;
               Arrays.sort(si, new TaskAbstractObjectComparator());
               if (sortError)
                  throw new IOException("Error sorting objects...");
               for (int i = 0; i < si.length; i++)
                   os.println(((TaskAbstractObject)si[i]).getTemporary());
       }

       private String strColspan(int columns) {
               if (columns > 1)
                  return " colspan = \""+columns+"\"";
               return "";
       }
       private String strRowspan(int rows) {
               if (rows > 1)
                  return " rowspan = \""+rows+"\"";
               return "";
       }
       private String strParam(String name, int value) {
               return " "+name+" = \""+value+"\"";
       }
       private void putTrs(PrintWriter os) {
               os.println(" <tr align = \"left\">");
       }
       private void putTrl(PrintWriter os) {
               os.println(" </tr>");
       }
       private void putTh(PrintWriter os, int width, int height) {
               os.println("  <th"+strParam("width",width)+strParam("height",height)+"></th>");
       }
       private void putThl(PrintWriter os) {
               os.println("  </th>");
       }
       private void putThColspan(PrintWriter os, int columns) {
               if (columns > 0)
                  os.println("  <th"+strColspan(columns)+"></th>");
       }
       private boolean putThColRowspan(PrintWriter os, int columns, int rows) {
               if (columns < 1 || rows < 1)
                  return false;
               os.println("  <th valign = \"top\""+strColspan(columns)+strRowspan(rows)+">");
               return true;
       }
       private void putHTMLTableData(PrintWriter os) throws IOException {
               int minx = -1, miny = -1, maxx = -1, maxy = -1;
               int xx[] = new int[size()*2];
               int yy[] = new int[size()*2];
               int columns = 0, rows = 0;
               ArrayList items = new ArrayList();
               Arrays.fill(xx,Integer.MAX_VALUE);
               Arrays.fill(yy,Integer.MAX_VALUE);
               sortError = false;

               for (int i = 0; i < size(); i++)
                   { TaskAbstractObject o = (TaskAbstractObject)get(i);
                     // if (o.isEmpty()) continue;
                     items.add(o);
                     Rectangle bounds = o.getBounds();
                     int x1 = bounds.x, y1 = bounds.y;
                     int x2 = x1 + bounds.width, y2 = y1 + bounds.height;
                     // Add rows positions
                     for (int cx = 0; cx < columns; cx++)
                         {if (xx[cx] == x1) x1 = -1;
                          if (xx[cx] == x2) x2 = -1;
                         }
                     if (x1 >= 0)
                        { xx[columns++] = x1;
                          if (minx < 0 || minx > x1) minx = x1;
                          if (maxx < 0 || maxx < x1) maxx = x1;
                        }
                     if (x2 >= 0)
                        { xx[columns++] = x2;
                          if (minx < 0 || minx > x2) minx = x2;
                          if (maxx < 0 || maxx < x2) maxx = x2;
                        }
                     // Add columns position
                     for (int cy = 0; cy < rows; cy++)
                         { if (yy[cy] == y1) y1 = -1;
                           if (yy[cy] == y2) y2 = -1;
                         }
                     if (y1 >= 0)
                        { yy[rows++] = y1;
                          if (miny < 0 || miny > y1) miny = y1;
                          if (maxy < 0 || maxy < y1) maxy = y1;
                        }
                     if (y2 >= 0)
                        { yy[rows++] = y2;
                          if (miny < 0 || miny > y2) miny = y2;
                          if (maxy < 0 || maxy < y2) maxy = y2;
                        }
                   }

               if (items.size() <= 0)
                  throw new IOException("Nothing store in HTML...");
               Arrays.sort(xx);
               Arrays.sort(yy);
               TaskAbstractObject si[] = new TaskAbstractObject[items.size()];
               for (int i = 0; i < items.size(); i++)
                   si[i] = (TaskAbstractObject)items.get(i);
               Arrays.sort(si, new TaskAbstractObjectComparator());
               if (sortError || minx < 0 || minx >= maxx || miny < 0 || miny >= maxy)
                  throw new IOException("Error sorting objects ["+columns+","+rows+"] ("+minx+","+miny+","+maxx+","+maxy+")...");

               // Print table header
               os.println("<table border = \"0\">");

               // Print width formatter line
               putTrs(os);
               putTh(os,minx,miny);
               for (int xcount = 1, lastx = minx; xcount < columns; lastx = xx[xcount++])
                   { putTh(os,xx[xcount]-lastx,miny);
                   }
               putTrl(os);

               int               citem = 0;
               boolean            more = true;
               TaskAbstractObject item = si[citem];
               Rectangle        bounds = item.getBounds();
               for (int ycount = 1, lasty = miny; more && ycount < rows; lasty = yy[ycount++])
                   { // Print height formatter line
                     putTrs(os);
                     putTh(os,minx,yy[ycount]-lasty);
                     int xpos = minx;
                     int ccol = 1;
                     while (lasty == bounds.y)
                           { int wcount = 0;
                             while (xpos < bounds.x)
                                   {if (ccol + wcount >= columns)
                                       throw new IOException("Error defined X position...");
                                    xpos = xx[ccol + wcount];
                                    wcount++;
                                   }
                             putThColspan(os,wcount);
                             ccol += wcount;

                             wcount = 0;
                             while (xpos < bounds.x + bounds.width)
                                   {if (ccol + wcount >= columns)
                                       throw new IOException("Error defined object width...");
                                    xpos = xx[ccol+wcount];
                                    wcount++;
                                   }
                             ccol += wcount;

                             int ypos   = lasty;
                             int hcount = 0;
                             int crow   = ycount;
                             while (ypos < bounds.y + bounds.height)
                                   {if (crow + hcount >= rows)
                                       throw new IOException("Error defined object height...");
                                    ypos = yy[crow+hcount];
                                    hcount++;
                                   }
                             if (putThColRowspan(os,wcount,hcount))
                                { item.putAsTable(os);
                                  putThl(os);
                                }
                             if (++citem >= si.length)
                                { more = false;
                                  break;
                                }
                             item   = si[citem];
                             bounds = item.getBounds();
                           }
                     putTrl(os);
                   }
               // Print table tail
               os.println("</table>");
       }
}