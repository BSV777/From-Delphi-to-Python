import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import javax.swing.*;
import javax.swing.border.*;

public class TaskWindow extends JFrame implements TaskPanelOwner {
       static final int DEFAULT_WIDTH  = 800;
       static final int DEFAULT_HEIGHT = 550;

       private  TaskMainMenu    menuBar     = null;
       private  TaskToolbar     toolBar     = null;
       private  TaskPanel       mainPanel   = null;
       private  JTextField      status      = null;

       public TaskWindow(String title,String srcfname, TaskObjectsList list) {
              super(title);
              setDefaultLayout();
              setMainPanel(new TaskPanel(list));
              setMenuBar(new TaskMainMenu(mainPanel));
              setToolBar(new TaskToolbar(mainPanel));
              mainPanel.linkMainWindow(this);
              mainPanel.setSrcfname(srcfname);
              setStatusPanel();
              setDefaultListeners();
              setSize(DEFAULT_WIDTH,DEFAULT_HEIGHT);
       };

       public TaskWindow(TaskWindow dupe) {
              super();
              setTitle(dupe.getTitle());
              setDefaultLayout();
              setMenuBar(dupe.menuBar);
              dupe.remove(dupe.menuBar);
              setToolBar(dupe.toolBar);
              dupe.remove(dupe.toolBar);
              setMainPanel(dupe.mainPanel);
              dupe.remove(dupe.mainPanel);
              mainPanel.linkMainWindow(this);
              setStatusPanel();
              setDefaultListeners();
              setSize(dupe.getSize());
       }
       public void init() {
              show();
       }
       public Dimension getMinimumSize() {
              return new Dimension(TaskPanel.DEFAULT_WIDTH, TaskPanel.DEFAULT_HEIGHT);
       }
       // interface TaskInformativePanel {
       public void showInfo(String info) {
              if (status != null)
                 status.setText(info);
       }
       public void quit() {
              dispose();
              System.exit(0);
       }
       // }

       private void setDefaultLayout() {
               getContentPane().setLayout(new BorderLayout());
       }
       private void setMenuBar(TaskMainMenu menuBar) {
               if (menuBar == null)
                  System.exit(1);
               this.menuBar = menuBar;
               setJMenuBar(menuBar);
       }
       private void setToolBar(TaskToolbar toolBar) {
               if (toolBar == null)
                  System.exit(1);
               this.toolBar = toolBar;
               getContentPane().add(BorderLayout.NORTH,toolBar);
       }
       private void setMainPanel(TaskPanel mainPanel) {
               if (mainPanel == null)
                  System.exit(1);
               this.mainPanel = mainPanel;
               getContentPane().add(BorderLayout.CENTER,mainPanel);
       }
       private void setStatusPanel() {
               status = new JTextField("");
               status.setEnabled(false);
               status.setOpaque(false);
               status.setBorder(new BevelBorder(BevelBorder.RAISED,Color.gray,Color.gray));
               status.setDisabledTextColor(Color.black);
               getContentPane().add(BorderLayout.SOUTH,status);
       }
       private void checkExit() {
               if (mainPanel == null)
                  return;
               if (!mainPanel.mayDestroy("Quit without saving ?"))
                  { TaskWindow newest = new TaskWindow(this);
                    newest.show();
                  }
               else
                  System.exit(0);
       }
       private void setDefaultListeners() {
               addWindowListener(new WindowAdapter() {
                        public void windowClosing(WindowEvent e) {
                               checkExit();
                        }
                  });
       }
};