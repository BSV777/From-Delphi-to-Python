import java.awt.*;
import java.lang.*;

public class ObjectRectangle implements Cloneable, java.io.Serializable {
       public Rectangle actual  = new Rectangle();
       public Rectangle current = new Rectangle();

       ObjectRectangle()
             {
             }
       ObjectRectangle(Rectangle bounds)
             {this(bounds.x,bounds.y,bounds.width,bounds.height);
             }
       ObjectRectangle(int x, int y, int w, int h)
             {if (x < 0)
                 {actual.x = 0;
                  w += x;
                 }
              else
                 actual.x      = x;
              if (y < 0)
                 {actual.y = 0;
                  h += y;
                 }
              else
                 actual.y = y;
              if (w >= 0)
                 actual.width  = w;
              else
                 throw new IllegalArgumentException("ObjectRectangle : width less zerro...");
              if (h >= 0)
                 actual.height = h;
              else
                 throw new IllegalArgumentException("ObjectRectangle : height less zerro...");
             }
       public Object clone()
              {ObjectRectangle n = new ObjectRectangle(actual);
               return n;
              }
};