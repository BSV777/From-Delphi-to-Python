import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class HtmlBuilder {
       static void showHelp() {
            System.out.println("Usage : java HtmlBuilder [-options] [source] [dest] ");
            System.out.println("   or : java -jar HtmlBuilder.jar [-options] [source] [dest] ");
            System.out.println("      options:");
            System.out.println("         -table<default> - put as <TABLE></TABLE> document");
            System.out.println("         -css            - put as TEXT/CSS style document");
            System.out.println("         -c              - check source file only");
            System.exit(0);
       }
       public static void main(String[] args)
              { boolean         helpmode  = false;
                boolean         checkmode = false;
                boolean         cssoutput = false;
                String          input     = null;
                String          output    = null;
                TaskObjectsList list      = null;

                for (int i = 0; i < args.length; i++)
                    { String arg = args[i].toUpperCase(Locale.getDefault());
                      if (arg.equals("/?") || arg.equals("-?"))
                         helpmode = true;
                      else
                      if (arg.equals("/C") || arg.equals("-C"))
                         checkmode = true;
                      else
                      if (arg.equals("/CSS") || arg.equals("-CSS"))
                         cssoutput = true;
                      else
                      if (arg.equals("/TABLE") || arg.equals("-TABLE"))
                         cssoutput = false;
                      else
                      if (input == null)
                         input = new String(args[i]);
                      else
                      if (output == null)
                         output = new String(args[i]);
                    }
                if (helpmode)
                   showHelp();
                if (checkmode && input == null)
                   { System.out.println("You need define source file in check mode...");
                     System.exit(1);
                   }
                if (input != null)
                   { try { BufferedReader is = new BufferedReader(new FileReader(input));
                           try { list = new TaskObjectsList(is);
                               }
                           catch (IOException e)
                               { System.out.println("Error reading file...");
                                 System.exit(1);
                               }
                         }
                     catch (IOException e)
                         { System.out.println("File <"+input+"> not found...");
                           input = null;
                         }
                   }
                if (checkmode)
                   System.exit(0);
                if (output != null)
                   { if (list == null || list.size() == 0)
                        { System.out.println("Nothing to save...");
                          System.exit(1);
                        }
                     boolean ok = false;
                     if (cssoutput)
                        ok = list.storeHtml(output,TaskObjectsList.STORE_CSS);
                     else
                        ok = list.storeHtml(output,TaskObjectsList.STORE_TABLE);
                     if (ok)
                        System.out.println("All done...");
                     else
                        System.out.println("Error storing output file...");
                     System.exit(0);
                   }
                final TaskWindow window = new TaskWindow("HTML Builder", input, list);
                window.init();
              }
}