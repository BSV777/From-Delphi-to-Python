#include "competitionmainwindow.h"

#include <qapplication.h>
#include <qworkspace.h>
#include <qmenubar.h>
#include <qtoolbar.h>
#include <qpopupmenu.h>
#include <qaction.h>


CompetitionMainWindow::CompetitionMainWindow( QWidget* parent, const char* name, WFlags f )
	: QMainWindow( parent, name, f )
{
	setCaption("Competition");

	mdi = new QWorkspace( this, "workspace" );
	mdi->setBackgroundMode( PaletteDark );

	QPopupMenu *fileMenu = new QPopupMenu( this );
	menuBar()->insertItem( tr("&File"), fileMenu );
	QToolBar *fileToolBar = new QToolBar( this );
	addToolBar( fileToolBar, tr("File") );
	QAction *action = 0;

	action = new QAction( tr("New"), tr("&New"), CTRL+Key_N, this );
	connect( action, SIGNAL( activated() ), SLOT( fileNew() ) );
	action->addTo( fileMenu );
	action->addTo( fileToolBar );

	action = new QAction( tr("Exit"), tr("E&xit"), 0, this );
	fileMenu->insertSeparator();
	action->addTo( fileMenu );
	connect( action, SIGNAL( activated() ), qApp, SLOT( closeAllWindows() ) );

	// Insert more actions

	setCentralWidget( mdi );

}


void CompetitionMainWindow::fileNew()
{
	// Use your own documentclass

	QWidget *doc = new QWidget( mdi, "$MSDEVPROJECTNAME document" );
	doc->setCaption( tr("Document%1").arg( mdi->windowList().count()+1 ) );
	doc->show();
}

