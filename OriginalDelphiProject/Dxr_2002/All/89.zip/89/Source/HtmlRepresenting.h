// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_HTMLREPRESENTING_3CA6BF8903D8_INCLUDED
#define _INC_HTMLREPRESENTING_3CA6BF8903D8_INCLUDED

#include "ExportMapRepresenting.h"

class Widget;

//##ModelId=3CA6BF8903D8
class HtmlRepresenting : public ExportMapRepresenting {
public:
    //##ModelId=3CA6E320007D
                            HtmlRepresenting();

    //##ModelId=3CA6E320009C
    virtual                 ~HtmlRepresenting();

    //##ModelId=3CA7299900AB
    virtual bool            CreateNewRaster();

    //##ModelId=3CA7299900CB
    virtual bool            CreateNewRow();

    //##ModelId=3CA7299900EA
    virtual bool            InsertNewCell(const QSize&  arSize,
                                          const Widget* apcObject);

    //##ModelId=3CA729990157
    virtual bool            CloseRow();

    //##ModelId=3CA729990177
    virtual bool            CloseRaster();

    //##ModelId=3CA7299901A5
    virtual QDomDocument    GetDocument();

private:
    //##ModelId=3CA7671502B1
    QDomDocument            m_Document;
    //##ModelId=3CA7671502A6
    QDomElement             m_Root;
    //##ModelId=3CA7671502A1
    QDomElement             m_Body;

    //##ModelId=3CA767150295
    QDomElement             m_Raster;
    //##ModelId=3CA767150290
    QDomElement             m_Row;

    //##ModelId=3CA767150251
    bool                    m_DocumentPrepared;
    //##ModelId=3CA767150242
    bool                    m_RasterPrepared;
    //##ModelId=3CA767150232
    bool                    m_RowPrepared;
};

#endif /* _INC_HTMLREPRESENTING_3CA6BF8903D8_INCLUDED */

