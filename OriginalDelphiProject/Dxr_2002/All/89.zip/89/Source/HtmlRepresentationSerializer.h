// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_HTMLREPRESENTATIONSERIALIZER_3CA6BF9A0280_INCLUDED
#define _INC_HTMLREPRESENTATIONSERIALIZER_3CA6BF9A0280_INCLUDED

#include "RepresentationSerializer.h"


//##ModelId=3CA6BF9A0280
class HtmlRepresentationSerializer : public RepresentationSerializer {
public:
	//##ModelId=3CA6C9970222
	                        HtmlRepresentationSerializer();

	//##ModelId=3CA6C9970232
	virtual                 ~HtmlRepresentationSerializer();

	//##ModelId=3CA6C9970177
	virtual bool            Serialize(const QDomDocument& arcDocument);

	//##ModelId=3CA6C99701A5
	virtual QString         GetString() const;

	//##ModelId=3CA6C99701C5
	virtual bool            Save(const QString& arcName);

	//##ModelId=3CA6C9970203
	virtual bool            Close();


private:
	//##ModelId=3CA6E35B0030
    QString                 m_String;
};

#endif /* _INC_HTMLREPRESENTATIONSERIALIZER_3CA6BF9A0280_INCLUDED */
