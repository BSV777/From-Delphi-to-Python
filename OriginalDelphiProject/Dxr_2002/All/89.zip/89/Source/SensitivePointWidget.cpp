// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "SensitivePointWidget.h"

#include "SensitivePointOrientation.h"
#include "View.h"
#include "Widget.h"

//##ModelId=3C89FC3803B9
SensitivePointWidget::SensitivePointWidget() {
    SetId(GenerateId());
    m_Properties.setRect(0, 0, 0, 0);
    m_pOrientation = NULL;
}

//##ModelId=3C89FC3803C8
SensitivePointWidget::~SensitivePointWidget() {
    delete m_pOrientation;
    m_pOrientation = NULL;
}

//##ModelId=3C89F65D0261
bool 
SensitivePointWidget::Draw(View*& arpDestinationView) const {
    return arpDestinationView->DrawSensitivePoint(this);
}

//##ModelId=3C89F65D029F
const QRect* 
SensitivePointWidget::GetPosition() const {
    return &m_Properties;
}

//##ModelId=3C89F65D02BF
void 
SensitivePointWidget::SetPosition(const QRect* apcPosition) {
    if ((apcPosition != NULL) &&
        (m_pOrientation != NULL)) {
        m_Properties = m_pOrientation->CalculatePosition(apcPosition);
    }
    else {
        m_Properties.setRect(0, 0, 0, 0);
    }
}

//##ModelId=3C89F65D02AF
const QString* 
SensitivePointWidget::GetValue() const {
    return NULL;
}

//##ModelId=3C89F65D030D
void 
SensitivePointWidget::SetValue(const QString* apcValue) {
}

//##ModelId=3C89F65D02EE
Command* 
SensitivePointWidget::Commit() {
    //FIXME:
    /* ������� ������� � ������� �� ����������??? */
    return NULL;
}

//##ModelId=3C89F65D02FD
void 
SensitivePointWidget::Cancel() {
    //FIXME:
}

//##ModelId=3C8D33030157
Widget* 
SensitivePointWidget::FindById(long aId) {
    /* Check mine */
    if (aId == GetId()) {
        return this;
    }
    else {
        /* Look at the children */
        return NULL;
    }
}

const Widget* 
SensitivePointWidget::FindById(long aId) const {
    /* Check mine */
    if (aId == GetId()) {
        return this;
    }
    else {
        /* Look at the children */
        return NULL;
    }
}

//##ModelId=3C93CA560157
void
SensitivePointWidget::SetOrientation(SensitivePointOrientation* apOrientation) {
    delete m_pOrientation;
    m_pOrientation = apOrientation;
}

//##ModelId=3C93CA040148
Widget*
SensitivePointWidget::GetOwner(const QPoint* apPosition) {
    if (apPosition != NULL) {
        if (m_Properties.contains(*apPosition)) {
            return this;
        }
    }
	return NULL;
}

//##ModelId=3C9B908501D4
bool
SensitivePointWidget::IsValidWidget(const Widget* apExamineWidget) const {
    return true;
}

void
SensitivePointWidget::MoveFrom(const QPoint* apDeparturePoint) {
    if (m_pOrientation == NULL) {
        return;
    }
    if (apDeparturePoint == NULL) {
        return;
    }

    m_pOrientation->MoveFrom(apDeparturePoint);
}

void
SensitivePointWidget::MoveTo(const QPoint*  apDestinationPoint, 
                             int            aGridSize) {
    if (m_pOrientation == NULL) {
        return;
    }

    if (apDestinationPoint == NULL) {
        return;
    }

    if (m_pParent == NULL) {
        return;
    }

    
    Widget* p_object = NULL;
    bool    result = false;
    p_object = m_pParent->GetChild();

    result = m_pOrientation->MoveTo(p_object, 
                                    apDestinationPoint, 
                                    aGridSize);
}

long
SensitivePointWidget::GetHash() const {
    return 0x00000000;
}
