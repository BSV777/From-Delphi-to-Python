// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "DataSaver.h"

#include "qfile.h"

#include "Widget.h"
#include "Model.h"
#include "Controller.h"


//##ModelId=3CA38D28032C
DataSaver::DataSaver() {
    m_Name = "";
    m_pFile = NULL;
}

//##ModelId=3CA38D28038A
DataSaver::~DataSaver() {
}

//##ModelId=3CA38D240148
void 
DataSaver::Notify() {
}

//##ModelId=3CA38D2401E4
bool 
DataSaver::DrawLabel(const Widget* apLabel) {
    if (m_pFile == NULL) {
        return false;
    }

    if (apLabel == NULL) {
        return true;
    }

    const QRect*    properties = NULL;
    QString         left;
    QString         top;
    QString         height;
    QString         width;
    QString         text;

    properties = apLabel->GetPosition();
    if (properties != NULL) {
        left.setNum(properties->left());
        top.setNum(properties->top());
        height.setNum(properties->height());
        width.setNum(properties->width());
    }

    if (apLabel->GetValue() != NULL) {
        text = *apLabel->GetValue();
    }

    m_Buffer = "<Label ";
    if (properties != NULL) {
        m_Buffer = m_Buffer + "Left=\"" + left + "\"; ";
        m_Buffer = m_Buffer + "Top=\"" + top + "\"; ";
        m_Buffer = m_Buffer + "Width=\"" + width + "\"; ";
        m_Buffer = m_Buffer + "Height=\"" + height + "\"";
        if (!text.isEmpty()) {
            m_Buffer = m_Buffer + ";";
        }
    }
               
    if (!text.isEmpty()) {
        m_Buffer = m_Buffer + " Text=\"" + text + "\"";
    }

    m_Buffer = m_Buffer + ">\n";

    int     length = -1;
    int     saved = -1;

    length = m_Buffer.length();
    saved = m_pFile->writeBlock(m_Buffer.ascii(), length);

	return (length == saved);
}

//##ModelId=3CA38D2402FD
bool 
DataSaver::DrawButton(const Widget* apButton) {
    if (m_pFile == NULL) {
        return false;
    }

    if (apButton == NULL) {
        return true;
    }

    const QRect*    properties = NULL;
    QString         left;
    QString         top;
    QString         height;
    QString         width;
    QString         text;

    properties = apButton->GetPosition();
    if (properties != NULL) {
        left.setNum(properties->left());
        top.setNum(properties->top());
        height.setNum(properties->height());
        width.setNum(properties->width());
    }

    if (apButton->GetValue() != NULL) {
        text = *apButton->GetValue();
    }

    m_Buffer = "<Button ";
    if (properties != NULL) {
        m_Buffer = m_Buffer + "Left=\"" + left + "\";";
        m_Buffer = m_Buffer + "Top=\"" + top + "\";";
        m_Buffer = m_Buffer + "Width=\"" + width + "\";";
        m_Buffer = m_Buffer + "Height=\"" + height + "\"";
        if (!text.isEmpty()) {
            m_Buffer = m_Buffer + ";";
        }
    }
               
    if (!text.isEmpty()) {
        m_Buffer = m_Buffer + " Caption=\"" + text + "\"";
    }

    m_Buffer = m_Buffer + ">\n";

    int     length = -1;
    int     saved = -1;

    length = m_Buffer.length();
    saved = m_pFile->writeBlock(m_Buffer.ascii(), length);

	return (length == saved);
}

//##ModelId=3CA38D25004E
bool 
DataSaver::DrawTextEdit(const Widget* apTextEdit) {
    if (m_pFile == NULL) {
        return false;
    }

    if (apTextEdit == NULL) {
        return true;
    }

    const QRect*    properties = NULL;
    QString         left;
    QString         top;
    QString         height;
    QString         width;
    QString         text;

    properties = apTextEdit->GetPosition();
    if (properties != NULL) {
        left.setNum(properties->left());
        top.setNum(properties->top());
        height.setNum(properties->height());
        width.setNum(properties->width());
    }

    if (apTextEdit->GetValue() != NULL) {
        text = *apTextEdit->GetValue();
    }

    m_Buffer = "<TextEdit ";
    if (properties != NULL) {
        m_Buffer = m_Buffer + "Left=\"" + left + "\"; ";
        m_Buffer = m_Buffer + "Top=\"" + top + "\"; ";
        m_Buffer = m_Buffer + "Width=\"" + width + "\"; ";
        m_Buffer = m_Buffer + "Height=\"" + height + "\"";
        if (!text.isEmpty()) {
            m_Buffer = m_Buffer + ";";
        }
    }
               
    if (!text.isEmpty()) {
        m_Buffer = m_Buffer + " Caption=\"" + text + "\"";
    }

    m_Buffer = m_Buffer + ">\n";

    int     length = -1;
    int     saved = -1;

    length = m_Buffer.length();
    saved = m_pFile->writeBlock(m_Buffer.ascii(), length);

	return (length == saved);
}

//##ModelId=3CA38D250186
bool 
DataSaver::DrawMarker(const Widget* apMarker) {
	return true;
}

//##ModelId=3CA38D2502CE
bool 
DataSaver::DrawRoot(const Widget* apRoot) {
	return true;
}

//##ModelId=3CA38D26003E
bool 
DataSaver::DrawMouseLabel(const Widget* apMouseLabel) {
	return true;
}

//##ModelId=3CA38D260196
bool 
DataSaver::DrawSensitivePoint(const Widget* apSensitivePoint) {
	return true;
}

//##ModelId=3CA38D2602EE
bool 
DataSaver::SetServicedModel(Model* apModel, bool aReset) {
	return false;
}

//##ModelId=3CA38D270109
bool 
DataSaver::SetController(Controller* apController, bool aReset) {
	return false;
}

//##ModelId=3CA38D27032C
bool 
DataSaver::SaveModel(const Model* apcModel) {
    if (m_Name.isEmpty()) {
        return false;
    }

    if (apcModel == NULL) {
        return false;
    }

    bool    result = false;

    m_pFile = new QFile(m_Name);
    result = m_pFile->open(IO_WriteOnly);

    if (result) {
        result = apcModel->Draw(this);

        m_pFile->flush();
        m_pFile->close();
    }

    delete m_pFile;
    m_pFile = NULL;
    return result;
}

//##ModelId=3CA38D2800BB
const QString* 
DataSaver::GetName() const {
	return &m_Name;
}

//##ModelId=3CA38D2801A5
void 
DataSaver::SetName(const QString* apcNewName) {
    if (apcNewName != NULL) {
        m_Name = *apcNewName;
    }
    else {
        m_Name = "";
    }
}
