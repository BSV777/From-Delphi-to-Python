#include <qmainwindow.h>


class QWorkspace;


