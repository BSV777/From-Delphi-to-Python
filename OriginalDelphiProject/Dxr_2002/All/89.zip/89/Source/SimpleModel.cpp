// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "SimpleModel.h"

#include "View.h"
#include "Controller.h"

#include "Widget.h"

#include "CommandController.h"
#include "CommandFactory.h"
#include "SimpleCommandFactory.h"
#include "SimpleWidgetFactory.h"


//##ModelId=3C8D157302FD
SimpleModel::SimpleModel() {
    m_pRootWidget           = NULL;
    m_pSubscribedView       = NULL;
    m_pCommandController    = NULL;
    m_pCommandFactory       = NULL;
    m_pWidgetFactory        = NULL;
    m_pModelName            = NULL;

    m_pWidgetFactory        = new SimpleWidgetFactory();
    m_pCommandFactory       = new SimpleCommandFactory();
    m_pCommandController    = new CommandController();
    m_pRootWidget           = m_pWidgetFactory->CreateRootWidget();
}

//##ModelId=3C8D1573030D
SimpleModel::~SimpleModel() {
    if (m_pSubscribedView != NULL) {
        m_pSubscribedView->SetServicedModel(NULL, true);
        m_pSubscribedView = NULL;
    }

    delete m_pModelName;
    delete m_pRootWidget;
    delete m_pCommandController;
    delete m_pCommandFactory;
    delete m_pWidgetFactory;
}

//##ModelId=3C8D157300DA
void 
SimpleModel::SetName(const QString*& arpcNewName) {
    delete m_pModelName;
    m_pModelName = NULL;

    if (arpcNewName != NULL) {
        m_pModelName = new QString;
        *m_pModelName = *arpcNewName;
    }
}

//##ModelId=3C8D15730119
const QString* 
SimpleModel::GetName() const {
    return m_pModelName;
}

//##ModelId=3C8D15730128
Model*
SimpleModel::Subscribe(View* apNewView) {
    bool result = false;
    if (apNewView != NULL) {
        result = apNewView->SetServicedModel(this);
    }
    if (result) {
        m_pSubscribedView = apNewView;
        return this;
    }
    else {
        return NULL;
    }
}

//##ModelId=3C8D15730157
bool 
SimpleModel::UnSubscribe(View* apOldView) {
    bool result = false;
    result = (m_pSubscribedView == apOldView);
    if (result && 
        (apOldView != NULL)) {
        result = apOldView->SetServicedModel(NULL, true);
        m_pSubscribedView = NULL;
    }
    return result;
}

//##ModelId=3C8D15730196
bool 
SimpleModel::Draw(View* apView) const {
    if (apView == NULL) {
        return false;
    }
    else {
        return m_pRootWidget->Draw(apView);
    }
}

//##ModelId=3C8D273A00EA
void
SimpleModel::SetRootWidget(Widget*& arpNewRootWidget) {
    if (arpNewRootWidget != NULL) {
        delete m_pRootWidget;
        m_pRootWidget = arpNewRootWidget;
        if (m_pCommandController != NULL) {
            m_pCommandController->Clear();
        }
    }
    else {
    }
}

//##ModelId=3C8D157301E4
Widget* 
SimpleModel::GetWidgetById(long aId) {
    return m_pRootWidget->FindById(aId);
}

//##ModelId=3C8D15730203
void 
SimpleModel::Undo(int aCount) {
    if (m_pCommandController != NULL) {
        m_pCommandController->Undo(aCount);
    }
}

//##ModelId=3C8D15730242
void 
SimpleModel::Redo(int aCount) {
    if (m_pCommandController != NULL) {
        m_pCommandController->Redo(aCount);
    }
}

//##ModelId=3C8D15730280
void 
SimpleModel::Activate(Widget* apChosenWidget) {
    Widget*     marker = NULL;
    if (m_pRootWidget == NULL) {
        return;
    }

    marker = m_pRootWidget->FindById(MARKER_WIDGET_ID);
    if (marker == NULL) {
        return;
    }

    marker->AppendChild(apChosenWidget);
}

void
SimpleModel::PutCommand(Command* apNewCommand) {
    if ((m_pCommandController != NULL) &&
        (apNewCommand != NULL)){
        m_pCommandController->Execute(this, apNewCommand);
    }
}

inline
bool
SimpleModel::CanUndo() const {
    bool result = false;
     if (m_pCommandController != NULL) {
        result = m_pCommandController->CanUndo();
    }
    return result;
}

inline
bool
SimpleModel::CanRedo() const {
    bool result = false;
    if (m_pCommandController != NULL) {
        result = m_pCommandController->CanRedo();
    }
    return result;
}
