#include "stdafx.h"

QDomDocument*
DataLoader::Parse(const QString* apcSource) {
    m_ErrorCount = 0;
}
