// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"

#include "Widget.h"

//##ModelId=3C8A23CF00DD
long
Widget::GenerateId() {
    long new_id = -1;
    new_id = m_Random.NextLong() & 0x7fffffff;
    if (new_id < 100L) {
        new_id = GenerateId();
    }
    return new_id;
}

//##ModelId=3C9B90800232
void
Widget::MoveFrom(const QPoint*  apDeparturePoint) {
}

//##ModelId=3C9B908001A5
void
Widget::MoveTo(const QPoint*    apDestinationPoint, 
               int              aGridSize) {
}

long
Widget::GetHash(const QString* apcStr) const {
    const char*     pc_string = NULL;
    unsigned int    length = 0;
    long            hash =0xa3859100;

    if (apcStr != NULL) {
        pc_string = apcStr->ascii();
        length    = apcStr->length();

        unsigned int    i = 0;
        long            temp = 0x00000000;

        for (i = 0; i < length; i++) {
            temp = pc_string[i];
            temp = temp << (6*i%4);
            hash = hash + temp;
        }
    }
    return hash;
}

long
Widget::GetHash(const QRect* apcRect) const {
    const char*     pc_string = NULL;
    unsigned int    length = 0;
    long            hash =0x8220c5a2;

    if (apcRect != NULL) {
        long            temp = 0x7f13596b;
        temp = temp + apcRect->x();
        temp = temp << 8;
        temp = temp + apcRect->y();
        temp = temp << 8;
        temp = temp + apcRect->width();
        temp = temp << 8;
        temp = temp + apcRect->height();
        temp = temp << 8;
        hash = hash ^ temp;
    }
    return hash;
}
