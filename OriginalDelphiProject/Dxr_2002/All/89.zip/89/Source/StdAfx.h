#ifndef _STDAFX_H
#define _STDAFX_H

#include <vector>

#include <QString.h>
#include <QRect.h>
#include <QFile.h>
#include <QList.h>

using namespace std;

class Widget;
class Command;

typedef vector<Widget*>                 WidgetVector;
typedef vector<const Widget*>           ConstWidgetVector;
typedef WidgetVector::iterator          WidgetIterator;
typedef WidgetVector::const_iterator    ConstWidgetIterator;
typedef ConstWidgetVector::iterator     WidgetConstIterator;
typedef ConstWidgetVector::const_iterator
                                        ConstWidgetConstIterator;

typedef QList<Command>                  CommandQList;

#include "Command.h"
#include "Widget.h"

#ifndef NULL
#define NULL 0
#endif

#ifndef max
#define max(a, b) ((a)>(b))?(a):(b)
#endif

#ifndef min
#define min(a, b) ((a)<(b))?(a):(b)
#endif

#ifndef QT_THREAD_SUPPORT
#define QT_THREAD_SUPPORT 
#endif

// Widget types
enum WidgetType {
    UNKNOWN_WIDGET          = -1,
    LABEL_WIDGET            =  1,
    TEXTEDIT_WIDGET         =  2,
    BUTTON_WIDGET           =  3,
    ROOT_WIDGET             = 10,
    MOUSELABEL_WIDGET       = 11,
    MARKER_WIDGET           = 12,
    SENSITIVEPOINT_WIDGET   = 13
};

enum SensitivePointPosition {
    UNKNOWN                 = 0,
    NORTH                   = 1,
    NORTHEAST               = 2,
    EAST                    = 3,
    SOUTHEAST               = 4,
    SOUTH                   = 5,
    SOUTHWEST               = 6,
    WEST                    = 7,
    NORTHWEST               = 8
};

static const long   ROOT_WIDGET_ID          =  1;
static const long   MARKER_WIDGET_ID        = 10;
static const long   MOUSELABEL_WIDGET_ID    = 11;

static const int    COMMAND_STACK_SIZE      = 20;

static const int    DEFAULT_CONTROL_HEIGHT  = 25;
static const int    DEFAULT_CONTROL_WIDTH   = 60;
static const char*  DEFAULT_BUTTON_VALUE    = "Button";
static const char*  DEFAULT_TEXTEDIT_VALUE  = "Textedit";
static const char*  DEFAULT_LABEL_VALUE     = "Label";

static const char*  STRETCH_DOCUMENT        = "stretch";
static const char*  NORMAL_DOCUMENT         = "normal";

#endif