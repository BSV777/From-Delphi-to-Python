// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_SELECTOBJECTCOMMAND_3C866FEF0186_INCLUDED
#define _INC_SELECTOBJECTCOMMAND_3C866FEF0186_INCLUDED

#include "Command.h"

#include "Model.h"

//##ModelId=3C8A829F032C
class SelectObjectCommand : public Command {
public:
	//##ModelId=3C8A829F0340
	                        SelectObjectCommand();

	//##ModelId=3C8A829F033F
	virtual                 ~SelectObjectCommand();

	//##ModelId=3C8A829F033E
	virtual bool            Execute();

	//##ModelId=3C8A829F033D
	virtual bool            Unexecute();
};

#endif /* _INC_SELECTOBJECTCOMMAND_3C866FEF0186_INCLUDED */

