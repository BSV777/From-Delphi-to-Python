/****************************************************************************
** AppMainWindow meta object code from reading C++ file 'AppMainWindow.h'
**
** Created: Sun Mar 31 23:31:50 2002
**      by: The Qt MOC ($Id: //depot/qt/main/src/moc/moc.y#178 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#define Q_MOC_AppMainWindow
#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 8
#elif Q_MOC_OUTPUT_REVISION != 8
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "AppMainWindow.h"
#include <qmetaobject.h>
#include <qapplication.h>

#if defined(Q_SPARCWORKS_FUNCP_BUG)
#define Q_AMPERSAND
#else
#define Q_AMPERSAND &
#endif


const char *AppMainWindow::className() const
{
    return "AppMainWindow";
}

QMetaObject *AppMainWindow::metaObj = 0;

void AppMainWindow::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QMainWindow::className(), "QMainWindow") != 0 )
	badSuperclassWarning("AppMainWindow","QMainWindow");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION
QString AppMainWindow::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("AppMainWindow",s);
}

#endif // QT_NO_TRANSLATION
QMetaObject* AppMainWindow::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QMainWindow::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void(AppMainWindow::*m1_t0)();
    typedef void(AppMainWindow::*m1_t1)();
    typedef void(AppMainWindow::*m1_t2)();
    typedef void(AppMainWindow::*m1_t3)();
    typedef void(AppMainWindow::*m1_t4)();
    typedef void(AppMainWindow::*m1_t5)();
    typedef void(AppMainWindow::*m1_t6)();
    typedef void(AppMainWindow::*m1_t7)();
    typedef void(AppMainWindow::*m1_t8)();
    typedef void(AppMainWindow::*m1_t9)();
    typedef void(AppMainWindow::*m1_t10)();
    typedef void(AppMainWindow::*m1_t11)();
    typedef void(AppMainWindow::*m1_t12)();
    typedef void(AppMainWindow::*m1_t13)();
    typedef void(AppMainWindow::*m1_t14)();
    typedef void(AppMainWindow::*m1_t15)();
    typedef void(AppMainWindow::*m1_t16)();
    typedef void(AppMainWindow::*m1_t17)();
    typedef void(AppMainWindow::*m1_t18)();
    typedef void(AppMainWindow::*m1_t19)();
    typedef void(AppMainWindow::*m1_t20)();
    typedef void(AppMainWindow::*m1_t21)();
    typedef void(AppMainWindow::*m1_t22)();
    typedef void(AppMainWindow::*m1_t23)();
    typedef void(AppMainWindow::*m1_t24)();
    typedef void(AppMainWindow::*m1_t25)(const QString&);
    typedef void(AppMainWindow::*m1_t26)(QPaintEvent*);
    typedef void(AppMainWindow::*m1_t27)(QMouseEvent*);
    typedef void(AppMainWindow::*m1_t28)(QMouseEvent*);
    typedef void(AppMainWindow::*m1_t29)(QMouseEvent*);
    m1_t0 v1_0 = Q_AMPERSAND AppMainWindow::ToggleProperty;
    m1_t1 v1_1 = Q_AMPERSAND AppMainWindow::ToggleToolBar;
    m1_t2 v1_2 = Q_AMPERSAND AppMainWindow::ToggleShowGrid;
    m1_t3 v1_3 = Q_AMPERSAND AppMainWindow::ToggleSnapToGrid;
    m1_t4 v1_4 = Q_AMPERSAND AppMainWindow::ToggleCreateLabel;
    m1_t5 v1_5 = Q_AMPERSAND AppMainWindow::ToggleCreateTextEdit;
    m1_t6 v1_6 = Q_AMPERSAND AppMainWindow::ToggleCreateButton;
    m1_t7 v1_7 = Q_AMPERSAND AppMainWindow::ToggleStretchDocument;
    m1_t8 v1_8 = Q_AMPERSAND AppMainWindow::New;
    m1_t9 v1_9 = Q_AMPERSAND AppMainWindow::Open;
    m1_t10 v1_10 = Q_AMPERSAND AppMainWindow::Save;
    m1_t11 v1_11 = Q_AMPERSAND AppMainWindow::SaveAs;
    m1_t12 v1_12 = Q_AMPERSAND AppMainWindow::Close;
    m1_t13 v1_13 = Q_AMPERSAND AppMainWindow::Export;
    m1_t14 v1_14 = Q_AMPERSAND AppMainWindow::Quit;
    m1_t15 v1_15 = Q_AMPERSAND AppMainWindow::Redo;
    m1_t16 v1_16 = Q_AMPERSAND AppMainWindow::Undo;
    m1_t17 v1_17 = Q_AMPERSAND AppMainWindow::About;
    m1_t18 v1_18 = Q_AMPERSAND AppMainWindow::AboutQt;
    m1_t19 v1_19 = Q_AMPERSAND AppMainWindow::SetWindowsStyle;
    m1_t20 v1_20 = Q_AMPERSAND AppMainWindow::SetPlatinumStyle;
    m1_t21 v1_21 = Q_AMPERSAND AppMainWindow::SetMotifStyle;
    m1_t22 v1_22 = Q_AMPERSAND AppMainWindow::SetMotifPlusStyle;
    m1_t23 v1_23 = Q_AMPERSAND AppMainWindow::SetCdeStyle;
    m1_t24 v1_24 = Q_AMPERSAND AppMainWindow::SetSgiStyle;
    m1_t25 v1_25 = Q_AMPERSAND AppMainWindow::ChangeGridSize;
    m1_t26 v1_26 = Q_AMPERSAND AppMainWindow::paintEvent;
    m1_t27 v1_27 = Q_AMPERSAND AppMainWindow::mousePressEvent;
    m1_t28 v1_28 = Q_AMPERSAND AppMainWindow::mouseReleaseEvent;
    m1_t29 v1_29 = Q_AMPERSAND AppMainWindow::mouseMoveEvent;
    QMetaData *slot_tbl = QMetaObject::new_metadata(30);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(30);
    slot_tbl[0].name = "ToggleProperty()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "ToggleToolBar()";
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "ToggleShowGrid()";
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl_access[2] = QMetaData::Public;
    slot_tbl[3].name = "ToggleSnapToGrid()";
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl_access[3] = QMetaData::Public;
    slot_tbl[4].name = "ToggleCreateLabel()";
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl_access[4] = QMetaData::Public;
    slot_tbl[5].name = "ToggleCreateTextEdit()";
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    slot_tbl_access[5] = QMetaData::Public;
    slot_tbl[6].name = "ToggleCreateButton()";
    slot_tbl[6].ptr = *((QMember*)&v1_6);
    slot_tbl_access[6] = QMetaData::Public;
    slot_tbl[7].name = "ToggleStretchDocument()";
    slot_tbl[7].ptr = *((QMember*)&v1_7);
    slot_tbl_access[7] = QMetaData::Public;
    slot_tbl[8].name = "New()";
    slot_tbl[8].ptr = *((QMember*)&v1_8);
    slot_tbl_access[8] = QMetaData::Protected;
    slot_tbl[9].name = "Open()";
    slot_tbl[9].ptr = *((QMember*)&v1_9);
    slot_tbl_access[9] = QMetaData::Protected;
    slot_tbl[10].name = "Save()";
    slot_tbl[10].ptr = *((QMember*)&v1_10);
    slot_tbl_access[10] = QMetaData::Protected;
    slot_tbl[11].name = "SaveAs()";
    slot_tbl[11].ptr = *((QMember*)&v1_11);
    slot_tbl_access[11] = QMetaData::Protected;
    slot_tbl[12].name = "Close()";
    slot_tbl[12].ptr = *((QMember*)&v1_12);
    slot_tbl_access[12] = QMetaData::Protected;
    slot_tbl[13].name = "Export()";
    slot_tbl[13].ptr = *((QMember*)&v1_13);
    slot_tbl_access[13] = QMetaData::Protected;
    slot_tbl[14].name = "Quit()";
    slot_tbl[14].ptr = *((QMember*)&v1_14);
    slot_tbl_access[14] = QMetaData::Protected;
    slot_tbl[15].name = "Redo()";
    slot_tbl[15].ptr = *((QMember*)&v1_15);
    slot_tbl_access[15] = QMetaData::Protected;
    slot_tbl[16].name = "Undo()";
    slot_tbl[16].ptr = *((QMember*)&v1_16);
    slot_tbl_access[16] = QMetaData::Protected;
    slot_tbl[17].name = "About()";
    slot_tbl[17].ptr = *((QMember*)&v1_17);
    slot_tbl_access[17] = QMetaData::Protected;
    slot_tbl[18].name = "AboutQt()";
    slot_tbl[18].ptr = *((QMember*)&v1_18);
    slot_tbl_access[18] = QMetaData::Protected;
    slot_tbl[19].name = "SetWindowsStyle()";
    slot_tbl[19].ptr = *((QMember*)&v1_19);
    slot_tbl_access[19] = QMetaData::Protected;
    slot_tbl[20].name = "SetPlatinumStyle()";
    slot_tbl[20].ptr = *((QMember*)&v1_20);
    slot_tbl_access[20] = QMetaData::Protected;
    slot_tbl[21].name = "SetMotifStyle()";
    slot_tbl[21].ptr = *((QMember*)&v1_21);
    slot_tbl_access[21] = QMetaData::Protected;
    slot_tbl[22].name = "SetMotifPlusStyle()";
    slot_tbl[22].ptr = *((QMember*)&v1_22);
    slot_tbl_access[22] = QMetaData::Protected;
    slot_tbl[23].name = "SetCdeStyle()";
    slot_tbl[23].ptr = *((QMember*)&v1_23);
    slot_tbl_access[23] = QMetaData::Protected;
    slot_tbl[24].name = "SetSgiStyle()";
    slot_tbl[24].ptr = *((QMember*)&v1_24);
    slot_tbl_access[24] = QMetaData::Protected;
    slot_tbl[25].name = "ChangeGridSize(const QString&)";
    slot_tbl[25].ptr = *((QMember*)&v1_25);
    slot_tbl_access[25] = QMetaData::Protected;
    slot_tbl[26].name = "paintEvent(QPaintEvent*)";
    slot_tbl[26].ptr = *((QMember*)&v1_26);
    slot_tbl_access[26] = QMetaData::Protected;
    slot_tbl[27].name = "mousePressEvent(QMouseEvent*)";
    slot_tbl[27].ptr = *((QMember*)&v1_27);
    slot_tbl_access[27] = QMetaData::Protected;
    slot_tbl[28].name = "mouseReleaseEvent(QMouseEvent*)";
    slot_tbl[28].ptr = *((QMember*)&v1_28);
    slot_tbl_access[28] = QMetaData::Protected;
    slot_tbl[29].name = "mouseMoveEvent(QMouseEvent*)";
    slot_tbl[29].ptr = *((QMember*)&v1_29);
    slot_tbl_access[29] = QMetaData::Protected;
    metaObj = QMetaObject::new_metaobject(
	"AppMainWindow", "QMainWindow",
	slot_tbl, 30,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
