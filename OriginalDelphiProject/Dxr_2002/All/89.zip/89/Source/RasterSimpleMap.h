// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_RASTERSIMPLEMAP_3CA6BEA8003E_INCLUDED
#define _INC_RASTERSIMPLEMAP_3CA6BEA8003E_INCLUDED

#include "ExportMap.h"

#include <qdom.h>
#include <qsize.h>
#include <qpoint.h> 

class Widget;
class ExportMapRepresenting;

typedef struct _MapElement {
    short   x;              // 2
    short   y;              // 2
    short   width;          // 2
    short   height;         // 2
    long    id;             // 4
    short   x_cell;         // 2
    short   y_cell;         // 2
} MapElement;               // sizeof(MapElement) == 16

//##ModelId=3CA6BEA8003E
class RasterSimpleMap : public ExportMap {
public:
    //##ModelId=3CA6BF38006D
                            RasterSimpleMap(ExportMapRepresenting* apMapRepresenting);

    //##ModelId=3CA6BF38007D
    virtual                 ~RasterSimpleMap();

    //##ModelId=3CA6BECC0138
    virtual bool            CreateNewMap(const ConstWidgetVector* apcWidgets);

    //##ModelId=3CA6BECC0186
    virtual bool            CloseMap();

    //##ModelId=3CA6BECC01A5
    virtual QDomDocument    GetRepresentation();

private:
    //##ModelId=3CA6E353031F
    void                    GetSize();

    //##ModelId=3CA727C9006D
    bool                    PrepareMap();

    //##ModelId=3CA727C9005D
    bool                    WriteWidgets();

    //##ModelId=3CA727C9004E
    bool                    WriteWidget(const Widget* apcWidget);

    //##ModelId=3CA727C9003E
    void                    SetCellsData();

    //##ModelId=3CA727C90022
    void                    SetObjectCellsData(QPoint& arcFrom);

    //##ModelId=3CA767110196
    bool                    ConvertMap();

private:
    //##ModelId=3CA6E353031C
    QSize                   m_Size;

    //##ModelId=3CA6E353030F
    MapElement**            m_ppMap;

    //##ModelId=3CA6E35302FF
    const ConstWidgetVector*
                            m_pcWidgetArr;
    //##ModelId=3CA6E35302EE
    ExportMapRepresenting*  m_pRepresenting;

    //##ModelId=3CA727C9001F
    const Widget*           m_pRoot;
};

#endif /* _INC_RASTERSIMPLEMAP_3CA6BEA8003E_INCLUDED */
