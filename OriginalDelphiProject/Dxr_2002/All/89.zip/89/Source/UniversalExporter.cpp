// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "UniversalExporter.h"

#include "Widget.h"
#include "Model.h"
#include "Controller.h"
#include "ExportMap.h"
#include "RepresentationSerializer.h"

UniversalExporter::UniversalExporter(ExportMap*                 apExportMap, 
                                     RepresentationSerializer*  apSerializer) {

    m_pMap          = apExportMap;
    m_pSerializer   = apSerializer;

    m_Name          = "";

    m_pWidgetArr    = NULL;
}
                                     

//##ModelId=3CA6BC5400FA
UniversalExporter::~UniversalExporter() {
    delete m_pMap;
    delete m_pSerializer;

    m_pMap          = NULL;
    m_pSerializer   = NULL;
}

//##ModelId=3CA6BC54002E
void 
UniversalExporter::Initialize() {
    delete m_pWidgetArr;
    m_pWidgetArr = new ConstWidgetVector;
}

//##ModelId=3CA6BC530232
void 
UniversalExporter::SetName(const QString* apcName) {
    if (apcName != NULL) {
        m_Name  = *apcName;
    }
    else {
        m_Name  = "";
    }
}

bool
UniversalExporter::ExportModel(const Model* apcModel) {
    if (apcModel == NULL) {
        return false;
    }

    bool result = false;
    result = apcModel->Draw(this);
    return result;
}


//##ModelId=3CA6BC53035B
bool 
UniversalExporter::Finish() {
    bool    success = false;
    bool    result = false;
    do {
        if (m_pWidgetArr == NULL) {
            break;
        }

        if (m_pMap == NULL) {
            break;
        }

        if (m_pSerializer == NULL) {
            break;
        }


        result = m_pMap->CreateNewMap(m_pWidgetArr);
        m_pWidgetArr = NULL;
        if (!result) {
            break;
        }

        QDomDocument    document;
        QDomElement     root;

        document = m_pMap->GetRepresentation();

        if (document.isNull()) {
            break;
        }
/*
        root = document.documentElement();
        if (root.isNull()) {
            break;
        }
*/
        success = m_pSerializer->Serialize(document);
        if (!success) {
            break;
        }

        success = m_pSerializer->Save(m_Name);
        if (!success) {
            break;
        }

        success = m_pSerializer->Close();
        if (!success) {
            break;
        }

    } while (false);

/*
    while (!m_pWidgetArr->empty()) {
        m_pWidgetArr->pop_back();
    }
*/

    delete m_pWidgetArr;
    m_pWidgetArr = NULL;
    m_Name  = "";
	return success;
}

//##ModelId=3CA6BC50038A
void
UniversalExporter::Notify() {
}

//##ModelId=3CA6BC51002E
bool 
UniversalExporter::DrawLabel(const Widget* apLabel) {
    if (m_pWidgetArr == NULL) {
        return false;
    }

    if (apLabel == NULL) {
        return false;
    }

    m_pWidgetArr->push_back(apLabel);
	return true;
}

//##ModelId=3CA6BC510109
bool 
UniversalExporter::DrawButton(const Widget* apButton) {
    if (m_pWidgetArr == NULL) {
        return false;
    }

    if (apButton == NULL) {
        return false;
    }

    m_pWidgetArr->push_back(apButton);
	return true;
}

//##ModelId=3CA6BC5101F4
bool
UniversalExporter::DrawTextEdit(const Widget* apTextEdit) {
    if (m_pWidgetArr == NULL) {
        return false;
    }

    if (apTextEdit == NULL) {
        return false;
    }

    m_pWidgetArr->push_back(apTextEdit);
	return true;
}

//##ModelId=3CA6BC5102DE
bool 
UniversalExporter::DrawMarker(const Widget* apMarker) {
	return true;
}

//##ModelId=3CA6BC5103C8
bool 
UniversalExporter::DrawRoot(const Widget* apRoot) {
	return true;
}

//##ModelId=3CA6BC5200EA
bool 
UniversalExporter::DrawMouseLabel(const Widget* apMouseLabel) {
	return true;
}

//##ModelId=3CA6BC5201F4
bool 
UniversalExporter::DrawSensitivePoint(const Widget* apSensitivePoint) {
	return true;
}

//##ModelId=3CA6BC52030D
bool 
UniversalExporter::SetServicedModel(Model*  apModel, 
                                    bool    aReset) {
	return false;
}

//##ModelId=3CA6BC5300AB
bool 
UniversalExporter::SetController(Controller*    apController, 
                                 bool           aReset) {
	return false;
}
