// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_CREATELABELCOMMAND_3C8669220251_INCLUDED
#define _INC_CREATELABELCOMMAND_3C8669220251_INCLUDED
#include "Model.h"


#include "Command.h"

class Model;

//##ModelId=3C8669220251
class CreateLabelCommand : public Command {
protected:
	//##ModelId=3C9A5A9002EE
	virtual void            SetModel(Model* apModel);

public:
	//##ModelId=3C9B90DC0222
	virtual void            SetNewProperties(const QRect* apPosition);

	//##ModelId=3C9B90DC0251
	virtual void            SetNewValue(const QString* apValue);

	//##ModelId=3C9B90DC0280
	virtual void            SetOldValue(const QString* apValue);

	//##ModelId=3C9B90DC029F
	virtual void            SetOldProperties(const QRect* apPosition);

	//##ModelId=3C8A49080213
	                        CreateLabelCommand();

	//##ModelId=3C8A49080222
	virtual                 ~CreateLabelCommand();

	//##ModelId=3CA0DD8101F7
    virtual void            SetObject(const Widget* apObject) {}

private:
	//##ModelId=3C8A47BC01E4
	virtual bool            Execute();

	//##ModelId=3C8A47BC0232
	virtual bool            Unexecute();

private:
	//##ModelId=3CA0DD8101F4
    Model*                  m_pModel;

	//##ModelId=3CA0DD8101E4
    long                    m_ObjectId;

	//##ModelId=3CA0DD8101DB
    QRect*                  m_pProperties;

	//##ModelId=3CA0DD8101D6
    QString*                m_pValue;
};

//##ModelId=3C9A5AA10138
inline
void
CreateLabelCommand::SetModel(Model* apModel) {
    m_pModel = apModel;
}


#endif /* _INC_CREATELABELCOMMAND_3C8669220251_INCLUDED */
