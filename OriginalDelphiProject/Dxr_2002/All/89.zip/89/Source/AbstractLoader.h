// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_ABSTRACTLOADER_3C89D81703C8_INCLUDED
#define _INC_ABSTRACTLOADER_3C89D81703C8_INCLUDED

//##ModelId=3C89D81703C8
class AbstractLoader {
public:
	//##ModelId=3CA567D003D8
	inline virtual                  ~AbstractLoader();

	//##ModelId=3CA5661503A9
    virtual void                    SetFileName(const QString* apcFilename) = 0;

	//##ModelId=3CA5661502BF
    virtual WidgetVector*           LoadFile(const QString* apcFilename) = 0;

	//##ModelId=3CA56615035B
    virtual WidgetVector*           LoadFile() = 0;
};

//##ModelId=3CA567D003D8
inline 
AbstractLoader::~AbstractLoader() {
}

#endif /* _INC_ABSTRACTLOADER_3C89D81703C8_INCLUDED */
