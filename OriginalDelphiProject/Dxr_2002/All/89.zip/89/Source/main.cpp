#include "stdafx.h"

#include <qapplication.h>
#include <qstring.h>

#include "AppMainWindow.h"

#include "Command.h"
#include "Widget.h"
#include "RootWidget.h"
#include "LabelWidget.h"

#include "CommandFactory.h"
#include "SimpleCommandFactory.h"
#include "CommandController.h"

#include "widgetfactory.h"
#include "simplewidgetfactory.h"

#include "View.h"
#include "SimpleView.h"

#include "Controller.h"
#include "SimpleController.h"

#include "Model.h"
#include "SimpleModel.h"

int
main(int argc, char** argv) {
    int ret = 0;


    Model*          model = NULL;
    View*           view = NULL;
    Controller*     controller = NULL;
    Widget*         root = NULL;
    Widget*         child = NULL;
    Widget*         marker = NULL;
    WidgetFactory*  factory = NULL;
    bool            quick_export = false;

    QString         value;
    QRect           posit;

    model = new SimpleModel();

    controller = new SimpleController();
    controller->SetModel(model);

    if (argc == 3) {
        value = argv[1];
        quick_export = controller->Load(&value);

        value = argv[2];
        if (quick_export) {
            controller->Export(&value);
        }
    }

    QApplication    app(argc, argv);
    AppMainWindow*  window = NULL;

    if (!quick_export) {

        window = new AppMainWindow();
    	app.setMainWidget(window);

        window->SetController(controller);
	    window->show();

        ret = app.exec();
    }

    delete window;
    view = controller->GetView();
    model = controller->GetModel();
    controller->SetView(NULL);
    controller->SetModel(NULL);
    delete controller;
    delete view;
    delete model;
    delete factory;

	return ret;
}
