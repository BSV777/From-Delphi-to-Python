// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_CREATEEDITCOMMAND_3C86695800BB_INCLUDED
#define _INC_CREATEEDITCOMMAND_3C86695800BB_INCLUDED
#include "Model.h"


#include "Command.h"

class Model;

//##ModelId=3C86695800BB
class CreateEditCommand : public Command {
public:
	//##ModelId=3C9B91110157
	virtual void            SetNewProperties(const QRect* apPosition);

	//##ModelId=3C9B91110186
	virtual void            SetNewValue(const QString* apValue);

	//##ModelId=3C9B911101B5
	virtual void            SetOldValue(const QString* apValue);

	//##ModelId=3C9B911101E4
	virtual void            SetOldProperties(const QRect* apPosition);

	//##ModelId=3C8A48FD00BB
	                        CreateEditCommand();

	//##ModelId=3C8A48FD00DA
	virtual                 ~CreateEditCommand();

	//##ModelId=3CA0DD8401D4
    virtual void            SetObject(const Widget* apObject) {}

protected:
	//##ModelId=3C9A5AA10138
	inline virtual void     SetModel(Model* apModel);

    //##ModelId=3C8A47D6033C
	virtual bool            Execute();

	//##ModelId=3C8A47D6037A
	virtual bool            Unexecute();

private:
	//##ModelId=3C9B9084010B
    Model*                  m_pModel;

	//##ModelId=3CA0DD8401CF
    long                    m_ObjectId;

	//##ModelId=3CA0DD8401CC
    QRect*                  m_pProperties;

	//##ModelId=3CA0DD8401C7
    QString*                m_pValue;
};

//##ModelId=3C9A5AA10138
inline
void
CreateEditCommand::SetModel(Model* apModel) {
    m_pModel = apModel;
}

#endif /* _INC_CREATEEDITCOMMAND_3C86695800BB_INCLUDED */

