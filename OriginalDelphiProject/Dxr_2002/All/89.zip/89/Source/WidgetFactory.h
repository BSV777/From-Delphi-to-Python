// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_WIDGETFACTORY_3C8931B8037A_INCLUDED
#define _INC_WIDGETFACTORY_3C8931B8037A_INCLUDED

class Widget;

/**
 * ������ ����� ��������� ��������� ����������� 
 * ������� ��������.
 *
 * @see http://www.vico.org/pages/PatronsDisseny/Pattern%20Abstract%20Factory/index.html
 *
 * @version 0.1.0 form 03/14/2002
 * 
 * @author Eugene Gusev
 */
//##ModelId=3C8931B8037A
class WidgetFactory {
public:
    /**
     * ����������.
     */
	//##ModelId=3C8FBA8900FA
    virtual                 ~WidgetFactory() {};

	//##ModelId=3C89E13C01E4
	virtual Widget*         CreateButton() = 0;

	//##ModelId=3C89E151008C
	virtual Widget*         CreateLabel() = 0;

	//##ModelId=3C89E161000F
	virtual Widget*         CreateTextEdit() = 0;

	//##ModelId=3C8FBA8900EA
    virtual Widget*         CreateRootWidget() = 0;

protected:
	//##ModelId=3C8A338F0187
	virtual Widget*         CreateMarker() = 0;

	//##ModelId=3C8A338F0167
	virtual Widget*         CreateMouseLabel() = 0;

    //##ModelId=3C8A338F0186
	virtual Widget*         CreateSensitivePoint(SensitivePointPosition aPosition) = 0;
};

#endif /* _INC_WIDGETFACTORY_3C8931B8037A_INCLUDED */

