#ifndef PROPERTYWINDOW_H
#define PROPERTYWINDOW_H
#include "propertywindow.h"

class PropertyWindow : public PropertyWindowBase { 
    Q_OBJECT

public:
    PropertyWindow( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~PropertyWindow();

};

#endif // PROPERTYWINDOW_H
