// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_CHANGEPARAMSCOMMAND_3C8669CD031C_INCLUDED
#define _INC_CHANGEPARAMSCOMMAND_3C8669CD031C_INCLUDED

#include "Command.h"

//##ModelId=3C8669CD031C
class ChangeParamsCommand 
: public Command
{
};

#endif /* _INC_CHANGEPARAMSCOMMAND_3C8669CD031C_INCLUDED */

