// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "SaverManager.h"

#include "AbstractSaver.h"
#include "DataSaver.h"


//##ModelId=3C8BDA6D03D8
AbstractSaver*
SaverManager::GetSaver() {
	return new DataSaver();
}


