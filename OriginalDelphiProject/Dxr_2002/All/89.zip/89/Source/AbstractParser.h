// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_ABSTRACTPARSER_3CA5737001D4_INCLUDED
#define _INC_ABSTRACTPARSER_3CA5737001D4_INCLUDED

#include <qdom.h> 

//##ModelId=3CA5737001D4
class AbstractParser {
public:
	//##ModelId=3CA574950138
	inline virtual          ~AbstractParser();

	//##ModelId=3CA5744901A5
	virtual QDomDocument*   Parse(const char* apcSource) = 0;
};

//##ModelId=3CA574950138
inline 
AbstractParser::~AbstractParser() {
}

#endif /* _INC_ABSTRACTPARSER_3CA5737001D4_INCLUDED */
