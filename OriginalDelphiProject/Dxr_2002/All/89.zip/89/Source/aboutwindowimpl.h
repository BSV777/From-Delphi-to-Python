#ifndef ABOUTWINDOW_H
#define ABOUTWINDOW_H
#include "aboutwindow.h"

//##ModelId=3C8BD4EB0242
class AboutWindow : public AboutWindowBase { 
    Q_OBJECT

public:
                            AboutWindow(QWidget* parent = 0,
                                        const char* name = 0,
                                        bool modal = FALSE,
                                        WFlags fl = 0);
	//##ModelId=3C8BD4EB0244
                            ~AboutWindow();
};

#endif // ABOUTWINDOW_H
