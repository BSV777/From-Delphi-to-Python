#include "stdafx.h"
#include "AppMainWindow.h"

#include <qpopupmenu.h>
#include <qcombobox.h> 
#include <qtoolbar.h>
#include <qtoolbutton.h>
#include <qscrollview.h>

#include "controller.h"

#include "Widget.h"
#include "Model.h"
#include "propertywindow.h"

void
AppMainWindow::ToggleStretchDocument() {
    SetStretchDocument(!GetStretchStatus());
}

void
AppMainWindow::SetStretchDocument(bool aIsSretching) {
    m_StretchingDocument = aIsSretching;
    Model*      model = NULL;
    Widget*     root = NULL;
    QString     document_mode;

    if (m_pStretchButton != NULL) {
        m_pStretchButton->setOn(m_StretchingDocument);
    }

    if (m_pModelController != NULL) {
        model = m_pModelController->GetModel();
    }

    if (model != NULL) {
        root = model->GetWidgetById(ROOT_WIDGET_ID);
    }

    if (root != NULL) {
        document_mode = m_StretchingDocument? STRETCH_DOCUMENT
                                             :NORMAL_DOCUMENT;
        root->SetValue(&document_mode);
    }
}

void
AppMainWindow::ToggleCreateLabel() {
    SetCreateLabel(!GetCreateLabel());
}

void
AppMainWindow::SetCreateLabel(bool aNewState) {
    m_CreateLabel = aNewState;
    if (m_pModelViewport == NULL) {
        m_CreateLabel = false;
    }
    m_pCreateLabelButton->setOn(m_CreateLabel);
    if (m_pModelController != NULL) {
        m_pModelController->SetCreateLabelMode(m_CreateLabel);
    }
    if (m_CreateLabel) {
        m_CreateTextEdit = false;
        m_CreateButton = false;
        m_pCreateTextEditButton->setOn(false);
        m_pCreateButtonButton->setOn(false);
    }
}

void
AppMainWindow::ToggleCreateTextEdit() {
    SetCreateTextEdit(!GetCreateTextEdit());
}

void
AppMainWindow::SetCreateTextEdit(bool aNewState) {
    m_CreateTextEdit = aNewState;
    if (m_pModelViewport == NULL) {
        m_CreateTextEdit = false;
    }
    m_pCreateTextEditButton->setOn(m_CreateTextEdit);
    if (m_pModelController != NULL) {
        m_pModelController->SetCreateTextEditMode(m_CreateTextEdit);
    }
    if (m_CreateTextEdit) {
        m_CreateLabel = false;
        m_CreateButton = false;
        m_pCreateLabelButton->setOn(false);
        m_pCreateButtonButton->setOn(false);
    }
}

void
AppMainWindow::ToggleCreateButton() {
    SetCreateButton(!GetCreateButton());
}

void
AppMainWindow::SetCreateButton(bool aNewState) {
    m_CreateButton = aNewState;
    if (m_pModelViewport == NULL) {
        m_CreateButton = false;
    }
    m_pCreateButtonButton->setOn(m_CreateButton);
    if (m_pModelController != NULL) {
        m_pModelController->SetCreateButtonMode(m_CreateButton);
    }
    if (m_CreateButton) {
        m_CreateLabel = false;
        m_CreateTextEdit = false;
        m_pCreateLabelButton->setOn(false);
        m_pCreateTextEditButton->setOn(false);
    }
}

void
AppMainWindow::ToggleShowGrid() {
    SetShowGridState(!GetShowGridState());
}

void
AppMainWindow::SetShowGridState(bool aNewState) {
    m_ShowGrid = aNewState;
    if (m_pModelViewport == NULL) {
        m_ShowGrid = false;
    }
    m_pOptions->setItemChecked(m_ShowGridMenuId, m_ShowGrid);
    m_pShowGridButton->setOn(m_ShowGrid);
    if (m_pModelViewport != NULL) {
        m_pModelViewport->ShowGrid(m_ShowGrid);
        m_pModelViewport->Notify();
    }
}

void
AppMainWindow::ToggleSnapToGrid() {
    SetSnapToGridState(!GetSnapToGridState());
}

void
AppMainWindow::SetSnapToGridState(bool aNewState) {
    m_SnapToGrid = aNewState;
    if (m_pModelViewport == NULL) {
        m_SnapToGrid = false;
    }
    m_pOptions->setItemChecked(m_SnapToGridMenuId, m_SnapToGrid);
    m_pSnapToGridButton->setOn(m_SnapToGrid);
    if (m_pModelController != NULL) {
        m_pModelController->SnapToGrid(m_SnapToGrid);
    }
}

void
AppMainWindow::CreateView(int aWidth, int aHeight) {
    if ((m_pModelViewport == NULL) &&
        (m_pModelController != NULL)) {

        Widget*     root = NULL;
        Model*      model = NULL;
        QRect       prop;

        int width   = -1;
        int height  = -1;

        if ((aWidth  > 0) &&
            (aHeight > 0)) {
            width = aWidth;
            height = aHeight;
        }

        m_pModelViewport = new SimpleView(this, 0, 0);
//        m_pModelViewport->SetCascadeView(m_pPropertyWindow);
        m_pModelViewport->SetController(m_pModelController);
        m_pModelController->SetView(m_pModelViewport);
        m_pModelController->CreateNew();

        model = m_pModelController->GetModel();
        if (model == NULL) {
            return;
        }

//        m_pPropertyWindow->SetServicedModel(model);
        root = model->GetWidgetById(ROOT_WIDGET_ID);
        prop = *root->GetPosition();

        if ((width <= 0) || (height <= 0)) {
            width = prop.width();
            height = prop.height();
        }
        else {
            prop.setWidth(width);
            prop.setHeight(height);
            root->SetPosition(&prop);
        }

        m_pModelViewport->SetFrameSize(width, height);


        m_pCentralView->addChild(m_pModelViewport);
        m_pCentralView->setResizePolicy(QScrollView::AutoOneFit);
        m_pCentralView->show();
    }
}

void
AppMainWindow::CloseView() {
    m_pCentralView->hide();
    if (m_pModelViewport != NULL) {
        if (m_pModelController != NULL) {
            m_pModelController->SetView(NULL);
        }
        m_pCentralView->removeChild(m_pModelViewport);
        delete m_pModelViewport;
        m_pModelViewport = NULL;
    }
}

void
AppMainWindow::ChangeGridSize(const QString& arNewGridSize) {
    int     new_grid_size = 0;
    bool    success = false;

    new_grid_size = arNewGridSize.toInt(&success, 10);

    if (success) {
        if (m_pModelController != NULL) {
            m_pModelController->SetGridSize(new_grid_size);
        }
        if (m_pModelViewport != NULL) {
            m_pModelViewport->Notify();
        }
    }
    else {
        SetShowGridState(false);
        if (m_pGridSizeComboBox->count() > 0) {
            m_pGridSizeComboBox->setCurrentItem(0);
        }
    }
}
