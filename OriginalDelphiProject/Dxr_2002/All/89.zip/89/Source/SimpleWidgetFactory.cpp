// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "SimpleWidgetFactory.h"
#include "ButtonWidget.h"
#include "LabelWidget.h"
#include "MarkerWidget.h"
#include "MouseLabelWidget.h"
#include "SensitivePointWidget.h"
#include "TextEditWidget.h"
#include "RootWidget.h"

#include "SensitivePointOrientation.h"
#include "EastSensitivePoint.h"
#include "NorthEastSensitivePoint.h"
#include "NorthSensitivePoint.h"
#include "NorthWestSensitivePoint.h"
#include "SouthEastSensitivePoint.h"
#include "SouthSensitivePoint.h"
#include "SouthWestSensitivePoint.h"
#include "WestSensitivePoint.h"
#include "CentralSensitivePoint.h"

//##ModelId=3C89E24403C8
Widget* 
SimpleWidgetFactory::CreateButton() {
	return new ButtonWidget();
}

//##ModelId=3C89E24403D8
Widget*
SimpleWidgetFactory::CreateLabel() {
	return new LabelWidget();
}   

//##ModelId=3C89E245000F
Widget*
SimpleWidgetFactory::CreateTextEdit() {
	return new TextEditWidget();
}

//##ModelId=3C89E245001F
Widget* 
SimpleWidgetFactory::CreateMouseLabel() {
	return new MouseLabelWidget();
}

//##ModelId=3C89E245003E
Widget* 
SimpleWidgetFactory::CreateSensitivePoint(SensitivePointPosition aPosition) {
    SensitivePointWidget* result = NULL;
    result = new SensitivePointWidget();
    switch (aPosition) {
    case NORTH:
        result->SetOrientation(new NorthSensitivePoint());
        break;
    case NORTHEAST:
        result->SetOrientation(new NorthEastSensitivePoint());
        break;
    case EAST:
        result->SetOrientation(new EastSensitivePoint());
        break;
    case SOUTHEAST:
        result->SetOrientation(new SouthEastSensitivePoint());
        break;
    case SOUTH:
        result->SetOrientation(new SouthSensitivePoint());
        break;
    case SOUTHWEST:
        result->SetOrientation(new SouthWestSensitivePoint());
        break;
    case WEST:
        result->SetOrientation(new WestSensitivePoint());
        break;
    case NORTHWEST:
        result->SetOrientation(new NorthWestSensitivePoint());
        break;
    }
	return result;
}

//##ModelId=3C89E245005D
Widget*
SimpleWidgetFactory::CreateMarker() {
    MarkerWidget*   p_marker = NULL;
    p_marker = new MarkerWidget();
    p_marker->SetOrientation(new CentralSensitivePoint());
	return p_marker;
}

//##ModelId=3C8FBA860128
Widget*
SimpleWidgetFactory::CreateRootWidget() {
    Widget*     root = NULL;
    Widget*     marker = NULL;
    Widget*     child = NULL;

    root = new RootWidget();
    marker = CreateMarker();
    root->AppendChild(marker);

    child = CreateSensitivePoint(NORTH);
    marker->AppendChild(child);

    child = CreateSensitivePoint(NORTHEAST);
    marker->AppendChild(child);

    child = CreateSensitivePoint(EAST);
    marker->AppendChild(child);

    child = CreateSensitivePoint(SOUTHEAST);
    marker->AppendChild(child);

    child = CreateSensitivePoint(SOUTH);
    marker->AppendChild(child);

    child = CreateSensitivePoint(SOUTHWEST);
    marker->AppendChild(child);

    child = CreateSensitivePoint(WEST);
    marker->AppendChild(child);

    child = CreateSensitivePoint(NORTHWEST);
    marker->AppendChild(child);

    child = CreateMouseLabel();
    root->AppendChild(child);

	return root;
}
