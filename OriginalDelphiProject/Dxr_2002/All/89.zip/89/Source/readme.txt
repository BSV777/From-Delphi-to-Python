========================================================================
        Qt Application "Competition"
========================================================================


This Developer Studio Project file has been created by the QMsDev
plugin and is a basic implementation of a Qt application based on
a Multi Document interface (MDI).

The project contains the following files in which you should add the
code for your project:

main.cpp
    The starting point for your application. Add startup routines, e.g.
    commandline processing here.

competitionmainwindow.h
    A basic declaration of your application window. Add declarations of
    methods here.
competitionmainwindow.cpp
    A basic implementation of the methods declared in
    competitionmainwindow.h. Add implementation code here.

The following files will be generated during the Qt specific build
steps, and you shouldn't modify them:
