/****************************************************************************
** Form interface generated from reading ui file '.\newdialog.ui'
**
** Created: Sun Mar 10 23:32:00 2002
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef NEWDIALOGBASE_H
#define NEWDIALOGBASE_H

#include <qvariant.h>
#include <qdialog.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QLabel;
class QPushButton;

class NewDialogBase : public QDialog
{ 
    Q_OBJECT

public:
    NewDialogBase( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~NewDialogBase();

    QPushButton* buttonHelp;
    QPushButton* buttonApply;
    QPushButton* buttonOk;
    QPushButton* buttonCancel;
    QLabel* TextLabel1;
    QLabel* PixmapLabel1;

protected:
    QHBoxLayout* Layout1;
};

#endif // NEWDIALOGBASE_H
