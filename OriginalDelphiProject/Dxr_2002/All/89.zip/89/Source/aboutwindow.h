/****************************************************************************
** Form interface generated from reading ui file '.\aboutwindow.ui'
**
** Created: Sun Mar 10 19:08:52 2002
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef ABOUTWINDOWBASE_H
#define ABOUTWINDOWBASE_H

#include <qvariant.h>
#include <qdialog.h>
#include <QMovie.h>

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QLabel;

//##ModelId=3C8BD4E80138
class AboutWindowBase : public QDialog { 
    Q_OBJECT

public:
                            AboutWindowBase(QWidget* parent = 0,
                                            const char* name = 0,
                                            bool modal = FALSE,
                                            WFlags fl = 0 );
	//##ModelId=3C8BD4E80169
                            ~AboutWindowBase();

	//##ModelId=3C8BD4E80166
    QLabel*                 m_pFace;
	//##ModelId=3C8BD4E80161
    QLabel*                 m_pDescription;
	//##ModelId=3C8BD4E8015C
    QLabel*                 m_pName;
	//##ModelId=3C8BD4E80157
    QLabel*                 m_pTrollTech;
	//##ModelId=3C8BD4E8014A
    QMovie                  m_Movie;

};

#endif // ABOUTWINDOWBASE_H
