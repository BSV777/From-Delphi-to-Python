// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_ROOTWIDGET_3C89F4F40251_INCLUDED
#define _INC_ROOTWIDGET_3C89F4F40251_INCLUDED

#include "Widget.h"

class View;
class Widget;
class Command;
class CommandFactory;

/**
 * ������ ����� ��������� �������� ������� � 
 * ��������� ������ � ������ ��� ���������.
 *
 * @version 0.1.0 form 03/14/2002
 * 
 * @author Eugene Gusev
 */
//##ModelId=3C89F4F40251
class RootWidget : public Widget {
public:
    //##ModelId=3C89FC5D0157
                            RootWidget();

    /**
     * ����������.
     */
    //##ModelId=3C89FC5D0167
    virtual                 ~RootWidget();

	/**
	 * ����� ������� �� �������������� ������� � �������� �������.
	 * (������� ������ � ����).
	 *
	 * @param aId - ������������� �������� �������.
	 *
	 * @return ���� ������ � ��������� ��������������� ������, �� 
	 * ��������� �� ����, ����� NULL.
     */
	//##ModelId=3C8D333D01C5
	virtual Widget*         FindById(long aId);

	//##ModelId=3CA727CA007D
	virtual const Widget*   FindById(long aId) const;

	//##ModelId=3C93CA320222
	virtual Widget*         GetOwner(const QPoint* apPosition);

    //##ModelId=3C89F61A03D8
    virtual bool            Draw(View*& arpDestinationView) const;

    //##ModelId=3C89F61B000F
    inline virtual int      GetType() const;

    //##ModelId=3C89F61B001F
    virtual const QRect*    GetPosition() const;

    //##ModelId=3C89F61B0020
    virtual const QString*  GetValue() const;

    //##ModelId=3C89F61B002E
    virtual void            SetPosition(const QRect* apcPosition);

    //##ModelId=3C89F61B005D
    virtual Command*        Commit();
    
    //##ModelId=3C89F61B006D
    virtual void            Cancel();

    //##ModelId=3C89F61B007D
    inline virtual void     SetId(long aId);

    //##ModelId=3C89F61B009C
    virtual void            SetValue(const QString* apcValue);

	//##ModelId=3C9317DB03B9
    inline void             SetParent(Widget* apParent);

	//##ModelId=3C934D18033C
    inline Widget*          GetParent() const;

	//##ModelId=3C9B907F01A6
    inline Widget*          GetRoot();

	//##ModelId=3CA727CA006D
    inline const Widget*    GetRoot() const;

	//##ModelId=3C8A23CE031C
    inline void             AppendChild(Widget* apNewChild);

	//##ModelId=3C8A23CE02EE
    inline void             RemoveChild(Widget* apOldChild);

	//##ModelId=3C8A23CE02BF
    inline bool             IsChild(const Widget* apPossibleChild) const;

	//##ModelId=3C9317DB0399
    inline bool             IsParent(const Widget* apPossibleParent) const;

	//##ModelId=3C9B907F0196
    virtual bool            IsValidWidget(const Widget* apExamineWidget) const;

	//##ModelId=3CA38C9D01C5
    virtual long            GetHash() const;

protected:

	//##ModelId=3C8A23CE0290
    int                     FindChild(Widget* apChild);
	
    //##ModelId=3C8D3BDA02EE
    Widget*                 LookAtTheChildren(long aId);

	//##ModelId=3CA727CA004E
    const Widget*           LookAtTheChildren(long aId) const;

	//##ModelId=3C934D18030E
    inline void             AdvAppendChild(Widget* apOldChild);

    //##ModelId=3C934D18031D
    inline void             AdvRemoveChild(Widget* apOldChild);
	
    //##ModelId=3C934D1802FD
    inline void             AdvSetParent(Widget* apParent);

protected:
	//##ModelId=3C8A23CE0282
    WidgetVector            m_Children;

	//##ModelId=3C9317DB036B
    QString*                m_pValue;

private:
	//##ModelId=3CA0DD8100FC
    mutable QRect           m_Size;

	//##ModelId=3CA32E9F0282
    CommandFactory*         m_pFactory;
};

//##ModelId=3C89F61B007D
inline 
void 
RootWidget::SetId(long aId) {
}

//##ModelId=3C89F61B000F
inline 
int 
RootWidget::GetType() const {
    return ROOT_WIDGET;
}

//##ModelId=3C9317DB03B9
inline
void
RootWidget::SetParent(Widget* apParent) {
    return;
}

//##ModelId=3C934D18033C
inline
Widget*
RootWidget::GetParent() const {
    return NULL;
}

//##ModelId=3C9B907F01A6
inline 
Widget*
RootWidget::GetRoot() {
    return this;
}

inline
const Widget*
RootWidget::GetRoot() const {
    return this;
}

//##ModelId=3C934D1802FD
inline
void
RootWidget::AdvSetParent(Widget* apParent) {
}

//##ModelId=3C8A23CE031C
inline
void
RootWidget::AppendChild(Widget* apNewChild) {
    if (apNewChild == NULL) {
        return;
    }
    Widget* parent = NULL;
    parent = apNewChild->GetParent();
    if (parent != NULL) {
        AdvanceRemoveChildFrom(parent, apNewChild);
    }
    AdvanceSetParentTo(apNewChild, this);

    parent = apNewChild->GetParent();
    if (parent != NULL) {
        AdvanceAppendChildTo(parent, apNewChild);
    }
}

//##ModelId=3C8A23CE02EE
inline
void
RootWidget::RemoveChild(Widget* apOldChild) {
    if (apOldChild == NULL) {
        return;
    }

    if (apOldChild->IsParent(this)) {
        AdvanceSetParentTo(apOldChild, NULL);
    }
    AdvRemoveChild(apOldChild);
}

//##ModelId=3C934D18031D
inline
void
RootWidget::AdvRemoveChild(Widget* apOldChild) {
    int index = FindChild(apOldChild);
    if (index >= 0) {
        m_Children.erase(m_Children.begin() + index);
    }
}

//##ModelId=3C934D18030E
inline
void
RootWidget::AdvAppendChild(Widget* apOldChild) {
    m_Children.push_back(apOldChild);
}

//##ModelId=3C9317DB0399
inline
bool
RootWidget::IsParent(const Widget* apPossibleParent) const {
    return false;
}

//##ModelId=3C8A23CE02BF
inline
bool
RootWidget::IsChild(const Widget* apPossibleChild) const {
    if (apPossibleChild != NULL) {
        return apPossibleChild->IsParent(this);
    }
    else {
        return false;
    }
}

#endif /* _INC_ROOTWIDGET_3C89F4F40251_INCLUDED */
