// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "MarkerWidget.h"
#include "View.h"
#include "Widget.h"

#include "SimpleCommandFactory.h"
#include "Command.h"

#include "SensitivePointOrientation.h"

//##ModelId=3C89FC42037A
MarkerWidget::MarkerWidget() {
    Widget::SetId(MARKER_WIDGET_ID);
    m_pChild = NULL;
    m_pFactory = new SimpleCommandFactory();
    m_pOrientation = NULL;
}

//##ModelId=3C89FC42038A
MarkerWidget::~MarkerWidget() {
    WidgetIterator      iter;
    ConstWidgetIterator end;

    iter = m_Children.begin();
    end = m_Children.end();

    for (; iter != end; iter++) {
        delete (*iter);
    }

    delete m_pChild;
    m_pChild = NULL;

    delete m_pFactory;
    m_pFactory = NULL;

    delete m_pOrientation;
    m_pOrientation = NULL;
}

//##ModelId=3C89F6520203
bool 
MarkerWidget::Draw(View*& arpDestinationView) const {
    bool    result = true;
    bool    res = false;

    if (m_pChild == NULL) {
        return true;
    }

    res = m_pChild->Draw(arpDestinationView);
    result = result && res;

    res = arpDestinationView->DrawMarker(this);
    result = result && res;

    ConstWidgetIterator iter;
    ConstWidgetIterator end;

    iter = m_Children.begin();
    end  = m_Children.end();

    for (; iter != end; iter++) {
        res = (*iter)->Draw(arpDestinationView);
        result = result && res;
    }
    return result;
}

//##ModelId=3C89F6520251
const QString* 
MarkerWidget::GetValue() const {
    const QString*  value = NULL;
    if (m_pChild != NULL) {
        value = m_pChild->GetValue();
    }
    return value;
}

//##ModelId=3C89F65202DE
void 
MarkerWidget::SetValue(const QString* apcValue) {
    if (m_pChild != NULL) {
        m_pChild->SetValue(apcValue);
    }
}

//##ModelId=3C89F6520242
const QRect* 
MarkerWidget::GetPosition() const {
    return &m_Properties;
}

//##ModelId=3C89F6520261
void 
MarkerWidget::SetPosition(const QRect* apcPosition) {
    if (m_pChild != NULL) {
        m_pChild->SetPosition(apcPosition);
        Update();
    }
}

void
MarkerWidget::SetOrientation(SensitivePointOrientation* apOrientation) {
    delete m_pOrientation;
    m_pOrientation = apOrientation;
}

//##ModelId=3C89F6520290
Command* 
MarkerWidget::Commit() {
    Command*    command = NULL;

    if (m_pChild == NULL) {
        return command;
    }

    command = m_pFactory->CreateChangePropertiesCommand();

    if (command == NULL) {
        return command;
    }

    command->SetNewProperties(m_pChild->GetPosition());
    command->SetNewValue(m_pChild->GetValue());
    command->SetOldProperties(&m_OriginalProp);
    command->SetOldValue(&m_OriginalValue);
    command->SetObject(m_pChild);


    return command;
}

//##ModelId=3C89F652029F
void 
MarkerWidget::Cancel() {
    m_pChild->SetPosition(&m_OriginalProp);
    m_pChild->SetValue(&m_OriginalValue);
}

//##ModelId=3C8D33A201F4
Widget* 
MarkerWidget::FindById(long aId) {
    /* Check mine */
    if (aId == GetId()) {
        return this;
    }
    else {
        /* Look at the children */
        return LookAtTheChildren(aId);
    }
}

const Widget* 
MarkerWidget::FindById(long aId) const {
    /* Check mine */
    if (aId == GetId()) {
        return this;
    }
    else {
        /* Look at the children */
        return LookAtTheChildren(aId);
    }
}

//##ModelId=3C939BA90062
void
MarkerWidget::Update() {
    m_Properties.setRect(0, 0, 0, 0);

    const QRect*  posit = NULL;
    if (m_pChild != NULL) {
        posit = m_pChild->GetPosition();
    }
    if (posit != NULL) {
        m_Properties = m_pOrientation->CalculatePosition(posit);
    }

    WidgetIterator      iter;
    ConstWidgetIterator end;
    Widget*             result = NULL;

    iter = m_Children.begin();
    end  = m_Children.end();
    for (; iter != end; iter++) {
        result = (*iter);
        if (result->GetType() == SENSITIVEPOINT_WIDGET) {
            result->SetPosition(posit);
        }
    }
}

//##ModelId=3C93AD160203
void
MarkerWidget::AppendChild(Widget* apNewChild) {
    m_pResizePoint = NULL;

    if (apNewChild == NULL) {
        if ((m_pChild != NULL) &&
            (m_pParent != NULL)){
            AdvanceSetParentTo(m_pChild, m_pParent);
            AdvanceAppendChildTo(m_pParent, m_pChild);
        }
        m_pChild = apNewChild;
        Update();
        return;
    }

    if (apNewChild->GetType() == SENSITIVEPOINT_WIDGET) {
        if (FindChild(apNewChild) < 0) {
            // ��������� ����� �����
            AdvanceSetParentTo(apNewChild, this);
            AdvAppendChild(apNewChild);
        }
        else {
            // ������ ����� ��� ������������ � ������ �����
            // �.�. ������ ����� ������ ���� �������� �� �����
            // ���� �������������.
            m_pResizePoint = apNewChild;
        }
    }
    else {
        if ((m_pChild != NULL) &&
            (m_pParent != NULL)){
            AdvanceSetParentTo(m_pChild, m_pParent);
            AdvanceAppendChildTo(m_pParent, m_pChild);
        }
        m_pChild = apNewChild;
        Widget* parent = NULL;
        parent = m_pChild->GetParent();
        if (parent != NULL) {
            AdvanceRemoveChildFrom(parent, m_pChild);
        }
        AdvanceSetParentTo(m_pChild, this);
        Update();
    }
}

//##ModelId=3C8D3BDF033C
Widget* 
MarkerWidget::LookAtTheChildren(long aId) {
    WidgetIterator      iter;
    ConstWidgetIterator end;
    Widget*             result = NULL;

    if (m_pChild != NULL) {
        result = m_pChild->FindById(aId);
        if (result != NULL) {
            return result;
        }
    }

    iter = m_Children.begin();
    end  = m_Children.end();

    for (; iter != end; iter++) {
        result = (*iter)->FindById(aId);
        if (result != NULL) {
            break;
        }
    }
    return result;
}

const Widget* 
MarkerWidget::LookAtTheChildren(long aId) const {
    ConstWidgetIterator iter;
    ConstWidgetIterator end;
    Widget*             result = NULL;

    if (m_pChild != NULL) {
        result = m_pChild->FindById(aId);
        if (result != NULL) {
            return result;
        }
    }

    iter = m_Children.begin();
    end  = m_Children.end();

    for (; iter != end; iter++) {
        result = (*iter)->FindById(aId);
        if (result != NULL) {
            break;
        }
    }
    return result;
}

//##ModelId=3C93AD1601A5
int
MarkerWidget::FindChild(Widget* apChild) {
    WidgetIterator      iter;
    ConstWidgetIterator end;
    int                 index = -1;

    iter = m_Children.begin();
    end  = m_Children.end();

    for (index = 0; iter != end; index++, iter++) {
        if ((*iter) == apChild) {
            return index;
        }
    }
    return -1;
}

//##ModelId=3C93CA0C0177
Widget*
MarkerWidget::GetOwner(const QPoint* apPosition) {
    WidgetIterator      iter;
    ConstWidgetIterator end;
    Widget*             result = NULL;

    iter = m_Children.begin();
    end  = m_Children.end();

    for (; iter != end; iter++) {
        result = (*iter)->GetOwner(apPosition);
        if (result != NULL) {
            break;
        }
    }

    if (result == NULL) {
        if (m_pChild != NULL) {
            result = m_pChild->GetOwner(apPosition);
        }
    }

    return result;
}

//##ModelId=3C9B908701F5
void
MarkerWidget::MoveFrom(const QPoint* apDeparturePoint) {
    if (m_pChild == NULL) {
        return;
    }
    if (apDeparturePoint == NULL) {
        return;
    }

    m_OriginalProp = *m_pChild->GetPosition();
    m_OriginalValue = *m_pChild->GetValue();

    if (m_pResizePoint == NULL) {
        m_pOrientation->MoveFrom(apDeparturePoint);
//        m_DeparturePoint = *apDeparturePoint;
    }
    else {
        m_pResizePoint->MoveFrom(apDeparturePoint);
    }

}

//##ModelId=3C9B908701E5
void
MarkerWidget::MoveTo(const QPoint* apDestinationPoint, int aGridSize) {
    if (m_pChild == NULL) {
        return;
    }

    if (apDestinationPoint == NULL) {
        return;
    }

    if (m_pResizePoint == NULL) {
        m_pOrientation->MoveTo(m_pChild, 
                               apDestinationPoint, 
                               aGridSize);
    }
    else {
        m_pResizePoint->MoveTo(apDestinationPoint, aGridSize);
    }

    Update();
}

//##ModelId=3C9B908701D7
bool
MarkerWidget::IsValidWidget(const Widget* apExamineWidget) const {
    if (m_pChild != NULL) {
        return m_pChild->IsValidWidget(apExamineWidget);
    }
    else {
        return true;
    }
}

long
MarkerWidget::GetHash() const {
    if (m_pChild != NULL) {
        return m_pChild->GetHash();
    }
    else {
        return 0x00000000;
    }
}
