// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_ABSTRACTEXPORTER_3C83DD070399_INCLUDED
#define _INC_ABSTRACTEXPORTER_3C83DD070399_INCLUDED
#include "Model.h"


#include "View.h"

//##ModelId=3C83DD070399
class AbstractExporter : public View {
public:
	//##ModelId=3CA6BAB7003E
	inline virtual          ~AbstractExporter();

	//##ModelId=3CA6BAD2032C
	virtual void            SetName(const QString* apcName) = 0;

	//##ModelId=3CA6BB54037A
	virtual bool            Finish() = 0;

	//##ModelId=3CA6BB890232
	virtual void            Initialize() = 0;

	//##ModelId=3CA6E35F006D
	virtual bool            ExportModel(const Model* apcModel) = 0;

};

//##ModelId=3CA6BAB7003E
inline 
AbstractExporter::~AbstractExporter() {
}


#endif /* _INC_ABSTRACTEXPORTER_3C83DD070399_INCLUDED */

