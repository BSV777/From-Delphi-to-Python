// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "LabelWidget.h"
#include "View.h"
#include "Widget.h"

//##ModelId=3C89FC4C0128
LabelWidget::LabelWidget() {
    SetId(GenerateId());
    m_Properties.setRect(0, 0, 0, 0);
    m_Value = "";
}

//##ModelId=3C89FC4C0138
LabelWidget::~LabelWidget() {
}

//##ModelId=3C89F63D005D
bool 
LabelWidget::Draw(View*& arpDestinationView) const {
    return arpDestinationView->DrawLabel(this);
}

//##ModelId=3C89F63D009C
const QRect* 
LabelWidget::GetPosition() const {
    return &m_Properties;
}

//##ModelId=3C89F63D00BB
void 
LabelWidget::SetPosition(const QRect* apcPosition) {
    if (apcPosition != NULL) {
        m_Properties = *apcPosition;
    }
    else {
        m_Properties.setRect(0, 0, 0, 0);
    }
}

//##ModelId=3C89F63D00AB
const QString* 
LabelWidget::GetValue() const {
    return &m_Value;
}

//##ModelId=3C89F63D0109
void 
LabelWidget::SetValue(const QString* apcValue) {
    if (apcValue != NULL) {
        m_Value = *apcValue;
        m_Value.truncate(255);
    }
    else {
        m_Value = "";
    }
}

//##ModelId=3C89F63D00EA
Command*
LabelWidget::Commit() {
    return NULL;
}

//##ModelId=3C89F63D00FA
void 
LabelWidget::Cancel() {
}

//##ModelId=3C8D332B00AB
Widget* 
LabelWidget::FindById(long aId) {
    /* Check mine */
    if (aId == GetId()) {
        return this;
    }
    else {
        /* Look at the children */
        return NULL;
    }
}

const Widget* 
LabelWidget::FindById(long aId) const {
    /* Check mine */
    if (aId == GetId()) {
        return this;
    }
    else {
        /* Look at the children */
        return NULL;
    }
}

//##ModelId=3C93CA1B029F
Widget* 
LabelWidget::GetOwner(const QPoint* apPosition) {
    if (apPosition != NULL) {
        if (m_Properties.contains(*apPosition)) {
            return this;
        }
    }
	return NULL;
}

//##ModelId=3C9B908500AB
bool
LabelWidget::IsValidWidget(const Widget* apExamineWidget) const {
    bool result = true;
    if (apExamineWidget == NULL) {
        return result;
    }
    if (apExamineWidget == this) {
        return result;
    }

    result = !m_Properties.intersects(*(apExamineWidget->GetPosition()));

    return result;
}

long
LabelWidget::GetHash() const {
    long                hash = 0x85a159b2;
    hash = hash + Widget::GetHash(&m_Value);
    hash = hash + Widget::GetHash(&m_Properties);
    return hash;
}
