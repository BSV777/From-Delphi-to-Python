#include "stdafx.h"
#include "SimpleView.h"

#include <qpainter.h>
#include <qrect.h>
#include <qstring.h>
#include <qpen.h>

#include "Controller.h"

//##ModelId=3C8D28610000
bool 
SimpleView::DrawLabel(const Widget* apLabel) {
/*
    if (m_pCascadView) {
        m_pCascadView->DrawLabel(apLabel);
    }
*/
    if ((m_pPainter == NULL) ||
        (apLabel == NULL)) {
        return false;
    }

    const QRect*   pparam = NULL;
    const QString* pvalue = NULL;
    
    pparam = apLabel->GetPosition();
    pvalue = apLabel->GetValue();

    if ((pparam == NULL) ||
        (pvalue == NULL)) {
        return false;
    }

    QRect           param = *pparam;
    QPoint          point;
    const QString&  value = *pvalue;
    QColor          color(lightGray);
    QBrush          brush(color);

    point = Translate(0, 0);
    param.moveBy(point.rx(), point.ry());
    m_pPainter->fillRect(param, brush);

    m_pPainter->drawText(param, Qt::AlignLeft, value);
    return true;
}

//##ModelId=3C8D2861005D
bool 
SimpleView::DrawButton(const Widget* apButton) {
/*
    if (m_pCascadView) {
        m_pCascadView->DrawButton(apButton);
    }
*/
    if ((m_pPainter == NULL) ||
        (apButton == NULL)) {
        return false;
    }

    const QRect*   pparam = NULL;
    const QString* pvalue = NULL;
    
    pparam = apButton->GetPosition();
    pvalue = apButton->GetValue();

    if ((pparam == NULL) ||
        (pvalue == NULL)) {
        return false;
    }

    QRect           param = *pparam;
    QPoint          point = param.topLeft();
    const QString&  value = *pvalue;
    QColor          top_left_color(lightGray);
    QColor          center_color(gray);
    QColor          right_bottom_color(darkGray);
    QBrush          brush(center_color);
    QPen            pen;

    pen = m_pPainter->pen();
    point = Translate(0, 0);
    param.moveBy(point.rx(), point.ry());

    m_pPainter->setPen(top_left_color);
    m_pPainter->drawLine(param.rLeft(),
                         param.rTop(),
                         param.rLeft(),
                         param.rBottom());
    m_pPainter->drawLine(param.rLeft(),
                         param.rTop(),
                         param.rRight(),
                         param.rTop());

    m_pPainter->setPen(right_bottom_color);
    m_pPainter->drawLine(param.rRight(),
                         param.rTop(),
                         param.rRight(),
                         param.rBottom());
    m_pPainter->drawLine(param.rLeft(),
                         param.rBottom(),
                         param.rRight(),
                         param.rBottom());

    param.rLeft()++;
    param.rTop()++;
    param.rRight()--;
    param.rBottom()--;

    m_pPainter->setPen(top_left_color);
    m_pPainter->drawLine(param.rLeft(),
                         param.rTop(),
                         param.rLeft(),
                         param.rBottom());
    m_pPainter->drawLine(param.rLeft(),
                         param.rTop(),
                         param.rRight(),
                         param.rTop());

    m_pPainter->setPen(right_bottom_color);
    m_pPainter->drawLine(param.rRight(),
                         param.rTop(),
                         param.rRight(),
                         param.rBottom());
    m_pPainter->drawLine(param.rLeft(),
                         param.rBottom(),
                         param.rRight(),
                         param.rBottom());

    param.rLeft()++;
    param.rTop()++;
    param.rRight()--;
    param.rBottom()--;

    m_pPainter->fillRect(param, brush);
    m_pPainter->setPen(pen);

    m_pPainter->drawText(param, Qt::AlignCenter, value);
    return true;
}

//##ModelId=3C8D286100CB
bool 
SimpleView::DrawTextEdit(const Widget* apTextEdit) {
/*
    if (m_pCascadView) {
        m_pCascadView->DrawTextEdit(apTextEdit);
    }
*/
    if ((m_pPainter == NULL) ||
        (apTextEdit == NULL)) {
        return false;
    }

    const QRect*   pparam = NULL;
    const QString* pvalue = NULL;
    
    pparam = apTextEdit->GetPosition();
    pvalue = apTextEdit->GetValue();

    if ((pparam == NULL) ||
        (pvalue == NULL)) {
        return false;
    }

    QRect           param = *pparam;
    QPoint          point;
    const QString&  value = *pvalue;
    QColor          color(white);
    QBrush          brush(color);

    point = Translate(0, 0);
    param.moveBy(point.rx(), point.ry());
    
    m_pPainter->drawRect(param);
    param.rLeft()++;
    param.rTop()++;
    param.rRight()--;
    param.rBottom()--;
    m_pPainter->fillRect(param, brush);

    m_pPainter->drawText(param, Qt::AlignLeft, value);
    return true;
}

//##ModelId=3C8D28610148
bool 
SimpleView::DrawMarker(const Widget* apMarker) {
/*
    if (m_pCascadView) {
        m_pCascadView->DrawMarker(apMarker);
    }
*/
    if ((m_pPainter == NULL) ||
        (apMarker == NULL)) {
        return false;
    }

    const QRect*   pparam = NULL;
    
    pparam = apMarker->GetPosition();

    if (pparam == NULL) {
        return false;
    }

    QRect   param = *pparam;
    QPoint  point;
    QColor  color(red);
    QPen    pen;

    pen = m_pPainter->pen();

    if (param.isNull()) {
        return false;
    }

    point = Translate(0, 0);
    param.moveBy(point.rx(), point.ry());
    param.rLeft()--;
    param.rTop()--;
    param.rRight()++;
    param.rBottom()++;

    m_pPainter->setPen(color);
    m_pPainter->drawRect(param);
    m_pPainter->setPen(pen);
    return true;
}

//##ModelId=3C8D286101B5
bool 
SimpleView::DrawRoot(const Widget* apRoot) {
/*
    if (m_pCascadView) {
        m_pCascadView->DrawRoot(apRoot);
    }
*/
    if ((m_pPainter == NULL) || 
        (apRoot == NULL)) {
        return false;
    }

    int width = -1;
    int height = -1;

    width  = apRoot->GetPosition()->width();
    height = apRoot->GetPosition()->height();

    if ((width > 0) && (height > 0)) {
        if ((width != m_FrameSize.width()) ||
            (height != m_FrameSize.height())) {
            m_FrameSize.rwidth() = width;
            m_FrameSize.rheight() = height;
            Recalculate();
        }
    }

    PrepareBorder(m_pPainter);
    if (m_ShowGrid == true) {
        PrepareGrid(m_pPainter);
    }

    return true;
}

//##ModelId=3C8D28610232
bool 
SimpleView::DrawMouseLabel(const Widget* apMouseLabel) {
/*
    if (m_pCascadView) {
        m_pCascadView->DrawMouseLabel(apMouseLabel);
    }
*/
    if ((m_pPainter == NULL) ||
        (apMouseLabel == NULL)) {
        return false;
    }

    const QRect*   pparam = NULL;
    const QString* pvalue = NULL;
    
    pparam = apMouseLabel->GetPosition();
    pvalue = apMouseLabel->GetValue();

    if ((pparam == NULL) ||
        (pvalue == NULL)) {
        return false;
    }

    QRect           param = *pparam;
    QRect           size;
    QPoint          point;
    const QString&  value = *pvalue;
    QColor          color(yellow);
    QBrush          brush(color);

    point = Translate(0, 0);
    param.moveBy(point.rx(), point.ry());

    param = m_pPainter->boundingRect(param, Qt::AlignCenter, value);
    param.rLeft() -= 2;
    param.rTop() -= 2;
    param.rRight() += 2;
    param.rBottom() += 2;
    m_pPainter->fillRect(param, brush);

    param.rLeft()--;
    param.rTop()--;
    param.rRight()++;
    param.rBottom()++;
    m_pPainter->drawRect(param);

    m_pPainter->drawText(param, Qt::AlignCenter, value);
    return true;
}

//##ModelId=3C8D2861029F
bool 
SimpleView::DrawSensitivePoint(const Widget* apSensitivePoint) {
/*
    if (m_pCascadView) {
        m_pCascadView->DrawSensitivePoint(apSensitivePoint);
    }
*/
    if ((m_pPainter == NULL) ||
        (apSensitivePoint == NULL)) {
        return false;
    }

    const QRect*   pparam = NULL;
    
    pparam = apSensitivePoint->GetPosition();

    if (pparam == NULL) {
        return false;
    }

    QRect   param = *pparam;
    QPoint  point = param.topLeft();
    QColor  color(darkBlue);
    QBrush  brush(color);
/*
    param.rLeft() = param.rRight();
    param.rTop() = param.rBottom();
    param.rLeft() -= 2;
    param.rTop() -= 2;
    param.rRight() += 2;
    param.rBottom() += 2;
*/
    point = Translate(0, 0);
    param.moveBy(point.rx(), point.ry());

    m_pPainter->fillRect(param, brush);
    return true;
}

//##ModelId=3C9317DF03A9
void
SimpleView::PrepareBackground(QPainter*& arpPainter) {
    PrepareBorder(arpPainter);
    if (m_ShowGrid == true) {
        PrepareGrid(arpPainter);
    }
}

//##ModelId=3C9317DF02FD
void
SimpleView::PrepareBorder(QPainter*& arpPainter) {
    if ((m_Offset.rx() == 0) && (m_Offset.ry() == 0)) {
        return;
    }
    else {
        QColor color(color0);
        QBrush brush(color);
        arpPainter->drawWinFocusRect(m_Offset.rx() - 1,
                                     m_Offset.ry() - 1,
                                     m_FrameSize.rwidth() + 2,
                                     m_FrameSize.rheight() + 2);
        arpPainter->fillRect(m_Offset.rx(),
                             m_Offset.ry(),
                             m_FrameSize.rwidth(),
                             m_FrameSize.rheight(),
                             brush);
    }
}

//##ModelId=3C9317DF0261
void
SimpleView::PrepareGrid(QPainter*& arpPainter) {
    register int    i = 0;
    register int    j = 0;
    int             grid_size = 0;

    if (m_pController != NULL) {
        grid_size = m_pController->GetGridSize();
    }

    if (grid_size <= 0) {
        return;
    }

    for (i = grid_size; (i < m_FrameSize.rwidth()) && (i < m_WidgetSize.rwidth()) ; i += grid_size) {
        for (j = grid_size; (j < m_FrameSize.rheight()) && (j < m_WidgetSize.rheight()); j += grid_size) {
            arpPainter->drawPoint(Translate(i, j));
        }
    }
}
