// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "CreateButtonCommand.h"

#include <qrect.h>
#include <qstring.h>

#include "Model.h"
#include "Widget.h"
#include "WidgetFactory.h"

//##ModelId=3C8A49020251
CreateButtonCommand::CreateButtonCommand() {
    m_ObjectId = -1;
    m_pProperties = NULL;
    m_pValue = NULL;
    m_pModel = NULL;
}

//##ModelId=3C8A49020261
CreateButtonCommand::~CreateButtonCommand() {
    delete m_pProperties;
    delete m_pValue;
    m_pProperties = NULL;
    m_pValue = NULL;

    m_pModel = NULL;
}

//##ModelId=3C8A47D0032C
bool 
CreateButtonCommand::Execute() {
    WidgetFactory*  p_widget_factory = NULL;
    Widget*         p_new_object = NULL;
    Widget*         p_root_widget = NULL;
    QString*        p_value = NULL;
    bool            result = false;

    p_value = new QString(DEFAULT_BUTTON_VALUE);

    do {
        if (m_pModel == NULL) {
            break;
        }

        if (m_pProperties == NULL) {
            break;
        }

        p_widget_factory = m_pModel->GetWidgetFactory();
        if (p_widget_factory == NULL) {
            break;
        }

        p_new_object = p_widget_factory->CreateButton();
        if (p_new_object == NULL) {
            break;
        }

        p_root_widget = m_pModel->GetWidgetById(ROOT_WIDGET_ID);
        if (p_root_widget == NULL) {
            break;
        }

        if (m_ObjectId > 100) {
            // ��������� ����� ���������� ��������.
            // ������ ������� ����������� Id ������� �������.
            p_new_object->SetId(m_ObjectId);
        }
        else {
            // �������� ����������� ������ ���.
            // ������������ Id ������ �������.
            m_ObjectId = p_new_object->GetId();
        }

        if (m_pValue != NULL) {
            *p_value = *m_pValue;
        }

        p_new_object->SetPosition(m_pProperties);
        p_new_object->SetValue(p_value);
        if (!p_root_widget->IsValidWidget(p_new_object)) {
            break;
        }

        result = true;
    } while (false);

    if (result) {
        p_root_widget->AppendChild(p_new_object);
    }
    else {
        delete p_new_object;
        p_new_object = NULL;
    }

    delete p_value;
    p_value = NULL;
	return result;
}

//##ModelId=3C8A47D0036B
bool 
CreateButtonCommand::Unexecute() {
    Widget*     p_old_widget = NULL;

    if (m_pModel == NULL) {
        return false;
    }

    if (m_ObjectId <= 100) {
        return false;
    }

    p_old_widget = m_pModel->GetWidgetById(m_ObjectId);
    if (p_old_widget == NULL) {
        return false;
    }

    p_old_widget->SetParent(NULL);

    delete p_old_widget;
    p_old_widget = NULL;

	return true;
}

//##ModelId=3C9B9105002E
void 
CreateButtonCommand::SetNewProperties(const QRect* apPosition) {
    delete m_pProperties;
    m_pProperties = NULL;

    if (apPosition == NULL) {
        return;
    }

    m_pProperties = new QRect();
    *m_pProperties = *apPosition;
    m_pProperties->setWidth(DEFAULT_CONTROL_WIDTH);
    m_pProperties->setHeight(DEFAULT_CONTROL_HEIGHT);
}

//##ModelId=3C9B9105005D
void CreateButtonCommand::SetNewValue(const QString* apValue) {
    delete m_pValue;
    m_pValue = NULL;

    if (apValue == NULL) {
        return;
    }

    m_pValue = new QString();
    *m_pValue = *apValue;
}

//##ModelId=3C9B9105008C
void
CreateButtonCommand::SetOldValue(const QString* apValue) {
}

//##ModelId=3C9B910500BB
void
CreateButtonCommand::SetOldProperties(const QRect* apPosition) {
}


