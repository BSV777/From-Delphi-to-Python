#include "propertywindow.h"

#include <qlabel.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

#include "appmainwindow.h"
#include "View.h"
#include "Controller.h"

#include "Widget.h"

/* 
 *  Constructs a PropertyWindow which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 */
PropertyWindow::PropertyWindow(QWidget* parent, 
                               const char* name,
                               WFlags fl) 
                               : QWidget(parent, 
                                         name,
                                         fl) {

    setName( "PropertyWindowBase" );
    resize( 348, 172 ); 
    setProperty( "maximumSize", QSize( 352, 172 ) );
    setProperty( "caption", tr( "PropertyWindow" ) );

    CaptionValue = new QLineEdit( this, "CaptionValue" );
    CaptionValue->setGeometry( QRect( 170, 20, 180, 30 ) ); 

    LeftValue = new QLineEdit( this, "LeftValue" );
    LeftValue->setGeometry( QRect( 170, 50, 180, 30 ) ); 

    TopValue = new QLineEdit( this, "TopValue" );
    TopValue->setGeometry( QRect( 170, 80, 180, 30 ) ); 

    WidthValue = new QLineEdit( this, "WidthValue" );
    WidthValue->setGeometry( QRect( 170, 110, 180, 30 ) ); 

    HeightValue = new QLineEdit( this, "HeightValue" );
    HeightValue->setGeometry( QRect( 170, 140, 180, 30 ) ); 

    Value = new QLabel( this, "Value" );
    Value->setGeometry( QRect( 170, 0, 180, 20 ) ); 
    QPalette pal;
    QColorGroup cg;
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 192, 192, 192) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 223, 223, 223) );
    cg.setColor( QColorGroup::Dark, QColor( 96, 96, 96) );
    cg.setColor( QColorGroup::Mid, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 179, 179, 179) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 192, 192, 192) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Dark, QColor( 96, 96, 96) );
    cg.setColor( QColorGroup::Mid, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 179, 179, 179) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 192, 192, 192) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Dark, QColor( 96, 96, 96) );
    cg.setColor( QColorGroup::Mid, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 179, 179, 179) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    pal.setDisabled( cg );
    Value->setProperty( "palette", pal );
    Value->setProperty( "text", tr( "Value" ) );
    Value->setProperty( "alignment", int( QLabel::AlignCenter ) );

    Property = new QLabel( this, "Property" );
    Property->setGeometry( QRect( 0, 0, 170, 20 ) ); 
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 192, 192, 192) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 223, 223, 223) );
    cg.setColor( QColorGroup::Dark, QColor( 96, 96, 96) );
    cg.setColor( QColorGroup::Mid, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 179, 179, 179) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 192, 192, 192) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Dark, QColor( 96, 96, 96) );
    cg.setColor( QColorGroup::Mid, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 179, 179, 179) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 192, 192, 192) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Dark, QColor( 96, 96, 96) );
    cg.setColor( QColorGroup::Mid, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 179, 179, 179) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    pal.setDisabled( cg );
    Property->setProperty( "palette", pal );
    Property->setProperty( "text", tr( "Property" ) );
    Property->setProperty( "alignment", int( QLabel::AlignCenter ) );

    CaptionText = new QLabel( this, "CaptionText" );
    CaptionText->setGeometry( QRect( 0, 20, 170, 30 ) ); 
    CaptionText->setProperty( "text", tr( "     Caption/Text" ) );

    Left = new QLabel( this, "Left" );
    Left->setGeometry( QRect( 0, 50, 170, 30 ) ); 
    Left->setProperty( "text", tr( "     Left" ) );

    Top = new QLabel( this, "Top" );
    Top->setGeometry( QRect( 0, 80, 170, 30 ) ); 
    Top->setProperty( "text", tr( "     Top" ) );

    Width = new QLabel( this, "Width" );
    Width->setGeometry( QRect( 0, 110, 170, 30 ) ); 
    Width->setProperty( "text", tr( "     Width" ) );

    Height = new QLabel( this, "Height" );
    Height->setGeometry( QRect( 0, 140, 170, 30 ) ); 
    Height->setProperty( "text", tr( "     Height" ) );
}

//##ModelId=3C8BD4EB029F
PropertyWindow::~PropertyWindow() {
}

//##ModelId=3CA767F00177
void 
PropertyWindow::Notify() {
    if (m_pModel != NULL) {
        m_pModel->Lock();
        repaint();
        m_pModel->UnLock();
    }
}

//##ModelId=3CA767F001F4
bool 
PropertyWindow::DrawLabel(const Widget* apLabel) {
    return true;
}

//##ModelId=3CA767F0030D
bool 
PropertyWindow::DrawButton(const Widget* apButton) {
    return true;
}

//##ModelId=3CA767F1002E
bool 
PropertyWindow::DrawTextEdit(const Widget* apTextEdit) {
    return true;
}

//##ModelId=3CA767F10157
bool 
PropertyWindow::DrawMarker(const Widget* apMarker) {
    if (apMarker == NULL) {
        CaptionValue->clear();
        LeftValue->clear();
        TopValue->clear();
        WidthValue->clear();
        HeightValue->clear();
        return false;
    }
    QString     str;
    CaptionValue->setText(*apMarker->GetValue());

    str.setNum(apMarker->GetPosition()->left());
    LeftValue->setText(str);

    str.setNum(apMarker->GetPosition()->top());
    TopValue->setText(str);

    str.setNum(apMarker->GetPosition()->width());
    WidthValue->setText(str);

    str.setNum(apMarker->GetPosition()->height());
    HeightValue->setText(str);
    return true;
}

//##ModelId=3CA767F10271
bool 
PropertyWindow::DrawRoot(const Widget* apRoot) {
    return true;
}

//##ModelId=3CA767F10399
bool 
PropertyWindow::DrawMouseLabel(const Widget* apMouseLabel) {
    return true;
}

//##ModelId=3CA767F200EA
bool 
PropertyWindow::DrawSensitivePoint(const Widget* apSensitivePoint) {
    return true;
}

//##ModelId=3CA767F20222
bool 
PropertyWindow::SetServicedModel(Model* apModel, bool aReset) {
    m_pModel = apModel;
    return true;
}

//##ModelId=3CA767F3000F
bool 
PropertyWindow::SetController(Controller* apController, bool aReset) {
    m_pController = apController;
    return true;
}

void
PropertyWindow::paintEvent(QPaintEvent* apPaintEvent) {
    if (m_pModel != NULL) {
        m_pModel->Lock();
        m_pModel->Draw(this);
        m_pModel->UnLock();
    }
}