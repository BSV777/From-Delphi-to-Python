// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "SensitivePointOrientation.h"


//##ModelId=3C93AD0F01C5
SensitivePointOrientation::~SensitivePointOrientation() {
}

//##ModelId=3C93AD0F01C6
SensitivePointOrientation::SensitivePointOrientation() {
}


