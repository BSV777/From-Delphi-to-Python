#include "stdafx.h"
#include "AppMainWindow.h"

#include <qapplication.h>

#include <qcombobox.h> 
#include <qtoolbar.h>
#include <qtoolbutton.h>
#include <qpixmap.h>
#include <qwhatsthis.h>
#include <qmenubar.h>
#include <qpopupmenu.h>

#include <qmotifstyle.h>
#include <qmotifplusstyle.h>
#include <qcdestyle.h>
#include <qwindowsstyle.h>
#include <qplatinumstyle.h>
#include <qsgistyle.h>
#include "propertywindow.h"

void
AppMainWindow::ToggleToolBar() {
    if (m_pToolBar->isVisible()) {
        // Hide toolbar
        m_pToolBar->hide();
        m_pOptions->changeItem(m_ToolbarId, "Show &Toolbar");
    }
    else {
        //Show toolbar
        m_pToolBar->show();
        m_pOptions->changeItem(m_ToolbarId, "Hide &Toolbar");
    }
}

void
AppMainWindow::ToggleProperty() {
    bool    hidden = false;
    QString text;
    text = m_pOptions->text(m_PropertyWindowId);
    hidden = (text == "Show &Property");

    if (hidden) {
        // Show property window
        m_pOptions->changeItem(m_PropertyWindowId, "Hide &Property");
//        m_pPropertyWindow->show();
    }
    else {
        // Hide property window
        m_pOptions->changeItem(m_PropertyWindowId, "Show &Property");
//        m_pPropertyWindow->hide();
    }
}

void
AppMainWindow::BuildLayout() {
    setCaption("Simple editor");


    m_ShowGrid      = false;
    m_SnapToGrid    = false;

    AppendToolBar();
    AppendMenu();
}

void
AppMainWindow::AppendToolBar() {
    // create a toolbar
    m_pToolBar = new QToolBar(this, "Toolbar");

    QPixmap new_icon(XPM::document_xpm);
    QPixmap open_icon(XPM::fileopen);
    QPixmap save_icon(XPM::filesave);
    QPixmap undo_icon(XPM::back);
    QPixmap redo_icon(XPM::forward);
    QPixmap snap_to_grid_icon(XPM::snap);
    QPixmap show_grid_icon(XPM::show);
    QPixmap create_label_icon(XPM::label);
    QPixmap create_textedit_icon(XPM::textedit);
    QPixmap create_button_icon(XPM::button);
    QPixmap stretch_button_icon(XPM::stretch);

    QToolButton* new_document = NULL;
    QToolButton* open_document = NULL;
    QToolButton* save_document = NULL;
    QToolButton* whats_this = NULL;

    new_document    = new QToolButton(new_icon, 
                                      "New file",
                                      QString::null,
                                      this, 
                                      SLOT(New()),
                                      m_pToolBar, 
                                      "Create new");
    open_document   = new QToolButton(open_icon, 
                                      "Open file",
                                      QString::null,
                                      this, 
                                      SLOT(Open()),
                                      m_pToolBar, 
                                      "Open file");

    save_document   = new QToolButton(save_icon, 
                                      "Save file",
                                      QString::null,
                                      this, 
                                      SLOT(Save()),
                                      m_pToolBar, 
                                      "Save file");
    m_pToolBar->addSeparator();

    m_pUndo         = new QToolButton(undo_icon, 
                                      "Undo",
                                      QString::null,
                                      this, 
                                      SLOT(Undo()),
                                      m_pToolBar, 
                                      "Undo action");

    m_pRedo         = new QToolButton(redo_icon, 
                                      "Redo",
                                      QString::null,
                                      this, 
                                      SLOT(Redo()),
                                      m_pToolBar, 
                                      "Undo action");
    m_pToolBar->addSeparator();

    m_pShowGridButton
                    = new QToolButton(show_grid_icon,
                                      "Show grid",
                                      QString::null,
                                      this, 
                                      SLOT(ToggleShowGrid()),
                                      m_pToolBar, 
                                      "Show grid");
    m_pShowGridButton->setToggleButton(true);

    m_pSnapToGridButton 
                    = new QToolButton(snap_to_grid_icon,
                                      "Snap to grid",
                                      QString::null,
                                      this, 
                                      SLOT(ToggleSnapToGrid()),
                                      m_pToolBar, 
                                      "Snap to grid");
    m_pSnapToGridButton->setToggleButton(true);

    m_pGridSizeComboBox
                    = new QComboBox(m_pToolBar,
                                    "Grid size");

    QString value;
    value = "5";
    m_pGridSizeComboBox->insertItem(value);
    value = "10";
    m_pGridSizeComboBox->insertItem(value);
    value = "15";
    m_pGridSizeComboBox->insertItem(value);
    value = "20";
    m_pGridSizeComboBox->insertItem(value);
    value = "25";
    m_pGridSizeComboBox->insertItem(value);
    value = "30";
    m_pGridSizeComboBox->insertItem(value);
    connect(m_pGridSizeComboBox,
            SIGNAL(activated(const QString&)),
            this,
            SLOT(ChangeGridSize(const QString&)));

    m_pToolBar->addSeparator();

    m_pStretchButton
                    = new QToolButton(stretch_button_icon,
                                      "Stretching the document",
                                      QString::null,
                                      this,
                                      SLOT(ToggleStretchDocument()),
                                      m_pToolBar,
                                      "Stretching the document");
    m_pStretchButton->setToggleButton(true);


    m_pToolBar->addSeparator();

    m_pCreateLabelButton
                    = new QToolButton(create_label_icon,
                                      "Create label",
                                      QString::null,
                                      this, 
                                      SLOT(ToggleCreateLabel()),
                                      m_pToolBar, 
                                      "Create label");
    m_pCreateLabelButton->setToggleButton(true);

    m_pCreateTextEditButton 
                    = new QToolButton(create_textedit_icon,
                                      "Create textedit",
                                      QString::null,
                                      this, 
                                      SLOT(ToggleCreateTextEdit()),
                                      m_pToolBar, 
                                      "Create textedit");
    m_pCreateTextEditButton->setToggleButton(true);

    m_pCreateButtonButton 
                    = new QToolButton(create_button_icon,
                                      "Create button",
                                      QString::null,
                                      this, 
                                      SLOT(ToggleCreateButton()),
                                      m_pToolBar, 
                                      "Create button");
    m_pCreateButtonButton->setToggleButton(true);

    m_pToolBar->addSeparator();

    whats_this      = QWhatsThis::whatsThisButton(m_pToolBar);

    QWhatsThis::add(new_document,   "<i>Create a new document</i> <b>(Ctrl+N)</b>");
    QWhatsThis::add(open_document,  "<i>Open exist document</i> <b>(Ctrl+O)</b>");
    QWhatsThis::add(save_document,  "<i>Save changes on the disk</i> <b>(Ctrl+S)</b>");
    QWhatsThis::add(m_pUndo,        "<i>Undo</i> <b>(Ctrl+Z)</b>");
    QWhatsThis::add(m_pRedo,        "<i>Redo</i> <b>(Ctrl+Y)</b>");
    QWhatsThis::add(m_pShowGridButton,
                                    "<i>Show grid</i><b></b>");
    QWhatsThis::add(m_pSnapToGridButton,
                                    "<i>Snap to grid</i><b></b>");
    QWhatsThis::add(m_pStretchButton,
                                    "<i>Auto stretch document</i><b></b>");
    QWhatsThis::add(m_pCreateLabelButton,
                                    "<i>Create a label</i><b></b>");
    QWhatsThis::add(m_pCreateTextEditButton,
                                    "<i>Create a textedit</i><b></b>");
    QWhatsThis::add(m_pCreateButtonButton,
                                    "<i>Create a button</i><b></b>");
    QWhatsThis::add(whats_this,     "<i>Small help about controls</i>");
}

void
AppMainWindow::AppendMenu() {
    // Create an easter egg

    QMenuBar*   menu_bar = NULL;
    menu_bar = menuBar();

    QPixmap new_icon(XPM::document_xpm);
    QPixmap open_icon(XPM::fileopen);
    QPixmap save_icon(XPM::filesave);
    QPixmap undo_icon(XPM::back);
    QPixmap redo_icon(XPM::forward);

    QPopupMenu* file_popup = NULL;
    QPopupMenu* edit_popup = NULL;
    QPopupMenu* options_popup = NULL;
    QPopupMenu* help_popup = NULL;
    QPopupMenu* style_options_popup = NULL;

    file_popup          = new QPopupMenu(this);
    edit_popup          = new QPopupMenu(this);
    options_popup       = new QPopupMenu(this);
    help_popup          = new QPopupMenu(this);
    style_options_popup = new QPopupMenu(options_popup);

    m_pEdit = edit_popup;
    m_pOptions = options_popup;
    m_pOptionsStyle= style_options_popup;

    menu_bar->insertItem("&File",   file_popup);
    menu_bar->insertItem("&Edit",   edit_popup);
    menu_bar->insertItem("&Option", options_popup);
    menu_bar->insertItem("&Help",   help_popup);

    int id; 
    id = file_popup->insertItem(new_icon,
                                "&New",
                                this,
                                SLOT(New()),
                                CTRL+Key_N);

    id = file_popup->insertItem(open_icon, 
                                "&Open", 
                                this, 
                                SLOT(Open()),
                                CTRL+Key_O);

    id = file_popup->insertItem("&Close", 
                                this, 
                                SLOT(Close()));

    id = file_popup->insertItem(save_icon, 
                                "&Save", 
                                this, 
                                SLOT(Save()),
                                CTRL+Key_S);

    id = file_popup->insertItem("Save &As", 
                                this, 
                                SLOT(SaveAs()));

    file_popup->insertSeparator();

    id = file_popup->insertItem("&Export", 
                                this, 
                                SLOT(Export()),
                                CTRL+Key_E);

    file_popup->insertSeparator();

    id = file_popup->insertItem("&Quit", 
                                this, 
                                SLOT(Quit()), 
                                CTRL+Key_Q);


    id = edit_popup->insertItem("&Undo", 
                                this, 
                                SLOT(Undo()), 
                                CTRL+Key_Z);

    m_UndoMenuId = id;

    id = edit_popup->insertItem("&Redo", 
                                this, 
                                SLOT(Redo()), 
                                CTRL+Key_Y);
    m_RedoMenuId = id;

    id  = style_options_popup->insertItem("Windows",
                                           this,
                                           SLOT(SetWindowsStyle()));
    m_WindowStyleId = id;

    id  = style_options_popup->insertItem("Platinum",
                                           this,
                                           SLOT(SetPlatinumStyle()));
    m_PlatinumStyleId = id;

    id  = style_options_popup->insertItem("Motif",
                                           this,
                                           SLOT(SetMotifStyle()));
    m_MotifStyleId = id;

    id  = style_options_popup->insertItem("MotifPlus",
                                           this,
                                           SLOT(SetMotifPlusStyle()));
    m_MotifPlusStyleId = id;

    id  = style_options_popup->insertItem("CDE",
                                           this,
                                           SLOT(SetCdeStyle()));
    m_CDEStyleId = id;

    id  = style_options_popup->insertItem("SGI",
                                           this,
                                           SLOT(SetSgiStyle()));
    m_SGIStyleId = id;

    id = options_popup->insertItem("&Set style", 
                                    style_options_popup);

    id = options_popup->insertItem("Show &Property",
                                   this,
                                   SLOT(ToggleProperty()));
    m_PropertyWindowId = id;


    id = options_popup->insertItem("Hide &Toolbar",
                                   this,
                                   SLOT(ToggleToolBar()));
    m_ToolbarId = id;

    id = options_popup->insertItem("Show &Grid",
                                   this,
                                   SLOT(ToggleShowGrid()));
    m_ShowGridMenuId = id;

    id = options_popup->insertItem("Snap Gr&id",
                                   this,
                                   SLOT(ToggleSnapToGrid()));
    
    m_SnapToGridMenuId = id;
    
    id = help_popup->insertItem("&About",
                                this,
                                SLOT(About()),
                                Key_F1);

    id = help_popup->insertItem("About &Qt",
                                this,
                                SLOT(AboutQt()),
                                CTRL+Key_F1);
}

void
AppMainWindow::SetWindowsStyle() {
    m_pOptionsStyle->setItemChecked(m_CurrentStyle, false);
    m_pOptionsStyle->setItemChecked(m_WindowStyleId, true);
    m_CurrentStyle = m_WindowStyleId;
    qApp->setStyle(new QWindowsStyle);
}

void
AppMainWindow::SetPlatinumStyle() {
    m_pOptionsStyle->setItemChecked(m_CurrentStyle, false);
    m_pOptionsStyle->setItemChecked(m_PlatinumStyleId, true);
    m_CurrentStyle = m_PlatinumStyleId;
    qApp->setStyle(new QPlatinumStyle);
}

void
AppMainWindow::SetMotifStyle() {
    m_pOptionsStyle->setItemChecked(m_CurrentStyle, false);
    m_pOptionsStyle->setItemChecked(m_MotifStyleId, true);
    m_CurrentStyle = m_MotifStyleId;
    qApp->setStyle(new QMotifStyle);
}

void
AppMainWindow::SetMotifPlusStyle() {
    m_pOptionsStyle->setItemChecked(m_CurrentStyle, false);
    m_pOptionsStyle->setItemChecked(m_MotifPlusStyleId, true);
    m_CurrentStyle = m_MotifPlusStyleId;
    qApp->setStyle(new QMotifPlusStyle);
}

void
AppMainWindow::SetCdeStyle() {
    m_pOptionsStyle->setItemChecked(m_CurrentStyle, false);
    m_pOptionsStyle->setItemChecked(m_CDEStyleId, true);
    m_CurrentStyle = m_CDEStyleId;
    qApp->setStyle(new QCDEStyle);
}

void
AppMainWindow::SetSgiStyle() {
    m_pOptionsStyle->setItemChecked(m_CurrentStyle, false);
    m_pOptionsStyle->setItemChecked(m_SGIStyleId, true);
    m_CurrentStyle = m_SGIStyleId;
    qApp->setStyle(new QSGIStyle);
}
