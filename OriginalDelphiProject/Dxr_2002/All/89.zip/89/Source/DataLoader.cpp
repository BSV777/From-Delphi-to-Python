// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "DataLoader.h"

#include "AbstractParser.h"

#include "qfile.h"
#include <qsize.h> 

//##ModelId=3CA567C500AB
DataLoader::DataLoader(AbstractParser*  apParser,
                       WidgetFactory*   apWidgetFactory) {
    m_Filename = "";
    m_pParser = apParser;
    m_pWidgetFactory = apWidgetFactory;
}

//##ModelId=3CA567C500DA
DataLoader::~DataLoader() {
    delete m_pParser;
    m_pParser = NULL;
}

//##ModelId=3CA566FB008C
WidgetVector* 
DataLoader::LoadFile(const QString* apcFilename) {
    if (m_pParser == NULL) {
        return NULL;
    }

    if (m_pWidgetFactory == NULL) {
        return NULL;
    }

    QFile           input_file;
    char*           source_data = NULL;
    unsigned int    source_size = 0;

    bool            open_result = false;
    int             read_bytes = -1;

    // <���������� ����� � ������>
    input_file.setName(*apcFilename);
    open_result = input_file.open(IO_ReadOnly);

    if (!open_result) {
        return NULL;
    }

    source_size = input_file.size() + 1;
    if ((source_size == 0) ||
        (source_size >= MAX_FILE_LENGTH)) {
        return NULL;
    }

    source_data = new char[source_size];
    memset(source_data, 0x00, source_size);
    read_bytes = input_file.readBlock(source_data, source_size);
    if (read_bytes == -1) {
        return NULL;
    }
    // </���������� ����� � ������>

    QDomDocument*   document = NULL;
    QDomElement     root;
    QDomNodeList    list;
    QDomNode        item;

    document = m_pParser->Parse(source_data);
    delete source_data;
    source_data = NULL;

    if (document == NULL) {
        return NULL;
    }

    unsigned int    index = 0;
    unsigned int    list_size = 0;
    Widget*         widget = NULL;
    WidgetVector*   widget_arr = NULL;

    root = document->documentElement();
    list = root.childNodes();
    widget_arr = new WidgetVector();

    list_size = list.length();
    for (index = 0; index < list_size; index++) {
        item = list.item(index);
        widget = CreatFromNode(item);
        if (widget == NULL) {
            continue;
        }
        widget_arr->push_back(widget);
    }
    delete document;
    document = NULL;

    return widget_arr;
}

Widget*
DataLoader::CreatFromNode(const QDomNode& arcNode) {
    if (!arcNode.isElement()) {
        return NULL;
    }

    if (m_pWidgetFactory == NULL) {
        return NULL;
    }

    Widget* result = NULL;
    QRect   properties;
    QSize   size;
    QString value_attr_name;
    QString value;
    QString node_name;

    properties.setRect(0,0, DEFAULT_CONTROL_WIDTH, DEFAULT_CONTROL_HEIGHT);
    size.setWidth(DEFAULT_CONTROL_WIDTH);
    size.setHeight(DEFAULT_CONTROL_HEIGHT);

    node_name = arcNode.nodeName().lower();
    if (node_name == LABEL_ELEMENT_NAME) {
        result = m_pWidgetFactory->CreateLabel();
        value_attr_name = LABEL_VALUE_ATTR_NAME;
        value = DEFAULT_LABEL_VALUE;
    } 
    else if (node_name == BUTTON_ELEMENT_NAME) {
        result = m_pWidgetFactory->CreateButton();
        value_attr_name = BUTTON_VALUE_ATTR_NAME;
        value = DEFAULT_BUTTON_VALUE;
    }
    else if (node_name == TEXTEDIT_ELEMENT_NAME) {
        result = m_pWidgetFactory->CreateTextEdit();
        value_attr_name = TEXTEDIT_VALUE_ATTR_NAME;
        value = DEFAULT_TEXTEDIT_VALUE;
    }
    else {
    }

    if (result == NULL) {
        return NULL;
    }

    QDomNamedNodeMap    attributes;
    QDomNode            attribute;
    QString             attr_name;
    QString             attr_value;
    int                 integer_value;
    bool                parse;
    unsigned int        index = 0;
    unsigned int        list_size = 0;

    value_attr_name = value_attr_name.lower();
    attributes = arcNode.attributes();
    list_size = attributes.length();


    for (index = 0; index < list_size; index++) {
        attribute = attributes.item(index);
        if (attribute.isAttr()) {

            attr_name = attribute.nodeName().lower();
            attr_value = attribute.nodeValue();

            if (attr_name == value_attr_name) {
                value = attr_value;
            }
            integer_value = attr_value.toInt(&parse);

            if (!parse) {
                continue;
            }

                 if (attr_name == LEFT_ATTR_NAME)   { properties.setX(integer_value); }
            else if (attr_name == TOP_ATTR_NAME)    { properties.setY(integer_value); }
            else if (attr_name == WIDTH_ATTR_NAME)  { size.setWidth(integer_value); }
            else if (attr_name == HEIGHT_ATTR_NAME) { size.setHeight(integer_value); }
            else {
            }
        }
    }

    properties.setSize(size);
    result->SetPosition(&properties);
    result->SetValue(&value);

    return result;
}

//##ModelId=3CA566FB00FA
WidgetVector* 
DataLoader::LoadFile() {
    return LoadFile(&m_Filename);
}

//##ModelId=3CA566FB0186
void 
DataLoader::SetFileName(const QString* apcFilename) {
    if (apcFilename == NULL) {
        m_Filename = "";
    }
    else {
        m_Filename = *apcFilename;
    }
}
