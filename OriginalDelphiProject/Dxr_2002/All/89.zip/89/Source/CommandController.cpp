// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "CommandController.h"

#include "Command.h"

//##ModelId=3C8A6409008C
CommandController::CommandController() {
    m_StackPointer = 0;
    m_CommandHistory.clear();
}

//##ModelId=3C8A6409006D
CommandController::~CommandController() {
    Command*    p_command = NULL;
    while (!m_CommandHistory.isEmpty()) {
        p_command = m_CommandHistory.last();
        delete p_command;
        m_CommandHistory.removeLast();
    }
    m_CommandHistory.clear();
}

//##ModelId=3C8935890128
void 
CommandController::Execute(Model*       apModel, 
                           Command*&    arpCommand) {

    if ((apModel == NULL) ||
        (arpCommand == NULL)) {
        return;
    }

    arpCommand->SetModel(apModel);
    if (arpCommand->Execute()) {
        // ���� ������� ����������� ������, ���������
        // �� � ������� ������.
        Insert(arpCommand);
    }
    else {
        delete arpCommand;
        arpCommand = NULL;
    }
}

//##ModelId=3C89360902FD
bool 
CommandController::Undo(int aCount) {
    for (; aCount != 0; aCount--) {
        if (!UndoOnce()) {
            break;
        }
    }

	return (aCount == 0);
}

//##ModelId=3C89361501C5
bool 
CommandController::Redo(int aCount) {
    for (; aCount != 0; aCount--) {
        if (!RedoOnce()) {
            break;
        }
    }

    return (aCount == 0);
}

//##ModelId=3C8A460602CE
bool
CommandController::UndoOnce() {
    Command*    command = NULL;

    if (m_StackPointer <= 0) {
        return false;
    }

    m_StackPointer--;
    command = m_CommandHistory.at(m_StackPointer);
    command->Unexecute();
	return true;
}

//##ModelId=3C8A460602B4
bool
CommandController::RedoOnce() {
    Command*    command = NULL;
    int         size = 0;

    size = m_CommandHistory.count();

    if (m_StackPointer >= size) {
        return false;
    }

    command = m_CommandHistory.at(m_StackPointer);
    m_StackPointer++;
    command->Execute();
	return true;
}

//##ModelId=3C8A460602DE
void
CommandController::PrepareToInsert() {
    int             size = 0;
    int             delete_count = 0;

    size = m_CommandHistory.count();
    delete_count = size - m_StackPointer;

    // ������� ���������� ����� ������
    while (delete_count > 0) {
        delete m_CommandHistory.last();
        m_CommandHistory.removeLast();
        delete_count--;
    }
        
    size = m_CommandHistory.count();
    delete_count = size - COMMAND_STACK_SIZE + 1;

    // ���� ������ ������ ��������, �� �������� ������ ������
    while (delete_count > 0) {
        delete m_CommandHistory.first();
        m_CommandHistory.removeFirst();
        delete_count--;
        m_StackPointer--;
    }
}

//##ModelId=3C8A460602FD
void
CommandController::Insert(Command*& arpCommand) {
    PrepareToInsert();
    m_CommandHistory.append(arpCommand);
    m_StackPointer++;
}

//##ModelId=3C8FBA86038A
void
CommandController::Clear() {
    Command*    p_command = NULL;

    while (!m_CommandHistory.isEmpty()) {
        p_command = m_CommandHistory.last();
        delete p_command;
        m_CommandHistory.removeLast();
    }

    m_CommandHistory.clear();
    m_StackPointer = 0;
}
