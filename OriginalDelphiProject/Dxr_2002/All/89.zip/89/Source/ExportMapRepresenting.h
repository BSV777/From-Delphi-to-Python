// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_EXPORTMAPREPRESENTING_3CA6B8430280_INCLUDED
#define _INC_EXPORTMAPREPRESENTING_3CA6B8430280_INCLUDED

#include <qsize.h>
#include <qdom.h>

class Widget;

//##ModelId=3CA6B8430280
class ExportMapRepresenting {
public:
	//##ModelId=3CA6C05402DE
	inline virtual          ~ExportMapRepresenting();

    //##ModelId=3CA72846031C
	virtual bool            CreateNewRaster() = 0;

	//##ModelId=3CA72870036B
	virtual bool            CreateNewRow() = 0;

	//##ModelId=3CA728720280
	virtual bool            InsertNewCell(const QSize&  arSize,
                                          const Widget* apcObject) = 0;

	//##ModelId=3CA7293F002E
	virtual bool            CloseRow() = 0;

	//##ModelId=3CA729650109
	virtual bool            CloseRaster() = 0;

	//##ModelId=3CA729740177
	virtual QDomDocument    GetDocument() = 0;
};

//##ModelId=3CA6C05402DE
inline 
ExportMapRepresenting::~ExportMapRepresenting() {
}

#endif /* _INC_EXPORTMAPREPRESENTING_3CA6B8430280_INCLUDED */
