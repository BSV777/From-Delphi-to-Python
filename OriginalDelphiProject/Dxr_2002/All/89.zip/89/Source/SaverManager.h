// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_SAVERMANAGER_3C89D67F030D_INCLUDED
#define _INC_SAVERMANAGER_3C89D67F030D_INCLUDED

class AbstractSaver;

//##ModelId=3C89D67F030D
class SaverManager {
public:
	//##ModelId=3C8BDA6D03D8
	AbstractSaver*          GetSaver();

};

#endif /* _INC_SAVERMANAGER_3C89D67F030D_INCLUDED */

