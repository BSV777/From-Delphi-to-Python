/* XPM */
/* Drawn by Eugene Gusev for DXRussia competition task */
namespace XPM {
const char* snap[] = { 
"17 17 5 1",
"b c #000000",
"# c #000080",
". c #c0c0c0",
"c c #ffff00",
"a c #ffffff",
".................",
"...#....#....#...",
"...#....#....#...",
".####a#####a####.",
"...#aaaa#aaaa#...",
"...aaaaa.baaaa...",
"...#aaaabbaaa#...",
"...#aaabbbaaa#...",
".####.bcbb.#####.",
"...#aaabbbaaa#...",
"...#aaaabbaaa#...",
"...aaaaa.baaaa...",
"...#aaaa#aaaa#...",
".####a#####a####.",
"...#....#....#...",
"...#....#....#...",
"................."};
}