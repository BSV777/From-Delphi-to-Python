// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "TextEditWidget.h"
#include "View.h"
#include "Widget.h"

//##ModelId=3C89FC53007D
TextEditWidget::TextEditWidget() {
    SetId(GenerateId());
    m_Properties.setRect(0, 0, 0, 0);
    m_Value = "";
}

//##ModelId=3C89FC53008C
TextEditWidget::~TextEditWidget() {
}

//##ModelId=3C89F632008C
bool 
TextEditWidget::Draw(View*& arpDestinationView) const {
    return arpDestinationView->DrawTextEdit(this);
}

//##ModelId=3C89F63200BB
const QRect* 
TextEditWidget::GetPosition() const {
    return &m_Properties;
}

//##ModelId=3C89F63200DB
void 
TextEditWidget::SetPosition(const QRect* apcPosition) {
    if (apcPosition != NULL) {
        m_Properties = *apcPosition;
    }
    else {
        m_Properties.setRect(0, 0, 0, 0);
    }
}

//##ModelId=3C89F63200DA
const QString*
TextEditWidget::GetValue() const {
    return &m_Value;
}

//##ModelId=3C89F6320128
void 
TextEditWidget::SetValue(const QString* apcValue) {
    if (apcValue != NULL) {
        m_Value = *apcValue;
        m_Value.truncate(255);
    }
    else {
        m_Value = "";
    }
}

//##ModelId=3C89F6320109
Command* 
TextEditWidget::Commit() {
    /* ������� ������� � ������� �� ���������� */
    return NULL;
}

//##ModelId=3C89F6320119
void 
TextEditWidget::Cancel() {
//    m_Value = m_BackupValue;
//    m_Properties = m_BackupProperties;
}

//##ModelId=3C8D33300271
Widget* 
TextEditWidget::FindById(long aId) {
    /* Check mine */
    if (aId == GetId()) {
        return this;
    }
    else {
        /* Look at the children */
        return NULL;
    }
}

const Widget* 
TextEditWidget::FindById(long aId) const {
    /* Check mine */
    if (aId == GetId()) {
        return this;
    }
    else {
        /* Look at the children */
        return NULL;
    }
}

//##ModelId=3C93CA23006D
Widget*
TextEditWidget::GetOwner(const QPoint* apPosition) {
    if (apPosition != NULL) {
        if (m_Properties.contains(*apPosition)) {
            return this;
        }
    }
	return NULL;
}

//##ModelId=3C9B90810261
bool
TextEditWidget::IsValidWidget(const Widget* apExamineWidget) const {
    bool result = true;
    if (apExamineWidget == NULL) {
        return result;
    }

    if (apExamineWidget == this) {
        return result;
    }

    result = !m_Properties.intersects(*(apExamineWidget->GetPosition()));

    return result;
}

long
TextEditWidget::GetHash() const {
    long                hash = 0x74c8a0d;
    hash = hash + Widget::GetHash(&m_Value);
    hash = hash ^ Widget::GetHash(&m_Properties);
    return hash;
}
