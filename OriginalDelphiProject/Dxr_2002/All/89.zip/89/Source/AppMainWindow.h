// AppMainWindow.h: interface for the AppMainWindow class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_APPMAINWINDOW_H__64CAC382_0917_455E_AA69_2589D9A25B2E__INCLUDED_)
#define AFX_APPMAINWINDOW_H__64CAC382_0917_455E_AA69_2589D9A25B2E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <qmainwindow.h>
#include <qpixmap.h>
#include <qcombobox.h>

#include "SimpleView.h"

class QToolButton;
class QScrollView;

class View;
class Controller;
class PropertyWindow;

class AppMainWindow : public QMainWindow {
    Q_OBJECT
public:
                            AppMainWindow(QWidget* parent = 0,
                                          const char* name = 0, 
                                          WFlags f = WType_TopLevel);
    virtual                 ~AppMainWindow();

    inline View*            GetView();
    void                    SetController(Controller* apNewController);

    inline bool             GetShowGridState() const;
    inline bool             GetSnapToGridState() const;
    inline bool             GetCreateLabel() const;
    inline bool             GetCreateTextEdit() const;
    inline bool             GetCreateButton() const;
    inline bool             GetStretchStatus() const;

    void                    SetShowGridState(bool aNewState);
    void                    SetSnapToGridState(bool aNewState);
    void                    SetCreateLabel(bool aNewState);
    void                    SetCreateTextEdit(bool aNewState);
    void                    SetCreateButton(bool aNewState);
    void                    SetStretchDocument(bool aIsSretching);

protected:
    void                    BuildLayout();

    void                    AppendToolBar();
    void                    AppendMenu();

    void                    CreateView(int aWidth = -1, int aHeight = -1);
    void                    CloseView();

public slots:
    void                    ToggleProperty();
    void                    ToggleToolBar();
    void                    ToggleShowGrid();
    void                    ToggleSnapToGrid();

    void                    ToggleCreateLabel();
    void                    ToggleCreateTextEdit();
    void                    ToggleCreateButton();

    void                    ToggleStretchDocument();

protected slots:
    void                    New();
    void                    Open();
    void                    Save();
    void                    SaveAs();
    void                    Close();
    void                    Export();
    void                    Quit();
    void                    Redo();
    void                    Undo();
    void                    About();
    void                    AboutQt();

    void                    SetWindowsStyle();
    void                    SetPlatinumStyle();
    void                    SetMotifStyle();
    void                    SetMotifPlusStyle();
    void                    SetCdeStyle();
    void                    SetSgiStyle();

    void                    ChangeGridSize(const QString& arNewGridSize);

    void                    paintEvent(QPaintEvent* apPaintEvent);

    void                    mousePressEvent(QMouseEvent* apMouseEvent);
    void                    mouseReleaseEvent(QMouseEvent* apMouseEvent);
    void                    mouseMoveEvent(QMouseEvent* apMouseEvent);

protected:
    int                     m_MouseState;
    int                     m_UndoMenuId;
    int                     m_RedoMenuId;
    int                     m_PropertyWindowId;
    int                     m_ToolbarId;
    int                     m_WindowStyleId;
    int                     m_PlatinumStyleId;
    int                     m_MotifStyleId;
    int                     m_MotifPlusStyleId;
    int                     m_CDEStyleId;
    int                     m_SGIStyleId;

    bool                    m_ShowGrid;
    bool                    m_SnapToGrid;

    bool                    m_CreateLabel;
    bool                    m_CreateTextEdit;
    bool                    m_CreateButton;

    bool                    m_StretchingDocument;

    int                     m_SnapToGridMenuId;
    int                     m_ShowGridMenuId;

    int                     m_CurrentStyle;
    QPopupMenu*             m_pEdit;
    QPopupMenu*             m_pOptions;
    QPopupMenu*             m_pOptionsStyle;
    PropertyWindow*         m_pPropertyWindow;
    QToolBar*               m_pToolBar;
    QToolButton*            m_pSnapToGridButton;
    QToolButton*            m_pShowGridButton;

    QToolButton*            m_pUndo;
    QToolButton*            m_pRedo;

    QToolButton*            m_pCreateLabelButton;
    QToolButton*            m_pCreateTextEditButton;
    QToolButton*            m_pCreateButtonButton;
    QComboBox*              m_pGridSizeComboBox;

    QToolButton*            m_pStretchButton;

    QScrollView*            m_pCentralView;

    SimpleView*             m_pModelViewport;
    Controller*             m_pModelController;
};

namespace XPM {
    extern const char* document_xpm[];
    extern const char* fileopen[];
    extern const char* filesave[];
    extern const char* back[];
    extern const char* forward[];
    extern const char* show[];
    extern const char* snap[];
    extern const char* label[];
    extern const char* textedit[];
    extern const char* button[];
    extern const char* qt_face[];
    extern const char* stretch[];
}

/*
static const char NEW_DOCUMENT[]    = "./XPM/document.xpm";
static const char OPEN_DOCUMENT[]   = "./XPM/fileopen.xpm";
static const char SAVE_DOCUMENT[]   = "./XPM/filesave.xpm";
static const char UNDO[]            = "./XPM/back.xpm";
static const char REDO[]            = "./XPM/forward.xpm";

static const char SHOW[]            = "./XPM/show.xpm";
static const char SNAP[]            = "./XPM/snap.xpm";

static const char CREATE_LABEL[]    = "./XPM/createlabel.xpm";
static const char CREATE_TEXTEDIT[] = "./XPM/createtextedit.xpm";
static const char CREATE_BUTTON[]   = "./XPM/createbutton.xpm";
*/

inline
View*
AppMainWindow::GetView() {
    return m_pModelViewport;
}

inline
bool
AppMainWindow::GetShowGridState() const {
    return m_ShowGrid;
}

inline
bool
AppMainWindow::GetSnapToGridState() const {
    return m_SnapToGrid;
}

inline
bool
AppMainWindow::GetCreateLabel() const {
    return m_CreateLabel;
}

inline
bool
AppMainWindow::GetCreateTextEdit() const {
    return m_CreateTextEdit;
}

inline
bool
AppMainWindow::GetCreateButton() const {
    return m_CreateButton;
}

inline
bool
AppMainWindow::GetStretchStatus() const {
    return m_StretchingDocument;
}

#endif // !defined(AFX_APPMAINWINDOW_H__64CAC382_0917_455E_AA69_2589D9A25B2E__INCLUDED_)
