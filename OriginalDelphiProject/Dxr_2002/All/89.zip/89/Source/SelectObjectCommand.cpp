// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "SelectObjectCommand.h"

//##ModelId=3C8A4918002E
SelectObjectCommand::SelectObjectCommand() {
}

//##ModelId=3C8A4918003E
SelectObjectCommand::~SelectObjectCommand() {
}

//##ModelId=3C8A47E3037A
bool
SelectObjectCommand::Execute() {
	return static_cast<bool>(0);
}

//##ModelId=3C8A47E303B9
bool 
SelectObjectCommand::Unexecute() {
	return static_cast<bool>(0);
}



