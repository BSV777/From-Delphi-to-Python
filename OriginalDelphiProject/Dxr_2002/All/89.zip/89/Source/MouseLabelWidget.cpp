// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "MouseLabelWidget.h"
#include "View.h"
#include "Widget.h"

//##ModelId=3C89FC570232
MouseLabelWidget::MouseLabelWidget() {
    Widget::SetId(MOUSELABEL_WIDGET_ID);
    m_Value = "";
    m_IsShow = false;
}

//##ModelId=3C89FC570242
MouseLabelWidget::~MouseLabelWidget() {
}

//##ModelId=3C89F624031C
bool 
MouseLabelWidget::Draw(View*& arpDestinationView) const {
    bool    result = false;
    if (m_IsShow) {
        result = arpDestinationView->DrawMouseLabel(this);
    }
    else {
        result = true;
    }

    return result;
}

//##ModelId=3C89F624034B
const QRect* 
MouseLabelWidget::GetPosition() const {
    return &m_Properties;
}

//##ModelId=3C89F624036B
void 
MouseLabelWidget::SetPosition(const QRect* apcPosition) {
    if (apcPosition != NULL) {
        m_Properties = *apcPosition;
    }
    else {
        m_Properties.setRect(0, 0, 0, 0);
    }
}

//##ModelId=3C89F624035B
const QString*
MouseLabelWidget::GetValue() const {
    return &m_Value;
}

//##ModelId=3C89F6250000
void 
MouseLabelWidget::SetValue(const QString* apcValue) {
    if (apcValue != NULL) {
        m_Value = *apcValue;
    }
    else {
        m_Value = "";
    }
}

//##ModelId=3C89F6240399
Command* 
MouseLabelWidget::Commit() {
    return NULL;
}

//##ModelId=3C89F62403A9
void 
MouseLabelWidget::Cancel() {
}

//##ModelId=3C8D3337004E
Widget* 
MouseLabelWidget::FindById(long aId) {
    /* Check mine */
    if (aId == GetId()) {
        return this;
    }
    else {
        /* Look at the children */
        return NULL;
    }
}

const Widget* 
MouseLabelWidget::FindById(long aId) const {
    /* Check mine */
    if (aId == GetId()) {
        return this;
    }
    else {
        /* Look at the children */
        return NULL;
    }
}

//##ModelId=3C93CA2B001F
Widget* 
MouseLabelWidget::GetOwner(const QPoint* apPosition) {
	return NULL;
}

//##ModelId=3C9B90840242
bool
MouseLabelWidget::IsValidWidget(const Widget* apExamineWidget) const {
    return true;
}

long
MouseLabelWidget::GetHash() const {
    return 0x00000000;
}
