// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "RootWidget.h"
#include <qstring.h>
#include "View.h"
#include "Widget.h"


//##ModelId=3C89FC5D0157
RootWidget::RootWidget() {
    Widget::SetId(ROOT_WIDGET_ID);
    m_pValue = NULL;
    m_Size.setRect(0, 0, 600, 800); // ��������� �������
}

//##ModelId=3C89FC5D0167
RootWidget::~RootWidget() {
    WidgetIterator      iter;
    ConstWidgetIterator end;

    iter = m_Children.begin();
    end = m_Children.end();

    for (; iter != end; iter++) {
        delete (*iter);
    }
    delete m_pValue;
}

//##ModelId=3C89F61A03D8
bool 
RootWidget::Draw(View*& arpDestinationView) const {
    bool            result      = true;
    bool            res         = NULL;
    const Widget*   mouse_label = NULL; 

    result = result && arpDestinationView->DrawRoot(this);

    ConstWidgetIterator iter;
    ConstWidgetIterator end;

    iter = m_Children.begin();
    end  = m_Children.end();

    for (; iter != end; iter++) {
        res = (*iter)->Draw(arpDestinationView);
        if ((*iter)->GetType() == MOUSELABEL_WIDGET) {
            mouse_label = (*iter);
        }
        result = result && res;
    }

    if (mouse_label != NULL) {
        mouse_label->Draw(arpDestinationView);
    }
    return result;
}

//##ModelId=3C89F61B001F
const QRect* 
RootWidget::GetPosition() const {
    return &m_Size;
}

//##ModelId=3C89F61B0020
const QString* 
RootWidget::GetValue() const {
    if (m_pValue == NULL) {
        return NULL;
    }
    else {
        QString*    ret_value;
        ret_value = new QString();
        *ret_value = *m_pValue;
        return ret_value;
    }
}

//##ModelId=3C89F61B002E
void 
RootWidget::SetPosition(const QRect* apcPosition) {
    if (apcPosition != NULL) {
        m_Size = *apcPosition;
    }
}

//##ModelId=3C89F61B009C
void 
RootWidget::SetValue(const QString* apcValue) {
    if (apcValue == NULL) {
        delete m_pValue;
        m_pValue = NULL;
    }
    delete m_pValue;
    m_pValue = new QString();
    *m_pValue = *apcValue;
}

//##ModelId=3C89F61B005D
Command*
RootWidget::Commit() {
    return NULL;
}

//##ModelId=3C89F61B006D
void 
RootWidget::Cancel() {
}

//##ModelId=3C8A23CE0290
int
RootWidget::FindChild(Widget* apChild) {
    WidgetIterator      iter;
    ConstWidgetIterator end;
    int                 index = -1;

    iter = m_Children.begin();
    end  = m_Children.end();

    for (index = 0; iter != end; index++, iter++) {
        if ((*iter) == apChild) {
            return index;
        }
    }
    return -1;
}

//##ModelId=3C8D333D01C5
Widget* 
RootWidget::FindById(long aId) {
    /* Check mine */
    if (aId == GetId()) {
        return this;
    }
    else {
        /* Look at the children */
        return LookAtTheChildren(aId);
    }
}

const Widget* 
RootWidget::FindById(long aId) const {
    /* Check mine */
    if (aId == GetId()) {
        return this;
    }
    else {
        /* Look at the children */
        return LookAtTheChildren(aId);
    }
}

//##ModelId=3C8D3BDA02EE
Widget* 
RootWidget::LookAtTheChildren(long aId) {
    WidgetIterator      iter;
    ConstWidgetIterator end;
    Widget*             result = NULL;

    iter = m_Children.begin();
    end  = m_Children.end();

    for (; iter != end; iter++) {
        result = (*iter)->FindById(aId);
        if (result != NULL) {
            break;
        }
    }
    return result;
}

const Widget*
RootWidget::LookAtTheChildren(long aId) const {
    ConstWidgetIterator iter;
    ConstWidgetIterator end;
    Widget*             result = NULL;

    iter = m_Children.begin();
    end  = m_Children.end();

    for (; iter != end; iter++) {
        result = (*iter)->FindById(aId);
        if (result != NULL) {
            break;
        }
    }
    return result;
}

//##ModelId=3C93CA320222
Widget* 
RootWidget::GetOwner(const QPoint* apPosition) {
    WidgetIterator      iter;
    ConstWidgetIterator end;
    Widget*             result = NULL;

    iter = m_Children.begin();
    end  = m_Children.end();

    for (; iter != end; iter++) {
        result = (*iter)->GetOwner(apPosition);
        if (result != NULL) {
            break;
        }
    }
    return result;
}

//##ModelId=3C9B907F0196
bool
RootWidget::IsValidWidget(const Widget* apExamineWidget) const {
    ConstWidgetIterator iter;
    ConstWidgetIterator end;
    bool                result = true;
    const QRect*        p_position;

    if (apExamineWidget == NULL) {
        return result;
    }

    p_position = apExamineWidget->GetPosition();
    if (!m_Size.contains(p_position->topLeft(), false)) {
        return false;
    }
    
    if (!m_Size.contains(p_position->bottomRight(), false)) {
        if (m_pValue == NULL) {
            return false;
        }

        if (*m_pValue == STRETCH_DOCUMENT) {
            m_Size.rRight()  = max (m_Size.right(),  p_position->right());
            m_Size.rBottom() = max (m_Size.bottom(), p_position->bottom());
        }
        else {
            return false;
        }
    }

    iter = m_Children.begin();
    end  = m_Children.end();

    for (; iter != end; iter++) {
        result = (*iter)->IsValidWidget(apExamineWidget);
        if (!result) {
            break;
        }
    }
    return result;
}

long
RootWidget::GetHash() const {
    ConstWidgetIterator iter;
    ConstWidgetIterator end;
    long                hash = 0x00000000;

    iter = m_Children.begin();
    end  = m_Children.end();

    for (int index = 0; iter != end; index++, iter++) {
        hash += (*iter)->GetHash();
    }
    return hash;
}
