// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "WestSensitivePoint.h"

#include <qpoint.h>
#include <qrect.h>

//##ModelId=3C93B31D0203
QRect
WestSensitivePoint::CalculatePosition(const QRect* apPosition) {
    QRect result;
    if (apPosition != NULL) {
        result.setRect(apPosition->left() - 2,
                       apPosition->top() + apPosition->height()/2 - 2,
                       5,
                       5);
    }
	return result;
}

//##ModelId=3CA21C50008C
void 
WestSensitivePoint::MoveFrom(const QPoint* apDeparturePoint) {
}

//##ModelId=3CA236570261
bool 
WestSensitivePoint::MoveTo(Widget*          apObject, 
                           const QPoint*    apcDestinationPoint, 
                           int              aGridSize) {
    QPoint      rounded_point;
    QRect       old_posit;
    QRect       new_posit;
    Widget*     root = NULL;
    bool        is_valid = false;
    bool        result = false;

    do {
        if (apObject == NULL) {
            break;
        }

        if (apcDestinationPoint == NULL) {
            break;
        }

        if (aGridSize < 0) {
            break;
        }

        rounded_point = *apcDestinationPoint;
//        rounded_point.rx() -= rounded_point.x()%aGridSize;
        rounded_point.rx() = rounded_point.x()/double(aGridSize) + 0.5;
        rounded_point.rx() *= aGridSize;

        old_posit = *(apObject->GetPosition());

        if (old_posit.right() <= rounded_point.x()) {
            break;
        }

        new_posit = old_posit;
        new_posit.setLeft(rounded_point.rx());

        apObject->SetPosition(&new_posit);

        root = apObject->GetRoot();
        if (root != NULL) {
            is_valid = root->IsValidWidget(apObject);
        }
        if (!is_valid) {
            // ���� ������ �� �������, �� ���������� �����.
            apObject->SetPosition(&old_posit);
        }
        else {
            // 
            result = true;
        }
    } while (false);

    if (result) {
        Widget*     tool_tip = NULL;
        QString     tool_tip_value;
        QString     width;

        tool_tip = root->FindById(MOUSELABEL_WIDGET_ID);
        width.setNum(apObject->GetPosition()->width());
        tool_tip_value = "width: " + width;

        tool_tip->SetValue(&tool_tip_value);
    }
    
    return result;
}
