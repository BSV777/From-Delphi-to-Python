// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_CREATEBUTTONCOMMAND_3C8669450196_INCLUDED
#define _INC_CREATEBUTTONCOMMAND_3C8669450196_INCLUDED
#include "Model.h"

#include "Command.h"

class Model;
class QRect;
class QString;

//##ModelId=3CA2321F0242
class CreateButtonCommand : public Command {
public:
	//##ModelId=3CA2321F0274
	                        CreateButtonCommand();

	//##ModelId=3CA2321F0273
	virtual                 ~CreateButtonCommand();

	//##ModelId=3CA2321F0271
	virtual void            SetNewProperties(const QRect* apPosition);

	//##ModelId=3CA2321F0268
	virtual void            SetNewValue(const QString* apValue);

	//##ModelId=3CA2321F0266
	virtual void            SetOldValue(const QString* apValue);

	//##ModelId=3CA2321F0264
	virtual void            SetOldProperties(const QRect* apPosition);

	//##ModelId=3CA2321F0262
    virtual void            SetObject(const Widget* apObject) {}

protected:
	//##ModelId=3CA2321F025C
	inline virtual void     SetModel(Model* apModel);

	//##ModelId=3CA2321F025B
	virtual bool            Execute();

	//##ModelId=3CA2321F025A
	virtual bool            Unexecute();

private:
	//##ModelId=3CA2321F0259
    long                    m_ObjectId;

	//##ModelId=3CA2321F0256
    QRect*                  m_pProperties;

	//##ModelId=3CA2321F0251
    QString*                m_pValue;

	//##ModelId=3CA2321F0246
    Model*                  m_pModel;
};

//##ModelId=3C9A5A95029F
inline 
void
CreateButtonCommand::SetModel(Model* apModel) {
    m_pModel = apModel;
}

#endif /* _INC_CREATEBUTTONCOMMAND_3C8669450196_INCLUDED */
