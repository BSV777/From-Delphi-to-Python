// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_REPRESENTATIONSERIALIZER_3CA6BBCA000F_INCLUDED
#define _INC_REPRESENTATIONSERIALIZER_3CA6BBCA000F_INCLUDED

#include <qstring.h>
#include <qdom.h>

//##ModelId=3CA6BBCA000F
class RepresentationSerializer {
public:
	//##ModelId=3CA6C02F02BF
	inline virtual          ~RepresentationSerializer();

	//##ModelId=3CA6C89501B5
	virtual bool            Serialize(const QDomDocument& arcDocument) = 0;

	//##ModelId=3CA6C94401B5
	virtual QString         GetString() const = 0;

	//##ModelId=3CA6C8FC03A9
	virtual bool            Save(const QString& arcName) = 0;

	//##ModelId=3CA6C96A03A9
	virtual bool            Close() = 0;
};

//##ModelId=3CA6C02F02BF
inline 
RepresentationSerializer::~RepresentationSerializer() {
}

#endif /* _INC_REPRESENTATIONSERIALIZER_3CA6BBCA000F_INCLUDED */
