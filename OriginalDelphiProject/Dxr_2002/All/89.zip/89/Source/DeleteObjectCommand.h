// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_DELETEOBJECTCOMMAND_3C8669B5035B_INCLUDED
#define _INC_DELETEOBJECTCOMMAND_3C8669B5035B_INCLUDED
#include "Model.h"


#include "Command.h"

class Model;

//##ModelId=3C8669B5035B
class DeleteObjectCommand : public Command {
public:
	//##ModelId=3C8A490D000F
	                        DeleteObjectCommand();

	//##ModelId=3C8A490D001F
	virtual                 ~DeleteObjectCommand();

    //##ModelId=3C9B911A032C
	virtual void            SetNewProperties(const QRect* apPosition);

	//##ModelId=3C9B911A034B
	virtual void            SetNewValue(const QString* apValue);

	//##ModelId=3C9B911A037A
	virtual void            SetOldValue(const QString* apValue);

	//##ModelId=3C9B911A03A9
	virtual void            SetOldProperties(const QRect* apPosition);

	//##ModelId=3CA0DD8202AF
    virtual void            SetObject(const Widget* apObject);

protected:
	//##ModelId=3C9A5AA700AB
	inline virtual void     SetModel(Model* apModel);

    //##ModelId=3C8A47DE00FA
	virtual bool            Execute();

	//##ModelId=3C8A47DE0138
	virtual bool            Unexecute();

private:
	//##ModelId=3CA0DD82029F
    int                     m_ObjectType;

	//##ModelId=3CA0DD820295
    long                    m_ObjectId;

	//##ModelId=3CA0DD820292
    QRect*                  m_pProperties;

	//##ModelId=3CA0DD820287
    QString*                m_pValue;

	//##ModelId=3CA0DD820282
    Model*                  m_pModel;
};

//##ModelId=3C9A5AA700AB
inline 
void
DeleteObjectCommand::SetModel(Model* apModel) {
    m_pModel = apModel;
}

#endif /* _INC_DELETEOBJECTCOMMAND_3C8669B5035B_INCLUDED */
