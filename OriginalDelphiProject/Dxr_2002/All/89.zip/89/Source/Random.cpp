// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"

#include "Random.h"

#define BITS 24

//##ModelId=3C8A23CF03C8
const long Random::m_Multiplier = 0x00EECE66DL;
//##ModelId=3C8A23CF038A
const long Random::m_Addend = 0xBL;
//##ModelId=3C8A23CF034B
const long Random::m_Mask = (1L << BITS) - 1L;

//##ModelId=3C8A23D0003E
long                
Random::Next(int a_Bits) {
    long nextseed;
    long result;
    nextseed = (m_Seed*m_Multiplier + m_Addend) & m_Mask;
    result = (nextseed >> (BITS - a_Bits));
    return result;
}
