// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_EXPORTERMANAGER_3C89D34C00AB_INCLUDED
#define _INC_EXPORTERMANAGER_3C89D34C00AB_INCLUDED

class AbstractExporter;

//##ModelId=3C89D34C00AB
class ExporterManager {
public:
	//##ModelId=3C8BD9B503A9
	AbstractExporter*       GetExporter(const QString* apName);
};

#endif /* _INC_EXPORTERMANAGER_3C89D34C00AB_INCLUDED */

