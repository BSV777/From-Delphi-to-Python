// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "HtmlRepresentationSerializer.h"

#include <qtextstream.h>

//##ModelId=3CA6C9970222
HtmlRepresentationSerializer::HtmlRepresentationSerializer() {
    m_String = "";
}

//##ModelId=3CA6C9970232
HtmlRepresentationSerializer::~HtmlRepresentationSerializer() {
    m_String = "";
}

//##ModelId=3CA6C9970177
bool 
HtmlRepresentationSerializer::Serialize(const QDomDocument& arcDocument) {
    if (arcDocument.isNull()) {
        return false;
    }
    if (!m_String.isEmpty()) {
        return false;
    }

    QTextStream     stream(m_String, IO_WriteOnly);

    QDomElement   root;
    root = arcDocument.documentElement();
    if (root.isNull()) {
        return false;
    }

    root.save(stream, 0);
	return true;
}

//##ModelId=3CA6C99701A5
QString 
HtmlRepresentationSerializer::GetString() const {
	return m_String;
}

//##ModelId=3CA6C99701C5
bool 
HtmlRepresentationSerializer::Save(const QString& arcName) {
    QFile           file;
    bool            result = false;
    const char*     data = NULL;
    unsigned int    length = 0;
    int             saved = -1;

    if (m_String.isEmpty()) {
        return false;
    }

    file.setName(arcName);
    result = file.open(IO_WriteOnly);
    if (!result) {
        return false;
    }

    data    = (const char*)m_String;
    length  = m_String.length();
    saved   = file.writeBlock(data, length);
    if (saved != length) {
        result = false;
    }
    else {
        result = true;
    }

    file.flush();
    file.close();
	return result;
}

//##ModelId=3CA6C9970203
bool 
HtmlRepresentationSerializer::Close() {
    m_String = "";
	return true;
}
