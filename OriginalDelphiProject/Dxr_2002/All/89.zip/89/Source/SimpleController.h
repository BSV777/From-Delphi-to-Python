// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_SIMPLECONTROLLER_3C8BDDDE0399_INCLUDED
#define _INC_SIMPLECONTROLLER_3C8BDDDE0399_INCLUDED

#include "Controller.h"

#include "Model.h"
#include "Command.h"
#include "CommandFactory.h"

class SaverManager;
class LoaderManager;
class ExporterManager;

static const int NONE           = 0x00000000;
static const int LEFT_BUTTON    = 0x00000001;
static const int MIDDLE_BUTTON  = 0x00000002;
static const int RIGHT_BUTTON   = 0x00000004;

//##ModelId=3C8BDDDE0399
class SimpleController : public Controller {
public:
	//##ModelId=3C8BDEAA02EE
	                        SimpleController();

	//##ModelId=3C8BDEAA030D
	virtual                 ~SimpleController();

	//##ModelId=3C8BDEA90399
	virtual void            LButtonPressed(const QPoint* apcPoint);

	//##ModelId=3C8BDEA903B9
	virtual void            LButtonReleased(const QPoint* apcPoint);

	//##ModelId=3C8BDEA903D8
	virtual void            MouseMove(QPoint* apoordinate);

	//##ModelId=3C8BDEAA002E
	virtual void            SnapToGrid(bool aSnap);

	//##ModelId=3C8BDEAA007D
	virtual void            CreateNew();

	//##ModelId=3C8BDEAA009C
	virtual bool            CanSave() const;

	//##ModelId=3C8BDEAA00CB
	virtual void            SetName(const QString* apNewName);

	//##ModelId=3C8BDEAA0119
	virtual bool            Save();

	//##ModelId=3CA6E35E02AF
    virtual bool            Export(const QString* apFileName);

	//##ModelId=3C8BDEAA0138
	virtual bool            Load(const QString* apNewName);

	//##ModelId=3CA38CA7030D
    virtual bool            IsChanged() const;

	//##ModelId=3C8BDEAA0196
	virtual void            Undo();

	//##ModelId=3C8BDEAA01B5
	virtual void            Redo();

	//##ModelId=3C8BDEAA01E4
	virtual bool            CanUndo() const;

	//##ModelId=3C8BDEAA0203
	virtual bool            CanRedo() const;

	//##ModelId=3C8BDEAA0232
	virtual void            SetModel(Model* apModel);

	//##ModelId=3C934D2000EA
	inline virtual Model*   GetModel();

    //##ModelId=3C8BDEAA0290
	virtual void            SetView(View* apView);

	//##ModelId=3C934D2000CB
    inline virtual View*    GetView();

	//##ModelId=3C9A59C40157
    inline virtual int      GetGridSize() const;

	//##ModelId=3C9A59C40119
    inline virtual void     SetGridSize(const int aNewGridSize);

	//##ModelId=3C9A59C400DA
    inline virtual void     SetCreateLabelMode(bool aCreateLabelMode = true);

	//##ModelId=3C9A59C4009C
    inline virtual void     SetCreateTextEditMode(bool aCreateTextEditMode = true);

	//##ModelId=3C9A59C4005D
    inline virtual void     SetCreateButtonMode(bool aCreateButtonMode = true);

	//##ModelId=3CA0DD88033C
    inline virtual CreateMode 
                            GetCreateMode() const;

	//##ModelId=3CA0DD88032C
    void                    Delete();

private:
	//##ModelId=3C8BDFE50177
    virtual bool            AssertSanity() const;

private:
	//##ModelId=3C8BDFE50169
	View*                   m_pActiveView;

	//##ModelId=3C8BDFE50157
	Model*                  m_pModel;

	//##ModelId=3C8BDDF4011B
	SaverManager*           m_pSaverManager;

	//##ModelId=3C8BDFE50148
	ExporterManager*        m_pExporterManager;

	//##ModelId=3C8BDDF90198
	LoaderManager*          m_pLoaderManager;

	//##ModelId=3C9A59C4002E
    int                     m_GridSize;

	//##ModelId=3C9A59C40003
    int                     m_ButtonState;

	//##ModelId=3C9A59C40000
    Command*                m_PreparedCommand;

	//##ModelId=3CA0DD8802F3
    bool                    m_SnapToGrid;

	//##ModelId=3CA0DD8802F0
    CreateMode              m_CreateMode;

	//##ModelId=3CA38CA702BF
    long                    m_OldHash;
};

//##ModelId=3C934D2000EA
inline 
Model*
SimpleController::GetModel() {
    return m_pModel;
}

//##ModelId=3C934D2000CB
inline 
View*
SimpleController::GetView() { 
    return m_pActiveView;
}

inline
int
SimpleController::GetGridSize() const {
    return m_GridSize;
}

inline
void
SimpleController::SetGridSize(const int aNewGridSize) {
    m_GridSize = aNewGridSize;
}

inline
void
SimpleController::SetCreateLabelMode(bool aCreateLabelMode) {
    const CommandFactory*   factory = NULL;

    delete m_PreparedCommand;
    m_PreparedCommand   = NULL;
    m_CreateMode        = CREATE_NOTHING;

    if (aCreateLabelMode) {
        factory = m_pModel->GetCommandFactory();
        if (factory != NULL) {
            m_PreparedCommand   = factory->CreateCLabelCommand();
            m_CreateMode        = CREATE_LABEL;
        }
    }
    else {
    }
}

inline
void
SimpleController::SetCreateTextEditMode(bool aCreateTextEditMode) {
    const CommandFactory* factory = NULL;

    delete m_PreparedCommand;
    m_PreparedCommand   = NULL;
    m_CreateMode        = CREATE_NOTHING;

    if (aCreateTextEditMode) {
        factory = m_pModel->GetCommandFactory();
        if (factory != NULL) {
            m_PreparedCommand   = factory->CreateCEditCommand();
            m_CreateMode        = CREATE_TEXTEDIT;
        }
    }
    else {
    }
}

inline
void
SimpleController::SetCreateButtonMode(bool aCreateButtonMode) {
    const CommandFactory* factory = NULL;

    delete m_PreparedCommand;
    m_PreparedCommand   = NULL;
    m_CreateMode        = CREATE_NOTHING;

    if (aCreateButtonMode) {
        factory = m_pModel->GetCommandFactory();
        if (factory != NULL) {
            m_PreparedCommand   = factory->CreateCButtonCommand();
            m_CreateMode        = CREATE_BUTTON;
        }
    }
    else {
    }
}

inline 
CreateMode
SimpleController::GetCreateMode() const {
    return m_CreateMode;
}


#endif /* _INC_SIMPLECONTROLLER_3C8BDDDE0399_INCLUDED */
