// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_DATALOADER_3C89D8450138_INCLUDED
#define _INC_DATALOADER_3C89D8450138_INCLUDED

#include "AbstractLoader.h"
#include "WidgetFactory.h"

#include <qstring.h>
#include <qdom.h>

const static char*          TEXTEDIT_ELEMENT_NAME       = "textedit";
const static char*          LABEL_ELEMENT_NAME          = "label";
const static char*          BUTTON_ELEMENT_NAME         = "button";
const static char*          TEXTEDIT_VALUE_ATTR_NAME    = "text";
const static char*          LABEL_VALUE_ATTR_NAME       = "text";
const static char*          BUTTON_VALUE_ATTR_NAME      = "caption";
const static char*          LEFT_ATTR_NAME              = "left";
const static char*          TOP_ATTR_NAME               = "top";
const static char*          WIDTH_ATTR_NAME             = "width";
const static char*          HEIGHT_ATTR_NAME            = "height";
const static unsigned int   MAX_FILE_LENGTH             = 1048576;

class AbstractParser;
class Widget;

//##ModelId=3C89D8450138
class DataLoader : public AbstractLoader {
public:
	//##ModelId=3CA567C500AB
	                        DataLoader(AbstractParser*  apParser,
                                       WidgetFactory*   apWidgetFactory);

	//##ModelId=3CA567C500DA
	virtual                 ~DataLoader();

	//##ModelId=3CA566FB0186
	virtual void            SetFileName(const QString* apcFilename);

	//##ModelId=3CA566FB008C
	virtual WidgetVector*   LoadFile(const QString* apcFilename);

	//##ModelId=3CA566FB00FA
	virtual WidgetVector*   LoadFile();

protected:
	//##ModelId=3CA630530290
    QDomDocument*           Parse(const QString* apcSource);

	//##ModelId=3CA630530218
    Widget*                 CreatFromNode(const QDomNode& arcNode);

private:
	//##ModelId=3CA566170290
    long                    GetType(const QChar*  apcCharacter);

	//##ModelId=3CA630530215
    QString                 m_Filename;

	//##ModelId=3CA630530208
    AbstractParser*         m_pParser;

	//##ModelId=3CA630530203
    WidgetFactory*          m_pWidgetFactory;
};

#endif /* _INC_DATALOADER_3C89D8450138_INCLUDED */
