// AppMainWindow.cpp: implementation of the AppMainWindow class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include <qapplication.h>

#include <qcombobox.h> 
#include <qpoint.h>
#include <qmessagebox.h>
#include <qscrollview.h>
#include <qtoolbutton.h>
#include <qfiledialog.h>

#include "appmainwindow.h"
#include "propertywindow.h"
#include "aboutwindowimpl.h"

#include "controller.h"
#include "model.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

AppMainWindow::AppMainWindow(QWidget* parent, 
                             const char* name, 
                             WFlags f) 
                             : QMainWindow(parent, name, f) {

    m_pPropertyWindow = NULL;
/*
    = new PropertyWindow(this,
                         "Property Editor",
                         WType_TopLevel);
*/
    BuildLayout();
    m_CurrentStyle = -1;
    SetMotifPlusStyle();
    resize(650, 500);
    showMaximized();

    m_pCentralView = new QScrollView(this);
    m_pCentralView->show();
    m_pCentralView->setResizePolicy(QScrollView::AutoOneFit);
    m_pCentralView->setVScrollBarMode(QScrollView::Auto);
    m_pCentralView->setHScrollBarMode(QScrollView::Auto);
    setCentralWidget(m_pCentralView);

    m_StretchingDocument = false;
    m_pModelViewport     = NULL;
}

AppMainWindow::~AppMainWindow() {
    CloseView();
}


void
AppMainWindow::SetController(Controller* apNewController) {
    if (m_pModelController != NULL) {
        delete m_pModelController;
    }
    m_pModelController = apNewController;
    if (m_pModelController != NULL) {
        ChangeGridSize(m_pGridSizeComboBox->currentText());
    }
}


/**
 * ����������� ������.
 */

void
AppMainWindow::paintEvent(QPaintEvent* apPaintEvent) {
    QMainWindow::paintEvent(apPaintEvent);
   
    if (m_pModelController == NULL) {
        return;
    }

    m_pUndo->setEnabled(m_pModelController->CanUndo());
    m_pRedo->setEnabled(m_pModelController->CanRedo());

    CreateMode mode = CREATE_NOTHING;

    mode = m_pModelController->GetCreateMode();
    if (mode = CREATE_NOTHING) {
        SetCreateLabel(false);
        SetCreateTextEdit(false);
        SetCreateButton(false);
    }

    if (m_pModelViewport != NULL) {
        QSize           size;
        size = m_pModelViewport->sizeHint();

        m_pCentralView->resizeContents(size.width(), 
                                       size.height());
    }
}

void
AppMainWindow::mousePressEvent(QMouseEvent* apMouseEvent) {
}

void
AppMainWindow::mouseReleaseEvent(QMouseEvent* apMouseEvent) {
    int     new_state = NoButton;
    int     diff_state = NoButton;
    
    diff_state  = apMouseEvent->button() & MouseButtonMask;
    new_state   = apMouseEvent->stateAfter() & MouseButtonMask;

    //Check for left button pressed.
    if ((diff_state & LeftButton) != 0) {
        //The left button was release.
    }

    //Check for left key pressed.
    if ((diff_state & RightButton) != 0) {
        //The right button was release.
    }
    m_MouseState = new_state;
}

void
AppMainWindow::mouseMoveEvent(QMouseEvent* apMouseEvent) {
}

void
AppMainWindow::New() {
    Close();
    CreateView();
}

void
AppMainWindow::Open() {
    if (m_pModelController == NULL) {
        return;
    }

    const static int    save = 0;
    const static int    cancel = 1;
    const static int    leave = 2;

    int                 result = leave;
    bool                model_changed = false;

    model_changed = m_pModelController->IsChanged();
    if (model_changed) {
        result = QMessageBox::information(this,
                                          "Attention",
                                          "The document has been changed since the last save.",
                                          "Save now",
                                          "Cancel",
                                          "Leave anyway",
                                          0,
                                          1);
    }

    if (result == save) {
        SaveAs();
        result = leave;
    }
    if (result == leave) {
        QString filename = QFileDialog::getOpenFileName(NULL,
                                                        "*.dat",
                                                        this);
        if (filename.isEmpty()) {
            QMessageBox::warning(NULL,
                                 "File load error",
                                 "Loading aborted!");
        } 
        else {
            Close();
            CreateView();
            m_pModelController->Load(&filename);
            if (m_pModelViewport == NULL) {
                m_pModelViewport->Notify();
            }
        }
    }
    else {
    }
}

void
AppMainWindow::Save() {
    if (m_pModelController == NULL) {
        return;
    }

    if (m_pModelController->CanSave()) {
        m_pModelController->Save();
    }
    else {
/*
        QMessageBox::critical(NULL,
                              "File save error",
                              "Document cann't be saved!");
*/
        SaveAs();
    }

}

void
AppMainWindow::SaveAs() {
    if (m_pModelController == NULL) {
        return;
    }

    Model*          model = NULL;
    const QString*  name = NULL;

    model = m_pModelController->GetModel();

    if (model != NULL) {
        name = model->GetName();
    }

    if (name == NULL) {
        name = new QString("");
    }
    else {
        name = new QString(*name);
    }

    QString filename;
    filename = QFileDialog::getSaveFileName(*name,
                                            "*.dat",
                                            this );

    delete name;
    name = NULL;

    if (filename.isEmpty()) {
        QMessageBox::warning(NULL,
                             "File save error",
                             "Saving aborted!");
    } 
    else {
        m_pModelController->SetName(&filename);
        Save();
    }
}

void
AppMainWindow::Close() {
    if (m_pModelController != NULL) {
        const static int    save = 0;
        const static int    cancel = 1;
        const static int    leave = 2;

        int                 result = leave;
        bool                model_changed = false;

        model_changed = m_pModelController->IsChanged();

        if (model_changed) {
            result = QMessageBox::information(this,
                                              "Attention",
                                              "The document has been changed since the last save.",
                                              "Save now",
                                              "Cancel",
                                              0,
                                              1);
        }

        if (result == save) {
            SaveAs();
        }
    }

    CloseView();
    SetShowGridState(false);
    SetSnapToGridState(false);
    SetCreateLabel(false);
    SetCreateTextEdit(false);
    SetCreateButton(false);
}

void
AppMainWindow::Export() {
    if (m_pModelController == NULL) {
        return;
    }

    QString filename;
    filename = QFileDialog::getSaveFileName(QString::null,
                                            "*.html",
                                            this );

    if (filename.isEmpty()) {
        QMessageBox::warning(NULL,
                             "File export error",
                             "Export aborted!");
    } 
    else {
        bool result = false;
        result = m_pModelController->Export(&filename);

        if (!result) {

            QMessageBox::warning(NULL,
                                 "File export error",
                                 "Error occured while file exporting!");

        }
    }

}

void
AppMainWindow::Quit() {
    qApp->quit();
}

void
AppMainWindow::Redo() {
    if (m_pModelController != NULL) {
        m_pModelController->Redo();
    }
}

void
AppMainWindow::Undo() {
    if (m_pModelController != NULL) {
        m_pModelController->Undo();
    }
}

void
AppMainWindow::About() {
    AboutWindow about(NULL, "About", true);
    about.exec();
}

void
AppMainWindow::AboutQt() {
    QMessageBox::aboutQt(this, "DX Russia competition task");
}
