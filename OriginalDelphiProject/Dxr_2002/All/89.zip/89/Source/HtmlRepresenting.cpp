// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "HtmlRepresenting.h"

#include <qstring.h>

//##ModelId=3CA6E320007D
HtmlRepresenting::HtmlRepresenting() {
    m_DocumentPrepared  = false;
    m_RasterPrepared    = false;
    m_RowPrepared       = false;
}

//##ModelId=3CA6E320009C
HtmlRepresenting::~HtmlRepresenting() {
}


//##ModelId=3CA7299900AB
bool 
HtmlRepresenting::CreateNewRaster() {
    m_Document  = QDomDocument("document");
    m_Root      = m_Document.createElement("html");
    m_Body      = m_Document.createElement("body");
    m_Document.appendChild(m_Root);

    QDomElement head;
    QDomElement item;
    QDomText    value;
    head  = m_Document.createElement("head");
    m_Root.appendChild(head);
    item  = m_Document.createElement("title");
    value = m_Document.createTextNode("title");
    value.setNodeValue("Competition task");
    item.appendChild(value);
    head.appendChild(item);
    m_Root.appendChild(m_Body);
    m_DocumentPrepared = true;

    QString     attr_name;
    QString     attr_value;
    m_Raster    = m_Document.createElement("table");

    attr_name   = "border";
    attr_value  = "0";
    m_Raster.setAttribute(attr_name, attr_value);

    attr_name   = "cellpadding";
    attr_value  = "0";
    m_Raster.setAttribute(attr_name, attr_value);

    attr_name   = "cellspacing";
    attr_value  = "0";
    m_Raster.setAttribute(attr_name, attr_value);
    m_Body.appendChild(m_Raster);
    m_RasterPrepared  = true;
	return true;
}

//##ModelId=3CA7299900CB
bool 
HtmlRepresenting::CreateNewRow() {
    if (!m_RasterPrepared) {
        return false;
    }
    m_Row = m_Document.createElement("tr");
    QString     attr_name;
    QString     attr_value;

    attr_name   = "cellpadding";
    attr_value  = "0";
    m_Row.setAttribute(attr_name, attr_value);
    m_Raster.appendChild(m_Row);
    m_RowPrepared   = true;
    return true;
}

//##ModelId=3CA7299900EA
bool
HtmlRepresenting::InsertNewCell(const QSize&    arSize,
                                const Widget*   apcObject) {

    if (!m_RowPrepared) {
        return false;
    }

    const QString*  value = NULL;
    const QRect*    rect = NULL;
    int             type = 0;

    if (apcObject != NULL) {
        rect    = apcObject->GetPosition();
        value   = apcObject->GetValue();
        type    = apcObject->GetType();
    }

    QDomElement cell;
    QDomElement data;
    QDomText    text_elem;
    QString     attr_name;
    QString     attr_value;
    QString     string;

    cell = m_Document.createElement("td");

    if (value != NULL) {
        attr_name   = "bgcolor";
        attr_value  = "green";
        cell.setAttribute(attr_name, attr_value);
    }

    attr_name = "colspan";
    cell.setAttribute(attr_name, arSize.width());

    attr_name = "rowspan";
    cell.setAttribute(attr_name, arSize.height());

    if (value != NULL) {
        if (type == LABEL_WIDGET) {
            data = m_Document.createElement("div");
            text_elem = m_Document.createTextNode("label");
            text_elem.setNodeValue(*value);
            data.appendChild(text_elem);
        }
        else if (type == TEXTEDIT_WIDGET) {
            data = m_Document.createElement("input");
            attr_name   = "type";
            attr_value  = "text";
            data.setAttribute(attr_name, attr_value);

            attr_name   = "value";
            attr_value  = *value;
            data.setAttribute(attr_name, attr_value);

            attr_name   = "style";
            string.setNum(arSize.width());
            attr_value  = "width: " + string + "; height: ";
            string.setNum(arSize.height());
            attr_value  = attr_value + string;
            data.setAttribute(attr_name, attr_value);
        }
        else if (type == BUTTON_WIDGET) {
            data = m_Document.createElement("input");
            attr_name   = "type";
            attr_value  = "button";
            data.setAttribute(attr_name, attr_value);

            
            attr_name   = "value";
            attr_value  = *value;
            data.setAttribute(attr_name, attr_value);

            attr_name   = "style";
            string.setNum(arSize.width());
            attr_value  = "width: " + string + "; height: ";
            string.setNum(arSize.height());
            attr_value  = attr_value + string;
            data.setAttribute(attr_name, attr_value);
        }


    }
/*
    data = m_Document.createElement("input");
    attr_name   = "src";
    attr_value  = "0.gif";
    data.setAttribute(attr_name, attr_value);

    attr_name   = "width";
    attr_value  = "1";
    data.setAttribute(attr_name, attr_value);
        

    attr_name   = "height";
    attr_value  = "1";
    data.setAttribute(attr_name, attr_value);
*/        

    cell.appendChild(data);
    m_Row.appendChild(cell);
	return true;
}

//##ModelId=3CA729990157
bool 
HtmlRepresenting::CloseRow() {
    if (m_RowPrepared) {
        m_RowPrepared = false;
        return true;
    }
    else {
        return false;
    }
}

//##ModelId=3CA729990177
bool 
HtmlRepresenting::CloseRaster() {
    if (m_RasterPrepared) {
        m_RasterPrepared = false;
        return true;
    }
    else {
        return false;
    }
}

//##ModelId=3CA7299901A5
QDomDocument 
HtmlRepresenting::GetDocument() {
	return m_Document;
}


