// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"

#include <qmessagebox.h> 

#include "SimpleController.h"

#include "Model.h"
#include "View.h"
#include "Widget.h"
#include "Command.h"

#include "AbstractLoader.h"
#include "LoaderManager.h"

#include "AbstractSaver.h"
#include "SaverManager.h"

#include "AbstractExporter.h"
#include "ExporterManager.h"

#include "MouseLabelWidget.h"
#include "MarkerWidget.h"
#include "WidgetFactory.h"

//##ModelId=3C8BDEAA02EE
SimpleController::SimpleController() {
    m_pActiveView       = NULL;
    m_pModel            = NULL;
    m_pSaverManager     = NULL;
    m_pExporterManager  = NULL;
    m_pLoaderManager    = NULL;

    m_ButtonState       = NONE;
    m_PreparedCommand   = NULL;

    m_pLoaderManager    = new LoaderManager();
    m_pSaverManager     = new SaverManager();
    m_pExporterManager  = new ExporterManager();

    m_SnapToGrid        = false;
    m_CreateMode        = CREATE_NOTHING;

    m_OldHash           = 0x00000000;
}

//##ModelId=3C8BDEAA030D
SimpleController::~SimpleController() {
    if (m_pModel != NULL) {
        delete m_pModel;
        m_pModel = NULL;
    }

    if (m_pActiveView != NULL) {
        delete m_pActiveView;
        m_pActiveView = NULL;
    }
    delete m_PreparedCommand;
    m_PreparedCommand = NULL;

    delete m_pSaverManager;
    delete m_pExporterManager;
    delete m_pLoaderManager;
    m_pSaverManager = NULL;
    m_pExporterManager = NULL;
    m_pLoaderManager = NULL;
}

//##ModelId=3C8BDEAA0232
void 
SimpleController::SetModel(Model* apModel) {
    if (m_pModel != NULL) {
        m_pModel->UnSubscribe(m_pActiveView);
    }
    m_pModel = apModel;
    if (m_pModel != NULL) {
        m_pModel->Subscribe(m_pActiveView);
    }
    else {
        m_OldHash = 0x00000000;
    }
}

//##ModelId=3C8BDEAA0290
void 
SimpleController::SetView(View* apView) {
    if (m_pModel != NULL) {
        m_pModel->UnSubscribe(m_pActiveView);
    }
    m_pActiveView = apView;
    if (m_pModel != NULL) {
        m_pModel->Subscribe(m_pActiveView);
    }
}

//##ModelId=3C8BDEA90399
void
SimpleController::LButtonPressed(const QPoint* apcPoint) {
    m_ButtonState = m_ButtonState | LEFT_BUTTON;

    if (!AssertSanity()) {
        return;
    }

    if (apcPoint == NULL) {
        return;
    }

    Widget*         root = NULL;
    Widget*         checked = NULL;
    MarkerWidget*   marker = NULL;
    QPoint          point_position = *apcPoint;

    root    = m_pModel->GetWidgetById(ROOT_WIDGET_ID);
    marker  = static_cast<MarkerWidget*>(m_pModel->GetWidgetById(MARKER_WIDGET_ID));
    checked = root->GetOwner(apcPoint);

    if (checked == NULL) {
        if (m_PreparedCommand != NULL) {
            QRect   prop;
            prop.moveTopLeft(*apcPoint);
            m_PreparedCommand->SetNewProperties(&prop);
        }
    }
    else {
        int type = -1;
        type = checked->GetType();
    }

    if (marker != NULL) {
        marker->AppendChild(checked);

        point_position.rx() = m_GridSize*(point_position.rx()/m_GridSize);
        point_position.ry() = m_GridSize*(point_position.ry()/m_GridSize);

        marker->MoveFrom(apcPoint);
    }

    m_pModel->PutCommand(m_PreparedCommand);
    m_PreparedCommand   = NULL;
    m_CreateMode        = CREATE_NOTHING;

    m_pActiveView->Notify();
}

//##ModelId=3C8BDEA903B9
void 
SimpleController::LButtonReleased(const QPoint* apcPoint) {
    m_ButtonState = m_ButtonState & !LEFT_BUTTON;
    if (!AssertSanity()) {
        return;
    }

    MouseLabelWidget*   mouse_label = NULL;
    Widget*             marker = NULL;
    Command*            command = NULL;

    marker      = m_pModel->GetWidgetById(MARKER_WIDGET_ID);
    mouse_label = static_cast<MouseLabelWidget*>(m_pModel->GetWidgetById(MOUSELABEL_WIDGET));
    if (mouse_label != NULL) {
        mouse_label->SetStatus(false);
    }
    if (marker != NULL) {
        command = marker->Commit();
        if (command != NULL) {
            m_pModel->PutCommand(command);
        }
    }
    m_pActiveView->Notify();
}

//##ModelId=3C8BDEA903D8
void 
SimpleController::MouseMove(QPoint* apoordinate) {
    if (!AssertSanity()) {
        return;
    }

    if (apoordinate == NULL) {
        return;
    }

    Widget*             root = NULL;
    MouseLabelWidget*   mouse_label = NULL;
    MarkerWidget*       marker = NULL;
    QRect               position;
    QPoint              point_position = *apoordinate;
    QPoint              offset(35, 35);

    point_position += offset;
    root        = m_pModel->GetWidgetById(ROOT_WIDGET_ID);
    mouse_label = static_cast<MouseLabelWidget*>(m_pModel->GetWidgetById(MOUSELABEL_WIDGET));
    marker      = static_cast<MarkerWidget*>(m_pModel->GetWidgetById(MARKER_WIDGET_ID));
    
    position.moveTopLeft(point_position);
    position.moveBottomRight(point_position);

    if (mouse_label != NULL) {
        if (((m_ButtonState & LEFT_BUTTON) != NONE) &&
            (marker->GetChild() != NULL)) {
            mouse_label->SetStatus(true);
            mouse_label->SetPosition(&position);
        }
        else {
            mouse_label->SetStatus(false);
        }
    }

    point_position = *apoordinate;
    int grid = m_GridSize;
    if (!m_SnapToGrid) {
        grid = 1;
    }
    if (marker != NULL) {
        Command*    resize_document_command = NULL;

        marker->MoveTo(&point_position, grid);
        resize_document_command = root->Commit();

        if (resize_document_command != NULL) {
            m_pModel->PutCommand(resize_document_command);
        }
    }
    m_pActiveView->Notify();
}

//##ModelId=3C8BDEAA002E
void 
SimpleController::SnapToGrid(bool aSnap) {
    if (!AssertSanity()) {
        return;
    }
    m_SnapToGrid = aSnap;
}

//##ModelId=3C8BDEAA007D
void 
SimpleController::CreateNew() {
    if (!AssertSanity()) {
        return;
    }
    Widget*     new_root = NULL;

    new_root = m_pModel->GetWidgetFactory()->CreateRootWidget();
    m_pModel->SetRootWidget(new_root);
    m_OldHash = m_pModel->GetHash();
}


void
SimpleController::Delete() {
    if (!AssertSanity()) {
        return;
    }

    Widget*                 root = NULL;
    MarkerWidget*           marker = NULL;
    Widget*                 active = NULL;
    const CommandFactory*   p_command_factory = NULL;
    Command*                p_command = NULL;


    root                = m_pModel->GetWidgetById(ROOT_WIDGET_ID);
    p_command_factory   = m_pModel->GetCommandFactory();
    marker              = static_cast<MarkerWidget*>(m_pModel->GetWidgetById(MARKER_WIDGET_ID));

    if ((marker == NULL) ||
        (p_command_factory == NULL)) {
        return;
    }

    active = marker->GetChild();
    if (active == NULL) {
        return;
    }

    p_command = p_command_factory->CreateDeleteObjectCommand();
    p_command->SetObject(active);
    m_pModel->PutCommand(p_command);
    m_pActiveView->Notify();
}

//##ModelId=3C8BDEAA009C
bool 
SimpleController::CanSave() const {
    if (!AssertSanity()) {
        return false;
    }

    const QString* model_name = m_pModel->GetName();;

    bool possible_to_save = true;

    if (model_name != NULL) {
        possible_to_save = !model_name->isEmpty();
    }
    else {
        possible_to_save = false;
    }

    return possible_to_save;
}

//##ModelId=3C8BDEAA00CB
void 
SimpleController::SetName(const QString* apNewName) {
    if (!AssertSanity()) {
        return;
    }
    if (apNewName != NULL) {
        m_pModel->SetName(apNewName);
    }
}

//##ModelId=3C8BDEAA0119
bool
SimpleController::Save() {
    if (!AssertSanity()) {
        return false;
    }

    if (!CanSave()) {
        return false;
    }

    AbstractSaver* saver = NULL;

    saver = m_pSaverManager->GetSaver();
    if (saver == NULL) {
        return false;
    }

    saver->SetName(m_pModel->GetName());
    saver->SaveModel(m_pModel);

    m_OldHash = m_pModel->GetHash();
    delete saver; 
    saver = NULL;
    return true;
}

bool
SimpleController::Export(const QString* apFileName) {
    if (m_pExporterManager == NULL) {
        return false;
    }
    if (m_pModel == NULL) {
        return false;
    }

    AbstractExporter*   exporter = NULL;
    exporter = m_pExporterManager->GetExporter(apFileName);
    
    if (exporter == NULL) {
        return false;
    }

    bool result = false;
    do {
        exporter->Initialize();
        exporter->SetName(apFileName);
        result = exporter->ExportModel(m_pModel);
        if (!result) {
            break;
        }
        result = exporter->Finish();
        if (!result) {
            break;
        }
    } while (false);

    delete exporter;
    exporter = NULL;

    return result;
}

//##ModelId=3C8BDEAA0138
bool 
SimpleController::Load(const QString* apNewName) {
    if (m_pModel == NULL) {
        return false;
    }
    if (m_pLoaderManager == NULL) {
        return false;
    }
    if (apNewName == NULL) {
        return false;
    }

    AbstractLoader* loader = NULL;

    loader = m_pLoaderManager->GetLoader(apNewName, 
                                         m_pModel->GetWidgetFactory());
    if (loader == NULL) {
        return false;
    }

    CreateNew();
    WidgetVector*       widgets = NULL;
    Widget*             root = NULL;
    WidgetIterator      iter;
    ConstWidgetIterator end;

    widgets = loader->LoadFile(apNewName);
    root = m_pModel->GetWidgetById(ROOT_WIDGET_ID);


    if ((widgets != NULL) &&
        (root != NULL)) {

        iter = widgets->begin();
        end  = widgets->end();

        for (; iter != end; iter++) {
            root->AppendChild(*iter);
        }
    }

    delete widgets;
    widgets = NULL;
   
    m_OldHash = m_pModel->GetHash();

    delete loader; 
    loader = NULL;
    return true;
}

bool
SimpleController::IsChanged() const {
    long    new_hash = 0x00000000;

    if (m_pModel != NULL) {
        new_hash = m_pModel->GetHash();
    }

    return (new_hash != m_OldHash);
}

//##ModelId=3C8BDEAA0196
void 
SimpleController::Undo() {
    if (!AssertSanity()) {
        return;
    }
    m_pModel->Undo(1);
    m_pModel->Activate(NULL);
    m_pActiveView->Notify();
}

//##ModelId=3C8BDEAA01B5
void 
SimpleController::Redo() {
    if (!AssertSanity()) {
        return;
    }
    m_pModel->Redo(1);
    m_pModel->Activate(NULL);
    m_pActiveView->Notify();
}

//##ModelId=3C8BDEAA01E4
bool 
SimpleController::CanUndo() const {
    if (!AssertSanity()) {
        return false;
    }
    return m_pModel->CanUndo();
}

//##ModelId=3C8BDEAA0203
bool 
SimpleController::CanRedo() const {
    if (!AssertSanity()) {
        return false;
    }
    return m_pModel->CanRedo();
}

//##ModelId=3C8BDFE50177
bool
SimpleController::AssertSanity() const {
    if (m_pActiveView == NULL) {
        return false;
    }

    if (m_pModel == NULL) {
        return false;
    }

    if (m_pSaverManager == NULL) {
        return false;
    }

    if (m_pLoaderManager == NULL) {
        return false;
    }

    if (m_pExporterManager == NULL) {
        return false;
    }
    return true;
}
