// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_RANDOM_3C8A078702FD_INCLUDED
#define _INC_RANDOM_3C8A078702FD_INCLUDED

#include <stdlib.h>

//##ModelId=3C8A078702FD
class Random {
public:
	//##ModelId=3C8A07A10222
	inline                  Random();

	//##ModelId=3C8A23D00167
    inline                  Random(long aSeed);

	//##ModelId=3C8A07A10242
	inline virtual          ~Random();

	//##ModelId=3C8A23D000FA
    inline void             SetSeed(long aSeed);

	//##ModelId=3C8A23D000CB
    long                    NextLong();

	//##ModelId=3C8A23D000AB
    int                     NextInt();
  
private:
	//##ModelId=3C8A23D0003E
    long                    Next(int a_Bits);

private:
	//##ModelId=3C8A23CF03C8
    static const long       m_Multiplier;
	//##ModelId=3C8A23CF038A
    static const long       m_Addend;
	//##ModelId=3C8A23CF034B
    static const long       m_Mask;
	//##ModelId=3C8A23CF030D
    long                    m_Seed;

};

//##ModelId=3C8A07A10222
inline
Random::Random() {
    SetSeed(rand());
}

//##ModelId=3C8A23D00167
inline
Random::Random(long aSeed) {
    SetSeed(aSeed);
}

//##ModelId=3C8A07A10242
inline
Random::~Random() {
}

//##ModelId=3C8A23D000FA
inline
void
Random::SetSeed(long aSeed) {
    m_Seed = aSeed;
}

//##ModelId=3C8A23D000CB
inline
long
Random::NextLong() {
    return static_cast<long>(((Next(16)) << 16) + Next(16));
}

//##ModelId=3C8A23D000AB
inline
int
Random::NextInt() {
    int result;
    long long_result;

    long_result = NextLong();
    if (sizeof(int) < sizeof(long)) {
        long_result = long_result & (1L << (sizeof(int)-1));
    }

    result = static_cast<int>(long_result);
    return result;
}
#endif /* _INC_RANDOM_3C8A078702FD_INCLUDED */
