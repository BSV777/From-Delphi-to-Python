// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "RasterSimpleMap.h"

#include "Widget.h"
#include "ExportMapRepresenting.h"

//##ModelId=3CA6BF38006D
RasterSimpleMap::RasterSimpleMap(ExportMapRepresenting* apMapRepresenting) {
    m_pRepresenting = apMapRepresenting;
    m_ppMap         = NULL;
    m_pcWidgetArr   = NULL;
    m_pRoot         = NULL;

    m_Size          = QSize(-1, -1);
}

//##ModelId=3CA6BF38007D
RasterSimpleMap::~RasterSimpleMap() {
    CloseMap();

    delete m_pcWidgetArr;
    m_pcWidgetArr   = NULL;

    delete m_pRepresenting;
    m_pRepresenting = NULL;
}

//##ModelId=3CA6BECC0138
bool 
RasterSimpleMap::CreateNewMap(const ConstWidgetVector* apcWidgets) {
    if (apcWidgets == NULL) {
        return false;
    }
    if (m_pRepresenting == NULL) {
        return false;
    }
    if (m_ppMap != NULL) {
        return false;
    }

    if (m_pcWidgetArr != NULL) {
        return false;
    }

    bool        success = false;

    m_pcWidgetArr = apcWidgets;
    GetSize();

    do {
        if (!m_Size.isValid()) {
            break;
        }

        int max_value = (1 << (sizeof(short)*8 - 1)) - 1;

        if ((m_Size.width()  >= max_value) ||
            (m_Size.height() >= max_value)) {
            break;
        }

        m_ppMap = new MapElement*[m_Size.width()];
        if (m_ppMap == NULL) {
            break;
        }

        int     index;
        success = true;
        for (index = 0; index < m_Size.width(); index++) {
            m_ppMap[index] = new MapElement[m_Size.height()];
            if (m_ppMap[index] == NULL) {
                success = false;
            }
        }
        if (!success) {
            break;
        }

        success = PrepareMap();
        if (!success) {
            break;
        }

        success = WriteWidgets();
        if (!success) {
            break;
        }

//        SetCellsData();

        success = ConvertMap();
        if (!success) {
            break;
        }

    } while (false);

    if (!success) {
        CloseMap();
    }
    return success;
}

//##ModelId=3CA6BECC0186
bool 
RasterSimpleMap::CloseMap() {
    delete m_pcWidgetArr;
    m_pcWidgetArr   = NULL;

    int index;
    for (index = 0; index < m_Size.width(); index++) {
        delete m_ppMap[index];
        m_ppMap[index] = NULL;
    }

    delete m_ppMap;

    m_ppMap         = NULL;
    m_Size          = QSize(-1, -1);
	return true;
}

//##ModelId=3CA6BECC01A5
QDomDocument 
RasterSimpleMap::GetRepresentation() {
    QDomDocument document;
    if (m_pRepresenting == NULL) {
        return document;
    }


    document = m_pRepresenting->GetDocument();
/*
    if (m_ppMap != NULL) {
        return document;
    }
    if (!m_Size.isValid()) {
        return document;
    }

    QString         string;
    QDomElement     root;
    QDomElement     item;

    string      = "document";
    document    = QDomDocument(string);
    root        = document.createElement("html");

    document.appendChild(root);
*/
	return document;
}

void
RasterSimpleMap::GetSize() {
    if (m_pcWidgetArr == NULL) {
        return;
    }

    ConstWidgetConstIterator    iter;
    ConstWidgetConstIterator    end;
    const Widget*               item = NULL;
    const QRect*                prop = NULL;
    int                         value;

    iter = m_pcWidgetArr->begin();
    end = m_pcWidgetArr->end();
    
    if (iter == NULL) {
        return;
    }

    for (; iter != end; iter++) {
        item = *iter;
        if (item == NULL) {
            continue;
        }
        prop = item->GetPosition();
        if (prop == NULL) {
            continue;
        }

        value = prop->right() + 1 + 2; // +1 ��� 0, +2 ��� ���������.
        if (m_Size.width() < value) {
            m_Size.setWidth(value);
        }

        value = prop->bottom() + 1 + 2; // +1 ��� 0, +2 ��� ���������.
        if (m_Size.height() < value) {
            m_Size.setHeight(value);
        }
    }
}

// ���������� (�������) �����. 
bool
RasterSimpleMap::PrepareMap() {
    if (m_ppMap == NULL) {
        return false;
    }

    if (!m_Size.isValid()) {
        return false;
    }

    register int    x;
    register int    y;
    MapElement*     row = NULL;
    bool            result = true;
    MapElement      templ = {-1, -1, 1, 1, -1, -1, -1};

    for (x = 0; x < m_Size.width(); x++) {
        templ.x_cell = x;
        templ.x = x;
        row = m_ppMap[x];
        if (row == NULL) {
            result = false;
            break;
        }
        for (y = 0; y < m_Size.height(); y++) {
            templ.y_cell = y;
            templ.y = y;
            row[y] = templ;
        }
    }

    return result;
}

// ��������� �������� �� �����. 
bool
RasterSimpleMap::WriteWidgets() {
    ConstWidgetConstIterator    iter;
    ConstWidgetConstIterator    end;
    const Widget*               item = NULL;
    bool                        result = false;
    bool                        written = false;


    iter = m_pcWidgetArr->begin();
    end = m_pcWidgetArr->end();
    
    if (iter == NULL) {
        return false;
    }
    else {
        if (iter != end) {
            m_pRoot = (*iter)->GetRoot();
        }
    }

    result = true;

    for (; iter != end; iter++) {
        item = *iter;
        if (item == NULL) {
            continue;
        }
        written = WriteWidget(item);
        result = result && written;
    }

    return result;
}

// ��������� ������� �� �����. 
bool
RasterSimpleMap::WriteWidget(const Widget* apcWidget) {
    register int    x = 0;
    register int    y = 0;
    int             object_x = 0;
    int             object_y = 0;
    int             object_last_x = 0;
    int             object_last_y = 0;
    const QRect*    prop = NULL;
    MapElement*     row = NULL;
    bool            another_object_present = false;
    long            id = -1;
    MapElement      templ;

    if (apcWidget == NULL) {
        return false;
    }

    prop            = apcWidget->GetPosition();
    id              = apcWidget->GetId();
    object_x        = prop->x() + 1;
    object_y        = prop->y() + 1;
    object_last_x   = prop->width() + object_x;
    object_last_y   = prop->height() + object_y;

    another_object_present = false;
    for (x = object_x; x < object_last_x; x++) {
        row = m_ppMap[x];
        for (y = object_y; y < object_last_y; y++) {
            if (row[y].id >= 0) {
                another_object_present = true;
                break;
            }
        }
        if (another_object_present) {
            break;
        }
    }

    if (another_object_present) {
        return false;
    }

    templ.id        = id;
    templ.x         = object_x;
    templ.y         = object_y;
    templ.width     = prop->width();
    templ.height    = prop->height();
    templ.x_cell    = -1;
    templ.y_cell    = -1;

    for (x = object_x; x < object_last_x; x++) {
        row = m_ppMap[x];
        templ.x_cell = x;
        for (y = object_y; y < object_last_y; y++) {
            templ.y_cell = y;
            row[y] = templ;
        }
    }

    return true;
}

// ������ �����. 
void
RasterSimpleMap::SetCellsData() {
    register int    x = 0;
    register int    y = 0;
    int             cell_x = 0;
    MapElement      element;
    QPoint          point;
    
    for (y = 0; y < m_Size.height(); y++) {
        cell_x = 0;
        for (x = 0; x < m_Size.width(); x++) {
            element = m_ppMap[x][y];

            element.x       = x;
            element.y       = y;
            element.x_cell  = x;
            element.y_cell  = y;
            m_ppMap[x][y]   = element;

            if (element.id >= 0) {
                point.setX(x);
                point.setY(y);
                SetObjectCellsData(point);
                x = point.x();
            }
        }
    }
}

// ��������� ����� ��� ������.
void
RasterSimpleMap::SetObjectCellsData(QPoint& arcFrom) {
    register int    x = 0;
    register int    y = 0;
    int             last_x = 0;
    int             last_y = 0;
    MapElement      element;

    x = arcFrom.x();
    y = arcFrom.y();

    element = m_ppMap[x][y];
    last_x = element.x + element.width;
    last_y = element.y + element.height;


    for (x = element.x; x <= last_x; x++) {
        element.x_cell = x;
        for (y = element.y; y <= last_y; y++) {
            element.y_cell = y;
            m_ppMap[x][y] = element;
        }
    }
    arcFrom.setX(last_x + 1);
}

bool
RasterSimpleMap::ConvertMap() {
    register int    x = 0;
    register int    y = 0;
    int             cell_x = 0;
    MapElement      element;
    MapElement      begin;
    QPoint          point;
    QSize           size;
    const Widget*   item = NULL;

    bool            result;

    if (m_pRepresenting == NULL) {
        return false;
    }

    if (m_pRoot == NULL) {
        return false;
    }

    result = m_pRepresenting->CreateNewRaster();

    if (!result) {
        return false;
    }

    for (y = 0; y < m_Size.height(); y++) {
        if (!m_pRepresenting->CreateNewRow()) {
            result = false;
            break;
        }
        begin = m_ppMap[0][y];
        for (x = 0; x < m_Size.width(); x++) {
            element = m_ppMap[x][y];

            if ((begin.id != element.id) ||
                (x == (m_Size.width() - 1)) ||
                (x == 1) ||
                (y == 1)) {
                if (begin.y == y) {
                    // ���������� ������ �������

                    item = m_pRoot->FindById(begin.id);
                    
                    size.setWidth(element.x_cell - begin.x_cell);
                    size.setHeight(begin.height);
                    result = m_pRepresenting->InsertNewCell(size, item);

                }
                else {
                    result = begin.height;
                    // ������� ������� (2-� � ����� ������)
                }
                begin = element;
            }
            else {
                // ���� ��� ��� �� ������.
            }
        }
        
        if (!m_pRepresenting->CloseRow()) {
            result = false;
            break;
        }
    }
    result = m_pRepresenting->CloseRaster();
    return result;
}