// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "ChangePropertiesCommand.h"

#include "Model.h"

//##ModelId=3C8A4921031C
ChangePropertiesCommand::ChangePropertiesCommand() {
    m_pOldValue = NULL;
    m_pOldProp  = NULL;
    m_pNewValue = NULL;
    m_pNewProp  = NULL;
    m_pObjectId = -1;
}

//##ModelId=3C8A4921032C
ChangePropertiesCommand::~ChangePropertiesCommand() {
    delete m_pOldValue;
    delete m_pOldProp;
    delete m_pNewValue;
    delete m_pNewProp;

    m_pOldValue = NULL;
    m_pOldProp  = NULL;
    m_pNewValue = NULL;
    m_pNewProp  = NULL;
}

//##ModelId=3C8A47EE00AB
bool
ChangePropertiesCommand::Execute() {
    bool    result = false;
    Widget* p_object = NULL;

    if (m_pModel == NULL) {
        return result;
    }

    if (m_pObjectId < 0) {
        return result;
    }

    if ((m_pOldValue == NULL) || 
        (m_pOldProp == NULL)) {
        return result;
    }

    if ((m_pNewValue == NULL) || 
        (m_pNewProp == NULL)) {
        return result;
    }

    if ((*m_pOldValue == *m_pNewValue) && 
        (*m_pOldProp == *m_pNewProp)) {
        return result;
    }

    p_object = m_pModel->GetWidgetById(m_pObjectId);
    
    if (p_object == NULL) {
        return result;
    }

    p_object->SetValue(m_pNewValue);
    p_object->SetPosition(m_pNewProp);
    result = true;

	return result;
}

//##ModelId=3C8A47EE00EA
bool
ChangePropertiesCommand::Unexecute() {
    bool    result = false;
    Widget* p_object = NULL;

    if (m_pModel == NULL) {
        return result;
    }

    if (m_pObjectId < 0) {
        return result;
    }

    p_object = m_pModel->GetWidgetById(m_pObjectId);

    if (p_object == NULL) {
        return result;
    }

    p_object->SetValue(m_pOldValue);
    p_object->SetPosition(m_pOldProp);
    result = true;

	return result;
}


void
ChangePropertiesCommand::SetObject(const Widget* apObject) {
    if (apObject != NULL) {
        m_pObjectId = apObject->GetId();
    }
}

//##ModelId=3C9B912500FA
void
ChangePropertiesCommand::SetNewValue(const QString* apValue) {
    delete m_pNewValue;
    m_pNewValue = NULL;

    if (apValue == NULL) {
        return;
    }

    m_pNewValue     = new QString;
    *m_pNewValue    = *apValue;
}

//##ModelId=3C9B912500DA
void
ChangePropertiesCommand::SetNewProperties(const QRect* apPosition) {
    delete m_pNewProp;
    m_pNewProp = NULL;

    if (apPosition == NULL) {
        return;
    }

    m_pNewProp = new QRect;
    *m_pNewProp = *apPosition;
}

//##ModelId=3C9B91250128
void
ChangePropertiesCommand::SetOldValue(const QString* apValue) {
    delete m_pOldValue;
    m_pOldValue = NULL;

    if (apValue == NULL) {
        return;
    }

    m_pOldValue     = new QString;
    *m_pOldValue    = *apValue;
}

//##ModelId=3C9B91250157
void
ChangePropertiesCommand::SetOldProperties(const QRect* apPosition) {
    delete m_pOldProp;
    m_pOldProp = NULL;

    if (apPosition == NULL) {
        return;
    }

    m_pOldProp = new QRect;
    *m_pOldProp = *apPosition;
}
