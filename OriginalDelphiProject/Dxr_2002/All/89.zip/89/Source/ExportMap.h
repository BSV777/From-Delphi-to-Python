// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_EXPORTMAP_3CA6B72E031C_INCLUDED
#define _INC_EXPORTMAP_3CA6B72E031C_INCLUDED

#include <qdom.h>

//##ModelId=3CA6B72E031C
class ExportMap {
public:
	//##ModelId=3CA6C03E001F
	inline virtual          ~ExportMap();

	//##ModelId=3CA6BCD002EE
	virtual bool            CreateNewMap(const ConstWidgetVector* apcWidgets) = 0;

	//##ModelId=3CA6BD630222
	virtual bool            CloseMap() = 0;

	//##ModelId=3CA6BE490157
	virtual QDomDocument    GetRepresentation() = 0;

};

//##ModelId=3CA6C03E001F
inline ExportMap::~ExportMap() {
}

#endif /* _INC_EXPORTMAP_3CA6B72E031C_INCLUDED */

