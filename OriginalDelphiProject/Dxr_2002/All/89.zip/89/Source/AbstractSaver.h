#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_ABSTRACTSAVER_3C89D324007D_INCLUDED
#define _INC_ABSTRACTSAVER_3C89D324007D_INCLUDED

#include "View.h"

//##ModelId=3C89D324007D
class AbstractSaver : public View {
public:
	//##ModelId=3CA567F10148
	inline virtual          ~AbstractSaver();

	//##ModelId=3CA38CA5035B
    virtual void            SetName(const QString* apcNewName) = 0;

	//##ModelId=3CA38CA5030D
    virtual const QString*  GetName() const = 0;

	//##ModelId=3CA38CA50232
    virtual bool            SaveModel(const Model* apcModel) = 0;
};

//##ModelId=3CA567F10148
inline
AbstractSaver::~AbstractSaver() {
}

#endif /* _INC_ABSTRACTSAVER_3C89D324007D_INCLUDED */
