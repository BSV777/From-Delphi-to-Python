// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "ExporterManager.h"

#include "AbstractExporter.h"
#include "UniversalExporter.h"

#include "ExportMap.h"
#include "RasterSimpleMap.h"

#include "RepresentationSerializer.h"
#include "HtmlRepresentationSerializer.h"

#include "ExportMapRepresenting.h"
#include "HtmlRepresenting.h"



//##ModelId=3C8BD9B503A9
AbstractExporter*
ExporterManager::GetExporter(const QString* apName) {
    RepresentationSerializer*   serializer = NULL;
    ExportMapRepresenting*      represinting = NULL;
    ExportMap*                  map = NULL;
    UniversalExporter*          exporter = NULL;

    serializer      = new HtmlRepresentationSerializer();
    represinting    = new HtmlRepresenting();
    map             = new RasterSimpleMap(represinting);
    exporter        = new UniversalExporter(map, serializer);
	return exporter;
}


