// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_SIMPLEPARSER_3CA573DA003E_INCLUDED
#define _INC_SIMPLEPARSER_3CA573DA003E_INCLUDED

#include "AbstractParser.h"
#include <qthread.h>
#include <qdom.h> 

static const long   NULL_VALUE              = 0x00000000;
static const long   SMALL_LETTER_VALUE      = 0x00000001;   // [a,z]
static const long   CAPITAL_LETTER_VALUE    = 0x00000002;   // [A,Z]
static const long   DIGIT_VALUE             = 0x00000004;   // {0123456789}
static const long   SPACE_VALUE             = 0x00000008;   // {' '}
static const long   NEWLINE_VALUE           = 0x00000010;   // {'\n', '\r'}
static const long   LEFT_CHEVRON_VALUE      = 0x00000020;   // {'<'}
static const long   RIGHT_CHEVRON_VALUE     = 0x00000040;   // {'>'}
static const long   UNDERSCORE_VALUE        = 0x00000080;   // {'_'}
static const long   LEFT_BRAKET_VALUE       = 0x00000100;   // {'('}
static const long   RIGHT_BRAKET_VALUE      = 0x00000200;   // {')'}
static const long   QUOTES_VALUE            = 0x00000400;   // {'\"'}
static const long   SEMICOLON_VALUE         = 0x00000800;   // {';'}
static const long   ASSIGN_VALUE            = 0x00001000;   // {'='}
static const long   DELIMITER_VALUE         = 0x00008000;   // {...}
static const long   UNKNOWN_VALUE           = 0x80000000;

static const long   LETTER_VALUE            = SMALL_LETTER_VALUE | CAPITAL_LETTER_VALUE;
static const long   WHITESPACE_VALUE        = SPACE_VALUE | NEWLINE_VALUE;
static const long   FIRST_CHARACTER_OF_NAME = LETTER_VALUE | UNDERSCORE_VALUE;
static const long   OTHER_CHARACTER_OF_NAME = LETTER_VALUE | UNDERSCORE_VALUE | DIGIT_VALUE;

#define MAX_ELEMENT_NAME 512

//##ModelId=3CA573DA003E
class SimpleParser : public AbstractParser {
public:
	//##ModelId=3CA5749E02CE
	                        SimpleParser();

	//##ModelId=3CA5749E02DE
	virtual                 ~SimpleParser();

	//##ModelId=3CA5749E0271
	virtual QDomDocument*   Parse(const char*   apcSource);

private:
	//##ModelId=3CA6304F0128
    long                    GetType(const char  apcCharacter);
	//##ModelId=3CA6304F010A
    unsigned int            SkipWhiteSpace(const char*      apString, 
                                           unsigned int     aFrom = 0);

	//##ModelId=3CA6304F00FA
    bool                    ParseElement(const char*        apcString, 
                                         unsigned int*      apFrom);

	//##ModelId=3CA6304F00DB
    QDomAttr                ParseAttribute(const char*      apcString, 
                                           unsigned int*    apFrom);

	//##ModelId=3CA6304F00CB
    QString                 SubString(const char*           apcString,
                                      int                   apFirstIndex,
                                      int                   apLength);
private:
	//##ModelId=3CA6304F00BB
    int                     m_ErrorCount;
	//##ModelId=3CA6304F00B5
    bool                    n_ErrorPresent;

	//##ModelId=3CA6304F00B2
    QDomDocument*           m_pDocument;

	//##ModelId=3CA6304F00AD
    QDomElement             m_CurrentElement;

	//##ModelId=3CA6304F009E
    QMutex                  m_Synchronizer;
};

#endif /* _INC_SIMPLEPARSER_3CA573DA003E_INCLUDED */
