#include "aboutwindowimpl.h"

AboutWindow::AboutWindow(QWidget* parent,
                         const char* name,
                         bool modal, 
                         WFlags fl) 
                         : AboutWindowBase(parent, 
                                           name,
                                           modal,
                                           fl) {
}

/*  
 *  Destroys the object and frees any allocated resources
 */
//##ModelId=3C8BD4EB0244
AboutWindow::~AboutWindow() {
    // no need to delete child widgets, Qt does it all for us
}

