// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "CentralSensitivePoint.h"

#include <qpoint.h>
#include <qrect.h>

//##ModelId=3CA21A720203
QRect
CentralSensitivePoint::CalculatePosition(const QRect* apPosition) {
	return *apPosition;
}

//##ModelId=3CA21C690109
void 
CentralSensitivePoint::MoveFrom(const QPoint* apDeparturePoint) {
    if (apDeparturePoint == NULL) {
        return;
    }
    m_DeparturePoint = *apDeparturePoint;
}

//##ModelId=3CA23651030D
bool 
CentralSensitivePoint::MoveTo(Widget*       apObject, 
                              const QPoint* apcDestinationPoint, 
                              int           aGridSize) {
    QPoint      delta;
    QRect       old_posit;
    QRect       new_posit;
    Widget*     root = NULL;
    bool        is_valid = false;
    bool        result = false;

    if (apObject == NULL) {
        return false;
    }

    if (apcDestinationPoint == NULL) {
        return false;
    }

    if (aGridSize < 0) {
        return false;
    }

    delta = (*apcDestinationPoint) - m_DeparturePoint;
    old_posit = *(apObject->GetPosition());
    new_posit = old_posit;
    new_posit.moveBy(delta.x(), delta.y());

    delta.setX(aGridSize - new_posit.x()%aGridSize);
    delta.setY(aGridSize - new_posit.y()%aGridSize);
    new_posit.moveBy(delta.x(), delta.y());


    apObject->SetPosition(&new_posit);

    root = apObject->GetRoot();
    if (root != NULL) {
        is_valid = root->IsValidWidget(apObject);
    }
    if (!is_valid) {
        // ���� ������ �� �������, �� ���������� �����.
        apObject->SetPosition(&old_posit);
    }
    else {
        // 
        m_DeparturePoint = (*apcDestinationPoint);
        m_DeparturePoint = m_DeparturePoint + delta;
        result = true;
    }

    Widget*     tool_tip = NULL;
    QString     tool_tip_value;
    QString     x_position;
    QString     y_position;

    tool_tip = root->FindById(MOUSELABEL_WIDGET_ID);
    x_position.setNum(apObject->GetPosition()->left());
    y_position.setNum(apObject->GetPosition()->top());
    tool_tip_value = x_position + "/" + y_position;

    tool_tip->SetValue(&tool_tip_value);
    
    return result;
}
