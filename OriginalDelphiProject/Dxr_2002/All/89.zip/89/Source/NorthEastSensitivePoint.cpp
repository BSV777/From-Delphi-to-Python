// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "NorthEastSensitivePoint.h"

#include <qpoint.h>
#include <qrect.h>

//##ModelId=3C93B33E0000
QRect
NorthEastSensitivePoint::CalculatePosition(const QRect* apPosition) {
    QRect result;
    if (apPosition != NULL) {
        result.setRect(apPosition->right() - 2,
                       apPosition->top() - 2,
                       5,
                       5);
    }
	return result;
}

//##ModelId=3CA21C61036B
void 
NorthEastSensitivePoint::MoveFrom(const QPoint* apDeparturePoint) {
}

//##ModelId=3CA2364C00AB
bool 
NorthEastSensitivePoint::MoveTo(Widget*         apObject, 
                                const QPoint*   apcDestinationPoint, 
                                int             aGridSize) {
    QPoint      rounded_point;
    QRect       old_posit;
    QRect       new_posit;
    Widget*     root = NULL;
    bool        is_valid = false;
    bool        result = false;

    do {
        if (apObject == NULL) {
            break;
        }

        if (apcDestinationPoint == NULL) {
            break;
        }

        if (aGridSize < 0) {
            break;
        }

        rounded_point = *apcDestinationPoint;
//        rounded_point.rx() -= rounded_point.x()%aGridSize;
//        rounded_point.ry() -= rounded_point.y()%aGridSize;
        rounded_point.rx() = rounded_point.x()/double(aGridSize) + 0.5;
        rounded_point.rx() *= aGridSize;

        rounded_point.ry() = rounded_point.y()/double(aGridSize) + 0.5;
        rounded_point.ry() *= aGridSize;

        old_posit = *(apObject->GetPosition());

        if ((old_posit.left() >= rounded_point.x()) ||
            (old_posit.bottom() <= rounded_point.y())) {
            break;
        }

        new_posit = old_posit;
        new_posit.setRight(rounded_point.rx());
        new_posit.setTop(rounded_point.ry());

        apObject->SetPosition(&new_posit);

        root = apObject->GetRoot();
        if (root != NULL) {
            is_valid = root->IsValidWidget(apObject);
        }
        if (!is_valid) {
            // ���� ������ �� �������, �� ���������� �����.
            apObject->SetPosition(&old_posit);
        }
        else {
            // 
            result = true;
        }
    } while (false);

    if (result) {
        Widget*     tool_tip = NULL;
        QString     tool_tip_value;
        QString     width;
        QString     height;

        tool_tip = root->FindById(MOUSELABEL_WIDGET_ID);
        width.setNum(apObject->GetPosition()->width());
        height.setNum(apObject->GetPosition()->height());
        tool_tip_value = "size: " + width + "x" + height;

        tool_tip->SetValue(&tool_tip_value);
    }
    
    return result;
}
