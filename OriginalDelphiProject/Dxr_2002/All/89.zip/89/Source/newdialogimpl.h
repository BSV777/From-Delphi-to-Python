#ifndef NEWDIALOG_H
#define NEWDIALOG_H
#include "newdialog.h"

class NewDialog : public NewDialogBase
{ 
    Q_OBJECT

public:
    NewDialog( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~NewDialog();

};

#endif // NEWDIALOG_H
