// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "SimpleView.h"

#include <qaccel.h>
#include <qpainter.h>
#include <qpixmap.h>
#include <qmessagebox.h>

#include <qmainwindow.h>

#include "Model.h"
#include "Controller.h"
#include "Widget.h"

#include "propertywindow.h"

//##ModelId=3C8D2862007D
SimpleView::SimpleView(QWidget* apParent, 
                       const char* name,
                       WFlags fl) 
                       : QWidget(apParent, 
                                 name,
                                 fl) {


    m_pCascadView           = NULL;

    m_pServicedModel        = NULL;
    m_pController           = NULL;
    m_Offset.rx()           = 0;
    m_Offset.ry()           = 0;
    m_WidgetSize.rwidth()   = 0;
    m_WidgetSize.rheight()  = 0;
    m_FrameSize.rwidth()    = 0;
    m_FrameSize.rheight()   = 0;

    m_pParent               = apParent;

    m_ShowGrid              = false;

    m_pSynchronizer = new QMutex(true);
    m_pTimer = new TimeController(this);
    m_pTimer->start();

    QAccel *a = new QAccel(this);        
    a->connectItem(a->insertItem(Key_Delete),
                   this,
                   SLOT(Delete()));
}

//##ModelId=3C8D2862009C
SimpleView::~SimpleView() {
    Model*  model = NULL;
    model = m_pServicedModel;
    m_pServicedModel = NULL;

    if (model != NULL) {
        model->UnSubscribe(this);
        model = NULL;
    }

    m_pController = NULL;

    m_pTimer->stop();
    m_pTimer->WainForFinish();
    delete m_pTimer;
    m_pTimer = NULL;

    delete m_pSynchronizer;
    m_pSynchronizer = NULL;
}

//##ModelId=3C8D2861032C
bool 
SimpleView::SetServicedModel(Model* apModel, bool aReset) {
    Model*  model = NULL;
    model = m_pServicedModel;

    if (m_pServicedModel == NULL) {
        m_pServicedModel = apModel;
        return true;
    } 
    else if (aReset) {
        m_pServicedModel = NULL;
        model->UnSubscribe(this);
        m_pServicedModel = apModel;
        return true;
    } else {
        return false;
    }
}

//##ModelId=3C8D28620000
bool 
SimpleView::SetController(Controller* apController, bool aReset) {
    m_pController = apController;
    return true;
}

//##ModelId=3C8D286003A9
void 
SimpleView::Notify() {
    if (m_pCascadView) {
        m_pCascadView->Notify();
    }
    m_pParent->repaint();
    m_pTimer->repaint();
}

//##ModelId=3C9317E1003E
void
SimpleView::SetFrameSize(int aWidth, int aHeight) {
    if ((aWidth > 0) && (aHeight > 0)) {
        m_FrameSize.rwidth() = aWidth;
        m_FrameSize.rheight() = aHeight;
        Recalculate();
    }
    repaint(false);
}

//##ModelId=3C9317E00167
void
SimpleView::paintEvent(QPaintEvent* apPaintEvent) {
    m_pSynchronizer->lock();
    QPixmap pm(size());
    pm.setOptimization(QPixmap::BestOptim);
    pm.fill(backgroundColor());
    m_pPainter = new QPainter();
    m_pPainter->begin(&pm, this);

//    PrepareBackground(m_pPainter);
    if (m_pServicedModel != NULL) {
        m_pServicedModel->Lock();
        m_pServicedModel->Draw(this);
        m_pServicedModel->UnLock();
    }
    m_pPainter->end();
    bitBlt(this, 0, 0, &pm);
    delete m_pPainter;
    m_pPainter = NULL;
    m_pSynchronizer->unlock();
}

void
SimpleView::mousePressEvent(QMouseEvent* apMouseEvent) {
    int     new_state = NoButton;
    int     diff_state = NoButton;
    QPoint  pos;

    pos         = apMouseEvent->pos();
    pos         = pos - Translate(0,0);
    diff_state  = apMouseEvent->button() & MouseButtonMask;
    new_state   = apMouseEvent->stateAfter() & MouseButtonMask;

    //Check for left button pressed.
    if ((diff_state & static_cast<int>(LeftButton)) != 0) {
        //The left button was press.
        m_pController->LButtonPressed(&pos);
    }

    //Check for left key pressed.
    if ((diff_state & RightButton) != 0) {
        //The right button was press.
    }
    m_MouseState = new_state;
}

void
SimpleView::mouseReleaseEvent(QMouseEvent* apMouseEvent) {
    int     new_state = NoButton;
    int     diff_state = NoButton;
    QPoint  pos;

    pos         = apMouseEvent->pos();
    pos         = pos - Translate(0,0);
    diff_state  = apMouseEvent->button() & MouseButtonMask;
    new_state   = apMouseEvent->stateAfter() & MouseButtonMask;

    //Check for left button pressed.
    if ((diff_state & LeftButton) != 0) {
        //The left button was press.
        m_pController->LButtonReleased(&pos);
    }

    //Check for left key pressed.
    if ((diff_state & RightButton) != 0) {
        //The right button was press.
    }
    m_MouseState = new_state;
}

void
SimpleView::mouseMoveEvent(QMouseEvent* apMouseEvent) {
    QPoint  pos;

    if ((m_MouseState & LeftButton) != 0) {
        pos = apMouseEvent->pos();
        pos = pos - Translate(0,0);
    }

    m_pController->MouseMove(&pos);
}

//##ModelId=3C9317E000BB
void
SimpleView::resizeEvent(QResizeEvent* apResizeEvent) {
    m_WidgetSize = apResizeEvent->size();
    Recalculate();
}

//##ModelId=3C9317E0006D
void
SimpleView::Recalculate() {
    int value = 0;
    
    value = (m_WidgetSize.height() - m_FrameSize.height())/2;
    m_Offset.ry() = max(value, BORDER_SIZE);

    value = (m_WidgetSize.width() - m_FrameSize.width())/2;
    m_Offset.rx() = max(value, BORDER_SIZE);
}

void
SimpleView::TimeController::run() {
    if (m_pViewport == NULL) {
        return;
    }
    do {
        msleep(30);
        if (m_IsChanger) {
            m_pViewport->repaint(false);
            m_IsChanger = false;
        }
    } while (!m_Finish);
    m_Finished.wakeAll();
}

void
SimpleView::Delete() {
    if (m_pController != NULL) {
        m_pController->Delete();
    }
}
