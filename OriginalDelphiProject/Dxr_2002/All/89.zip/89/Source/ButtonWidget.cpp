// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "ButtonWidget.h"
#include "View.h"
#include "Widget.h"

//##ModelId=3C89FC47030D
ButtonWidget::ButtonWidget() {
    SetId(GenerateId());
    m_Properties.setRect(0, 0, 0, 0);
    m_Value = "";
}

//##ModelId=3C89FC47031C
ButtonWidget::~ButtonWidget() {
}

//##ModelId=3C89F64601F4
bool 
ButtonWidget::Draw(View*& arpDestinationView) const {
    return arpDestinationView->DrawButton(this);
}

//##ModelId=3C89F6460232
const QRect* 
ButtonWidget::GetPosition() const {
    return &m_Properties;
}

//##ModelId=3C89F6460251
void 
ButtonWidget::SetPosition(const QRect* apcPosition) {
    if (apcPosition != NULL) {
        m_Properties = *apcPosition;
    }
    else {
        m_Properties.setRect(0, 0, 0, 0);
    }
}

//##ModelId=3C89F6460242
const QString* 
ButtonWidget::GetValue() const {
    return &m_Value;
}

//##ModelId=3C89F646029F
void 
ButtonWidget::SetValue(const QString* apcValue) {
    if (apcValue != NULL) {
        m_Value = *apcValue;
        m_Value.truncate(255);
    }
    else {
        m_Value = "";
    }
}

//##ModelId=3C89F6460280
Command* 
ButtonWidget::Commit() {
    return NULL;
}

//##ModelId=3C89F6460290
void 
ButtonWidget::Cancel() {
    m_Value = m_BackupValue;
    m_Properties = m_BackupProperties;
}

//##ModelId=3C8D33250203
Widget* 
ButtonWidget::FindById(long aId) {
    /* Check mine */
    if (aId == GetId()) {
        return this;
    }
    else {
        /* Look at the children */
        return NULL;
    }
}

const Widget* 
ButtonWidget::FindById(long aId) const {
    /* Check mine */
    if (aId == GetId()) {
        return this;
    }
    else {
        /* Look at the children */
        return NULL;
    }
}

//##ModelId=3C93CA1501D4
Widget* 
ButtonWidget::GetOwner(const QPoint* apPosition) {
    if (apPosition != NULL) {
        if (m_Properties.contains(*apPosition)) {
            return this;
        }
    }
	return NULL;
}

//##ModelId=3C9B9084036B
bool
ButtonWidget::IsValidWidget(const Widget* apExamineWidget) const {
    bool result = true;
    if (apExamineWidget == NULL) {
        return result;
    }
    if (apExamineWidget == this) {
        return result;
    }

    result = !m_Properties.intersects(*(apExamineWidget->GetPosition()));

    return result;
}

long
ButtonWidget::GetHash() const {
    long                hash = 0x5a273835;
    hash = hash ^ Widget::GetHash(&m_Value);
    hash = hash + Widget::GetHash(&m_Properties);
    return hash;
}
