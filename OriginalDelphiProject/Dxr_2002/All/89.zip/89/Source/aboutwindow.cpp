#include "aboutwindow.h"

#include <qlabel.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

static const char FACE[]        = "./XPM/face.xpm";
static const char TROLLTECH[]   = "./PICT/trolltech.gif";

AboutWindowBase::AboutWindowBase(QWidget* parent,
                                 const char* name,
                                 bool modal, 
                                 WFlags fl) 
                                 : QDialog(parent, 
                                           name,
                                           modal,
                                           fl) {

    QPixmap face(FACE);

    if (!name) {
        setName( "AboutWindowBase" );
    }
    resize(350, 200); 
    setProperty("sizePolicy", 
                QSizePolicy((QSizePolicy::SizeType)0,
                            (QSizePolicy::SizeType)0, 
                            sizePolicy().hasHeightForWidth()));
    setProperty("minimumSize", QSize(350, 200));
    setProperty("maximumSize", QSize(350, 200));
    setProperty("caption", tr("About"));
    setProperty("sizeGripEnabled", QVariant(FALSE, 0));


    // Create a label containing a QMovie
    m_Movie      = QMovie(TROLLTECH);
    m_pTrollTech = new QLabel(this, "m_pTrollTech");
    m_pTrollTech->setFrameStyle(QFrame::Box | QFrame::Plain);
    m_pTrollTech->setMovie(m_Movie);
    m_pTrollTech->setGeometry(QRect(20, 20, 120, 60)); 
    m_pTrollTech->setFixedSize(120, 60);

    m_pFace = new QLabel(this, "m_pFace");
    m_pFace->setGeometry(QRect(260, 110, 60, 60)); 
    m_pFace->setProperty("pixmap", face);
    m_pFace->setProperty("scaledContents", QVariant(TRUE, 0));

    m_pDescription = new QLabel(this, "m_pDescription");
    m_pDescription->setGeometry(QRect( 20, 90, 220, 90)); 
    m_pDescription->setProperty("text", tr("This editor can save a result in the stanges\nformat and can export to the HTML\n\nPS In the project was use the Qt 2.3 as a \ngraphical library  (www.trolltech.com)"));

    m_pName = new QLabel(this, "m_pName");
    m_pName->setGeometry(QRect(160, 20, 170, 60)); 
    m_pName->setProperty("text", tr("<b>Simple editor.</b><br>\nversion 0.1.0 by Eugene Gusev"));
}

/*  
 *  Destroys the object and frees any allocated resources
 */
//##ModelId=3C8BD4E80169
AboutWindowBase::~AboutWindowBase() {
    // no need to delete child widgets, Qt does it all for us
}

