// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "DeleteObjectCommand.h"

#include <qrect.h>
#include <qstring.h>

#include "Model.h"
#include "Widget.h"
#include "WidgetFactory.h"

//##ModelId=3C8A490D000F
DeleteObjectCommand::DeleteObjectCommand() {
    m_ObjectId = -1;
    m_pProperties = NULL;
    m_pValue = NULL;
    m_pModel = NULL;
    m_ObjectType = UNKNOWN_WIDGET;
}

//##ModelId=3C8A490D001F
DeleteObjectCommand::~DeleteObjectCommand() {
    delete m_pProperties;
    delete m_pValue;
    m_pProperties = NULL;
    m_pValue = NULL;

    m_pModel = NULL;
}

void
DeleteObjectCommand::SetObject(const Widget* apObject) {
    if (apObject != NULL) {
        m_ObjectId = apObject->GetId();
        m_ObjectType = apObject->GetType();
        SetOldProperties(apObject->GetPosition());
        SetOldValue(apObject->GetValue());
    }
}

//##ModelId=3C8A47DE00FA
bool 
DeleteObjectCommand::Execute() {
    Widget*     p_old_widget = NULL;
    Widget*     p_parent_widget = NULL;

    if (m_pModel == NULL) {
        return false;
    }

    if ((m_ObjectId <= 100) ||
        (m_ObjectType == UNKNOWN_WIDGET)) {
        return false;
    }

    p_old_widget = m_pModel->GetWidgetById(m_ObjectId);
    if (p_old_widget == NULL) {
        return false;
    }

    p_old_widget->SetParent(NULL);

    delete p_old_widget;
    p_old_widget = NULL;

	return true;
}

//##ModelId=3C8A47DE0138
bool 
DeleteObjectCommand::Unexecute() {
    WidgetFactory*  p_widget_factory = NULL;
    Widget*         p_new_object = NULL;
    Widget*         p_root_widget = NULL;
    bool            result = false;

    do {
        if (m_pModel == NULL) {
            break;
        }

        if (m_pProperties == NULL) {
            break;
        }

        if ((m_ObjectId <= 100) ||
            (m_ObjectType == UNKNOWN_WIDGET)) {
            break;
        }

        p_widget_factory = m_pModel->GetWidgetFactory();
        if (p_widget_factory == NULL) {
            break;
        }

             if (m_ObjectType == LABEL_WIDGET) {
            p_new_object = p_widget_factory->CreateLabel();
        }
        else if (m_ObjectType == TEXTEDIT_WIDGET) {
            p_new_object = p_widget_factory->CreateTextEdit();
        }
        else if (m_ObjectType == BUTTON_WIDGET) {
            p_new_object = p_widget_factory->CreateButton();
        }

        if (p_new_object == NULL) {
            break;
        }

        p_root_widget = m_pModel->GetWidgetById(ROOT_WIDGET_ID);
        if (p_root_widget == NULL) {
            break;
        }

        p_new_object->SetId(m_ObjectId);

        if (m_pValue == NULL) {
            m_pValue = new QString;
            *m_pValue = "";
        }

        p_new_object->SetPosition(m_pProperties);
        p_new_object->SetValue(m_pValue);
        if (!p_root_widget->IsValidWidget(p_new_object)) {
            break;
        }

        result = true;
    } while (false);

    if (result) {
        p_root_widget->AppendChild(p_new_object);
    }
    else {
        delete p_new_object;
        p_new_object = NULL;
    }

	return result;
}

//##ModelId=3C9B911A032C
void
DeleteObjectCommand::SetNewProperties(const QRect* apPosition) {
}

//##ModelId=3C9B911A034B
void
DeleteObjectCommand::SetNewValue(const QString* apValue) {
}

//##ModelId=3C9B911A03A9
void
DeleteObjectCommand::SetOldProperties(const QRect* apPosition) {
    delete m_pProperties;
    m_pProperties = NULL;

    if (apPosition != NULL) {
        m_pProperties = new QRect;
        *m_pProperties = *apPosition;
    }
}

//##ModelId=3C9B911A037A
void
DeleteObjectCommand::SetOldValue(const QString* apValue) {
    delete m_pValue;
    m_pValue = NULL;

    if (apValue != NULL) {
        m_pValue = new QString;
        *m_pValue = *apValue;
    }
}
