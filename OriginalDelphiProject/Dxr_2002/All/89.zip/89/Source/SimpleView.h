// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_SIMPLEVIEW_3C83E43C0242_INCLUDED
#define _INC_SIMPLEVIEW_3C83E43C0242_INCLUDED

#include "View.h"

//#include <qscrollview.h>
#include <qframe.h>
#include <qwidget.h>
#include <qevent.h>
#include <qpoint.h>
#include <qsize.h>
#include <qthread.h>

class Widget;
class Model;
class Controller;

static const int        BORDER_SIZE = 15;

/**
 * ���������� ���������� View ��� ����������� ������
 * �� ������. 
 *
 * @author Eugene Gusev 
 *
 * @version 1.2.2 from 03/24/2002
 */
//##ModelId=3C83E43C0242
class SimpleView : public QWidget, 
                   public View {
    Q_OBJECT
public:
    //##ModelId=3C8D2862007D
                            SimpleView(QWidget* parent = 0,
                                       const char* name = 0, 
                                       WFlags f = WType_TopLevel);

    //##ModelId=3C8D2862009C
    virtual                 ~SimpleView();

    //##ModelId=3C8D2861032C
    virtual bool            SetServicedModel(Model* apModel, bool aReset = false);

    //##ModelId=3C8D28620000
    virtual bool            SetController(Controller* apController, bool aReset = false);

    //##ModelId=3C8D286003A9
    virtual void            Notify();

    //##ModelId=3C8D28610000
    virtual bool            DrawLabel(const Widget* apLabel);

    //##ModelId=3C8D2861005D
    virtual bool            DrawButton(const Widget* apButton);

    //##ModelId=3C8D286100CB
    virtual bool            DrawTextEdit(const Widget* apTextEdit);

    //##ModelId=3C8D28610148
    virtual bool            DrawMarker(const Widget* apMarker);

    //##ModelId=3C8D286101B5
    virtual bool            DrawRoot(const Widget* apRoot);

    //##ModelId=3C8D28610232
    virtual bool            DrawMouseLabel(const Widget* apMouseLabel);

    //##ModelId=3C8D2861029F
    virtual bool            DrawSensitivePoint(const Widget* apSensitivePoint);

    //##ModelId=3C9317E1003E
    void                    SetFrameSize(int aWidth, int aHeight);

    //##ModelId=3C9317E0038A
    void                    SetGrid(int aNewGridSize);

    //##ModelId=3C9317E002EE
    inline void             ShowGrid(bool aShowGrid = true);

    //##ModelId=3C9317E00280
    inline bool             IsShowGrid() const;

    //##ModelId=3C9317E00213
    inline QSize            sizeHint() const;

    inline void             SetCascadeView(View* apCascadView);

public slots:
    void                    Delete();

protected:
    //##ModelId=3C9317E00167
    void                    paintEvent(QPaintEvent* apPaintEvent);

    //##ModelId=3C9317E000BB
    void                    resizeEvent(QResizeEvent* apResizeEvent);

    //##ModelId=3C94DD4E038A
    void                    mousePressEvent(QMouseEvent* apMouseEvent);

    //##ModelId=3C9A59BE032C
    void                    mouseReleaseEvent(QMouseEvent* apMouseEvent);

    //##ModelId=3C94DD4E0271
    void                    mouseMoveEvent(QMouseEvent* apMouseEvent);

private:
    //##ModelId=3C9317E0006D
    void                    Recalculate();

    //##ModelId=3C9317DF03A9
    void                    PrepareBackground(QPainter*& arpPainter);

    //##ModelId=3C9317DF02FD
    void                    PrepareBorder(QPainter*& arpPainter);

    //##ModelId=3C9317DF0261
    void                    PrepareGrid(QPainter*& arpPainter);

    //##ModelId=3C9317DF0060
    inline QPoint           Translate(QPoint& arPoint) const;

    //##ModelId=3C9317DF0138
    inline QPoint           Translate(int aX, int aY) const;

protected:
    //##ModelId=3C94DD4E01A5
    int                     m_MouseState;

    //##ModelId=3C8D2739006F
    Controller*             m_pController;

    //##ModelId=3C8D2739005D
    Model*                  m_pServicedModel;

    //##ModelId=3C9317DF005D
    QPoint                  m_Offset;

    //##ModelId=3C9317DF004E
    QSize                   m_WidgetSize;

    //##ModelId=3C9317DF003E
    QSize                   m_FrameSize;

    //##ModelId=3C9317DE032C
    bool                    m_ShowGrid;

    //##ModelId=3C934D1C02E0
    QPainter*               m_pPainter;

    //##ModelId=3C9A59BE031C
    QMutex*                 m_pSynchronizer;

    //##ModelId=3C9B9084005D
    QWidget*                m_pParent;

    View*                   m_pCascadView;

    class TimeController : public QThread {
    public:
        inline          TimeController(QWidget* apViewport);
        inline          ~TimeController();
        void            run();
        inline void     repaint();
        inline void     stop();
        inline void     WainForFinish();
    private:
        bool            m_IsChanger;
        bool            m_Finish;
        QWidget*        m_pViewport;
        QWaitCondition  m_Finished;
    };

    //##ModelId=3C94DD4E0196
    TimeController*         m_pTimer;

};

//##ModelId=3C9317DF0060
inline
QPoint
SimpleView::Translate(QPoint& arPoint) const {
    return (arPoint + m_Offset);
}

//##ModelId=3C9317DF0138
inline
QPoint
SimpleView::Translate(int aX, int aY) const {
    QPoint point;
    point = m_Offset;
    point.rx() += aX;
    point.ry() += aY;
    return point;
}

//##ModelId=3C9317E002EE
inline 
void
SimpleView::ShowGrid(bool aShowGrid) {
    m_ShowGrid = aShowGrid;
}

//##ModelId=3C9317E00280
inline
bool
SimpleView::IsShowGrid() const {
    return m_ShowGrid;
}

//##ModelId=3C9317E00213
inline 
QSize
SimpleView::sizeHint() const {
    QSize recomend_size;
    recomend_size = m_FrameSize;
    recomend_size.rwidth() += BORDER_SIZE*2;
    recomend_size.rheight() += BORDER_SIZE*2;
    return recomend_size;
}

inline
SimpleView::TimeController::TimeController(QWidget* apViewport) {
    m_pViewport = apViewport;
    m_IsChanger = true;
    m_Finish = false;
}

inline
SimpleView::TimeController::~TimeController() {
    stop();
    m_pViewport = NULL;
}

inline
void
SimpleView::TimeController::repaint() {
    m_IsChanger = true;
}

inline
void
SimpleView::TimeController::stop() {
    m_Finish = true;
}

inline
void
SimpleView::TimeController::WainForFinish() {
    m_Finished.wait();
}

inline
void
SimpleView::SetCascadeView(View* apCascadView) {
    m_pCascadView = apCascadView;
}

#endif /* _INC_SIMPLEVIEW_3C83E43C0242_INCLUDED */
