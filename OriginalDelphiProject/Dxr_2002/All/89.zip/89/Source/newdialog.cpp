/****************************************************************************
** Form implementation generated from reading ui file '.\newdialog.ui'
**
** Created: Sun Mar 10 23:32:00 2002
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "newdialog.h"

#include <qlabel.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

static const char* const image0_data[] = { 
"17 17 2 1",
"# c #000080",
". c #c0c0c0",
".................",
".................",
"...#....#....#...",
"..###..###..###..",
"...#....#....#...",
".................",
".................",
"...#....#....#...",
"..###..###..###..",
"...#....#....#...",
".................",
".................",
"...#....#....#...",
"..###..###..###..",
"...#....#....#...",
".................",
"................."};


/* 
 *  Constructs a NewDialogBase which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
NewDialogBase::NewDialogBase( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    QPixmap image0( ( const char** ) image0_data );
    if ( !name )
	setName( "NewDialogBase" );
    resize( 515, 285 ); 
    setProperty( "caption", tr( "NewDialog" ) );
    setProperty( "sizeGripEnabled", QVariant( TRUE, 0 ) );

    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setGeometry( QRect( 20, 240, 476, 33 ) ); 
    Layout1 = new QHBoxLayout( privateLayoutWidget ); 
    Layout1->setSpacing( 6 );
    Layout1->setMargin( 0 );

    buttonHelp = new QPushButton( privateLayoutWidget, "buttonHelp" );
    buttonHelp->setProperty( "text", tr( "&Help" ) );
    buttonHelp->setProperty( "autoDefault", QVariant( TRUE, 0 ) );
    Layout1->addWidget( buttonHelp );
    QSpacerItem* spacer = new QSpacerItem( 20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    Layout1->addItem( spacer );

    buttonApply = new QPushButton( privateLayoutWidget, "buttonApply" );
    buttonApply->setProperty( "text", tr( "&Apply" ) );
    buttonApply->setProperty( "autoDefault", QVariant( TRUE, 0 ) );
    Layout1->addWidget( buttonApply );

    buttonOk = new QPushButton( privateLayoutWidget, "buttonOk" );
    buttonOk->setProperty( "caption", tr( "" ) );
    buttonOk->setProperty( "text", tr( "&OK" ) );
    buttonOk->setProperty( "autoDefault", QVariant( TRUE, 0 ) );
    buttonOk->setProperty( "default", QVariant( TRUE, 0 ) );
    Layout1->addWidget( buttonOk );

    buttonCancel = new QPushButton( privateLayoutWidget, "buttonCancel" );
    buttonCancel->setProperty( "text", tr( "&Cancel" ) );
    buttonCancel->setProperty( "autoDefault", QVariant( TRUE, 0 ) );
    Layout1->addWidget( buttonCancel );

    TextLabel1 = new QLabel( this, "TextLabel1" );
    TextLabel1->setGeometry( QRect( 200, 120, 116, 13 ) ); 
    TextLabel1->setProperty( "text", tr( "Place your widgets here!" ) );

    PixmapLabel1 = new QLabel( this, "PixmapLabel1" );
    PixmapLabel1->setGeometry( QRect( 130, 70, 100, 100 ) ); 
    PixmapLabel1->setProperty( "pixmap", image0 );
    PixmapLabel1->setProperty( "scaledContents", QVariant( TRUE, 0 ) );

    // signals and slots connections
    connect( buttonOk, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( buttonCancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
NewDialogBase::~NewDialogBase()
{
    // no need to delete child widgets, Qt does it all for us
}

