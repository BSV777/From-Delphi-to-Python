// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_SIMPLEWIDGETFACTORY_3C89E1190242_INCLUDED
#define _INC_SIMPLEWIDGETFACTORY_3C89E1190242_INCLUDED

#include "WidgetFactory.h"

class Widget;

/**
 * ������ ����� �������� �������� ��������.
 *
 * @see http://www.vico.org/pages/PatronsDisseny/Pattern%20Abstract%20Factory/index.html
 *
 * @version 0.1.0 form 03/14/2002
 * 
 * @author Eugene Gusev
 */
//##ModelId=3C89E1190242
class SimpleWidgetFactory : public WidgetFactory {
public:
	//##ModelId=3C89E24403C8
	virtual Widget*         CreateButton();

	//##ModelId=3C89E24403D8
	virtual Widget*         CreateLabel();

	//##ModelId=3C89E245000F
	virtual Widget*         CreateTextEdit();

	//##ModelId=3C8FBA860128
    virtual Widget*         CreateRootWidget();

protected:
	//##ModelId=3C89E245005D
	virtual Widget*         CreateMarker();

	//##ModelId=3C89E245001F
	virtual Widget*         CreateMouseLabel();

	//##ModelId=3C89E245003E
	virtual Widget*         CreateSensitivePoint(SensitivePointPosition aPosition);
};

#endif /* _INC_SIMPLEWIDGETFACTORY_3C89E1190242_INCLUDED */

