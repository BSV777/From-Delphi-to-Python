// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_LOADERMANAGER_3C89D7E50157_INCLUDED
#define _INC_LOADERMANAGER_3C89D7E50157_INCLUDED

class AbstractLoader;
class WidgetFactory;


//##ModelId=3C89D7E50157
class LoaderManager {
public:
	//##ModelId=3C8BDA3D03D8
	AbstractLoader*         GetLoader(const QString*    apcName,
                                      WidgetFactory*    apWidgetFactory);
};

#endif /* _INC_LOADERMANAGER_3C89D7E50157_INCLUDED */

