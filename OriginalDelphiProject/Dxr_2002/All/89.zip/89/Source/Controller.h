// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_CONTROLLER_3C83D8DA035B_INCLUDED
#define _INC_CONTROLLER_3C83D8DA035B_INCLUDED

class Model;
class View;

class QPoint;
class QString;

enum CreateMode {
    CREATE_NOTHING  = -1,
    CREATE_LABEL    = 1,
    CREATE_TEXTEDIT = 2,
    CREATE_BUTTON   = 4
};

/**
 * ����� Control � ������ MVC. � ������ ���� ������������ 
 * ������ ��� ��������� ��������� �� ������������ � ���������� 
 * ���������� ������.
 *
 * A controller is the means by which the user interacts with 
 * the application. A controller accepts input from the user 
 * and instructs the model and viewport to perform actions 
 * based on that input. In effect, the controller is 
 * responsible for mapping end-user action to application 
 * response.
 *
 * ��� ����� ��������� ����������� �������� ������������ �� 
 * ������ MVC.
 *
 * @author Eugene Gusev
 *
 * @version 1.1.2 03/23/2002
 *
 * @see http://ootips.org/mvc-pattern.html
 * @see http://www.javaworld.com/javaworld/jw-04-1998/jw-04-howto.html
 *
 */
//##ModelId=3C83D8DA035B
class Controller {
public:
    /**
     * ����������.
     */
	//##ModelId=3C8FBA890251
    virtual                 ~Controller() {}

	//##ModelId=3C8BD1E80138
	virtual void            LButtonPressed(const QPoint* apcPoint) = 0;

	//##ModelId=3C8BD203009C
	virtual void            LButtonReleased(const QPoint* apcPoint) = 0;

	//##ModelId=3C8BD21400EA
	virtual void            MouseMove(QPoint* apoordinate) = 0;

	//##ModelId=3C8BD287007D
	virtual void            SnapToGrid(bool aSnap) = 0;

	//##ModelId=3C8BD32F00AB
	virtual void            CreateNew() = 0;

	//##ModelId=3C8BD2AB036B
	virtual bool            CanSave() const = 0;

	//##ModelId=3C8BD2BB01A5
	virtual void            SetName(const QString* apNewName) = 0;;

	//##ModelId=3C8BD2D9006D
	virtual bool            Save() = 0;

	//##ModelId=3CA6E35C003E
    virtual bool            Export(const QString* apFileName) = 0;

	//##ModelId=3C8BD2E2035B
	virtual bool            Load(const QString* apNewName) = 0;

	//##ModelId=3CA38CA50119
    virtual bool            IsChanged() const = 0;

	//##ModelId=3C8BD2F9004E
	virtual void            Undo() = 0;

	//##ModelId=3C8BD305035B
	virtual void            Redo() = 0;

	//##ModelId=3C8BD30B01E4
	virtual bool            CanUndo() const = 0;

	//##ModelId=3C8BD31D009C
	virtual bool            CanRedo() const = 0;

	//##ModelId=3C8BD4A302DE
	virtual void            SetModel(Model* apModel) = 0;

	//##ModelId=3C934D1E033C
	virtual Model*          GetModel() = 0;

	//##ModelId=3C8BD4B3006D
	virtual void            SetView(View* apView) = 0;

	//##ModelId=3C934D1E0271
    virtual View*           GetView() = 0;

	//##ModelId=3C9A59C201F4
    virtual int             GetGridSize() const = 0;

	//##ModelId=3C9A59C200BB
    virtual void            SetGridSize(const int aNewGridSize) = 0;

	//##ModelId=3C9A59C1038A
    virtual void            SetCreateLabelMode(bool aCreateLabelMode = true) = 0;

	//##ModelId=3C9A59C10251
    virtual void            SetCreateTextEditMode(bool aCreateTextEditMode = true) = 0;

	//##ModelId=3C9A59C10128
    virtual void            SetCreateButtonMode(bool aCreateButtonMode = true) = 0;

	//##ModelId=3CA0DD87004E
    virtual CreateMode      GetCreateMode() const = 0;

	//##ModelId=3CA0DD86038A
    virtual void            Delete() = 0;
};

#endif /* _INC_CONTROLLER_3C83D8DA035B_INCLUDED */

