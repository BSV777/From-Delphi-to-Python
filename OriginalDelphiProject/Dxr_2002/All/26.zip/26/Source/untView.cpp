//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "untView.h"
#include "untMain.h"
#include "Shapes.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmHTML *frmHTML;
//---------------------------------------------------------------------------
__fastcall TfrmHTML::TfrmHTML(TComponent* Owner) : TForm(Owner){}
//---------------------------------------------------------------------------
void __fastcall TfrmHTML::btnRequeryClick(TObject *Sender){
  frmMain->shapeList->SaveHTML ();
  try {
    HTML1->RequestDoc("File:///test.html");
    }
  catch (...){
    MessageBox ( 0, "������, ����� HTML �� ���������������!", "������", MB_OK|MB_ICONERROR|MB_TASKMODAL );
    }
}
//---------------------------------------------------------------------------
void __fastcall TfrmHTML::FormClose(TObject *Sender, TCloseAction &Action){
  frmMain->ActionViewHTML->Checked = !frmMain->ActionViewHTML->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TfrmHTML::FormShow(TObject *Sender){
  btnRequeryClick(NULL);
}
//---------------------------------------------------------------------------

