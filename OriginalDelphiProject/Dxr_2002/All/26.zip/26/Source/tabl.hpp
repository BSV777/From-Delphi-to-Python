// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Tabl.pas' rev: 4.00

#ifndef TablHPP
#define TablHPP

#pragma delphiheader begin
#pragma option push -w-
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Tabl
{
//-- type declarations -------------------------------------------------------
#pragma pack(push, 1)
struct Shaps
{
	int x;
	int y;
	int height;
	int width;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct TDataToHTML
{
	int Row;
	int Col;
	int Ntabl;
	int Height;
	int Width;
	int nObject;
	int nCellsX;
	int nCellsY;
} ;
#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall Table(int &NPoints, Shaps * ukazShaps, const int ukazShaps_Size, TDataToHTML 
	* ukazHTML, const int ukazHTML_Size);

}	/* namespace Tabl */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Tabl;
#endif
#pragma option pop	// -w-

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Tabl
