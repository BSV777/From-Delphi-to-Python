//---------------------------------------------------------------------------
#ifndef untMainH
#define untMainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ActnList.hpp>
#include <ComCtrls.hpp>
#include <Menus.hpp>
#include <ToolWin.hpp>
#include <ImgList.hpp>
#include <ExtCtrls.hpp>
#include <NMHTML.hpp>
#include <OleCtrls.hpp>
#include <Dialogs.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class ShapeIterator;
class Shape;

class TfrmMain : public TForm
{
__published:	// IDE-managed Components
  TStatusBar *StatusBar1;
  TToolBar *ToolBar1;
  TMainMenu *MainMenu1;
  TMenuItem *N1;
  TActionList *ActionList1;
  TAction *ActionOpen;
  TImageList *ImageList1;
  TMenuItem *N2;
  TToolButton *ToolButton1;
  TToolBar *ToolBar2;
  TToolButton *ToolButton2;
  TAction *ActionSel;
  TAction *ActionNew;
  TAction *ActionSave;
  TAction *ActionSaveAs;
  TMenuItem *N3;
  TMenuItem *N5;
  TAction *ActionExit;
  TMenuItem *N6;
  TMenuItem *N7;
  TToolButton *ToolButton3;
  TToolButton *ToolButton4;
  TPanel *Panel1;
  TToolButton *ToolButton5;
  TAction *ActionButton;
  TPaintBox *PaintBox1;
  TAction *ActionLabel;
  TToolButton *ToolButton6;
  TToolButton *ToolButton7;
  TAction *ActionEdit;
  TImageList *ImageList2;
  TMenuItem *N8;
  TMenuItem *N9;
  TAction *ActionViewProperty;
  TAction *ActionViewHTML;
  TMenuItem *N10;
  TToolButton *ToolButton8;
  TToolButton *ToolButton9;
  TMenuItem *N11;
  TAction *ActionDelete;
  TMenuItem *N12;
  TSaveDialog *SaveDialog1;
  TOpenDialog *OpenDialog1;
  TComboBox *ComboBox1;
  TToolButton *ToolButton10;
  TMenuItem *Mabout;
  void __fastcall ActionOpenExecute(TObject *Sender);
  void __fastcall ActionExitExecute(TObject *Sender);
  void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
  void __fastcall ActionButtonExecute(TObject *Sender);
  void __fastcall PaintBox1Paint(TObject *Sender);
  void __fastcall FormCreate(TObject *Sender);
  void __fastcall FormDestroy(TObject *Sender);
  void __fastcall PaintBox1MouseDown(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
  void __fastcall PaintBox1MouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
  void __fastcall ActionLabelExecute(TObject *Sender);
  void __fastcall ActionEditExecute(TObject *Sender);
  void __fastcall ActionViewPropertyExecute(TObject *Sender);
  void __fastcall ActionViewHTMLExecute(TObject *Sender);
  void __fastcall ActionDeleteExecute(TObject *Sender);
  void __fastcall ActionSaveAsExecute(TObject *Sender);
  void __fastcall ActionNewExecute(TObject *Sender);
  void __fastcall FormResize(TObject *Sender);
  void __fastcall ComboBox1Change(TObject *Sender);
  void __fastcall MaboutClick(TObject *Sender);
private:	// User declarations
  char buf[20];
  AnsiString fileName;
  void OpenFile (char *fname);
public:		// User declarations
  __fastcall TfrmMain(TComponent* Owner);
  void Draw ( char *text );
  Shape *activeShape();
  ShapeIterator *shapeList;
  bool SaveAsExecute();
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmMain *frmMain;
//---------------------------------------------------------------------------
#endif
 