//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <stdio.h>
#include "untMain.h"
#include "Shapes.h"
#include "untProperty.h"
#include "untView.h"
#include "tabl.hpp"
#include "UnAb.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmMain *frmMain;

//TfrmHTML *frmHTML;
//---------------------------------------------------------------------------
__fastcall TfrmMain::TfrmMain(TComponent* Owner) : TForm(Owner){
  shapeList = NULL;
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::FormCreate(TObject *Sender){
  ActionNewExecute(NULL);
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::FormDestroy(TObject *Sender){
  delete shapeList;
  delete frmHTML;
}
//---------------------------------------------------------------------------
void TfrmMain::OpenFile (char *fname){
  OpenDialog1->FileName = fname;
  Caption = "�������������� � HTML - " + OpenDialog1->FileName;
  fileName = OpenDialog1->FileName;
 	shapeList->Load ( OpenDialog1->FileName.c_str() );
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::ActionOpenExecute(TObject *Sender){
  if( OpenDialog1->Execute() ){
    ActionNewExecute(NULL);
    OpenFile (OpenDialog1->FileName.c_str());
    }
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::ActionExitExecute(TObject *Sender){
  Close();
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::FormClose(TObject *Sender, TCloseAction &Action){
  if ( shapeList->Count == 0 )
    Action = caFree;
  else
  if ( MessageBox ( 0, "��������� ������?", Caption.c_str(), MB_YESNO|MB_ICONQUESTION|MB_TASKMODAL ) == IDYES	)
    Action = caFree;
  else
    Action = caNone;
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::ActionButtonExecute(TObject *Sender){
MButton *button;
  sprintf(buf, "Button%d", ++shapeList->nButtons);
  button = new MButton(Panel1, buf);
  button->Text = buf;
  shapeList->Add ( button );
  frmProp->Refresh ( button );
  ComboBox1->Items->Add ( buf );
  ComboBox1->ItemIndex = ComboBox1->Items->Count-1;
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::ActionLabelExecute(TObject *Sender){
MLabel *label;
  sprintf(buf, "Label%d", ++shapeList->nLabels);
  label = new MLabel(Panel1, buf);
  label->Text = buf;
  shapeList->Add ( label );
  frmProp->Refresh ( label );
  ComboBox1->Items->Add ( buf );
  ComboBox1->ItemIndex = ComboBox1->Items->Count-1;
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::ActionEditExecute(TObject *Sender){
MEdit *edit;
  sprintf(buf, "Edit%d", ++shapeList->nEdits);
  edit = new MEdit(Panel1, buf);
  edit->Text = buf;
  shapeList->Add ( edit );
  frmProp->Refresh ( edit );
  ComboBox1->Items->Add ( buf );
  ComboBox1->ItemIndex = ComboBox1->Items->Count-1;
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::ActionViewPropertyExecute(TObject *Sender){
  frmProp->Visible = !frmProp->Visible;
  ActionViewProperty->Checked = frmProp->Visible;
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::ActionViewHTMLExecute(TObject *Sender){
//  if ( !frmHTML->Visible )
//    shapeList->SaveHTML();
  if ( frmHTML == NULL )
    frmHTML = new TfrmHTML(this);
  if ( frmHTML )
    frmHTML->Visible = !frmHTML->Visible;
  ActionViewHTML->Checked = !ActionViewHTML->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::ActionDeleteExecute(TObject *Sender){
Shape *shape = shapeList->Selected;
  if ( shape != NULL ){
    AnsiString msg;
    msg = "�� ������������� ������ ������� " + AnsiString(shape->Name()) + " ?"; 
    if(MessageBox(0,msg.c_str(),"��������",MB_YESNO|MB_ICONQUESTION|MB_TASKMODAL)==IDYES){
      int ind = shapeList->IndexOf ( shape );
      ComboBox1->Items->Delete ( ind ); 
      shapeList->Remove ( shape );
      delete shape;
      PaintBox1->Invalidate();
      shapeList->Selected = NULL;
      frmProp->Refresh(NULL);
      ComboBox1->Text = "";
      }
    }
}
//---------------------------------------------------------------------------
Shape *TfrmMain::activeShape(){
  return shapeList->Selected;
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::PaintBox1Paint(TObject *Sender){
//  shapeList->Draw();
TRect r( 10, 10, 200, 200 );
  PaintBox1->Canvas->Brush->Color = clBlack;
/*  PaintBox1->Canvas->FillRect (r);
//  ((TCustomControl *)Panel1)->Canvas->FillRect (r);
  */
/*
  TCanvas *tempCanvas = new TCanvas;
  HWND notUsed;
  TWinControl *pCtrl = (TWinControl *)Button1;       //TButton
  Button1->PaintTo(Handle, 10, 10);

//  tempCanvas->Handle = pCtrl->GetDeviceContext(notUsed);
  */ 

}
//---------------------------------------------------------------------------
void TfrmMain::Draw ( char *text ){
  StatusBar1->Panels->Items[0]->Text = text;
  }
//---------------------------------------------------------------------------
void __fastcall TfrmMain::PaintBox1MouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y){
  shapeList->Selected = NULL;
  Panel1->Invalidate();
  frmProp->Refresh(NULL);
  ComboBox1->ItemIndex = -1;
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::PaintBox1MouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y){
  Draw(" ");
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::ActionSaveAsExecute(TObject *Sender){
  SaveAsExecute();
}
//---------------------------------------------------------------------------
bool TfrmMain::SaveAsExecute(){
AnsiString sName = fileName;
int p;
    if ( (p = sName.AnsiPos( ExtractFileExt(fileName) )) > 0 )
    		sName.SetLength( p-1 );
    SaveDialog1->FileName = sName;
    if (SaveDialog1->Execute()){
    	fileName = SaveDialog1->FileName;
      if ( SaveDialog1->FilterIndex == 2 )
        shapeList->Save(SaveDialog1->FileName.c_str());
      else
        shapeList->SaveHTML(SaveDialog1->FileName.c_str());
      return true;
      }
    return false;
	}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::ActionNewExecute(TObject *Sender){
  if ( shapeList )
    delete shapeList;
  shapeList = new ShapeIterator ( Panel1 );
  ComboBox1->Text = "";
  ComboBox1->Items->Clear();
  if ( frmProp )
    frmProp->Refresh ( NULL );
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::FormResize(TObject *Sender){
  if ( Visible )
    if ( shapeList->Count != 0 )
      return;
  switch ( ParamCount() ){
    case 1:
      fileName = ParamStr(1);
      if ( Visible )
        OpenFile (fileName.c_str());
      break;
    case 2:
      Close();
      break;
    case 0:
    default:
      fileName = "TestFile.csf";
      break;
    }
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::ComboBox1Change(TObject *Sender){
int ind = -2;
  if ( ComboBox1->Text != "" ){
    ind = ComboBox1->ItemIndex;
    if ( ind != -1 ){
      shapeList->Selected = ((Shape *)shapeList->Items[ind]);
      frmProp->Refresh((Shape *)shapeList->Items[ind]);
      }
    }
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::MaboutClick(TObject *Sender){
  AboutBox->Visible = true;
}
//---------------------------------------------------------------------------

