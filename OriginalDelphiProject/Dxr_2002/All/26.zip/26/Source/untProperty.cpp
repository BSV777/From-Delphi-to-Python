//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <stdlib.h>
#include "untProperty.h"
#include "untMain.h"
#include "Shapes.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmProp *frmProp;
//---------------------------------------------------------------------------
__fastcall TfrmProp::TfrmProp(TComponent* Owner)  : TForm(Owner){
}
//---------------------------------------------------------------------------
void TfrmProp::DrawShapeProp ( Shape *shape ){
  Refresh ( shape );
}
//---------------------------------------------------------------------------
void TfrmProp::Refresh ( Shape *shape_ ){
shape = shape_;
  if ( shape == NULL ){
    StringGrid1->RowCount = 0;
    StringGrid1->Enabled = false;
    StringGrid1->Cells[0][0] = "";
    StringGrid1->Cells[1][0] = "";
    Caption = "��������";
    return;
    }
  else
    StringGrid1->Enabled = true;
  switch ( shape->Type ){
      case _MBUTTON_:
        Caption = shape->Name();
        StringGrid1->Cells[0][0] = "Caption";
        StringGrid1->RowCount = 5;
        break;
      case _MLABEL_:
        Caption = shape->Name();
        StringGrid1->Cells[0][0] = "Text";
        StringGrid1->RowCount = 5;
        break;
      case _MEDIT_:
        Caption = shape->Name();
        StringGrid1->Cells[0][0] = "Text";
        StringGrid1->RowCount = 5;
        break;
      }
  StringGrid1->Cells[1][0] = shape->Text;
  StringGrid1->Cells[0][1] = "Left";
  StringGrid1->Cells[1][1] = shape->ClientRect->Left;
  StringGrid1->Cells[0][2] = "Height";
  StringGrid1->Cells[1][2] = shape->ClientRect->Height();
  StringGrid1->Cells[0][3] = "Top";
  StringGrid1->Cells[1][3] = shape->ClientRect->Top;
  StringGrid1->Cells[0][4] = "Width";
  StringGrid1->Cells[1][4] = shape->ClientRect->Width();
  frmMain->ActionViewProperty->Checked = Visible;
  }
//---------------------------------------------------------------------------
void __fastcall TfrmProp::StringGrid1KeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift){
//
  switch ( Key ){
    case VK_UP:
    case VK_DOWN:
//    case VK_LEFT:
//    case VK_RIGHT:
    case VK_RETURN:
    case VK_TAB:
      RefreshShape();
      break;
    }
}
//---------------------------------------------------------------------------
void __fastcall TfrmProp::StringGrid1SelectCell(TObject *Sender, int ACol,
      int ARow, bool &CanSelect){
  if ( !ACol ){
    StringGrid1->EditorMode = false;
    StringGrid1->Options  >> goEditing;
    }
  else {
    if ( ARow == 2 && shape->Type == _MEDIT_ ){
      StringGrid1->EditorMode = false;
      StringGrid1->Options  >> goEditing;
      }
    else {
      StringGrid1->EditorMode = true;
      StringGrid1->Options  << goEditing;
      }
    RefreshShape();
    }
}
//---------------------------------------------------------------------------
void __fastcall TfrmProp::StringGrid1GetEditMask(TObject *Sender, int ACol,
      int ARow, AnsiString &Value){
  if (  StringGrid1->Cells[0][ARow] == "Left" ||
        StringGrid1->Cells[0][ARow] == "Top" ||
        StringGrid1->Cells[0][ARow] == "Height" ||
        StringGrid1->Cells[0][ARow] == "Width" )
    Value = "0000;1";
}
//---------------------------------------------------------------------------
void __fastcall TfrmProp::StringGrid1GetEditText(TObject *Sender, int ACol,
      int ARow, AnsiString &Value){
  RefreshShape();
}
//---------------------------------------------------------------------------
void TfrmProp::RefreshShape(){
    if ( shape == NULL ){
      StringGrid1->Enabled = false;
      StringGrid1->RowCount = 0;
      return;
      }
    else
      StringGrid1->Enabled = true;
    try {
      TRect *r = shape->ClientRect;
      r->Left = StringGrid1->Cells[1][1].Trim().ToInt();
      r->Top  = StringGrid1->Cells[1][3].Trim().ToInt();
      r->Right= r->Left+StringGrid1->Cells[1][4].Trim().ToInt();
      r->Bottom = r->Top+StringGrid1->Cells[1][2].Trim().ToInt();
      shape->Update();
      shape->Text = StringGrid1->Cells[1][0].c_str();
      }
    catch (...){
      }
}
//---------------------------------------------------------------------------
void __fastcall TfrmProp::FormResize(TObject *Sender){
  StringGrid1->ColWidths[1] = frmProp->ClientWidth - 105;
}
//---------------------------------------------------------------------------
void __fastcall TfrmProp::FormActivate(TObject *Sender){
  Refresh( frmMain->shapeList->Selected );
  frmMain->ActionViewProperty->Checked = Visible;
}
//---------------------------------------------------------------------------
void __fastcall TfrmProp::FormCreate(TObject *Sender){
TPoint p = frmMain->Panel1->ClientToScreen(TPoint ( 0, 0 ) );
  Left = frmMain->Left + frmMain->Width - Width;
  Top = p.y;
}
//---------------------------------------------------------------------------
void __fastcall TfrmProp::FormHide(TObject *Sender){
  frmMain->ActionViewProperty->Checked = Visible;
}
//---------------------------------------------------------------------------

