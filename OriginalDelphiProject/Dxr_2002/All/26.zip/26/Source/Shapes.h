//---------------------------------------------------------------------------
#ifndef ShapesH
#define ShapesH
//---------------------------------------------------------------------------
#include "tabl.hpp"

#define MAXSTR  255
#define OFF     4
#define RSEL    6

#define TOP     0
#define LEFT    0
#define WIDTH   200
#define HEIGHT  20

//#define TEST // ��� �������

#ifdef TEST
 #define BLANK   "."
 #define BORDER
#else
 #define BLANK   ""
#endif

enum StateOfShape { _NONE_=0, _SELECTED_, _MOVE_ };
enum TypeOfShape { _MNONE_= 0, _MBUTTON_, _MLABEL_, _MEDIT_, _MERROR_ = -1 };

//---------------------------------------------------------------------------
//  S h a p e
//---------------------------------------------------------------------------
class Shape {
    TRect               rect;
    char                text[MAXSTR+1];

    TypeOfShape         GetType(){return type;};
    int                 GetWidth();
    void                SetWidth(int w);
    int                 GetHeight();
    void                SetHeight(int h);

  protected:
    TypeOfShape         type;
    Classes::TComponent *AOwner;
    TControl            *Control;
    TPoint              pointPressed;
    StateOfShape        state;
    int                 numPoint; // 0-��������, ��� ��������� �� �.�.
    char                name[100];

    void Write ( char *s, int fd );
    void SaveRect(int fd);
    void Initialize();
    bool Cmparr(TRect &r1, TRect &r2);

    virtual TRect *GetRect();
    virtual void SetRect(TRect *);
    virtual void SetText ( char *text );
    virtual char *GetText();
    virtual bool GetSelected();
    virtual void SetSelected(bool selected);

    virtual void __fastcall Enter(TObject *Sender);
    virtual void __fastcall MouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
    virtual void __fastcall MouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
    virtual void __fastcall MouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
  public:
    Shape(Classes::TComponent* AOwner, char *Name );
    ~Shape();

    Shape *Over ( Shape *shape, TRect &r );
    bool IsCorrect ( TRect &r );
    void Stoping(TRect &r1, TPoint p1, TPoint	p2, Shape *shape);

    virtual void Draw();
    virtual void SetPos ( TPoint &point );
    virtual void SetPos ( TRect  &r );
    virtual void Move(TPoint &point);
    virtual void Update();
    virtual void SaveHTML(int fd);
    virtual void Save(int fd);
    virtual char *Name();

    __property TRect *ClientRect = { read=GetRect, write=SetRect };
    __property int Width = { read=GetWidth, write=SetWidth };
    __property int Height = { read=GetHeight, write=SetHeight };
    __property char *Text = { read=GetText, write=SetText };
    __property bool Selected = { read=GetSelected, write=SetSelected };
    __property TypeOfShape Type = { read=GetType };
  };

//---------------------------------------------------------------------------
//  M B u t t o n
//---------------------------------------------------------------------------
class MButton : public Shape {
    virtual void SetText ( char *text );
    void __fastcall KeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
  public:
    MButton (Classes::TComponent* AOwner, char *Name );
    virtual void SaveHTML(int fd);
    virtual void Save(int fd);
  };

//---------------------------------------------------------------------------
//  M E d i t
//---------------------------------------------------------------------------
class MEdit : public Shape {
    virtual void SetText ( char *text );
    void __fastcall TextChange(TObject *Sender);
  public:
    MEdit (Classes::TComponent* AOwner, char *Name );
    virtual void SaveHTML(int fd);
    virtual void Save(int fd);
  };

//---------------------------------------------------------------------------
//  M L a b e l
//---------------------------------------------------------------------------
class TTLabel : public TLabel {
    virtual void __fastcall Paint(void);
  public:
    __fastcall virtual TTLabel(Classes::TComponent* AOwner);
  };

class MLabel : public MEdit {
  public:
    MLabel (Classes::TComponent* AOwner, char *Name );
    virtual void Save(int fd);
    virtual void SaveHTML(int fd);
  };

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//  S h a p e I t e r a t o r
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
class ShapeIterator : public TList {
    char buf[20];
    int fd;
    char *fBuffer;
    Classes::TComponent *AOwner;
    Shape *GetSelected();
    void SetSelected ( Shape *shape );

    void WriteTable(TDataToHTML *toHtml, int NPoint, int &index);
    void WriteRow  (TDataToHTML *toHtml, int NPoint, int &index);
    void WriteCellT(TDataToHTML *toHtml, int NPoint, int &index);

    void WriteLn ( char *s );
    void Write   ( char *s );
    void WriteHeader ( char *s );
    void WriteTitle ( char *s );
    void WriteCell ( Shape *shape, int nCellsX=0, int nCellsY=0, int width=0 );
    void WriteZeroImg( TDataToHTML *toHtml, int NPoint, int &index);
    void WriteBegRow ( int height );
    void WriteEndRow ();
    void CalcColumns(TDataToHTML *toHtml, int count);
    int  GetWidthTable ( TDataToHTML *toHtml, int count, int off=0, int key=-1 );
    bool rowEmpty(TDataToHTML *toHtml, int i, int count);
    Shape *ReadObject ( int &offset );
    char  *ReadTag    ( int &offset, char begCh, char endCh  );
    char  *ReadNameTag( char *s );
    char  *StrChr     ( char *s, char ch );
    char  *DelSpace   ( char *s );
    int    GetInt     ( char *s, char *key );
    char  *GetString  ( char *s, char *key );
    char  *ReadStringTag( char *s );

    TypeOfShape KeyObject ( char *name );
  public:
    ShapeIterator(Classes::TComponent* AOwner);
    __fastcall virtual ~ShapeIterator();

    Shape *Over ( Shape *shape, TRect &r );
    void Allocate ( Shape *shape );
    void Draw ();
    void DeleteObjects();
    __property Shape *Selected = { read=GetSelected, write=SetSelected };
    void SaveHTML( char *fName="test.html" );
    void SaveZeroGif( char *fname );
    void Save( char *fName="test.csf");
    bool Load( char *fName);

    int  nButtons;
    int  nLabels;
    int  nEdits;
    // ���������� ������
    int 					__fastcall		Add(void* Item);
    void 					__fastcall		Pack(void);
  };


#endif
