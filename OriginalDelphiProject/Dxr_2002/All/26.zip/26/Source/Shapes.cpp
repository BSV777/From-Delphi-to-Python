//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <stdio.h>
#include "untMain.h"
#include "untProperty.h"

#include "Shapes.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)

//---------------------------------------------------------------------------
void DrawSelected(TCanvas *canvas, TPoint &p){
TRect r;
  r.Left = p.x - RSEL;
  r.Top =  p.y - RSEL;
  r.Right = p.x + RSEL;
  r.Bottom = p.y + RSEL;
  canvas->Brush->Color = clBlack;
  canvas->Pen->Color = clDkGray;
  canvas->FillRect ( r );
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
Shape::Shape(Classes::TComponent* AOwner_, char *name_ ){
  type = _MNONE_;
  AOwner = AOwner_;
  strnset ( text, 0, MAXSTR );
  state = _NONE_;
  numPoint = 0;
  strcpy ( name, name_ );
}
//---------------------------------------------------------------------------
Shape::~Shape(){
  if ( AOwner )
    delete Control;
}
//---------------------------------------------------------------------------
char *Shape::Name(){
  return name;
}
//---------------------------------------------------------------------------
void Shape::Initialize(){
  if ( AOwner ){
    Control->Parent = (TWinControl *)AOwner;
    Control->Visible = true;
    Control->Tag = 0;
    Control->Left = LEFT;
    Control->Top = TOP;
    if ( type == _MBUTTON_ ){
      Control->Width = WIDTH/2;
      Control->Height = HEIGHT*2;
      }
    else {
      Control->Width = WIDTH;
      Control->Height = HEIGHT;
      }
    ((TWinControl *)Control)->SetFocus();
    }
}
//---------------------------------------------------------------------------
void __fastcall Shape::Enter(TObject *Sender){
  frmProp->Refresh ( this );
  frmMain->shapeList->Selected = this;
}
//---------------------------------------------------------------------------
void Shape::Write ( char *s, int fd ){
  FileWrite(fd,s,strlen(s));
}
//---------------------------------------------------------------------------
void Shape::SaveHTML(int fd){
  Write ( text, fd );
}
//---------------------------------------------------------------------------
void Shape::Save(int fd){
}
//---------------------------------------------------------------------------
void Shape::SaveRect(int fd){
  Write ( " Left=", fd );
  Write ( IntToStr(int(ClientRect->Left)).c_str() , fd );
  Write ( "; Top=", fd );
  Write ( IntToStr(int(ClientRect->Top)).c_str() , fd );
  Write ( "; Height=", fd );
  Write ( IntToStr(int(ClientRect->Height())).c_str() , fd );
  Write ( "; Width=", fd );
  Write ( IntToStr(int(ClientRect->Width())).c_str() , fd );
  Write ( "; ", fd );
}
//---------------------------------------------------------------------------
void Shape::Update(){
  if ( frmMain->shapeList->Over ( this, rect ) == NULL && IsCorrect ( rect ) )
    ClientRect = &rect;
  else
    SetPos ( *ClientRect );
}
//---------------------------------------------------------------------------
bool Shape::GetSelected(){
  return state == _MOVE_ || state == _SELECTED_;
}
//---------------------------------------------------------------------------
void Shape::SetSelected(bool selected){
TMessage msg;
  state = selected ? _SELECTED_ : _NONE_;
  if ( AOwner ){
    Control->Tag = selected ? 1 : 0;
    msg.WParam = 0;
    msg.LParam = 0;
    msg.Result = 0;
    msg.Msg = selected ? WM_SETFOCUS : WM_KILLFOCUS;
    Control->Dispatch ( &msg );
    if ( type == _MEDIT_ )
      ((TMemo *)Control)->ReadOnly = selected ? false : true;
    }
}
//---------------------------------------------------------------------------
bool Shape::IsCorrect ( TRect &r ){
  return !(r.Top < 0 || r.Left < 0 || r.Height() < 2 || r.Width() < 2);
}
//---------------------------------------------------------------------------
bool Shape::Cmparr(TRect &r1, TRect &r2){
  if ( ( (r1.Left>=r2.Left) && (r1.Left<=r2.Right ) &&
         (r1.Top >=r2.Top ) && (r1.Top <=r2.Bottom) ) ||
       ( (r2.Left>=r1.Left) && (r2.Left<=r1.Right ) &&
         (r2.Top >=r1.Top ) && (r2.Top <=r1.Bottom) ) )
         return false;
  if ( ( r1.Left>=r2.Left) && (r1.Left<=r2.Right) ){
    if ( (r2.Top>=r1.Top ) && (r2.Top<=r1.Bottom) )
         return false;
    if ( (r2.Bottom>=r1.Top) && (r2.Bottom<=r1.Bottom) )
         return false;
    }
  if ( (r1.Right>=r2.Left) && (r1.Right<=r2.Right) ) {
    if ( (r2.Top>=r1.Top)&&(r2.Top<=r1.Bottom) )
         return false;
    if ( (r2.Bottom>=r1.Top)&&(r2.Bottom<=r1.Bottom) )
         return false;
    }
  if ( (r1.Top>=r2.Top)&&(r1.Top<=r2.Bottom) ) {
    if ( (r2.Left>=r1.Left)&&(r2.Left<=r1.Right) )
         return false;
    if ( (r2.Right>=r1.Left)&&(r2.Right<=r1.Right) )
         return false;
    }
  if ( (r1.Bottom>=r2.Top)&&(r1.Bottom<=r2.Bottom) ) {
    if ( (r2.Left>=r1.Left)&&(r2.Left<=r1.Right) )
         return false;
    if ( (r2.Right>=r1.Left)&&(r2.Right<=r1.Right) )
         return false;
    }
  if ( (r2.Left>=r1.Left)&&(r2.Left<=r1.Right) ) {
    if ( (r2.Top>=r1.Top)&&(r2.Top<=r1.Bottom) )
         return false;
    if ( (r2.Bottom>=r1.Top)&&(r2.Bottom<=r1.Bottom) )
         return false;
    }
  if ( (r2.Right>=r1.Left)&&(r2.Right<=r1.Right) ){
    if ( (r1.Top>=r2.Top)&&(r1.Top<=r2.Bottom) )
         return false;
    if ( (r1.Bottom>=r2.Top)&&(r1.Bottom<=r2.Bottom) )
         return false;
    }
  if ( (r2.Top>=r1.Top)&&(r2.Top<=r1.Bottom) ){
    if ( (r1.Left>=r2.Left)&&(r1.Left<=r2.Right) )
         return false;
    if ( (r1.Right>=r2.Left)&&(r1.Right<=r2.Right) )
         return false;
    }
  if ( (r2.Bottom>=r1.Top)&&(r2.Bottom<=r1.Bottom) ) {
    if ( (r1.Left>=r2.Left)&&(r1.Left<=r2.Right) )
         return false;
    if ( (r1.Right>=r2.Left)&&(r1.Right<=r2.Right) )
         return false;
    }
  return true;
}
//---------------------------------------------------------------------------
Shape *Shape::Over ( Shape *shape, TRect &r ){
  if ( shape == this )
    return NULL;
  return Cmparr( rect, r ) ? NULL : this;
}
//---------------------------------------------------------------------------
void Shape::Stoping(TRect &r1, TPoint p1, TPoint p2, Shape *shape){
int dx = p2.x - p1.x;
int dy = p2.y - p1.y;
int error = 0;
  if ( shape == this )
    return;
  while ( frmMain->shapeList->Over ( this, r1 ) != NULL || !IsCorrect ( r1 ) ){
    if ( dy > 0 ){
      if ( r1.Top > 0 ){
        r1.Top--;
        r1.Bottom--;
        }
      }
    else
    if ( dy < 0 ){
      r1.Top++;
      r1.Bottom++;
      }
    if ( dx > 0 ){
      if ( r1.Left > 0 ) {
        r1.Left--;
        r1.Right--;
        }
      }
    else
    if ( dx < 0 ){
      r1.Left++;
      r1.Right++;
      }
    if ( error++ > 50000 ){
      frmMain->shapeList->Allocate ( this );
      r1 = rect;
      break;
      }
    }
  SetPos ( r1 );
}
//---------------------------------------------------------------------------
void __fastcall Shape::MouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y){
TRect r;
  r = Control->BoundsRect;

  if ( !Shift.Contains ( ssLeft ) )
  if ( X <= OFF && Y <= OFF ){
    Control->Cursor = crSizeNWSE; // ���� �����
    numPoint = 1;
    }
  else if ( X >= Control->ClientWidth - OFF && Y <= OFF ){
    Control->Cursor = crSizeNESW; // ���� ������
    numPoint = 3;
    }
  else if ( Y <= OFF ){
    Control->Cursor = crSizeNS;   // ���� ��������
    numPoint = 2;
    }
  else if ( X <= OFF && Y >= Control->ClientHeight - OFF ){
    Control->Cursor = crSizeNESW; // ��� �����
    numPoint = 7;
    }
  else if ( X <= OFF ){
    Control->Cursor = crSizeWE;   // ����� ��������
    numPoint = 8;
    }
  else if ( X >= Control->ClientWidth - OFF && Y >= Control->ClientHeight - OFF ){
    Control->Cursor = crSizeNWSE; // ��� ������
    numPoint = 5;
    }
  else if ( X >= Control->ClientWidth - OFF ){
    Control->Cursor = crSizeWE;   // ������ �� ��������
    numPoint = 4;
    }
  else if ( Y >= Control->ClientHeight - OFF ){
    Control->Cursor = crSizeNS;   // ��� �� ��������
    numPoint = 6;
    }
  else {
    Control->Cursor = crSizeAll; //crHandPoint;
    numPoint = 0;
    }
  if ( Shift.Contains ( ssLeft ) && state == _MOVE_ ){
    switch ( numPoint ){
      case 0:
      	r.Top  += Y - pointPressed.y;
        r.Left += X - pointPressed.x;
      	r.Bottom  += Y - pointPressed.y;
        r.Right += X - pointPressed.x;
        break;
      case 1:
        r.Left += X - pointPressed.x;
      case 2:
        if ( type != _MEDIT_ )
      		r.Top  += Y - pointPressed.y;
        break;
      case 3:
        if ( type != _MEDIT_ )
          r.Top  += Y - pointPressed.y;
      case 4:
        r.Right  = r.Left + X;
        break;
      case 5:
        r.Right =  r.Left + X;
      case 6:
        if ( type != _MEDIT_ )
          r.Bottom = r.Top  + Y;
        break;
      case 7:
        if ( type != _MEDIT_ )
          r.Bottom = r.Top + Y;
      case 8:
        r.Left += X - pointPressed.x;
        break;
      }
    if ( frmMain->shapeList->Over ( this, r ) || !IsCorrect ( r ) )
      Stoping( r, pointPressed, TPoint(X,Y), NULL);
    else
      SetPos ( r );
    }
  frmMain->Draw (Name());
}
//---------------------------------------------------------------------------
void __fastcall Shape::MouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y){
  frmProp->StringGrid1->EditorMode = false;
  frmProp->StringGrid1->Repaint();
  pointPressed = TPoint ( X, Y );
  frmMain->shapeList->Selected = this;
  frmMain->ComboBox1->ItemIndex = frmMain->shapeList->IndexOf ( this );
  state = _MOVE_;
  frmProp->DrawShapeProp ( this );
  ClientRect = ClientRect;
  ((TPanel *)AOwner)->Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall Shape::MouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y){
  state = _SELECTED_;
  Control->Tag = 1;

  frmProp->Refresh ( this );
  ClientRect = ClientRect;
}
//---------------------------------------------------------------------------
TRect *Shape::GetRect(){
  if ( AOwner )
    rect = Control->BoundsRect;
  return &rect;
}
//---------------------------------------------------------------------------
void Shape::SetRect(TRect *rect_){
  if ( AOwner )
    Control->BoundsRect = rect;
}
//---------------------------------------------------------------------------
void Shape::Draw(){
  Control->Invalidate();
}
//---------------------------------------------------------------------------
void Shape::SetPos(TPoint &point){
int w = rect.Width();
int h = rect.Height();
  rect.Top = point.y;
  rect.Left = point.x;
  rect.Bottom = rect.Top + h;
  rect.Right = rect.Left + w;
  ClientRect = &rect;
  if ( frmProp )
    frmProp->Refresh ( this );
}
//---------------------------------------------------------------------------
void Shape::SetPos(TRect &r){
  rect = r;
  ClientRect = &rect;
  if ( frmProp )
    frmProp->Refresh ( this );
}
//---------------------------------------------------------------------------
int Shape::GetWidth(){
  return rect.Width();
}
//---------------------------------------------------------------------------
void Shape::SetWidth(int w){
  rect.Right = rect.Left + w;
  ClientRect = &rect;
}
//---------------------------------------------------------------------------
int Shape::GetHeight(){
  return rect.Height();
}
//---------------------------------------------------------------------------
void Shape::SetHeight(int h){
  rect.Bottom = rect.Top + h;
  ClientRect = &rect;
}
//---------------------------------------------------------------------------
void Shape::Move(TPoint &point){
}
//---------------------------------------------------------------------------
void Shape::SetText ( char *text_ ){
  strncpy ( text, text_, MAXSTR );
  text[MAXSTR] = 0;  
}
//---------------------------------------------------------------------------
char *Shape::GetText(){
  return text;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
MButton::MButton(Classes::TComponent* AOwner, char *name) : Shape(AOwner,name){
  type = _MBUTTON_;
  if ( AOwner ){
    TButton *b = new TButton(AOwner);
    Control = b;
    Initialize();
    b->OnMouseMove = MouseMove;
    b->OnMouseDown = MouseDown;
    b->OnMouseUp   = MouseUp;
    b->OnKeyDown   = KeyDown;
    b->OnEnter     = Enter;
    }
}
//---------------------------------------------------------------------------
void __fastcall MButton::KeyDown(TObject *Sender, WORD &Key, TShiftState Shift){
AnsiString s;
  s = GetText();
  switch ( Key ){
    case '\r':
    case '\n':
    case VK_END:
    case VK_HOME:
    case VK_LEFT:
    case VK_UP:
    case VK_RIGHT:
    case VK_DOWN:
    case 34:
    case 33:
      break;
    case 8:
      s.SetLength ( s.Length() - 1 );
      break;
    default:
      s = s + char(Key);
      break;
    }
  Text = s.c_str();
  frmProp->Refresh ( this );
}
//---------------------------------------------------------------------------
void MButton::SetText ( char *text_ ){
  Shape::SetText ( text_ );
  if ( AOwner )
    ((TButton *)Control)->Caption = Text;
}
//---------------------------------------------------------------------------
void MButton::SaveHTML(int fd){
char buff[1000];

  strcpy ( buff, "<INPUT TYPE=RESET VALUE=\"" );
  strcat ( buff, Text );
  strcat ( buff, "\">" );
  Write ( buff, fd );
}
//---------------------------------------------------------------------------
void MButton::Save(int fd){
  Write ( "<Button", fd );
  SaveRect ( fd );
  Write ( "Caption=\"", fd );
  Write ( Text, fd );
  Write ( "\">\r\n", fd );
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//  M E d i t
//---------------------------------------------------------------------------
MEdit::MEdit(Classes::TComponent* AOwner, char *name) : Shape(AOwner,name){
  type = _MEDIT_;
  if ( AOwner ){
    TMemo *tmemo = new TMemo(AOwner);
    Control = tmemo;
    Initialize();
//    tmemo->AutoSize = false;
    tmemo->OnMouseMove = MouseMove;
    tmemo->OnMouseDown = MouseDown;
    tmemo->OnMouseUp   = MouseUp;
    tmemo->OnChange = TextChange;
    tmemo->Ctl3D = false;
    tmemo->Color = clWindow;
    tmemo->MaxLength = 255;
    tmemo->OnEnter     = Enter;
    }
}
//---------------------------------------------------------------------------
void __fastcall MEdit::TextChange(TObject *Sender){
  Text = ((TMemo *)Control)->Text.c_str();
  if ( frmProp )
    frmProp->Refresh ( this );
}
//---------------------------------------------------------------------------
void MEdit::SetText ( char *text_ ){
  Shape::SetText ( text_ );
  if ( AOwner )
    ((TMemo *)Control)->Text = Text;
}
//---------------------------------------------------------------------------
void MEdit::SaveHTML(int fd){
char buff[1000], str[100];
//int size = strlen(Text);
int size;

  strcpy ( buff, "<INPUT TYPE=TEXT MAXLENGTH=255" );
//  if ( size > 20 ){

//    itoa ( size, str, 10 );
  if ( Width > 0 )
    size = Width/8;
  if ( size > 15 )
    itoa ( size, str, 10 );
  else
    itoa ( 15, str, 10 );

    strcat ( buff, " SIZE=" );
    strcat ( buff, str );
//    }
  strcat ( buff, " VALUE=\"" );
  strcat ( buff, Text );
  strcat ( buff, "\">" );
  Write ( buff, fd );
}
//---------------------------------------------------------------------------
void MEdit::Save(int fd){
  Write ( "<TextEdit", fd );
  SaveRect ( fd );
  Write ( "Text=\"", fd );
  Write ( Text, fd );
  Write ( "\">\r\n", fd );
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
__fastcall TTLabel::TTLabel(Classes::TComponent* AOwner) : TLabel (AOwner){}
//---------------------------------------------------------------------------
void __fastcall TTLabel::Paint(void){
  TLabel::Paint();
  Canvas->Brush->Color = clBlack;
  Canvas->FrameRect(ClientRect);
  if ( Tag != 0 ){
    DrawSelected(Canvas,TPoint(ClientRect.Left,ClientRect.Top));
    DrawSelected(Canvas,TPoint(ClientRect.Right,ClientRect.Top));
    DrawSelected(Canvas,TPoint(ClientRect.Left,ClientRect.Bottom));
    DrawSelected(Canvas,TPoint(ClientRect.Right,ClientRect.Bottom));
    }
  }
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
MLabel::MLabel(Classes::TComponent* AOwner, char *name) : MEdit(AOwner,name){
  type = _MLABEL_;
  if ( AOwner )
    ((TMemo *)Control)->Color = clMenu;
}
//---------------------------------------------------------------------------
void MLabel::Save(int fd){
  Write ( "<Label", fd );
  SaveRect ( fd );
  Write ( "Text=\"", fd );
  Write ( Text, fd );
  Write ( "\">\r\n", fd );
}
//---------------------------------------------------------------------------
void MLabel::SaveHTML(int fd){
  Shape::SaveHTML(fd);
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
ShapeIterator::ShapeIterator(Classes::TComponent* AOwner_) {
  AOwner = AOwner_;
  fd = -1;
  nButtons = nLabels = nEdits = 0;
}
//---------------------------------------------------------------------------
__fastcall ShapeIterator::~ShapeIterator(){
  DeleteObjects();
}
//---------------------------------------------------------------------------
int __fastcall ShapeIterator::Add(void* Item) {
int result = -1;
  if ( IndexOf ( Item  ) == -1 ){
			result = TList::Add(Item);
      Allocate ( (Shape *)Item );
      }
  return result;
}
//---------------------------------------------------------------------------
void __fastcall ShapeIterator::Pack(void){ // ��� �������� shape
  TList::Pack();
}
//---------------------------------------------------------------------------
void ShapeIterator::Draw (){
	for ( int i = 0; i < Count; i++ )
  		((Shape*)Items[i])->Draw ();
}
//---------------------------------------------------------------------------
void ShapeIterator::DeleteObjects(){
Shape *shape;
	for ( int i = Count; i > 0; i-- ){
 		shape=(Shape*)Items[i-1];
		Delete( i-1 );
    delete shape;
    }
  TList::Pack();
}
//---------------------------------------------------------------------------
Shape *ShapeIterator::GetSelected(){
	for ( int i = 0; i < Count; i++ )
    if ( ((Shape*)Items[i])->Selected == true )
      return (Shape*)Items[i];
  return NULL;
}
//---------------------------------------------------------------------------
void ShapeIterator::SetSelected ( Shape *shape ){
	for ( int i = 0; i < Count; i++ )
    if ( shape == Items[i] ){
      ((Shape*)Items[i])->Selected = true;
      if ( AOwner )
        frmMain->ComboBox1->ItemIndex = i;
      }
    else
      ((Shape*)Items[i])->Selected = false;
}
//---------------------------------------------------------------------------
TypeOfShape ShapeIterator::KeyObject ( char *name ){
  if ( strcmpi ( "BUTTON", name ) == 0 )
    return _MBUTTON_;
  else
  if ( strcmpi ( "TEXTEDIT", name ) == 0 )
    return _MEDIT_;
  else
  if ( strcmpi ( "LABEL", name ) == 0 )
    return _MLABEL_;
  return _MERROR_;
}
//---------------------------------------------------------------------------
char *ShapeIterator::StrChr ( char *s, char ch ){
char *ptr = s;
  while ( *ptr ){
    if ( *ptr == ch  )
      if ( *(ptr+1) )
        return ptr + 1;
      else
        return ptr;
    ptr++;
    }
  return NULL;
}
//---------------------------------------------------------------------------
char *ShapeIterator::DelSpace ( char *s ){
char *ptr = s;
  while ( *ptr != 0 ){
    switch ( *ptr ){
      case ' ':
      case '\t':
      case '\r':
      case '\n':
      case ';':
      case '=':
      case '"':
        ptr++;
        break;
      default:
        return ptr;
      }
    }
  return ptr;
}
//---------------------------------------------------------------------------
char *ShapeIterator::ReadNameTag( char *s ){
char buffer[10000];
char *p, *ptr;

  strncpy(buffer,s,9999);
  strupr(buffer);
  buffer[9999]=0;
  ptr = p = DelSpace ( buffer );
  while ( *ptr != 0 ){
    if ( *ptr == ' ' || *ptr == '\t' || *ptr == '\r' || *ptr == '\n' ||
            *ptr == ';' || *ptr == '=' )
        break;
    ptr++;
    }
  *ptr = 0;
  return p;
}
//---------------------------------------------------------------------------
char *ShapeIterator::ReadStringTag( char *s ){
char buffer[10000];
char *p, *ptr;

  strncpy(buffer,s,9999);
  buffer[9999]=0;
  ptr = p = DelSpace ( buffer );
  while ( *ptr != 0 ){
    if ( *ptr == '"' )
        break;
    ptr++;
    }
  *ptr = 0;
  return p;
}
//---------------------------------------------------------------------------
int ShapeIterator::GetInt ( char *s, char *key ){
char buffer[10000];
char *ptr;

  strncpy(buffer,s,9999);
  buffer[9999]=0;
  strupr(buffer);
  ptr = strstr ( buffer, key );
  if ( ptr != NULL ){
    ptr += strlen(key);
    ptr = DelSpace ( ptr );
    ptr = ReadNameTag( ptr );
    return atoi ( ptr );
    }
  return -1;
}
//---------------------------------------------------------------------------
char *ShapeIterator::GetString ( char *s, char *key ){
char buffer[10000];
char *ptr;

  strncpy(buffer,s,9999);
  buffer[9999]=0;
  strupr(buffer);
  ptr = strstr ( buffer, key );
  if ( ptr != NULL ){
    ptr += strlen(key);
    ptr = DelSpace ( ptr );
    char *p = buffer;
    ptr = ReadStringTag( s + (ptr - p) );
    return ptr;
    }
  return NULL;
}
//---------------------------------------------------------------------------
char *ShapeIterator::ReadTag ( int &offset, char begCh, char endCh ){
char *p1, *p2, *retS = NULL;
  p1 = StrChr ( &fBuffer[offset], begCh );
  if ( p1 != NULL ){
    p2 = StrChr ( p1, endCh );
    if ( p2 != NULL ){
      int l = p2 - p1;
      retS = new char [ l ];
      strncpy ( retS, p1, l - 1 );
      retS [ l - 1 ] = 0;
      offset = p2 - fBuffer;
      }
    }
  return retS;
}
//---------------------------------------------------------------------------
Shape *ShapeIterator::ReadObject ( int &offset ){
char *p = ReadTag ( offset, '<', '>' );
char *name, *ptr;
Shape *shape = NULL;
  if ( p != NULL ){
    name = ReadNameTag( p );
    switch ( KeyObject (name ) ){
      case _MBUTTON_:
        sprintf(buf, "Button%d", ++nButtons);
        shape = new MButton ( AOwner, buf );
        break;
      case _MLABEL_:
        sprintf(buf, "Label%d", ++nLabels);
        shape = new MLabel ( AOwner, buf );
        break;
      case _MEDIT_:
        sprintf(buf, "EditText%d", ++nEdits);
        shape = new MEdit ( AOwner, buf );
        break;
      }
    if ( shape ){
      if ( AOwner ){
        frmMain->ComboBox1->Items->Add ( buf );
        frmMain->ComboBox1->ItemIndex = frmMain->ComboBox1->Items->Count-1;
        }
      int l = GetInt ( p, "LEFT" );
      int t = GetInt ( p, "TOP" );
      int w = GetInt ( p, "WIDTH" );
      int h = GetInt ( p, "HEIGHT" );
      TPoint p_ = TPoint(l,t);
      shape->SetPos ( p_ );
      shape->Width = w;
      shape->Height = h;
      Add ( shape );
      Selected = shape;
      switch ( shape->Type ){
        case _MBUTTON_:
          ptr = GetString ( p, "CAPTION" );
          break;
        case _MLABEL_:
        case _MEDIT_:
          ptr = GetString ( p+1, "TEXT" );
          break;
        }
      if ( ptr )
        shape->Text = ptr;
      }
    delete []p;
    }
  return shape;
}
//---------------------------------------------------------------------------
bool ShapeIterator::Load( char *fName){
int fd = -1, offset = 0;
  try {
    if ( (fd = FileOpen( fName, fmOpenRead )) == -1 )
      return false;
    int fileLen = FileSeek ( fd, 0, 2 );
    FileSeek ( fd, 0, 0 );
    fBuffer = new char[fileLen+1];
    if ( FileRead ( fd, fBuffer, fileLen ) == fileLen ){
      fBuffer[fileLen] = 0;
      while ( ReadObject ( offset ) != NULL )
        ;
      }
    delete []fBuffer;
	  FileClose(fd);
    }
  catch(...){
    if ( fd != -1 ){
  	  FileClose(fd);
      delete []fBuffer;
      }
    return false;
    }
  return true;
}
//---------------------------------------------------------------------------
void ShapeIterator::Save( char *fName ){
int fd;
	try {
  	DeleteFile ( fName );
    fd = FileCreate( fName );
  	for ( int i = 0; i < Count; i++ )
      ((Shape *)Items[i])->Save(fd);
	  FileClose(fd);
    }
  catch(...){
    }
}
//---------------------------------------------------------------------------
void ShapeIterator::SaveZeroGif( char *fname ){
char drive[MAXDRIVE];
char dir[MAXDIR];
char file[MAXFILE];
char ext[MAXEXT];
char nameGif[1000];
char	array[]={
	 71, 73, 70, 56, 57, 97,  1,  0,  1,  0,128,  0,  0,255,  0,255,
	  0,  0,  0, 33,249,  4,  1,  0,  0,  0,  0, 44,  0,  0,  0,  0,
	  1,  0,  1,  0,  0,  2,  2, 68,  1,  0, 59,
	};

  fnsplit(fname,drive,dir,file,ext);
  fnmerge(nameGif,drive,dir,"zero","gif");

  if ( FileExists ( nameGif ) )
    return;
  int fd = FileCreate ( nameGif );
  FileWrite ( fd, array, 43 );
  FileClose ( fd );
}
//---------------------------------------------------------------------------
void ShapeIterator::SaveHTML( char *fName ){
Shaps *s;
Shape *shape;
int NPoints = Count;
TDataToHTML *toHtml= new TDataToHTML[1000];
int result = 1000;

  SaveZeroGif( fName );

  s = new Shaps[Count];
  SaveZeroGif( fName );
  try {
    for ( int i = 0; i < Count; i++ ){
      shape = (Shape *)Items[i];
      s[i].x = shape->ClientRect->Left;
      s[i].y = shape->ClientRect->Top;
      s[i].width = shape->ClientRect->Width();
      s[i].height = shape->ClientRect->Height();
      }
    if ( Count > 0 )
      Table ( NPoints, s, Count, toHtml, result);
    }
  catch (...){
		MessageBox( 0, "������ �������������!", "������!", MB_OK|MB_SYSTEMMODAL);
    }
  delete []s;

	try {
  	DeleteFile ( fName );
    fd = FileCreate( fName );

    WriteLn ("<HTML>");
    WriteTitle ( "���� HTML �����" );
    WriteLn ("<BODY>");

    WriteHeader ( fName );

    CalcColumns ( toHtml, NPoints );
    int index = 0;

    while ( index < NPoints )
      WriteTable ( toHtml, NPoints, index );

    WriteLn ("\r\n</BODY>" );
		WriteLn ("</HTML>" );
	  FileClose(fd);
    fd = -1;
    }
  catch(...){
			MessageBox( 0, "������ ����������!", "������!", MB_OK|MB_SYSTEMMODAL);
			}
  delete []toHtml;
}
//---------------------------------------------------------------------------
void ShapeIterator::WriteTable(TDataToHTML *toHtml, int NPoint, int &index){
AnsiString s;
  if ( toHtml[index].Ntabl == -1 && index == 0 ){
    int width = GetWidthTable ( toHtml, NPoint, 0, -1);
#ifdef BORDER
    s="<TABLE BORDER=1 CELLSPACING=0 CELLPADDING=0 WIDTH="+IntToStr(width)+">";
#else
    s="<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="+IntToStr(width)+">";
#endif
    WriteLn ( s.c_str() );
    }
  else
#ifdef BORDER
    WriteLn ("<TABLE BORDER=1 CELLSPACING=0 CELLPADDING=0 WIDTH=100%>");
#else
    WriteLn ("<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=100%>");
#endif
  ///////// ���� ������� //////////
  WriteLn ( "<TBODY>");
  int oldIndex = toHtml[index].Ntabl;
  while ( toHtml[index].Ntabl == oldIndex && index < NPoint ){
    WriteRow ( toHtml, NPoint, index );
    //index++;
    }
  WriteLn ( "</TBODY>");
  ////////  ����� ����  //////////
  WriteLn ("</TABLE>" );
}
//---------------------------------------------------------------------------
void ShapeIterator::WriteRow(TDataToHTML *toHtml, int NPoint, int &index){
int oldR = toHtml[index].Row, table = toHtml[index].Ntabl;
int countImg = 0;
bool emptyRow = rowEmpty ( toHtml, index, NPoint );
  WriteBegRow ( toHtml[index].Height );
  while ( toHtml[index].Row == oldR && index < NPoint && table == toHtml[index].Ntabl){
    if ( toHtml[index].Ntabl == -1 && toHtml[index].nObject == -2 )// �������
      WriteCellT (toHtml, NPoint, index);
    else
    if ( toHtml[index].nObject > 0 && toHtml[index].Ntabl != -1 )  // �� ������ ������
      WriteCell ((Shape *)Items[toHtml[index].nObject-1], toHtml[index].nCellsX, toHtml[index].nCellsY, toHtml[index].Width );
    else
    if ( toHtml[index].nObject == 0 || toHtml[index].Ntabl == -1 ){ // ������ ������
      if ( countImg == 0 && emptyRow ){
        countImg++;
        WriteZeroImg (toHtml, NPoint, index);
        }
      else
        WriteCell (NULL, toHtml[index].nCellsX, toHtml[index].nCellsY, toHtml[index].Width);
      }
    index++;
    }
  WriteEndRow ();
}
//---------------------------------------------------------------------------
int ShapeIterator::GetWidthTable(TDataToHTML *toHtml,int count,int off,int key){
int w = 0, r = toHtml[off].Row;
  for ( int i = off; i < count; i++ ){
    if ( toHtml[i].Ntabl == key && r == toHtml[i].Row )
      w += toHtml[i].Width;
    else
      break;
    }
  return w;
}
//---------------------------------------------------------------------------
void ShapeIterator::CalcColumns(TDataToHTML *toHtml, int count){
TDataToHTML *html;
int *w;
  if ( count > 0 ){
    int oldR = toHtml[0].Row;
    w = &(toHtml[0].Width);
    for ( int j = 0; j < count; j++ ){
      html = &toHtml[j];
      if ( oldR != html->Row )
        oldR = html->Row;
      if ( html->nObject == -1 )
        *w += html->Width;
      else
        w = &(html->Width);
      }
    }
}
//---------------------------------------------------------------------------
bool ShapeIterator::rowEmpty(TDataToHTML *toHtml, int i, int count){
TDataToHTML *html;
int oldR = toHtml[i].Row;
int x = toHtml[i].Ntabl;
//  if ( oldR == 0 )
//    return false;
  for ( int j = i; j < count; j++ ){
    html = &toHtml[j];
    if ( oldR != html->Row || html->Ntabl != x )
      return true;
    if ( html->nObject > 0 || html->nCellsX > 1 || html->nCellsY > 1 )
      return false;
    }
  return true;
}
//---------------------------------------------------------------------------
void ShapeIterator::WriteHeader ( char *s ){
AnsiString s_;
  if ( fd == -1 )
    return;
  s_ = "\r\n<H1>" + AnsiString(s) + "</H1>";
  WriteLn ( s_.c_str() );
}
//---------------------------------------------------------------------------
void ShapeIterator::WriteTitle ( char *s ){
  if ( fd == -1 )
    return;
  WriteLn ( "<HEAD>" );
  Write ( "  <TITLE>" );
  Write ( s );
  WriteLn ( "</TITLE>" );
  WriteLn ("  <META CONTENT=\"text/html; charset=Windows-1251\" HTTP-EQUIV=\"Content-Type\">");
  WriteLn ( "</HEAD>" );
}
//---------------------------------------------------------------------------
void ShapeIterator::WriteCell(Shape *shape,int nCellsX,int nCellsY, int width){
AnsiString s;
  if ( fd == -1 )
    return;
  if ( width > 0 )
    s = "    <TD WIDTH=" + IntToStr(width);
  else
    s = "    <TD";
  if ( nCellsX > 1 )
    s = s + " COLSPAN=" + IntToStr(nCellsX);
  if ( nCellsY > 1 )
    s = s + " ROWSPAN=" + IntToStr(nCellsY);
  s = s + ">";
  Write ( s.c_str() );
  if ( shape != NULL )
    shape->SaveHTML ( fd );
  else
    Write ( BLANK );
  WriteLn ( "</TD>" );
}
//---------------------------------------------------------------------------
void ShapeIterator::WriteZeroImg( TDataToHTML *toHtml, int NPoint, int &index){
AnsiString s;
  if ( fd == -1 )
    return;
  s = "    <TD";
  if ( toHtml[index].nCellsX > 1 )
    s = s + " COLSPAN=" + IntToStr(toHtml[index].nCellsX);
  if ( toHtml[index].nCellsY > 1 )
    s = s + " ROWSPAN=" + IntToStr(toHtml[index].nCellsY);
  s = s + ">";
  Write ( s.c_str() );
#ifdef BORDER
  s = "<IMG SRC=\"zero.gif\" border=1";
#else
  s = "<IMG SRC=\"zero.gif\" border=0";
#endif
  s = s + " HEIGHT=" + IntToStr(toHtml[index].Height);
  s = s + " WIDTH=" + IntToStr(toHtml[index].Width);
  s = s + ">";
  Write ( s.c_str() );
  WriteLn ( "</TD>" );
}
//---------------------------------------------------------------------------
void ShapeIterator::WriteCellT( TDataToHTML *toHtml, int NPoint, int &index){
AnsiString s;
  if ( fd == -1 )
    return;
  if ( toHtml[index].Width > 0 )
    s = "    <TD WIDTH=" + IntToStr(toHtml[index].Width);
  else
    s = "    <TD";
  if ( toHtml[index].nCellsX > 1 )
    s = s + " COLSPAN=" + IntToStr(toHtml[index].nCellsX);
  if ( toHtml[index].nCellsY > 1 )
    s = s + " ROWSPAN=" + IntToStr(toHtml[index].nCellsY);
  s = s + ">";
  WriteLn ( s.c_str() );
  while ( toHtml[index].Ntabl == -1 )
    index++;
  while ( index < NPoint )
    WriteTable(toHtml, NPoint, index);
  WriteLn ( "</TD>" );
}
//---------------------------------------------------------------------------
void ShapeIterator::WriteBegRow ( int height ){
AnsiString s;
  if ( fd == -1 )
    return;
  s = "  <TR VALIGN=TOP ALIGN=LEFT HEIGHT=" + IntToStr(height) + ">";
  WriteLn ( s.c_str() );
}
//---------------------------------------------------------------------------
void ShapeIterator::WriteEndRow (){
  WriteLn ( "  </TR>" );
}
//---------------------------------------------------------------------------
void ShapeIterator::WriteLn ( char *s ){
  Write ( s );
  Write ( "\r\n" );
}
//---------------------------------------------------------------------------
void ShapeIterator::Write ( char *s ){
  if ( fd == -1 )
    return;
  FileWrite(fd,s,strlen(s));
}
//---------------------------------------------------------------------------
Shape *ShapeIterator::Over ( Shape *shape, TRect &r ){
Shape *shapeR;
	for ( int i = 0; i < Count; i++ )
    if ( (shapeR = ((Shape*)Items[i])->Over ( shape, r )) != NULL )
      return shapeR;
  return NULL;
}
//---------------------------------------------------------------------------
void ShapeIterator::Allocate ( Shape *shape ){
TRect r = *shape->ClientRect;
  while ( Over ( shape, r ) || !shape->IsCorrect ( r ) ){
    while ( r.Left < 0 ){
      r.Left++;
      r.right++;
      }
    if ( r.Left + 2 > r.Right )
      r.Right = r.Left + WIDTH;
    if ( r.Top + 2 > r.Bottom )
      r.Bottom = r.Top + HEIGHT;
    r.Top++;
    r.Bottom++;
    shape->SetPos ( r );
    }
}
//---------------------------------------------------------------------------

