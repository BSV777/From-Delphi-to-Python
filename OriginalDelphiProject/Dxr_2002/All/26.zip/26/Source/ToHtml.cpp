//---------------------------------------------------------------------------
#include <vcl.h>

#include "Shapes.h"

#pragma hdrstop
USERES("ToHtml.res");
USEFORM("untMain.cpp", frmMain);
USEUNIT("Shapes.cpp");
USEFORM("untProperty.cpp", frmProp);
USEUNIT("tabl.pas");
USEFORM("UnAb.cpp", AboutBox);
USEFORM("untView.cpp", frmHTML);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int){
ShapeIterator *shapeList;
  try {
    if ( ParamCount() == 2 ){
      shapeList = new ShapeIterator ( NULL );
     	shapeList->Load ( ParamStr(1).c_str() );
      shapeList->SaveHTML(ParamStr(2).c_str());
      delete shapeList;
      }
    else {
     Application->Initialize();
     Application->CreateForm(__classid(TfrmMain), &frmMain);
     Application->CreateForm(__classid(TfrmProp), &frmProp);
     Application->CreateForm(__classid(TAboutBox), &AboutBox);
//     Application->CreateForm(__classid(TfrmHTML), &frmHTML);
     Application->Run();
     }
  }
  catch (Exception &exception)
  {
     Application->ShowException(&exception);
  }
  return 0;
}
//---------------------------------------------------------------------------
