//---------------------------------------------------------------------------
#ifndef untViewH
#define untViewH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <NMHTML.hpp>
#include <OleCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TfrmHTML : public TForm
{
__published:	// IDE-managed Components
  TPanel *Panel1;
  TButton *btnRequery;
  TPanel *Panel2;
  THTML *HTML1;
  void __fastcall btnRequeryClick(TObject *Sender);
  void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
  void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
  __fastcall TfrmHTML(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmHTML *frmHTML;
//---------------------------------------------------------------------------
#endif
