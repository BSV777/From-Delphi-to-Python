//---------------------------------------------------------------------------
#ifndef untPropertyH
#define untPropertyH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------

class Shape;

class TfrmProp : public TForm
{
__published:	// IDE-managed Components
  TStringGrid *StringGrid1;
  void __fastcall StringGrid1KeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
  void __fastcall StringGrid1SelectCell(TObject *Sender, int ACol,
          int ARow, bool &CanSelect);
  void __fastcall StringGrid1GetEditMask(TObject *Sender, int ACol,
          int ARow, AnsiString &Value);
  void __fastcall StringGrid1GetEditText(TObject *Sender, int ACol,
          int ARow, AnsiString &Value);
  void __fastcall FormResize(TObject *Sender);
  void __fastcall FormActivate(TObject *Sender);
  void __fastcall FormCreate(TObject *Sender);
  void __fastcall FormHide(TObject *Sender);
private:	// User declarations
  Shape *shape;
public:		// User declarations
  __fastcall TfrmProp(TComponent* Owner);
  void DrawShapeProp ( Shape *shape );
  void Refresh ( Shape *shape );
  void RefreshShape ();
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmProp *frmProp;
//---------------------------------------------------------------------------
#endif
