// EditorView.cpp : implementation file
//

#include "stdafx.h"
#include "Editor.h"
#include "EditorView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditorView

IMPLEMENT_DYNCREATE(CEditorView, CView)

CEditorView::CEditorView()
{
}

CEditorView::~CEditorView()
{
}


BEGIN_MESSAGE_MAP(CEditorView, CView)
	//{{AFX_MSG_MAP(CEditorView)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_RBUTTONDOWN()
	ON_WM_SIZE()
	ON_WM_TIMER()
	ON_COMMAND(E_DELETE, OnDelete)
	ON_COMMAND(E_SELECT_ALL, OnSelectAll)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_COMMAND(E_BUTTON, OnButton)
	ON_COMMAND(E_CURSOR, OnCursor)
	ON_COMMAND(E_EDIT, OnEdit)
	ON_COMMAND(E_LABEL, OnLabel)
	ON_COMMAND(E_FILE_SAVE_AS, OnFileSaveAs)
	ON_COMMAND(E_FILE_OPEN, OnFileOpen)
	ON_COMMAND(E_ALIGN_HEIGHT, OnAlignHeight)
	ON_COMMAND(E_ALIGN_LEFT, OnAlignLeft)
	ON_COMMAND(E_ALIGN_TOP, OnAlignTop)
	ON_COMMAND(E_ALIGN_WIDTH, OnAlignWidth)
	ON_COMMAND(E_PROPERTIES, OnProperties)
	ON_WM_LBUTTONDBLCLK()
	ON_COMMAND(E_FILE_NEW, OnFileNew)
	ON_COMMAND(E_FILE_SAVE, OnFileSave)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditorView drawing

void CEditorView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CEditorView diagnostics

#ifdef _DEBUG
void CEditorView::AssertValid() const
{
	CView::AssertValid();
}

void CEditorView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CEditorView message handlers

int CEditorView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
  CClientDC *m_pDC = new CClientDC(this);
  GLEngine1.glDC=m_pDC->GetSafeHdc();
  GLEngine1.SetupPixelFormat();
  GLEngine1.Init();
  GLEngine1.pEBase=&EBase1;
  SetTimer(1,0,0);
  FileName="";
  	return 0;
}

void CEditorView::OnDestroy() 
{
	CView::OnDestroy();
	
	wglMakeCurrent(GLEngine1.glDC,GLEngine1.glRC);
	wglDeleteContext(GLEngine1.glRC);
	
}

void CEditorView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	LastX=point.x;
	LastY=point.y;
	
	if((EBase1.instrument== EBUTTON)||
       (EBase1.instrument== EEDIT)|| 
	   (EBase1.instrument== ELABEL))
       EBase1.AddObject(LastX-EBase1.xScroll,LastY-EBase1.yScroll);
	else
	if(EBase1.instrument!=ESCROLL)
	{
	 EBase1.Select(CPoint(LastX-EBase1.xScroll,LastY-EBase1.yScroll));
	
	if(EBase1.instrument==ESELECT)
	{
	        EBase1.SV.left=LastX-EBase1.xScroll;
	        EBase1.SV.bottom=LastY-EBase1.yScroll;
	        EBase1.SV.right=LastX-EBase1.xScroll;
            EBase1.SV.top=LastY-EBase1.yScroll;
			
	 }
	}
	
	CView::OnLButtonDown(nFlags, point);
}

void CEditorView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if(EBase1.instrument==ESELECT)
	 EBase1.GroupSelect();
    if((EBase1.instrument==EMOVE)||(EBase1.instrument==ERESIZE))
	  EBase1.HitTest();
	EBase1.instrument=EWORK;

	CView::OnLButtonUp(nFlags, point);
}

void CEditorView::OnMouseMove(UINT nFlags, CPoint point) 
{
	
	if(nFlags==MK_LBUTTON)
	{
	switch(EBase1.instrument)
	{
	case EMOVE:
		EBase1.Move(point.x-LastX,point.y-LastY);
		break;
	case ESELECT:
        EBase1.SV.right=point.x-EBase1.xScroll;
		EBase1.SV.top=point.y-EBase1.yScroll;
    	break;
	case ESCROLL:
        EBase1.xScroll+=point.x-LastX;
	    EBase1.yScroll+=point.y-LastY;
	    if(EBase1.xScroll>0)
		  EBase1.xScroll=0;
	    if(EBase1.yScroll>0)
		  EBase1.yScroll=0;
		break;
	case ERESIZE:
        EBase1.Resize(point.x-LastX,point.y-LastY);
		break;
	}
	}
	GLEngine1.x=point.x-EBase1.xScroll;
	GLEngine1.y=point.y-EBase1.yScroll;

	LastX=point.x;
	LastY=point.y;
	
	CView::OnMouseMove(nFlags, point);
}

void CEditorView::OnRButtonDown(UINT nFlags, CPoint point) 
{
   EBase1.Select(CPoint(point.x-EBase1.xScroll,point.y-EBase1.yScroll));
   EBase1.instrument=EWORK;
   ClientToScreen(&point);
   CMenu* edit_menu = AfxGetMainWnd()->GetMenu()->GetSubMenu(1);    
   edit_menu->TrackPopupMenu(TPM_LEFTALIGN |TPM_LEFTBUTTON, point.x,   
                               point.y, this);
      
   CView::OnRButtonDown(nFlags, point);
}

void CEditorView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	wglMakeCurrent(GLEngine1.glDC,GLEngine1.glRC);
	GLEngine1.Resize(cx,cy);
	
}

void CEditorView::OnTimer(UINT nIDEvent) 
{
	wglMakeCurrent(GLEngine1.glDC,GLEngine1.glRC);
	GLEngine1.Draw();
	CView::OnTimer(nIDEvent);
}

void CEditorView::OnDelete() 
{
	EBase1.DeleteObject();
	
}

void CEditorView::OnSelectAll() 
{
	EBase1.SelectAll();
	
}

void CEditorView::OnEditCopy() 
{
	EBase1.Copy();
	
}

void CEditorView::OnEditCut() 
{
		EBase1.Cut();
	
}

void CEditorView::OnEditPaste() 
{
	EBase1.Paste(GLEngine1.x,GLEngine1.y);
	
}

void CEditorView::OnButton() 
{
 EBase1.instrument=EBUTTON;		
}

void CEditorView::OnCursor() 
{
 if(EBase1.instrument!=ESCROLL)
   EBase1.instrument=ESCROLL;
 else
   EBase1.instrument=EMOVE;
}

void CEditorView::OnEdit() 
{
 EBase1.instrument=EEDIT;		
}

void CEditorView::OnLabel() 
{
 EBase1.instrument=ELABEL;		
}

void CEditorView::OnFileSaveAs() 
{
 CFileDialog fd(false);  
 CString s("Editor ����(*.edi)");s+=(TCHAR)NULL;
 s+="*.edi"; s+=(TCHAR)NULL;
 s+="HTML ����(*.htm)"; s+=(TCHAR)NULL;
 s+="*.htm"; s+=(TCHAR)NULL;
 s+="������ ����(*.*)"; s+=(TCHAR)NULL;
 s+="*.*";  s+=(TCHAR)NULL;
 fd.m_ofn.lpstrFilter=s;
 fd.m_ofn.lpstrDefExt="edi";
 if(fd.DoModal()==IDOK)
  if(fd.GetFileExt()!="htm")
  EBase1.SaveToFile(FileName=fd.GetFileName());
  else
  EBase1.SaveToHTML(FileName=fd.GetFileName());
}

void CEditorView::OnFileOpen() 
{
 CFileDialog fd(true);
 CString s("Editor �����(*.edi)");s+=(TCHAR)NULL;
 s+="*.edi"; s+=(TCHAR)NULL;
 s+="��� �����(*.*)"; s+=(TCHAR)NULL;
 s+="*.*";  s+=(TCHAR)NULL;
 fd.m_ofn.lpstrFilter=s;
 if(fd.DoModal()==IDOK)
  EBase1.LoadFromFile(FileName=fd.GetFileName());
}

void CEditorView::OnAlignHeight() 
{
	EBase1.Align(4);
	
}

void CEditorView::OnAlignLeft() 
{
	EBase1.Align(1);
	
}

void CEditorView::OnAlignTop() 
{
	EBase1.Align(2);
	
}

void CEditorView::OnAlignWidth() 
{
	EBase1.Align(3);
	
}

void CEditorView::OnProperties() 
{
	if(EBase1.CurrentObj!=-1)
	{
	EProperties prop(NULL);
	prop.pEBase=&EBase1;
	prop.DoModal();
	}
}

void CEditorView::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
    if(EBase1.Select(CPoint(point.x-EBase1.xScroll,point.y-EBase1.yScroll))!=-1)
	{
	EProperties prop(NULL);
	prop.pEBase=&EBase1;
	prop.DoModal();
	}
	CView::OnLButtonDblClk(nFlags, point);
}


void CEditorView::OnFileNew() 
{
	EBase1.DeleteAll();
	FileName="";
	
}

void CEditorView::OnFileSave() 
{
	if(FileName!="")
    EBase1.SaveToFile(FileName);
	else
    CEditorView::OnFileSaveAs();
}

