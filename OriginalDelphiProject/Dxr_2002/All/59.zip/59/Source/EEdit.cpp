// EEdit.cpp: implementation of the EEdit class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Editor.h"
#include "EEdit.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

EEdit::~EEdit()
{
}




void EEdit::Draw(int xs,int ys)
{
 glColor3f(0.0,0.0,0.0);
 glBegin(GL_QUADS);
   glVertex3i(rect.left,rect.bottom,-1); 
   glVertex3i(rect.left,rect.top,-1); 
   glVertex3i(rect.left+2,rect.top+2,-1); 
   glVertex3i(rect.left+2,rect.bottom-2,-1); 
 glEnd();
 glBegin(GL_QUADS);
   glVertex3i(rect.left,rect.top,-1); 
   glVertex3i(rect.right,rect.top,-1); 
   glVertex3i(rect.right-2,rect.top+2,-1); 
   glVertex3i(rect.left+2,rect.top+2,-1); 
 glEnd();
 glColor3f(0.75,0.75,0.75);
 glBegin(GL_QUADS);
   glVertex3i(rect.left,rect.bottom,-1); 
   glVertex3i(rect.left+2,rect.bottom-2,-1); 
   glVertex3i(rect.right-2,rect.bottom-2,-1); 
   glVertex3i(rect.right,rect.bottom,-1); 
 glEnd();
 glBegin(GL_QUADS);
   glVertex3i(rect.right,rect.top,-1); 
   glVertex3i(rect.right,rect.bottom,-1); 
   glVertex3i(rect.right-2,rect.bottom-2,-1); 
   glVertex3i(rect.right-2,rect.top+2,-1); 
 glEnd();
 
 glColor3f(1.0,1.0,1.0);
 glBegin(GL_QUADS);
   glVertex3i(rect.left+2,rect.bottom-2,-1); 
   glVertex3i(rect.left+2,rect.top+2,-1); 
   glVertex3i(rect.right-2,rect.top+2,-1); 
   glVertex3i(rect.right-2,rect.bottom-2,-1); 
 glEnd();
 
 glPushAttrib(GL_ALL_ATTRIB_BITS);
 glDepthFunc(GL_ALWAYS);
 
 int m[4];
 glGetIntegerv(GL_VIEWPORT,&m[0]);

 int w=rect.right-rect.left;
 int h=rect.bottom-rect.top;
 int xr=(rect.left+2);
 int yr=(rect.bottom+2);

 glEnable(GL_SCISSOR_TEST);
 glScissor(xr+xs,m[3]-(yr+ys),w-2,h-2);
 
 xr=rect.left+2;
 yr=rect.top+(h/2);

 glColor3f(0.0,0.0,0.0);
  glRasterPos3i(xr,yr+4,-1);
  glCallLists (Caption.GetLength(), GL_UNSIGNED_BYTE,(LPCTSTR)Caption); 
  glDisable(GL_SCISSOR_TEST);
 glPopAttrib();
}

EEdit::EEdit()
{

}

EEdit::EEdit(int x, int y)
{
	 ID_object=EEDIT;
    DefaultWidth=80;
	DefaultHeight=28;
	MinWidth=12;
	MinHeight=24;
    Caption="Edit";
    
    if(x<int(DefaultWidth/2))
		x=int(DefaultWidth/2);
	
	if(y<int(DefaultHeight/2))
		y=int(DefaultHeight/2);

	rect.left=x-(int)(DefaultWidth/2);
	rect.right=x+(int)(DefaultWidth/2);
	rect.top=y-(int)(DefaultHeight/2);
	rect.bottom=y+(int)(DefaultHeight/2);
	
	prevRect=rect;
	status=1;
}
