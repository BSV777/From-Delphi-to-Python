// EProperties.cpp : implementation file
//

#include "stdafx.h"
#include "Editor.h"
#include "EProperties.h"
#include "EObject.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// EProperties dialog


EProperties::EProperties(CWnd* pParent /*=NULL*/)
	: CDialog(EProperties::IDD, pParent)
{
	//{{AFX_DATA_INIT(EProperties)
	top = 0;
	left = 0;
	bottom = 0;
	right = 0;
	caption = _T("");
	text = _T("");
	//}}AFX_DATA_INIT
}


void EProperties::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(EProperties)
	DDX_Control(pDX, IDC_EDIT6, textCtrl);
	DDX_Control(pDX, IDC_EDIT5, captionCtrl);
	DDX_Text(pDX, IDC_EDIT2, top);
	DDV_MinMaxInt(pDX, top, 0, 5000);
	DDX_Text(pDX, IDC_EDIT1, left);
	DDV_MinMaxInt(pDX, left, 0, 5000);
	DDX_Text(pDX, IDC_EDIT3, bottom);
	DDV_MinMaxInt(pDX, bottom, 0, 5000);
	DDX_Text(pDX, IDC_EDIT4, right);
	DDV_MinMaxInt(pDX, right, 0, 5000);
	DDX_Text(pDX, IDC_EDIT5, caption);
	DDV_MaxChars(pDX, caption, 255);
	DDX_Text(pDX, IDC_EDIT6, text);
	DDV_MaxChars(pDX, text, 255);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(EProperties, CDialog)
	//{{AFX_MSG_MAP(EProperties)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// EProperties message handlers

void EProperties::OnButton1() 
{
	UpdateData(true);
	((EObject *)(pEBase->ArrayObject[pEBase->CurrentObj]))->rect.left=left;
	((EObject *)(pEBase->ArrayObject[pEBase->CurrentObj]))->rect.top=top;
	((EObject *)(pEBase->ArrayObject[pEBase->CurrentObj]))->rect.bottom=bottom;
	((EObject *)(pEBase->ArrayObject[pEBase->CurrentObj]))->rect.right=right;
	switch(((EObject *)(pEBase->ArrayObject[pEBase->CurrentObj]))->ID_object)
	{
    case EBUTTON:
        ((EObject *)(pEBase->ArrayObject[pEBase->CurrentObj]))->Caption=caption;
		break;
	case EEDIT:
	case ELABEL:
        ((EObject *)(pEBase->ArrayObject[pEBase->CurrentObj]))->Caption=text;
		break;
	}
	pEBase->HitTest();
	OnOK();
}

void EProperties::OnButton2() 
{
	OnCancel();
}

BOOL EProperties::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CStatic k;
	left=((EObject *)(pEBase->ArrayObject[pEBase->CurrentObj]))->rect.left;
	top=((EObject *)(pEBase->ArrayObject[pEBase->CurrentObj]))->rect.top;
	bottom=((EObject *)(pEBase->ArrayObject[pEBase->CurrentObj]))->rect.bottom;
	right=((EObject *)(pEBase->ArrayObject[pEBase->CurrentObj]))->rect.right;
	switch(((EObject *)(pEBase->ArrayObject[pEBase->CurrentObj]))->ID_object)
	{
    case EBUTTON:
        caption=((EObject *)(pEBase->ArrayObject[pEBase->CurrentObj]))->Caption;
		text="";
		textCtrl.ModifyStyle(WS_VISIBLE,WS_DISABLED,0);
		break;
	case EEDIT:
	case ELABEL:
        text=((EObject *)(pEBase->ArrayObject[pEBase->CurrentObj]))->Caption;
		caption="";
		captionCtrl.ModifyStyle(WS_VISIBLE,WS_DISABLED,0);
		break;
	}
	
	
	
	UpdateData(false);
	return TRUE;  // return TRUE unless you set the focus to a control
}
