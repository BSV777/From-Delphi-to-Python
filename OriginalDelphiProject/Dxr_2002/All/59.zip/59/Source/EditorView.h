#if !defined(AFX_EDITORVIEW_H__64062B75_3A57_11D6_B052_F85806D7264A__INCLUDED_)
#define AFX_EDITORVIEW_H__64062B75_3A57_11D6_B052_F85806D7264A__INCLUDED_

#include "GLEngine.h"	// Added by ClassView
#include "EBase.h"	// Added by ClassView
#include "EProperties.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EditorView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEditorView view

class CEditorView : public CView
{
protected:
	CEditorView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CEditorView)

// Attributes
public:

// Operations
public:
	CString FileName;
	int LastX,LastY;
	EBase EBase1;
	GLEngine GLEngine1;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditorView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CEditorView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CEditorView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDelete();
	afx_msg void OnSelectAll();
	afx_msg void OnEditCopy();
	afx_msg void OnEditCut();
	afx_msg void OnEditPaste();
	afx_msg void OnButton();
	afx_msg void OnCursor();
	afx_msg void OnEdit();
	afx_msg void OnLabel();
	afx_msg void OnFileSaveAs();
	afx_msg void OnFileOpen();
	afx_msg void OnAlignHeight();
	afx_msg void OnAlignLeft();
	afx_msg void OnAlignTop();
	afx_msg void OnAlignWidth();
	afx_msg void OnProperties();
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnFileNew();
	afx_msg void OnFileSave();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITORVIEW_H__64062B75_3A57_11D6_B052_F85806D7264A__INCLUDED_)
