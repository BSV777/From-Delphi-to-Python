// EObject.h: interface for the EObject class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EOBJECT_H__94AED320_31E7_11D6_B052_D070AE7C8A47__INCLUDED_)
#define AFX_EOBJECT_H__94AED320_31E7_11D6_B052_D070AE7C8A47__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <gl\gl.h>
#include <gl\glu.h>
#include <gl\glaux.h>
#include <math.h>

#define EBUTTON 10
#define EEDIT   11
#define ELABEL  12

class EObject  
{
public:
	CString ObjToLine();
	void resize(int x,int y);
	virtual void Draw(int xs,int ys);
	short ID_object;
	CString Caption;
	CRect rect;
	CRect prevRect;
	void DrawResize();
	int resizeNum;
	bool select(CRect r);
	void move(int x, int y);
	int select(CPoint p);
	short status;
	int MinWidth,MinHeight,DefaultWidth,DefaultHeight;
	EObject();

	virtual ~EObject();

};

#endif // !defined(AFX_EOBJECT_H__94AED320_31E7_11D6_B052_D070AE7C8A47__INCLUDED_)
