// ELabel.cpp: implementation of the ELabel class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Editor.h"
#include "ELabel.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


ELabel::~ELabel()
{
}




void ELabel::Draw(int xs,int ys)
{
glColor3f(0.6,0.6,0.6);
 glBegin(GL_QUADS);
   glVertex3i(rect.left,rect.bottom,-1); 
   glVertex3i(rect.left,rect.top,-1); 
   glVertex3i(rect.right,rect.top,-1); 
   glVertex3i(rect.right,rect.bottom,-1); 
 glEnd();
 
 glPushAttrib(GL_ALL_ATTRIB_BITS);
 glDepthFunc(GL_ALWAYS);
 int m[4];
 glGetIntegerv(GL_VIEWPORT,&m[0]);

 int w=rect.right-rect.left;
 int h=rect.bottom-rect.top;
 int xr=(rect.left);
 int yr=(rect.bottom);
 
 glEnable(GL_SCISSOR_TEST);
 glScissor(xr+xs,m[3]-(yr+ys),w,h); 
 
 
 xr=rect.left+((w-(8*Caption.GetLength()))/2);
 yr=rect.top+(h/2);
 
 glColor3f(0.0,0.0,0.0);
  glRasterPos3i(xr+2
	  ,yr+4,-1);
  
  glCallLists (Caption.GetLength(), GL_UNSIGNED_BYTE,(LPCTSTR)Caption); 
  glDisable(GL_SCISSOR_TEST);
 glPopAttrib();
}

ELabel::ELabel()
{

}

ELabel::ELabel(int x, int y)
{
  ID_object=ELABEL;
	DefaultWidth=36;
	DefaultHeight=16;
	MinWidth=MinHeight=16;
    Caption="Label";

	if(x<int(DefaultWidth/2))
		x=int(DefaultWidth/2);
	
	if(y<int(DefaultHeight/2))
		y=int(DefaultHeight/2);
	
	rect.left=x-(int)(DefaultWidth/2);
	rect.right=x+(int)(DefaultWidth/2);
	rect.top=y-(int)(DefaultHeight/2);
	rect.bottom=y+(int)(DefaultHeight/2);

	prevRect=rect;
	status=1;
}
