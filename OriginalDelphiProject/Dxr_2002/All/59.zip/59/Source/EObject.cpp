// EObject.cpp: implementation of the EObject class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Editor.h"
#include "EObject.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
#include "EButton.h"

EObject::EObject()
{
 status=1;
}

EObject::~EObject()
{

}

int EObject::select(CPoint p)
{
	  int h;
	  CRectTracker tr((LPRECT)rect,CRectTracker::resizeOutside);
	  tr.m_nHandleSize=10;
	  if((h=tr.HitTest(p))==8)
        status=1;
	  prevRect=rect;
	  return h;
}

void EObject::move(int x, int y)
{
 rect.left+=x;
 rect.right+=x;
 rect.top+=y;
 rect.bottom+=y;
 if(rect.left<0)
 {
	 rect.right+=0-rect.left;
	 rect.left=0;
 }
 if(rect.top<0)
 {
	 rect.bottom+=0-rect.top;
	 rect.top=0;
 }
 
}

bool EObject::select(CRect r)
{
  r.NormalizeRect();
  prevRect=rect;

  if((r.left<rect.left)&&(r.right>rect.right)&&(r.bottom>rect.bottom)&&(r.top<rect.top))
      {
	      status=1;
		  return true;
	  }
	  else
	   	  return false;
}

void EObject::DrawResize()
{
  if(status==1)
  {
    glDepthFunc(GL_ALWAYS);
	glLineWidth(2);
	glPointSize(10);
	glColor3f(0.0,1.0,0.0);
	glBegin(GL_LINE_STRIP);
      glVertex3i(rect.left-1,rect.bottom+1,-1);
	  glVertex3i(rect.left-1,rect.top-1,-1);
	  glVertex3i(rect.right+1,rect.top-1,-1);
	  glVertex3i(rect.right+1,rect.bottom+1,-1);
	  glVertex3i(rect.left-1,rect.bottom+1,-1);
	glEnd();

	glColor3f(0.6,0.0,0.1);
	glBegin(GL_POINTS);
      glVertex3i(rect.left-5,rect.bottom+5,-1); 
	  glVertex3i(rect.left-5,rect.top-5,-1);
	  glVertex3i(rect.right+5,rect.top-5,-1);
	  glVertex3i(rect.right+5,rect.bottom+5,-1);

	  glVertex3i(rect.left-5,rect.bottom-(rect.Height()/2),-1); 
	  glVertex3i(rect.left+(rect.Width()/2),rect.top-5,-1);
	  glVertex3i(rect.right+5,rect.bottom-(rect.Height()/2),-1);
	  glVertex3i(rect.right-(rect.Width()/2),rect.bottom+5,-1);

    glEnd();
  }
  
 
 
}

void EObject::Draw(int xs, int ys)
{

}


void EObject::resize(int x, int y)
{
 if(ID_object==EEDIT)
	 y=0;
 switch(resizeNum)
  {
  case 0: 
	  rect.left+=x;
	  rect.top+=y;
	  break;
  case 1:
	  rect.right+=x;
	  rect.top+=y;
	  break;
  case 2:
	  rect.right+=x;
	  rect.bottom+=y;
	  break;
  case 3:
	  rect.left+=x;
	  rect.bottom+=y;
	  break;
  case 4: 
	  rect.top+=y;
	  break;
  case 5:
	  rect.right+=x;
	  break;
  case 6:
	  rect.bottom+=y;
	  break;
  case 7:
      rect.left+=x;
	  break;
  }

  if(rect.left<0)
 {
	 rect.right+=0-rect.left;
	 rect.left=0;
 }
 if(rect.top<0)
 {
	 rect.bottom+=0-rect.top;
	 rect.top=0;
 }

 if(rect.Height()<MinHeight)
	 switch(resizeNum)
  {
  case 0: 
  case 1:
  case 4: 
	  rect.top=rect.bottom-MinHeight;
	  break;
  case 2:
  case 3:
  case 6:
	  rect.bottom=rect.top+MinHeight;
	  break;
  }
 
 if(rect.Width()<MinWidth)
	 switch(resizeNum)
  {
  case 0: 
  case 3:
  case 7: 
	  rect.left=rect.right-MinWidth;
	  break;
  case 1:
  case 2:
  case 5:
	  rect.right=rect.left+MinWidth;
	  break;
  }
  
}

CString EObject::ObjToLine()
{
 CString obj;
 CString num;
	
     num.Format("%d",rect.left);   
 obj+="left=\""+num+"\";";
	 num.Format("%d",rect.top);   
 obj+="top=\""+num+"\";";
	 num.Format("%d",rect.bottom);   
 obj+="bottom=\""+num+"\";";
	 num.Format("%d",rect.right);   
 obj+="right=\""+num+"\";";
 
 switch(ID_object)
	  {
	  case EBUTTON:
          obj="Button "+obj;
		  obj+="Caption=";
		  break;
	  case EEDIT:
          obj="Edit "+obj;
		  obj+="Text=";
		  break;
	  case ELABEL:
          obj="Label "+obj;
		  obj+="Text=";
		  break;

	  }
 obj+="\""+Caption+"\"";
 obj="<"+obj;
 obj+=">";
 obj+="\n";
 return obj;
}

