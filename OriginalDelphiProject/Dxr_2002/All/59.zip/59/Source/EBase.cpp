// EBase.cpp: implementation of the EBase class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Editor.h"
#include "EBase.h"
#include <gl\gl.h>
#include <gl\glu.h>
#include <gl\glaux.h>
#include <shlwapi.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

EBase::EBase()
{
 xScroll=yScroll=0;
 CurrentObj=-1;
 instrument=EWORK;
}

EBase::~EBase()
{
 DeleteAll();
 int i;
 for(i=0;i<TempObject.GetSize();)
 {
  delete TempObject[i];
  TempObject.RemoveAt(i);	 
 }
}

bool EBase::AddObject(int x,int y)
{
 bool f=false;
 ClearGroup();
 switch(instrument)
 {
 case EBUTTON:
	 ArrayObject.Add(new EButton(x,y));
	 break;
 case EEDIT:
	 ArrayObject.Add(new EEdit(x,y));
	 break;
 case ELABEL:
	 ArrayObject.Add(new ELabel(x,y));
	 break;
 }
 	 
 if(HitTest())
 {
	 delete ArrayObject[ArrayObject.GetUpperBound()];
     ArrayObject.RemoveAt(ArrayObject.GetUpperBound());
 }
 else
	 f=true;
 instrument=EWORK;
 return f;
}

void EBase::Draw()
{
	int i; 
  for(i=0;i<ArrayObject.GetSize();i++)
     ((EObject *)ArrayObject[i])->Draw(xScroll,yScroll);
  for(i=0;i<ArrayObject.GetSize();i++)
     ((EObject *)ArrayObject[i])->DrawResize();
}

int EBase::Select(CPoint p)
{
  	int i,t;
	bool f=false;
	short f1;
	CurrentObj=-1;
  
  for(i=0;i<ArrayObject.GetSize();i++)
  {
	  f1=((EObject *)ArrayObject[i])->status;

	  if((t=((EObject *)ArrayObject[i])->select(p))==8)
	  {
	    f=true;
	    instrument=EMOVE;
	    CurrentObj=i; 
	    if(f1==0)
		{
		   ClearGroup();
           ((EObject *)ArrayObject[i])->status=1;
		}
      }	
	  else
		if((t!=-1)&&(f1==1))
		{
        f=true;
        ((EObject *)ArrayObject[i])->resizeNum=t;
		instrument=ERESIZE;
		CurrentObj=i; 
		}
  }

	 if(f==false)
	 {
	 ClearGroup();
	 instrument=ESELECT;
	 }

  return CurrentObj;
}

void EBase::Move(int x, int y)
{
  	int i;
  for(i=0;i<ArrayObject.GetSize();i++)
	      if(((EObject *)ArrayObject[i])->status==1)
             ((EObject *)ArrayObject[i])->move(x,y);
}

void EBase::DrawSelect()
{
  if(instrument==ESELECT)
  {

	glPushAttrib(GL_ALL_ATTRIB_BITS);
  glDepthFunc(GL_ALWAYS);
  glBegin(GL_QUADS);
   glColor4f(0,0,0,0.2);
   glVertex3i(SV.left,SV.bottom,-1);
   glVertex3i(SV.left,SV.top,-1);
   glVertex3i(SV.right,SV.top,-1);
   glVertex3i(SV.right,SV.bottom,-1);
 glEnd();
  glLineWidth(1);
  glColor3f(0.0,1.0,0.7);
  glBegin(GL_LINES);
    glVertex3i(SV.left,SV.bottom,-1);
	glVertex3i(SV.right,SV.bottom,-1);
	glVertex3i(SV.right,SV.bottom,-1);
	glVertex3i(SV.right,SV.top,-1);
	glVertex3i(SV.right,SV.top,-1);
	glVertex3i(SV.left,SV.top,-1);
	glVertex3i(SV.left,SV.top,-1);
	glVertex3i(SV.left,SV.bottom,-1);
  glEnd();
  glPopAttrib();
  }
}


bool EBase::GroupSelect()
{
  int i;
  bool f=false;
  
  for(i=0;i<ArrayObject.GetSize();i++)
	      if(((EObject *)ArrayObject[i])->select(SV))
    		  f=true;
  return f;
}

void EBase::ClearGroup()
{
	int i;
 for( i=0;i<ArrayObject.GetSize();i++)
   ((EObject *)ArrayObject[i])->status=0;
}

bool EBase::HitTest()
{
	int i,j;
	bool f=false;
 for(i=0;i<ArrayObject.GetSize();i++) 
  if(((EObject *)ArrayObject[i])->status==1)
	 for(j=0;j<ArrayObject.GetSize();j++) 
	    if(j!=i)
		{
         CRect lprcDst;
		 if((IntersectRect(lprcDst,((EObject *)ArrayObject[i])->rect,((EObject *)ArrayObject[j])->rect))||
			 (((EObject *)ArrayObject[i])->rect.Width()<((EObject *)ArrayObject[i])->MinWidth)||
			 (((EObject *)ArrayObject[i])->rect.Height()<((EObject *)ArrayObject[i])->MinHeight))
         {
			 ((EObject *)ArrayObject[i])->rect=((EObject *)ArrayObject[i])->prevRect;
			 f=true;
		 }
		}
return f;
}

bool EBase::DeleteObject()
{
 int i;
 bool f=false;
  for(i=0;i<ArrayObject.GetSize();i++)
	  if(((EObject *)ArrayObject[i])->status==1)
	  {
        delete ArrayObject[i];
		ArrayObject.RemoveAt(i);
		i--;
        f=true;
		CurrentObj=-1;
	  }
 return f;    
}

void EBase::SelectAll()
{
  int i;
  for(i=0;i<ArrayObject.GetSize();i++)
	  ((EObject *)ArrayObject[i])->status=1;
}

void EBase::Copy()
{
  int i;
  for(i=0;i<TempObject.GetSize();i++)
  delete TempObject[i];
  TempObject.RemoveAll();

  for(i=0;i<ArrayObject.GetSize();i++)
	  if(((EObject *)ArrayObject[i])->status==1)
	  {
	  	 TempObject.Add(new EObject);
		 memcpy(TempObject[TempObject.GetUpperBound()],
			 ArrayObject[i],sizeof(EObject));
	  }
}

void EBase::Paste(int x,int y)
{
  int i;
  ClearGroup();
  CRect r;
  CRect r1;
  if(TempObject.GetSize()>0)
  r=((EObject*)TempObject[0])->rect;
  
  for(i=1;i<TempObject.GetSize();i++)
  {
   r1=r;
   r.UnionRect((LPRECT)((EObject*)TempObject[i])->rect,(LPRECT)r1);
  }

  for(i=0;i<TempObject.GetSize();i++)
  {
   ((EObject*)TempObject[i])->rect.left-=(r.left-x);
   ((EObject*)TempObject[i])->rect.right-=(r.left-x);
   ((EObject*)TempObject[i])->rect.top-=(r.top-y);
   ((EObject*)TempObject[i])->rect.bottom-=(r.top-y);
  }


  for(i=0;i<TempObject.GetSize();i++)
  {
	 ArrayObject.Add(new EObject);
	 memcpy(ArrayObject[ArrayObject.GetUpperBound()],
		 TempObject[i],
			 sizeof(EObject));

     if(HitTest())
	 {
	  delete ArrayObject[ArrayObject.GetUpperBound()];
	  ArrayObject.RemoveAt(ArrayObject.GetUpperBound());

	 }
  }
}

void EBase::Cut()
{
  int i;
  for(i=0;i<TempObject.GetSize();i++)
	  delete TempObject[i];
  TempObject.RemoveAll();
  
  for(i=0;i<ArrayObject.GetSize();i++)
	  if(((EObject *)ArrayObject[i])->status==1)
	  {
		  TempObject.Add(new EObject);
          memcpy(TempObject[TempObject.GetUpperBound()],
			 ArrayObject[i],sizeof(EObject));
		  delete ArrayObject[i];
		  ArrayObject.RemoveAt(i);
		  i--;
		  CurrentObj=-1;	
	  }
}

int EBase::IsSelection()
{
  int i,k=0;
  for(i=0;i<ArrayObject.GetSize();i++)
	  if(((EObject *)ArrayObject[i])->status==1)
		  k++;
	  return k;
}


void EBase::Resize(int x,int y)
{
	int i;
 for(i=0;i<ArrayObject.GetSize();i++)
	  if(((EObject *)ArrayObject[i])->status==1)
	    ((EObject *)ArrayObject[i])->resize(x,y);
      
}

void EBase::Align(short param)
{
  	int i,w,w1,h,h1;
  if(CurrentObj!=-1)
  {
  for(i=0;i<ArrayObject.GetSize();i++)
    if(((EObject *)ArrayObject[i])->status==1)
  switch(param)
  {
   case 1:
	   w=((EObject *)ArrayObject[i])->rect.Width();
      ((EObject *)ArrayObject[i])->rect.left=((EObject *)ArrayObject[CurrentObj])->rect.left;
	  ((EObject *)ArrayObject[i])->rect.right=((EObject *)ArrayObject[i])->rect.left+w;
	   break;
   case 2:
	   h=((EObject *)ArrayObject[i])->rect.Height();
      ((EObject *)ArrayObject[i])->rect.top=((EObject *)ArrayObject[CurrentObj])->rect.top;
	  ((EObject *)ArrayObject[i])->rect.bottom=((EObject *)ArrayObject[i])->rect.top+h;
	   break;
   case 3:
      w=((EObject *)ArrayObject[CurrentObj])->rect.Width();
	  w1=(w-((EObject *)ArrayObject[i])->rect.Width())/2;
	  ((EObject *)ArrayObject[i])->rect.left-=w1;
	  ((EObject *)ArrayObject[i])->rect.right+=w1;
	   break;
   case 4:
      h=((EObject *)ArrayObject[CurrentObj])->rect.Height();
	  h1=(h-((EObject *)ArrayObject[i])->rect.Height())/2;
	  ((EObject *)ArrayObject[i])->rect.top-=h1;
	  ((EObject *)ArrayObject[i])->rect.bottom+=h1;
	   break;
  }
  }
  HitTest();
}

void EBase::SaveToFile(CString str)
{
  int i;
  CString line;
  CStdioFile f(str,CFile::modeCreate|CFile::modeWrite|CFile::typeText);

  	for(i=0;i<ArrayObject.GetSize();i++)
	{
	  line=((EObject *)ArrayObject[i])->ObjToLine();
	  f.WriteString((LPCTSTR)line);
	  line="";
	}
	f.Close();
}

void EBase::LoadFromFile(CString str)
{
 DeleteAll();
 int i;
 CRect r;
  CString line,l2,s;
  CStdioFile f;
  if(f.Open(str,CFile::modeRead|CFile::typeText))
  {
  while(f.ReadString(line))
  {
  s=line;
  line.MakeLower();

   if(line.Find("button")>0)
    ArrayObject.Add(new EButton(0,0));
  if(line.Find("edit")>0)
    ArrayObject.Add(new EEdit(0,0));
  if(line.Find("label")>0)
    ArrayObject.Add(new ELabel(0,0));

  l2=s;
  if(MakeValue(line,"left=",l2))
  ((EObject *)ArrayObject[ArrayObject.GetUpperBound()])->rect.left=StrToInt((LPCTSTR)l2);
  l2=s;
  if(MakeValue(line,"top=",l2))
  ((EObject *)ArrayObject[ArrayObject.GetUpperBound()])->rect.top=StrToInt((LPCTSTR)l2);
  l2=s;
  if(MakeValue(line,"bottom=",l2))
  ((EObject *)ArrayObject[ArrayObject.GetUpperBound()])->rect.bottom=StrToInt((LPCTSTR)l2);
  l2=s;
  if(MakeValue(line,"right=",l2))
  ((EObject *)ArrayObject[ArrayObject.GetUpperBound()])->rect.right=StrToInt((LPCTSTR)l2);

    l2=s;
    if(((EObject *)ArrayObject[ArrayObject.GetUpperBound()])->ID_object==EBUTTON)
	{
	  if(MakeValue(line,"caption=",l2))
      ((EObject *)ArrayObject[ArrayObject.GetUpperBound()])->Caption=l2;
	}
    else
	{
      if(MakeValue(line,"text=",l2))
      ((EObject *)ArrayObject[ArrayObject.GetUpperBound()])->Caption=l2; 
	}
    
     if(HitTest())
	 {
	 delete ArrayObject[ArrayObject.GetUpperBound()];
     ArrayObject.RemoveAt(ArrayObject.GetUpperBound());
	 }
  }
  f.Close();
  }
 
 instrument=EWORK;
}

bool EBase::MakeValue(CString& dt,CString pn,CString& source)
{
 bool f=false;
 int k,k1;
 k=dt.Find(pn);
 if(k>0)
 {
 source.Delete(0,k+pn.GetLength()+1);
 k1=source.Find('\"');
 if(k1>0)
 {
 source.Delete(k1,source.GetLength()-k1);	
  f=true;
 }
 }
 return f;
}

void EBase::DeleteAll()
{
 int i;
 for(i=0;i<ArrayObject.GetSize();)
 {
  delete ArrayObject[i];
  ArrayObject.RemoveAt(i);	 
 }

  CurrentObj=-1;	
}


void EBase::SaveToHTML(CString str)
{
  int i;
  CString line;
  CStdioFile f(str,CFile::modeCreate|CFile::modeWrite|CFile::typeText);
  line.LoadString(E_HTML1);
  f.WriteString((LPCTSTR)line);
  line.LoadString(E_HTML2);
  f.WriteString((LPCTSTR)line);
  line.LoadString(E_HTML3);
  f.WriteString((LPCTSTR)line);
	for(i=0;i<ArrayObject.GetSize();i++)
	{
      CString o,l,t,w,h;
      switch(((EObject *)ArrayObject[i])->ID_object)
	  {
       case EBUTTON:
	       o="button";
	   break;
       case EEDIT:
	       o="edit";
	   break;
       case ELABEL:
	       o="label";
	   break;
	  }
	  l.Format("%d",((EObject *)ArrayObject[i])->rect.left);
	  t.Format("%d",((EObject *)ArrayObject[i])->rect.top);
	  w.Format("%d",((EObject *)ArrayObject[i])->rect.Width());
	  h.Format("%d",((EObject *)ArrayObject[i])->rect.Height());
      line="init('"+o+"',"+l+","+t+","+w+","+h+",'"+((EObject *)ArrayObject[i])->Caption+"');\n";
	  f.WriteString((LPCTSTR)line);
	  line="";
	}
  line.LoadString(E_HTML_END);
  f.WriteString((LPCTSTR)line);
	f.Close();
}

