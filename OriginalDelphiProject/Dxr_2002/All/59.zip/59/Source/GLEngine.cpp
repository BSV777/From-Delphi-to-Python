// GLEngine.cpp: implementation of the GLEngine class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GLEngine.h"
#include "EObject.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

GLEngine::GLEngine()
{
 x=y=w=h=0;
}

GLEngine::~GLEngine()
{

}

GLvoid GLEngine::Draw(GLvoid)
{
  glClear(GL_COLOR_BUFFER_BIT| GL_DEPTH_BUFFER_BIT );
  glPushMatrix();
     glTranslatef(pEBase->xScroll,pEBase->yScroll,0);
     	 glLineWidth(4);
		 glBegin(GL_LINES);
           glColor3f(1.0,0.0,0.0);
		   glVertex3i(0,0,-1);
		   glColor3f(0.0,1.0,0.0);
		   glVertex3i(0,Wheight-pEBase->yScroll,-1);
		 glEnd();
		 glBegin(GL_LINES);
		   glColor3f(1.0,0.0,0.0);
           glVertex3i(0,0,-1);
		   glColor3f(0.0,1.0,0.0);
		   glVertex3i(Wwidth-pEBase->xScroll,0,-1);
		 glEnd();
	 glLineWidth(3);
     
	glPushAttrib(GL_ALL_ATTRIB_BITS); 
	 pEBase->Draw();
	 pEBase->DrawSelect();
    glPopAttrib();
  glPopMatrix();

  DrawStatusBar();
  
  glFinish();
  SwapBuffers(glDC);
}


GLvoid GLEngine::Init()
{
  
  glClearDepth( 1 );
  glClearColor(0.1,0.0,0.85,1.0);
  
  glEnable(GL_DEPTH_TEST);
  glEnable(GL_COLOR_MATERIAL);
  glEnable(GL_AUTO_NORMAL);
  glEnable(GL_NORMALIZE);
  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);
  glEnable(GL_BLEND);
  
  glPolygonMode(GL_FRONT,GL_FILL);
/* glEnable(GL_POINT_SMOOTH);
  glEnable(GL_LINE_SMOOTH);
  glEnable(GL_POLYGON_SMOOTH);*/
  
  glShadeModel(GL_SMOOTH);
  glDepthFunc(GL_LESS);
  glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

  SelectObject (glDC, GetStockObject (DEFAULT_GUI_FONT)); 
  wglUseFontBitmaps (glDC, 0, 255, 1000); 
  glListBase (1000); 


}

BOOL GLEngine::SetupPixelFormat()
{
    PIXELFORMATDESCRIPTOR *ppfd;
    int pixelformat;
    PIXELFORMATDESCRIPTOR  pfd = {        sizeof(PIXELFORMATDESCRIPTOR),  /* size */
        1,                              /* version */
        PFD_SUPPORT_OPENGL |PFD_DRAW_TO_WINDOW |PFD_DOUBLEBUFFER ,               /* support double-buffering */
        PFD_TYPE_RGBA,                  /* color type */
        16,                             /* prefered color depth */
        0, 0, 0, 0, 0, 0,               /* color bits (ignored) */
        0,                              /* no alpha buffer */
        0,                              /* alpha bits (ignored) */
        0,                              /* no accumulation buffer */
        0, 0, 0, 0,                     /* accum bits (ignored) */
        16,                             /* depth buffer */
        0,                              /* no stencil buffer */
        0,                              /* no auxiliary buffers */
        PFD_MAIN_PLANE,                 /* main layer */
        0,                              /* reserved */
        0, 0, 0,                        /* no layer, visible, damage masks */
    };

    ppfd = &pfd;

    if ( (pixelformat = ChoosePixelFormat(glDC, ppfd)) == 0 )
    {
      MessageBox(NULL, "ChoosePixelFormat failed", "Error", MB_OK);
     return FALSE;
    }

    if (SetPixelFormat(glDC, pixelformat, ppfd) == FALSE)
    {
        MessageBox(NULL, "SetPixelFormat failed", "Error", MB_OK);
        return FALSE;
    }

    glRC = wglCreateContext(glDC);
    wglMakeCurrent(glDC,glRC);

    return TRUE;


}

void GLEngine::Resize(int width, int height)
{
  Wwidth=width;
  Wheight=height;
  glViewport(0,0,width,height);
  glMatrixMode( GL_PROJECTION );
  glLoadIdentity();
  glFrustum( 0.0,Wwidth,Wheight,0.0,1.0,30.0);
  glMatrixMode( GL_MODELVIEW );
}





void GLEngine::GLTextOut(CString text,float x,float y,float z)
{
  glRasterPos3f(x,y,z);
  glCallLists (text.GetLength(), GL_UNSIGNED_BYTE,(LPCTSTR)text); 
}

void GLEngine::DrawStatusBar()
{
	if(pEBase->CurrentObj!=-1)
	{
 w=((EObject *)(pEBase->ArrayObject[pEBase->CurrentObj]))->rect.Width();
 h=((EObject *)(pEBase->ArrayObject[pEBase->CurrentObj]))->rect.Height();
	}
	else
	{
	w=0;
	h=0;
	}
 glBegin(GL_QUADS);
   glColor4f(0,0,0,0.2);
   glVertex3i(0,Wheight,-1);
   glVertex3i(0,Wheight-20,-1);
   glVertex3i(Wwidth,Wheight-20,-1);
   glVertex3i(Wwidth,Wheight,-1);
 glEnd();
  CString CX,CY,CW,CH;
  
  CX.Format("%d",x);
  CY.Format("%d",y);
  CX="X="+CX; CY="Y="+CY;

  CW.Format("%d",w);
  CH.Format("%d",h);
  CW="������="+CW; CH="������="+CH;

  glDepthFunc(GL_ALWAYS);
  glColor3f(0.8,0.0,0.1);
  glRasterPos3i(10,Wheight-5,-1);
	  glCallLists (CX.GetLength(), GL_UNSIGNED_BYTE,(LPCTSTR)CX); 
  glRasterPos3i(70,Wheight-5,-1);
	  glCallLists (CY.GetLength(), GL_UNSIGNED_BYTE,(LPCTSTR)CY); 
  glRasterPos3i(130,Wheight-5,-1);
	  glCallLists (CW.GetLength(), GL_UNSIGNED_BYTE,(LPCTSTR)CW); 
  glRasterPos3i(250,Wheight-5,-1);
	  glCallLists (CH.GetLength(), GL_UNSIGNED_BYTE,(LPCTSTR)CH); 

}
