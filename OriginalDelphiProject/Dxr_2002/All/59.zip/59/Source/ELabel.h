// ELabel.h: interface for the ELabel class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ELABEL_H__1B1F9885_3428_11D6_B052_D1B7AACB8C47__INCLUDED_)
#define AFX_ELABEL_H__1B1F9885_3428_11D6_B052_D1B7AACB8C47__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "EObject.h"

class ELabel : public EObject  
{
public:
	ELabel(int x,int y);
	void Draw(int xs,int ys);
	
	ELabel();
	virtual ~ELabel();

};

#endif // !defined(AFX_ELABEL_H__1B1F9885_3428_11D6_B052_D1B7AACB8C47__INCLUDED_)
