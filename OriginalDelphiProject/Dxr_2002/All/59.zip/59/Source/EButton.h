// EButton.h: interface for the EButton class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EBUTTON_H__1B1F9883_3428_11D6_B052_D1B7AACB8C47__INCLUDED_)
#define AFX_EBUTTON_H__1B1F9883_3428_11D6_B052_D1B7AACB8C47__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "EObject.h"

class EButton :public EObject  
{
public:
	EButton(int x,int y);
	void Draw(int xs,int ys);
	EButton();
	virtual ~EButton();
};

#endif // !defined(AFX_EBUTTON_H__1B1F9883_3428_11D6_B052_D1B7AACB8C47__INCLUDED_)
