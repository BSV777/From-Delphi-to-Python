// EEdit.h: interface for the EEdit class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EEDIT_H__1B1F9884_3428_11D6_B052_D1B7AACB8C47__INCLUDED_)
#define AFX_EEDIT_H__1B1F9884_3428_11D6_B052_D1B7AACB8C47__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "EObject.h"

class EEdit : public EObject  
{
public:
	EEdit(int x,int y);
	void Draw(int xs,int ys);
	EEdit();
	
	virtual ~EEdit();

};

#endif // !defined(AFX_EEDIT_H__1B1F9884_3428_11D6_B052_D1B7AACB8C47__INCLUDED_)
