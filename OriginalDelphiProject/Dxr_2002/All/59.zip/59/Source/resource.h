//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Editor.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_EDITOR_FORM                 101
#define IDC_POINTER                     104
#define IDR_MAINFRAME                   128
#define IDR_EDITORTYPE                  129
#define IDR_TOOLBAR1                    130
#define IDD_DIALOG1                     132
#define IDC_ESELECT                     134
#define IDB_ALIGNL                      135
#define IDB_ALIGNT                      136
#define IDB_ALIGNW                      137
#define IDB_ALIGNH                      138
#define IDC_RESIZE                      138
#define IDC_MOVE                        140
#define IDB_PANEL                       141
#define IDC_ESCROLL                     141
#define IDC_EOBJECT                     142
#define IDB_FSAVE                       147
#define IDB_FOPEN                       148
#define IDB_COPY                        149
#define IDB_PASTE                       150
#define IDB_CUT                         151
#define IDB_FNEW                        152
#define IDC_EDIT1                       1005
#define IDC_EDIT2                       1006
#define IDC_EDIT3                       1007
#define IDC_EDIT4                       1008
#define IDC_BUTTON1                     1010
#define IDC_BUTTON2                     1011
#define IDC_EDIT5                       1012
#define IDC_EDIT6                       1013
#define E_DELETE                        32771
#define E_SELECT_ALL                    32772
#define E_CURSOR                        32775
#define E_BUTTON                        32776
#define E_EDIT                          32777
#define E_LABEL                         32778
#define E_ALIGN_LEFT                    32779
#define E_ALIGN_TOP                     32781
#define E_ALIGN_WIDTH                   32782
#define E_ALIGN_HEIGHT                  32783
#define E_PROPERTIES                    32784
#define E_FILE_SAVE_AS                  32785
#define E_FILE_OPEN                     32786
#define E_FILE_NEW                      32787
#define E_FILE_SAVE                     -32748
#define E_HTML1                         61204
#define E_HTML2                         61205
#define E_HTML3                         61206
#define E_HTML_END                      61207

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        156
#define _APS_NEXT_COMMAND_VALUE         32809
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
