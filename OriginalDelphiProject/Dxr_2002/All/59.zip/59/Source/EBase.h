// EBase.h: interface for the EBase class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EBASE_H__BBC8900E_314B_11D6_B052_A762B28D474B__INCLUDED_)
#define AFX_EBASE_H__BBC8900E_314B_11D6_B052_A762B28D474B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <afxtempl.h>

#define EWORK   100
#define EMOVE   101
#define ESELECT 102
#define ESCROLL 103
#define ERESIZE 104

#include "EObject.h"
#include "EButton.h"
#include "ELabel.h"
#include "EEdit.h"


//�������� ����� �������
class EBase  
{
public:
	void SaveToHTML(CString str);
	void DeleteAll();
	int CurrentObj;
	bool MakeValue(CString& dt,CString pn,CString& source);
	void LoadFromFile(CString str);
	void SaveToFile(CString str);
	void Align(short param);
	void Resize(int x,int y);
	int IsSelection();
	void Cut();
	void Paste(int x,int y);
	void Copy();
	void SelectAll();
	bool DeleteObject();
	bool HitTest();
	void ClearGroup();
	bool GroupSelect();
	int xScroll,yScroll;
	void DrawSelect();
	short instrument;
	void Move(int x,int y);
	int Select(CPoint p);
	void Draw();
	bool AddObject(int x,int y);
	
	CArray<void*,void*> ArrayObject;
	CArray<void*,void*> TempObject;
		
	CRect SV;

	EBase();
	virtual ~EBase();

};

#endif // !defined(AFX_EBASE_H__BBC8900E_314B_11D6_B052_A762B28D474B__INCLUDED_)
