// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Editor.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_INITMENU()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
  ToolBar1.Create(this,WS_CHILD|WS_VISIBLE|CBRS_LEFT,AFX_IDW_TOOLBAR);
  ToolBar1.LoadToolBar(IDR_TOOLBAR1);
  ToolBar1.EnableDocking(CBRS_ALIGN_LEFT);
  EnableDocking(CBRS_ALIGN_LEFT);
  DockControlBar(&ToolBar1);

  BitMap[0].LoadBitmap(IDB_ALIGNL);
  BitMap[1].LoadBitmap(IDB_ALIGNT);
  BitMap[2].LoadBitmap(IDB_ALIGNW);
  BitMap[3].LoadBitmap(IDB_ALIGNH);
  BitMap[4].LoadBitmap(IDB_CUT);
  BitMap[5].LoadBitmap(IDB_COPY);
  BitMap[6].LoadBitmap(IDB_PASTE);
  BitMap[7].LoadBitmap(IDB_FNEW);
  BitMap[8].LoadBitmap(IDB_FOPEN);
  BitMap[9].LoadBitmap(IDB_FSAVE);
 
  CMenu* menu_bar =GetMenu();
  menu_bar->SetMenuItemBitmaps(E_ALIGN_LEFT,MF_BYCOMMAND,
	  &BitMap[0],&BitMap[0]);
  menu_bar->SetMenuItemBitmaps(E_ALIGN_TOP,MF_BYCOMMAND,
	  &BitMap[1],&BitMap[1]);
  menu_bar->SetMenuItemBitmaps(E_ALIGN_WIDTH,MF_BYCOMMAND,
	  &BitMap[2],&BitMap[2]);
  menu_bar->SetMenuItemBitmaps(E_ALIGN_HEIGHT,MF_BYCOMMAND,
	  &BitMap[3],&BitMap[3]);
  menu_bar->SetMenuItemBitmaps(ID_EDIT_CUT,MF_BYCOMMAND,
	  &BitMap[4],&BitMap[4]);
  menu_bar->SetMenuItemBitmaps(ID_EDIT_COPY,MF_BYCOMMAND,
	  &BitMap[5],&BitMap[5]);
  menu_bar->SetMenuItemBitmaps(ID_EDIT_PASTE,MF_BYCOMMAND,
	  &BitMap[6],&BitMap[6]);
  menu_bar->SetMenuItemBitmaps(E_FILE_NEW,MF_BYCOMMAND,
	  &BitMap[7],&BitMap[7]);
  menu_bar->SetMenuItemBitmaps(E_FILE_OPEN,MF_BYCOMMAND,
	  &BitMap[8],&BitMap[8]);
  menu_bar->SetMenuItemBitmaps(E_FILE_SAVE,MF_BYCOMMAND,
	  &BitMap[9],&BitMap[9]);
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers





void CMainFrame::OnInitMenu(CMenu* pMenu) 
{
	CFrameWnd::OnInitMenu(pMenu);
}
