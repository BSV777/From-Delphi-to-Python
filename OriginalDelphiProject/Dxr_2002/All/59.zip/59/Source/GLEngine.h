// GLEngine.h: interface for the GLEngine class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GLENGINE_H__D7A0D8E0_0B45_11D6_B052_C4E601C10000__INCLUDED_)
#define AFX_GLENGINE_H__D7A0D8E0_0B45_11D6_B052_C4E601C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <gl\gl.h>
#include <gl\glu.h>
#include <gl\glaux.h>
#include <math.h>
#include "EBase.h"

class GLEngine  
{
public:
	void DrawStatusBar();
	int x,y,w,h;
	EBase* pEBase;
	void GLTextOut(CString text,float x,float y,float z);
	int Wheight;
	int Wwidth;
	void Resize(int width,int height);
	BOOL SetupPixelFormat();
	GLvoid Init();
	GLvoid Draw(GLvoid);
	HGLRC glRC;
	HDC glDC;
	GLEngine();
	virtual ~GLEngine();

};

#endif // !defined(AFX_GLENGINE_H__D7A0D8E0_0B45_11D6_B052_C4E601C10000__INCLUDED_)
