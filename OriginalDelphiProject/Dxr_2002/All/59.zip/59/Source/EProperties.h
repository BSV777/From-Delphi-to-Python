#if !defined(AFX_EPROPERTIES_H__67C7FA5F_3D08_11D6_B052_9D67677BC648__INCLUDED_)
#define AFX_EPROPERTIES_H__67C7FA5F_3D08_11D6_B052_9D67677BC648__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EProperties.h : header file
//
#include "EBase.h"
/////////////////////////////////////////////////////////////////////////////
// EProperties dialog

class EProperties : public CDialog
{
// Construction
public:
	EBase* pEBase;
	EProperties(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(EProperties)
	enum { IDD = IDD_DIALOG1 };
	CEdit	textCtrl;
	CEdit	captionCtrl;
	int		top;
	int		left;
	int		bottom;
	int		right;
	CString	caption;
	CString	text;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(EProperties)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(EProperties)
	afx_msg void OnButton1();
	afx_msg void OnButton2();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EPROPERTIES_H__67C7FA5F_3D08_11D6_B052_9D67677BC648__INCLUDED_)
