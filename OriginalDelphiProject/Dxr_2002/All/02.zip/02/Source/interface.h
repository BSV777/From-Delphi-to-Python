/*
** Corners. Version 1.0.
** �����: gpptm.
** ��������� ������������ ���������� �������������� � �������� ������
** ������� <ObjectType [propertyname="PropertyValue"[; propertyname2="PropertyValue2"]]>
** � ����� �������� ���� ������ � ������ html (����� GUI � command line) 
*/
//---------------------------------------------------------------------------
#ifndef interfaceH
#define interfaceH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ExtCtrls.hpp>
#include <Menus.hpp>
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
#include <map>
//---------------------------------------------------------------------------
#define BUTTON  	11
#define LABEL     	22
#define EDIT      	33
using namespace std;
typedef map <int,int, less<int> > TRANSLATOR;

class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TPopupMenu *PopupMenu;
        TMenuItem *UnDock;
        TMenuItem *Dock;
        TMenuItem *N1;
        TMenuItem *Drag;
        TMainMenu *MainMenu;
        TMenuItem *Open1;
        TMenuItem *New1;
        TMenuItem *Create1;
        TMenuItem *Create2;
        TMenuItem *Creat3;
        TMenuItem *Open;
        TMenuItem *Save;
        TMenuItem *N2;
        TMenuItem *Exit;
        TMenuItem *N3;
        TMenuItem *Delete;
        TMenuItem *N4;
        TMenuItem *Text;
        TPanel *Panel;
        TEdit *Edit;
        TButton *Ok;
        TStatusBar *StatusBar1;
        TOpenDialog *OpenDlg;
        TSaveDialog *SaveDlg;
        TMenuItem *ClearSpace;
        TMenuItem *N5;
        TMenuItem *Info1;
        TMenuItem *Version;
        TMenuItem *Help;
	void __fastcall ButtonMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift,
	int X, int Y);

	void __fastcall ButtonDragOver(TObject *Sender, TObject *Source, int X, int Y,
	TDragState State, bool &Accept);
        void __fastcall UnDockClick(TObject *Sender);
        void __fastcall DockClick(TObject *Sender);
        void __fastcall DragClick(TObject *Sender);
        void __fastcall ButtonEndDrag(TObject *Sender, TObject *Target,
          int X, int Y);
        void __fastcall Create1Click(TObject *Sender);
        void __fastcall ExitClick(TObject *Sender);
        void __fastcall Create2Click(TObject *Sender);
        void __fastcall Create3Click(TObject *Sender);
        void __fastcall DeleteClick(TObject *Sender);
        void __fastcall TextClick(TObject *Sender);
        void __fastcall EditKeyPress(TObject *Sender, char &Key);
        void __fastcall OkClick(TObject *Sender);
        void __fastcall OpenClick(TObject *Sender);
        void __fastcall SaveClick(TObject *Sender);
        void __fastcall ClearSpaceClick(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall HelpClick(TObject *Sender);
        void __fastcall VersionClick(TObject *Sender);
private:	// User declarations
  bool __fastcall IsConflict(TControl* src);
  void __fastcall SaveAsDat(FILE*);
  void __fastcall SaveAsHTML(FILE*);
  void __fastcall LoadFromDat(FILE*);
public:		// User declarations
  __fastcall TForm1(TComponent* Owner);
private:
  int x,y;
  TControl* DockedControl;
  TControl* NewControl;
  TRect prevPos;
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
