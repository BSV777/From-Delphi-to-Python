#include "error.hpp"

Error Err;

Error::Error() : code(0),
                 system(FALSE), 
		 descript(NULL),
		 source(NULL),
                 helpFile(NULL),
		 helpContext(0)
{
}

Error::Error(int	  _code, 
	     const char*  _description,
	     const char*  _source,
	     const char*  _helpFile,
	     int	  _helpContext)
  : code(_code), 
    system(FALSE),
    descript(NULL),
    source(NULL),
    helpFile(NULL),
    helpContext(_helpContext)
{
  CopyStrings(_description, _source, _helpFile);
}

// virtual
Error::~Error()
{
  delete descript;
  delete source;
  delete helpFile;
}

// virtual
const Error& Error::operator = (const Error& e)
{
  if(&e != this)
  {
    code	= e.code;
    system	= e.system;
    helpContext = e.helpContext;
    CopyStrings(e.descript, e.source, e.helpFile);
  }
  return *this;
}

// virtual protected
BOOL Error::CopyStrings(const char* _description,
			const char* _source,
			const char* _helpFile)
{
  BOOL e = FALSE;

  if(_description && _description[0])
  {
    descript = new char[lstrlen(_description) + 1];
    if(descript)
      lstrcpy(descript, _description);
    else
      e = TRUE;
  }

  if(_source && _source[0])
  {
    source = new char[lstrlen(_source) + 1];
    if(source)
      lstrcpy(source, _source);
    else
      e = TRUE;
  }

  if(_helpFile && _helpFile[0])
  {
    delete helpFile; // It only happens when helpfile is changing
    helpFile = new char[lstrlen(_helpFile) + 1];
    if(helpFile)
      lstrcpy(helpFile, _helpFile);
    else
      e = TRUE;
  }
  return !e;
}

// virtual
BOOL  Error::SetErrorInfo(int	      _code, 
			  const char* _description, 
			  const char* _source,
			  const char* _helpFile,
			  int	      _helpContext)
{
  Clear();
  code	      = _code;
  system      = FALSE;
  helpContext = _helpContext;
  return CopyStrings(_description, _source, _helpFile);
}

// Sets error info for global Err object!!!
// static
BOOL Error::Raise(int	      _code, 
		  const char* _description, 
		  const char* _source,
		  const char* _helpFile,
		  int	      _helpContext)
{
  return Err.SetErrorInfo(_code, _description, _source, _helpFile, _helpContext);
}

// virtual
void Error::Clear()
{
  code = system = helpContext = 0;
  delete descript;
  delete source;
  // Do not do this: delete helpFile; - it's usually one for an application
  descript = source = NULL;
}

// virtual
int Error::GetSystemError()
{
  Clear();

  code	  = GetLastError();
  system  = TRUE;
  return code;
}

// virtual
BOOL Error::LoadSystemErrorInfo()
{
  GetSystemError();

  char	text[512] = "Internal error occured";
  int	ret = FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, 0, code, 0,
			    text, sizeof(text), NULL);
  if(!ret)
    return FALSE;

  CopyStrings(text, "Win32 API", NULL);
  return TRUE;
}

// virtual protected
int Error::DisplaySystemError(UINT flags)
{
  char text[512] = "Internal error occured";

  int ret = FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, 0, code, 0,
    text, sizeof(text), NULL);
  if(!ret)
    return FALSE;

  try
  {
    wsprintf(text + lstrlen(text), "\nError # %d\nSource: Win32 API", code);
  }
  catch(...)
  {
  }
  return ::MessageBox(NULL, text, "Error", MB_ICONEXCLAMATION | flags |
                                           (helpContext ? MB_HELP : 0));
}

// Modify to use main window handle and application title
int Error::Display(UINT flags)
{
  if(system)
    return DisplaySystemError(flags);

  char text[512] = "Internal error occured";
  try
  {
    wsprintf(text, "%s\n\nError # %d\nSource: %s", descript, code, 
      source ? source : "unknown");
  }
  catch(...)
  {
  }
  return ::MessageBox(NULL, text, "Error", MB_ICONEXCLAMATION | flags |
                                           (helpContext ? MB_HELP : 0));
}
// ---------------------------------------------------------------------------
//                    End of Error object definition
// ---------------------------------------------------------------------------
