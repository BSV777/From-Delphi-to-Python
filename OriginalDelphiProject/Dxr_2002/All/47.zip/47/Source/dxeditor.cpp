#include "dxeditor.hpp"
#include "textfile.hpp"
#include "matrix.hpp"

BOOL loadingFile = FALSE;
extern char LogFileName[MAX_PATH];

void WriteDotGif(const char* htmlfile)
{
  BYTE gif[] = {0x47, 0x49, 0x46, 0x38, 0x39, 0x61, 0x01, 0x00,
                0x01, 0x00, 0xD1, 0x00, 0x00, 0xFF, 0xFF, 0xFF,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x21, 0xF9, 0x04, 0x09, 0x64, 0x00, 0x00,
                0x00, 0x2C, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 
                0x01, 0x00, 0x00, 0x02, 0x02, 0x44, 0x01, 0x00,
                0x3B};
  char fname[256];
  lstrcpy(fname, htmlfile);
  for(int i = lstrlen(fname); i; i--)
    if(fname[i] == '\\')
    {
      fname[i + 1] = '\0';
      break;
    }
  if(i)
    lstrcat(fname, "dot.gif");
  else
    lstrcpy(fname, "dot.gif");

  HANDLE hfile = ::CreateFile(fname, GENERIC_WRITE, FILE_SHARE_READ,
    NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
  if(hfile == INVALID_HANDLE_VALUE)
    return;

  DWORD written = 0;
  ::WriteFile(hfile, gif, sizeof(gif), &written, NULL);
  ::CloseHandle(hfile);
}

DXEditor::DXEditor() : mainWindow(NULL), focusedCtl(NULL), modified(FALSE), insertCtl(0)
{
  fname[0] = '\0';
}

DXEditor::~DXEditor()
{
}

void DXEditor::GoInteractive(const char* filename)
{  
  mainWindow = new MainWindow();

  if(filename)
  {
    lstrcpy(fname, filename);
    LoadFile(filename);
  }
  else
    MenuFileNew();

  mainWindow->Run();
}

void DXEditor::DisplayControlInfo()
{

}

void DXEditor::ExportFile(const char* sourcefile, const char* htmlfile)
{
  if(sourcefile)
    if(!LoadFile(sourcefile))
      return;

  WriteDotGif(htmlfile);

  TextFile html(htmlfile);
  html.Open(NULL, "w");

  html.WriteLine("<html>\n<body leftmargin=0 topmargin=0 rightmargin=0 "
    "marginwidth=0 marginheight=0 bgColor=silver>\n"
    "<style>\n"
    "body, td, input, div, button {font: 13px 'Arial Cyr', Arial, swiss;}\n"
    "</style>\n"
    "\n<form>\n");

  // Processing page
  if(cset.Count())
  {
    int	      from = 0, to = 0;
    AControl  *ctl = cset.ControlByIndex(0);
    DWORD     max_bottom = ctl->Top() + ctl->Height() - 1;

    char t[64];
    wsprintf(t, "<img src=dot.gif width=1 height=%d border=0 alt=''>", ctl->Top());
    html.WriteLine(t);

/*    for(DWORD i = 1; i < cset.Count(); i++)
    { 
      ctl = cset.ControlByIndex(i);
      if(ctl->Top() > (int)max_bottom)
      {
        try
        {
	  
          int dy = cset.ControlByIndex(to + 1)->Top() - 
                   cset.ControlByIndex(from)->Top() - 
          ExportControls(html, from, to);
          
          char text[256];
          wsprintf(text, "<img src=dot.gif width=1 height=%d border=0>", dy);
	  if(dy > 0)
	    html.WriteLine(text);
        }
        catch(...)
        {
        }
        html.Flush();
	from = ++to;
      }
      else
      {
	to = i;
      }
      if(ctl->Top() + ctl->Height() > max_bottom)
        max_bottom = ctl->Top() + ctl->Height();      
    } */
    ExportControls(html, 0, cset.Count() - 1);
    //ExportControls(html, from, to);
    html.Flush();
  }

  html.WriteLine("</form></body></html>");
  html.Close();
}

BOOL DXEditor::LoadFile(const char* fn)
{
  DWORD	    ctlLeft   = 0,
	    ctlTop    = 0,
	    ctlWidth  = 0,
	    ctlHeight = 0,
	    ctlType   = controlBasic;
  char	    s[2048];
  TextFile  f(fn);
  AControl* ctl = NULL;
  ControlSet  badControls;
  LogFile   log(LogFileName);

  if(!f.Open(NULL, "r"))
  {
    log.Log("Unable to open source file: ");
    log.LogValue(fn);
    return FALSE;
  }
  log.Log("Open file: ");
  log.LogValue(fn);

  //AppWindow()->EditorCtl()->Show(SW_HIDE);

  loadingFile = TRUE;
  while(f.ReadLine(s, sizeof(s)))
  {
    if(ParseLine(s, &ctl))
    {
      if(!cset.AddControl(ctl))
      {
        char text[512];
        wsprintf(text, "Control intersection:\n  Can't find the location for "
          "%s at %d, %d  %d x %d '%s' - moved to the document's bottom",
          ctl->ControlTypeName, ctl->Left(), ctl->Top(), ctl->Width(),
          ctl->Height(), ctl->GetText());
        log.Log(text);

        static DWORD ypos = 1;
        ctl->MoveTo(1, ypos);
        badControls.AddControl(ctl);
        ypos += ctl->Height();
      }
    }
    else
    {
      log.Log("Control unknown - unable to parse the following line:"); // Report error
      log.LogValue(s);
    }
  }
  loadingFile = FALSE;
 
  //AppWindow()->EditorCtl()->Show();
  f.Close();
  if(!badControls.Count())
    SetModified(FALSE);
  else
  {
    SetModified(TRUE);
    DWORD maxypos = 0, pos;

    // Looking for the first acceptable position at the end of page
    for(DWORD i = 0; i < cset.Count(); i++)
    {
      pos = cset.ControlByIndex(i)->Top() + cset.ControlByIndex(i)->Height();
      if(pos > maxypos)
        maxypos = pos;
    }

    AControl* aCtl;
    DWORD xp = 1;
    for(i = 0; i < badControls.Count(); i++)
    {
      aCtl = badControls.ControlByIndex(i);
      aCtl->MoveTo(xp, maxypos);
      cset.AddControl(aCtl);
      xp += aCtl->Width();
    }
  }

  char cap[300];
  wsprintf(cap, "DXEditor - %s", fn);
  mainWindow->SetCaption(cap);
  return TRUE;
}

BOOL DXEditor::SaveFile(const char* fn)
{
  TextFile f(fn);
  if(!f.Open(NULL, "w"))
  {
    Error err;
    err.LoadSystemErrorInfo();
    err.Display(MB_ICONEXCLAMATION | MB_OK);
    return FALSE;
  }

  for(DWORD i = 0; i < cset.Count(); i++)
  {
    char      text[512];
    AControl* ctl = cset.ControlByIndex(i);

    wsprintf(text, "%d", 1);
    wsprintf(text, 
      "<%s left=\"%d\"; top=\"%d\"; width=\"%d\"; height=\"%d\"; %s=\"%s\">\n",
      ctl->ControlTypeName(), ctl->Left(), ctl->Top(), ctl->Width(), ctl->Height(),
      LPSTR(ctl->ControlType() == controlButton ? "caption" : "text"), 
      ctl->GetText() ? ctl->GetText() : "");

    if(!f.WriteLine(text))
    {
      Error err;
      err.LoadSystemErrorInfo();
      err.Display(MB_ICONEXCLAMATION | MB_YESNO);
      f.Close();
      return FALSE;
    }
  }
  f.Close();
  lstrcpy(fname, fn);

  char text[512];
  wsprintf(text, "DXEditor - %s", fname);
  mainWindow->SetCaption(text);
  SetModified(FALSE);
  return TRUE;
}

void DXEditor::TrackControlPosition(AControl* ctl, RECT* rc)
{
  static HCURSOR hcursorNoDrop = ::LoadCursor(hInst, "nodrop");
  static HCURSOR hcursorNormal = ::LoadCursor(hInst, "movecursor");

  SetModified(TRUE);

  if(!IsPositionValid(ctl, rc))
    ::SetCursor(hcursorNoDrop);
  else
    ::SetCursor(hcursorNormal);

  char text[64];
  wsprintf(text, "%s   %d, %d   %d x %d", ctl->ControlTypeName(),
    rc->left, rc->top, rc->right - rc->left, rc->bottom - rc->top);
  AppWindow()->StatusbarCtl()->SetText(1 | SBT_NOBORDERS, text);
  AppWindow()->StatusbarCtl()->Update();
}

BOOL DXEditor::IsPositionValid(AControl* ctl, RECT* rc)
{
  AControl* iCtl = NULL;
  RECT      rc2, rc3;

  for(DWORD i = 0; i < cset.Count(); i++)
  {
    iCtl = cset.ControlByIndex(i);
    if(iCtl == ctl)
      continue;

    iCtl->GetExtent(rc2);
    if(::IntersectRect(&rc3, rc, &rc2))
      return FALSE;
  }
  return TRUE;
}

void DXEditor::ScrollControls(int dx, int dy)
{
  AControl *ctl = NULL;
  for(DWORD i = 0; i < cset.Count(); i++)
  {
    ctl = cset.ControlByIndex(i);
    ctl->MoveTo(ctl->Left() + dx, ctl->Top() + dy);
  }
}

BOOL DXEditor::ParseLine(const char* s, AControl** ctl)
{
  int	slen = lstrlen(s);
  char	ctlName[32]	= "";
  char  propName[16]	= "";
  char  propValue[1024]	= "";

  for(int i = 0, j = 0; i < slen && s[i] != '<'; i++)
    ; // Skip chars before <
  for(j = 0, ++i; i < slen && j < sizeof(ctlName) - 1 && s[i] != ' '; i++, j++)
    ctlName[j] = s[i];	// Copy control name
  ctlName[i] = '\0';

  // Create a control
  HWND hwndParent = mainWindow ? HWND(*(mainWindow->EditorCtl())) : NULL;
  if(!lstrcmpi(ctlName, "Button"))
    *ctl = new AButton(hwndParent, 10, 10, 100, 30, "Button");
  else if(!lstrcmpi(ctlName, "Label"))
    *ctl = new ALabel(hwndParent, 10, 10, 100, 30, "Label");
  else if(!lstrcmpi(ctlName, "TextEdit"))
    *ctl = new ATextEdit(hwndParent, 10, 10, 100, TEXTEDIT_HEIGHT, "TextEdit");
  else
  {
    *ctl = NULL;
    return FALSE;
  }

  char stopChar = '"';

  for(int n = 0; n < 5; n++)
  {
    for(; !isalpha(s[i]) && i < slen; i++)
      ;
    for(j = 0; j < sizeof(propName) - 1 && isalpha(s[i]) && i < slen; i++, j++)
      propName[j] = s[i];
    propName[j] = '\0';

    // Searching for quote, or for digit or letter if quote is missed
    for(; s[i] != stopChar && i < slen; i++)
      if(isalpha(s[i]) || isdigit(s[i]))
      {
        i--;
        stopChar = ' ';
        break;
      }
    for(j = 0, ++i; j < sizeof(propValue) - 1 && (s[i] != '"' || s[i] != stopChar) && i < slen; i++, j++)
      propValue[j] = s[i];
    propValue[j] = '\0';
    (*ctl)->SetPropByName(propName, propValue);
  }

  return TRUE;
}

BOOL DXEditor::ExportControls(TextFile&f, int from, int to)
{
  DWORD		  min_top = DWORD(-1);
  int		  cnt = to - from + 2;
  TArray <int>	  lefts(cnt, TRUE);
  TArray <int>	  tops(cnt, TRUE);
  TArray <DWORD>  wid(cnt, TRUE);
  TArray <DWORD>  hei(cnt, TRUE);
  TMatrix <DWORD> tbl(cnt, cnt);
  AControl*	  ctl = NULL;

  for(int i = 0; i < cnt; i++)
  {
    lefts[i] = -1;
    tops[i] = -1;
  }

  for(i = 0; i < cnt - 1; i++)
  {
    ctl = cset.ControlByIndex(i + from);

    if(ctl->Top() < (int)min_top)
      min_top = ctl->Top();

    // Creating vector of cell lefts
    for(int j = 0; j < cnt; j++)
    {
      if(lefts[j] < 0)
      {
	lefts[j] = ctl->Left();
	break;
      }
      if(ctl->Left() < lefts[j])
      {
	lefts.ShiftOut(j);
	lefts[j] = ctl->Left();
	break;
      }
      else if(ctl->Left() == lefts[j])
	break;	
    }

    // Creating vector of cell tops
    for(j = 0; j < cnt; j++)
    {
      if(tops[j] < 0)
      {
	tops[j] = ctl->Top();
	break;
      }
      else if(ctl->Top() < tops[j])
      {
	tops.ShiftOut(j);
	tops[j] = ctl->Top();
	break;
      }
      else if(ctl->Top() == tops[j])
	break;
    }
  }

  DWORD twid = 0, cwid = 0;
  for(i = 0; i < cnt - 1 && lefts[i]; i++)
    wid[i] = lefts[i] - (i ? lefts[i - 1] : 1);
  for(int j = 0; j < cnt - 1; j++)
  {
    AControl* aCtl = cset.ControlByIndex(from + j);
    twid = (aCtl->Left() + aCtl->Width() > twid) ? aCtl->Left() + aCtl->Width() : twid;
    cwid += wid[j];
  }
  wid[i] = twid - cwid;

  DWORD thei = 0, chei = 0;
  for(i = 0; i < cnt - 1 && tops[i + 1] > 0; i++)
      hei[i] = tops[i + 1] - tops[i];//min_top;
  for(j = 0; j < cnt - 1; j++)
  {
    AControl* aCtl = cset.ControlByIndex(from + j);
    thei = (aCtl->Top() + aCtl->Height() - min_top) > thei ?
      (aCtl->Top() + aCtl->Height() - min_top) : thei;
    chei += (hei[j] > 0 ? hei[j] : 0);
  }
  hei[i] = thei - chei;
  //hei.ShiftOut(0);
  //hei[0] = 1;
  
  // Creating table of controls
  for(i = 0; i < cnt - 1; i++)
  {
    ctl = cset.ControlByIndex(i + from);

    for(int j = 0; j < cnt; j++)
      if(ctl->Left() == lefts[j])
	break;

    for(int k = 0; k < cnt; k++)
      if(ctl->Top() == tops[k])
	break;

    DWORD w, h;
    w = 0, h = 0;

    j++;
    //k++;
    tbl[k][j] = i + from + 1; // index of control + 1
    for(; w < ctl->Width() && j < cnt; j++)
    {
      int tk;

      w += wid[j];
      if(!tbl[k][j])
	tbl[k][j] = -3;

      tk = k;
      for(h = 0; h < ctl->Height() && k < cnt; k++)
      {
	h += hei[k];
	if(!tbl[k][j])
	  tbl[k][j] = -2;
      }
      k = tk;
    }
  }

  // Process table
  char text[256];
  wsprintf(text, "\n<table cellSpacing=0 cellPadding=0 border=0 width=%d>\n", twid);
  f.WriteLine(text);

  // Writing first row 
  f.WriteLine("<tr>");
  for(j = 0; j < cnt; j++)
    if(wid[j] > 0)
    {
        char t[120];
        wsprintf(t, "\n<td width=%d height=1>"
          "<img src=dot.gif width=%d height=1 border=0 alt=''></td>",
          wid[j], wid[j]);
        f.WriteLine(t);
    }
  f.WriteLine("</tr>");

  for(i = 0; i < cnt; i ++)
  {
    if(hei[i] < 0)
      continue;
    f.WriteLine("<tr valign=top>\n");
    for(int j = 0; j < cnt; j++)
    {
      char text[32];
      if(tbl[i][j] < 10000)
        f.WriteLine("<td");
      if(!j)
      {
        wsprintf(text, " height=%d", hei[i] ? hei[i] : 1);
        f.WriteLine(text);
      }

      if(tbl[i][j] < 10000 && tbl[i][j])
      {
        int colSpan = 1, rowSpan = 1;
	for(; j + colSpan < cnt && tbl[i][j + colSpan] == -3; colSpan++)
	  ;
	for(; i + rowSpan < cnt && tbl[i + rowSpan][j] == -2; rowSpan++)
	  ;

	if(colSpan > 1)
	{
	  wsprintf(text, " colSpan=%d", colSpan);
	  f.WriteLine(text);
	}
	if(rowSpan > 1)
	{
	  wsprintf(text, " rowSpan=%d", rowSpan);
	  f.WriteLine(text);
	}

	f.WriteLine(">");

        char htmls[256];
        if(tbl[i][j] < 5000)
          f.WriteLine(cset.ControlByIndex(tbl[i][j] - 1)->GetHTMLString(htmls));
      }
      else if(tbl[i][j] > 10000)
        ;
      else
	f.WriteLine(">");

      if(1) 
      {
        char text[256];
        if(!j)
        { 
	  wsprintf(text, "<img src=dot.gif width=1 height=%d border=0 alt=''>", hei[i]);
	  f.WriteLine(text);
        } 
      } 
      if(tbl[i][j] < 10000)
        f.WriteLine("</td>\n");
    }

    f.WriteLine("</tr>\n");
  }

  f.WriteLine("</table>\n");


  return thei;
}

void DXEditor::ExitEditor()
{
  if(Modified())
  {
    int ret = 0;
    if((ret = ::MessageBox(HWND(*mainWindow), "The document has been modified. "
      "Do you want to save it before quitting?", "DXEditor",
      MB_ICONEXCLAMATION | MB_YESNOCANCEL)) == IDYES)
    {
      MenuFileSave();
    }
    else if(ret == IDCANCEL)
      return;
  }
  delete mainWindow;
}

void DXEditor::MenuFileNew()
{
  // Save current document if it is modified
  if(Modified())
  {
    int ret = 0;
    if((ret = ::MessageBox(HWND(*mainWindow), "The document has been modified. "
      "Do you want to save it before opening new document?", "DXEditor",
      MB_ICONEXCLAMATION | MB_YESNOCANCEL)) == IDYES)
    {
      MenuFileSave();
    }
    else if(ret == IDCANCEL)
      return;
  }

  // Destroying all controls
  cset.Clear();
  AppWindow()->EditorCtl()->ResetPage();

  SetModified(FALSE);
  fname[0] = '\0';
  mainWindow->SetCaption("DXEditor - Untitled");
}

void DXEditor::MenuFileOpen()
{
  // Save current document if it is modified
  MenuFileNew();

  // Get a file name to open
  OPENFILENAME  ofn;
  memset(&ofn, 0, sizeof(ofn));
  ofn.lStructSize   = sizeof(ofn);
  ofn.hwndOwner     = HWND(*mainWindow);
  ofn.lpstrFilter   = "DXEditor Files (*.dxe)\0*.dxe\0"
                      "DAT Files (*.dat)\0*.dat\0"
                      "All Files (*.*)\0*.*\0";
  ofn.nFilterIndex  = 1;
  ofn.lpstrFile     = fname;
  ofn.nMaxFile      = sizeof(fname);
  ofn.lpstrTitle    = "Open File";
  ofn.lpstrDefExt   = "dxe";
  ofn.Flags         = OFN_HIDEREADONLY;
  if(::GetOpenFileName(&ofn))
    LoadFile(fname);
}

void DXEditor::MenuFileSave()
{
  if(!fname[0])
  {
    MenuFileSaveAs();
    return;
  }

  if(SaveFile(fname))
    SetModified(FALSE);
}

void DXEditor::MenuFileSaveAs()
{
  char name[256] = "";
  OPENFILENAME  ofn;
  memset(&ofn, 0, sizeof(ofn));
  ofn.lStructSize   = sizeof(ofn);
  ofn.hwndOwner     = HWND(*mainWindow);
  ofn.lpstrFilter   = "DXEditor Files (*.dxe)\0*.dxe\0"
                      "DAT Files (*.dat)\0*.dat\0"
                      "All Files (*.*)\0*.*\0";
  ofn.nFilterIndex  = 1;
  ofn.lpstrFile     = name;
  ofn.nMaxFile      = sizeof(fname);
  ofn.lpstrTitle    = "Save File";
  ofn.lpstrDefExt   = "dxe";
  ofn.Flags         = OFN_HIDEREADONLY;
  if(::GetSaveFileName(&ofn))
  {
    lstrcpy(fname, name);
    MenuFileSave();
  }
}

void DXEditor::MenuFileExport()
{
  char        source[256] = "";
  static char target[256] = "page.html";

  int dx = ::GetScrollPos(*AppWindow()->EditorCtl(), SB_HORZ);
  int dy = ::GetScrollPos(*AppWindow()->EditorCtl(), SB_VERT);
  ScrollControls(dx, dy);

  MenuFileSave();
  if(Modified())
  {
    MessageBox(*mainWindow, "You should save the file before exporting it",
      "DXEditor", MB_OK | MB_ICONEXCLAMATION);
    return;
  }
  else
    lstrcpy(source, fname);

  OPENFILENAME  ofn;
  memset(&ofn, 0, sizeof(ofn));
  ofn.lStructSize   = sizeof(ofn);
  ofn.hwndOwner     = HWND(*mainWindow);
  ofn.lpstrFilter   = "Web Page Files (*.html)\0*.html\0";
  ofn.nFilterIndex  = 1;
  ofn.lpstrFile     = target;
  ofn.nMaxFile      = sizeof(target);
  ofn.lpstrTitle    = "Save Web Page File (HTML)";
  ofn.lpstrDefExt   = "html";
  ofn.Flags         = OFN_HIDEREADONLY;
  if(::GetSaveFileName(&ofn))
  {
    MenuFileNew();
    ExportFile(source, target);
  }
}

void DXEditor::MenuInsertControl(DWORD ctlId)
{
  insertCtl = ctlId;
}

void DXEditor::MenuViewPageInBrowser()
{
  //char  source[256];
  char  target[256];

  MenuFileSave();
  if(Modified())
  {
    ::MessageBox(*mainWindow, "Please save the file before previewing it!",
      "DXEditor", MB_OK | MB_ICONEXCLAMATION);
    return;
  }

  lstrcpy(target, fname);
  for(int i = lstrlen(target); i; i--)
  {
    if(target[i] == '.')
    {
      target[i] = '\0';
      break;
    }
  }
  lstrcat(target, ".html");
  dxeditor.Controls()->Clear();
  ExportFile(fname, target);
  ::ShellExecute(NULL, "open", target, "", "", SW_SHOWNORMAL);
}

void DXEditor::MenuViewProperties()
{
  ::SetFocus(*mainWindow->PropBrowserCtl());
}