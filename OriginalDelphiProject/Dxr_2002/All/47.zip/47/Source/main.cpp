#include "dxeditor.hpp"
#include "textfile.hpp"

struct CommandArgs
{
  char  sfile[256];
  char  tfile[256];
};

void ParseCommandLine(const char* cmdLine, CommandArgs& args);

// Globals
HINSTANCE hInst	      = NULL;
char      AppName[]   = "DXEditorApp";
char      AppTitle[]  = "DXEditor";
DXEditor  dxeditor;
char      LogFileName[MAX_PATH] = "";

#include <stdio.h>
#include "matrix.hpp"

// ------------------------ Here it starts -----------------------------------
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR cmdLine, int)
{ 
  CommandArgs args;

  hInst = hInstance;
  ::GetModuleFileName(hInst, LogFileName, sizeof(LogFileName));
  lstrcpy(LogFileName + lstrlen(LogFileName) - 3, "log");
  DeleteFile(LogFileName);

  ParseCommandLine(cmdLine, args);

  if(args.sfile[0] && args.tfile[0])
  {
    loadingFile = TRUE;
    dxeditor.ExportFile(args.sfile, args.tfile);
  }
  else
    dxeditor.GoInteractive(args.sfile[0] ? args.sfile : NULL);

  return 0;
}


// ----------------------------------------------------------
void ParseCommandLine(const char* cmdLine, CommandArgs& args)
{
  int   clen = lstrlen(cmdLine);
  char  stopChar = ' ';
  int   i = 0;

  memset(&args, 0, sizeof(args));

  if(cmdLine[0] == '"')
  {
    stopChar = '"';
    i++;
  }

  for(int j = 0; i < clen && i < 256 && cmdLine[i] != stopChar; i++, j++)
    args.sfile[j] = cmdLine[i];
  
  for(; cmdLine[i] == ' ' || cmdLine[i] == '"'; i++)
    ;

  if(cmdLine[i - 1] == '"')
    stopChar = '"';
  else
    stopChar = ' ';

  for(j = 0; i < clen && i < 256 && cmdLine[i] != stopChar; i++, j++)
    args.tfile[j] = cmdLine[i];

  return;
}
