#ifndef _DXEDITOR_HPP_
#define _DXEDITOR_HPP_
#include <windows.h>
#include <commctrl.h>
#include "controls.hpp"
#include "ctlset.hpp"
#include "textfile.hpp"
#include "error.hpp"
#include "matrix.hpp"

class Toolbar;
class Statusbar;
class Controlbar;
class PropBrowser;
class EditorWindow;
class MainWindow;
class DXEditor;
class ControlSet;

extern char	AppName[];
extern char	AppTitle[];
extern DXEditor	dxeditor;

#define IDB_CTL_BUTTON  1001
#define IDB_CTL_LABEL   1002
#define IDB_CTL_TEXT    1003

enum _EditorStates
{
  stateNormal,
  stateInserting
};

struct CTLBARBUTTON
{
  HICON hIcon;
  char* text;
  DWORD id;
};

struct CTLBARBUTTONS
{
  CTLBARBUTTON* buttons;
  DWORD         count;
};

class MainWindow
{
    Toolbar*      tb;
    Statusbar*    sb;
    Controlbar*   cb;
    PropBrowser*  pb;
    EditorWindow* editor;
    HWND          hwndMain;
    DWORD	  lpwidth;    // Left pannel width
    BOOL          splitting;  // Window is being splitted flag

  protected:
    BOOL  RegisterClass();

  public:
    MainWindow();
    ~MainWindow();

    operator HWND() { return hwndMain;}

    Toolbar*	  ToolbarCtl()	    { return tb;}
    Statusbar*	  StatusbarCtl()    { return sb;}
    Controlbar*	  ControlbarCtl()   { return cb;}
    PropBrowser*  PropBrowserCtl()  { return pb;}
    EditorWindow* EditorCtl()	    { return editor;}

    DWORD Run();
    void  SetCaption(const char* caption);
    void  Update() { ::InvalidateRect(hwndMain, NULL, TRUE); ::UpdateWindow(hwndMain);}

    // Events
    LRESULT OnSize(DWORD width, DWORD height);
    LRESULT OnLeftButtonDown(DWORD keys, DWORD x, DWORD y);
    LRESULT OnLeftButtonUp(DWORD keys, DWORD x, DWORD y);
    LRESULT OnMouseMove(DWORD keys, DWORD x, DWORD y);
    LRESULT OnCommand(DWORD codeNotify, DWORD ctlId, HWND hwndCtl);
    LRESULT OnPaint(HDC hdc);
    LRESULT OnNotify(int idFrom, NMHDR* pnmhdr);
};

class DXEditor
{
    MainWindow*	mainWindow;
    char	fname[256];
    HWND	focusedCtl;
    ControlSet	cset;
    BOOL        modified;
    DWORD       insertCtl;

    BOOL  ParseLine(const char* s, AControl** ctl);

  public:
    DXEditor();
    ~DXEditor();

    void  GoInteractive(const char* filename);
    void  ExportFile(const char* sourcefile, const char* htmlfile);
    BOOL  ExportControls(TextFile& f, int from, int to);
    void  ExitEditor();

    void  SetModified(BOOL _modified) { modified = _modified;}
    BOOL  Modified() { return modified;}
    DWORD InsertControl() { return insertCtl;}
    void  DoneInserting() { insertCtl = 0;}

    void  SetFocusedControl(HWND _hwnd) { focusedCtl = _hwnd;}
    HWND  FocusedControl() { return focusedCtl;}
    void  DisplayControlInfo();

    BOOL  LoadFile(const char* fn);
    BOOL  SaveFile(const char* fn);

    void  MenuFileNew();
    void  MenuFileOpen();
    void  MenuFileSave();
    void  MenuFileSaveAs();
    void  MenuFileExport();

    void  MenuInsertControl(DWORD ctlId);

    void  MenuViewPageInBrowser();
    void  MenuViewProperties();

    MainWindow* AppWindow() { return mainWindow;}
    ControlSet* Controls() { return &cset;}
    void  TrackControlPosition(AControl* ctl, RECT* rc);
    BOOL  IsPositionValid(AControl* ctl, RECT* rc);
    void  ScrollControls(int dx, int dy);
};

class ToolWindow : public CtlWnd
{
  public:
    ToolWindow(HWND _hwnd) : CtlWnd(_hwnd) {}
    virtual ~ToolWindow() {}
};

class Toolbar : public ToolWindow
{
  public:
    Toolbar(HWND hwndParent);
};

class Statusbar : public ToolWindow
{
  public:
    Statusbar(HWND hwndParent);

    void  SetText(int panel, const char* text)
    {
      ::SendMessage(hwnd, SB_SETTEXT, panel, LPARAM(text));
    }
};

class Controlbar : public ToolWindow
{
    CTLBARBUTTONS butts;

  public:
    Controlbar(HWND hwndParent);

    BOOL  RegisterClass();

    LRESULT OnPaint(HDC hdc);
};

class PropBrowser : public ToolWindow
{
  friend LRESULT APIENTRY PropBrowserWndProc(HWND hwnd, 
                            UINT msg, WPARAM wParam, LPARAM lParam);
    static HWND  hwndEdits[5];
  public:
    PropBrowser(HWND hwndParent);

    BOOL  RegisterClass();

    void  SetProps(DWORD left, DWORD top, DWORD width, DWORD height, const char* text);
    void  GetProps(DWORD* left, DWORD* top, DWORD* width, DWORD* height, char* text);
    void  OnCreate(HWND _hwnd);
    LRESULT OnPaint(HDC hdc);
};

class EditorWindow : public ToolWindow
{
    DWORD   page_width;
    DWORD   page_height;

  public:
    EditorWindow(HWND hwndParent);

    BOOL  RegisterClass();

    DWORD   PageWidth() const   { return page_width;}
    DWORD   PageHeight() const  { return page_height;}
    void    SetPageWidth(DWORD pw)  { page_width = pw;}
    void    SetPageHeight(DWORD ph) { page_height = ph;}
    void    ResetPage();
};



















#endif // _DXEDITOR_HPP_