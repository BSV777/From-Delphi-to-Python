#ifndef _CTLSET_HPP_
#define _CTLSET_HPP_
#include "controls.hpp"

#define MAX_PAGEWIDTH   1600

/*template <class T>
class List
{
    T*    ptr;
    List* prev;
    List* next;

  public:
    List();
    ~List();

    List<T>*  InsertAfter(T* object); // Insert new node after current
    List<T>*  Remove(); // Remove current node
};*/

class ControlSet
{
    AControl**	controls;
    DWORD	count;
    DWORD	maxcount;

  protected:
    BOOL	ReallocMem();
  public:
    ControlSet();
    ~ControlSet();

    DWORD	Count() { return count;}

    BOOL	AddControl(AControl* ctl);
    BOOL	RemoveControl(AControl* ctl);
    void        Clear();
    AControl*	ControlByIndex(DWORD index);
    BOOL	PositionValid(AControl* ctl);
    BOOL	MakeValidPosition(AControl* ctl);
};





















#endif