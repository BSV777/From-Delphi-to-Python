#ifndef _CONTROLS_HPP_
#define _CONTROLS_HPP_
#include <windows.h>

#define TEXTEDIT_HEIGHT 22
#define MIN_CTL_WIDTH   25
#define MIN_CTL_HEIGHT  16

extern HINSTANCE  hInst;
extern BOOL       loadingFile;

enum _ControlTypes
{
  controlBasic,
  controlButton,
  controlLabel,
  controlTextEdit
};

class CtlWnd
{
  protected:
    HWND  hwnd;

  public:
    CtlWnd(HWND _hwnd) : hwnd(_hwnd) {}
    virtual ~CtlWnd() {}

    int Left() const;
    int Top() const;
    DWORD Width() const;
    DWORD Height() const;
    virtual BOOL  GetExtent(RECT& rc) const;

    virtual BOOL  MoveTo(int left, int top);
    virtual BOOL  SizeTo(DWORD width, DWORD height);
    virtual BOOL  SetExtent(int left, int top, DWORD width, DWORD height);
    void          Show(DWORD cmd = SW_SHOW) { ::ShowWindow(hwnd, cmd);}
    void          Update() { ::InvalidateRect(hwnd, NULL, TRUE); ::UpdateWindow(hwnd);}

    operator  HWND() { return hwnd;}
};

class AControl : public CtlWnd
{
  protected:
    int   left;
    int   top;
    DWORD width;
    DWORD height;
    char* text;


  public:
    AControl(HWND hwndParent, int _left, int _top,
      DWORD _width, DWORD _height, const char* _text = "Sample control");
    virtual ~AControl() { ::DestroyWindow(hwnd);}

    virtual BOOL  SetPropByName(const char* propName, void* propValue);

    DWORD GetId() const { return DWORD(GetMenu(hwnd));}
    virtual BOOL  GetExtent(RECT& rc) const;
    virtual BOOL  SetExtent(int _left, int _top, DWORD _width, DWORD _height);
    virtual BOOL  MoveTo(int _left, int _top);
    virtual BOOL  SizeTo(DWORD _width, DWORD _height);
    virtual const char*	GetText() const;
    virtual BOOL  SetText(const char* _text);
    HWND          GetParent() { return ::GetParent(hwnd);}

    virtual char* GetHTMLString(char* s) { return s;}
    virtual DWORD ControlType() { return controlBasic;}
    virtual const char* ControlTypeName() { return "Control";}
    virtual void  PaintControl(HDC hdc, BOOL focused) {}
    void	  DrawGrabbers(HDC hdc);

    LRESULT       OnMove(int x, int y);
    LRESULT       OnNCHitTest(int x, int y);

    static BOOL  RegisterWindowClass();
    static DWORD NextID();
};

typedef AControl* LPAControl;

class AButton : public AControl
{
  public:
    AButton(HWND hwndParent, int _left, int _top, 
      DWORD _width, DWORD _height, const char* _text = "Sample button");

    const char*	GetCaption() const	    { return GetText();}
    BOOL  SetCaption(const char* _caption)  { return SetText(_caption);}
    virtual DWORD ControlType()		    { return controlButton;}
    virtual void  PaintControl(HDC hdc, BOOL focused);
    virtual BOOL  SetPropByName(const char* propName, void* propValue);
    virtual const char* ControlTypeName() { return "Button";}
    virtual char* GetHTMLString(char* s);
};

class ATextEdit : public AControl
{
  public:
    ATextEdit(HWND hwndParent, int _left, int _top, DWORD _width, DWORD _height,
      const char* _text = "Sample text");

    const char* GetText() const		    { return AControl::GetText();}
    BOOL  SetText(const char* _text)	    { return AControl::SetText(_text);}
    virtual DWORD ControlType()		    { return controlTextEdit;}
    virtual void  PaintControl(HDC hdc, BOOL focused);

    virtual char* GetHTMLString(char* s);
    virtual const char* ControlTypeName() { return "TextEdit";}
    virtual BOOL  SetExtent(int _left, int _top, DWORD _width, DWORD);
    virtual BOOL  SetPropByName(const char* propName, void* propValue);
    BOOL          SizeTo(DWORD _width, DWORD _height);
};

class ALabel : public AControl
{
    static BOOL hilited;
  public:
    ALabel(HWND hwndParent, int _left, int _top, DWORD _width, DWORD _height,
      const char* _text = "Sample label");

    const char* GetText() const		    { return AControl::GetText();}
    BOOL  SetText(const char* _text)	    { return AControl::SetText(_text);}
    virtual DWORD ControlType()		    { return controlLabel;}
    virtual void  PaintControl(HDC hdc, BOOL focused);
    virtual const char* ControlTypeName() { return "Label";}
    virtual char* GetHTMLString(char* s);

    static void   HiliteLabels(BOOL f) { hilited = f;}
    static BOOL   LabelsHilited() { return hilited;}
};


LRESULT APIENTRY ControlWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);


#endif // _CONTROLS_HPP_