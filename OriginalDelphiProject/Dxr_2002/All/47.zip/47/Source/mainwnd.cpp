#include "dxeditor.hpp"
#include <commctrl.h>
#include "resource.h"

AControl* clipControl = NULL;
extern TBBUTTON	tbButtons[11];

// ----------------------------------------------------------------
LRESULT APIENTRY MainWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

MainWindow::MainWindow() : tb(NULL), sb(NULL), cb(NULL), pb(NULL),
                           editor(NULL), hwndMain(NULL),
                           lpwidth(150), splitting(FALSE)
{
  if(!RegisterClass())
    throw -1;

  HMENU hMenu = ::LoadMenu(hInst, "appmenu");

  hwndMain = ::CreateWindowEx(0, AppName, AppTitle, WS_OVERLAPPEDWINDOW,
    CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
    NULL, hMenu, hInst, LPVOID(this));
  if(!hwndMain)
    throw -1;

  // Create toolbar, statusbar, contolbar, prop. browser and editor window
  tb = new Toolbar(hwndMain);
  sb = new Statusbar(hwndMain);
  cb = new Controlbar(hwndMain);
  pb = new PropBrowser(hwndMain);
  editor = new EditorWindow(hwndMain);

  ::ShowWindow(hwndMain, SW_SHOWNORMAL);
  ::UpdateWindow(hwndMain);
}

MainWindow::~MainWindow()
{
  delete tb;
  delete sb;
  delete cb;
  delete pb;
  delete editor;
  ::DestroyWindow(hwndMain);
}

BOOL MainWindow::RegisterClass()
{
  static BOOL registered = FALSE;
  WNDCLASSEX  wcx;

  memset(&wcx, 0, sizeof(wcx));
  wcx.cbSize        = sizeof(wcx);
  wcx.hbrBackground = HBRUSH(COLOR_WINDOW);
  wcx.hCursor       = ::LoadCursor(NULL, IDC_SIZEWE);
  wcx.hIcon         = ::LoadIcon(hInst, "appicon");
  wcx.hInstance     = hInst;
  wcx.lpfnWndProc   = MainWndProc;
  wcx.lpszClassName = AppName;

  if(!RegisterClassEx(&wcx))
    return FALSE;

  if(!AControl::RegisterWindowClass())
    return FALSE;

  registered = TRUE;
  return TRUE;
}

DWORD MainWindow::Run()
{
  MSG msg;

  while(GetMessage(&msg, 0, 0, 0))
  {
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }

  return msg.wParam;
}

void MainWindow::SetCaption(const char* caption)
{
  if(this)
    ::SetWindowText(hwndMain, caption);
}


LRESULT MainWindow::OnSize(DWORD width, DWORD height)
{
  SendMessage(*tb, WM_SIZE, width, height);
  SendMessage(*sb, WM_SIZE, width, height);

  RECT rc;
  ::GetClientRect(hwndMain, &rc);
  cb->SetExtent(-2, tb->Height() - 1, lpwidth, (rc.bottom - tb->Height() - sb->Height()) / 2);
  pb->SetExtent(-2, tb->Height() + cb->Height() - 3, lpwidth, rc.bottom - tb->Height() - cb->Height() - 14);
  editor->SetExtent(cb->Width(), tb->Height() - 1, rc.right - cb->Width(), rc.bottom - tb->Height() - sb->Height() + 2);

  // ������������ ������� �������� Statusbar
  int ptWidth[] = {width / 3 * 2, -1};
  
  SendMessage(*sb, SB_SETPARTS, 2, (LPARAM)ptWidth);
  return 0;
}

LRESULT MainWindow::OnPaint(HDC hdc)
{
  return 0;
}

LRESULT MainWindow::OnCommand(DWORD codeNotify, DWORD ctlId, HWND hwndCtl)
{
  switch(codeNotify)
  {
    case 0:
    {
      switch(ctlId)
      {
        case IDM_FILE_NEW:
          dxeditor.MenuFileNew();
	  break;
	case IDM_FILE_OPEN:
          dxeditor.MenuFileOpen();
	  break;
	case IDM_FILE_SAVE:
          dxeditor.MenuFileSave();
	  break;
	case IDM_FILE_SAVEAS:
          dxeditor.MenuFileSaveAs();
	  break;
	case IDM_FILE_EXPORT:
          dxeditor.MenuFileExport();
	  break;
	case IDM_FILE_EXIT:
	  dxeditor.ExitEditor();
	  break;
	case IDM_EDIT_CUT:
          if(dxeditor.FocusedControl())
          {
            LPAControl ctl = LPAControl(::GetProp(dxeditor.FocusedControl(), "ObjPtr"));
            dxeditor.Controls()->RemoveControl(ctl);
            ctl->Show(SW_HIDE);
            clipControl = ctl;
            dxeditor.SetModified(TRUE);
          }
	  break;
	case IDM_EDIT_COPY:
          if(dxeditor.FocusedControl())
          {
            LPAControl ctl = LPAControl(::GetProp(dxeditor.FocusedControl(), "ObjPtr"));
            clipControl = ctl;
          }
	  break;
	case IDM_EDIT_PASTE:
        {          
          if(!clipControl)
            break;
          try
          {
            LPAControl newCtl = NULL; 
            switch(clipControl->ControlType())
            {
              case controlButton:
                newCtl = new AButton(clipControl->GetParent(), clipControl->Left(), clipControl->Top(),
                  clipControl->Width(), clipControl->Height(), clipControl->GetText());
                break;
              case controlLabel:
                newCtl = new ALabel(clipControl->GetParent(), clipControl->Left(), clipControl->Top(),
                  clipControl->Width(), clipControl->Height(), clipControl->GetText());
                break;
              case controlTextEdit:
                newCtl = new ATextEdit(clipControl->GetParent(), clipControl->Left(), clipControl->Top(),
                  clipControl->Width(), clipControl->Height(), clipControl->GetText());
                break;
            }
            if(newCtl)
              dxeditor.Controls()->AddControl(newCtl);
            dxeditor.SetModified(TRUE);
          }
          catch(...)
          {
          }
	  break;
        }
	case IDM_EDIT_DEL:
          if(dxeditor.FocusedControl())
          {
            LPAControl ctl = LPAControl(::GetProp(dxeditor.FocusedControl(), "ObjPtr"));
            if(!ctl)
              break;
            dxeditor.Controls()->RemoveControl(ctl);
            delete ctl;
            dxeditor.SetModified(TRUE);
          }
	  break;
        case IDM_INSERT_BUTTON:
          dxeditor.MenuInsertControl(controlButton);
          dxeditor.SetModified(TRUE);
          break;
        case IDM_INSERT_LABEL:
          dxeditor.MenuInsertControl(controlLabel);
          dxeditor.SetModified(TRUE);
          break;
        case IDM_INSERT_TEXT:
          dxeditor.MenuInsertControl(controlTextEdit);
          dxeditor.SetModified(TRUE);
          break;
	case IDM_VIEW_BROWSER:
          dxeditor.MenuViewPageInBrowser();
	  break;
        case IDM_VIEW_HILITELABELS:
        {
          ALabel::HiliteLabels(!ALabel::LabelsHilited());
          HMENU hmenu = ::GetMenu(hwndMain);
          hmenu = ::GetSubMenu(hmenu, 3);
          CheckMenuItem(hmenu, IDM_VIEW_HILITELABELS,
            MF_BYCOMMAND | (ALabel::LabelsHilited() ? MF_CHECKED : MF_UNCHECKED));
          editor->Update();
          break;
        }
	case IDM_VIEW_PROPERTIES:
          dxeditor.MenuViewProperties();
	  break;
	case IDM_HELP_ABOUT:
	  ::MessageBox(hwndMain, "DXEditor v. 1.1 created by\n\nAlexander Sorokin "
	    "(al@splav.org), March 2002", "About DXEditor", MB_OK | MB_ICONINFORMATION);
	  break;
	case IDM_HELP_CONTENTS:
	{
	  char hlpfile[256];
	  ::GetModuleFileName(hInst, hlpfile, sizeof(hlpfile));
	  lstrcpy(hlpfile + lstrlen(hlpfile) - 3, "hlp");
	  WinHelp(hwndMain, hlpfile, HELP_CONTENTS, 0);
	  break;
	}
	default:
	  break;
      }
      break;
    }

  }

  return 0;
}

LRESULT MainWindow::OnNotify(int idFrom, NMHDR* pnmhdr)
{
  LPTOOLTIPTEXT lpToolTipText;
  LPTBNOTIFY lptbn;
  int nItem;
  static CHAR szBuf[128];

  switch(pnmhdr->code)
  {
    case TTN_NEEDTEXT:
      lpToolTipText = (LPTOOLTIPTEXT)pnmhdr;
      LoadString(hInst, lpToolTipText->hdr.idFrom,
        szBuf, sizeof(szBuf));
      lpToolTipText->lpszText = szBuf;
      break;

    case TBN_GETBUTTONINFO:
      lptbn = (LPTBNOTIFY)pnmhdr; 
      nItem = lptbn->iItem;
      lptbn->tbButton.iBitmap   = tbButtons[nItem].iBitmap;
      lptbn->tbButton.idCommand = tbButtons[nItem].idCommand;
      lptbn->tbButton.fsState   = tbButtons[nItem].fsState;
      lptbn->tbButton.fsStyle   = tbButtons[nItem].fsStyle;
      lptbn->tbButton.dwData    = tbButtons[nItem].dwData;
      lptbn->tbButton.iString   = tbButtons[nItem].iString;

      return((nItem < 
        sizeof(tbButtons)/sizeof(tbButtons[0]))? TRUE : FALSE);
      break;
  
    default:
      break;
  }
  return FALSE;
}


LRESULT MainWindow::OnLeftButtonDown(DWORD keys, DWORD x, DWORD y)
{
  RECT rc;

  ::GetWindowRect(hwndMain, &rc);
  rc.left += 100;
  rc.right -= (rc.right - rc.left) / 2;
  rc.top += 70;
  rc.bottom -= 20;

  splitting = TRUE;
  ::SetCapture(hwndMain);
  ::ClipCursor(&rc);
  return 0;
}

LRESULT MainWindow::OnLeftButtonUp(DWORD keys, DWORD x, DWORD y)
{
  RECT rc;

  ::GetClientRect(hwndMain, &rc);
  ::ReleaseCapture();
  ::ClipCursor(NULL);

  lpwidth = x;
  splitting = FALSE;
  OnSize(rc.right, rc.bottom);
  return 0;


  ::GetWindowRect(hwndMain, &rc);
  rc.left += 30;
  rc.right -= (rc.right - rc.left) / 2;
  rc.top += 50;
  rc.bottom -= 20;

  ::SetCapture(hwndMain);
  ::ClipCursor(&rc);
  return 0;
}

LRESULT MainWindow::OnMouseMove(DWORD keys, DWORD x, DWORD y)
{
  if(splitting)
  {
    RECT rc;

    lpwidth = x;
    ::GetClientRect(hwndMain, &rc);
    OnSize(rc.right, rc.bottom);
  }
  return 0;
}

LRESULT APIENTRY MainWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  try {
  MainWindow* mainWnd = (MainWindow*)::GetProp(hwnd, "ObjPtr");
  switch(msg)
  {
    case WM_CREATE:
      ::SetProp(hwnd, "ObjPtr", HANDLE(LPCREATESTRUCT(lParam)->lpCreateParams));
      return 0;

    case WM_COMMAND:
      return mainWnd->OnCommand(HIWORD(wParam), LOWORD(wParam), HWND(lParam));;

    case WM_SIZE:
      return mainWnd->OnSize(LOWORD(lParam), HIWORD(lParam));

    case WM_CLOSE:
      dxeditor.ExitEditor();
      return 0;

    case WM_LBUTTONDOWN:
      return mainWnd->OnLeftButtonDown(wParam, LOWORD(lParam), HIWORD(lParam));

    case WM_LBUTTONUP:
      return mainWnd->OnLeftButtonUp(wParam, LOWORD(lParam), HIWORD(lParam));

    case WM_MOUSEMOVE:
      return mainWnd->OnMouseMove(wParam, LOWORD(lParam), HIWORD(lParam));

    case WM_GETMINMAXINFO:
    {
      LPMINMAXINFO mm = LPMINMAXINFO(lParam);
      mm->ptMinTrackSize.x = 450;
      mm->ptMinTrackSize.y = 320;
      return 0;
    }

    case WM_PAINT:
    {
      PAINTSTRUCT ps;
      HDC hdc = ::BeginPaint(hwnd, &ps);

      LRESULT ret = mainWnd->OnPaint(hdc);
      ::EndPaint(hwnd, &ps);
      return ret;
    }

    case WM_NOTIFY:
      return mainWnd->OnNotify(wParam, LPNMHDR(lParam));

    case WM_DESTROY:
      PostQuitMessage(0);
      break;

    default:
      break;
  }
  } catch(...) {}
  return ::DefWindowProc(hwnd, msg, wParam, lParam);
}

LRESULT APIENTRY ControlWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  try{
  AControl*   object = (AControl*)::GetProp(hwnd, "ObjPtr");
  static RECT rcCtl;

  switch(msg)
  {
    case WM_CREATE:
      ::SetProp(hwnd, "ObjPtr", HANDLE(LPCREATESTRUCT(lParam)->lpCreateParams));
      return 0;

    case WM_PAINT:
    {
      PAINTSTRUCT ps;
      HDC hdc = ::BeginPaint(hwnd, &ps);
      HFONT hfont = ::CreateFont(16, 0, 0, 0, FW_NORMAL, 
        FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
        CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, "Arial Cyr");
      HFONT holdfont = HFONT(::SelectObject(hdc, hfont));
      
      object->PaintControl(hdc, dxeditor.FocusedControl() == hwnd);

      ::SelectObject(hdc, holdfont);
      ::DeleteObject(hfont);
      ::EndPaint(hwnd, &ps);
      return 0;
    }

    case WM_GETMINMAXINFO:
    {
      LPMINMAXINFO mm = LPMINMAXINFO(lParam);
      mm->ptMinTrackSize.x = MIN_CTL_WIDTH;
      mm->ptMinTrackSize.y = MIN_CTL_HEIGHT;

      if(object->ControlType() == controlTextEdit)
      {
        mm->ptMinTrackSize.y = mm->ptMaxTrackSize.y = TEXTEDIT_HEIGHT;
      }
      return 0;
    }

    case WM_SETFOCUS:
    {
      dxeditor.SetFocusedControl(hwnd);
      char text[64];
      wsprintf(text, "%s   %d, %d   %d x %d", object->ControlTypeName(),
        object->Left(), object->Top(), object->Width(), object->Height());
      dxeditor.AppWindow()->StatusbarCtl()->SetText(1 | SBT_NOBORDERS, text);
      dxeditor.AppWindow()->StatusbarCtl()->Update();
      dxeditor.AppWindow()->PropBrowserCtl()->Update();

      if(wParam)
      {
        ::InvalidateRect(HWND(wParam), NULL, TRUE);
        ::UpdateWindow(HWND(wParam));
      }
      break;
    }
    case WM_KILLFOCUS:
      dxeditor.AppWindow()->StatusbarCtl()->SetText(1 | SBT_NOBORDERS, "");
      dxeditor.AppWindow()->StatusbarCtl()->Update();
      break;

    case WM_KEYDOWN:
      if(wParam == VK_DELETE)
	dxeditor.Controls()->RemoveControl(LPAControl(::GetProp(hwnd, "ObjPtr")));
      delete LPAControl(::GetProp(hwnd, "ObjPtr"));
      break;

    case WM_NCHITTEST:
    {
      POINT pt = {LOWORD(lParam), HIWORD(lParam)};
      ::ScreenToClient(hwnd, &pt);

      return object->OnNCHitTest(pt.x, pt.y);;
    }

    case WM_MOUSEMOVE:
    {
      if(wParam & MK_LBUTTON)
        return DefWindowProc(hwnd, WM_SYSCOMMAND, 0xF012, 0);
      break;
    }

    case WM_LBUTTONDOWN:
      ::SetFocus(hwnd);
      ::InvalidateRect(hwnd, NULL, TRUE);
      ::UpdateWindow(hwnd);
      break;

    case WM_SIZE:
    {
      RECT rc;
      object->GetExtent(rc);
      if(!dxeditor.IsPositionValid(object, &rc) && !loadingFile)
        object->SetExtent(rcCtl.left, rcCtl.top, rcCtl.right - rcCtl.left,
        rcCtl.bottom - rcCtl.top);

      if(HWND(*object) && !loadingFile)
      {
        ::InvalidateRect(*object, NULL, TRUE);
        ::UpdateWindow(*object);
      }
      return 0;
    }

    case WM_MOVE:
    {
      int x = (int)(short)LOWORD(lParam),
          y = (int)(short)HIWORD(lParam);
      RECT rc = {x, y, x + object->Width(), y + object->Height()};
      if(dxeditor.IsPositionValid(object, &rc) || loadingFile)
        object->MoveTo(x, y);
      else
        object->MoveTo(rcCtl.left, rcCtl.top);
      //::InvalidateRect(*object, NULL, TRUE);
      //::UpdateWindow(*object);
      return 0;
    }

    case WM_SIZING:
    case WM_MOVING:
    {
      RECT rc, rcClient, *pRect = LPRECT(lParam);
      ::CopyRect(&rc, pRect);
      POINT lt = {rc.left, rc.top}, rb = {rc.right, rc.bottom};
      ::ScreenToClient(*(dxeditor.AppWindow()->EditorCtl()), &lt);
      ::ScreenToClient(*(dxeditor.AppWindow()->EditorCtl()), &rb);
      ::SetRect(&rcClient, lt.x, lt.y, rb.x, rb.y);
      
      int dx = 0, dy = 0;
      if(rcClient.left < 0)
      {
        dx = -rcClient.left;
        pRect->left   += dx;
        pRect->right  += dx;
        rcClient.left   += dx;
        rcClient.right  += dx;
      }
      if(rcClient.top < 0)
      {
        dy = -rcClient.top;
        pRect->top    += dy;
        pRect->bottom += dy;
        rcClient.top    += dy;
        rcClient.bottom += dy;
      }
      
      dxeditor.TrackControlPosition(object, &rcClient);
      object->GetExtent(rcCtl);
      break;
    }

    default:
      break;
  }
  } catch(...) {}
  return DefWindowProc(hwnd, msg, wParam, lParam);
}

LRESULT APIENTRY ControlbarWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  try{
  Controlbar* object = (Controlbar*)::GetProp(hwnd, "ObjPtr");
  switch(msg)
  {
    case WM_CREATE:
      ::SetProp(hwnd, "ObjPtr", HANDLE(LPCREATESTRUCT(lParam)->lpCreateParams));
      return 0;
    case WM_PAINT:
    {
      PAINTSTRUCT ps;
      HDC         hdc = ::BeginPaint(hwnd, &ps);
      object->OnPaint(hdc);
      ::EndPaint(hwnd, &ps);
      break;
    }
    case WM_LBUTTONDOWN:
      ::SetProp(hwnd, "state", HANDLE((HIWORD(lParam) - 4) / 24));
      object->Update();
      dxeditor.MenuInsertControl((HIWORD(lParam) - 4) / 24 + 1);
      break;
    case WM_LBUTTONUP:
      ::SetProp(hwnd, "state", HANDLE(-1));
      object->Update();
      break;
    case WM_SIZE:
    {
      ::InvalidateRect(hwnd, NULL, TRUE);
      ::UpdateWindow(hwnd);
      break;
    }
    case WM_NCHITTEST:
      return HTCLIENT;
    default:
      break;
  }
  } catch(...) {}
  return ::DefWindowProc(hwnd, msg, wParam, lParam);
}

LRESULT APIENTRY PropBrowserWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  try {
  PropBrowser* object = (PropBrowser*)::GetProp(hwnd, "ObjPtr");
  switch(msg)
  {
    case WM_CREATE:
      ::SetProp(hwnd, "ObjPtr", HANDLE(LPCREATESTRUCT(lParam)->lpCreateParams));
      object->OnCreate(hwnd);
      return 0;
    case WM_NCHITTEST:
    {
      LRESULT ret = ::DefWindowProc(hwnd, msg, wParam, lParam);
      if(ret == HTCAPTION)
        return HTCLIENT;
      return ret;
    }
    case WM_SIZE:
    {
      int x = LOWORD(lParam);
      for(int i = 0; i < 5; i++)
        ::MoveWindow(object->hwndEdits[i], x / 2, i * 16 + 1, x / 2, 15, TRUE);
      object->Update();
      break;
    }
    case WM_PAINT:
    {
      PAINTSTRUCT ps;
      HDC         hdc = ::BeginPaint(hwnd, &ps);
      object->OnPaint(hdc);
      ::EndPaint(hwnd, &ps);
      return 0;
    }
    case WM_LBUTTONDOWN:
    {
      ::SetFocus(object->hwndEdits[4]);
      break;
    }
    case WM_COMMAND:
    {
      if(HIWORD(wParam) == EN_CHANGE)
      {
	HWND hwndCap = HWND(lParam);
	if(hwndCap == object->hwndEdits[4]) // It's caption
	{
	  AControl* ctl = LPAControl(::GetProp(dxeditor.FocusedControl(), "ObjPtr"));
	  if(ctl)
	  {
	    char text[256];
	    ::GetWindowText(hwndCap, text, sizeof(text));
	    ctl->SetText(text);
	  }
	}
      }
      break;
    }
    case WM_SETFOCUS:
      ::SetFocus(object->hwndEdits[4]);
      break;
    default:
      break;
  }
  } catch(...) {}
  return ::DefWindowProc(hwnd, msg, wParam, lParam);
}

LRESULT APIENTRY EditorWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  try {
  EditorWindow* object = (EditorWindow*)::GetProp(hwnd, "ObjPtr");
  switch(msg)
  {
    case WM_CREATE:
      ::SetProp(hwnd, "ObjPtr", HANDLE(LPCREATESTRUCT(lParam)->lpCreateParams));
      return 0;
    case WM_SIZE:
    {
      ::SetScrollRange(hwnd, SB_HORZ, 0, MAX_PAGEWIDTH - LOWORD(lParam), TRUE);
      ::SetScrollRange(hwnd, SB_VERT, 0, 30000, TRUE);// *****
      break;
    }
    case WM_MOUSEMOVE:
    {
      
      static HCURSOR hcursorInserting = ::LoadCursor(NULL, IDC_CROSS);
      static HCURSOR hcursorNormal = ::LoadCursor(NULL, IDC_ARROW);
      if(dxeditor.InsertControl())
        ::SetCursor(hcursorInserting);
      else
        ::SetCursor(hcursorNormal);

      break;
    }
    case WM_HSCROLL:
    {
      int pos = GetScrollPos(hwnd, SB_HORZ);
      switch(LOWORD(wParam))
      {
        case SB_PAGEDOWN:
          pos += 200;
          break;
        case SB_PAGEUP:
          pos -= 200;
          break;
        case SB_LINEDOWN:
          pos += 20;
          break;
        case SB_LINEUP:
          pos -= 20;
          break;
      }
      if(pos < 0)
        pos = 0;

      int dx = ::GetScrollPos(hwnd, SB_HORZ) - pos;
      ::SetScrollPos(hwnd, SB_HORZ, pos, TRUE);
      dxeditor.ScrollControls(dx, 0);
      ::SetScrollRange(hwnd, SB_HORZ, 0, 
        dxeditor.Controls()->ControlByIndex(dxeditor.Controls()->Count() - 1)->Top() + 500,
        TRUE);
      return 0;
    }
    case WM_VSCROLL:
    {
      int pos = GetScrollPos(hwnd, SB_VERT);
      switch(LOWORD(wParam))
      {
        case SB_PAGEDOWN:
          pos += 200;
          break;
        case SB_PAGEUP:
          pos -= 200;
          break;
        case SB_LINEDOWN:
          pos += 20;
          break;
        case SB_LINEUP:
          pos -= 20;
          break;
      }
      if(pos < 0)
        pos = 0;

      int dy = ::GetScrollPos(hwnd, SB_VERT) - pos;
      ::SetScrollPos(hwnd, SB_VERT, pos, TRUE);
      dxeditor.ScrollControls(0, dy);
      return 0;
    }

    case WM_LBUTTONDOWN:
    {
      ::SetFocus(hwnd);
      HWND hwndCtl = dxeditor.FocusedControl();
      dxeditor.SetFocusedControl(NULL);
      dxeditor.AppWindow()->PropBrowserCtl()->Update();
      if(hwndCtl) // Or it will repaint all screen
      {
        ::InvalidateRect(hwndCtl, NULL, TRUE);
        ::UpdateWindow(hwndCtl);
      }

      if(dxeditor.InsertControl())
      {
        AControl* ctl = NULL;
        int x = LOWORD(lParam), y = HIWORD(lParam);
	RECT rc = {x, y, x + 50, y + 22};
	if(!dxeditor.IsPositionValid(ctl, &rc))
	{
	  MessageBeep(MB_ICONEXCLAMATION);
	  break;
	}

        switch(dxeditor.InsertControl())
        {
          case controlButton:
            ctl = new AButton(*(dxeditor.AppWindow()->EditorCtl()),
              x, y, 50, 22, "Button");
            break;
          case controlLabel:
            ctl = new ALabel(*(dxeditor.AppWindow()->EditorCtl()),
              x, y, 50, 22, "Label");
            break;
          case controlTextEdit:
            ctl = new ATextEdit(*(dxeditor.AppWindow()->EditorCtl()),
              x, y, 50, TEXTEDIT_HEIGHT, "Text");
            break;
          default:
            break;
        }
        if(ctl)
        {
          POINT pt;
          dxeditor.Controls()->AddControl(ctl);
          dxeditor.DoneInserting();
          ::GetCursorPos(&pt);
          ::SetCursorPos(pt.x + 47, pt.y + 20);
        }
      }

      break;
    }

    default:
      break;
  }
  } catch(...) {}
  return ::DefWindowProc(hwnd, msg, wParam, lParam);
}
