#include "controls.hpp"

LRESULT APIENTRY ControlWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

// CtlWnd methods
BOOL CtlWnd::GetExtent(RECT& rc) const
{
  ::GetWindowRect(hwnd, &rc);

  POINT pt1 = { rc.left, rc.top},
        pt2 = { rc.right, rc.bottom};
  HWND	hwndParent = ::GetParent(hwnd);

  if(!hwndParent)
    return FALSE;

  ::ScreenToClient(hwndParent, &pt1);
  ::ScreenToClient(hwndParent, &pt2);
  rc.left   = pt1.x;
  rc.top    = pt1.y;
  rc.right  = pt2.x;
  rc.bottom = pt2.y;

  return TRUE;
}

int CtlWnd::Left() const
{
  RECT rc;
  if(!GetExtent(rc))
    return 0;

  return rc.left;
}

int CtlWnd::Top() const
{
  RECT rc;
  if(!GetExtent(rc))
    return 0;

  return rc.top;
}

DWORD CtlWnd::Width() const
{
  RECT rc;
  if(!GetExtent(rc))
    return 0;

  return rc.right - rc.left;
}

DWORD CtlWnd::Height() const
{
  RECT rc;
  if(!GetExtent(rc))
    return 0;

  return rc.bottom - rc.top;
}

// AControl methods
AControl::AControl(HWND hwndParent, 
                   int _left, int _top, DWORD _width, DWORD _height, 
		   const char* _text)
  : CtlWnd(NULL), text(NULL), left(_left), top(_top), width(_width), height(_height)
{
  if(_text)
  {
    text = new char[lstrlen(_text) + 1];
    lstrcpy(text, _text);
  }
  else
    text = NULL;

  if(hwndParent)
  {
    hwnd = ::CreateWindowEx(0, "ControlWndClass", text, WS_CHILD | WS_VISIBLE,
      left, top, width, height, hwndParent, HMENU(NextID()), hInst, this);
  }
}

const char* AControl::GetText() const
{
  return text;
}

BOOL AControl::GetExtent(RECT& rc) const
{
  if(hwnd)
    return CtlWnd::GetExtent(rc);

  rc.left   = left;
  rc.top    = top;
  rc.right  = left + width - 1;
  rc.bottom = top + height - 1;
  return TRUE;
}

BOOL AControl::SetExtent(int _left, int _top, DWORD _width, DWORD _height)
{
  left	  = _left;
  top	  = _top;
  width	  = _width;
  height  = _height;

  if(hwnd)
    return CtlWnd::SetExtent(left, top, width, height);
  return TRUE;
}

BOOL AControl::MoveTo(int _left, int _top)
{
  left = _left;
  top = _top;
  if(hwnd)
    return CtlWnd::MoveTo(_left, _top);
  return TRUE;
}

BOOL AControl::SizeTo(DWORD _width, DWORD _height)
{
  width = _width;
  height = _height;
  if(hwnd)
    return CtlWnd::SizeTo(width, height);
  return TRUE;
}

BOOL AControl::SetText(const char* _text)
{
  char* tmp = new char[lstrlen(_text) + 1];
  if(!tmp)
    return FALSE;

  delete text;
  text = tmp;
  lstrcpy(text, _text);
  Update();
  return TRUE;
}

BOOL AControl::SetPropByName(const char* propName, void* propValue)
{
  if(!lstrcmpi(propName, "left"))
    left = abs(atoi((const char*)propValue));
  else if(!lstrcmpi(propName, "top"))
    top = abs(atoi((const char*)propValue));
  else if(!lstrcmpi(propName, "width"))
    width = abs(atoi((const char*)propValue));
  else if(!lstrcmpi(propName, "height"))
    height = abs(atoi((const char*)propValue));
  else if(!lstrcmpi(propName, "text"))
    SetText((const char*)propValue);
  else
    return FALSE;

  ::MoveWindow(hwnd, left, top, width, height, TRUE);

  return TRUE;
}

BOOL CtlWnd::MoveTo(int _left, int _top)
{
  return ::MoveWindow(hwnd, _left, _top, Width(), Height(), TRUE);
}

BOOL CtlWnd::SizeTo(DWORD _width, DWORD _height)
{  
  return ::MoveWindow(hwnd, Left(), Top(), _width, _height, TRUE);
}

BOOL CtlWnd::SetExtent(int _left, int _top, DWORD _width, DWORD _height )
{
  return ::MoveWindow(hwnd, _left, _top, _width, _height, TRUE);
}

BOOL AControl::RegisterWindowClass()
{
  static BOOL registered = FALSE;

  if(registered)
    return TRUE;

  WNDCLASSEX  wcx;
  memset(&wcx, 0, sizeof(wcx));
  wcx.cbSize	    = sizeof(wcx);
  wcx.hbrBackground = HBRUSH(COLOR_WINDOW);
  wcx.hCursor	    = ::LoadCursor(hInst, "movecursor");
  wcx.hInstance	    = hInst;
  wcx.lpfnWndProc   = ControlWndProc;
  wcx.lpszClassName = "ControlWndClass";
  
  if(!::RegisterClassEx(&wcx))
    return FALSE;

  registered = TRUE;
  return TRUE;
}

void AControl::DrawGrabbers(HDC hdc)
{
    RECT rc;
    ::GetClientRect(hwnd, &rc);

    RECT rc1 = rc;
    HBRUSH  hbrush = ::CreateSolidBrush(RGB(0, 0, 0));

    ::SelectObject(hdc, ::GetStockObject(NULL_BRUSH));
    ::Rectangle(hdc, rc.left, rc.top, rc.right, rc.bottom);

    rc1.right = rc.left + 6;
    rc1.bottom = rc.top + 6;
    ::FillRect(hdc, &rc1, hbrush);

    rc1.top = rc.bottom / 2 - 3;
    rc1.bottom = rc1.top + 6;
    ::FillRect(hdc, &rc1, hbrush);

    rc1.bottom = rc.bottom;
    rc1.top = rc1.bottom - 6;
    ::FillRect(hdc, &rc1, hbrush);

    rc1.left = rc.right / 2 - 3;
    rc1.right = rc1.left + 6;
    ::FillRect(hdc, &rc1, hbrush);

    rc1.right = rc.right;
    rc1.left = rc1.right - 6;
    ::FillRect(hdc, &rc1, hbrush);

    rc1.top = rc.bottom / 2 - 3;
    rc1.bottom = rc1.top + 6;
    ::FillRect(hdc, &rc1, hbrush);

    rc1.top = rc.top;
    rc1.bottom = rc1.top + 6;
    ::FillRect(hdc, &rc1, hbrush);

    rc1.left = rc.right / 2 - 3;
    rc1.right = rc1.left + 6;
    ::FillRect(hdc, &rc1, hbrush);

    ::DeleteObject(hbrush);
}

LRESULT AControl::OnMove(int x, int y)
{
  MoveTo(x, y);
  return TRUE;
}

LRESULT AControl::OnNCHitTest(int x, int y)
{
  if(y < 7) // Top side
  {
    if(x < 7)
      return HTTOPLEFT;
    else if(x > (int)Width() - 6)
      return HTTOPRIGHT;
    else if(x > int(Width() / 2 - 3) && x < int(Width() / 2 + 3))
      return HTTOP;
  }
  else if(y > (int)Height() - 6) // Bottom side
  {
    if(x < 7)
      return HTBOTTOMLEFT;
    else if(x > (int)Width() - 6)
      return HTBOTTOMRIGHT;
    else if(x > int(Width() / 2 - 3) && x < int(Width() / 2 + 3))
      return HTBOTTOM;
  }
  else if(x < 7 && y > int(Height() / 2 - 3) && y < int(Height() /2 + 3))
    return HTLEFT;
  else if(x > (int)Width() - 6 && y > int(Height() / 2 - 3) && y < int(Height() /2 + 3))
    return HTRIGHT;
  return HTCLIENT;
}

DWORD AControl::NextID()
{
  static DWORD next_id = 0;
  return ++next_id;
}

// Derived controls
BOOL ALabel::hilited = FALSE;
ALabel::ALabel(HWND hwndParent, int left, int top, DWORD width, DWORD height, 
		   const char* _text) : AControl(hwndParent, left, top, width, height, _text)
{
}

void ALabel::PaintControl(HDC hdc, BOOL focused)
{
  RECT	rc;
  static HBRUSH hbrush = ::CreateSolidBrush(RGB(250, 250, 220));

  ::GetClientRect(hwnd, &rc);

  if(hilited)
    ::FillRect(hdc, &rc, hbrush);
  ::SetBkMode(hdc, TRANSPARENT);
  ::DrawText(hdc, GetText(), lstrlen(GetText()), &rc,
    DT_LEFT | DT_WORDBREAK);

  if(focused)
    DrawGrabbers(hdc);
}

char* ALabel::GetHTMLString(char* s)
{
  try
  {
    wsprintf(s, "<div style='width:%d; height:%d'>%s</div>",
      Width(), Height(), GetText());
  }
  catch(...)
  {
    return NULL;
  }
  return s;
}


AButton::AButton(HWND hwndParent, int left, int top, DWORD width, DWORD height, 
		   const char* _text) : AControl(hwndParent, left, top, width, height, _text)
{
}

void AButton::PaintControl(HDC hdc, BOOL focused)
{
  RECT	rc;

  ::GetClientRect(hwnd, &rc);
  ::DrawEdge(hdc, &rc, EDGE_RAISED, BF_RECT);

  ::SetBkMode(hdc, TRANSPARENT);
  ::DrawText(hdc, GetCaption(), lstrlen(GetCaption()), &rc,
    DT_CENTER | DT_VCENTER | DT_SINGLELINE);

  if(focused)
    DrawGrabbers(hdc);
}

BOOL AButton::SetPropByName(const char* propName, void* propValue)
{
  if(!lstrcmpi(propName, "caption"))
  {
    SetText((const char*)propValue);
    return TRUE;
  }

  return AControl::SetPropByName(propName, propValue);
}

char* AButton::GetHTMLString(char* s)
{
  try
  {
    wsprintf(s, "<input type=button width=%d height=%d "
      "style='width:%d; height:%d' value='%s'>", 
      Width(), Height(), Width(), Height(), GetCaption());
  }
  catch(...)
  {
    return NULL;
  }
  return s;
}

ATextEdit::ATextEdit(HWND hwndParent, int left, int top, DWORD width, DWORD height, 
		   const char* _text) : AControl(hwndParent, left, top, 
                                                 width, TEXTEDIT_HEIGHT, _text)
{
}

BOOL ATextEdit::SizeTo(DWORD _width, DWORD _height)
{
  width = _width;
  height = TEXTEDIT_HEIGHT;
  if(hwnd)
    return CtlWnd::SizeTo(width, TEXTEDIT_HEIGHT);
  return TRUE;
}

BOOL ATextEdit::SetExtent(int _left, int _top, DWORD _width, DWORD)
{
  left	  = _left;
  top	  = _top;
  width	  = _width;
  height  = TEXTEDIT_HEIGHT;

  if(hwnd)
    return CtlWnd::SetExtent(left, top, width, TEXTEDIT_HEIGHT);
  return TRUE;
}

BOOL ATextEdit::SetPropByName(const char* propName, void* propValue)
{
  if(lstrcmpi(propName, "height"))
    return AControl::SetPropByName(propName, propValue);
  else
    height = TEXTEDIT_HEIGHT;
  return TRUE;
}


void ATextEdit::PaintControl(HDC hdc, BOOL focused)
{
  RECT	rc;

  ::GetClientRect(hwnd, &rc);
  ::FillRect(hdc, &rc, (HBRUSH)::GetStockObject(WHITE_BRUSH));
  ::DrawEdge(hdc, &rc, EDGE_SUNKEN, BF_RECT);
  rc.top += 3;
  rc.bottom -= 3;
  rc.left += 3;
  rc.right -= 3;

  ::SetBkMode(hdc, TRANSPARENT);
  ::DrawText(hdc, GetText(), lstrlen(GetText()), &rc,
    DT_LEFT);

  if(focused)
    DrawGrabbers(hdc);
}

char* ATextEdit::GetHTMLString(char* s)
{
  try
  {
    wsprintf(s, "<input type=text size=%d width=%d "
      "style='width:%d' value='%s'>", int(Width() / 9),
      Width(), Width(), GetText());
  }
  catch(...)
  {
    return NULL;
  }
  return s;
}

