#ifndef _TEXTFILE_HPP_
#define _TEXTFILE_HPP_
#include <windows.h>
#include <stdio.h>

#define TEXTBUFSIZE   16384

enum TextFileOpenMode
{
  textfileRead,
  textfileWrite,
  textfileAppend
};

class TextFile
{
    FILE*   file;  // Handle to open file
    char    fname[MAX_PATH];  // Filename to operate

  public:
    TextFile(const char* filename = NULL);
    ~TextFile();

    BOOL  Open(const char* filename, const char* openFor);
    BOOL  Close();
    BOOL  Flush() { return fflush(file);}

    BOOL  ReadLine(char* buf, DWORD bufsize);
    BOOL  WriteLine(const char* buf);
};

class LogFile : public TextFile
{
  public:
    LogFile(const char* lfname) : TextFile(lfname) {}

    void Log(const char* text) 
    {
      if(!Open(NULL, "a"))
        return;
      WriteLine(text);
      WriteLine("\n");
      Close();
    }

    void LogValue(const char* text)
    {
      if(!Open(NULL, "a"))
        return;
      WriteLine("\t");
      WriteLine(text);
      WriteLine("\n");
      Close();
    }
};














#endif // _TEXTFILE_HPP_