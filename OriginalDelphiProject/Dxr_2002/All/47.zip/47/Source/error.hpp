#ifndef _ERROR_HPP_
#define _ERROR_HPP_
#include <windows.h>
// ---------------------------------------------------------------------------
//                    Error object definition
// ---------------------------------------------------------------------------

class Error
{
    int	    code;
    BOOL    system;
    char*   descript;
    char*   source;
    char*   helpFile;
    int	    helpContext;
  
  protected:
    virtual BOOL  CopyStrings(const char* _description,
			const char* _source,
			const char* _helpFile);
    virtual int	  DisplaySystemError(UINT flags = MB_OK);

  public:
    Error();
    Error(int _code, 
	  const char* _description,
	  const char* _source	    = NULL,
	  const char* _helpFile	    = NULL,
	  int	      _helpContext  = 0);
    virtual ~Error();
    
    virtual const Error& operator = (const Error& e);

    static  BOOL  Raise(int	    _code, 
			const char* _description,
			const char* _source	  = NULL,
			const char* _helpFile	  = NULL,
			int	    _helpContext  = 0);

    virtual BOOL  SetErrorInfo(int  _code,
                        const char* _description, 
                        const char* _source	  = NULL,
	                const char* _helpFile	  = NULL,
			int	    _helpContext  = 0);

    virtual int   GetSystemError();
    virtual BOOL  LoadSystemErrorInfo();
    virtual int	  Display(UINT flags = MB_OK);
    virtual void  Clear();

    int		  Code() const	      { return code;}
    const char*	  Description() const { return descript;}
    const char*	  Source() const      { return source;}
    const char*	  HelpFile() const    { return helpFile;}
    int		  HelpContext() const { return helpContext;}
};

extern Error Err;

#endif // _ERROR_HPP_