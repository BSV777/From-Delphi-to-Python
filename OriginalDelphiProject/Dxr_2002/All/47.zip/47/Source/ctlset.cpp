#include "ctlset.hpp"


ControlSet::ControlSet() : controls(NULL), count(0), maxcount(1000)
{
  controls = new LPAControl[maxcount];
  if(!controls)
    maxcount = 0;
}

ControlSet::~ControlSet()
{
}

BOOL ControlSet::ReallocMem()
{
  AControl**  tmp = new LPAControl[maxcount + 100];
  if(!tmp)
    return FALSE;

  memcpy(tmp, controls, count * sizeof(LPAControl));
  delete (void*)controls;
  controls = tmp;
  maxcount += 100;
  return TRUE;
}

BOOL ControlSet::AddControl(AControl* ctl)
{
  if(!PositionValid(ctl))
    if(!MakeValidPosition(ctl))
      return FALSE;

  if(count == maxcount)
    if(!ReallocMem())
      return FALSE;

  for(DWORD i = 0; i < count; i++)
  {
    if(ctl->Top() < controls[i]->Top())
      break;
    else if(ctl->Top() == controls[i]->Top())
    {
      if(ctl->Left() < controls[i]->Left())
        break;
    }
  }

  if(count)
    memcpy(controls + i + 1, controls + i, (count - i) * sizeof(LPAControl));
  count++;
  controls[i] = ctl;
  return TRUE;
}

BOOL ControlSet::RemoveControl(AControl* ctl)
{
  for(DWORD i = 0; i < count; i++)
  {
    if(controls[i] == ctl)
    {
      memmove(controls + i, controls + i + 1, (count - i - 1) * sizeof(void*));
      count--;
      return TRUE;
    }
  }
  return FALSE;
}

void ControlSet::Clear()
{
  for(DWORD i = 0; i < count; i++)
    delete controls[i];
  count = 0;
}
AControl* ControlSet::ControlByIndex(DWORD index)
{
  if(index < count)
    return controls[index];

  return NULL;
}

BOOL ControlSet::MakeValidPosition(AControl* ctl)
{
  RECT rc1;
  RECT rc2;
  RECT rc3;
  RECT rcArea;
  AControl* iCtl = NULL;

  for(DWORD i = 0; i < count; i++)
  {
    iCtl = controls[i];
    iCtl->GetExtent(rc1);
    ctl->GetExtent(rc2);
    if(::IntersectRect(&rc3, &rc1, &rc2))
    {
      // Looking for space at the right of intersecting control
      rcArea.left   = iCtl->Left() + iCtl->Width();
      rcArea.top    = iCtl->Top() - ctl->Height();
      rcArea.right  = rcArea.left + ctl->Width() - 1;
      rcArea.bottom = iCtl->Top() + ctl->Height() + iCtl->Height() - 1;

      // Anyone is in there?
      AControl* jCtl = NULL;
      for(DWORD j = 0; j < count; j++)
      {
        jCtl = controls[j];
        jCtl->GetExtent(rc1);
        if(::IntersectRect(&rc3, &rc1, &rcArea))
        {
          rc1.left = 0;
          rc1.right = MAX_PAGEWIDTH;
          if(rc1.top < iCtl->Top())
            rc1.top = 0;
          if((DWORD)rc1.bottom > iCtl->Top() + iCtl->Height() - 1)
            rc1.bottom += 1000; // Big enough

          if(::SubtractRect(&rcArea, &rcArea, &rc1))
            if(ctl->Height() > DWORD(rcArea.bottom - rcArea.top + 1))
              break; // It became too small to fit the control
        }
      }
      if(ctl->Width() <= DWORD(rcArea.right - rcArea.left + 1) &&
         ctl->Height() <= DWORD(rcArea.bottom - rcArea.top + 1))
      {
        ctl->MoveTo(rcArea.left, rcArea.top);
        return TRUE;
      }

      // Looking for space at the bottom of intersecting control
      rcArea.left   = iCtl->Left() - iCtl->Width();
      rcArea.top    = iCtl->Top();
      rcArea.right  = iCtl->Left() + ctl->Width() + iCtl->Width() - 1;
      rcArea.bottom = rcArea.top + ctl->Height() - 1;

      // Anyone is in there?
      for(j = 0; j < count; j++)
      {
        jCtl = controls[j];
        jCtl->GetExtent(rc1);
        if(::IntersectRect(&rc3, &rc1, &rcArea))
        {
          rc1.top = 0;
          rc1.bottom += 1000;  // Big enough
          if(rc1.left < iCtl->Left())
            rc1.left = 0;
          if((DWORD)rc1.right > iCtl->Left() + iCtl->Width() - 1)
            rc1.right = MAX_PAGEWIDTH; 

          if(::SubtractRect(&rcArea, &rcArea, &rc1))
            if(ctl->Width() > DWORD(rcArea.right - rcArea.left + 1))
              break; // It became too small to fit the control
        }
      }
      if(ctl->Width() <= DWORD(rcArea.right - rcArea.left + 1) &&
         ctl->Height() <= DWORD(rcArea.bottom - rcArea.top + 1))
      {
        ctl->MoveTo(rcArea.left, rcArea.top);
        return TRUE;
      }

    }
  }
  return FALSE;
}

BOOL ControlSet::PositionValid(AControl* ctl)
{
  RECT rc1;
  RECT rc2;
  RECT rc3;

  for(DWORD i = 0; i < count; i++)
  {
    controls[i]->GetExtent(rc1);
    ctl->GetExtent(rc2);
    if(::IntersectRect(&rc3, &rc1, &rc2))
      return FALSE;
  }
  return TRUE;
}