//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dxres.rc
//
#define IDB_TBBITMAP                    103
#define IDM_FILE_EXIT                   40001
#define IDM_FILE_NEW                    40002
#define IDM_FILE_OPEN                   40003
#define IDM_FILE_SAVE                   40004
#define IDM_FILE_SAVEAS                 40005
#define IDM_FILE_EXPORT                 40006
#define IDM_EDIT_CUT                    40008
#define IDM_EDIT_COPY                   40009
#define IDM_EDIT_PASTE                  40010
#define IDM_EDIT_SELECTALL              40011
#define IDM_VIEW_BROWSER                40012
#define ID_VIEW_PROPERTIES              40013
#define IDM_VIEW_PROPERTIES             40013
#define IDM_HELP_ABOUT                  40014
#define IDM_VIEW_HILITELABELS           40015
#define IDM_INSERT_BUTTON               40016
#define IDM_INSERT_LABEL                40017
#define IDM_INSERT_TEXT                 40018
#define IDM_EDIT_DEL                    40019
#define IDM_HELP_CONTENTS               40020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40022
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
