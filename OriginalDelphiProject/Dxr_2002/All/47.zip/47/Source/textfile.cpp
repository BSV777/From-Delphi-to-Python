#include "textfile.hpp"

TextFile::TextFile(const char* filename /* = NULL */) : file(NULL)
{
  if(filename)
    lstrcpyn(fname, filename, MAX_PATH);
  else
    fname[0] = '\0';
}

TextFile::~TextFile()
{
  Close();
}

BOOL TextFile::Open(const char* filename, const char* openFor)
{
  if(filename)
    if(filename[0])
    {
      if(file)
        fclose(file);
      lstrcpyn(fname, filename, MAX_PATH);
    }

  file = fopen(fname, openFor);

  return BOOL(file);
}

BOOL TextFile::Close()
{
  if(file)
    fclose(file);
  file = NULL;
  return TRUE;
}

BOOL TextFile::ReadLine(char* buf, DWORD bufsize)
{
  return (BOOL)fgets(buf, bufsize, file);
}

BOOL TextFile::WriteLine(const char* buf)
{
  return (fputs(buf, file) >= 0);
}

