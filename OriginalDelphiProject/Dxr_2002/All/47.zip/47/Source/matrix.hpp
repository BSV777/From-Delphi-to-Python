#ifndef _MATRIX_HPP_
#define _MATRIX_HPP_

#include <windows.h>

template <class T>
class TArray
{
    T*	  data;
    DWORD count;

  public:
    TArray() : data(NULL), count(0)
    {
    }

    TArray(DWORD size, BOOL zeroIt) : data(NULL), count(0)
    {
      Allocate(size, zeroIt);
    }

    virtual ~TArray()
    {
      delete data;
    }

    int Count()
    {
      return count;
    }

    BOOL Allocate(DWORD size, BOOL zeroIt)
    {
      data = new T[size];
      if(data)
      {
	count = size;
	if(zeroIt)
	  memset(data, 0, sizeof(T) * size);
	return TRUE;
      }
      return FALSE;
    }

    BOOL ShiftIn(DWORD index)
    {
      return (BOOL)memcpy(data + index, data + index + 1, (count - index - 1) * sizeof(void*));
    }

    BOOL ShiftOut(DWORD index)
    {
      return (BOOL)memcpy(data + index + 1, data + index, (count - index - 1) * sizeof(void*));
    }

    T&	operator [](DWORD index)
    {
      static T t = 0;
      if(index < count)
	return data[index];

      t = 0;
      return t;
    }

    T	Item(DWORD index)
    {
      return operator=(index);
    }

    DWORD Size()
    {
      return count;
    }
};

template <class T>
class TMatrix
{
    TArray <T> * data;
    DWORD	rows;

  public:
    TMatrix(DWORD _rows, DWORD _cols) : data(NULL), rows(0)
    {
      data = new TArray<T>[_rows];
      if(data)
      {
	TArray<T> *arr = data;

	rows = _rows;
	for(DWORD i = 0; i < _rows; i++)
	  (*arr++).Allocate(_cols, TRUE);
      }
    }

    virtual ~TMatrix()
    {
      delete [] data;
    }

    TArray<T>& operator [] (DWORD _row)
    {
      TArray<T> t;
      if(_row < rows)
      {
	return data[_row];
      }
      throw -1;
      //return t;
    }

    int Rows() { return rows;}
    int Cols() { return data->Count();}
};





















#endif // _MATRIX_HPP_