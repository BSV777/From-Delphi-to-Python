#include "dxeditor.hpp"
#include "resource.h"
#include <commctrl.h>

#define IDT_TOOLBAR	4090
#define IDS_STATUSBAR	4091
#define IDC_CONTROLBAR	4092
#define IDC_PROPBROWSER	4093
#define IDC_EDITOR	4094

LRESULT APIENTRY ControlbarWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT APIENTRY PropBrowserWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT APIENTRY EditorWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

// _____________________________ Toolbar __________________________________________
// Toolbar buttons
TBBUTTON tbButtons[] = 
{
  { 0, IDM_FILE_NEW,  TBSTATE_ENABLED, TBSTYLE_BUTTON, 0L, 0},
  { 1, IDM_FILE_OPEN, TBSTATE_ENABLED, TBSTYLE_BUTTON, 0L, 0},
  { 2, IDM_FILE_SAVE, TBSTATE_ENABLED, TBSTYLE_BUTTON, 0L, 0},
  { 0, 0, TBSTATE_ENABLED, TBSTYLE_SEP, 0L, 0},
  { 3, IDM_EDIT_CUT,   TBSTATE_ENABLED, TBSTYLE_BUTTON, 0L, 0},
  { 4, IDM_EDIT_COPY,  TBSTATE_ENABLED, TBSTYLE_BUTTON, 0L, 0},
  { 5, IDM_EDIT_PASTE, TBSTATE_ENABLED, TBSTYLE_BUTTON, 0L, 0},
  { 0, 0, TBSTATE_ENABLED, TBSTYLE_SEP, 0L, 0},
  { 7, IDM_EDIT_DEL, TBSTATE_ENABLED, TBSTYLE_BUTTON, 0L, 0},
  { 0, 0, TBSTATE_ENABLED, TBSTYLE_SEP, 0L, 0},
  { 6, IDM_VIEW_BROWSER, TBSTATE_ENABLED, TBSTYLE_BUTTON, 0L, 0}
};


Toolbar::Toolbar(HWND hwndParent) : ToolWindow(NULL)
{
  hwnd = CreateToolbarEx(hwndParent, WS_CHILD | WS_VISIBLE | 
    TBSTYLE_TOOLTIPS/* | TBSTYLE_FLAT*/, IDT_TOOLBAR, 8, hInst,                  
    IDB_TBBITMAP, (LPCTBBUTTON)&tbButtons, 11, 16,16, 16,16, sizeof(TBBUTTON));
  if(!hwnd)
    ::MessageBox(hwndParent, "Failed to create a toolbar. Continuing...", "DXEditor", 
                 MB_OK | MB_ICONEXCLAMATION);
}

// _____________________________ Statusbar __________________________________________
Statusbar::Statusbar(HWND hwndParent) : ToolWindow(NULL)
{
  hwnd = CreateWindowEx(0L, STATUSCLASSNAME, "", WS_CHILD | 
    WS_VISIBLE | SBARS_SIZEGRIP, 0, 0, 0, 0, hwndParent,
    (HMENU)IDS_STATUSBAR, hInst, NULL);       
  if(!hwnd)
    ::MessageBox(hwndParent, "Failed to create a statusbar. Continuing...", "DXEditor", 
                 MB_OK | MB_ICONEXCLAMATION);

  int ptWidth[] = {100, 100, 50, 50};  
  SendMessage(hwnd, SB_SETPARTS, 4, (LPARAM)ptWidth);
}

// _____________________________ Control bar __________________________________________
Controlbar::Controlbar(HWND hwndParent) : ToolWindow(NULL)
{
  if(!RegisterClass())
    return;

  hwnd = ::CreateWindowEx(WS_EX_TOOLWINDOW | WS_EX_CLIENTEDGE, "ControlbarClass", " Controls",
    WS_CHILD | WS_CAPTION | WS_VISIBLE, -2, 30, 200, 300, hwndParent, 
    HMENU(IDC_CONTROLBAR), hInst, LPVOID(this));
  ::SetProp(hwnd, "state", HANDLE(-1));

  static CTLBARBUTTON  buttons[3] = 
  {{::LoadIcon(hInst, "ctlbutton"), "Button", IDB_CTL_BUTTON},
  {::LoadIcon(hInst, "ctllabel"), "Label", IDB_CTL_LABEL},
  {::LoadIcon(hInst, "ctltextedit"), "Text", IDB_CTL_TEXT}
  }; 

  butts.buttons  = buttons;
  butts.count    = sizeof(buttons) / sizeof(buttons[0]);
}
 
BOOL Controlbar::RegisterClass()
{
  static BOOL registered = FALSE;

  if(registered)
    return TRUE;

  WNDCLASSEX wcx;
  memset(&wcx, 0, sizeof(wcx));
  wcx.cbSize	      = sizeof(wcx);
  wcx.hbrBackground   = HBRUSH(COLOR_WINDOW);
  wcx.hCursor	      = ::LoadCursor(NULL, IDC_ARROW);
  wcx.hInstance	      = hInst;
  wcx.lpfnWndProc     = ControlbarWndProc;
  wcx.lpszClassName   = "ControlbarClass";

  if(!::RegisterClassEx(&wcx))
    return FALSE;

  registered = TRUE;
  return TRUE;
}

LRESULT Controlbar::OnPaint(HDC hdc)
{
  RECT  rc;
  HFONT hfont = ::CreateFont(16, 0, 0, 0, FW_NORMAL, 
    FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
    CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH,
    "MS Sans Serif");
  HFONT holdfont = HFONT(::SelectObject(hdc, hfont));

  ::SetBkMode(hdc, TRANSPARENT);
  ::GetClientRect(hwnd, &rc);
  rc.left   += 4;
  rc.right  -= 4;

  for(DWORD i = 0; i < butts.count; i++)
  {
    ::DrawIcon(hdc, 10, i * 24 + 7, butts.buttons[i].hIcon);
    ::TextOut(hdc, 32, i * 24 + 6, butts.buttons[i].text, 
      lstrlen(butts.buttons[i].text));

    rc.top    = i * 24 + 4;
    rc.bottom = rc.top + 22;

    ::DrawEdge(hdc, &rc, DWORD(::GetProp(hwnd, "state")) < 0 || DWORD(::GetProp(hwnd, "state")) != i ? 
               BDR_RAISEDINNER : BDR_SUNKENOUTER, BF_RECT);
  }
   
  ::SelectObject(hdc, holdfont);
  ::DeleteObject(hfont);

  return 0;
}

HWND PropBrowser::hwndEdits[5] = {NULL, NULL, NULL, NULL, NULL};

PropBrowser::PropBrowser(HWND hwndParent) : ToolWindow(NULL)
{
  if(!RegisterClass())
    return;

  hwnd = ::CreateWindowEx(WS_EX_TOOLWINDOW | WS_EX_CLIENTEDGE, "PropBrowserClass",
    " Properties", WS_CHILD | WS_CAPTION | WS_VISIBLE | WS_CLIPCHILDREN,
    -2, 300, 200, 300, 
    hwndParent, HMENU(IDC_PROPBROWSER), hInst, LPVOID(this));
}

BOOL PropBrowser::RegisterClass()
{
  static BOOL registered = FALSE;

  if(registered)
    return TRUE;

  WNDCLASSEX wcx;
  memset(&wcx, 0, sizeof(wcx));
  wcx.cbSize	      = sizeof(wcx);
  wcx.hbrBackground   = HBRUSH(COLOR_WINDOW + 1);
  wcx.hCursor	      = ::LoadCursor(NULL, IDC_ARROW);
  wcx.hInstance	      = hInst;
  wcx.lpfnWndProc     = PropBrowserWndProc;
  wcx.lpszClassName   = "PropBrowserClass";

  if(!::RegisterClassEx(&wcx))
    return FALSE;

  registered = TRUE;
  return TRUE;
}

void PropBrowser::SetProps(DWORD left, DWORD top, DWORD width, DWORD height, const char* text)
{
}

void PropBrowser::GetProps(DWORD* left, DWORD* top, DWORD* width, DWORD* height, char* text)
{
}

void PropBrowser::OnCreate(HWND _hwnd)
{
  RECT rc;
  ::GetClientRect(_hwnd, &rc);

  HFONT hfont = ::CreateFont(15, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
    DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
    DEFAULT_PITCH, "MS Sans Serif");
  ::SetProp(_hwnd, "hfont", HANDLE(hfont));

  for(int i = 0; i < 5; i++)
  {
    hwndEdits[i] = ::CreateWindowEx(0, "edit", "text", WS_CHILD | WS_VISIBLE |
      ES_AUTOHSCROLL, rc.right / 2, i * 16, rc.right / 2, 15, _hwnd, 
      HMENU(2000 + i), hInst, NULL);
    ::SendMessage(hwndEdits[i], WM_SETFONT, WPARAM(hfont), MAKELPARAM(1, 0));
  }
}

LRESULT PropBrowser::OnPaint(HDC hdc)
{
  RECT  rc;
  POINT pt;
  HPEN  hpen = ::CreatePen(PS_SOLID, 1, RGB(164, 164, 164)), holdpen;
  HFONT hfont = HFONT(::GetProp(hwnd, "hfont"));
  HFONT holdfont = HFONT(::SelectObject(hdc, hfont));

  ::GetClientRect(hwnd, &rc);
  holdpen = HPEN(::SelectObject(hdc, hpen));
  ::SetBkMode(hdc, TRANSPARENT);

  RECT  rc1;
  char *propNames[] = {"Left", "Top", "Width", "Height", "Text", "Caption"};
  int   ind;

  LPAControl  ctl = LPAControl(::GetProp(dxeditor.FocusedControl(), "ObjPtr"));
  DWORD       ctlType = 0; 
  char text[4][16] = {"", "", "", ""};

  if(ctl)
  {
    wsprintf(text[0], "%d", ctl->Left());
    wsprintf(text[1], "%d", ctl->Top());
    wsprintf(text[2], "%d", ctl->Width());
    wsprintf(text[3], "%d", ctl->Height());

    ctlType = ctl->ControlType();
  }
  ::SetWindowText(hwndEdits[0], text[0]);
  ::SetWindowText(hwndEdits[1], text[1]);
  ::SetWindowText(hwndEdits[2], text[2]);
  ::SetWindowText(hwndEdits[3], text[3]);
  ::SetWindowText(hwndEdits[4], ctl ?  ctl->GetText() : "");

  for(int i = 0; i < rc.bottom; i += 16)
  {
    ind = i / 16;

    if(ind < 5)
    {

      if(ctl)
      {
        if(ctlType == controlButton && ind == 4)
          ind++;

        ::SetRect(&rc1, 2, i + 2, rc.right / 2 - 2, i + 15);
        ::DrawText(hdc, propNames[ind], lstrlen(propNames[ind]), &rc1, DT_LEFT);
      }
    }

    ::MoveToEx(hdc, 0, i, &pt);
    ::LineTo(hdc, rc.right, i);
  }
  ::MoveToEx(hdc, rc.right / 2 - 3, 0, &pt);
  ::LineTo(hdc, rc.right / 2 - 3, rc.bottom);

  ::SelectObject(hdc, holdfont);
  ::SelectObject(hdc, holdpen);
  return 0;
}

// _____________________________ Control bar __________________________________________
EditorWindow::EditorWindow(HWND hwndParent) : ToolWindow(NULL),
                           page_width(0), page_height(0)
{
  if(!RegisterClass())
    return;

  hwnd = ::CreateWindowEx(WS_EX_CLIENTEDGE, "EditorClass", NULL,
    WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL, 150, 300, 200, 300, hwndParent, 
    HMENU(IDC_EDITOR), hInst, LPVOID(this));
}

BOOL EditorWindow::RegisterClass()
{
  static BOOL registered = FALSE;

  if(registered)
    return TRUE;

  WNDCLASSEX wcx;
  memset(&wcx, 0, sizeof(wcx));
  wcx.cbSize	      = sizeof(wcx);
  wcx.hbrBackground   = HBRUSH(COLOR_WINDOW);
  wcx.hCursor	      = ::LoadCursor(NULL, IDC_ARROW);
  wcx.hInstance	      = hInst;
  wcx.lpfnWndProc     = EditorWndProc;
  wcx.lpszClassName   = "EditorClass";

  if(!::RegisterClassEx(&wcx))
    return FALSE;

  registered = TRUE;
  return TRUE;
}

void EditorWindow::ResetPage()
{
      ::SetScrollRange(hwnd, SB_HORZ, 0, 100, TRUE);
      ::SetScrollRange(hwnd, SB_VERT, 0, 100, TRUE);// *****
      ::SetScrollPos(hwnd, SB_HORZ, 0, TRUE);
      ::SetScrollPos(hwnd, SB_VERT, 0, TRUE);
}



