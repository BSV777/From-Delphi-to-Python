// Editor.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Editor.h"

#include "MainFrm.h"
#include "ChildFrm.h"
#include "EditorDoc.h"
#include "EditorView.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditorApp

BEGIN_MESSAGE_MAP(CEditorApp, CWinApp)
	//{{AFX_MSG_MAP(CEditorApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditorApp construction

CEditorApp::CEditorApp()
{
	m_bNoInterface = FALSE;
}

CEditorApp::~CEditorApp()
{
	DestroyCursor(m_hCursor_Cross);
	DestroyCursor(m_hCursor_Move);
	DestroyCursor(m_hCursor_LR);
	DestroyCursor(m_hCursor_UD);
	DestroyCursor(m_hCursor_RT_LB);
	DestroyCursor(m_hCursor_LT_RB);
	DestroyCursor(m_hCursor_CrButton);
	DestroyCursor(m_hCursor_CrEdit);
	DestroyCursor(m_hCursor_CrLabel);
	DestroyCursor(m_hCursor_Arrow);
	DestroyCursor(m_hCursor_OverObject);
	DestroyCursor(m_hCursor_No);
}
/////////////////////////////////////////////////////////////////////////////
// The one and only CEditorApp object

CEditorApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CEditorApp initialization

BOOL CEditorApp::InitInstance()
{
	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	SetRegistryKey(_T("Local AppWizard-Generated Applications"));
	LoadStdProfileSettings();

	//��������� �������
	m_hCursor_Cross		= LoadCursor(IDC_CROSS_);
	m_hCursor_Move		= LoadCursor(IDC_MOVE);
	m_hCursor_LR		= LoadCursor(IDC_LR);
	m_hCursor_UD		= LoadCursor(IDC_UD);
	m_hCursor_RT_LB		= LoadCursor(IDC_RT_LB);
	m_hCursor_LT_RB		= LoadCursor(IDC_LT_RB);
	m_hCursor_CrButton	= LoadCursor(IDC_CR_BUTTON);
	m_hCursor_CrEdit	= LoadCursor(IDC_CR_TEXTEDIT);
	m_hCursor_CrLabel	= LoadCursor(IDC_CR_LABEL);
	m_hCursor_Arrow		= LoadCursor(IDC_ARROW_);
	m_hCursor_OverObject = LoadCursor(IDC_OVER_OBJECT);
	m_hCursor_No		= LoadCursor(IDC_NO_);
	

	CMultiDocTemplate* pDocTemplate;
	pDocTemplate = new CMultiDocTemplate(
		IDR_EDITORTYPE,
		RUNTIME_CLASS(CEditorDoc),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CEditorView));
	AddDocTemplate(pDocTemplate);

	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;

	CMyCmdLineInfo cmdInfo;
	MyParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!MyProcessShellCommand(cmdInfo))
		return FALSE;

	// The main window has been initialized, so show and update it.
	pMainFrame->ShowWindow(m_nCmdShow);
	pMainFrame->UpdateWindow();


	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CDlgAbout dialog used for App About

class CDlgAbout : public CDialog
{
public:
	CDlgAbout();

// Dialog Data
	//{{AFX_DATA(CDlgAbout)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgAbout)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CDlgAbout)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CDlgAbout::CDlgAbout() : CDialog(CDlgAbout::IDD)
{
	//{{AFX_DATA_INIT(CDlgAbout)
	//}}AFX_DATA_INIT
}

void CDlgAbout::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgAbout)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDlgAbout, CDialog)
	//{{AFX_MSG_MAP(CDlgAbout)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CEditorApp::OnAppAbout()
{
	CDlgAbout aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CEditorApp message handlers


void CEditorApp::MyParseCommandLine(CMyCmdLineInfo& rCmdLine)
{
	if(3 == __argc)
	{
		rCmdLine.m_strFileName = __targv[1];
		rCmdLine.m_str_HTML_FileName = __targv[2];
		rCmdLine.m_bDirect_To_HTML = TRUE;
	}
	else
		ParseCommandLine(rCmdLine);
}

BOOL CEditorApp::MyProcessShellCommand(CMyCmdLineInfo &rCmdLine)
{
	BOOL bResult = TRUE;

	if (rCmdLine.m_bDirect_To_HTML)
	{
		m_bNoInterface = TRUE;
		bResult = FALSE;

		CEditorDoc *pDoc = (CEditorDoc *) OpenDocumentFile(rCmdLine.m_strFileName);
		if (pDoc)
		{
			char *pFileName = rCmdLine.m_str_HTML_FileName.GetBuffer(MAX_PATH);
			
			if (pDoc->ExportToHTML(pFileName))
			{
				CString strTitle;
				strTitle.LoadString(IDS_HTML_MSG_TITLE);

				CString strMessage;
				strMessage.LoadString(IDS_HTML_EXPORT_ERROR);

				MessageBox(m_pMainWnd->m_hWnd, strMessage, strTitle, MB_ICONEXCLAMATION);
			}

			rCmdLine.m_str_HTML_FileName.ReleaseBuffer();
		}
	}
	else
	{
		if (rCmdLine.m_nShellCommand == CCommandLineInfo::FileNew)
			rCmdLine.m_nShellCommand = CCommandLineInfo::FileNothing;

		bResult = ProcessShellCommand(rCmdLine);
	}

	return bResult;
}
