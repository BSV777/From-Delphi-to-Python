// Ed_Label.cpp: implementation of the CEd_Label class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Editor.h"
#include "EditorDoc.h"
#include "Ed_Label.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


CEd_Label::CEd_Label(int x, int y, CEditorDoc *pDoc) : CEditorControl(pDoc)
{
	m_type = OBJ_LABEL;

	m_x = x; 
	m_y = y;

	if (m_pDoc->m_State != ES_LOADING && m_pDoc->m_State != ES_PASTING)
		AutoName("label_%d");
}

CEd_Label::~CEd_Label()
{

}

void CEd_Label::DrawSelf(CDC *pDC, int ox, int oy)
{
	CPen pen(PS_DOT, 1, GetSysColor(COLOR_WINDOWTEXT)), *oldpen;
	oldpen = pDC->SelectObject(&pen);

	CBrush brush, *oldbrush;
	brush.CreateSolidBrush(GetSysColor(COLOR_WINDOW));
	oldbrush = pDC->SelectObject(&brush);

	RECT rtDrawRect = m_rtViewRect;
	OffsetRect(&rtDrawRect, ox, oy);

	pDC->Rectangle(&rtDrawRect);

	CFont *oldfont;
	oldfont = (CFont *) pDC->SelectStockObject(ANSI_VAR_FONT);

	pDC->SetBkMode(TRANSPARENT);
	pDC->SetTextColor(GetSysColor(COLOR_WINDOWTEXT));

	RECT rtTxtRect = rtDrawRect;
	rtTxtRect.left += 2;
	rtTxtRect.right -= 2;

	UINT nFormat = DT_SINGLELINE;

	//��������� �������������� ������������
	if (m_pDoc->m_nLabelTextAlign & LTA_LEFT)
		nFormat |= DT_LEFT;
	else if (m_pDoc->m_nLabelTextAlign & LTA_CENTER)
		nFormat |= DT_CENTER;
	else if (m_pDoc->m_nLabelTextAlign & LTA_RIGHT)
		nFormat |= DT_RIGHT;
	else
		ASSERT(0);

	//��������� ������������ ������������
	if (m_pDoc->m_nLabelTextAlign & LTA_TOP)
		nFormat |= DT_TOP;
	else if (m_pDoc->m_nLabelTextAlign & LTA_VCENTER)
		nFormat |= DT_VCENTER;
	else if (m_pDoc->m_nLabelTextAlign & LTA_BOTTOM)
		nFormat |= DT_BOTTOM;
	else
		ASSERT(0);

	pDC->DrawText(m_caption, strlen(m_caption), &rtTxtRect, nFormat);
	
	pDC->SelectObject(oldfont);
	pDC->SelectObject(oldbrush);
	pDC->SelectObject(oldpen);

	CEditorControl::DrawSelf(pDC, ox, oy);
}

void CEd_Label::GetSaveString(char *pString)
{
	wsprintf(pString, "<Label left=\"%d\"; top=\"%d\"; width=\"%d\"; height=\"%d\"; text=\"%s\">", 
		m_x, m_y, m_width, m_height, m_caption);
}

BOOL CEd_Label::RestoreFromString(char *lpstrString)
{
	int val;

	int x, y, w, h;

	if (!ReadIntProperty(lpstrString, "left", &val))
		x = __max(val, 0);
	else
		x = 0;

	if (!ReadIntProperty(lpstrString, "top", &val))
		y = __max(val, 0);
	else
		y = 0;

	if (!ReadIntProperty(lpstrString, "width", &val))
		w = val;
	else if (!ReadIntProperty(lpstrString, "right", &val))
		w = val - x;
	else
		w = LABEL_DEFAULT_WIDTH;

	if (!ReadIntProperty(lpstrString, "height", &val))
		h = val;
	else if (!ReadIntProperty(lpstrString, "buttom", &val))
		h = val - y;
	else
		h = LABEL_DEFAULT_HEIGHT;

	if (ReadStrProperty(lpstrString, "text", m_caption))
		AutoName("label_%d");

	Move(x, y, w, h);

	return FALSE;
}

void CEd_Label::Get_HTML_Tag(char *pString)
{
	strcpy(pString, "\0");

	//�������� ������������
	if (m_pDoc->m_nLabelTextAlign & LTA_CENTER)
		strcat(pString, " align=center");
	else if (m_pDoc->m_nLabelTextAlign & LTA_RIGHT)
		strcat(pString, " align=right");
	if (m_pDoc->m_nLabelTextAlign & LTA_TOP)
		strcat(pString, " valign=top");
	else if (m_pDoc->m_nLabelTextAlign & LTA_VCENTER)
		strcat(pString, " valign=center");
	else if (m_pDoc->m_nLabelTextAlign & LTA_BOTTOM)
		strcat(pString, " valign=bottom");
	else
		ASSERT(0);

	char s[MAX_NAME + 100];
	wsprintf(s, "><span style=\"overflow:hidden;font-size:10pt;width=%d;height=%d\">%s</span>", 
		m_width, __min(15, m_height), m_caption);

	strcat(pString, s);
}
