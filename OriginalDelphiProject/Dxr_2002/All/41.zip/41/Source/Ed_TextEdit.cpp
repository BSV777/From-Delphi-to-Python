// Ed_TextEdit.cpp: implementation of the CEd_TextEdit class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Editor.h"
#include "EditorDoc.h"
#include "Ed_TextEdit.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEd_TextEdit::CEd_TextEdit(int x, int y, CEditorDoc *pDoc) : CEditorControl(pDoc)
{
	m_type = OBJ_TEXTEDIT;

	m_x = x; 
	m_y = y;

	if (m_pDoc->m_State != ES_LOADING && m_pDoc->m_State != ES_PASTING)
		AutoName("text_%d");
}

CEd_TextEdit::~CEd_TextEdit()
{

}

void CEd_TextEdit::DrawSelf(CDC *pDC, int ox, int oy)
{
	CPen pen(PS_NULL, 1, (COLORREF) 0x0), *oldpen;
	oldpen = pDC->SelectObject(&pen);

	CBrush brush, *oldbrush;
	brush.Attach(GetSysColorBrush(COLOR_WINDOW));
	oldbrush = pDC->SelectObject(&brush);

	RECT rtDrawRect = m_rtViewRect;
	OffsetRect(&rtDrawRect, ox, oy);

	pDC->Rectangle(&rtDrawRect);
	pDC->DrawEdge(&rtDrawRect, EDGE_SUNKEN, BF_RECT);

	CFont *oldfont;
	oldfont = (CFont *) pDC->SelectStockObject(ANSI_VAR_FONT);

	pDC->SetBkMode(TRANSPARENT);
	pDC->SetTextColor(GetSysColor(COLOR_WINDOWTEXT));

	RECT rtTxtRect = rtDrawRect;
	rtTxtRect.left += 3;
	rtTxtRect.right -= 3;

	pDC->DrawText(m_caption, strlen(m_caption), &rtTxtRect, 
		DT_SINGLELINE | DT_VCENTER);
	
	pDC->SelectObject(oldfont);
	pDC->SelectObject(oldbrush);
	pDC->SelectObject(oldpen);

	CEditorControl::DrawSelf(pDC, ox, oy);
}

void CEd_TextEdit::GetSaveString(char *pString)
{
	wsprintf(pString, "<TextEdit left=\"%d\"; top=\"%d\"; width=\"%d\"; text=\"%s\">", m_x, m_y, m_width, m_caption);
}

void CEd_TextEdit::Move(int x, int y, int width, int height)
{
	if (0 == height) return;

	height = height/abs(height)*TEXTEDIT_HEIGHT;
	CEditorObject::Move(x, y, width, height);
}

BOOL CEd_TextEdit::RestoreFromString(char *lpstrString)
{
	int val;

	int x, y, w;

	if (!ReadIntProperty(lpstrString, "left", &val))
		x = __max(val, 0);
	else
		x = 0;

	if (!ReadIntProperty(lpstrString, "top", &val))
		y = __max(val, 0);
	else
		y = 0;

	if (!ReadIntProperty(lpstrString, "width", &val))
		w = val;
	else if (!ReadIntProperty(lpstrString, "right", &val))
		w = val - x;
	else
		w = TEXTEDIT_DEFAULT_WIDTH;

	if (ReadStrProperty(lpstrString, "text", m_caption))
		AutoName("text_%d");

	Move(x, y, w, TEXTEDIT_HEIGHT);

	return FALSE;
}

void CEd_TextEdit::Get_HTML_Tag(char *pString)
{
	sprintf(pString, "><input type=text value=\"%s\" style=\"font-size:8pt;width:%d;height:%d\">",
		m_caption, m_width, m_height-2);
}



BOOL CEd_TextEdit::TestSize(int x, int y, int w, int h, BOOL bIgnoreSel)
{
	h  =  0 == h ? TEXTEDIT_HEIGHT : h/abs(h)*TEXTEDIT_HEIGHT;

	return CEditorControl::TestSize(x, y, w, h, bIgnoreSel);
}
