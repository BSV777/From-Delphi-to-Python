#if !defined(AFX_DLGSHORTCUTS_H__BC9E49E1_3F1D_11D6_929F_E88B7FA90335__INCLUDED_)
#define AFX_DLGSHORTCUTS_H__BC9E49E1_3F1D_11D6_929F_E88B7FA90335__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgShortcuts.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgShortcuts dialog

class CDlgShortcuts : public CDialog
{
// Construction
public:
	CDlgShortcuts(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgShortcuts)
	enum { IDD = IDD_SHORTCUTS };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgShortcuts)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgShortcuts)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGSHORTCUTS_H__BC9E49E1_3F1D_11D6_929F_E88B7FA90335__INCLUDED_)
