// EditorView.cpp : implementation of the CEditorView class
//

#include "stdafx.h"
#include "Editor.h"
#include "MainFrm.h"
#include "EditorDoc.h"
#include "EditorObject.h"
#include "EditorControl.h"
#include "EditorView.h"
#include "DlgOptions.h"
#include "DlgStatistics.h"

extern CEditorApp theApp;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditorView

IMPLEMENT_DYNCREATE(CEditorView, CView)

BEGIN_MESSAGE_MAP(CEditorView, CView)
	//{{AFX_MSG_MAP(CEditorView)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_SIZE()
	ON_WM_SETCURSOR()
	ON_EN_CHANGE(IDC_TEXT, OnChangeText)
	ON_WM_KEYDOWN()
	ON_EN_CHANGE(IDC_LEFT, OnChangeLeft)
	ON_EN_CHANGE(IDC_TOP, OnChangeTop)
	ON_EN_CHANGE(IDC_HEIGHT, OnChangeHeight)
	ON_EN_CHANGE(IDC_WIDTH, OnChangeWidth)
	ON_WM_KEYUP()
	ON_WM_RBUTTONDOWN()
	ON_COMMAND(ID_EXPORT_HTML, OnExportHtml)
	ON_COMMAND(ID_CREATE_BUTTON, OnCreateButton)
	ON_COMMAND(ID_CREATE_LABEL, OnCreateLabel)
	ON_COMMAND(ID_CREATE_TEXTEDIT, OnCreateTextedit)
	ON_COMMAND(IDM_SHOWGRID, OnShowGrid)
	ON_UPDATE_COMMAND_UI(IDM_SHOWGRID, OnUpdateShowGrid)
	ON_WM_VSCROLL()
	ON_WM_HSCROLL()
	ON_COMMAND(IDM_OPTIONS, OnOptions)
	ON_COMMAND(ID_DELETE, OnDelete)
	ON_COMMAND(ID_SELECT_NONE, OnSelectNone)
	ON_WM_CONTEXTMENU()
	ON_COMMAND(ID_SELECT_ALL, OnSelectAll)
	ON_COMMAND(ID_SELECT_INVERT, OnSelectInvert)
	ON_COMMAND(ID_EDIT_UNDO, OnEditUndo)
	ON_UPDATE_COMMAND_UI(ID_EDIT_UNDO, OnUpdateEditUndo)
	ON_COMMAND(ID_EDIT_REDO, OnEditRedo)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REDO, OnUpdateEditRedo)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopy)
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CUT, OnUpdateEditCut)
	ON_UPDATE_COMMAND_UI(ID_DELETE, OnUpdateDelete)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, OnUpdateEditPaste)
	ON_COMMAND(ID_EDIT_PASTE_EX, OnEditPasteEx)
	ON_WM_DESTROY()
	ON_COMMAND(ID_ALIGN_POS, OnAlignPos)
	ON_UPDATE_COMMAND_UI(ID_ALIGN_POS, OnUpdateAlignPos)
	ON_COMMAND(ID_ALIGN_SIZE, OnAlignSize)
	ON_UPDATE_COMMAND_UI(ID_ALIGN_SIZE, OnUpdateAlignSize)
	ON_COMMAND(ID_STATISTICS, OnStatistics)
	ON_WM_TIMER()
	ON_EN_SETFOCUS(IDC_TEXT, OnSetfocusText)
	ON_EN_KILLFOCUS(IDC_TEXT, OnKillfocusText)
	ON_EN_KILLFOCUS(IDC_LEFT, OnKillfocusLeft)
	ON_EN_SETFOCUS(IDC_LEFT, OnSetfocusLeft)
	ON_EN_KILLFOCUS(IDC_TOP, OnKillfocusTop)
	ON_EN_SETFOCUS(IDC_TOP, OnSetfocusTop)
	ON_EN_KILLFOCUS(IDC_WIDTH, OnKillfocusWidth)
	ON_EN_SETFOCUS(IDC_WIDTH, OnSetfocusWidth)
	ON_EN_KILLFOCUS(IDC_HEIGHT, OnKillfocusHeight)
	ON_EN_SETFOCUS(IDC_HEIGHT, OnSetfocusHeight)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditorView construction/destruction

CEditorView::CEditorView()
{
	m_pOldBitmap = NULL;
	m_OldDocViewState = 0xffffffff;
	
	m_bAllowMenu = TRUE;
	m_Menu.LoadMenu(IDR_VIEWMENU);

	m_bCtrlUpdateOff = FALSE;
	m_EdMode = EM_SELECT;

	m_bShift = FALSE;
	m_bControl = FALSE;

	m_nTimerId = 0;
	m_nAutoScroll_dx = 0;
	m_nAutoScroll_dx = 0;

	//�� ��������� ����� ��������
	m_bShowGrid = TRUE;

	//��������� �������� �������� �����
	m_grid_x = theApp.GetProfileInt("settings", "Grid_X", 10);
	m_grid_y = theApp.GetProfileInt("settings", "Grid_Y", 10);
}

CEditorView::~CEditorView()
{
	EnableScrollTimer(FALSE);

	m_Menu.DestroyMenu();
	m_memDC.SelectObject(m_pOldBitmap);
}

BOOL CEditorView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CEditorView drawing

void CEditorView::OnDraw(CDC* pDC)
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CPoint ptOffset = GetScrollPosition();
	int ox = ptOffset.x, oy = ptOffset.y;

	RECT rt;
	GetClientRect(&rt);

	//��������� �������� �����
	if (m_OldDocViewState != pDoc->m_ViewState)
	{
		//������� �����
		CBrush brush, *oldbrush;
		brush.CreateSysColorBrush(COLOR_WINDOW);
		oldbrush = m_memDC.SelectObject(&brush);
		m_memDC.Rectangle(rt.left-1, rt.top-2, rt.right+1, rt.bottom+1);
		m_memDC.SelectObject(oldbrush);

		//������ �����
		if(m_bShowGrid)
		{
			COLORREF gridcolor = GetSysColor(COLOR_WINDOWTEXT);
			
			for(int x = -(ox%m_grid_x); x < rt.right; x += m_grid_x)
				for(int y = -(oy%m_grid_y); y < rt.bottom; y += m_grid_y)
					m_memDC.SetPixel(x, y, gridcolor);
		}

		RECT rtFrame = rt;
		OffsetRect(&rtFrame, ox, oy);
		
		//������ ��� ������� � �����
		CEditorObject *pObject = pDoc->m_pObjectList->m_pNextObject;
		while(pObject)
		{
			RECT rtDest;
			if(IntersectRect(&rtDest, &rtFrame, &(pObject->m_rtViewRect)))
				pObject->DrawSelf(&m_memDC, -ox, -oy);

			pObject = pObject->m_pNextObject;
		}

		m_OldDocViewState = pDoc->m_ViewState;
	}

	//���������� ���������� ������ �� ������
	pDC->BitBlt(ox, oy, rt.right, rt.bottom, &m_memDC, 0, 0, SRCCOPY);
}

/////////////////////////////////////////////////////////////////////////////
// CEditorView diagnostics

#ifdef _DEBUG
void CEditorView::AssertValid() const
{
	CView::AssertValid();
}

void CEditorView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CEditorDoc* CEditorView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CEditorDoc)));
	return (CEditorDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CEditorView message handlers

void CEditorView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CPoint ptOffset = GetScrollPosition();
	point.Offset(ptOffset);
	
	CEditorControl *pObject;

	//������� �� ���� ����
	SetCapture();

	//���������, ��� ��� �����
	if (pObject = pDoc->PickObject(point))
	{	
		//���� ��� ��������.

		//���� ������ �������, �������� ��� �������\�����������
		if (pObject->m_bSelected)
		{
			//����������� ����� ������ ���� ������ ���� ������
			if(1 == pDoc->m_nSelectedObjects)
			{
				CRect rt;
				int x = pObject->m_x;
				int y = pObject->m_y;
				int w = pObject->m_width;
				int h = pObject->m_height;

				#define MW 6
				//lt
				rt.SetRect(x, y, x + MW, y + MW);
				if (rt.PtInRect(point))
					pDoc->BeginSize(pObject, CS_LT);
				else {
				//tc
				rt.SetRect(x+w/2-MW/2, y, x+w/2+MW/2, y+MW);
				if (rt.PtInRect(point))
					pDoc->BeginSize(pObject, CS_T);
				else {
				//rt
				rt.SetRect(x+w-MW, y, x+w, y+MW);
				if (rt.PtInRect(point))
					pDoc->BeginSize(pObject, CS_RT);
				else {
				//lc
				rt.SetRect(x, y+h/2-MW/2, x+MW, y+h/2+MW/2);
				if (rt.PtInRect(point))
					pDoc->BeginSize(pObject, CS_L);
				else {
				//rc
				rt.SetRect(x+w-MW, y+h/2-MW/2, x+w, y+h/2+MW/2);
				if (rt.PtInRect(point))
					pDoc->BeginSize(pObject, CS_R);
				else {
				//lb
				rt.SetRect(x, y+h-MW, x+MW, y+h);
				if (rt.PtInRect(point))
					pDoc->BeginSize(pObject, CS_LB);
				else {
				//bc
				rt.SetRect(x+w/2-MW/2, y+h-MW, x+w/2+MW/2, y+h);
				if (rt.PtInRect(point))
					pDoc->BeginSize(pObject, CS_B);
				else {
				//rb
				rt.SetRect(x+w-MW, y+h-MW, x+w, y+h);
				if (rt.PtInRect(point))
					pDoc->BeginSize(pObject, CS_RB);
				else {
					//move
					if (m_bShowGrid)
						pDoc->BeginMove(GRID_ALIGN(point.x,m_grid_x), GRID_ALIGN(point.y,m_grid_y));
					else
						pDoc->BeginMove(point.x, point.y);
				}}}}}}}}
			}
			else
			{
				if(!m_bShift && !m_bControl)
				{
					if (m_bShowGrid)
						pDoc->BeginMove(GRID_ALIGN(point.x,m_grid_x), GRID_ALIGN(point.y,m_grid_y));
					else
						pDoc->BeginMove(point.x, point.y);
				}
				else
					pDoc->DeSelectObject(pObject);
			}
		}
		else
		{
			if (EM_SELECT == m_EdMode)
			{
				if(!m_bShift && !m_bControl) pDoc->SelectObject(NULL);
				pDoc->SelectObject(pObject);
				if (m_bShowGrid)
					pDoc->BeginMove(GRID_ALIGN(point.x,m_grid_x), GRID_ALIGN(point.y,m_grid_y));
				else
					pDoc->BeginMove(point.x, point.y);
			}
			else
			{
				MessageBeep(MB_OK);
			}
		}
	}
	else
	{
		//��� ����� �����. � ����������� �� ������, ���� �������
		switch (m_EdMode)
		{
		case EM_CR_BUTTON:
			if (m_bShowGrid) 
				pDoc->BeginObject(OBJ_BUTTON, 
					GRID_ALIGN(point.x,m_grid_x), 
					GRID_ALIGN(point.y,m_grid_y));
			else
				pDoc->BeginObject(OBJ_BUTTON, point.x, point.y);
			break;
		case EM_CR_TEXTEDIT:
			if (m_bShowGrid) 
				pDoc->BeginObject(OBJ_TEXTEDIT, 
					GRID_ALIGN(point.x,m_grid_x), 
					GRID_ALIGN(point.y,m_grid_y));
			else
				pDoc->BeginObject(OBJ_TEXTEDIT, point.x, point.y);
			break;
		case EM_CR_LABEL:
			if (m_bShowGrid) 
				pDoc->BeginObject(OBJ_LABEL, 
					GRID_ALIGN(point.x,m_grid_x), 
					GRID_ALIGN(point.y,m_grid_y));
			else
				pDoc->BeginObject(OBJ_LABEL, point.x, point.y);
			break;
		case EM_SELECT:
			pDoc->BeginSelect(point.x, point.y);
			break;
		}
	}

	CView::OnLButtonDown(nFlags, point);
}

void CEditorView::OnMouseMove(UINT nFlags, CPoint point) 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CPoint ptOffset = GetScrollPosition();
	point.Offset(ptOffset);

	CString	strStatus;

	//������� � ������ ��������� ���������� ����
	strStatus.Format("X = %d", point.x);
	((CMainFrame*)(theApp.m_pMainWnd))->m_wndStatusBar.SetPaneText(
		((CMainFrame*)(theApp.m_pMainWnd))->m_wndStatusBar.CommandToIndex(ID_INDICATOR_X), strStatus);
	strStatus.Format("Y = %d", point.y);
	((CMainFrame*)(theApp.m_pMainWnd))->m_wndStatusBar.SetPaneText(
		((CMainFrame*)(theApp.m_pMainWnd))->m_wndStatusBar.CommandToIndex(ID_INDICATOR_Y), strStatus);


	if (nFlags & MK_LBUTTON)
	{
		//�������� (���� �����) �������������
		RECT rt;
		GetClientRect(&rt);
		ClientToScreen(&rt);
		POINT pt;
		GetCursorPos(&pt);
		if (pt.x <= rt.left)
			m_nAutoScroll_dx = -m_grid_x;
		else if (pt.x >= rt.right)
			m_nAutoScroll_dx = m_grid_x;
		else
			m_nAutoScroll_dx = 0;

		if (pt.y <= rt.top)
			m_nAutoScroll_dy = -m_grid_y;
		else if (pt.y >= rt.bottom)
			m_nAutoScroll_dy = m_grid_y;
		else
			m_nAutoScroll_dy = 0;

		EnableScrollTimer(!PtInRect(&rt, pt));



		switch(pDoc->m_State)
		{
		case ES_CREATE:
			switch(m_EdMode)
			{
			case EM_CR_BUTTON:
				SetCursor(theApp.m_hCursor_CrButton);
				break;
			case EM_CR_TEXTEDIT:
				SetCursor(theApp.m_hCursor_CrEdit);
				break;
			case EM_CR_LABEL:
				SetCursor(theApp.m_hCursor_CrLabel);
				break;
			default:
				ASSERT(0);
			}
			if (m_bShowGrid && !m_bControl)
				pDoc->ProcessObject(GRID_ALIGN(point.x,m_grid_x), GRID_ALIGN(point.y,m_grid_y));
			else
				pDoc->ProcessObject(point.x, point.y);
			break;
		case ES_MOVE:
			if (m_bShowGrid && !m_bControl)
				pDoc->ProcessMove(GRID_ALIGN(point.x,m_grid_x), GRID_ALIGN(point.y,m_grid_y));
			else
				pDoc->ProcessMove(point.x, point.y);
			SetCursor(theApp.m_hCursor_Move);
			break;
		case ES_SIZE:
			if (m_bShowGrid && !m_bControl)
				pDoc->ProcessSize(GRID_ALIGN(point.x,m_grid_x), GRID_ALIGN(point.y,m_grid_y));
			else
				pDoc->ProcessSize(point.x, point.y);
			SetCursor(theApp.m_hCursor_Cross);
			break;
		case ES_SELECT:
			pDoc->ProcessSelect(point.x, point.y);
			SetCursor(theApp.m_hCursor_Cross);
			break;
		default:
			break;
		}
	}
	else
	{
		CEditorControl *pObject = pDoc->PickObject(point);
		if (pObject)
		{
			if (pObject->m_bSelected)
			{
				if(1 == pDoc->m_nSelectedObjects)
				{
					CRect rt;
					int x = pObject->m_x;
					int y = pObject->m_y;
					int w = pObject->m_width;
					int h = pObject->m_height;

					#define MW 6
					//lc
					rt.SetRect(x, y+h/2-MW/2, x+MW, y+h/2+MW/2);
					if (rt.PtInRect(point))
						SetCursor(theApp.m_hCursor_LR);
					else {
					//rc
					rt.SetRect(x+w-MW, y+h/2-MW/2, x+w, y+h/2+MW/2);
					if (rt.PtInRect(point))
						SetCursor(theApp.m_hCursor_LR);
					else {
						//���� ��� TextEdit, ������ �� ���������
						if (OBJ_TEXTEDIT == pObject->m_type)
						{
							SetCursor(theApp.m_hCursor_Move);
							goto end;
						}
					//lt
					rt.SetRect(x, y, x + MW, y + MW);
					if (rt.PtInRect(point))
						SetCursor(theApp.m_hCursor_LT_RB);
					else {
					//tc
					rt.SetRect(x+w/2-MW/2, y, x+w/2+MW/2, y+MW);
					if (rt.PtInRect(point))
						SetCursor(theApp.m_hCursor_UD);
					else {
					//rt
					rt.SetRect(x+w-MW, y, x+w, y+MW);
					if (rt.PtInRect(point))
						SetCursor(theApp.m_hCursor_RT_LB);
					else {
					//lb
					rt.SetRect(x, y+h-MW, x+MW, y+h);
					if (rt.PtInRect(point))
						SetCursor(theApp.m_hCursor_RT_LB);
					else {
					//bc
					rt.SetRect(x+w/2-MW/2, y+h-MW, x+w/2+MW/2, y+h);
					if (rt.PtInRect(point))
						SetCursor(theApp.m_hCursor_UD);
					else {
					//rb
					rt.SetRect(x+w-MW, y+h-MW, x+w, y+h);
					if (rt.PtInRect(point))
						SetCursor(theApp.m_hCursor_LT_RB);
					else {
						//move
						SetCursor(theApp.m_hCursor_Move);
						((CMainFrame*)theApp.m_pMainWnd)->m_wndStatusBar.SetPaneText(0, "����������� ������");
					}}}}}}}}
				}
				else
				{
					SetCursor(theApp.m_hCursor_Move);
					((CMainFrame*)theApp.m_pMainWnd)->m_wndStatusBar.SetPaneText(0, "����������� �������");
				}
			}
			else
			{
				if (EM_SELECT == m_EdMode)
				{
					SetCursor(theApp.m_hCursor_OverObject);
					((CMainFrame*)theApp.m_pMainWnd)->m_wndStatusBar.SetPaneText(0, "������� ������");
				}
				else
				{
					strStatus.LoadString(IDS_CREATE_FAIL);
					((CMainFrame*)theApp.m_pMainWnd)->m_wndStatusBar.SetPaneText(0, strStatus);
					SetCursor(theApp.m_hCursor_No);
				}
				
			}
		}
		else
		{
			switch(m_EdMode)
			{
			case EM_SELECT:
				strStatus.LoadString(AFX_IDS_IDLEMESSAGE);
				SetCursor(theApp.m_hCursor_Arrow);
				break;
			case EM_CR_BUTTON:
				strStatus.LoadString(IDS_CREATE_BUTTON_TIP);
				SetCursor(theApp.m_hCursor_CrButton);
				break;
			case EM_CR_TEXTEDIT:
				strStatus.LoadString(IDS_CREATE_TEXTEDIT_TIP);
				SetCursor(theApp.m_hCursor_CrEdit);
				break;
			case EM_CR_LABEL:
				strStatus.LoadString(IDS_CREATE_LABEL_TIP);
				SetCursor(theApp.m_hCursor_CrLabel);
				break;
			default:
				ASSERT(0);
			}

			((CMainFrame*)theApp.m_pMainWnd)->m_wndStatusBar.SetPaneText(0, strStatus);
		}
	}

end:
	CView::OnMouseMove(nFlags, point);
}

void CEditorView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	CPoint ptOffset = GetScrollPosition();
	point.Offset(ptOffset);

	pDoc->EndObject();
	pDoc->EndSize();
	pDoc->EndSelect(m_bShift || m_bControl);

	if (m_bShowGrid)
		pDoc->EndMove(GRID_ALIGN(point.x, m_grid_x), GRID_ALIGN(point.y, m_grid_y));
	else
		pDoc->EndMove(point.x, point.y);

	//��������� ����
	ReleaseCapture();

	EnableScrollTimer(FALSE);

	CView::OnLButtonUp(nFlags, point);
}


void CEditorView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
}

void CEditorView::OnSize(UINT nType, int cx, int cy) 
{
//	CView::OnSize(nType, cx, cy);

	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	RECT rt;
	GetClientRect(&rt);
	ResizeBackBuffer(rt.right - rt.left, rt.bottom - rt.top);

	pDoc->NeedUpdate();
}

BOOL CEditorView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	if (HTCLIENT == nHitTest)
	{
		return TRUE;
	}

	return CView::OnSetCursor(pWnd, nHitTest, message);
}

void CEditorView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CEditorControl *pObject = NULL;

	if (pDoc->m_pCurrentObject)
		pObject = (CEditorControl *) (pDoc->m_pCurrentObject);
	else if (1 == pDoc->m_nSelectedObjects)
		pObject = pDoc->m_ppSelArray[0];
		
	CDialogBar *pDialogBar = &(((CMainFrame*)(theApp.m_pMainWnd))->m_wndDialogBar);

	if(m_bActive)
	{
		if (pObject)
		{
			if (!m_bCtrlUpdateOff)
			{
				m_bCtrlUpdateOff = TRUE;
				
				BOOL bEn = pObject->m_type != OBJ_SELECT;
				pDialogBar->GetDlgItem(IDC_TEXT	 )->EnableWindow(bEn);
				pDialogBar->GetDlgItem(IDC_LEFT	 )->EnableWindow(bEn);
				pDialogBar->GetDlgItem(IDC_TOP	 )->EnableWindow(bEn);
				pDialogBar->GetDlgItem(IDC_WIDTH )->EnableWindow(bEn);
				pDialogBar->SetDlgItemText(IDC_TEXT,	bEn ? pObject->m_caption : "[�������� �������]");

				//� TextEdit �������� height ���������
				bEn = !(!bEn | (OBJ_TEXTEDIT == pObject->m_type));
				pDialogBar->GetDlgItem(IDC_HEIGHT)->EnableWindow(bEn);

				pDialogBar->SetDlgItemInt (IDC_LEFT,	pObject->m_x);
				pDialogBar->SetDlgItemInt (IDC_TOP,		pObject->m_y);
				pDialogBar->SetDlgItemInt (IDC_WIDTH,	pObject->m_width);
				pDialogBar->SetDlgItemInt (IDC_HEIGHT,	pObject->m_height);

				m_bCtrlUpdateOff = FALSE;
			}
		}
		else
		{
			if (!m_bCtrlUpdateOff)
			{
				m_bCtrlUpdateOff = TRUE;

				if (pDoc->m_nSelectedObjects > 1)
				{
					char txt[40];
					wsprintf(txt, "[�������� %d ��������]\0", pDoc->m_nSelectedObjects);
					pDialogBar->SetDlgItemText(IDC_TEXT,   txt);
				}
				else
					pDialogBar->SetDlgItemText(IDC_TEXT,   "[������ �� ��������]\0");

				pDialogBar->SetDlgItemText(IDC_LEFT,   "\0");
				pDialogBar->SetDlgItemText(IDC_TOP,    "\0");
				pDialogBar->SetDlgItemText(IDC_WIDTH,  "\0");
				pDialogBar->SetDlgItemText(IDC_HEIGHT, "\0");

				pDialogBar->GetDlgItem(IDC_TEXT	 )->EnableWindow(FALSE);
				pDialogBar->GetDlgItem(IDC_LEFT	 )->EnableWindow(FALSE);
				pDialogBar->GetDlgItem(IDC_TOP	 )->EnableWindow(FALSE);
				pDialogBar->GetDlgItem(IDC_WIDTH )->EnableWindow(FALSE);
				pDialogBar->GetDlgItem(IDC_HEIGHT)->EnableWindow(FALSE);

				m_bCtrlUpdateOff = FALSE;
			}
		}
	}

//������������� ������� ����������

	RECT rt;
	GetClientRect(&rt);

	SIZE	page = {rt.right, rt.bottom}, 
			line = {m_grid_x, m_grid_y},
			all	 = pDoc->m_DocSize;

	if (all.cx > rt.right)  all.cx += rt.right >> 1;
	if (all.cy > rt.bottom) all.cy += rt.bottom >> 1;

	SetScrollSizes(MM_TEXT, all, page, line);

	Invalidate(FALSE);
}



void CEditorView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	switch (nChar)
	{
	case VK_SHIFT:
		m_bShift = TRUE;
		break;
	case VK_CONTROL:
		m_bControl = TRUE;
		break;
	default:
		if (pDoc->m_nSelectedObjects)
		{
			int i;
			int dir = 1;

			switch (nChar)
			{
			//�������(�������) ������(�)
			case VK_LEFT:
				dir = -1;
			case VK_RIGHT:
				if (m_bShift)
				{
					for(i = 0; i < pDoc->m_nSelectedObjects; i++)
						if (pDoc->m_ppSelArray[i]->TestSize(
							pDoc->m_ppSelArray[i]->m_x,
							pDoc->m_ppSelArray[i]->m_y,
							pDoc->m_ppSelArray[i]->m_width + dir * (m_bControl ? m_grid_x:1),
							pDoc->m_ppSelArray[i]->m_height))
							goto end;

					for(i = 0; i < pDoc->m_nSelectedObjects; i++)
						pDoc->m_ppSelArray[i]->Move(
							pDoc->m_ppSelArray[i]->m_x,
							pDoc->m_ppSelArray[i]->m_y,
							pDoc->m_ppSelArray[i]->m_width + dir * (m_bControl ? m_grid_x:1),
							pDoc->m_ppSelArray[i]->m_height);
				}
				else
					pDoc->OffsetSel(dir * (m_bControl ? m_grid_x:1), 0);
				break;

			case VK_UP:
				dir = -1;
			case VK_DOWN:
				if (m_bShift)
				{
					for(i = 0; i < pDoc->m_nSelectedObjects; i++)
						if (pDoc->m_ppSelArray[i]->TestSize(
							pDoc->m_ppSelArray[i]->m_x,
							pDoc->m_ppSelArray[i]->m_y,
							pDoc->m_ppSelArray[i]->m_width,
							pDoc->m_ppSelArray[i]->m_height + dir * (m_bControl ? m_grid_y:1)))
							goto end;

					for(i = 0; i < pDoc->m_nSelectedObjects; i++)
						pDoc->m_ppSelArray[i]->Move(
							pDoc->m_ppSelArray[i]->m_x,
							pDoc->m_ppSelArray[i]->m_y,
							pDoc->m_ppSelArray[i]->m_width,
							pDoc->m_ppSelArray[i]->m_height + dir * (m_bControl ? m_grid_y:1));
				}
				else
					pDoc->OffsetSel(0, dir * (m_bControl ? m_grid_y:1));
				break;
			}

			pDoc->NeedUpdate();
		}
	}

end:
	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}


void CEditorView::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	switch (nChar)
	{
	case VK_SHIFT:
		m_bShift = FALSE;
		break;
	case VK_CONTROL:
		m_bControl = FALSE;
		break;
	case VK_LEFT:
	case VK_RIGHT:
	case VK_UP:
	case VK_DOWN:
		pDoc->SaveToUndoBuffer();
		break;
	}
	
	CView::OnKeyUp(nChar, nRepCnt, nFlags);
}

void CEditorView::OnChangeText() 
{
	if (m_bCtrlUpdateOff) return;

	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if (1 == pDoc->m_nSelectedObjects && !m_bCtrlUpdateOff)
	{
		CString text('x', MAX_NAME);

		((CMainFrame*)(theApp.m_pMainWnd))->m_wndDialogBar.GetDlgItemText(IDC_TEXT, text);

		strcpy(pDoc->m_ppSelArray[0]->m_caption, text.GetBuffer(MAX_NAME));
		text.ReleaseBuffer(MAX_NAME);

		pDoc->SaveToUndoBuffer();

		m_bCtrlUpdateOff = TRUE;
		pDoc->NeedUpdate();
		m_bCtrlUpdateOff = FALSE;
	}
	
}

void CEditorView::OnChangeLeft() 
{
	if (m_bCtrlUpdateOff) return;

	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if (1 == pDoc->m_nSelectedObjects && !m_bCtrlUpdateOff)
	{
		if (!pDoc->m_ppSelArray[0]->TestMove(((CMainFrame*)(theApp.m_pMainWnd))->
					m_wndDialogBar.GetDlgItemInt(IDC_LEFT), 
					pDoc->m_ppSelArray[0]->m_y))
		{
			pDoc->m_ppSelArray[0]->Move(((CMainFrame*)(theApp.m_pMainWnd))->
						m_wndDialogBar.GetDlgItemInt(IDC_LEFT), 
						pDoc->m_ppSelArray[0]->m_y,
						pDoc->m_ppSelArray[0]->m_width,
						pDoc->m_ppSelArray[0]->m_height);

			pDoc->SaveToUndoBuffer();

			m_bCtrlUpdateOff = TRUE;
			pDoc->NeedUpdate();
			m_bCtrlUpdateOff = FALSE;
		}
	}	
}

void CEditorView::OnChangeTop() 
{
	if (m_bCtrlUpdateOff) return;

	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if (1 == pDoc->m_nSelectedObjects && !m_bCtrlUpdateOff)
	{
		if (!pDoc->m_ppSelArray[0]->TestMove(pDoc->m_ppSelArray[0]->m_x, 
					((CMainFrame*)(theApp.m_pMainWnd))->
					m_wndDialogBar.GetDlgItemInt(IDC_TOP)))
		{
			pDoc->m_ppSelArray[0]->Move(pDoc->m_ppSelArray[0]->m_x, 
						((CMainFrame*)(theApp.m_pMainWnd))->
						m_wndDialogBar.GetDlgItemInt(IDC_TOP),
						pDoc->m_ppSelArray[0]->m_width,
						pDoc->m_ppSelArray[0]->m_height);

			pDoc->SaveToUndoBuffer();

			m_bCtrlUpdateOff = TRUE;
			pDoc->NeedUpdate();
			m_bCtrlUpdateOff = FALSE;
		}
	}	
	
}

void CEditorView::OnChangeHeight() 
{
	if (m_bCtrlUpdateOff) return;

	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if (1 == pDoc->m_nSelectedObjects && !m_bCtrlUpdateOff)
	{
		if (!pDoc->m_ppSelArray[0]->TestSize(
						pDoc->m_ppSelArray[0]->m_x, 
						pDoc->m_ppSelArray[0]->m_y,
						pDoc->m_ppSelArray[0]->m_width,
						((CMainFrame*)(theApp.m_pMainWnd))->
						m_wndDialogBar.GetDlgItemInt(IDC_HEIGHT)))
		{
			pDoc->m_ppSelArray[0]->Move(
						pDoc->m_ppSelArray[0]->m_x, 
						pDoc->m_ppSelArray[0]->m_y,
						pDoc->m_ppSelArray[0]->m_width,
						((CMainFrame*)(theApp.m_pMainWnd))->
						m_wndDialogBar.GetDlgItemInt(IDC_HEIGHT));

			pDoc->SaveToUndoBuffer();

			m_bCtrlUpdateOff = TRUE;
			pDoc->NeedUpdate();
			m_bCtrlUpdateOff = FALSE;
		}
	}
}

void CEditorView::OnChangeWidth() 
{
	if (m_bCtrlUpdateOff) return;

	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if (1 == pDoc->m_nSelectedObjects && !m_bCtrlUpdateOff)
	{
		if (!pDoc->m_ppSelArray[0]->TestSize(
						pDoc->m_ppSelArray[0]->m_x, 
						pDoc->m_ppSelArray[0]->m_y,
						((CMainFrame*)(theApp.m_pMainWnd))->
						m_wndDialogBar.GetDlgItemInt(IDC_WIDTH),
						pDoc->m_ppSelArray[0]->m_height))
		{
			pDoc->m_ppSelArray[0]->Move(
						pDoc->m_ppSelArray[0]->m_x, 
						pDoc->m_ppSelArray[0]->m_y,
						((CMainFrame*)(theApp.m_pMainWnd))->
						m_wndDialogBar.GetDlgItemInt(IDC_WIDTH),
						pDoc->m_ppSelArray[0]->m_height);

			pDoc->SaveToUndoBuffer();

			m_bCtrlUpdateOff = TRUE;
			pDoc->NeedUpdate();
			m_bCtrlUpdateOff = FALSE;
		}
	}	
}

void CEditorView::OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView) 
{
	m_bActive = bActivate;
	if (m_bActive) OnUpdate(NULL, NULL, NULL);
	CView::OnActivateView(bActivate, pActivateView, pDeactiveView);
}

void CEditorView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CPoint ptOffset = GetScrollPosition();
	point.Offset(ptOffset);

	if (m_EdMode != EM_SELECT)
	{
		m_EdMode = EM_SELECT;

		if (pDoc->PickObject(point))
			SetCursor(theApp.m_hCursor_OverObject);
		else
			SetCursor(theApp.m_hCursor_Arrow);
	}
	else
	{
		m_bAllowMenu = TRUE;

		CEditorControl *pObject = pDoc->PickObject(point);

		if (pObject)
		{
			if (!pObject->m_bSelected)
			{
				pDoc->SelectObject(NULL);
				pDoc->SelectObject(pDoc->PickObject(point));
			}
		}
		else
			pDoc->SelectObject(NULL);
	}

	CView::OnRButtonDown(nFlags, point);
}

void CEditorView::OnExportHtml() 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CString strTitle;
	strTitle.LoadString(IDS_HTML_MSG_TITLE);

	CString strMessage;

	if (0 == pDoc->m_nControls)
	{
		strMessage.LoadString(IDS_HTML_NO_OBJECTS);
		MessageBox(strMessage, strTitle, MB_ICONEXCLAMATION);
		return;
	}



	char pCurDir[MAX_PATH];
	GetCurrentDirectory(MAX_PATH, pCurDir);

	char pFileName[MAX_PATH] = {0};

	OPENFILENAME ofn = {0};
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = theApp.m_pMainWnd->m_hWnd;
	ofn.hInstance = theApp.m_hInstance;
	ofn.lpstrFilter = "HTML �����(*.htm;*.html)\0*.htm;*.html\0\0";
	ofn.lpstrFile = pFileName;
	ofn.nMaxFile = MAX_PATH;
	ofn.lpstrInitialDir = pCurDir;
	ofn.lpstrTitle = "������� � ���� HTML";
	ofn.Flags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;
	ofn.lpstrDefExt = "htm";

	if (GetSaveFileName(&ofn))
	{
		((CMainFrame*)(theApp.m_pMainWnd))->m_wndStatusBar.SetPaneText(
			((CMainFrame*)(theApp.m_pMainWnd))->m_wndStatusBar.CommandToIndex(ID_SEPARATOR), "�������...");

		int t = GetTickCount();
		
		if (pDoc->ExportToHTML(pFileName))
		{
			strMessage.LoadString(IDS_HTML_EXPORT_ERROR);
			MessageBox(strMessage, strTitle, MB_ICONSTOP);
			((CMainFrame*)(theApp.m_pMainWnd))->m_wndStatusBar.SetPaneText(
				((CMainFrame*)(theApp.m_pMainWnd))->m_wndStatusBar.CommandToIndex(ID_SEPARATOR), strMessage);
			return;
		}

		int dt = GetTickCount() - t;

		strMessage.Format("������� ������� ��������. %f ������", (float)dt * 0.001f);
		((CMainFrame*)(theApp.m_pMainWnd))->m_wndStatusBar.SetPaneText(
			((CMainFrame*)(theApp.m_pMainWnd))->m_wndStatusBar.CommandToIndex(ID_SEPARATOR), strMessage);
	}
}

void CEditorView::OnCreateButton() 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	m_EdMode = EM_CR_BUTTON;
	pDoc->SelectObject(NULL);

	m_bAllowMenu = FALSE;
}

void CEditorView::OnCreateLabel() 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	m_EdMode = EM_CR_LABEL;	
	pDoc->SelectObject(NULL);

	m_bAllowMenu = FALSE;
}

void CEditorView::OnCreateTextedit() 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	m_EdMode = EM_CR_TEXTEDIT;
	pDoc->SelectObject(NULL);

	m_bAllowMenu = FALSE;
}

void CEditorView::OnShowGrid() 
{
	m_bShowGrid = !m_bShowGrid;

	m_OldDocViewState--;
	Invalidate(FALSE);
}

void CEditorView::OnUpdateShowGrid(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_bShowGrid);
}

void CEditorView::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	int y = GetScrollPos(SB_VERT);
	int yOrig = y;

	switch (nSBCode)
	{
	case SB_TOP:
		y = 0;
		break;
	case SB_BOTTOM:
		y = INT_MAX;
		break;
	case SB_LINEUP:
		y -= m_lineDev.cy;
		break;
	case SB_LINEDOWN:
		y += m_lineDev.cy;
		break;
	case SB_PAGEUP:
		y -= m_pageDev.cy;
		break;
	case SB_PAGEDOWN:
		y += m_pageDev.cy;
		break;
	case SB_THUMBTRACK:
		y = nPos;
		break;
	}


	int yMax = GetScrollLimit(SB_VERT);
	if (y < 0)
		y = 0;
	else if (y > yMax)
		y = yMax;

	if (y != yOrig)
	{
		SetScrollPos(SB_VERT, y);
		m_OldDocViewState--;
		Invalidate(FALSE);
	}
}

void CEditorView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	int x = GetScrollPos(SB_HORZ);
	int xOrig = x;

	switch (nSBCode)
	{
	case SB_TOP:
		x = 0;
		break;
	case SB_BOTTOM:
		x = INT_MAX;
		break;
	case SB_LINEUP:
		x -= m_lineDev.cx;
		break;
	case SB_LINEDOWN:
		x += m_lineDev.cx;
		break;
	case SB_PAGEUP:
		x -= m_pageDev.cx;
		break;
	case SB_PAGEDOWN:
		x += m_pageDev.cx;
		break;
	case SB_THUMBTRACK:
		x = nPos;
		break;
	}


	int xMax = GetScrollLimit(SB_HORZ);
	if (x < 0)
		x = 0;
	else if (x > xMax)
		x = xMax;

	if (x != xOrig)
	{
		SetScrollPos(SB_HORZ, x);
		m_OldDocViewState--;
		Invalidate(FALSE);
	}
}

void CEditorView::ResizeBackBuffer(int cx, int cy)
{
	if(m_pOldBitmap)
	{
		m_memDC.SelectObject(m_pOldBitmap);
		m_memDC.DeleteDC();
		m_pOldBitmap = NULL;

		m_memBitmap.DeleteObject();
	}
	
	CDC *pDC = GetWindowDC();

	m_memDC.CreateCompatibleDC(pDC);
	m_memBitmap.CreateCompatibleBitmap(pDC, cx, cy);
	m_pOldBitmap = m_memDC.SelectObject(&m_memBitmap);

	ReleaseDC(pDC);
}

void CEditorView::OnOptions() 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CDlgOptions dlg;
	
	dlg.m_grid_x = m_grid_x;
	dlg.m_grid_y = m_grid_y;
	dlg.m_nTextAlign = pDoc->m_nLabelTextAlign;

	if (IDOK == dlg.DoModal())
	{
		m_grid_x = dlg.m_grid_x;
		m_grid_y = dlg.m_grid_y;
		pDoc->m_nLabelTextAlign = dlg.m_nTextAlign;

		pDoc->NeedUpdate();
	}
}

void CEditorView::OnDelete() 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	if (GetFocus() != this)
		return;

	pDoc->DeleteSelectedObjects();
}

void CEditorView::OnSelectNone() 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->SelectObject(NULL);
}

void CEditorView::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if (!m_bAllowMenu) return;

	CMenu *pSubMenu = m_Menu.GetSubMenu(0);

	if (0 == pDoc->m_nSelectedObjects)
	{
		pSubMenu->EnableMenuItem(ID_EDIT_COPY,		MF_GRAYED);
		pSubMenu->EnableMenuItem(ID_EDIT_CUT,		MF_GRAYED);
		pSubMenu->EnableMenuItem(ID_EDIT_PASTE_EX,	pDoc->m_bHasBuffer ? MF_ENABLED : MF_GRAYED);
		pSubMenu->EnableMenuItem(ID_DELETE,			MF_GRAYED);
		pSubMenu->EnableMenuItem(ID_SELECT_NONE,	MF_GRAYED);
		pSubMenu->EnableMenuItem(ID_ALIGN_POS,		MF_GRAYED);
		pSubMenu->EnableMenuItem(ID_ALIGN_SIZE,		MF_GRAYED);

		if (0 == pDoc->m_nControls)
		{
			pSubMenu->EnableMenuItem(ID_SELECT_ALL, MF_GRAYED);
			pSubMenu->EnableMenuItem(ID_SELECT_INVERT, MF_GRAYED);
		}
		else
		{
			pSubMenu->EnableMenuItem(ID_SELECT_ALL, MF_ENABLED);
			pSubMenu->EnableMenuItem(ID_SELECT_INVERT, MF_ENABLED);
		}
	}
	else
	{
		pSubMenu->EnableMenuItem(ID_EDIT_COPY,		MF_ENABLED);
		pSubMenu->EnableMenuItem(ID_EDIT_CUT,		MF_ENABLED);
		pSubMenu->EnableMenuItem(ID_EDIT_PASTE_EX,	MF_GRAYED);
		pSubMenu->EnableMenuItem(ID_DELETE,			MF_ENABLED);
		pSubMenu->EnableMenuItem(ID_SELECT_NONE,	MF_ENABLED);
		pSubMenu->EnableMenuItem(ID_SELECT_INVERT,	MF_ENABLED);
		pSubMenu->EnableMenuItem(ID_ALIGN_POS,		MF_ENABLED);
		pSubMenu->EnableMenuItem(ID_ALIGN_SIZE,		MF_ENABLED);

		if (pDoc->m_nSelectedObjects == pDoc->m_nControls)
			pSubMenu->EnableMenuItem(ID_SELECT_ALL,	MF_GRAYED);
		else
			pSubMenu->EnableMenuItem(ID_SELECT_ALL,	MF_ENABLED);
	}

	pSubMenu->CheckMenuItem(IDM_SHOWGRID, 
		m_bShowGrid  ?  MF_CHECKED : MF_UNCHECKED);

	if (point.x != -1 && point.y != -1)
	{
		CPoint pt = point;
		ScreenToClient(&pt);

		CPoint ptOffset = GetScrollPosition();
		pt.Offset(ptOffset);

		if (m_bShowGrid)
		{
			pDoc->m_x0 = GRID_ALIGN(pt.x, m_grid_x);
			pDoc->m_y0 = GRID_ALIGN(pt.y, m_grid_y);
		}
		else
		{
			pDoc->m_x0 = pt.x;
			pDoc->m_y0 = pt.y;
		}
	}
	else
	{
		pDoc->m_x0 = -1;
		pDoc->m_y0 = -1;
	}

	pSubMenu->TrackPopupMenu(TPM_VERTICAL | TPM_RIGHTBUTTON, 
		point.x, point.y, this);	
}

void CEditorView::OnSelectAll() 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	pDoc->SelectAll();
}

void CEditorView::OnSelectInvert() 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	pDoc->SelectInvert();
}

void CEditorView::OnEditUndo() 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	pDoc->Undo();
}

void CEditorView::OnUpdateEditUndo(CCmdUI* pCmdUI) 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pCmdUI->Enable(pDoc->m_nUndoBuffers > 1);
}

void CEditorView::OnEditRedo() 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	pDoc->Redo();
}

void CEditorView::OnUpdateEditRedo(CCmdUI* pCmdUI) 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pCmdUI->Enable(pDoc->m_nRedoBuffers);
}

void CEditorView::OnEditCopy() 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->CopySelected();
}

void CEditorView::OnUpdateEditCopy(CCmdUI* pCmdUI) 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pCmdUI->Enable(pDoc->m_nSelectedObjects);
}

void CEditorView::OnEditCut() 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->CopySelected();
	pDoc->DeleteSelectedObjects();
}

void CEditorView::OnUpdateEditCut(CCmdUI* pCmdUI) 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pCmdUI->Enable(pDoc->m_nSelectedObjects);	
}

void CEditorView::OnUpdateDelete(CCmdUI* pCmdUI) 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pCmdUI->Enable(pDoc->m_nSelectedObjects);		
}

void CEditorView::OnEditPaste() 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->m_x0 = -1;
	pDoc->m_y0 = -1;

	pDoc->Paste();
}

void CEditorView::OnUpdateEditPaste(CCmdUI* pCmdUI) 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if (!OpenClipboard())
	{
		pCmdUI->Enable(FALSE);
		pDoc->m_bHasBuffer = FALSE;
		return;
	}

	HANDLE hData = GetClipboardData(CF_TEXT);
	CloseClipboard();

	if (!hData)
	{
		pCmdUI->Enable(FALSE);
		pDoc->m_bHasBuffer = FALSE;
		return;
	}

	char* pStr = (char *) GlobalLock(hData);

	if ('<' == pStr[0])
	{
		pCmdUI->Enable(TRUE);
		pDoc->m_bHasBuffer = TRUE;
	}
	else
	{
		pCmdUI->Enable(FALSE);
		pDoc->m_bHasBuffer = FALSE;
	}

	GlobalUnlock(hData);
}

void CEditorView::OnEditPasteEx() 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->Paste();
}


void CEditorView::OnDestroy() 
{
	CView::OnDestroy();
	
	if (theApp.m_bNoInterface) return;
	
	m_bCtrlUpdateOff = TRUE;

	CDialogBar *pDialogBar = &(((CMainFrame*)(theApp.m_pMainWnd))->m_wndDialogBar);

	pDialogBar->SetDlgItemText(IDC_TEXT,   "\0");
	pDialogBar->SetDlgItemText(IDC_LEFT,   "\0");
	pDialogBar->SetDlgItemText(IDC_TOP,    "\0");
	pDialogBar->SetDlgItemText(IDC_WIDTH,  "\0");
	pDialogBar->SetDlgItemText(IDC_HEIGHT, "\0");

	pDialogBar->GetDlgItem(IDC_TEXT	 )->EnableWindow(FALSE);
	pDialogBar->GetDlgItem(IDC_LEFT	 )->EnableWindow(FALSE);
	pDialogBar->GetDlgItem(IDC_TOP	 )->EnableWindow(FALSE);
	pDialogBar->GetDlgItem(IDC_WIDTH )->EnableWindow(FALSE);
	pDialogBar->GetDlgItem(IDC_HEIGHT)->EnableWindow(FALSE);

	m_bCtrlUpdateOff = FALSE;
}

void CEditorView::OnAlignPos() 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	pDoc->AlignPos(m_grid_x, m_grid_y);
}

void CEditorView::OnUpdateAlignPos(CCmdUI* pCmdUI) 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pCmdUI->Enable(pDoc->m_nSelectedObjects);
}

void CEditorView::OnAlignSize() 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	pDoc->AlignSize(m_grid_x, m_grid_y);
}

void CEditorView::OnUpdateAlignSize(CCmdUI* pCmdUI) 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pCmdUI->Enable(pDoc->m_nSelectedObjects);
}

void CEditorView::OnStatistics() 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	//������� �������
	int nButtons = 0;
	int nLabels = 0;
	int nEdits = 0;
	CEditorControl *pObject = pDoc->m_pControlList->m_pNextControl;
	while (pObject)
	{
		switch (pObject->m_type)
		{
		case OBJ_BUTTON:
			nButtons++;
			break;
		case OBJ_TEXTEDIT:
			nEdits++;
			break;
		case OBJ_LABEL:
			nLabels++;
			break;
		default:
			ASSERT(0);
		}

		pObject = pObject->m_pNextControl;
	}


	CDlgStatistics dlg;

	dlg.m_nObjects.Format("%d", pDoc->m_nControls);
	dlg.m_nButtons.Format("%d", nButtons);
	dlg.m_nEdits.Format("%d", nEdits);
	dlg.m_nLabels.Format("%d", nLabels);
	
	dlg.DoModal();
}

void CEditorView::EnableScrollTimer(BOOL bEnable)
{
	if (bEnable)
	{
		if (!m_nTimerId)
			m_nTimerId = SetTimer(1, 50, NULL);
	}
	else
	{
		if (m_nTimerId)
		{
			KillTimer(m_nTimerId);
			m_nTimerId = 0;
		}
	}
}

void CEditorView::OnTimer(UINT nIDEvent) 
{
	CEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	int curx = GetScrollPos(SB_HORZ);
	int cury = GetScrollPos(SB_VERT);

	RECT rt;
	GetClientRect(&rt);

	//����� �������� ��������, ��������� ������ � ������ �������������
	if (pDoc->m_DocSize.cx > rt.right)
		SetScrollPos(SB_HORZ, curx + m_nAutoScroll_dx, FALSE);
	if (pDoc->m_DocSize.cy > rt.bottom)
		SetScrollPos(SB_VERT, cury + m_nAutoScroll_dy, FALSE);

	//���������� ����������� ���
	m_nAutoScroll_dx = int((float)m_nAutoScroll_dx * 1.4f);
	m_nAutoScroll_dy = int((float)m_nAutoScroll_dy * 1.4f);

	pDoc->NeedUpdate();	

	CView::OnTimer(nIDEvent);
}

BOOL CEditorView::PreTranslateMessage(MSG* pMsg) 
{
	if (GetFocus() == this)
		EnableAccel(TRUE);

	return CView::PreTranslateMessage(pMsg);
}

void CEditorView::EnableAccel(BOOL bEnable)
{
	::DestroyAcceleratorTable(((CFrameWnd*) theApp.m_pMainWnd)->m_hAccelTable);
	((CFrameWnd*) theApp.m_pMainWnd)->m_hAccelTable = NULL;

	if (bEnable)
		((CFrameWnd*) theApp.m_pMainWnd)->LoadAccelTable(MAKEINTRESOURCE(IDR_MAINFRAME));
	else
		((CFrameWnd*) theApp.m_pMainWnd)->LoadAccelTable(MAKEINTRESOURCE(IDR_MAINFRAME_SMP));
}

void CEditorView::OnSetfocusText() 
{
	EnableAccel(FALSE);
}

void CEditorView::OnKillfocusText() 
{
	EnableAccel(TRUE);
}

void CEditorView::OnKillfocusLeft() 
{
	EnableAccel(TRUE);
}

void CEditorView::OnSetfocusLeft() 
{
	EnableAccel(FALSE);
}

void CEditorView::OnKillfocusTop() 
{
	EnableAccel(TRUE);
}

void CEditorView::OnSetfocusTop() 
{
	EnableAccel(FALSE);
}

void CEditorView::OnKillfocusWidth() 
{
	EnableAccel(TRUE);
}

void CEditorView::OnSetfocusWidth() 
{
	EnableAccel(FALSE);
}

void CEditorView::OnKillfocusHeight() 
{
	EnableAccel(TRUE);
}

void CEditorView::OnSetfocusHeight() 
{
	EnableAccel(FALSE);
}
