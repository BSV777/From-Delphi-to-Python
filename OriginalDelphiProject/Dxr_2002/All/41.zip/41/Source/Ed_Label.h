// Ed_Label.h: interface for the CEd_Label class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ED_LABEL_H__96BE74C4_35C2_11D6_929F_A57866D0145F__INCLUDED_)
#define AFX_ED_LABEL_H__96BE74C4_35C2_11D6_929F_A57866D0145F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "EditorControl.h"

#define LABEL_DEFAULT_WIDTH 100
#define LABEL_DEFAULT_HEIGHT 30

class CEd_Label : public CEditorControl
{
public:
	CEd_Label(int x, int y, CEditorDoc *pDoc);
	virtual ~CEd_Label();

public:
	virtual void Get_HTML_Tag(char *pString);
	virtual BOOL RestoreFromString(char* lpstrString);

	virtual void DrawSelf(CDC *pDC, int ox, int oy);
	virtual void GetSaveString(char *pString);

};

#endif // !defined(AFX_ED_LABEL_H__96BE74C4_35C2_11D6_929F_A57866D0145F__INCLUDED_)
