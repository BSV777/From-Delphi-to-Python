// Select.h: interface for the CSelect class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SELECT_H__053B8AA0_3429_11D6_929F_E748882BAF25__INCLUDED_)
#define AFX_SELECT_H__053B8AA0_3429_11D6_929F_E748882BAF25__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "EditorObject.h"

class CSelect : public CEditorObject  
{
public:
	virtual void Move(int x, int y, int width, int height);
	CSelect(int x, int y, CEditorDoc *pDoc);
	virtual ~CSelect();

	int CreateSelectArray(CEditorControl* **ppObjArray);
	virtual void DrawSelf(CDC *pDC, int ox, int oy);
};

#endif // !defined(AFX_SELECT_H__053B8AA0_3429_11D6_929F_E748882BAF25__INCLUDED_)
