// DlgLoadError.cpp : implementation file
//

#include "stdafx.h"
#include "Editor.h"
#include "EditorDoc.h"
#include "DlgLoadError.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgLoadError dialog


CDlgLoadError::CDlgLoadError(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgLoadError::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgLoadError)
	m_bToAll = FALSE;
	m_strObjectName = _T("");
	//}}AFX_DATA_INIT

	MessageBeep(MB_ICONEXCLAMATION);
}


void CDlgLoadError::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgLoadError)
	DDX_Check(pDX, IDC_TO_ALL, m_bToAll);
	DDX_Text(pDX, IDC_OBJECT_NAME, m_strObjectName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgLoadError, CDialog)
	//{{AFX_MSG_MAP(CDlgLoadError)
	ON_BN_CLICKED(IDC_SKIP, OnSkip)
	ON_BN_CLICKED(IDC_NEW_POS, OnNewPos)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgLoadError message handlers

void CDlgLoadError::OnOK() 
{

//	CDialog::OnOK();
}

void CDlgLoadError::OnSkip() 
{
	m_bAutoMove = FALSE;
	
	CDialog::OnOK();
}

void CDlgLoadError::OnNewPos() 
{
	m_bAutoMove = TRUE;
	
	CDialog::OnOK();
}
