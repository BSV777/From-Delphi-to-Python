//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Editor.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_DIALOG_BAR                  101
#define ID_INDICATOR_X                  101
#define ID_INDICATOR_Y                  102
#define IDD_DLG_OPTIONS                 103
#define IDR_MAINFRAME                   128
#define IDR_EDITORTYPE                  129
#define IDR_MAINFRAME_SMP               129
#define IDC_MOVE                        130
#define IDC_CR_BUTTON                   131
#define IDC_OVER_OBJECT                 132
#define IDI_ICON1                       134
#define IDC_ARROW_                      135
#define IDC_LR                          136
#define IDC_UD                          137
#define IDC_LT_RB                       138
#define IDC_RT_LB                       139
#define IDC_CROSS_                      140
#define IDC_NO_                         141
#define IDR_CREATE_OBJECTS              142
#define IDC_CR_TEXTEDIT                 144
#define IDC_CR_LABEL                    145
#define IDR_VIEWMENU                    148
#define IDR_EDIT                        149
#define IDD_SHORTCUTS                   151
#define IDR_TEXT_SHORTCUTS              152
#define IDD_DLG_LOAD_ERR                154
#define IDI_EXCLAMATION_                155
#define IDD_STATISTICS                  156
#define IDI_INFO_                       157
#define IDC_TEXT                        1000
#define IDC_LEFT                        1002
#define IDC_TOP                         1003
#define IDC_WIDTH                       1004
#define IDC_HEIGHT                      1005
#define IDC_GRID_USE_DEFAULT            1007
#define IDC_GRID_X                      1008
#define IDC_GRID_Y                      1009
#define IDC_HALIGN_LEFT                 1010
#define IDC_HALIGN_CENTER               1011
#define IDC_HALIGN_RIGHT                1012
#define IDC_VALIGN_TOP                  1013
#define IDC_VALIGN_CENTER               1014
#define IDC_VALIGN_BOTTOM               1015
#define IDC_LABEL_USE_DEFAULT           1016
#define IDC_HTML_READ                   1021
#define IDC_HTML_SIZE                   1022
#define IDC_SKIP                        1023
#define IDC_NEW_POS                     1024
#define IDC_MESSAGE                     1026
#define IDC_TO_ALL                      1027
#define IDC_OBJECT_NAME                 1028
#define IDC_NUM_OBJECTS                 1029
#define IDC_NUM_BUTTON                  1030
#define IDC_NUM_EDIT                    1031
#define IDC_NUM_LABEL                   1032
#define IDM_SHOWGRID                    32774
#define ID_CREATE_BUTTON                32775
#define ID_CREATE_TEXTEDIT              32776
#define ID_CREATE_LABEL                 32777
#define ID_EXPORT_HTML                  32778
#define ID_VIEW_CROBJECTS               32779
#define ID_OBJ_PROPERTIES               32780
#define ID_EXPORT_HTML2                 32781
#define IDM_OPTIONS                     32782
#define ID_DELETE                       32787
#define ID_ALIGN                        32788
#define ID_ALIGN_SIZE                   32789
#define ID_ALIGN_POS                    32790
#define ID_SELECT_ALL                   32791
#define ID_SELECT_NONE                  32792
#define ID_SELECT_INVERT                32793
#define ID_CUT                          32796
#define ID_COPY                         32797
#define ID_PASTE                        32798
#define ID_UNDO                         32799
#define ID_REDO                         32800
#define ID_VIEW_EDIT                    32801
#define ID_KEYB_SHORTCUTS               32803
#define ID_EDIT_PASTE_EX                32804
#define ID_STATISTICS                   32805
#define IDS_CREATE_BUTTON_TIP           61216
#define IDS_CREATE_TEXTEDIT_TIP         61217
#define IDS_CREATE_LABEL_TIP            61218
#define IDS_CREATE_FAIL                 61219
#define IDS_HTML_MSG_TITLE              61220
#define IDS_HTML_EXPORT_ERROR           61221
#define IDS_HTML_NO_OBJECTS             61222
#define IDS_SAVING                      61223
#define IDS_LOADING                     61224

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        158
#define _APS_NEXT_COMMAND_VALUE         32808
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
