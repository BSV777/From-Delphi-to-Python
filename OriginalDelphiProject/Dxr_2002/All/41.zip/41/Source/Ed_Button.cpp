// Ed_Button.cpp: implementation of the CEd_Button class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Editor.h"
#include "EditorDoc.h"
#include "Ed_Button.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEd_Button::CEd_Button(int x, int y, CEditorDoc *pDoc) : CEditorControl(pDoc)
{
	m_type = OBJ_BUTTON;

	m_x = x; 
	m_y = y;

	if (m_pDoc->m_State != ES_LOADING && m_pDoc->m_State != ES_PASTING)
		AutoName("button_%d");
}

CEd_Button::~CEd_Button()
{
	
}

void CEd_Button::DrawSelf(CDC *pDC, int ox, int oy)
{
	CPen pen(PS_NULL, 1, (COLORREF) 0x0), *oldpen;
	oldpen = pDC->SelectObject(&pen);

	CBrush brush, *oldbrush;
	brush.Attach(GetSysColorBrush(COLOR_BTNFACE));
	oldbrush = pDC->SelectObject(&brush);

	CFont *oldfont = (CFont *) pDC->SelectStockObject(ANSI_VAR_FONT);

	RECT rtDrawRect = m_rtViewRect;
	OffsetRect(&rtDrawRect, ox, oy);

	pDC->Rectangle(&rtDrawRect);

	pDC->SetBkMode(TRANSPARENT);
	pDC->SetTextColor(GetSysColor(COLOR_BTNTEXT));
	pDC->DrawText(m_caption, strlen(m_caption), &rtDrawRect, 
		DT_SINGLELINE | DT_CENTER | DT_VCENTER);
	
	pDC->DrawEdge(&rtDrawRect, EDGE_RAISED, BF_RECT);

	pDC->SelectObject(oldfont);
	pDC->SelectObject(oldbrush);
	pDC->SelectObject(oldpen);

	CEditorControl::DrawSelf(pDC, ox, oy);
}

void CEd_Button::GetSaveString(char *pString)
{
	wsprintf(pString, "<Button left=\"%d\"; top=\"%d\"; width=\"%d\"; height=\"%d\"; caption=\"%s\">", 
		m_x, m_y, m_width, m_height, m_caption);
}

BOOL CEd_Button::RestoreFromString(char *lpstrString)
{
	int val;

	int x, y, h, w;

	if (!ReadIntProperty(lpstrString, "left", &val))
		x = __max(val, 0);
	else
		x = 0;

	if (!ReadIntProperty(lpstrString, "top", &val))
		y = __max(val, 0);
	else
		y = 0;

	if (!ReadIntProperty(lpstrString, "width", &val))
		w = val;
	else if (!ReadIntProperty(lpstrString, "right", &val))
		w = val - x;
	else
		w = 100;

	if (!ReadIntProperty(lpstrString, "height", &val))
		h = val;
	else if (!ReadIntProperty(lpstrString, "buttom", &val))
		h = val - y;
	else
		h = 30;

	if (ReadStrProperty(lpstrString, "caption", m_caption))
		AutoName("button_%d");

	Move(x, y, w, h);

	return FALSE;
}

void CEd_Button::Get_HTML_Tag(char *pString)
{
	sprintf(pString, "><input type=button value=\"%s\" style=\"font-size:8pt;width:%d;height:%d\">", 
		m_caption, m_width, m_height);
}
