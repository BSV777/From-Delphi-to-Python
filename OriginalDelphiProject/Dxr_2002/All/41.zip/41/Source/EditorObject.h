// EditorObject.h: interface for the CEditorObject class.
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_EDITOROBJECT_H__CFC48FC5_2DE3_11D6_929F_C4FC6DDC883C__INCLUDED_)
#define AFX_EDITOROBJECT_H__CFC48FC5_2DE3_11D6_929F_C4FC6DDC883C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CEditorDoc;

class CEditorObject  
{
public:
	int m_x, m_y;
	int m_width, m_height;

	UINT m_type;

	RECT m_rtViewRect;

protected:
	CEditorDoc *m_pDoc;

public:
	CEditorObject *m_pNextObject;
	CEditorObject *m_pPrevObject;

public:
	CEditorObject(CEditorDoc *pDoc);
	virtual ~CEditorObject();

public:
	void MoveToEnd();

	virtual void Move(int x, int y, int width, int height);
	virtual void Offset(int dx, int dy);

	virtual void DrawSelf(CDC *pDC, int ox, int oy);
};

#endif // !defined(AFX_EDITOROBJECT_H__CFC48FC5_2DE3_11D6_929F_C4FC6DDC883C__INCLUDED_)
