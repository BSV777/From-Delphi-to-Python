// DlgOptions.cpp : implementation file
//

#include "stdafx.h"
#include "Editor.h"
#include "EditorDoc.h"
#include "DlgOptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgOptions dialog

extern CEditorApp theApp;

CDlgOptions::CDlgOptions(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgOptions::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgOptions)
	m_grid_x = 10;
	m_grid_y = 10;
	m_bDefaultGrid = FALSE;
	m_bDefaultLabel = FALSE;
	//}}AFX_DATA_INIT

	m_bHTML_MinSize = theApp.GetProfileInt("Settings", "HTML_MinSize", FALSE);
	m_nTextAlign = theApp.GetProfileInt("settings", 
		"LabelTextAlign", LTA_CENTER | LTA_VCENTER);
	m_grid_x = theApp.GetProfileInt("settings", "Grid_X", 10);
	m_grid_y = theApp.GetProfileInt("settings", "Grid_Y", 10);

	m_bHaveView = TRUE;
}


void CDlgOptions::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgOptions)
	DDX_Text(pDX, IDC_GRID_X, m_grid_x);
	DDV_MinMaxUInt(pDX, m_grid_x, 5, 30);
	DDX_Text(pDX, IDC_GRID_Y, m_grid_y);
	DDV_MinMaxUInt(pDX, m_grid_y, 5, 30);
	DDX_Check(pDX, IDC_GRID_USE_DEFAULT, m_bDefaultGrid);
	DDX_Check(pDX, IDC_LABEL_USE_DEFAULT, m_bDefaultLabel);
	//}}AFX_DATA_MAP

	if (pDX->m_bSaveAndValidate)
	{
		m_nTextAlign = 0;

		if (SendDlgItemMessage(IDC_HALIGN_LEFT, BM_GETCHECK, 0, 0))
			m_nTextAlign |= LTA_LEFT;
		else if(SendDlgItemMessage(IDC_HALIGN_CENTER, BM_GETCHECK, 0, 0))
			m_nTextAlign |= LTA_CENTER;
		else if(SendDlgItemMessage(IDC_HALIGN_RIGHT, BM_GETCHECK, 0, 0))
			m_nTextAlign |= LTA_RIGHT;

		if (SendDlgItemMessage(IDC_VALIGN_TOP, BM_GETCHECK, 0, 0))
			m_nTextAlign |= LTA_TOP;
		else if(SendDlgItemMessage(IDC_VALIGN_CENTER, BM_GETCHECK, 0, 0))
			m_nTextAlign |= LTA_VCENTER;
		else if(SendDlgItemMessage(IDC_VALIGN_BOTTOM, BM_GETCHECK, 0, 0))
			m_nTextAlign |= LTA_BOTTOM;

		if (SendDlgItemMessage(IDC_HTML_SIZE, BM_GETCHECK, 0, 0))
			m_bHTML_MinSize = TRUE;
		else
			m_bHTML_MinSize = FALSE;
	}
	else
	{
		if (m_nTextAlign & LTA_LEFT)
			SendDlgItemMessage(IDC_HALIGN_LEFT, BM_SETCHECK, TRUE, 0);
		else if(m_nTextAlign & LTA_CENTER)
			SendDlgItemMessage(IDC_HALIGN_CENTER, BM_SETCHECK, TRUE, 0);
		else if(m_nTextAlign & LTA_RIGHT)
			SendDlgItemMessage(IDC_HALIGN_RIGHT, BM_SETCHECK, TRUE, 0);

		if (m_nTextAlign & LTA_TOP)
			SendDlgItemMessage(IDC_VALIGN_TOP, BM_SETCHECK, TRUE, 0);
		else if(m_nTextAlign & LTA_VCENTER)
			SendDlgItemMessage(IDC_VALIGN_CENTER, BM_SETCHECK, TRUE, 0);
		else if(m_nTextAlign & LTA_BOTTOM)
			SendDlgItemMessage(IDC_VALIGN_BOTTOM, BM_SETCHECK, TRUE, 0);

		SendDlgItemMessage(IDC_HTML_SIZE, BM_SETCHECK, m_bHTML_MinSize, 0);
		SendDlgItemMessage(IDC_HTML_READ, BM_SETCHECK, !m_bHTML_MinSize, 0);

		GetDlgItem(IDC_GRID_USE_DEFAULT)->EnableWindow(m_bHaveView);
		GetDlgItem(IDC_LABEL_USE_DEFAULT)->EnableWindow(m_bHaveView);
	}
}


BEGIN_MESSAGE_MAP(CDlgOptions, CDialog)
	//{{AFX_MSG_MAP(CDlgOptions)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgOptions message handlers

void CDlgOptions::OnOK() 
{
	UpdateData();

	//��������� ���������_��_���������
	if (m_bDefaultLabel)
		theApp.WriteProfileInt("settings", "LabelTextAlign", m_nTextAlign);

	if (m_bDefaultGrid)
	{
		theApp.WriteProfileInt("settings", "Grid_X", m_grid_x);
		theApp.WriteProfileInt("settings", "Grid_Y", m_grid_y);
	}

	theApp.WriteProfileInt("Settings", "HTML_MinSize", m_bHTML_MinSize);

	CDialog::OnOK();
}
