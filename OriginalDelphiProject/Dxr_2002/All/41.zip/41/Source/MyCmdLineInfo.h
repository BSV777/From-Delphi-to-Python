// MyCmdLineInfo.h: interface for the CMyCmdLineInfo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYCMDLINEINFO_H__752140EC_3824_11D6_929F_B5156F4B6A5F__INCLUDED_)
#define AFX_MYCMDLINEINFO_H__752140EC_3824_11D6_929F_B5156F4B6A5F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMyCmdLineInfo : public CCommandLineInfo  
{
public:
	BOOL m_bDirect_To_HTML;
	CString m_str_HTML_FileName;

	CMyCmdLineInfo();
	virtual ~CMyCmdLineInfo();
};

#endif // !defined(AFX_MYCMDLINEINFO_H__752140EC_3824_11D6_929F_B5156F4B6A5F__INCLUDED_)
