// Select.cpp: implementation of the CSelect class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Editor.h"

#include "EditorDoc.h"
#include "EditorControl.h"
#include "Select.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSelect::CSelect(int x, int y, CEditorDoc *pDoc) : CEditorObject(pDoc)
{
	m_type = OBJ_SELECT;

	m_x = x;
	m_y = y;

	MoveToEnd();
}

CSelect::~CSelect()
{

}

void CSelect::DrawSelf(CDC *pDC, int ox, int oy)
{
	RECT rtDrawRect = m_rtViewRect;
	OffsetRect(&rtDrawRect, ox, oy);

	pDC->SetTextColor(0x0);
	pDC->DrawFocusRect(&rtDrawRect);
}

int CSelect::CreateSelectArray(CEditorControl* **ppObjArray)
{
	int nObjectsInSel = 0;

	CEditorControl *pObject;

	//�������, ������� �������� ������ � ���������� �������
	pObject = m_pDoc->m_pControlList->m_pNextControl;
	while(pObject)
	{
		RECT rt;
		if (IntersectRect(&rt, &m_rtViewRect, &pObject->m_rtViewRect))
			nObjectsInSel++;

		pObject = pObject->m_pNextControl;
	}

	//�� ������ �� ������
	if (0 == nObjectsInSel)
	{
		*ppObjArray = NULL;
		return 0;
	}

	*ppObjArray = new CEditorControl*[nObjectsInSel];

	pObject = m_pDoc->m_pControlList->m_pNextControl;
	for(int n = 0; n < nObjectsInSel; pObject = pObject->m_pNextControl)
	{
		RECT rt;
		if (IntersectRect(&rt, &m_rtViewRect, &pObject->m_rtViewRect))
		{
			(*ppObjArray)[n] = pObject;
			n++;
		}
	}
	
	return nObjectsInSel;
}

void CSelect::Move(int x, int y, int width, int height)
{
	m_x = x;
	m_y = y;
	m_height = height;
	m_width = width;

	//����������
	if (m_width < 0)
	{
		m_x += m_width;
		m_width = -m_width;
	}
	if (m_height < 0)
	{
		m_y += m_height;
		m_height = -m_height;
	}


	//�������� ������� ������
	m_rtViewRect.left = m_x;
	m_rtViewRect.top = m_y;
	m_rtViewRect.right = m_x + m_width;
	m_rtViewRect.bottom = m_y + m_height;
}
