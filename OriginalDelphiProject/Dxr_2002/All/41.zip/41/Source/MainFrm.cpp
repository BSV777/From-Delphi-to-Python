// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Editor.h"
#include "DlgOptions.h"
#include "DlgShortcuts.h"
#include "MainFrm.h"
#include "EditorDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	ON_UPDATE_COMMAND_UI(ID_VIEW_CROBJECTS, OnUpdateViewCrobjects)
	ON_UPDATE_COMMAND_UI(ID_OBJ_PROPERTIES, OnUpdateObjProperties)
	ON_COMMAND(ID_VIEW_TOOLBAR, OnViewToolbar)
	ON_UPDATE_COMMAND_UI(ID_VIEW_TOOLBAR, OnUpdateViewToolbar)
	ON_COMMAND(ID_VIEW_CROBJECTS, OnViewCrobjects)
	ON_COMMAND(ID_OBJ_PROPERTIES, OnObjProperties)
	ON_COMMAND(IDM_OPTIONS, OnOptions)
	ON_COMMAND(ID_VIEW_EDIT, OnViewEdit)
	ON_UPDATE_COMMAND_UI(ID_VIEW_EDIT, OnUpdateViewEdit)
	ON_COMMAND(ID_KEYB_SHORTCUTS, OnKeybShortcuts)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_X,
	ID_INDICATOR_Y,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	

	m_wndToolBar_File.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);
	m_wndToolBar_File.LoadToolBar(IDR_MAINFRAME);

	m_wndToolBar_Edit.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);
	m_wndToolBar_Edit.LoadToolBar(IDR_EDIT);

	m_wndCrObjectsBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);
	m_wndCrObjectsBar.LoadToolBar(IDR_CREATE_OBJECTS);

	m_wndDialogBar.Create(this, IDD_DIALOG_BAR, CBRS_TOP, IDD_DIALOG_BAR);
	m_wndDialogBar.SendDlgItemMessage(IDC_TEXT,		EM_LIMITTEXT, MAX_NAME, 0);
	m_wndDialogBar.SendDlgItemMessage(IDC_LEFT,		EM_LIMITTEXT, 5, 0);
	m_wndDialogBar.SendDlgItemMessage(IDC_TOP,		EM_LIMITTEXT, 5, 0);
	m_wndDialogBar.SendDlgItemMessage(IDC_WIDTH,	EM_LIMITTEXT, 5, 0);
	m_wndDialogBar.SendDlgItemMessage(IDC_HEIGHT,	EM_LIMITTEXT, 5, 0);


	m_wndStatusBar.Create(this);
	m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT));
	m_wndStatusBar.SetPaneInfo(m_wndStatusBar.CommandToIndex(
		ID_INDICATOR_X), ID_INDICATOR_X, SBPS_NORMAL, 64);
	m_wndStatusBar.SetPaneInfo(m_wndStatusBar.CommandToIndex(
		ID_INDICATOR_Y), ID_INDICATOR_Y, SBPS_NORMAL, 64);


	SetWindowLong(m_wndToolBar_File.m_hWnd, GWL_ID, IDR_MAINFRAME);
	SetWindowLong(m_wndToolBar_Edit.m_hWnd, GWL_ID, IDR_EDIT);
	SetWindowLong(m_wndDialogBar.m_hWnd, GWL_ID, IDD_DIALOG_BAR);
	SetWindowLong(m_wndCrObjectsBar.m_hWnd, GWL_ID, IDR_CREATE_OBJECTS);

	m_wndDialogBar.SetWindowText("�������� �������");
	m_wndToolBar_File.SetWindowText("����");
	m_wndToolBar_Edit.SetWindowText("������");
	m_wndCrObjectsBar.SetWindowText("������� �������");

	m_wndToolBar_File.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar_Edit.EnableDocking(CBRS_ALIGN_ANY);
	m_wndCrObjectsBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndDialogBar.EnableDocking(CBRS_ALIGN_TOP | CBRS_ALIGN_BOTTOM);

	EnableDocking(CBRS_ALIGN_ANY);
	
	DockControlBar(&m_wndToolBar_File);
	DockControlBar(&m_wndToolBar_Edit);
	DockControlBar(&m_wndDialogBar);
	DockControlBar(&m_wndCrObjectsBar);

	LoadBarState("Local AppWizard-Generated Applications");

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMDIFrameWnd::PreCreateWindow(cs) )
		return FALSE;

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


void CMainFrame::OnClose() 
{
	SaveBarState("Local AppWizard-Generated Applications");

	CMDIFrameWnd::OnClose();
}

void CMainFrame::OnUpdateViewCrobjects(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_wndCrObjectsBar.IsWindowVisible());
}

void CMainFrame::OnViewCrobjects() 
{
	ShowControlBar(&m_wndCrObjectsBar, !m_wndCrObjectsBar.IsWindowVisible(), FALSE);
}

void CMainFrame::OnUpdateObjProperties(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_wndDialogBar.IsWindowVisible());	
}

void CMainFrame::OnObjProperties() 
{
	ShowControlBar(&m_wndDialogBar, !m_wndDialogBar.IsWindowVisible(), FALSE);
}

void CMainFrame::OnViewToolbar() 
{
	ShowControlBar(&m_wndToolBar_File, !m_wndToolBar_File.IsWindowVisible(), FALSE);
}

void CMainFrame::OnUpdateViewToolbar(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_wndToolBar_File.IsWindowVisible());		
}

void CMainFrame::OnViewEdit() 
{
	ShowControlBar(&m_wndToolBar_Edit, !m_wndToolBar_Edit.IsWindowVisible(), FALSE);	
}

void CMainFrame::OnUpdateViewEdit(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_wndToolBar_Edit.IsWindowVisible());		
}


void CMainFrame::OnOptions() 
{
	CDlgOptions dlg;
	
	dlg.m_bDefaultGrid = TRUE;
	dlg.m_bDefaultLabel = TRUE;
	dlg.m_bHaveView = FALSE;

	dlg.DoModal();
}


void CMainFrame::OnKeybShortcuts() 
{
	CDlgShortcuts dlg;
	dlg.DoModal();
}
