// EditorControl.h: interface for the CEditorControl class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EDITORCONTROL_H__82B39CC1_3E60_11D6_929F_CF30D8DD2B35__INCLUDED_)
#define AFX_EDITORCONTROL_H__82B39CC1_3E60_11D6_929F_CF30D8DD2B35__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "EditorObject.h"
#include "TestMoveFrame.h"

class CEditorControl : public CEditorObject  
{
public:
	char m_caption[MAX_NAME];
	BOOL m_bSelected;

public:
	CEditorControl *m_pNextControl;
	CEditorControl *m_pPrevControl;

public:
	BOOL m_bShowTestMove;
	CTestMoveFrame *m_pTestMoveFrame;

	//���������� ������ ������
	int m_x0, m_y0;


public:
	void Select(BOOL bSelect);
	CEditorControl(CEditorDoc *pDoc);
	virtual ~CEditorControl();

	virtual void DrawSelf(CDC *pDC, int ox, int oy);

	virtual void AutoName(char* lpstrNameBase);

	BOOL ReadIntProperty(char* lpstrSource, char* lpstrPropertyName, int *pValue);
	BOOL ReadStrProperty(char *lpstrSource, char *lpstrPropertyName, char *pValue);

	virtual BOOL RestoreFromString(char *lpstrString);
	virtual void Get_HTML_Tag(char *pString);
	virtual void GetSaveString(char *pString);

	virtual BOOL TestMove(int x, int y);
	virtual BOOL TestSize(int x, int y, int w, int h, BOOL bIgnoreSel = FALSE);
};

#endif // !defined(AFX_EDITORCONTROL_H__82B39CC1_3E60_11D6_929F_CF30D8DD2B35__INCLUDED_)
