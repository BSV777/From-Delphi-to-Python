// MyCmdLineInfo.cpp: implementation of the CMyCmdLineInfo class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Editor.h"
#include "MyCmdLineInfo.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMyCmdLineInfo::CMyCmdLineInfo()
{
	m_bDirect_To_HTML = FALSE;
}

CMyCmdLineInfo::~CMyCmdLineInfo()
{

}
