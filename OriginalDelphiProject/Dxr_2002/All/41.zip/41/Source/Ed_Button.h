// Ed_Button.h: interface for the CEd_Button class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ED_BUTTON_H__CFC48FC6_2DE3_11D6_929F_C4FC6DDC883C__INCLUDED_)
#define AFX_ED_BUTTON_H__CFC48FC6_2DE3_11D6_929F_C4FC6DDC883C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "EditorControl.h"

class CEd_Button : public CEditorControl
{
public:
	virtual void Get_HTML_Tag(char* pString);
	virtual BOOL RestoreFromString(char *lpstrString);
	CEd_Button(int x, int y, CEditorDoc *pDoc);
	virtual ~CEd_Button();

	virtual void DrawSelf(CDC *pDC, int ox, int oy);
	virtual void GetSaveString(char *pString);
};

#endif // !defined(AFX_ED_BUTTON_H__CFC48FC6_2DE3_11D6_929F_C4FC6DDC883C__INCLUDED_)
