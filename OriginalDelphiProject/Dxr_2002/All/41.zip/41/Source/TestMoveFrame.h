// TestMoveFrame.h: interface for the CTestMoveFrame class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TESTMOVEFRAME_H__82B39CC0_3E60_11D6_929F_CF30D8DD2B35__INCLUDED_)
#define AFX_TESTMOVEFRAME_H__82B39CC0_3E60_11D6_929F_CF30D8DD2B35__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "EditorObject.h"

class CTestMoveFrame : public CEditorObject  
{
public:
	BOOL m_bVisible;

public:
	CTestMoveFrame(CEditorDoc *pDoc);
	virtual ~CTestMoveFrame();

	void DrawSelf(CDC *pDC, int ox, int oy);
};

#endif // !defined(AFX_TESTMOVEFRAME_H__82B39CC0_3E60_11D6_929F_CF30D8DD2B35__INCLUDED_)
