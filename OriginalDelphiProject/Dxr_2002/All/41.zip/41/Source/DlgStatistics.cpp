// DlgStatistics.cpp : implementation file
//

#include "stdafx.h"
#include "Editor.h"
#include "DlgStatistics.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgStatistics dialog


CDlgStatistics::CDlgStatistics(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgStatistics::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgStatistics)
	m_nButtons = _T("");
	m_nEdits = _T("");
	m_nLabels = _T("");
	m_nObjects = _T("");
	//}}AFX_DATA_INIT

	MessageBeep(MB_ICONASTERISK);
}


void CDlgStatistics::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgStatistics)
	DDX_Text(pDX, IDC_NUM_BUTTON, m_nButtons);
	DDX_Text(pDX, IDC_NUM_EDIT, m_nEdits);
	DDX_Text(pDX, IDC_NUM_LABEL, m_nLabels);
	DDX_Text(pDX, IDC_NUM_OBJECTS, m_nObjects);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgStatistics, CDialog)
	//{{AFX_MSG_MAP(CDlgStatistics)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgStatistics message handlers
