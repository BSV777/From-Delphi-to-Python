// TestMoveFrame.cpp: implementation of the CTestMoveFrame class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Editor.h"
#include "EditorDoc.h"


#include "TestMoveFrame.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTestMoveFrame::CTestMoveFrame(CEditorDoc *pDoc) : CEditorObject(pDoc)
{
	MoveToEnd();
	m_bVisible = FALSE;
}

CTestMoveFrame::~CTestMoveFrame()
{

}

void CTestMoveFrame::DrawSelf(CDC *pDC, int ox, int oy)
{
	if (!m_bVisible) return;

	RECT rtDrawRect = m_rtViewRect;
	OffsetRect(&rtDrawRect, ox, oy);

	pDC->SetTextColor(0x0);
	pDC->DrawFocusRect(&rtDrawRect);
}
