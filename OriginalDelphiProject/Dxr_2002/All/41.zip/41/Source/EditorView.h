// EditorView.h : interface of the CEditorView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_EDITORVIEW_H__21C998F3_2D4D_11D6_929F_AA0B7B26423D__INCLUDED_)
#define AFX_EDITORVIEW_H__21C998F3_2D4D_11D6_929F_AA0B7B26423D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

enum EdMode
{
	EM_SELECT,
	EM_CR_BUTTON,
	EM_CR_TEXTEDIT,
	EM_CR_LABEL
};

class CEditorView : public CScrollView
{
	CDC		m_memDC;
	CBitmap	m_memBitmap;
	CBitmap *m_pOldBitmap;

	BOOL	m_bAllowMenu;
	CMenu	m_Menu;

	BOOL	m_bCtrlUpdateOff;
	EdMode	m_EdMode;

	BOOL	m_bShift;
	BOOL	m_bControl;

	int		m_grid_y;
	int		m_grid_x;
	BOOL	m_bShowGrid;

	UINT	m_OldDocViewState;
	BOOL	m_bActive;

	UINT	m_nTimerId;
	int		m_nAutoScroll_dx;
	int		m_nAutoScroll_dy;

protected: // create from serialization only
	CEditorView();
	DECLARE_DYNCREATE(CEditorView)

// Attributes
public:
	CEditorDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditorView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	virtual void OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView);
	//}}AFX_VIRTUAL

// Implementation
public:
	void EnableAccel(BOOL bEnable);
	void EnableScrollTimer(BOOL bEnable = TRUE);
	void ResizeBackBuffer(int cx, int cy);

	virtual ~CEditorView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CEditorView)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnChangeText();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnChangeLeft();
	afx_msg void OnChangeTop();
	afx_msg void OnChangeHeight();
	afx_msg void OnChangeWidth();
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnExportHtml();
	afx_msg void OnCreateButton();
	afx_msg void OnCreateLabel();
	afx_msg void OnCreateTextedit();
	afx_msg void OnShowGrid();
	afx_msg void OnUpdateShowGrid(CCmdUI* pCmdUI);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnOptions();
	afx_msg void OnDelete();
	afx_msg void OnSelectNone();
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnSelectAll();
	afx_msg void OnSelectInvert();
	afx_msg void OnEditUndo();
	afx_msg void OnUpdateEditUndo(CCmdUI* pCmdUI);
	afx_msg void OnEditRedo();
	afx_msg void OnUpdateEditRedo(CCmdUI* pCmdUI);
	afx_msg void OnEditCopy();
	afx_msg void OnUpdateEditCopy(CCmdUI* pCmdUI);
	afx_msg void OnEditCut();
	afx_msg void OnUpdateEditCut(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDelete(CCmdUI* pCmdUI);
	afx_msg void OnEditPaste();
	afx_msg void OnUpdateEditPaste(CCmdUI* pCmdUI);
	afx_msg void OnEditPasteEx();
	afx_msg void OnDestroy();
	afx_msg void OnAlignPos();
	afx_msg void OnUpdateAlignPos(CCmdUI* pCmdUI);
	afx_msg void OnAlignSize();
	afx_msg void OnUpdateAlignSize(CCmdUI* pCmdUI);
	afx_msg void OnStatistics();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnSetfocusText();
	afx_msg void OnKillfocusText();
	afx_msg void OnKillfocusLeft();
	afx_msg void OnSetfocusLeft();
	afx_msg void OnKillfocusTop();
	afx_msg void OnSetfocusTop();
	afx_msg void OnKillfocusWidth();
	afx_msg void OnSetfocusWidth();
	afx_msg void OnKillfocusHeight();
	afx_msg void OnSetfocusHeight();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in EditorView.cpp
inline CEditorDoc* CEditorView::GetDocument()
   { return (CEditorDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITORVIEW_H__21C998F3_2D4D_11D6_929F_AA0B7B26423D__INCLUDED_)
