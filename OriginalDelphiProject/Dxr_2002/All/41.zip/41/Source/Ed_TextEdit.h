// Ed_TextEdit.h: interface for the CEd_TextEdit class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ED_TEXTEDIT_H__10877E11_2FA6_11D6_929F_A067CE71003F__INCLUDED_)
#define AFX_ED_TEXTEDIT_H__10877E11_2FA6_11D6_929F_A067CE71003F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "EditorControl.h"

#define TEXTEDIT_HEIGHT 20
#define TEXTEDIT_DEFAULT_WIDTH 100

class CEd_TextEdit : public CEditorControl
{
public:
	virtual BOOL TestSize(int x, int y, int w, int h, BOOL bIgnoreSel);
	virtual void Get_HTML_Tag(char *pString);
	virtual BOOL RestoreFromString(char* lpstrString);
	virtual void Move(int x, int y, int width, int height);
	CEd_TextEdit(int x, int y, CEditorDoc *pDoc);
	virtual ~CEd_TextEdit();

	virtual void DrawSelf(CDC *pDC, int ox, int oy);
	virtual void GetSaveString(char *pString);
};

#endif // !defined(AFX_ED_TEXTEDIT_H__10877E11_2FA6_11D6_929F_A067CE71003F__INCLUDED_)
