// DlgShortcuts.cpp : implementation file
//

#include "stdafx.h"
#include "Editor.h"
#include "DlgShortcuts.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgShortcuts dialog


CDlgShortcuts::CDlgShortcuts(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgShortcuts::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgShortcuts)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlgShortcuts::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgShortcuts)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP

	HRSRC hRSrc = FindResource(
		NULL, 
		(LPCTSTR)IDR_TEXT_SHORTCUTS,
		"Text"
	);


	HGLOBAL hGlobal = LoadResource(NULL, hRSrc);
		
	SetDlgItemText(IDC_TEXT, (char *)hGlobal);
}


BEGIN_MESSAGE_MAP(CDlgShortcuts, CDialog)
	//{{AFX_MSG_MAP(CDlgShortcuts)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgShortcuts message handlers
