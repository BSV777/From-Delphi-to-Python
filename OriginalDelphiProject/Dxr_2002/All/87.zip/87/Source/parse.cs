using System;
using System.IO;
using System.Collections;
using System.Text.RegularExpressions;
using Yul.Editor;
public class ElementsParser
{
static Element CreateElement(string name)
{
	switch(name.ToLower())
	{
	case "textedit":
		return new ElementTextEdit();
		break;	
	case "label":
		return new ElementLabel();
		break;	
	case "button":
		return new ElementButton();
		break;	
	}
	return new Element();
}
static Regex r=new Regex("(?:^|(?:\\s*;))\\s*(?<name>[a-zA-Z0-9]+)\\s*=\\s*\\\"(?<term>[^\\\"]*)\\\"",
	 RegexOptions.IgnoreCase|RegexOptions.Compiled);
static IDictionary CreateAttributeList(String term)
{
	Match m=r.Match(term);
	if(!m.Success)
		return null;
	Hashtable table=new Hashtable();
      	for (; m.Success; m = m.NextMatch()) 
      	{
		Console.Write("M ["+m.Groups["name"].Value+","+m.Groups["term"].Value+"]"); 
		table[m.Groups["name"].Value.ToLower()]=m.Groups["term"].Value;
      	}
	return table;
}
  static Element[] CreateMatchingElements(String inputString)
   {
	Element[] list;
      	Regex r;
	r = new Regex("\\<\\s*(?<name>[a-zA-Z0-9]+)(?:\\s+(?<term>[^\\>\\<]*))?\\s*\\>(?<hvost>[^\\>\\<]*)?",
		RegexOptions.IgnoreCase|RegexOptions.Compiled);
	Console.WriteLine("Origin " + inputString);
	MatchCollection m = r.Matches(inputString);
	list=new Element[m.Count];
	
      	for (int i = 0;i<m.Count; i++) 
      	{
		Console.WriteLine("Match"); 
		Element el=CreateElement(m[i].Groups["name"].Value);
		IDictionary  table=CreateAttributeList(m[i].Groups["term"].Value);
		el.ReadFrom(table);
		list[i]=el;
      	}
	return list;
	}
	public static Element[] parse(string file)
	{
		String str;
		StreamReader sr=File.OpenText(file);
		str=sr.ReadToEnd();
		sr.Close();	
		return CreateMatchingElements(str);
		
	}
	public static void Main(string[]args)
	{
		String str;
		if(args.Length>0)
		{
			StreamReader sr=File.OpenText(args[0]);
			str=sr.ReadToEnd();
			sr.Close();	
		}
		else
			str="<Button left=\"10\"; top=\"10\"; height=\"25\"; width=\"100\"; Caption=\"Press me!\"><Label left=\"110\"; top=\"110\"; height =\"20\"; width=\"200\"; Text=\"Look at me!\"> ";
		Element[]els=CreateMatchingElements(str);
			Console.WriteLine("");
		for(int i=0;i<els.Length;i++)
			Console.WriteLine("["+i+"]="+els[i].write());
	}
}