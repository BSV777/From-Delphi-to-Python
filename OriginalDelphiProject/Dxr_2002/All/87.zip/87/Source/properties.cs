namespace Yul
{
namespace Editor
{
using System;
using System.Drawing;
using System.Windows.Forms;
using System.Reflection;

public class PropertyDialog:Form
{
	public PropertyDialog(Element element,Control el)
	{
		Rectangle basicPosition=el.RectangleToScreen(new Rectangle(el.Location,el.Size));
		Text="�������� ������� �������";
		Point p=new Point(basicPosition.Left,basicPosition.Top);
		if(p.Y<0) p.Y=0;
		if(p.X<0) p.X=0;
		DesktopLocation=p;
		Size=new Size(310,stringHeight*5+60);
		Button cancel=new Button();
		cancel.Location=new Point(230,stringHeight*3);
		cancel.Size=new Size(70,20);
		cancel.DialogResult=DialogResult.Cancel;
		cancel.Text="��������";
		Controls.Add(cancel);
		AddElementProperties(element);
	}
	int stringHeight=30;
	private void AddProperty(string Name, string Value, int num)
	{
		Label name=new Label();
		name.Location=new Point(10,num*stringHeight+20);
		name.Text=Name;
		name.Size=new Size(100,20);
		Controls.Add(name);
		TextBox value=new TextBox();
		value.Location=new Point(110,num*stringHeight+15);
		value.Text=Value;
		value.Size=new Size(100,20);
		Controls.Add(value);
	}
	private void AddElementProperties(Element el)
	{
		Type t=el.GetType();
		PropertyInfo[]info=t.GetProperties();
		int i=0;
		foreach(PropertyInfo p in info)
		{
	            	Object[] myAttributes = p.GetCustomAttributes(false);
            		if(myAttributes.Length > 0)
            		{
               			for(int j = 0; j < myAttributes.Length; j++)
					if(myAttributes[j] is ElementAttribute)
					{
						ElementAttribute attr=(ElementAttribute)myAttributes[j];
						AddProperty(attr.Name,p.GetValue(el,null).ToString(),i++);
					}
            		}
         			
		}
	}
}
}
}