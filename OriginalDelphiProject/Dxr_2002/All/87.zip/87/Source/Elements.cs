namespace Yul
{
namespace Editor
{
using System;
using System.Collections;
using System.Drawing;
using System.Windows.Forms;
public class ElementControl:Control
{
	public Element element;
	public ElementControl(Element elm)
	{
		element=elm;
		Text="elm";
		BackColor=element.BackGroundColor;
		ResizeRedraw=true;
		Size=new Size(element.Width,element.Height);
		//UserPaint=true;
	}
	protected override void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
    
	   	ControlPaint.DrawSizeGrip(e.Graphics, BackColor,Size.Width-15,Size.Height-15,15,15);
		ControlPaint.DrawBorder(e.Graphics, ClientRectangle, element.BorderColor, element.BorderStyle);

	    	// Draw string to screen.
    		//e.Graphics.DrawString(Text, Font, new SolidBrush(ForeColor),ClientRectangle);
		element.draw(e.Graphics,ClientRectangle,Font);
	}
	Sides sideMove=Sides.Empty;
	bool changePosition=false;
	public enum Sides{Empty=0,N=1,W=2,E=4,S=8,NW=3,NE=5,SE=12,SW=10};
	const int delta=5;
	public static Cursor SidesCursor(Sides s)
	{
		switch(s)
		{
		case Sides.S: 
		case Sides.N: return Cursors.SizeNS;
		case Sides.E:
		case Sides.W: return Cursors.SizeWE;
		case Sides.NW:
		case Sides.SE: return Cursors.SizeNWSE;
		case Sides.NE: 
		case Sides.SW: return Cursors.SizeNESW;
		}
		return Cursors.Default;
	}
	protected bool BorderClick(Rectangle area,Point point)
	{
		if(area.Right-point.X<delta)
			sideMove=Sides.E;
		else if(point.X-area.X<delta)
			sideMove=Sides.W;
		if(area.Bottom-point.Y<delta)
			sideMove|=Sides.S;
		else if(point.Y-area.Y<delta)
			sideMove|=Sides.N;
		if(sideMove==Sides.Empty)
			return false;

		Cursor=SidesCursor(sideMove);
		return  true;
	}
	Point downPosition=new Point(0,0);
	protected override void OnMouseDown(MouseEventArgs e)//���������� � ������������� ��� ��������� �������
	{
		base.OnMouseDown(e);
		changePosition=false;
		sideMove=Sides.Empty;
		Capture=true;
		if(!BorderClick(ClientRectangle,new Point(e.X,e.Y)))
		{
			changePosition=true;//�����������
			Cursor=Cursors.Hand;
			downPosition=new Point(e.X,e.Y);
		}
	}
/*	protected override void OnMouseEnter(EventArgs e)//� ������ �������������??
	{
		base.OnMouseEnter(e);
	}
	protected override void OnMouseHover(EventArgs e)
	{
		base.OnMouseHover(e);
	}
	protected override void OnMouseLeave(EventArgs e)
	{
		base.OnMouseLeave(e);
	}
	protected override void OnMouseMove(MouseEventArgs e)//������ ������ �� ������������
	{
		base.OnMouseMove(e);
	}
*/
	protected override void OnKeyPress(KeyPressEventArgs e)
	{
		base.OnKeyPress(e);
		PropertyDialog dialog=new PropertyDialog(element, this);
		dialog.ShowDialog();
//		if(dialog.DialogResult==DialogResult.OK);
	}

	protected void EndProccess()
	{
		Capture=false;
		Cursor=Cursors.Default;
		changePosition=false;
		sideMove=Sides.Empty;
	}
	public interface ICheck
	{
		bool CheckPosition(Rectangle check, ElementControl el);
	}
	protected bool Change(int Left,int Top,int Width,int Height)
	{
		int saveLeft=element.Left;
		int saveTop= element.Top;
		int saveWidth=element.Width;
		int saveHeight=element.Height;
		element.Left=Left;
		element.Top= Top;
		element.Width=Width;
		element.Height=Height;
		Rectangle check=new Rectangle(element.Left,element.Top,
				element.Width,element.Height);
		bool allowedPosition=((ICheck)Parent).CheckPosition(check,this);
		//MessageBox.Show("Position"+Left+","+Top+";"+Width+","+Height+" "+allowedPosition);
		if(!allowedPosition)
		{
			element.Left=saveLeft;
			element.Top=saveTop;
			element.Width=saveWidth;
			element.Height=saveHeight;
		}
		Location=new Point(element.Left,element.Top);
		Size=new Size(element.Width,element.Height);

		return allowedPosition;
	}
	protected override void OnMouseUp(MouseEventArgs e)//��������� � ���������
	{
		base.OnMouseUp(e);
		int dx=e.X-downPosition.X;
		int dy=e.Y-downPosition.Y;

		if(changePosition==true)
		{       
			Change(element.Left+dx,element.Top+dy,element.Width,element.Height);
		}else if(sideMove!=Sides.Empty)
                {       //���������� ���������� ��������� ������� � �������� location+size
			switch(sideMove)
			{
			case Sides.S: 
				Change(element.Left,   element.Top,   element.Width,   e.Y);
				break;
			case Sides.N: 
				Change(element.Left,   element.Top+e.Y,element.Width,   element.Height-e.Y);
				break;
			case Sides.E:
				Change(element.Left,   element.Top,    e.X,             element.Height   );
				break;
			case Sides.W: 
				Change(element.Left+e.X,element.Top,   element.Width-e.X,element.Height   );
				break;
			case Sides.NW:
				Change(element.Left+e.X,element.Top+e.Y,element.Width-e.X,element.Height-e.Y);
				break;
			case Sides.SE:
				Change(element.Left,   element.Top,    e.X,              e.Y);
				break;
			case Sides.NE: 
				Change(element.Left,   element.Top+e.Y,e.X,              element.Height-e.Y);
				break;
			case Sides.SW:
				Change(element.Left+e.X,element.Top,   element.Width-e.X,e.Y);
				break;
			}
		}
		EndProccess();
	}
}
public class ElementTextEdit:Element
{
        string text="";
	[ElementAttribute("�����")]
	public string Text
	{
		get {
			if(text=="")
				return "TextEdit";
			return text;
		}
		set{
			text=value;
		}
	}
	[ElementAttribute("������")]
	public override int Height
	{
		get {
			return 20;
		}
		set{
		}
	}
	public override void ReadFrom(IDictionary group)
	{
		base.ReadFrom(group);
		Text=(string)group["text"];
	}
	public override string record()
	{
		string result=Attributes();
		if(text!="")
		{
	  		result+=(result=="")?"":(";") + " Text="+"\""+Text+"\"";
		}
		return "<TextEdit"+result+">";
	}
	public override Color BackGroundColor{get{return Color.White;} }
	public override ButtonBorderStyle BorderStyle{get{return ButtonBorderStyle.Solid;} }
	public override void draw(Graphics e,Rectangle r,Font f)
	{
	    	// Draw string to screen.
		StringFormat format=new StringFormat();
		format.LineAlignment=StringAlignment.Center;
		format.Alignment=StringAlignment.Near;
    		e.DrawString(Text, f, new SolidBrush(Color.Black),r,format);
	}
}
public class ElementButton:Element
{
        string text="";
	[ElementAttribute("���������")]
	public string Caption
	{
		get {
			if(text==""||text==null)
				return "Button";
			return text;
		}
		set{
			text=value;
		}
	}
	public override Color BackGroundColor{get{return Color.Gray;} }
	public override ButtonBorderStyle BorderStyle{get{return ButtonBorderStyle.Outset;} }
	public override void ReadFrom(IDictionary group)
	{
		base.ReadFrom(group);
		Caption=(string)group["caption"];
	}
	public override string record()
	{
		string result=Attributes();
		if(text!="")
		{
	  		result+=(result=="")?"":(";") + " Caption="+"\""+Caption+"\"";
		}
		return "<Button"+result+">";
	}
	public override void draw(Graphics e,Rectangle r,Font f)
	{
	    	// Draw string to screen.
		StringFormat format=new StringFormat();
		format.LineAlignment=StringAlignment.Center;
		format.Alignment=StringAlignment.Center;
    		e.DrawString(Caption, f, new SolidBrush(Color.Black),r,format);
	}
}
public class ElementLabel:Element
{
	public override Color BackGroundColor{get{return Color.Gray;} }
	public override ButtonBorderStyle BorderStyle{get{return ButtonBorderStyle.None;} }
        string text="";
	[ElementAttribute("�����")]
	public string Text
	{
		get {
			if(text=="")
				return "Label";
			return text;
		}
		set{
			text=value;
		}
	}
	public override void ReadFrom(IDictionary group)
	{
		base.ReadFrom(group);
		Text=(string)group["text"];
	}
	public override string record()
	{
		string result=Attributes();
		if(text!="")
		{
	  		result+=(result=="")?"":(";") + " Text="+"\""+Text+"\"";
		}
		return "<Label"+result+">";
	}
	public override void draw(Graphics e,Rectangle r,Font f)
	{
	    	// Draw string to screen.
		StringFormat format=new StringFormat();
		format.LineAlignment=StringAlignment.Center;
		format.Alignment=StringAlignment.Near;
    		e.DrawString(Text, f, new SolidBrush(Color.Black),r,format);
	}

}
}
}