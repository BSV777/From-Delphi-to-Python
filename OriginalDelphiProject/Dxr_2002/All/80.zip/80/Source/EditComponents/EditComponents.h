
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 5.03.0280 */
/* at Sun Mar 17 20:43:18 2002
 */
/* Compiler settings for C:\Projects\ATL\EditComponents\EditComponents.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32 (32b run), ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __EditComponents_h__
#define __EditComponents_h__

/* Forward Declarations */ 

#ifndef __IMyEdit_FWD_DEFINED__
#define __IMyEdit_FWD_DEFINED__
typedef interface IMyEdit IMyEdit;
#endif 	/* __IMyEdit_FWD_DEFINED__ */


#ifndef __IMyButton_FWD_DEFINED__
#define __IMyButton_FWD_DEFINED__
typedef interface IMyButton IMyButton;
#endif 	/* __IMyButton_FWD_DEFINED__ */


#ifndef __IMyLabel_FWD_DEFINED__
#define __IMyLabel_FWD_DEFINED__
typedef interface IMyLabel IMyLabel;
#endif 	/* __IMyLabel_FWD_DEFINED__ */


#ifndef __MyEdit_FWD_DEFINED__
#define __MyEdit_FWD_DEFINED__

#ifdef __cplusplus
typedef class MyEdit MyEdit;
#else
typedef struct MyEdit MyEdit;
#endif /* __cplusplus */

#endif 	/* __MyEdit_FWD_DEFINED__ */


#ifndef __MyButton_FWD_DEFINED__
#define __MyButton_FWD_DEFINED__

#ifdef __cplusplus
typedef class MyButton MyButton;
#else
typedef struct MyButton MyButton;
#endif /* __cplusplus */

#endif 	/* __MyButton_FWD_DEFINED__ */


#ifndef __MyLabel_FWD_DEFINED__
#define __MyLabel_FWD_DEFINED__

#ifdef __cplusplus
typedef class MyLabel MyLabel;
#else
typedef struct MyLabel MyLabel;
#endif /* __cplusplus */

#endif 	/* __MyLabel_FWD_DEFINED__ */


#ifndef __MyButtonPropPage_FWD_DEFINED__
#define __MyButtonPropPage_FWD_DEFINED__

#ifdef __cplusplus
typedef class MyButtonPropPage MyButtonPropPage;
#else
typedef struct MyButtonPropPage MyButtonPropPage;
#endif /* __cplusplus */

#endif 	/* __MyButtonPropPage_FWD_DEFINED__ */


#ifndef __MyEditPropPage_FWD_DEFINED__
#define __MyEditPropPage_FWD_DEFINED__

#ifdef __cplusplus
typedef class MyEditPropPage MyEditPropPage;
#else
typedef struct MyEditPropPage MyEditPropPage;
#endif /* __cplusplus */

#endif 	/* __MyEditPropPage_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IMyEdit_INTERFACE_DEFINED__
#define __IMyEdit_INTERFACE_DEFINED__

/* interface IMyEdit */
/* [unique][helpstring][dual][uuid][object] */ 

#define	DISPID_EDTTEXT	( 1 )


EXTERN_C const IID IID_IMyEdit;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("C3107E3E-2D06-11D6-B72D-00D0B728548D")
    IMyEdit : public IDispatch
    {
    public:
        virtual /* [requestedit][bindable][helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Text( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [requestedit][bindable][helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Text( 
            /* [in] */ BSTR newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IMyEditVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IMyEdit __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IMyEdit __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IMyEdit __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IMyEdit __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IMyEdit __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IMyEdit __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IMyEdit __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [requestedit][bindable][helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Text )( 
            IMyEdit __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [requestedit][bindable][helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Text )( 
            IMyEdit __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        END_INTERFACE
    } IMyEditVtbl;

    interface IMyEdit
    {
        CONST_VTBL struct IMyEditVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IMyEdit_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IMyEdit_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IMyEdit_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IMyEdit_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IMyEdit_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IMyEdit_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IMyEdit_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IMyEdit_get_Text(This,pVal)	\
    (This)->lpVtbl -> get_Text(This,pVal)

#define IMyEdit_put_Text(This,newVal)	\
    (This)->lpVtbl -> put_Text(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [requestedit][bindable][helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IMyEdit_get_Text_Proxy( 
    IMyEdit __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IMyEdit_get_Text_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [requestedit][bindable][helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IMyEdit_put_Text_Proxy( 
    IMyEdit __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IMyEdit_put_Text_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IMyEdit_INTERFACE_DEFINED__ */


#ifndef __IMyButton_INTERFACE_DEFINED__
#define __IMyButton_INTERFACE_DEFINED__

/* interface IMyButton */
/* [unique][helpstring][dual][uuid][object] */ 

#define	DISPID_BTNCAPTION	( 1 )


EXTERN_C const IID IID_IMyButton;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("C3107E3F-2D06-11D6-B72D-00D0B728548D")
    IMyButton : public IDispatch
    {
    public:
        virtual /* [requestedit][bindable][helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Caption( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [requestedit][bindable][helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Caption( 
            /* [in] */ BSTR newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IMyButtonVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IMyButton __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IMyButton __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IMyButton __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IMyButton __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IMyButton __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IMyButton __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IMyButton __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [requestedit][bindable][helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Caption )( 
            IMyButton __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [requestedit][bindable][helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Caption )( 
            IMyButton __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        END_INTERFACE
    } IMyButtonVtbl;

    interface IMyButton
    {
        CONST_VTBL struct IMyButtonVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IMyButton_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IMyButton_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IMyButton_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IMyButton_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IMyButton_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IMyButton_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IMyButton_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IMyButton_get_Caption(This,pVal)	\
    (This)->lpVtbl -> get_Caption(This,pVal)

#define IMyButton_put_Caption(This,newVal)	\
    (This)->lpVtbl -> put_Caption(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [requestedit][bindable][helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IMyButton_get_Caption_Proxy( 
    IMyButton __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IMyButton_get_Caption_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [requestedit][bindable][helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IMyButton_put_Caption_Proxy( 
    IMyButton __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IMyButton_put_Caption_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IMyButton_INTERFACE_DEFINED__ */


#ifndef __IMyLabel_INTERFACE_DEFINED__
#define __IMyLabel_INTERFACE_DEFINED__

/* interface IMyLabel */
/* [unique][helpstring][dual][uuid][object] */ 

#define	DISPID_LBLTEXT	( 2 )


EXTERN_C const IID IID_IMyLabel;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("4D331417-2F5F-11D6-B72D-00D0B728548D")
    IMyLabel : public IDispatch
    {
    public:
        virtual /* [requestedit][bindable][helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Text( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [requestedit][bindable][helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Text( 
            /* [in] */ BSTR newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IMyLabelVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IMyLabel __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IMyLabel __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IMyLabel __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IMyLabel __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IMyLabel __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IMyLabel __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IMyLabel __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [requestedit][bindable][helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Text )( 
            IMyLabel __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [requestedit][bindable][helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Text )( 
            IMyLabel __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        END_INTERFACE
    } IMyLabelVtbl;

    interface IMyLabel
    {
        CONST_VTBL struct IMyLabelVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IMyLabel_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IMyLabel_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IMyLabel_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IMyLabel_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IMyLabel_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IMyLabel_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IMyLabel_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IMyLabel_get_Text(This,pVal)	\
    (This)->lpVtbl -> get_Text(This,pVal)

#define IMyLabel_put_Text(This,newVal)	\
    (This)->lpVtbl -> put_Text(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [requestedit][bindable][helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IMyLabel_get_Text_Proxy( 
    IMyLabel __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IMyLabel_get_Text_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [requestedit][bindable][helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IMyLabel_put_Text_Proxy( 
    IMyLabel __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IMyLabel_put_Text_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IMyLabel_INTERFACE_DEFINED__ */



#ifndef __EDITCOMPONENTSLib_LIBRARY_DEFINED__
#define __EDITCOMPONENTSLib_LIBRARY_DEFINED__

/* library EDITCOMPONENTSLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_EDITCOMPONENTSLib;

EXTERN_C const CLSID CLSID_MyEdit;

#ifdef __cplusplus

class DECLSPEC_UUID("C3107E30-2D06-11D6-B72D-00D0B728548D")
MyEdit;
#endif

EXTERN_C const CLSID CLSID_MyButton;

#ifdef __cplusplus

class DECLSPEC_UUID("C3107E40-2D06-11D6-B72D-00D0B728548D")
MyButton;
#endif

EXTERN_C const CLSID CLSID_MyLabel;

#ifdef __cplusplus

class DECLSPEC_UUID("4D331418-2F5F-11D6-B72D-00D0B728548D")
MyLabel;
#endif

EXTERN_C const CLSID CLSID_MyButtonPropPage;

#ifdef __cplusplus

class DECLSPEC_UUID("B4689941-31AF-11D6-B72D-00D0B728548D")
MyButtonPropPage;
#endif

EXTERN_C const CLSID CLSID_MyEditPropPage;

#ifdef __cplusplus

class DECLSPEC_UUID("569AAC67-3656-43C6-8C03-69548F35E909")
MyEditPropPage;
#endif
#endif /* __EDITCOMPONENTSLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


