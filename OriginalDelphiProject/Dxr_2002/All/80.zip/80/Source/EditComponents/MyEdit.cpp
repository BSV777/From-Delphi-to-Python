// MyEdit.cpp : Implementation of CMyEdit

#include "stdafx.h"
#include "EditComponents.h"
#include "MyEdit.h"

/////////////////////////////////////////////////////////////////////////////
// CMyEdit


STDMETHODIMP CMyEdit::get_Text(BSTR *pVal)
{
	if (NULL == pVal) return E_POINTER;

	*pVal = m_bstrText.Copy();

	return S_OK;
}

STDMETHODIMP CMyEdit::put_Text(BSTR newVal)
{
	if (newVal == m_bstrText) return S_OK;
	
	if (!m_nFreezeEvents)
		if (FireOnRequestEdit(DISPID_EDTTEXT) == S_FALSE)
			return S_FALSE;

	m_bstrText = newVal;

	m_bRequiresSave = TRUE;
	if (!m_nFreezeEvents)
		FireOnChanged(DISPID_EDTTEXT);

	FireViewChange();
	SendOnDataChange(NULL);
		
	return S_OK;
}
