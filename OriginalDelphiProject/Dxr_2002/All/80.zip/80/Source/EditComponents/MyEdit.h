// MyEdit.h : Declaration of the CMyEdit

#ifndef __MYEDIT_H_
#define __MYEDIT_H_

#include "resource.h"       // main symbols
#include <atlctl.h>

/////////////////////////////////////////////////////////////////////////////
// CMyEdit
class ATL_NO_VTABLE CMyEdit : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CStockPropImpl<CMyEdit, IMyEdit, &IID_IMyEdit, &LIBID_EDITCOMPONENTSLib>,
	public CComControl<CMyEdit>,
	public IPersistStreamInitImpl<CMyEdit>,
	public IOleControlImpl<CMyEdit>,
	public IOleObjectImpl<CMyEdit>,
	public IOleInPlaceActiveObjectImpl<CMyEdit>,
	public IViewObjectExImpl<CMyEdit>,
	public IOleInPlaceObjectWindowlessImpl<CMyEdit>,
	public IPersistPropertyBagImpl<CMyEdit>,
	public IPersistStorageImpl<CMyEdit>,
	public ISpecifyPropertyPagesImpl<CMyEdit>,
	public IQuickActivateImpl<CMyEdit>,
	public IDataObjectImpl<CMyEdit>,
	public IObjectSafetyImpl<CMyEdit, INTERFACESAFE_FOR_UNTRUSTED_CALLER |
                                        INTERFACESAFE_FOR_UNTRUSTED_DATA>,
	public IProvideClassInfo2Impl<&CLSID_MyEdit, NULL, &LIBID_EDITCOMPONENTSLib>,
	public CComCoClass<CMyEdit, &CLSID_MyEdit>
{
public:
	CContainedWindow m_ctlEdit;

	CMyEdit() :	
		m_ctlEdit(_T("Edit"), this, 1)
	{
		m_bWindowOnly = TRUE;
		m_bstrText = CComBSTR("TextEdit Control");
		
	}

DECLARE_REGISTRY_RESOURCEID(IDR_MYEDIT)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CMyEdit)
	COM_INTERFACE_ENTRY(IMyEdit)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IViewObjectEx)
	COM_INTERFACE_ENTRY(IViewObject2)
	COM_INTERFACE_ENTRY(IViewObject)
	COM_INTERFACE_ENTRY(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceObject)
	COM_INTERFACE_ENTRY2(IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY(IOleControl)
	COM_INTERFACE_ENTRY(IOleObject)
	COM_INTERFACE_ENTRY(IPersistStreamInit)
	COM_INTERFACE_ENTRY2(IPersist, IPersistStreamInit)
	COM_INTERFACE_ENTRY(ISpecifyPropertyPages)
	COM_INTERFACE_ENTRY(IQuickActivate)
	COM_INTERFACE_ENTRY(IPersistStorage)
	COM_INTERFACE_ENTRY(IPersistPropertyBag)
	COM_INTERFACE_ENTRY(IDataObject)
	// Object Safety support
    COM_INTERFACE_ENTRY(IObjectSafety)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY(IProvideClassInfo2)
END_COM_MAP()

BEGIN_PROP_MAP(CMyEdit)
	PROP_DATA_ENTRY("_cx", m_sizeExtent.cx, VT_UI4)
	PROP_DATA_ENTRY("_cy", m_sizeExtent.cy, VT_UI4)
	PROP_ENTRY("Text", DISPID_EDTTEXT, CLSID_MyEditPropPage)
	// Example entries
	// PROP_ENTRY("Property Description", dispid, clsid)
	// PROP_PAGE(CLSID_StockColorPage)
END_PROP_MAP()

BEGIN_MSG_MAP(CMyEdit)
	MESSAGE_HANDLER(WM_CREATE, OnCreate)
	MESSAGE_HANDLER(WM_SETFOCUS, OnSetFocus)
	CHAIN_MSG_MAP(CComControl<CMyEdit>)
ALT_MSG_MAP(1)
	MESSAGE_HANDLER(WM_KEYUP, OnKeyUp)
	// Replace this with message map entries for superclassed Edit
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	BOOL PreTranslateAccelerator(LPMSG pMsg, HRESULT& hRet)
	{
		if(pMsg->message == WM_KEYDOWN && 
			(pMsg->wParam == VK_LEFT || 
			pMsg->wParam == VK_RIGHT ||
			pMsg->wParam == VK_UP ||
			pMsg->wParam == VK_DOWN))
		{
			hRet = S_FALSE;
			return TRUE;
		}
		//TODO: Add your additional accelerator handling code here
		return FALSE;
	}

	LRESULT OnSetFocus(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		LRESULT lRes = CComControl<CMyEdit>::OnSetFocus(uMsg, wParam, lParam, bHandled);
		if (m_bInPlaceActive)
		{
			DoVerbUIActivate(&m_rcPos,  NULL);
			if(!IsChild(::GetFocus()))
				m_ctlEdit.SetFocus();
		}
		return lRes;
	}

	LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		USES_CONVERSION;
		RECT rc;
		GetWindowRect(&rc);
		rc.right -= rc.left;
		rc.bottom -= rc.top;
		rc.top = rc.left = 0;
//		m_ctlEdit.Create(m_hWnd, rc);
		m_ctlEdit.Create(m_hWnd, rc, OLE2CT(m_bstrText.m_str), WS_CHILD | WS_VISIBLE);
		return 0;
	}
	STDMETHOD(SetObjectRects)(LPCRECT prcPos,LPCRECT prcClip)
	{
		IOleInPlaceObjectWindowlessImpl<CMyEdit>::SetObjectRects(prcPos, prcClip);
		int cx, cy;
		cx = prcPos->right - prcPos->left;
		cy = prcPos->bottom - prcPos->top;
		::SetWindowPos(m_ctlEdit.m_hWnd, NULL, 0,
			0, cx, cy, SWP_NOZORDER | SWP_NOACTIVATE);

		if (m_bInPlaceActive)
			m_ctlEdit.SetFont(AtlGetStockFont(DEFAULT_GUI_FONT));

		return S_OK;
	}

	HRESULT OnDraw(ATL_DRAWINFO& di)
	{
		USES_CONVERSION;
		HDC hdc  = di.hdcDraw;
		RECT& rc = *(RECT*)di.prcBounds;

		if (!m_bInPlaceActive)
		{

			HBRUSH backBrush = ::CreateSolidBrush(GetSysColor(COLOR_WINDOW));
			ATLASSERT (NULL != backBrush);

			int s = ::FillRect (hdc, &rc, backBrush);
			ATLASSERT (0 != s);

			HFONT hFont	= ::CreateFont(
									3, 0, 0, 0, FW_NORMAL,
									FALSE,FALSE,FALSE,ANSI_CHARSET,
									OUT_DEFAULT_PRECIS,
									CLIP_DEFAULT_PRECIS,
									DEFAULT_QUALITY,DEFAULT_PITCH,
									_T("Ms Sans Serif")
								);

			ATLASSERT( 0 != hFont);

			HFONT  hOldFont  = (HFONT)::SelectObject(hdc,hFont);
			LPCTSTR pszText = OLE2CT(m_bstrText.m_str);

			::SetBkMode(hdc, TRANSPARENT); 

			::DrawText(hdc,pszText,lstrlen(pszText),&rc, DT_TOP | DT_LEFT | DT_EDITCONTROL);

			::SelectObject(hdc,hOldFont);
			::DeleteObject(hFont);
			::DeleteObject(backBrush);
		}
		else
		{
			m_ctlEdit.SetWindowText(OLE2CT(m_bstrText.m_str));
		}
		return S_OK;

	}

	LRESULT OnKeyUp(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		switch (wParam)
		{
		case VK_RETURN:
			{
				int len = m_ctlEdit.GetWindowTextLength() + 1;
				LPTSTR pbuf = (LPTSTR) calloc(len, sizeof(TCHAR));
				m_ctlEdit.GetWindowText(pbuf, len);
				put_Text(CComBSTR(pbuf));
				free(pbuf);
				
			}
		case VK_ESCAPE:
			{
				FireViewChange();
				SendOnDataChange(NULL);
			}
		}

		bHandled = FALSE;
		return 1;
	}


// IViewObjectEx
	DECLARE_VIEW_STATUS(VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE)

// IMyEdit
public:
	STDMETHOD(get_Text)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Text)(/*[in]*/ BSTR newVal);
	CComBSTR  m_bstrText;
};

#endif //__MYEDIT_H_
