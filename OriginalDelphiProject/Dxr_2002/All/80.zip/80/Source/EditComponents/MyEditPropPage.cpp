// MyEditPropPage.cpp : Implementation of CMyEditPropPage
#include "stdafx.h"
#include "EditComponents.h"
#include "MyEditPropPage.h"

/////////////////////////////////////////////////////////////////////////////
// CMyEditPropPage

//
// Helper functions
//////////////////////////////////////////////////////////////

void CMyEditPropPage::InitializeControlsFromObject(DISPID dispid)
{
	// The array already contains IMyEdit* ...
	USES_CONVERSION;
	
	switch(typeObj)
	{
	case EDIT_OBJECT:
		{
			CComQIPtr<IMyEdit> pMyEdit = m_ppUnk[0];
			if (DISPID_EDTTEXT == dispid || DISPID_UNKNOWN == dispid)
			{

				// Get Text property
				HRESULT hr = pMyEdit->get_Text(&m_bstrTextOrig);
				ATLASSERT (SUCCEEDED (hr));

				m_bstrTextNew = m_bstrTextOrig;

				if (IsWindow())
				{
					SetDlgItemText(IDC_TEXT, OLE2CT(m_bstrTextOrig.m_str));
				}
			}
		}
		break;
	case LABEL_OBJECT:
		{
			CComQIPtr<IMyLabel> pMyLabel = m_ppUnk[0];
			if (DISPID_EDTTEXT == dispid || DISPID_UNKNOWN == dispid)
			{
				// Get Text property
				HRESULT hr = pMyLabel->get_Text(&m_bstrTextOrig);
				ATLASSERT (SUCCEEDED (hr));

				m_bstrTextNew = m_bstrTextOrig;

				if (IsWindow())
				{
					SetDlgItemText(IDC_TEXT, OLE2CT(m_bstrTextOrig.m_str));
				}
			}
			break;
		}
	default:
		return;
	}

}

void CMyEditPropPage::CleanupObjectArray()
{

    // Free existing array of objects, if any
    if (m_ppUnk != NULL && m_nObjects > 0) 
	{
        for (UINT i = 0; i < m_nObjects; i++) 
		{
            if (NULL == m_ppUnk[i]) break;
            // Unadvise the connection
			AtlUnadvise(m_ppUnk[i], IID_IPropertyNotifySink, m_pCookies[i]);
            m_ppUnk[i]->Release();
        }

        delete [] m_ppUnk;
        delete [] m_pCookies;
	}

    // Currently no objects in list
	m_ppUnk    = NULL;
	m_pCookies = NULL;
    m_nObjects = 0;
}

void CMyEditPropPage::SetPropertiesFromControls(DISPID dispid)
{
	// For all objects in array...
    for (UINT i = 0; i < m_nObjects; i++)
	{
		switch (typeObj)
		{
		case EDIT_OBJECT:
			{
				// Get the appropriate interface...
				CComQIPtr<IMyEdit> pEdit = m_ppUnk[i];

				// Update the Text property, if requested and required
				if ((DISPID_EDTTEXT == dispid || DISPID_UNKNOWN == dispid) &&
					m_flags & EDIT_CHANGED) 
				{
					pEdit->put_Text(m_bstrTextNew);
					m_bstrTextOrig = m_bstrTextNew;       // Prop page and property synced
					m_flags &= ~EDIT_CHANGED;          // Clear changed flag
				}
				break;
			}
		case LABEL_OBJECT:
			{
				// Get the appropriate interface...
				CComQIPtr<IMyLabel> pLabel = m_ppUnk[i];

				// Update the Text property, if requested and required
				if ((DISPID_LBLTEXT == dispid || DISPID_UNKNOWN == dispid) &&
					m_flags & LABEL_CHANGED) 
				{
					pLabel->put_Text(m_bstrTextNew);
					m_bstrTextOrig = m_bstrTextNew;       // Prop page and property synced
					m_flags &= ~LABEL_CHANGED;          // Clear changed flag
				}
				break;
			}
		default:
			break;
		}

	}
}

//
// IPropertyPage2 implementation
/////////////////////////////////////////////////////////////////////////////
STDMETHODIMP CMyEditPropPage::Activate(HWND hWndParent, LPCRECT pRect, BOOL bModal)
{
	ATLTRACE(_T("CMyEditPropPage::Activate\n"));
	HRESULT hr = IPropertyPage2Impl<CMyEditPropPage>::Activate(hWndParent, pRect, bModal);
	return hr;
}


STDMETHODIMP CMyEditPropPage::Apply()
{
	ATLTRACE(_T("CMyEditPropPage::Apply\n"));

	SetPropertiesFromControls(DISPID_UNKNOWN);
    m_bDirty = FALSE;
    
	return S_OK;
}


STDMETHODIMP CMyEditPropPage::EditProperty(DISPID dispid)
{
	ATLTRACE(_T("CMyEditPropPage::EditProperty\n"));

    m_EditProperty = dispid;

    if (IsWindow())
	{
        switch (dispid)
		{
        case DISPID_EDTTEXT:
            ::SetFocus(GetDlgItem (IDC_TEXT));
            break;
		case DISPID_LBLTEXT:
			::SetFocus(GetDlgItem (IDC_TEXT));
            break;
        default:
            return E_INVALIDARG;
        }
    }
    return S_OK;
}


STDMETHODIMP CMyEditPropPage::SetObjects(ULONG cObjects, IUnknown** ppUnk)
{

	ATLTRACE2(atlTraceControls,2,_T("CMyEditPropPage::SetObjects\n"));

	if (ppUnk == NULL) return E_POINTER;

    CleanupObjectArray();

    // Allocate new object array, make connections, and save cookies... 
    if (cObjects > 0)
	{
        // Allocate object array
        ATLTRY(m_ppUnk = new LPUNKNOWN[cObjects]);
        if (m_ppUnk == NULL) return E_OUTOFMEMORY;

        // Allocate connection cookies
        ATLTRY(m_pCookies = new DWORD[cObjects]);
        if (m_pCookies == NULL) 
		{
            delete [] m_ppUnk;
            m_ppUnk = NULL;
            return E_OUTOFMEMORY;
        }

        // Make a connection to each object's connection point
        for (UINT i = 0; i < cObjects; i++)
		{
            // Ensure object supports the default interface...
            // We need this interface to send changes back to object
			// First iteration...
            HRESULT hr = ppUnk[i]->QueryInterface (IID_IMyEdit, (void**)&m_ppUnk[i]);
			if (FAILED(hr))
			{
				HRESULT hr = ppUnk[i]->QueryInterface (IID_IMyLabel, (void**)&m_ppUnk[i]);
				if (FAILED(hr))
					return hr;

				typeObj = LABEL_OBJECT;
			
			}
			else
			{
				typeObj = EDIT_OBJECT;
			}

            // Establish a connection point from object to our sink...
            // We need this to receive change notifications from the object
			// both objects have this interface
            hr = AtlAdvise(m_ppUnk[i],
                           static_cast<IPropertyNotifySink*>(this),
					       IID_IPropertyNotifySink,
                           &m_pCookies[i]);
        }
    }
    m_nObjects = cObjects;

    ////////////////////////////////////////////////////////////
    // Transfer properties from first object to property page //

    InitializeControlsFromObject (DISPID_UNKNOWN);

    return S_OK;
}


//
// IPropertyNotifySink
//////////////////////////////////////////////////////////////////////////////////
STDMETHODIMP CMyEditPropPage::OnChanged(DISPID dispid)
{
	InitializeControlsFromObject (dispid);
    return S_OK;
}

STDMETHODIMP CMyEditPropPage::OnRequestEdit(DISPID dispid)
{
	return S_OK;
}

LRESULT CMyEditPropPage::OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled)
{
	InitializeControlsFromObject (DISPID_UNKNOWN);
    return 0;
}

LRESULT CMyEditPropPage::OnChangeText(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL &bHandled)
{
	TCHAR szText[256];
	int nLength = GetDlgItemText(IDC_TEXT, szText, 255);
	m_bstrTextNew = szText;

	switch(typeObj)
	{
	case EDIT_OBJECT:
		{
			if (m_bstrTextNew.m_str != m_bstrTextOrig.m_str)
				m_flags |= EDIT_CHANGED;
			else
				m_flags &= ~EDIT_CHANGED;

			break;
		}
	case LABEL_OBJECT:
		{
			if (m_bstrTextNew.m_str != m_bstrTextOrig.m_str)
				m_flags |= LABEL_CHANGED;
			else
				m_flags &= ~LABEL_CHANGED;

			break;
		}
	}

	return 0;
}







