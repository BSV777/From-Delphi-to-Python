// MyButton.h : Declaration of the CMyButton

#ifndef __MYBUTTON_H_
#define __MYBUTTON_H_

#include "resource.h"       // main symbols
#include <atlctl.h>
//#include "utility.h"

/////////////////////////////////////////////////////////////////////////////
// CMyButton
class ATL_NO_VTABLE CMyButton : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CStockPropImpl<CMyButton, IMyButton, &IID_IMyButton, &LIBID_EDITCOMPONENTSLib>,
	public CComControl<CMyButton>,
	public IPersistStreamInitImpl<CMyButton>,
	public IOleControlImpl<CMyButton>,
	public IOleObjectImpl<CMyButton>,
	public IOleInPlaceActiveObjectImpl<CMyButton>,
	public IViewObjectExImpl<CMyButton>,
	public IOleInPlaceObjectWindowlessImpl<CMyButton>,
	public IPersistPropertyBagImpl<CMyButton>,
	public IPersistStorageImpl<CMyButton>,
	public ISpecifyPropertyPagesImpl<CMyButton>,
	public IQuickActivateImpl<CMyButton>,
	public IDataObjectImpl<CMyButton>,
	public IObjectSafetyImpl<CMyButton, INTERFACESAFE_FOR_UNTRUSTED_CALLER |
                                        INTERFACESAFE_FOR_UNTRUSTED_DATA>,
	public IProvideClassInfo2Impl<&CLSID_MyButton, NULL, &LIBID_EDITCOMPONENTSLib>,
//	public CProxy_IBullsEyeEvents<CMyButton>,
	public IPropertyNotifySinkCP<CMyButton>,
	public CComCoClass<CMyButton, &CLSID_MyButton>
	
{
public:
	CContainedWindow m_ctlButton;
	BOOL m_bRequiresSave;
	

	CMyButton() :	
		m_ctlButton(_T("Button"), this, 1)
	{
		m_bWindowOnly = TRUE;
		m_bRequiresSave = FALSE;
//		m_bstrCaption = CComBSTR("Button Control");
	
	}

	HRESULT FinalConstruct ();

DECLARE_REGISTRY_RESOURCEID(IDR_MYBUTTON)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CMyButton)
	COM_INTERFACE_ENTRY(IMyButton)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IViewObjectEx)
	COM_INTERFACE_ENTRY(IViewObject2)
	COM_INTERFACE_ENTRY(IViewObject)
	COM_INTERFACE_ENTRY(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceObject)
	COM_INTERFACE_ENTRY2(IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY(IOleControl)
	COM_INTERFACE_ENTRY(IOleObject)
	COM_INTERFACE_ENTRY(IPersistStreamInit)
	COM_INTERFACE_ENTRY2(IPersist, IPersistStreamInit)
	COM_INTERFACE_ENTRY(ISpecifyPropertyPages)
	COM_INTERFACE_ENTRY(IQuickActivate)
	COM_INTERFACE_ENTRY(IPersistStorage)
	COM_INTERFACE_ENTRY(IPersistPropertyBag)
	COM_INTERFACE_ENTRY(IDataObject)
	// Object Safety support
    COM_INTERFACE_ENTRY(IObjectSafety)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY(IProvideClassInfo2)
END_COM_MAP()

BEGIN_PROP_MAP(CMyButton)
//	PROP_DATA_ENTRY("_cx", m_sizeExtent.cx, VT_UI4)
//	PROP_DATA_ENTRY("_cy", m_sizeExtent.cy, VT_UI4)
	PROP_ENTRY("Caption", DISPID_BTNCAPTION, CLSID_MyButtonPropPage)
	PROP_DATA_ENTRY("_cx", m_sizeExtent.cx, VT_UI4)
	PROP_DATA_ENTRY("_cy", m_sizeExtent.cy, VT_UI4)
	// Example entries
	// PROP_ENTRY("Property Description", dispid, clsid)
	// PROP_PAGE(CLSID_StockColorPage)
END_PROP_MAP()


/*BEGIN_CONNECTION_POINT_MAP(CMyButton)
	CONNECTION_POINT_ENTRY(IID_IPropertyNotifySink)
END_CONNECTION_POINT_MAP()*/



BEGIN_MSG_MAP(CMyButton)
	MESSAGE_HANDLER(WM_CREATE, OnCreate)
	MESSAGE_HANDLER(WM_SETFOCUS, OnSetFocus)
	CHAIN_MSG_MAP(CComControl<CMyButton>)
ALT_MSG_MAP(1)
	// Replace this with message map entries for superclassed Button
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);


	LRESULT OnSetFocus(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		LRESULT lRes = CComControl<CMyButton>::OnSetFocus(uMsg, wParam, lParam, bHandled);
		if (m_bInPlaceActive)
		{
			DoVerbUIActivate(&m_rcPos,  NULL);
			if(!IsChild(::GetFocus()))
				m_ctlButton.SetFocus();
		}
		return lRes;
	}

	LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		USES_CONVERSION;
		RECT rc;
		GetWindowRect(&rc);
		rc.right -= rc.left;
		rc.bottom -= rc.top;
		rc.top = rc.left = 0;
		m_ctlButton.Create(m_hWnd, rc);
		return 0;
	}

/*	LRESULT OnUpdate(UINT, WPARAM, LPARAM, BOOL& )
	{
//		USES_CONVERSION;
//		m_ctlButton.SetWindowText( OLE2CT(m_bstrCaption.m_str));
	}*/


	STDMETHOD(SetObjectRects)(LPCRECT prcPos,LPCRECT prcClip)
	{
		IOleInPlaceObjectWindowlessImpl<CMyButton>::SetObjectRects(prcPos, prcClip);
		int cx, cy;
		cx = prcPos->right - prcPos->left;
		cy = prcPos->bottom - prcPos->top;
		::SetWindowPos(m_ctlButton.m_hWnd, NULL, 0,
			0, cx, cy, SWP_NOZORDER | SWP_NOACTIVATE);

		USES_CONVERSION;
		if (m_bInPlaceActive)
		{
			m_ctlButton.SetFont(AtlGetStockFont(DEFAULT_GUI_FONT));
			m_ctlButton.SetWindowText(OLE2CT(m_bstrCaption.m_str));
		}
		return S_OK;
	}

	HRESULT OnDraw(ATL_DRAWINFO& di)
	{
		USES_CONVERSION;
		HRESULT hr;
		CRect rc = *(RECT*)di.prcBounds;
		HDC hdc  = di.hdcDraw;

		if (!m_bInPlaceActive)
		{

			HFONT hFont	= ::CreateFont(
									3, 0, 0, 0, FW_NORMAL,
									FALSE,FALSE,FALSE,ANSI_CHARSET,
									OUT_DEFAULT_PRECIS,
									CLIP_DEFAULT_PRECIS,
									DEFAULT_QUALITY,DEFAULT_PITCH,
									_T("Ms Sans Serif")
								);

			HBRUSH backBrush = ::CreateSolidBrush(GetSysColor(COLOR_BTNFACE));
			ATLASSERT (NULL != backBrush);

			int s = ::FillRect (hdc, &rc, backBrush);
			ATLASSERT (0 != s);

			HPEN hPen = ::CreatePen(PS_SOLID, 3, RGB(255,255,255));
			HPEN hPenOld = (HPEN)::SelectObject(hdc, hPen);
			::MoveToEx(hdc,rc.left, rc.bottom,NULL);
			::LineTo(hdc, rc.left, rc.top);
			::LineTo(hdc, rc.right, rc.top);
			::SelectObject(hdc,hPenOld);
			::DeleteObject(hPen);

			hPen = ::CreatePen(PS_SOLID,3,GetSysColor(COLOR_3DSHADOW));
//			hPen = ::CreatePen(PS_SOLID, 3, RGB(0,0,0));
			hPenOld = (HPEN)::SelectObject(hdc, hPen);
			::MoveToEx(hdc,rc.left, rc.bottom,NULL);
			::LineTo(hdc, rc.right, rc.bottom);
			::LineTo(hdc, rc.right, rc.top);
			::SelectObject(hdc,hPenOld);
			::DeleteObject(hPen);

			
			HFONT  hOldFont  = (HFONT)::SelectObject(hdc,hFont);
			LPCTSTR pszText = OLE2CT(m_bstrCaption.m_str);

			::SetBkMode(hdc, TRANSPARENT); 
			::DrawText(hdc,pszText,lstrlen(pszText),&rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE );
			::SelectObject(hdc,hOldFont);	
			::DeleteObject(hFont);
			::DeleteObject(backBrush);
		}
		else
		{
			m_ctlButton.SetWindowText(OLE2CT(m_bstrCaption.m_str));
		}
		return S_OK;
	}

// IViewObjectEx
	DECLARE_VIEW_STATUS(VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE)

// IMyButton
public:
	STDMETHOD(get_Caption)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Caption)(/*[in]*/ BSTR newVal);
	CComBSTR  m_bstrCaption;

};

#endif //__MYBUTTON_H_
