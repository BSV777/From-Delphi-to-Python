// MyButtonPropPage.h : Declaration of the CMyButtonPropPage

#ifndef __MYBUTTONPROPPAGE_H_
#define __MYBUTTONPROPPAGE_H_

#include "resource.h"       // main symbols

EXTERN_C const CLSID CLSID_MyButtonPropPage;

/////////////////////////////////////////////////////////////////////////////
// CMyButtonPropPage
class ATL_NO_VTABLE CMyButtonPropPage :
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMyButtonPropPage, &CLSID_MyButtonPropPage>,
	public IPropertyPage2Impl<CMyButtonPropPage>,
	public CDialogImpl<CMyButtonPropPage>,
	public IPropertyNotifySink
{
	DISPID m_EditProperty;
	LPDWORD m_pCookies;								// Array of connection tokens used by
												    // IConnectionPoint::Advise/Unadvise.
	short                       m_flags;            // Change flags
	CComBSTR					m_bstrCaptionOrig;
	CComBSTR					m_bstrCaptionNew;
	enum {BTNCAPTION_CHANGED = 1};
public:
	CMyButtonPropPage() 
	{
		m_dwTitleID = IDS_TITLEMyButtonPropPage;
		m_dwHelpFileID = IDS_HELPFILEMyButtonPropPage;
		m_dwDocStringID = IDS_DOCSTRINGMyButtonPropPage;
	}
	~CMyButtonPropPage()
	{
		CleanupObjectArray();
	}

	enum {IDD = IDD_MYBUTTONPROPPAGE};
	
DECLARE_REGISTRY_RESOURCEID(IDR_MYBUTTONPROPPAGE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CMyButtonPropPage) 
	COM_INTERFACE_ENTRY(IPropertyPage)
	COM_INTERFACE_ENTRY_IMPL(IPropertyPage2)
	COM_INTERFACE_ENTRY(IPropertyNotifySink)
END_COM_MAP()

BEGIN_MSG_MAP(CMyButtonPropPage)
	CHAIN_MSG_MAP(IPropertyPageImpl<CMyButtonPropPage>)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	COMMAND_HANDLER(IDC_CAPTION, EN_CHANGE, OnChangeCaption)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

// IPropertyPage2
	STDMETHODIMP Activate(HWND hWndParent, LPCRECT pRect, BOOL /* bModal */);
	STDMETHODIMP Apply(void);
    STDMETHODIMP EditProperty(DISPID dispID);
    STDMETHODIMP SetObjects(ULONG nObjects, IUnknown** ppUnk);

// IPropertyNotifySink
    STDMETHODIMP OnChanged(DISPID dispid);
    STDMETHODIMP OnRequestEdit(DISPID dispid);

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnChangeCaption(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	
protected:

	// helper functions
	void InitializeControlsFromObject(DISPID dispid);
    void SetPropertiesFromControls(DISPID dispid);
	void CleanupObjectArray();
};

#endif //__MYBUTTONPROPPAGE_H_
