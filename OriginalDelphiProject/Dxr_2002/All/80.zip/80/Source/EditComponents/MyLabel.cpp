// MyLabel.cpp : Implementation of CMyLabel

#include "stdafx.h"
#include "EditComponents.h"
#include "MyLabel.h"

/////////////////////////////////////////////////////////////////////////////
// CMyLabel


HRESULT CMyLabel::FinalConstruct()
{
	FreezeEvents (TRUE);
	put_Text(CComBSTR("Label Control"));
	FreezeEvents (FALSE);
	return S_OK;

}


STDMETHODIMP CMyLabel::get_Text(BSTR *pVal)
{
	if (NULL == pVal) return E_POINTER;

	*pVal = m_bstrText.Copy();

	return S_OK;
}

STDMETHODIMP CMyLabel::put_Text(BSTR newVal)
{
	if (newVal == m_bstrText) return S_OK;
	
	if (!m_nFreezeEvents)
		if (FireOnRequestEdit(DISPID_LBLTEXT) == S_FALSE)
			return S_FALSE;

	m_bstrText = newVal;

	m_bRequiresSave = TRUE;
	if (!m_nFreezeEvents)
		FireOnChanged(DISPID_LBLTEXT);

	FireViewChange();
	SendOnDataChange(NULL);
		
	return S_OK;
}

HRESULT CMyLabel::OnDraw(ATL_DRAWINFO& di)
{
//	HRESULT hr;
	USES_CONVERSION;
	HDC hdc  = di.hdcDraw;
	RECT& rc = *(RECT*)di.prcBounds;

	if (!m_bInPlaceActive)
	{
		
		HFONT hFont	= ::CreateFont(
									3, 0, 0, 0, FW_NORMAL,
									FALSE,FALSE,FALSE,DEFAULT_CHARSET,
									OUT_DEFAULT_PRECIS,
									CLIP_DEFAULT_PRECIS,
									DEFAULT_QUALITY,DEFAULT_PITCH,
									_T("Ms Sans Serif")
								);

		ATLASSERT (0 != hFont);

		HBRUSH backBrush = ::CreateSolidBrush(GetSysColor(COLOR_BTNFACE));
		ATLASSERT (NULL != backBrush);

		int s = ::FillRect (hdc, &rc, backBrush);
		ATLASSERT (0 != s);

		HFONT  hOldFont  = (HFONT)::SelectObject(hdc,hFont);
		LPCTSTR pszText = OLE2CT(m_bstrText.m_str);

		::SetBkMode(hdc, TRANSPARENT); 

		::DrawText(hdc,pszText,lstrlen(pszText),&rc, DT_TOP 
													| DT_LEFT | DT_EDITCONTROL );

		::SelectObject(hdc,hOldFont);
		DeleteObject(backBrush);
		DeleteObject(hFont);

	}
	else
	{
		m_ctlStatic.SetWindowText(OLE2CT(m_bstrText.m_str));
	}
	return S_OK;

}
