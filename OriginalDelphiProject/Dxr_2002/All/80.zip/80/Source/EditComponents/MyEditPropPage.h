// MyEditPropPage.h : Declaration of the CMyEditPropPage

#ifndef __MYEDITPROPPAGE_H_
#define __MYEDITPROPPAGE_H_

#include "resource.h"       // main symbols

EXTERN_C const CLSID CLSID_MyEditPropPage;

/////////////////////////////////////////////////////////////////////////////
// CMyEditPropPage
class ATL_NO_VTABLE CMyEditPropPage :
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMyEditPropPage, &CLSID_MyEditPropPage>,
	public IPropertyPage2Impl<CMyEditPropPage>,
	public CDialogImpl<CMyEditPropPage>,
	public IPropertyNotifySink
{
	DISPID m_EditProperty;
	LPDWORD m_pCookies;								// Array of connection tokens used by
												    // IConnectionPoint::Advise/Unadvise.
	short                       m_flags;            // Change flags
	CComBSTR					m_bstrTextOrig;
	CComBSTR					m_bstrTextNew;
	enum {NONE_OBJECT = 0, EDIT_OBJECT = 1, LABEL_OBJECT = 2} typeObj;
	enum {EDIT_CHANGED = 1, LABEL_CHANGED = 2};
public:
	CMyEditPropPage() 
	{
		m_dwTitleID = IDS_TITLEMyEditPropPage;
		m_dwHelpFileID = IDS_HELPFILEMyEditPropPage;
		m_dwDocStringID = IDS_DOCSTRINGMyEditPropPage;
		typeObj = NONE_OBJECT;
	}

	enum {IDD = IDD_MYEDITPROPPAGE};

DECLARE_REGISTRY_RESOURCEID(IDR_MYEDITPROPPAGE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CMyEditPropPage) 
	COM_INTERFACE_ENTRY(IPropertyPage)
	COM_INTERFACE_ENTRY_IMPL(IPropertyPage2)
	COM_INTERFACE_ENTRY(IPropertyNotifySink)
END_COM_MAP()

BEGIN_MSG_MAP(CMyEditPropPage)
	CHAIN_MSG_MAP(IPropertyPageImpl<CMyEditPropPage>)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	COMMAND_HANDLER(IDC_TEXT, EN_CHANGE, OnChangeText)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	// IPropertyPage2
	STDMETHODIMP Activate(HWND hWndParent, LPCRECT pRect, BOOL /* bModal */);
	STDMETHODIMP Apply(void);
    STDMETHODIMP EditProperty(DISPID dispID);
    STDMETHODIMP SetObjects(ULONG nObjects, IUnknown** ppUnk);

	// IPropertyNotifySink
    STDMETHODIMP OnChanged(DISPID dispid);
    STDMETHODIMP OnRequestEdit(DISPID dispid);

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnChangeText(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
protected:
	// helper functions
	void InitializeControlsFromObject(DISPID dispid);
    void SetPropertiesFromControls(DISPID dispid);
	void CleanupObjectArray();
};

#endif //__MYEDITPROPPAGE_H_
