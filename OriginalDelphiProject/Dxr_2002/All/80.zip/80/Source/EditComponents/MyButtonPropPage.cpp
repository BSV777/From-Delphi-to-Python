// MyButtonPropPage.cpp : Implementation of CMyButtonPropPage
#include "stdafx.h"
#include "EditComponents.h"
#include "MyButtonPropPage.h"

/////////////////////////////////////////////////////////////////////////////
// CMyButtonPropPage

//
// Helper functions
//////////////////////////////////////////////////////////////

void CMyButtonPropPage::InitializeControlsFromObject(DISPID dispid)
{
	// The array already contains IMyButton* ...
    CComQIPtr<IMyButton> pMyButton = m_ppUnk[0];
	USES_CONVERSION;

    if (DISPID_BTNCAPTION == dispid || DISPID_UNKNOWN == dispid)
	{

        // Get Caption property
	
        HRESULT hr = pMyButton->get_Caption(&m_bstrCaptionOrig);
        ATLASSERT (SUCCEEDED (hr));

		m_bstrCaptionNew = m_bstrCaptionOrig;

		if (IsWindow())
		{
			SetDlgItemText(IDC_CAPTION, OLE2CT(m_bstrCaptionOrig.m_str));
		}

	}
}

void CMyButtonPropPage::CleanupObjectArray()
{
    // Free existing array of objects, if any
    if (m_ppUnk != NULL && m_nObjects > 0) {
        for (UINT i = 0; i < m_nObjects; i++) {
            if (NULL == m_ppUnk[i]) break;
            // Unadvise the connection
			AtlUnadvise(m_ppUnk[i], IID_IPropertyNotifySink, m_pCookies[i]);
            m_ppUnk[i]->Release();
        }

        delete [] m_ppUnk;
        delete [] m_pCookies;
	}

    // Currently no objects in list
	m_ppUnk    = NULL;
	m_pCookies = NULL;
    m_nObjects = 0;
}


void CMyButtonPropPage::SetPropertiesFromControls(DISPID dispid)
{
	// For all objects in array...
    for (UINT i = 0; i < m_nObjects; i++)
	{
        // Get the appropriate interface...
       CComQIPtr<IMyButton> pButton = m_ppUnk[i];

        // Update the Caption property, if requested and required
        if ((DISPID_BTNCAPTION == dispid || DISPID_UNKNOWN == dispid) &&
            m_flags & BTNCAPTION_CHANGED) 
		{
			pButton->put_Caption(m_bstrCaptionNew);
            m_bstrCaptionOrig = m_bstrCaptionNew;       // Prop page and property synced
            m_flags &= ~BTNCAPTION_CHANGED;             // Clear changed flag
        }
	}
}


//
// IPropertyPage2 implementation
/////////////////////////////////////////////////////////////////////////////
STDMETHODIMP CMyButtonPropPage::Activate(HWND hWndParent, LPCRECT pRect, BOOL bModal)
{
	ATLTRACE(_T("CMyButtonPropPage::Activate\n"));
    HRESULT hr = IPropertyPage2Impl<CMyButtonPropPage>::Activate(hWndParent, pRect, bModal);
	return hr;
}

STDMETHODIMP CMyButtonPropPage::Apply()
{
	ATLTRACE(_T("CMyButtonPropPage::Apply\n"));

	SetPropertiesFromControls(DISPID_UNKNOWN);
    m_bDirty = FALSE;
    
	return S_OK;
}

STDMETHODIMP CMyButtonPropPage::EditProperty(DISPID dispid)
{
	ATLTRACE(_T("CMyButtonPropPage::EditProperty\n"));

    m_EditProperty = dispid;

    if (IsWindow())
	{
        switch (dispid)
		{
        case DISPID_BTNCAPTION:
            ::SetFocus(GetDlgItem (IDC_CAPTION));
            break;
        default:
            return E_INVALIDARG;
        }
    }
    return S_OK;

}

STDMETHODIMP CMyButtonPropPage::SetObjects(ULONG cObjects, IUnknown** ppUnk)
{

	ATLTRACE2(atlTraceControls,2,_T("CMyButtonPropPage::SetObjects\n"));

	if (ppUnk == NULL) return E_POINTER;

    CleanupObjectArray();

    // Allocate new object array, make connections, and save cookies //
   
    if (cObjects > 0)
	{
        // Allocate object array
        ATLTRY(m_ppUnk = new LPUNKNOWN[cObjects]);
        if (m_ppUnk == NULL) return E_OUTOFMEMORY;

        // Allocate connection cookies
        ATLTRY(m_pCookies = new DWORD[cObjects]);
        if (m_pCookies == NULL) 
		{
            delete [] m_ppUnk;
            m_ppUnk = NULL;
            return E_OUTOFMEMORY;
        }

        // Make a connection to each object's connection point
        for (UINT i = 0; i < cObjects; i++)
		{
            // Ensure object supports the default interface...
            // We need this interface to send changes back to object
            HRESULT hr = ppUnk[i]->QueryInterface (IID_IMyButton, (void**)&m_ppUnk[i]);
            if (FAILED(hr)) return hr;

            // Establish a connection point from object to our sink...
            // We need this to receive change notifications from the object
            hr = AtlAdvise(m_ppUnk[i],
                           static_cast<IPropertyNotifySink*>(this),
					       IID_IPropertyNotifySink,
                           &m_pCookies[i]);
//            if (FAILED(hr)) return hr;
        }
    }
    m_nObjects = cObjects;

    ////////////////////////////////////////////////////////////
    // Transfer properties from first object to property page //

    InitializeControlsFromObject (DISPID_UNKNOWN);

    return S_OK;
}

//
// IPropertyNotifySink
//////////////////////////////////////////////////////////////////////////////////
STDMETHODIMP CMyButtonPropPage::OnChanged(DISPID dispid)
{
	InitializeControlsFromObject (dispid);
    return S_OK;
}

STDMETHODIMP CMyButtonPropPage::OnRequestEdit(DISPID dispid)
{
	return S_OK;
}

LRESULT CMyButtonPropPage::OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled)
{
	InitializeControlsFromObject (DISPID_UNKNOWN);
    return 0;
}

LRESULT CMyButtonPropPage::OnChangeCaption(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL &bHandled)
{
	TCHAR szText[256];
	int nLength = GetDlgItemText(IDC_CAPTION, szText, 255);
	m_bstrCaptionNew = szText;
	
	if (m_bstrCaptionNew.m_str != m_bstrCaptionOrig.m_str)
        m_flags |= BTNCAPTION_CHANGED;
    else
        m_flags &= ~BTNCAPTION_CHANGED;

	return 0;
}

