// MyLabel.h : Declaration of the CMyLabel

#ifndef __MYLABEL_H_
#define __MYLABEL_H_

#include "resource.h"       // main symbols
#include <atlctl.h>

/////////////////////////////////////////////////////////////////////////////
// CMyLabel
class ATL_NO_VTABLE CMyLabel : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CStockPropImpl<CMyLabel, IMyLabel, &IID_IMyLabel, &LIBID_EDITCOMPONENTSLib>,
	public CComControl<CMyLabel>,
	public IPersistStreamInitImpl<CMyLabel>,
	public IOleControlImpl<CMyLabel>,
	public IOleObjectImpl<CMyLabel>,
	public IOleInPlaceActiveObjectImpl<CMyLabel>,
	public IViewObjectExImpl<CMyLabel>,
	public IOleInPlaceObjectWindowlessImpl<CMyLabel>,
	public IPersistPropertyBagImpl<CMyLabel>,
	public IPersistStorageImpl<CMyLabel>,
	public ISpecifyPropertyPagesImpl<CMyLabel>,
	public IQuickActivateImpl<CMyLabel>,
	public IDataObjectImpl<CMyLabel>,
	public IObjectSafetyImpl<CMyLabel, INTERFACESAFE_FOR_UNTRUSTED_CALLER |
                                        INTERFACESAFE_FOR_UNTRUSTED_DATA>,
	public IProvideClassInfo2Impl<&CLSID_MyLabel, NULL, &LIBID_EDITCOMPONENTSLib>,
	public ISupportErrorInfo,
	public CComCoClass<CMyLabel, &CLSID_MyLabel>
{
public:
	CContainedWindow m_ctlStatic;

	CMyLabel() :	
		m_ctlStatic(_T("Static"), this, 1)
	{
		m_bWindowOnly = TRUE;

	}

	HRESULT FinalConstruct ();

DECLARE_REGISTRY_RESOURCEID(IDR_MYLABEL)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CMyLabel)
	COM_INTERFACE_ENTRY(IMyLabel)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IViewObjectEx)
	COM_INTERFACE_ENTRY(IViewObject2)
	COM_INTERFACE_ENTRY(IViewObject)
	COM_INTERFACE_ENTRY(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceObject)
	COM_INTERFACE_ENTRY2(IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY(IOleControl)
	COM_INTERFACE_ENTRY(IOleObject)
	COM_INTERFACE_ENTRY(IPersistStreamInit)
	COM_INTERFACE_ENTRY2(IPersist, IPersistStreamInit)
	COM_INTERFACE_ENTRY(ISpecifyPropertyPages)
	COM_INTERFACE_ENTRY(IQuickActivate)
	COM_INTERFACE_ENTRY(IPersistStorage)
	COM_INTERFACE_ENTRY(IPersistPropertyBag)
	COM_INTERFACE_ENTRY(IDataObject)
	// Object Safety support
    COM_INTERFACE_ENTRY(IObjectSafety)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY(IProvideClassInfo2)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

BEGIN_PROP_MAP(CMyLabel)
	PROP_DATA_ENTRY("_cx", m_sizeExtent.cx, VT_UI4)
	PROP_DATA_ENTRY("_cy", m_sizeExtent.cy, VT_UI4)
	PROP_ENTRY("Text", DISPID_LBLTEXT, CLSID_MyEditPropPage)
	// Example entries
	// PROP_ENTRY("Property Description", dispid, clsid)
	// PROP_PAGE(CLSID_StockColorPage)
END_PROP_MAP()

BEGIN_MSG_MAP(CMyLabel)
	MESSAGE_HANDLER(WM_CREATE, OnCreate)
	MESSAGE_HANDLER(WM_SETFOCUS, OnSetFocus)
	CHAIN_MSG_MAP(CComControl<CMyLabel>)
ALT_MSG_MAP(1)
	// Replace this with message map entries for superclassed Static
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);


	LRESULT OnSetFocus(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		LRESULT lRes = CComControl<CMyLabel>::OnSetFocus(uMsg, wParam, lParam, bHandled);
		if (m_bInPlaceActive)
		{
			DoVerbUIActivate(&m_rcPos,  NULL);
			if(!IsChild(::GetFocus()))
				m_ctlStatic.SetFocus();
		}
		return lRes;
	}

	LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		RECT rc;
		GetWindowRect(&rc);
		rc.right -= rc.left;
		rc.bottom -= rc.top;
		rc.top = rc.left = 0;
		m_ctlStatic.Create(m_hWnd, rc);
		return 0;
	}
	STDMETHOD(SetObjectRects)(LPCRECT prcPos,LPCRECT prcClip)
	{
		USES_CONVERSION;
		IOleInPlaceObjectWindowlessImpl<CMyLabel>::SetObjectRects(prcPos, prcClip);
		int cx, cy;
		cx = prcPos->right - prcPos->left;
		cy = prcPos->bottom - prcPos->top;
		::SetWindowPos(m_ctlStatic.m_hWnd, NULL, 0,
			0, cx, cy, SWP_NOZORDER | SWP_NOACTIVATE);
		if (m_bInPlaceActive)
		{
			m_ctlStatic.SetFont(AtlGetStockFont(DEFAULT_GUI_FONT));
			m_ctlStatic.SetWindowText(OLE2CT(m_bstrText.m_str));
		}
		return S_OK;
	}

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid)
	{
		static const IID* arr[] = 
		{
			&IID_IMyLabel,
		};
		for (int i=0; i<sizeof(arr)/sizeof(arr[0]); i++)
		{
			if (InlineIsEqualGUID(*arr[i], riid))
				return S_OK;
		}
		return S_FALSE;
	}

// IViewObjectEx
	DECLARE_VIEW_STATUS(VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE)

// IMyLabel
public:
	STDMETHOD(get_Text)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Text)(/*[in]*/ BSTR newVal);
	HRESULT OnDraw(ATL_DRAWINFO& di);
	CComBSTR  m_bstrText;
};

#endif //__MYLABEL_H_
