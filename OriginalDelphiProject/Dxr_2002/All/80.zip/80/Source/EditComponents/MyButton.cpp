// MyButton.cpp : Implementation of CMyButton

#include "stdafx.h"
#include "EditComponents.h"
#include "MyButton.h"

/////////////////////////////////////////////////////////////////////////////
// CMyButton


STDMETHODIMP CMyButton::get_Caption(BSTR *pVal)
{
	if (NULL == pVal) return E_POINTER;

	*pVal = m_bstrCaption.Copy();

	return S_OK;

}

STDMETHODIMP CMyButton::put_Caption(BSTR newVal)
{
	USES_CONVERSION;

	if (newVal == m_bstrCaption) return S_OK;
	
	if (!m_nFreezeEvents)
		if (FireOnRequestEdit(DISPID_BTNCAPTION) == S_FALSE)
			return S_FALSE;

	m_bstrCaption = newVal;

	m_bRequiresSave = TRUE;
	if (!m_nFreezeEvents)
		FireOnChanged(DISPID_BTNCAPTION);

//	if (m_ctlButton.IsWindow())
//		m_ctlButton.SetWindowText(OLE2CT(m_bstrCaption.m_str));

	FireViewChange();
	SendOnDataChange(NULL);

	m_bRequiresSave = TRUE;
		
	return S_OK;
}

HRESULT CMyButton::FinalConstruct ()
{
	FreezeEvents (TRUE);
	put_Caption(CComBSTR("Button Control"));
	FreezeEvents (FALSE);
	return S_OK;
}