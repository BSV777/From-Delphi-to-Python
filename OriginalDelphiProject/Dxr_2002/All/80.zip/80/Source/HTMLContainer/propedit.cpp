// paredit.cpp: C++ derived edit control for numbers/letters etc
//
// This is a part of the Microsoft Foundation Classes C++ library.
// Copyright (C) 1992-1998 Microsoft Corporation
// All rights reserved.
//
// This source code is only intended as a supplement to the
// Microsoft Foundation Classes Reference and related
// electronic documentation provided with the library.
// See these sources for detailed information regarding the
// Microsoft Foundation Classes product.

#include "stdafx.h"
#include "htmlcontainer.h"
#include "propedit.h"
#include "PropertiesView.h"

/////////////////////////////////////////////////////////////////////////////
// ParsedEdit

CPropertyEdit::CPropertyEdit()
{
	m_bSubclassed = FALSE;
}

BEGIN_MESSAGE_MAP(CPropertyEdit, CEdit)
	//{{AFX_MSG_MAP(CPropertyEdit)
	ON_WM_KEYUP()
	ON_WM_KEYDOWN()
	ON_WM_SYSCHAR()
	ON_WM_SYSCOMMAND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Creating from C++ code

BOOL CPropertyEdit::Create(DWORD dwStyle, const RECT& rect,
		CWnd* pParentWnd, UINT nID)
{
	// figure out edit control style
	DWORD dwEditStyle = MAKELONG(ES_LEFT, HIWORD(dwStyle));
	return CWnd::Create(_T("EDIT"), NULL, dwEditStyle, rect, pParentWnd, nID);
}

/////////////////////////////////////////////////////////////////////////////
// Aliasing on top of an existing Edit control

BOOL CPropertyEdit::SubclassEdit(UINT nID, CWnd* pParent)
{
	if (!m_bSubclassed)
	{
		m_bSubclassed = TRUE;
		return SubclassDlgItem(nID, pParent);
	}
	else
		return FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// Input character filter

//DEL void CPropertyEdit::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)
//DEL {
//DEL /*	AfxMessageBox("Test");
//DEL 	if ( nChar == VK_RETURN )
//DEL     {
//DEL 		AfxMessageBox("Test");
//DEL         GetParent()->SetFocus();
//DEL 		return;
//DEL     }*/
//DEL 	CEdit::OnChar(nChar, nRepCnt, nFlags);
//DEL }

/////////////////////////////////////////////////////////////////////////////
// Spin controls will send scroll messages

/////////////////////////////////////////////////////////////////////////////

//DEL void CPropertyEdit::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
//DEL {
//DEL 	AfxMessageBox("KeyDown");
//DEL 	if ( nChar == VK_RETURN )
//DEL     {
//DEL 		AfxMessageBox("Test");
//DEL         GetParent()->SetFocus();
//DEL 		return;
//DEL     }
//DEL 	
//DEL 	CEdit::OnKeyDown(nChar, nRepCnt, nFlags);
//DEL }

//DEL void CPropertyEdit::OnSysChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
//DEL {
//DEL 	if ( nChar == VK_RETURN )
//DEL     {
//DEL 		AfxMessageBox("SysChar");
//DEL         GetParent()->SetFocus();
//DEL 		return;
//DEL     }
//DEL 	
//DEL 	CEdit::OnSysChar(nChar, nRepCnt, nFlags);
//DEL }

//DEL void CPropertyEdit::OnSysCommand(UINT nID, LPARAM lParam) 
//DEL {
//DEL 	AfxMessageBox("Test");
//DEL 		
//DEL 	CEdit::OnSysCommand(nID, lParam);
//DEL }

//DEL void CPropertyEdit::OnKillFocus(CWnd* pNewWnd) 
//DEL {
//DEL 	CEdit::OnKillFocus(pNewWnd);
//DEL }

void CPropertyEdit::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	CEdit::OnKeyUp(nChar, nRepCnt, nFlags);

	if ( nChar == VK_RETURN )
    {
		CPropertiesView* pView = (CPropertiesView*)GetParent();
		pView->ChangeProperty();
        SetFocus();
		return;
    }
}

void CPropertyEdit::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CEdit::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CPropertyEdit::OnSysChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	
	CEdit::OnSysChar(nChar, nRepCnt, nFlags);
}

void CPropertyEdit::OnSysCommand(UINT nID, LPARAM lParam) 
{
	// TODO: Add your message handler code here and/or call default
	
	CEdit::OnSysCommand(nID, lParam);
}
