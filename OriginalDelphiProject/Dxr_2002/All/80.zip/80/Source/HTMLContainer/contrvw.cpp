// ContrVw.cpp : implementation of the CHTMLContainerView class
//

#include "stdafx.h"
#include "HTMLContainer.h"

#include "HTMLContainerDoc.h"
#include "CntrItem.h"
#include "ContrVw.h"
#include "MainFrm.h"
#include "PropertiesView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CIntersectTracker

CIntersectTracker::CIntersectTracker(CHTMLContainerDoc* pDoc, CHTMLContainerView* pView, BOOL bTextEdControl)
{
	m_pDoc = pDoc;
	m_pView = pView;

	// variable for checking the state, when we create new
	// TextEdit control...
	m_bTextEditControl = bTextEdControl;
}

CIntersectTracker::~CIntersectTracker()
{

}

void CIntersectTracker::DrawTrackerRect(LPCRECT lpRect, CWnd* pWndClipTo, CDC* pDC, CWnd* pWnd)
{
	CRect rc = *lpRect;
	CHTMLContainerItem* pItem = m_pView->m_pSelection;

	if (!isIntersectRect(m_rect))
	{

		if (pItem)
		{
			if (pItem->m_ntypeObj == TEXT_EDIT )
			{
				if (rc.Height() > DEFAULTHEIGHT || rc.Height() < DEFAULTHEIGHT - 1)
					return;
			}
		}

		CRectTracker::DrawTrackerRect(lpRect, pWndClipTo, pDC, pWnd);
			
		CMainFrame* pFrame = (CMainFrame*)AfxGetApp()->GetMainWnd();
		CString str;
		str.Format("Left: %d", m_rect.left);
		pFrame->m_wndStatusBar.SetPaneText(1,str);
		str.Format("Top: %d", m_rect.top);
		pFrame->m_wndStatusBar.SetPaneText(2,str);
		str.Format("Height: %d",m_rect.Height());
		pFrame->m_wndStatusBar.SetPaneText(3,str);
		str.Format("Width: %d",m_rect.Width());
		pFrame->m_wndStatusBar.SetPaneText(4,str);
	}
}


void CIntersectTracker::OnChangedRect(const CRect& rectOld )
{
	if (isIntersectRect(m_rect))
		m_rect = rectOld;

	CRect rc = m_rect;
	CHTMLContainerItem* pItem = m_pView->m_pSelection;

	if (m_bTextEditControl) // we creating new TextEdit control...
	{
		m_rect.NormalizeRect();
		if (rc.Height() > DEFAULTHEIGHT )
			m_rect = rectOld;
	}

	if (pItem)
	{
		if (pItem->m_ntypeObj == TEXT_EDIT )
		{
			if (rc.Height() > DEFAULTHEIGHT || rc.Height() < DEFAULTHEIGHT - 1)
				m_rect = rectOld;
		}
	}
}

BOOL CIntersectTracker::isIntersectRect(CRect rc)
{
	CRect rect = rc;

	rect.NormalizeRect();

	CClientDC dc(m_pView);
	m_pView->OnPrepareDC(&dc);
	dc.DPtoLP(&rect);

	rect.top    = rect.top - DELTA;
	rect.left   = rect.left - DELTA;
	rect.bottom = rect.bottom + DELTA;
	rect.right  = rect.right + DELTA;

	CHTMLContainerItem* pItemHit = NULL;
	ASSERT_VALID(m_pDoc);


	// let's make boundaries of corners
	if (rect.left <= MAXLEFT || rect.top <= MAXTOP 
				|| rect.bottom >= MAXBOTTOM  || rect.right >= MAXRIGHT )
			return TRUE;
		
	POSITION pos = m_pDoc->GetStartPosition();

	while (pos != NULL)
	{
		CHTMLContainerItem* pItem = (CHTMLContainerItem*)m_pDoc->GetNextItem(pos);
		
		if (pItem == m_pView->m_pSelection)
			continue;

		CRect rectT;
		if (rectT.IntersectRect(rect, pItem->m_rect))
		{
			return TRUE; // return top item at point
		}

	}
	
	return FALSE;
}

void CIntersectTracker::AdjustRect(int nHandle, LPRECT lpRect)
{
	CRectTracker::AdjustRect(nHandle, lpRect);
}

/////////////////////////////////////////////////////////////////////////////
// CHTMLContainerView

IMPLEMENT_DYNCREATE(CHTMLContainerView, CScrollView)

BEGIN_MESSAGE_MAP(CHTMLContainerView, CScrollView)
	//{{AFX_MSG_MAP(CHTMLContainerView)
	ON_WM_SETFOCUS()
	ON_WM_SIZE()
	ON_COMMAND(ID_CANCEL_EDIT_CNTR, OnCancelEditCntr)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_SETCURSOR()
	ON_COMMAND(ID_EDIT_CLEAR, OnEditClear)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CLEAR, OnUpdateEditClear)
	ON_WM_CREATE()
	ON_WM_RBUTTONDOWN()
	ON_COMMAND(ID_ITEM_PROPERTIES, OnItemProperties)
	ON_COMMAND(ID_ITEM_DELETE, OnItemDelete)
	ON_UPDATE_COMMAND_UI(ID_ITEM_DELETE, OnUpdateItemDelete)
	ON_COMMAND(ID_MOVE_DOWN, OnMoveDown)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHTMLContainerView construction/destruction

CHTMLContainerView::CHTMLContainerView()
{
	m_pSelection = NULL;
	m_rcDefault.SetRect(0, 0, 20, 70);
}

CHTMLContainerView::~CHTMLContainerView()
{
}

BOOL CHTMLContainerView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CHTMLContainerView drawing

void CHTMLContainerView::OnDraw(CDC* pDC)
{
	CHTMLContainerDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// draw the OLE items from the list
	POSITION pos = pDoc->GetStartPosition();

	while (pos != NULL)
	{
		// draw the item

		TRACE("m_pSelection = %x\n", this->m_pSelection);
		CHTMLContainerItem* pItem = (CHTMLContainerItem*)pDoc->GetNextItem(pos);

		OnPrepareDC(pDC);
		pItem->Draw(pDC, pItem->m_rect);

		CRectTracker tracker;
		SetupTracker(pItem, &tracker);
		tracker.Draw(pDC);
	}
}

void CHTMLContainerView::OnInitialUpdate()
{
// 	CScrollView::OnInitialUpdate();

	CSize sz = GetDocument()->szDoc;
	CClientDC dc(this);
	sz.cx = MulDiv(sz.cx, dc.GetDeviceCaps(LOGPIXELSX), 100);
	sz.cy = MulDiv(sz.cy, dc.GetDeviceCaps(LOGPIXELSY), 100);
	SetScrollSizes(MM_TEXT, sz);
	int i;

	if ( GetDocument()->m_arrLoadedObjects.GetSize() > 0)
	{
		try
		{
			for (i = 0; i < GetDocument()->m_arrLoadedObjects.GetSize(); i++)
			{
				objElem* pElem = (objElem*)GetDocument()->m_arrLoadedObjects.GetAt(i);
				processLoading(pElem->m_nTypeObject, pElem->rcObject, pElem->strPropertyValue);
			}

			GetDocument()->m_arrLoadedObjects.RemoveAll();

			// Select First Object...
			POSITION pos = GetDocument()->GetStartPosition();
			CHTMLContainerItem* pItem = (CHTMLContainerItem*)GetDocument()->GetNextItem(pos);
			SetSelection(pItem);
		}
		catch(CLoadingException* e)
		{
			CString err;
			TCHAR  szErrMessage[500];
			e->GetErrorMessage(szErrMessage, 400);
			err.Format("������ ����� � ������ %d: %s. ���������� �� ����� ���������! ", i+1, szErrMessage);
			AfxMessageBox(err, MB_OK | MB_ICONERROR);
			e->Delete();
		}
		catch (...)
		{
			AfxMessageBox("������ �������� ��������!", MB_ICONERROR | MB_ICONEXCLAMATION);
			m_pSelection = 0;
		}
	}
	else
	{
		m_pSelection = 0;
	}

	CScrollView::OnInitialUpdate();

}

/////////////////////////////////////////////////////////////////////////////
// CHTMLContainerView printing

BOOL CHTMLContainerView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CHTMLContainerView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CHTMLContainerView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// OLE Client support and commands

BOOL CHTMLContainerView::IsSelected(const CObject* pDocItem) const
{
	// The implementation below is adequate if your selection consists of
	//  only CHTMLContainerItem objects.  To handle different selection
	//  mechanisms, the implementation here should be replaced.

	// TODO: implement this function that tests for a selected OLE client item

	return pDocItem == m_pSelection;
}

// The following command handler provides the standard keyboard
//  user interface to cancel an in-place editing session.  Here,
//  the container (not the server) causes the deactivation.
void CHTMLContainerView::OnCancelEditCntr()
{
	// Close any in-place active item on this view.
	COleClientItem* pActiveItem = GetDocument()->GetInPlaceActiveItem(this);
	if (pActiveItem != NULL)
	{
		pActiveItem->Close();
	}
	ASSERT(GetDocument()->GetInPlaceActiveItem(this) == NULL);
}

// Special handling of OnSetFocus and OnSize are required for a container
//  when an object is being edited in-place.
void CHTMLContainerView::OnSetFocus(CWnd* pOldWnd)
{
	COleClientItem* pActiveItem = GetDocument()->GetInPlaceActiveItem(this);
	if (pActiveItem != NULL &&
		pActiveItem->GetItemState() == COleClientItem::activeUIState)
	{
		// need to set focus to this item if it is in the same view
		CWnd* pWnd = pActiveItem->GetInPlaceWindow();
		if (pWnd != NULL)
		{
			pWnd->SetFocus();   // don't call the base class
			return;
		}
	}

	CScrollView::OnSetFocus(pOldWnd);
}

void CHTMLContainerView::OnSize(UINT nType, int cx, int cy)
{
	CScrollView::OnSize(nType, cx, cy);

	COleClientItem* pActiveItem = GetDocument()->GetInPlaceActiveItem(this);
	if (pActiveItem != NULL)
		pActiveItem->SetItemRects();

}
CHTMLContainerItem* CHTMLContainerView::HitTestItems(CPoint point)
{
	CRect rc;

	CHTMLContainerDoc* pDoc = GetDocument();
	CHTMLContainerItem* pItemHit = NULL;

	POSITION pos = pDoc->GetStartPosition();
	while (pos != NULL)
	{
		CHTMLContainerItem* pItem = (CHTMLContainerItem*)pDoc->GetNextItem(pos);
		rc = pItem->m_rect;
		rc.InflateRect(2,2); // inflate rect a little...
		if (rc.PtInRect(point))
			pItemHit = pItem;
	}

	return pItemHit;    // return top item at point*/

/*	CHTMLContainerDoc* pDoc = GetDocument();
	CHTMLContainerItem* pItemHit = NULL;
	POSITION pos = pDoc->GetStartPosition();
	while (pos != NULL)
	{
		CHTMLContainerItem* pItem = (CHTMLContainerItem*)pDoc->GetNextItem(pos);
		if (pItem->m_rect.PtInRect(point))
			pItemHit = pItem;
	}
	return pItemHit;    // return top item at point*/





}

void CHTMLContainerView::SetSelection(CHTMLContainerItem* pItem)
{
	// close in-place active item
	if (pItem == NULL || m_pSelection != pItem)
	{
		COleClientItem* pActiveItem = GetDocument()->GetInPlaceActiveItem(this);
		if (pActiveItem != NULL && pActiveItem != pItem)
			pActiveItem->Close();
	}

	CHTMLContainerItem* pOldItem = m_pSelection; // saving old item...

//3	if (m_pSelection)						// invalidate the old item
//3		InvalidateItem(m_pSelection);

	if ( (m_pSelection = pItem) != NULL)	// invalidate the new item
		InvalidateItem(m_pSelection);

	if (pOldItem != NULL)
		InvalidateItem(pOldItem);
	
//	Invalidate();
//	m_pSelection = pItem;

	CMainFrame* pFrame = (CMainFrame*)AfxGetApp()->GetMainWnd();

	if (pItem != NULL)
	{
		GetDocument()->OnSelectObject(pItem);
		CMainFrame* pFrame = (CMainFrame*)AfxGetApp()->GetMainWnd();
		pFrame->SetStatusBarInfo(GetDocument()->GetElemName(pItem), pItem->m_rect);
	}
	else
	{
		pFrame->SetStatusBarInfo("", CRect(0,0,0,0));
		pFrame->disablePropertiesBar();
	}
}

void CHTMLContainerView::SetupTracker(CHTMLContainerItem* pItem, CRectTracker* pTracker)
{
	CClientDC dc(this);
	OnPrepareDC(&dc);
	pTracker->m_rect = pItem->m_rect;

//	dc.LPtoDP(trObj.m_rect);
	dc.LPtoDP(pTracker->m_rect);

	if (pItem == m_pSelection)
		pTracker->m_nStyle |= CRectTracker::resizeInside;

	if (pItem->GetType() == OT_LINK)
		pTracker->m_nStyle |= CRectTracker::dottedLine;
	else
		pTracker->m_nStyle |= CRectTracker::solidLine;

	if (pItem->GetItemState() == COleClientItem::openState ||
		pItem->GetItemState() == COleClientItem::activeUIState)
	{
		pTracker->m_nStyle |= CRectTracker::hatchInside;
	}
}


/////////////////////////////////////////////////////////////////////////////
// CHTMLContainerView diagnostics

#ifdef _DEBUG
void CHTMLContainerView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CHTMLContainerView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CHTMLContainerDoc* CHTMLContainerView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CHTMLContainerDoc)));
	return (CHTMLContainerDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CHTMLContainerView message handlers
void CHTMLContainerView::OnLButtonDown(UINT nFlags, CPoint point)
{
	CClientDC dc(this);
	OnPrepareDC(&dc);

	CPoint lpoint = point;

	dc.DPtoLP(&lpoint);

	CHTMLContainerItem* pItemHit = HitTestItems(lpoint);
	SetSelection(pItemHit);

	CRect oldRect;
	
	if (pItemHit != NULL)
	{
		OnPrepareDC(&dc);
		CIntersectTracker tracker(GetDocument(), this);
		SetupTracker(pItemHit, &tracker);

        InvalidateRect(&tracker.m_rect);  //3
		oldRect = tracker.m_rect;
		oldRect.InflateRect(2,2); // make rect a little more large...

		if (tracker.Track(this, point))
		{
			InvalidateRect(&oldRect); //3

			dc.DPtoLP(&tracker.m_rect);
			pItemHit->m_rect = tracker.m_rect;
			InvalidateItem(pItemHit); // 3

			GetDocument()->SetModifiedFlag();
		}

	}
	else
	{
		CMainFrame* pFrame = (CMainFrame*)AfxGetApp()->GetMainWnd();
		CRectTracker* ptracker = NULL;
		BOOL bTextControl = FALSE;

		switch(pFrame->m_nState)
		{
		case 0:
			ptracker = new CRectTracker();
			ASSERT(ptracker != 0);
			break;
		case LABEL:
			break;
		case TEXT_EDIT:
			bTextControl = TRUE;
			break;
		case BUTTON:
			break;
		default:
			break;
		}

		if (!ptracker)
		{
			ptracker = new CIntersectTracker(GetDocument(), this, bTextControl);
			ASSERT(ptracker != 0);
		}

		if (ptracker->TrackRubberBand(this, point, TRUE))
		{
			ptracker->m_rect.NormalizeRect();
			dc.DPtoLP(&ptracker->m_rect);
			processCreation(ptracker->m_rect);
		}

		// if user just press button...
		if (pFrame->m_nState != 0)
		{
			CRect rcPoint;
			rcPoint.SetRect(lpoint.x - 2, lpoint.y - 2, lpoint.x + 2, lpoint.y + 2);
			processCreation(rcPoint);
		}
	}

	CScrollView::OnLButtonDown(nFlags, point);
}

void CHTMLContainerView::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	OnLButtonDown(nFlags, point);

	CClientDC dc(this);
	OnPrepareDC(&dc);
	dc.DPtoLP(&point);

	if (m_pSelection != NULL)
	{
		m_pSelection->DoVerb(GetKeyState(VK_CONTROL) < 0 ?
			OLEIVERB_OPEN : OLEIVERB_PRIMARY, this);
	}

	CScrollView::OnLButtonDblClk(nFlags, point);
}

BOOL CHTMLContainerView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	if (pWnd == this && m_pSelection != NULL)
	{
		// give the tracker for the selection a chance
		CRectTracker tracker;
		SetupTracker(m_pSelection, &tracker);
		if (tracker.SetCursor(this, nHitTest))
			return TRUE;
	}

	return CScrollView::OnSetCursor(pWnd, nHitTest, message);
}

void CHTMLContainerView::OnEditClear()
{
	if (m_pSelection != NULL)
	{
		m_pSelection->Delete();
		m_pSelection = NULL;
		GetDocument()->UpdateAllViews(NULL);
	}
}

void CHTMLContainerView::OnUpdateEditClear(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_pSelection != NULL);

}

BOOL CHTMLContainerView::processCreation(CRect rect)
{
	BOOL  bResult = TRUE;
	TCHAR szName[128] = "";
	CLSID clsid;
	UINT nTypeObj = 0;

	USES_CONVERSION;
	CMainFrame* pFrame = (CMainFrame*)AfxGetApp()->GetMainWnd();
	ASSERT_VALID(pFrame);

	rect.NormalizeRect();
	tryInflateRect(&rect);
	
	CHTMLContainerItem* pItemIntersected = isIntersectWithObject(rect);

	switch(pFrame->m_nState)
	{
	case 0:
		{
			if (pItemIntersected)
				SetSelection(pItemIntersected);

			return TRUE;
		}
	case 1:
		lstrcpy(szName,_T("EditComponents.MyLabel.1"));
		nTypeObj = 1;
		break;
	case 2:
		lstrcpy(szName,_T("EditComponents.MyEdit.1"));
		nTypeObj = 2;
		break;
	case 3:
		lstrcpy(szName,_T("EditComponents.MyButton.1"));
		nTypeObj = 3;
		break;
	}
	
	if (pItemIntersected)
	{
		AfxMessageBox("� ��������� �������������� ��� ���� ������! \n\t ���������� � ������ �����", MB_OK | MB_ICONEXCLAMATION);
	}
	else
	{
	
		BeginWaitCursor();

		CHTMLContainerItem* pItem = NULL;

		TRY
		{
			// Create new item connected to this document.
			CHTMLContainerDoc* pDoc = GetDocument();
			ASSERT_VALID(pDoc);
			pItem = new CHTMLContainerItem(pDoc, rect);
			ASSERT_VALID(pItem);

			CLSIDFromString(T2OLE(szName),&clsid);

			// Initialize the item 
			bResult = pItem->CreateNewItem(clsid);
		
			if (!bResult)
				AfxThrowMemoryException();  // any exception will do

			ASSERT_VALID(pItem);

			pItem->DoVerb(OLEIVERB_SHOW, this);
			pItem->m_ntypeObj = nTypeObj;

			m_pSelection = pItem;   // set selection to last inserted item
			
			pFrame->m_wndStructureBar.SendMessage(WM_USERINSERTOBJECT, (WPARAM)pItem, (LPARAM)pFrame->m_nState);

			CPropertiesView* pPropView = pFrame->m_wndPropertiesBar.GetView();
			pPropView->OnInsertObject(pDoc->m_arrTree.GetSize() - 1);

			OnCancelEditCntr();

//			pDoc->UpdateAllViews(NULL);
			InvalidateItem(pItem);
			GetDocument()->SetModifiedFlag();


		}
		CATCH(CException, e)
		{
			if (pItem != NULL)
			{
				ASSERT_VALID(pItem);
				pItem->Delete();
			}
			AfxMessageBox(IDP_FAILED_TO_CREATE);
		}
		END_CATCH

		EndWaitCursor();
	}

	pFrame->m_nState = 0;

	return TRUE;
}

CHTMLContainerItem* CHTMLContainerView::isIntersectWithObject(CRect rc)
{
	CHTMLContainerDoc* pDoc = GetDocument();
	CHTMLContainerItem* pItemHit = NULL;
	POSITION pos = pDoc->GetStartPosition();

	while (pos != NULL)
	{
		CHTMLContainerItem* pItem = (CHTMLContainerItem*)pDoc->GetNextItem(pos);
		
		if (pItem == m_pSelection)
			continue;

		CRect rectT;
		rc.NormalizeRect();
		if (rectT.IntersectRect(rc, pItem->m_rect))
		{
			pItemHit = pItem;
		}

	}
	
	return pItemHit;
}

void CHTMLContainerView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{

	CClientDC dc(this);
	OnPrepareDC(&dc);

	switch (lHint)
 	{						
 	case UPD_WINDOW:		
		Invalidate();
		break;
	case UPD_ITEM:
	case UPD_DELITEM:
		if ( !pHint || !(pHint->IsKindOf(RUNTIME_CLASS(CHTMLContainerItem))))
			Invalidate();
		else
		{
			InvalidateItem((CHTMLContainerItem*)pHint);
		}
	}
}

int CHTMLContainerView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CScrollView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	CDC* pDC = GetDC();				// ������� ��������� ��������
									// �������� � ���������� �������� ������
	szLogScreen.cx = pDC->GetDeviceCaps(LOGPIXELSX);
	szLogScreen.cy = pDC->GetDeviceCaps(LOGPIXELSY);
	ReleaseDC(pDC);					// ����������� ��������
	
	return 0;
}

BOOL CHTMLContainerView::OnScrollBy(CSize sizeScroll, BOOL bDoScroll) 
{
	CClientDC dc(this);

	if (bDoScroll)
	{							// ����������� ����� ����
		UpdateWindow();
	}
	
		
	return CScrollView::OnScrollBy(sizeScroll, bDoScroll);
}

void CHTMLContainerView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	CClientDC dc(this);
	OnPrepareDC(&dc);

	CPoint lpoint = point;
	dc.DPtoLP(&lpoint);

	CHTMLContainerItem* pItemHit = HitTestItems(lpoint);
	SetSelection(pItemHit);
	
	if (pItemHit != NULL)
	{
		ClientToScreen(&point);
		CMenu menu;
		if (menu.LoadMenu(IDR_CONTEXTMENU))
		{
			menu.GetSubMenu(0)->TrackPopupMenu(TPM_RIGHTBUTTON,point.x,point.y,AfxGetMainWnd());
		}
	}       
	
	CScrollView::OnRButtonDown(nFlags, point);
}

void CHTMLContainerView::OnItemProperties() 
{
	ASSERT(m_pSelection != NULL);
	if (m_pSelection != NULL)
	{
		m_pSelection->DoVerb(OLEIVERB_PROPERTIES, this);
	//	Invalidate();
		InvalidateItem(m_pSelection);
	}
	
}

void CHTMLContainerView::processLoading(UINT nTypeObject, CRect rc, LPCTSTR strProperty)
{
	TCHAR szName[128] = "";
	CLSID clsid;
	
	CMainFrame* pFrame = (CMainFrame*)AfxGetApp()->GetMainWnd();
	ASSERT_VALID(pFrame);

	CPropertiesView* pPropView = pFrame->m_wndPropertiesBar.GetView();
	ASSERT_VALID(pPropView);

	// check intersecting with other objects...
	// if so, then throw an exception...
	if (GetDocument()->isIntersectObject(rc))
	{
		CString error;
		error.Format("������ � ������������: left: %d, top: %d width: %d, height: %d ������������ � ����������� ���������!",
									rc.left, rc.top, rc.Width(), rc.Height());

		throw new CLoadingException((char*)(LPCTSTR)error);
	}

	USES_CONVERSION;
	switch(nTypeObject)
	{
	case LABEL:
		lstrcpy(szName,_T("EditComponents.MyLabel.1"));
		break;
	case TEXT_EDIT:
		lstrcpy(szName,_T("EditComponents.MyEdit.1"));
		break;
	case BUTTON:
		lstrcpy(szName,_T("EditComponents.MyButton.1"));
		break;
	}

	// Create new item connected to this document.
	CHTMLContainerDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CHTMLContainerItem* pItem = new CHTMLContainerItem(pDoc, rc);
	ASSERT_VALID(pItem);

	CLSIDFromString(T2OLE(szName),&clsid);

	// Initialize the item 
	BOOL bResult = pItem->CreateNewItem(clsid);
		
	if (!bResult)
		AfxThrowMemoryException();  // any exception will do

	ASSERT_VALID(pItem);

	pItem->m_ntypeObj = nTypeObject;
	pItem->SetStringValue(strProperty);
	
	pFrame->m_wndStructureBar.SendMessage(WM_USERINSERTOBJECT, (WPARAM)pItem, (LPARAM)nTypeObject);
//	pPropView->OnInsertObject(pDoc->m_arrTree.GetSize() - 1);

//	OnCancelEditCntr();

	//Invalidate();
	InvalidateItem(pItem);

}

void CHTMLContainerView::OnItemDelete() 
{
	if (m_pSelection)
	{
		GetDocument()->OnDeleteItem(m_pSelection);
	}
}

void CHTMLContainerView::OnUpdateItemDelete(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(	m_pSelection  &&  GetDocument()->GetInPlaceActiveItem(this) == NULL);
}

void CHTMLContainerView::tryInflateRect(CRect *prc)
{
	TRACE( "left %d top %d right %d bottom %d \n", prc->left, prc->top, prc->right, prc->bottom);
	TRACE( "Height %d Width %d\n", prc->Height(), prc->Width());
	if (  prc->Height() < DEFAULTHEIGHT || prc->Width() < DEFAULTWIDTH )
	{

		int nX, nY; nX = nY = 0;

		if (prc->Width() < DEFAULTWIDTH)
			nX = int ( ( DEFAULTWIDTH - prc->Width() ) / 2 );

		if (prc->Height() < DEFAULTHEIGHT)
			nY = int ( ( DEFAULTHEIGHT - prc->Height() ) / 2 );


		prc->InflateRect(nX, nY);
		prc->NormalizeRect();
		TRACE( "Now left %d top %d right %d bottom %d \n", prc->left, prc->top, prc->right, prc->bottom);
		TRACE( "Now Height %d Width %d\n", prc->Height(), prc->Width());
	
		// checking the up corner...
		if (prc->left < MAXLEFT || prc->top < MAXTOP)
		{
			if (prc->left < MAXLEFT)
				nX = MAXLEFT + abs(prc->left) + DELTA;
			else
				nX = 0; //nX = prc->left;

			if (prc->top < MAXTOP)
				nY = MAXTOP + abs (prc->top) + DELTA;
			else
				nY = 0; //nY = prc->top;

			prc->OffsetRect(nX, nY);
			TRACE( "Now left %d top %d right %d bottom %d \n", prc->left, prc->top, prc->right, prc->bottom);
		}

		if (prc->right > MAXRIGHT || prc->bottom > MAXBOTTOM)
		{
			if (prc->right > MAXRIGHT)
				nX = - ( prc->right - MAXRIGHT + DELTA);
			else
				nX = 0; // prc->right;

			if (prc->bottom > MAXBOTTOM)
				nY = - ( prc->bottom - MAXBOTTOM + DELTA);
			else
				nY = 0; //prc->bottom;

			prc->OffsetRect(nX, nY);
			TRACE( "Now left %d top %d right %d bottom %d \n", prc->left, prc->top, prc->right, prc->bottom);
		}
	}


}

void CHTMLContainerView::InvalidateItem(CHTMLContainerItem *pItem)
{
	if (m_nMapMode && pItem != NULL)
	{
		CClientDC dc(this);
		OnPrepareDC(&dc);

		pItem->Draw(&dc, pItem->m_rect);

		CRectTracker tracker;
		SetupTracker(pItem, &tracker);
		tracker.Draw(&dc);

		/// was...
/*		CRectTracker r;
		SetupTracker(pItem,&r);
		InvalidateRect(&r.m_rect);*/
	}
}


void CHTMLContainerView::InvalidateOldRect(CRect rc)
{
	CClientDC dc(this);
	OnPrepareDC(&dc);
	
	rc.InflateRect(2,2);
	dc.LPtoDP(&rc);
	InvalidateRect(rc);
}

void CHTMLContainerView::OnMoveDown() 
{
	// I'll make it later...

/*	if (m_pSelection != 0)
	{
		CPoint pt = m_pSelection->m_rect.CenterPoint();
		if (pt != CPoint(0,0))
		{
			pt.Offset(0,5);
			OnLButtonDown(NULL, pt);
			OnLButtonUp(NULL,pt);
		}

	}*/
}
