// HTMLFile.cpp: implementation of the CHTMLFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "htmlcontainer.h"
#include "HTMLFile.h"
#include "HTMLContainerDoc.h"
#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHTMLFile::CHTMLFile()
{
	m_nMinTopPos    = 1000;
	m_nMinLeftPos   = 1000;
	m_nMaxRightPos  = 0;
	m_nMaxBottomPos = 0;

}

CHTMLFile::~CHTMLFile()
{

}

BOOL CHTMLFile::processContainerFile(LPCTSTR lpszPathName)
{
	CString str;
	CStdioFile myFile;
	CParser parser;
	int nStrings = 0;

	try
	{
		myFile.Open( lpszPathName, CFile::modeRead | CFile::typeText);
		while( myFile.ReadString(str)) 
		{
			parser.parseString(str);
			nStrings++;
			addElem(&parser);
			checkForMaxTablePositions(parser.m_rc);
		}
		myFile.Close();
		if (nStrings == 0)
			throw new CParserException("�������� � ����� �� �������!");
	}
	catch (CParserException* e)
	{
		CString err;
		TCHAR  szErrMessage[500];
		e->GetErrorMessage(szErrMessage, 400);
		err.Format("������ ����� � ������ %d: �������� - %s. ���������� �� ����� ���������! ", nStrings, szErrMessage);
		AfxMessageBox(err, MB_OK | MB_ICONERROR);
		e->Delete();
	}
	catch (...)
	{
		CString error;
		error.Format("������ �������� ����� %s", lpszPathName);
		AfxMessageBox(error, MB_OK | MB_ICONERROR);
		return FALSE;
	}

	if (nStrings == 0)
		return FALSE;
	else
		return TRUE;
}

void CHTMLFile::addElem(CParser* parser)
{
	CHTMLElement* pElem = new CHTMLElement();
	
	pElem->m_rcPosition  = parser->m_rc;
	pElem->m_nTypeObject = parser->m_ntypeObj;
	pElem->m_strPropertyValue = (LPCTSTR)parser->m_strValue;

	// We can use both functions (I mean push_back and insert,
	// but last function more quick...
	// listElements.insert(listElements.end(),(*pElem));

	listElements.push_back((*pElem));
}

BOOL CHTMLFile::createOutputFile(LPCTSTR lpszFileName, BOOL bUseActiveX)
{

	CStdioFile  myFile;
	CFileException fileException;
	try
	{
		if ( !myFile.Open( lpszFileName, CFile::modeCreate | CFile::modeReadWrite, &fileException ) )
		{
			CString str;
			str.Format("Can't open file %s, error = %u\n",
			(char*)lpszFileName, fileException.m_cause );

			AfxMessageBox(str);
			return FALSE;
		}

		for(ElementIterator = listElements.begin(); ElementIterator != listElements.end(); ++ElementIterator)
		{
			TRACE("Object: %d, left: %d, top: %d, Value: %s\n",(*ElementIterator).m_nTypeObject,
															 (*ElementIterator).m_rcPosition.left,
															 (*ElementIterator).m_rcPosition.top,
															 (*ElementIterator).m_strPropertyValue);
		}

		CreateHeader(&myFile);
		listElements.sort();
		if (!bUseActiveX)
		{
			optimizeElements();   
			CreateBody(&myFile, bUseActiveX);
		}
		else
			CreateBody2(&myFile);

	}
	catch(...)
	{
		CString error;
		error.Format("������ �������� ����� %s", lpszFileName);
		AfxMessageBox(error, MB_OK | MB_ICONERROR);
		return FALSE;
	}

	return TRUE;
}

void CHTMLFile::CreateHeader(CStdioFile *pFile)
{
	CString str;

	str.Format("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\"\n \
        \"http://www.w3.org/TR/html4/strict.dtd\">\n");

	pFile->WriteString(str);

	str.Format("<HTML>\n<HEAD>\n \
    <META NAME=\"GENERATOR\" Content=\"HTMLContainer\">\n \
    <META HTTP-EQUIV=\"Content-Type\" content=\"text/html\">\n \
    <TITLE>%s</TITLE>\n</HEAD>\n", (LPCTSTR)pFile->GetFilePath());

	pFile->WriteString(str);
}

void CHTMLFile::CreateBody(CStdioFile *pFile, BOOL bUseActiveX)
{
	CPoint nDisabled;  // x - nuber  columns disabled
					   // y - number rows disabled
	
	CPoint  ptHTMLPos(int(COLUMNWIDTH / 4),int (ROWHEIGHT / 4));

	CString str;
	
	str.Format("<BODY BGCOLOR=\"DarkBlue\">\n<H4>HTML Container program</H4>\n<FORM>\n");
	pFile->WriteString(str);

	UINT nRows = (int) ( ( m_nMaxBottomPos - m_nMinTopPos ) / ROWHEIGHT ) + 1;
	UINT nCols = (int) ( ( m_nMaxRightPos  - m_nMinLeftPos) / COLUMNWIDTH ) + 1;

	pFile->WriteString("\n");

	str.Format("<!-- Total Rows: %d Columns %d -->\n", nRows, nCols);
	pFile->WriteString(str);
	str.Format("<TABLE WIDTH = \"%d\" BORDER>\n", (int)nCols*COLUMNWIDTH);
	pFile->WriteString(str);
	str.Format("<COLGROUP SPAN=\"%d\" WIDTH=\"%d\">\n", nCols, COLUMNWIDTH);
	pFile->WriteString(str);

	for (UINT i = 0; i < nRows; i++)
	{
     	str.Format("<TR HEIGHT=\"%d\">\n", ROWHEIGHT);
		pFile->WriteString(str);

		ptHTMLPos.x = 0;
		for (UINT j = 0; j < nCols; j++)
		{
			if ( pElementIterator = hasObjectIn(ptHTMLPos))
			{
				// draw object in table and erase it from list,
			    // but add it to drown elements list...
				if (!bUseActiveX)
					nDisabled = drawObject(pFile,pElementIterator);
				else
					nDisabled = drawObject2(pFile,pElementIterator);
			}
			if (!hasDrownObjectIn(ptHTMLPos))
			{
//				str.Format("<TD WIDTH=\"%d\"></TD>", COLUMNWIDTH);
				str.Format("<TD></TD>", COLUMNWIDTH);
				pFile->WriteString(str);
			}
			ptHTMLPos.x += COLUMNWIDTH;
		}
		ptHTMLPos.y += ROWHEIGHT;
		pFile->WriteString("\n</TR>\n");
	}

	pFile->WriteString("</COLGROUP>\n");
	pFile->WriteString("</TABLE>\n");
	pFile->WriteString("</FORM>\n");
	str.Format("</BODY>\n");
	pFile->WriteString(str);
	pFile->WriteString("</HTML>\n");

}

void CHTMLFile::checkForMaxTablePositions(CRect rc)
{
	// we use this method for calculating the min & max positions
	// of our HTML table...
	
	if (m_nMinTopPos > rc.top)
		m_nMinTopPos = rc.top;

	if (m_nMinLeftPos > rc.left)
		m_nMinLeftPos = rc.left;

	if (m_nMaxRightPos < rc.right)
		m_nMaxRightPos = rc.right;
	
	if (m_nMaxBottomPos < rc.bottom)
		m_nMaxBottomPos = rc.bottom;

}

list<CHTMLFile::CHTMLElement>::iterator* CHTMLFile::hasObjectIn(CPoint pt)
{
	CRect rc;

	try
	{
		for(ElementIterator = listElements.begin(); ElementIterator != listElements.end(); ++ElementIterator)
		{
			rc = (*ElementIterator).m_rcPosition;

			if (rc.PtInRect(pt))
				return &ElementIterator;
		}
	}
	catch(...)
	{
		TRACE("Error finding object in list...");
	}
	
	return NULL;
}

CPoint CHTMLFile::drawObject(CStdioFile* pFile, list<CHTMLFile::CHTMLElement>::iterator* iter)
{
	// here we will "draw" each element in html table...

	CPoint ptDisabled(0,0); // here we will keep number "disabled" columns and 
						    // strings... x Position = Columns, y Position = Rows

	CRect rcObject           = (**iter).m_rcPosition;
	CString strPropertyValue = (**iter).m_strPropertyValue;
	ptDisabled.x = floor( rcObject.Width()  / COLUMNWIDTH );
	ptDisabled.y = floor( rcObject.Height()  / ROWHEIGHT );

	TRACE("RECT: left:%d, top:%d, height:%d, width:%d\n", rcObject.left, 
														rcObject.top,
														rcObject.Height(), 
														rcObject.Width());


	CString str;
	switch ( (**iter).m_nTypeObject)
	{
	case LABEL:
		str.Format("<TD ROWSPAN=\"%d\" COLSPAN=\"%d\"BGCOLOR=\"SILVER\"><h6>%s</h6></TD>",
					ptDisabled.y,
					ptDisabled.x,
					strPropertyValue);
		break;
	case TEXT_EDIT:
		str.Format("<TD ROWSPAN=\"%d\" COLSPAN=\"%d\"><INPUT style =\"WIDTH: %dpx; HEIGHT: %dpx\" value=\"%s\"></TD>",
				   ptDisabled.y,
				   ptDisabled.x,
				   ptDisabled.x * COLUMNWIDTH,
				   DEFAULTHEIGHT, // because height = const like in rules...
//				   ptDisabled.y * ROWHEIGHT, 
				   strPropertyValue);
		break;
	case BUTTON:
		str.Format("<TD ROWSPAN=\"%d\"COLSPAN=\"%d\"><INPUT style=\"WIDTH:%dpx; HEIGHT:%dpx\" type=button value=\"%s\"></TD>",
				   ptDisabled.y,
				   ptDisabled.x,
				   ptDisabled.x * COLUMNWIDTH,
				   ptDisabled.y * ROWHEIGHT, strPropertyValue);
		TRACE(str);
		break;
	}

	pFile->WriteString(str);

	listDrownElements.push_back(**iter);

	// erasing element from one List...
	listElements.erase(*iter);

	return ptDisabled;
}

CPoint CHTMLFile::drawObject2(CStdioFile* pFile, list<CHTMLFile::CHTMLElement>::iterator* iter)
{
	// here we will "draw" each element in html table...

	CPoint ptDisabled(0,0); // here we will keep number "disabled" columns and 
						    // strings... x Position = Columns, y Position = Rows

	CRect rcObject           = (**iter).m_rcPosition;
	CString strPropertyValue = (**iter).m_strPropertyValue;
	ptDisabled.x = floor( rcObject.Width()  / COLUMNWIDTH );
	ptDisabled.y = floor( rcObject.Height()  / ROWHEIGHT );

	TRACE("RECT: left:%d, top:%d, height:%d, width:%d\n", rcObject.left, 
														rcObject.top,
														rcObject.Height(), 
														rcObject.Width());


	CString str;
	switch ( (**iter).m_nTypeObject)
	{
	case LABEL:

		str.Format("<TD ROWSPAN=\"%d\" COLSPAN=\"%d\">\
		<OBJECT ID=\"MyLabel\" WIDTH=%d HEIGHT=%d CLASSID=\"CLSID:4D331418-2F5F-11D6-B72D-00D0B728548D\">\
		<PARAM NAME=\"Text\" VALUE=\"%s\"></OBJECT></TD>",
					ptDisabled.y,
					ptDisabled.x,
					ptDisabled.x * COLUMNWIDTH - 5,
					ptDisabled.y * ROWHEIGHT - 5,
					strPropertyValue);
		TRACE(str);
		break;
	case TEXT_EDIT:
		str.Format("<TD ROWSPAN=\"%d\" COLSPAN=\"%d\">\
			<OBJECT ID=\"MyEdit\" WIDTH=%d HEIGHT=%d CLASSID=\"CLSID:C3107E30-2D06-11D6-B72D-00D0B728548D\">\
			<PARAM NAME=\"Text\" VALUE=\"%s\"</OBJECT></TD>",
				   ptDisabled.y,
				   ptDisabled.x,
				   ptDisabled.x * COLUMNWIDTH - 5,
				   DEFAULTHEIGHT, // because height = const like in rules...
//				   ptDisabled.y * ROWHEIGHT, 
				   strPropertyValue);
		TRACE(str);
		break;
	case BUTTON:
		str.Format("<TD ROWSPAN=\"%d\"COLSPAN=\"%d\">\
			<OBJECT ID=\"MyButton\" WIDTH=%d HEIGHT=%d CLASSID=\"CLSID:C3107E40-2D06-11D6-B72D-00D0B728548D\">\
			<PARAM NAME=\"Caption\" VALUE=\"%s\"</OBJECT></TD>",
				   ptDisabled.y,
				   ptDisabled.x,
				   ptDisabled.x * COLUMNWIDTH - 5,
				   ptDisabled.y * ROWHEIGHT - 5, strPropertyValue);
		TRACE(str);
		break;
	}

	pFile->WriteString(str);

	listDrownElements.push_back(**iter);

	// erasing element from one List...
	listElements.erase(*iter);

	return ptDisabled;
}




BOOL CHTMLFile::hasDrownObjectIn(CPoint pt)
{
	CRect rc;
	rc.SetRect(0,0,0,0);

	for(ElementIterator = listDrownElements.begin(); ElementIterator != listDrownElements.end(); ++ElementIterator)
	{
		TRACE("Drown Object: %d, left: %d, top: %d, height: %d width: %d Value: %s\n",
			(*ElementIterator).m_nTypeObject,
 		    (*ElementIterator).m_rcPosition.left,
			(*ElementIterator).m_rcPosition.top,
		    (*ElementIterator).m_rcPosition.Height(),
			(*ElementIterator).m_rcPosition.Width(), 
			(*ElementIterator).m_strPropertyValue);

			rc = (*ElementIterator).m_rcPosition;

			if (rc.PtInRect(pt))
				return TRUE;
	}

	return FALSE;
}

void CHTMLFile::optimizeElements()
{
	// Here we will optimize elements according to the
	// cell spacing (according to the ROWHEIGHT and COLUMNWIDTH params)
	// and we will recalculate them...

	// Okay, it's became more interesting :-)
	// After all my thoughts the main goal is:
	// 1 - we created list of elements (not optimized)
	// 2 - I decided to create list with optimized elements (may be it's crazy but I don't know yet...)
	// for comparing them with others NOT OPTIMIZED elements ...
	// I will use it to prevent situation, when element which will be optimized can to 
	// intersect with optimized objects...
	// sorry, I change my mind - I don't need new list - better way: just
	// check intersection stright from list of elements...

	list<CHTMLFile::CHTMLElement>::iterator Iterator; // iterator for acessing 
													  // to the other objects in List
	                                                  // in the second cycle...
	CRect rcObject;

	// first, recalculating system coordinates into table coordinates...
	for(ElementIterator = listElements.begin(); ElementIterator != listElements.end(); ++ElementIterator)
	{
	
			rcObject = (*ElementIterator).m_rcPosition;

			rcObject.left   = rcObject.left   - m_nMinLeftPos;
			rcObject.right  = rcObject.right  - m_nMinLeftPos;
			rcObject.top    = rcObject.top    - m_nMinTopPos;
			rcObject.bottom = rcObject.bottom - m_nMinTopPos;

			(*ElementIterator).m_rcPosition = rcObject;

		    TRACE("Recalculating coords: %d, top: %d, bottom% d, left: %d right: %d Value: %s\n",
									(*ElementIterator).m_nTypeObject,
 									(*ElementIterator).m_rcPosition.top,
									(*ElementIterator).m_rcPosition.bottom,
									(*ElementIterator).m_rcPosition.left,
									(*ElementIterator).m_rcPosition.right, 
									(*ElementIterator).m_strPropertyValue);
	}

	// then cut objects coordinates, so elements can easily plug into
	// table...

	UINT nRows, nCols     = 0;  // number of columns, rows which object will take in table
	int nDeltaX, nDeltaY = 0;   // rest from the object, when we cut him
	CRect relRect;              // we will compare this rect with rects of other objects...
	CRect rcBefore;				// Here we will check new object rect with optimized object rects...

	for(ElementIterator = listElements.begin(); ElementIterator != listElements.end(); ++ElementIterator)
	{
		rcObject = (*ElementIterator).m_rcPosition;

		nCols = floor( rcObject.Width()    / COLUMNWIDTH );
		nRows  = floor( rcObject.Height()  / ROWHEIGHT );

		nDeltaX         = rcObject.right;  // first state...
		nDeltaY         = rcObject.bottom;

		rcObject.right  = int ( nCols * COLUMNWIDTH ) + rcObject.left;
		rcObject.bottom = int ( nRows * ROWHEIGHT ) + rcObject.top;

		nDeltaX = nDeltaX - rcObject.right;  
		nDeltaY = nDeltaY - rcObject.bottom;

		(*ElementIterator).m_rcPosition = rcObject; // save new state...

		// now we have to recalculate other objects...
		// but we have to recalculate only those objects,
		// which have more right and bottom positions...

		Iterator = ElementIterator;
		relRect = rcObject;

		for (++Iterator; Iterator != listElements.end(); ++Iterator)
		{
			rcObject = rcBefore = (*Iterator).m_rcPosition;

			if (relRect.bottom <= rcObject.top)
			{
				// for checking at first...
				rcBefore.top     = rcObject.top    - nDeltaY;
				rcBefore.bottom  = rcObject.bottom - nDeltaY;
				if (!isIntersection(&Iterator, rcBefore))
				{
					rcObject.top    = rcObject.top    - nDeltaY;
					rcObject.bottom = rcObject.bottom - nDeltaY;
				}

			}

			if ( relRect.right <= rcObject.left )
			{
				// for checking at first...
				rcBefore.left  = rcObject.left  - nDeltaX;
				rcBefore.right = rcObject.right - nDeltaX;
				if (!isIntersection(&Iterator, rcBefore)) //!!!!!!!!!
				{
					rcObject.left   = rcObject.left   - nDeltaX;
					rcObject.right  = rcObject.right  - nDeltaX;
				}

			}
				
			(*Iterator).m_rcPosition = rcObject;
		}

		TRACE("After optimizing: %d, top: %d, bottom% d, left: %d right: %d Value: %s\n",
									(*ElementIterator).m_nTypeObject,
 									(*ElementIterator).m_rcPosition.top,
									(*ElementIterator).m_rcPosition.bottom,
									(*ElementIterator).m_rcPosition.left,
									(*ElementIterator).m_rcPosition.right, 
									(*ElementIterator).m_strPropertyValue);

	}

}

BOOL CHTMLFile::isIntersection(list<CHTMLElement>::iterator* end, CRect rc)
{
	// Here we will check intersection of rects 
	// from beginning of our array till this iterator...

	list<CHTMLFile::CHTMLElement>::iterator Iterator; // iterator for acessing 
	CRect rcObj;
	CRect rcIntersect;
	CRect eqRect;    // quick plug...

	for(Iterator = listElements.begin(); Iterator != listElements.end(); ++Iterator)
	{
		rcObj = eqRect =  (*Iterator).m_rcPosition;

		if ( rcIntersect.IntersectRect(rcObj, rc))
			if ((*Iterator) != (**end))
				return TRUE;
	}

	return FALSE;
}

void CHTMLFile::CreateBody2(CStdioFile *pFile)
{

	CString str;
	pFile->WriteString("<body bgcolor=\"DarkBlue\">\n");

	for(ElementIterator = listElements.begin(); ElementIterator != listElements.end(); ++ElementIterator)
	{
		switch ( (*ElementIterator).m_nTypeObject)
		{
		case LABEL:

			str.Format("<P style = \"position: absolute; top: %dpx; left: %dpx; z-index: 1\">\n<OBJECT ID=\"MyLabel\" WIDTH=%d HEIGHT=%d CLASSID=\"CLSID:4D331418-2F5F-11D6-B72D-00D0B728548D\"><PARAM NAME=\"Text\" VALUE=\"%s\">\n</OBJECT>\n</P>\n",
						(*ElementIterator).m_rcPosition.top, 
						(*ElementIterator).m_rcPosition.left,
						(*ElementIterator).m_rcPosition.Width(),
					    (*ElementIterator).m_rcPosition.Height(),
						(*ElementIterator).m_strPropertyValue );
			TRACE(str);
			break;

		case TEXT_EDIT:
			str.Format("<P style = \"position: absolute; top: %dpx; left: %dpx; z-index: 1\">\n<OBJECT ID=\"MyEdit\" WIDTH=%d HEIGHT=%d CLASSID=\"CLSID:C3107E30-2D06-11D6-B72D-00D0B728548D\"><PARAM NAME=\"Text\" VALUE=\"%s\">\n</OBJECT>\n</P>\n",
						(*ElementIterator).m_rcPosition.top, 
					    (*ElementIterator).m_rcPosition.left,
						(*ElementIterator).m_rcPosition.Width(),
					    (*ElementIterator).m_rcPosition.Height(),
						(*ElementIterator).m_strPropertyValue );
				TRACE(str);
			break;
		case BUTTON:
			str.Format("<P style = \"position: absolute; top: %dpx; left: %dpx; z-index: 1\">\n <OBJECT ID=\"MyButton\" WIDTH=%d HEIGHT=%d CLASSID=\"CLSID:C3107E40-2D06-11D6-B72D-00D0B728548D\"><PARAM NAME=\"Caption\" VALUE=\"%s\">\n</OBJECT>\n</P>\n",
						(*ElementIterator).m_rcPosition.top, 
						(*ElementIterator).m_rcPosition.left,
				   		(*ElementIterator).m_rcPosition.Width(),
					    (*ElementIterator).m_rcPosition.Height(),
						(*ElementIterator).m_strPropertyValue );
			    
				TRACE(str);
			break;
		}
		pFile->WriteString(str);
	}
	pFile->WriteString("</body>\n");
	pFile->WriteString("</html>\n");
}
