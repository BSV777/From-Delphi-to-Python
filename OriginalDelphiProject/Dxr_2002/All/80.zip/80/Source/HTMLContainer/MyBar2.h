#if !defined(__MYBAR2_H__)
#define __MYBAR2_H__

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// mybar2.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropertiesBar window

class CHTMLContainerDoc;
class CHTMLContainerView;
class CHTMLContainerItem;
class CPropertiesView;

#ifndef baseCMyBar
#define baseCMyBar CSizingControlBarG
#endif


class CPropertiesBar : public baseCMyBar
{
// Construction
public:
	CPropertiesBar();
	CPropertiesBar(CHTMLContainerDoc* pDoc, CHTMLContainerView* pView);
    virtual BOOL Create(
				CWnd* pParentWnd,			// mandatory
				CRuntimeClass *pViewClass,	// mandatory
				CCreateContext *pContext = NULL,
				LPCTSTR lpszWindowName = NULL,
				DWORD dwStyle = WS_CHILD | WS_VISIBLE | CBRS_TOP,
				UINT nID = AFX_IDW_PANE_FIRST);

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPropertiesBar)
	//}}AFX_VIRTUAL

// Implementation
public:
	CPropertiesView* GetView();
	CHTMLContainerDoc* GetDocument();
	virtual ~CPropertiesBar();

protected:
	CHTMLContainerDoc* m_pDoc;
	CHTMLContainerView* m_pView;
	CFrameWnd *m_pFrameWnd;
	CCreateContext m_Context;

	// Generated message map functions
protected:
	//{{AFX_MSG(CPropertiesBar)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(__MYBAR2_H__)
