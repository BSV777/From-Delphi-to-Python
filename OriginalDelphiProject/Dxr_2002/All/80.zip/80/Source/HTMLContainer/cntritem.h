// CntrItem.h : interface of the CHTMLContainerItem class
//

class CHTMLContainerDoc;
class CHTMLContainerView;

class CHTMLContainerItem : public COleClientItem
{
	DECLARE_SERIAL(CHTMLContainerItem)

// Constructors
public:
	CHTMLContainerItem(CHTMLContainerDoc* pContainer = NULL);
		// Note: pContainer is allowed to be NULL to enable IMPLEMENT_SERIALIZE.
		//  IMPLEMENT_SERIALIZE requires the class have a constructor with
		//  zero arguments.  Normally, OLE items are constructed with a
		//  non-NULL document pointer.
	CHTMLContainerItem(CHTMLContainerDoc* pContainer, CRect rc);

// Attributes
public:
	CRect m_rect;   // position within the document
	CSize szMax;
	UINT m_ntypeObj;
	CHTMLContainerDoc* GetDocument()
		{ return (CHTMLContainerDoc*)COleClientItem::GetDocument(); }
	CHTMLContainerView* GetActiveView()
		{ return (CHTMLContainerView*)COleClientItem::GetActiveView(); }

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHTMLContainerItem)
	public:
	virtual void OnChange(OLE_NOTIFICATION wNotification, DWORD dwParam);
	protected:
	virtual void OnGetItemPosition(CRect& rPosition);
	virtual void OnActivate();
	virtual void OnDeactivateUI(BOOL bUndoable);
	virtual BOOL OnChangeItemPosition(const CRect& rectPos);
	//}}AFX_VIRTUAL

// Implementation
public:
	BOOL IsModified() const;
	void SetStringValue(LPCTSTR lpszNewValue);
	CString GetStringValue();
	BOOL SaveObjectCondition(CStdioFile* pFile);
	void InvalidateItem();
	void ChangeSelection(CRect r);
	void UpdateFromServerExtent();
	~CHTMLContainerItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	virtual void Serialize(CArchive& ar);
};

/////////////////////////////////////////////////////////////////////////////
