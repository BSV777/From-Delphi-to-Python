
#ifndef PROPEDIT_H
#define PROPEDIT_H

class CPropertyEdit : public CEdit
{
public:
// Construction
	CPropertyEdit();
	BOOL SubclassEdit(UINT nID, CWnd* pParent);
	
	BOOL Create(DWORD dwStyle /* includes PES_ style*/, const RECT& rect,
		CWnd* pParentWnd, UINT nID);

// Implementation
protected:
	//{{AFX_MSG(CPropertyEdit)
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSysChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	BOOL m_bSubclassed;
};	
/////////////////////////////////////////////////////////////////////////////
#endif
