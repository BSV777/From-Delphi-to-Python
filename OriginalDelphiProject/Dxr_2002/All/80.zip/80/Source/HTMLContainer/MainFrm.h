// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__4D331409_2F5F_11D6_B72D_00D0B728548D__INCLUDED_)
#define AFX_MAINFRM_H__4D331409_2F5F_11D6_B72D_00D0B728548D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MyBar.h"
#include "MyBar2.h"

class CMainFrame : public CFrameWnd
{
	
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:
	friend class CHTMLContainerView;
	friend class CIntersectTracker;
	friend class CHTMLContainerDoc;
	friend class CTreeBar;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL DestroyWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:
	BOOL VerifyBarState(LPCTSTR lpszProfileName);

protected:  
	CCoolMenuManager m_menuManager; // thanks to Paul DiLascia!!!!
	// control bar embedded members
	CStatusBar      m_wndStatusBar;
	CToolBar        m_wndToolBar;
    CToolBar        m_wndToolBar2;
    CTreeBar	    m_wndStructureBar;
	CPropertiesBar  m_wndPropertiesBar;
//    enum {BTN_OBJECT = 0, BTN_LABEL = 1, BTN_EDIT = 2, BTN_BUTTON = 3} 
public:
	void disablePropertiesBar();
	void OnSelectElem(UINT nItem, HTREEITEM hItem);
	int  OnDeleteElem(UINT nElem, HTREEITEM pItem);
	void SetStatusBarInfo(TCHAR* szName, CRect rc);
	void SetSelection(UINT nIndex, treeElem* pElem);
	void OnClearAll();
	unsigned int m_nState;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnViewConstructor();
	afx_msg void OnUpdateViewConstructor(CCmdUI* pCmdUI);
	afx_msg void OnViewStructure();
	afx_msg void OnUpdateViewStructure(CCmdUI* pCmdUI);
	afx_msg void OnViewStatusBar();
	afx_msg void OnUpdateViewStatusBar(CCmdUI* pCmdUI);
	afx_msg void OnViewProperties();
	afx_msg void OnUpdateViewProperties(CCmdUI* pCmdUI);
	//}}AFX_MSG
	afx_msg void OnConstructor(UINT nID);
	afx_msg void OnUpdateConstructor(CCmdUI* pCmdUI);
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__4D331409_2F5F_11D6_B72D_00D0B728548D__INCLUDED_)
