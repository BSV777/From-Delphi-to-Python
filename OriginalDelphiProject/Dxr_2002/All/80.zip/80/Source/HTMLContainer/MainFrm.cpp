// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "HTMLContainer.h"

#include "MainFrm.h"
#include "PropertiesView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_VIEW_CONSTRUCTOR, OnViewConstructor)
	ON_UPDATE_COMMAND_UI(ID_VIEW_CONSTRUCTOR, OnUpdateViewConstructor)
	ON_COMMAND(ID_VIEW_STRUCTURE, OnViewStructure)
	ON_UPDATE_COMMAND_UI(ID_VIEW_STRUCTURE, OnUpdateViewStructure)
	ON_COMMAND(ID_VIEW_STATUS_BAR, OnViewStatusBar)
	ON_UPDATE_COMMAND_UI(ID_VIEW_STATUS_BAR, OnUpdateViewStatusBar)
	ON_COMMAND(ID_VIEW_PROPERTIES, OnViewProperties)
	ON_UPDATE_COMMAND_UI(ID_VIEW_PROPERTIES, OnUpdateViewProperties)
	//}}AFX_MSG_MAP
	ON_COMMAND_RANGE(ID_CONSTRUCTOR_1, ID_CONSTRUCTOR_4, OnConstructor)
	ON_UPDATE_COMMAND_UI_RANGE(ID_CONSTRUCTOR_1, ID_CONSTRUCTOR_4, OnUpdateConstructor)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // ObjectID
	ID_SEPARATOR,           // left position
	ID_SEPARATOR,           // top position
	ID_SEPARATOR,           // height of object
	ID_SEPARATOR,           // width of object
	ID_INDICATOR_NUM,
};

static UINT toolbars[] = 
{
	IDR_ELEMENTS,
	IDR_MAINFRAME
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_nState = 0;
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this, WS_CHILD | WS_VISIBLE | CBRS_BOTTOM, ID_MY_STATUS_BAR) ||
			!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	m_wndStatusBar.SetPaneInfo(0,0,SBPS_STRETCH,70);
	m_wndStatusBar.SetPaneInfo(1,0,0,65);
	m_wndStatusBar.SetPaneInfo(2,0,0,65);
	m_wndStatusBar.SetPaneInfo(3,0,0,65);
	m_wndStatusBar.SetPaneInfo(4,0,0,65);

	// second toolbar 
	if (!m_wndToolBar2.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC,
		CRect(0, 0, 0, 0), 122) ||
		!m_wndToolBar2.LoadToolBar(IDR_ELEMENTS))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;		// fail to create
	}
	m_wndToolBar2.SetWindowText(_T("�����������"));
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar2.EnableDocking(CBRS_ALIGN_ANY);

	if (!m_wndStructureBar.Create(_T("��������� ���������"), this, 123))
	{
		TRACE0("Failed to create Structure Bar\n");
		return -1;		// fail to create
	}
	m_wndStructureBar.SetBarStyle(m_wndStructureBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	m_wndStructureBar.EnableDocking(CBRS_ALIGN_LEFT|CBRS_ALIGN_RIGHT);

		
   if (!m_wndPropertiesBar.Create(this, RUNTIME_CLASS (CPropertiesView),
			(CCreateContext *)(lpCreateStruct->lpCreateParams),
			_T("��������"), WS_CHILD | WS_VISIBLE | CBRS_TOP, 124))
		{
			TRACE0("Failed to create PropertiesBar\n");
			return -1;		// fail to create
		}

	m_wndPropertiesBar.SetBarStyle(m_wndPropertiesBar.GetBarStyle() |
			CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);
	m_wndPropertiesBar.EnableDocking(CBRS_ALIGN_ANY);

	
#ifdef _SCB_REPLACE_MINIFRAME
		m_pFloatingFrameClass = RUNTIME_CLASS(CSCBMiniDockFrameWnd);
#endif //_SCB_REPLACE_MINIFRAME

	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);
	DockControlBar(&m_wndToolBar2, AFX_IDW_DOCKBAR_LEFT);
	DockControlBar(&m_wndStructureBar, AFX_IDW_DOCKBAR_RIGHT);

	RecalcLayout();
	CRect rBar;
	m_wndStructureBar.GetWindowRect(rBar);
	rBar.OffsetRect(0, 1);
	DockControlBar(&m_wndPropertiesBar, AFX_IDW_DOCKBAR_RIGHT, rBar);

	CString sProfile = _T("BarState");
	if (VerifyBarState(sProfile))
	{
		CSizingControlBar::GlobalLoadState(this, sProfile);
		LoadBarState(sProfile);
	}


	// install/load cool menus
	m_menuManager.Install(this);
	m_menuManager.LoadToolbars(toolbars,2);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


BOOL CMainFrame::DestroyWindow() 
{
	CString sProfile = _T("BarState");
	CSizingControlBar::GlobalSaveState(this, sProfile);
	SaveBarState(sProfile);

	return CFrameWnd::DestroyWindow();
}

void CMainFrame::OnViewConstructor() 
{
	ShowControlBar(&m_wndToolBar2, !m_wndToolBar2.IsVisible(), FALSE);
}

void CMainFrame::OnUpdateViewConstructor(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable();
	pCmdUI->SetCheck(m_wndToolBar2.IsVisible());
}

BOOL CMainFrame::VerifyBarState(LPCTSTR lpszProfileName)
{
    CDockState state;
    state.LoadState(lpszProfileName);

    for (int i = 0; i < state.m_arrBarInfo.GetSize(); i++)
    {
        CControlBarInfo* pInfo = (CControlBarInfo*)state.m_arrBarInfo[i];
        ASSERT(pInfo != NULL);
        int nDockedCount = pInfo->m_arrBarID.GetSize();
        if (nDockedCount > 0)
        {
            // dockbar
            for (int j = 0; j < nDockedCount; j++)
            {
                UINT nID = (UINT) pInfo->m_arrBarID[j];
                if (nID == 0) continue; // row separator
                if (nID > 0xFFFF)
                    nID &= 0xFFFF; // placeholder - get the ID
                if (GetControlBar(nID) == NULL)
                    return FALSE;
            }
        }
        
        if (!pInfo->m_bFloating) // floating dockbars can be created later
            if (GetControlBar(pInfo->m_nBarID) == NULL)
                return FALSE; // invalid bar ID
    }

    return TRUE;
}

void CMainFrame::OnViewStructure() 
{
	ShowControlBar(&m_wndStructureBar, !m_wndStructureBar.IsVisible(), FALSE);
}

void CMainFrame::OnUpdateViewStructure(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable();
	pCmdUI->SetCheck(m_wndStructureBar.IsVisible());
}

void CMainFrame::OnConstructor(UINT nID) 
{
	m_nState = nID - ID_CONSTRUCTOR_1;
}

void CMainFrame::OnUpdateConstructor(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable();
	pCmdUI->SetCheck(m_nState == pCmdUI->m_nID - ID_CONSTRUCTOR_1);
}

void CMainFrame::OnViewStatusBar() 
{
	m_wndStatusBar.ShowWindow((m_wndStatusBar.GetStyle() & WS_VISIBLE) == 0);
	RecalcLayout();
}

void CMainFrame::OnUpdateViewStatusBar(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck((m_wndStatusBar.GetStyle() & WS_VISIBLE) != 0);
	
}

void CMainFrame::OnClearAll()
{
	m_wndStructureBar.OnClearAll();

	CPropertiesView* pView = m_wndPropertiesBar.GetView();
	pView->OnClearAll();

}

void CMainFrame::OnViewProperties() 
{
	ShowControlBar(&m_wndPropertiesBar, !m_wndPropertiesBar.IsVisible(), FALSE);
}

void CMainFrame::OnUpdateViewProperties(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable();
	pCmdUI->SetCheck(m_wndPropertiesBar.IsVisible());
}

void CMainFrame::SetSelection(UINT nIndex, treeElem *pElem)
{
	CPropertiesView* pView = m_wndPropertiesBar.GetView();
	ASSERT_VALID(pView);

	m_wndStructureBar.SelectItem(pElem);
	pView->OnSelectObject(nIndex);

}

void CMainFrame::SetStatusBarInfo(TCHAR* szName, CRect rc)
{
	CString str;
	if ( lstrlen(szName) > 0)
	{
		str.Format("Object: %s", szName);
		m_wndStatusBar.SetPaneText(0,str);
		str.Format("Left: %d", rc.left);
		m_wndStatusBar.SetPaneText(1,str);
		str.Format("Top: %d", rc.top);
		m_wndStatusBar.SetPaneText(2,str);
		str.Format("Height: %d",rc.Height());
		m_wndStatusBar.SetPaneText(3,str);
		str.Format("Width: %d",rc.Width());
		m_wndStatusBar.SetPaneText(4,str);
	}
	else
	{
		m_wndStatusBar.SetPaneText(0,"");
		m_wndStatusBar.SetPaneText(1,"");
		m_wndStatusBar.SetPaneText(2,"");
		m_wndStatusBar.SetPaneText(3,"");
		m_wndStatusBar.SetPaneText(4,"");
	}
}

int CMainFrame::OnDeleteElem(UINT nElem, HTREEITEM pItem)
{
	m_wndStructureBar.OnDeleteItem(pItem);

	CPropertiesView* pView = m_wndPropertiesBar.GetView();
	ASSERT_VALID(pView);

	return pView->OnDeleteItem(nElem);

}

void CMainFrame::OnSelectElem(UINT nItem, HTREEITEM hItem)
{
	CPropertiesView* pView = m_wndPropertiesBar.GetView();
	m_wndStructureBar.OnSelectObject(hItem);
	pView->OnSelectObject(nItem);
}

void CMainFrame::disablePropertiesBar()
{
	// We use it when user loose selection...
	CPropertiesView* pView = m_wndPropertiesBar.GetView();
	ASSERT_VALID(pView);

	pView->disableProperties();
}
