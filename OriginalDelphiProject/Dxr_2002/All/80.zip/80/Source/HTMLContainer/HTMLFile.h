// HTMLFile.h: interface for the CHTMLFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HTMLFILE_H__E6296781_3FD7_11D6_B72D_00D0B728548D__INCLUDED_)
#define AFX_HTMLFILE_H__E6296781_3FD7_11D6_B72D_00D0B728548D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <stdio.h>
#include <map>
#include <list>
#include <iterator>
#include <algorithm>

using namespace std;
class CParser;

class CHTMLFile : public CObject  
{
	class CHTMLElement
	{
	public:
		CHTMLElement()
		{
			m_nTypeObject = 0;
			m_rcPosition.SetRect(0,0,0,0);
			m_strPropertyValue = "";
		}
		virtual ~CHTMLElement() {}
		UINT    m_nTypeObject;
		CRect   m_rcPosition;
		CString m_strPropertyValue;
		
		bool operator < (const CHTMLElement& elem)
		{
			// we have complicated key...
			// top position - primary key,
			// left - secondary key

			UINT delta = abs(this->m_rcPosition.top - elem.m_rcPosition.top);

			if ( delta > HTMLDELTA)
			{
				long nThisKey  = this->m_rcPosition.top * 10000 + this->m_rcPosition.left;
				long nKey      = elem.m_rcPosition.top * 10000 + elem.m_rcPosition.left;
				return nThisKey < nKey;
			}
			else
			{
				long nThisKey  = this->m_rcPosition.left;
				long nKey      = elem.m_rcPosition.left;
				return nThisKey < nKey;
			}

		}

		CHTMLElement& operator=(const CHTMLElement& elem)
		{
			return *this;
		}

		bool operator!=(const CHTMLElement& elem)
		{
			// I check only rects here...
			if (this->m_rcPosition.EqualRect(elem.m_rcPosition))
				return FALSE;
			else
				return TRUE;
		}

	};

public:
	void CreateBody2(CStdioFile* pFile);
	BOOL isIntersection(list<CHTMLElement>::iterator* end, CRect rc);
	void optimizeElements();
	BOOL hasDrownObjectIn(CPoint pt);
	CPoint drawObject(CStdioFile* pFile, list<CHTMLElement>::iterator* iter);
	CPoint drawObject2(CStdioFile* pFile, list<CHTMLElement>::iterator* iter);
	list<CHTMLElement>::iterator* hasObjectIn(CPoint pt);
	void checkForMaxTablePositions(CRect rc);
	void CreateBody(CStdioFile* pFile, BOOL bUseActiveX = FALSE);
	void CreateHeader(CStdioFile* pFile);
	BOOL createOutputFile(LPCTSTR lpszFileName, BOOL bUseActiveX = FALSE );
	void addElem(CParser* parser);
	BOOL processContainerFile(LPCTSTR lpszPathName);
	
	list<CHTMLElement> listDrownElements;         // list of Elements, which we already drew
	list<CHTMLElement> listElements;              // list of Elements, which we will draw
	list<CHTMLElement>::iterator ElementIterator; // iterator for acessing to the objects
	list<CHTMLElement>::iterator* pElementIterator;

	UINT m_nMinTopPos;
	UINT m_nMinLeftPos;
	UINT m_nMaxRightPos;
	UINT m_nMaxBottomPos;

	CHTMLFile();
	virtual ~CHTMLFile();

};

#endif // !defined(AFX_HTMLFILE_H__E6296781_3FD7_11D6_B72D_00D0B728548D__INCLUDED_)
