// HTMLContainer.h : main header file for the HTMLCONTAINER application
//

#if !defined(AFX_HTMLCONTAINER_H__4D331405_2F5F_11D6_B72D_00D0B728548D__INCLUDED_)
#define AFX_HTMLCONTAINER_H__4D331405_2F5F_11D6_B72D_00D0B728548D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
/////////////////////////////////////////////////////////////////////////////
// CHTMLContainerApp:
// See HTMLContainer.cpp for the implementation of this class
//

class CHTMLContainerApp : public CWinApp
{
public:
	void createHTMLFileFromCommandPrompt(CString pathCntrFile, CString pathHTMLFile);
	CSingleDocTemplate* pDocTemplate;
	CHTMLContainerApp();
	friend class CHTMLContainerDoc;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHTMLContainerApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CHTMLContainerApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	CString m_strPathHTMLFile;
	CString m_strPathCntrFile;
};

enum HintType
{
	UPD_WINDOW, UPD_ITEM, UPD_DELITEM
};

enum ObjectType
{
	LABEL = 1, TEXT_EDIT = 2, BUTTON = 3 
};

#define WM_USERINSERTOBJECT		WM_USER + 5
#define WM_USERSELECTOBJECT     WM_USER + 6

class CHTMLContainerItem;

typedef struct
{
	TCHAR     szName[128];
	HTREEITEM m_htreeNode;			
	CHTMLContainerItem* pHTMLItem;

} treeElem;


typedef struct
{
	UINT     m_nTypeObject;
	CRect    rcObject;
	CString  strPropertyValue;

}objElem;



#define MAXLEFT   3
#define MAXRIGHT  770
#define MAXTOP    3
#define MAXBOTTOM 870
#define DELTA     2
#define HTMLDELTA 5

#define DEFAULTWIDTH  70
#define DEFAULTHEIGHT 20

#define COLUMNWIDTH 10	
#define ROWHEIGHT 10
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HTMLCONTAINER_H__4D331405_2F5F_11D6_B72D_00D0B728548D__INCLUDED_)
