// PropertiesView.cpp : implementation file
//

#include "stdafx.h"
#include "htmlcontainer.h"
#include "PropertiesView.h"
#include "HTMLContainerDoc.h"
#include "CntrItem.h"
#include "Propedit.h"
//#include "GridBase\gridctrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropertiesView

IMPLEMENT_DYNCREATE(CPropertiesView, CFormView)

CPropertiesView::CPropertiesView()
	: CFormView(CPropertiesView::IDD)
{
	//{{AFX_DATA_INIT(CPropertiesView)
	//}}AFX_DATA_INIT
}

CPropertiesView::~CPropertiesView()
{
}

void CPropertiesView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropertiesView)
	DDX_Control(pDX, IDC_PROPERTYNAME, m_stPropertyName);
//	DDX_Control(pDX, IDC_PROPERTY, m_editProperty);
	DDX_Control(pDX, IDC_ELEMENTS, m_Elements);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropertiesView, CFormView)
	//{{AFX_MSG_MAP(CPropertiesView)
	ON_WM_SIZE()
	ON_CBN_SELCHANGE(IDC_ELEMENTS, OnSelchangeElements)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropertiesView diagnostics

#ifdef _DEBUG
void CPropertiesView::AssertValid() const
{
	CFormView::AssertValid();
}

void CPropertiesView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPropertiesView message handlers

void CPropertiesView::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	m_editProperty.SubclassEdit(IDC_PROPERTY, this);
	m_editProperty.SetLimitText(255);

	if (GetDocument()->m_arrTree.GetSize() > 0)
	{
		for (int i = 0; i < GetDocument()->m_arrTree.GetSize(); i ++)
			OnInsertObject(i);

		OnSelectObject(0);
	}

	
}

void CPropertiesView::OnSize(UINT nType, int cx, int cy) 
{
	CFormView::OnSize(nType, cx, cy);

	if (m_hWnd && m_Elements.m_hWnd && m_editProperty.m_hWnd)
	{
		CRect rc, rcElements, rcEdit,rcStatic;

		GetClientRect(rc);

		m_Elements.GetClientRect(rcElements);
		rcElements.right = rc.right - 5;
		m_Elements.MoveWindow(rcElements);
		
		m_editProperty.GetClientRect(rcEdit);
		rcEdit.top    = rcElements.bottom;
		rcEdit.bottom = rcEdit.top + 20;
		rcEdit.left   = 70;
		rcEdit.right  = rc.right - 5;
		m_editProperty.MoveWindow(rcEdit);

		m_stPropertyName.GetClientRect(rcStatic);
		rcStatic.top    = rcElements.bottom + 5;
		rcStatic.bottom = rcStatic.top + 20;
		rcStatic.left   = 5;
		rcStatic.right  = rcEdit.left;
		m_stPropertyName.MoveWindow(rcStatic);
	}

		
}

void CPropertiesView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	
}

void CPropertiesView::OnInsertObject(int nIndex)
{
	treeElem* pElem = GetDocument()->GetElem(nIndex);

	CHTMLContainerItem* pItem = pElem->pHTMLItem;
	ASSERT_VALID(pItem);

	CString strValue = pItem->GetStringValue();
	CString strNameProperty = (pItem->m_ntypeObj == BUTTON) ? "Caption" : "Text";

	if (!m_Elements || !m_editProperty || !m_stPropertyName)
		return;

	if (!m_Elements.IsWindowEnabled())
		m_Elements.EnableWindow();

	m_Elements.AddString(pElem->szName);
	m_Elements.SetCurSel(m_Elements.GetCount() - 1);

	if (!m_editProperty.IsWindowEnabled())
		m_editProperty.EnableWindow();

	m_editProperty.SetWindowText(strValue);

	m_stPropertyName.SetWindowText(strNameProperty);

}

BOOL CPropertiesView::OnSelectObject(int nIndex)
{
	treeElem* pElem = GetDocument()->GetElem(nIndex);

	CHTMLContainerItem* pItem = pElem->pHTMLItem;
	ASSERT_VALID(pItem);

	CString strValue = pItem->GetStringValue();
	CString strNameProperty = (pItem->m_ntypeObj == BUTTON) ? TEXT("Caption") : TEXT("Text");

	if (m_stPropertyName)
		m_stPropertyName.SetWindowText(strNameProperty);


	if (m_editProperty)
	{
		if (!m_editProperty.IsWindowEnabled())
			m_editProperty.EnableWindow();

		m_editProperty.SetWindowText(strValue);
	}
	if (m_Elements)
		m_Elements.SetCurSel(nIndex);

	return TRUE;

}

void CPropertiesView::OnClearAll()
{
	m_Elements.ResetContent();
	m_Elements.EnableWindow(FALSE);

	m_editProperty.SetWindowText("");
	m_editProperty.EnableWindow(FALSE);
	m_stPropertyName.SetWindowText("");
}


CHTMLContainerDoc* CPropertiesView::GetDocument()
{
	CDocTemplate* pTemplate = ((CHTMLContainerApp*) AfxGetApp())->pDocTemplate;
	ASSERT_VALID(pTemplate);

	POSITION pos = pTemplate->GetFirstDocPosition();
	CHTMLContainerDoc* pDoc = (CHTMLContainerDoc*)pTemplate->GetNextDoc(pos);
	ASSERT_VALID(pDoc);
	
	return pDoc;
}

void CPropertiesView::OnSelchangeElements() 
{
	int nIndex = m_Elements.GetCurSel();
	if (nIndex != LB_ERR)
	{
		CHTMLContainerDoc* pDoc = GetDocument();
		pDoc->OnComboClicked(nIndex);
	}

	OnSelectObject(nIndex);
}

int CPropertiesView::OnDeleteItem(UINT nItem)
{
	UINT nResultElem = 0;
	m_Elements.DeleteString(nItem);

	UINT nTotal = m_Elements.GetCount();

	if (nItem >= m_Elements.GetCount())
	{
		if (m_Elements.GetCount() > 0)
		{
			m_Elements.SetCurSel(0);
		}
		else
		{
			m_Elements.EnableWindow(FALSE);
			m_editProperty.EnableWindow(FALSE);
			return -1;
		}

	}
	else
	{
		nResultElem = nItem;
		m_Elements.SetCurSel(nResultElem);
	}

	treeElem* pElem = GetDocument()->GetElem(nResultElem);
	CString str = pElem->pHTMLItem->GetStringValue();
	m_editProperty.SetWindowText(str);
	GetDocument()->OnSelectObject(pElem->pHTMLItem);
	GetDocument()->OnComboClicked(nResultElem);

	return nResultElem;
}

void CPropertiesView::ChangeProperty()
{
 	CString str;
	m_editProperty.UpdateData();
 	m_editProperty.GetWindowText(str);
 	int nIndex = m_Elements.GetCurSel();
 	GetDocument()->OnChangeProperty(str, nIndex);
}

void CPropertiesView::disableProperties()
{
	// we use it when user loose selection...

	if (m_stPropertyName)
		m_stPropertyName.SetWindowText(_T(""));

	if (m_editProperty)
	{
		m_editProperty.SetWindowText(_T(""));
		m_editProperty.EnableWindow(FALSE);
	}

}
