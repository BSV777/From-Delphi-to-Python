// HTMLActive.cpp: implementation of the CHTMLActive class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "htmlcontainer.h"
#include "HTMLActive.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHTMLActiveFile::CHTMLActiveFile()
{

}

CHTMLActiveFile::~CHTMLActiveFile()
{

}
