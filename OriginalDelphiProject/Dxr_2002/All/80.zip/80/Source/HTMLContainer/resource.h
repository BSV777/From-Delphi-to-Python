//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by HTMLContainer.rc
//
#define IDR_CNTR_INPLACE                6
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define ID_MY_STATUS_BAR                101
#define IDP_FAILED_TO_CREATE            102
#define IDR_MAINFRAME                   128
#define IDR_HTMLCOTYPE                  129
#define IDR_ELEMENTS                    130
#define IDR_CONTEXTMENU                 132
#define IDI_DOCUMENT                    133
#define IDI_LABEL                       134
#define IDI_EDIT                        135
#define IDI_BUTTON                      136
#define IDI_SBUTTON                     137
#define IDI_SLABEL                      138
#define IDI_SEDIT                       139
#define IDD_PROPERTIES                  140
#define IDC_ELEMENTS                    1005
#define IDC_PROPERTY                    1007
#define IDC_PROPERTYNAME                1008
#define ID_CANCEL_EDIT_CNTR             32768
#define ID_CONSTRUCTOR_1                32771
#define ID_CONSTRUCTOR_2                32772
#define ID_CONSTRUCTOR_3                32773
#define ID_CONSTRUCTOR_4                32774
#define ID_VIEW_STRUCTURE               32775
#define ID_VIEW_CONSTRUCTOR             32776
#define ID_ITEM_PROPERTIES              32777
#define ID_ITEM_DELETE                  32778
#define ID_VIEW_PROPERTIES              32779
#define ID_ACCEL32780                   32780
#define ID_FILE_CREATEHTML              32782
#define ID_MOVE_UP                      32783
#define ID_MOVE_DOWN                    32784
#define ID_MOVE_LEFT                    32785
#define ID_MOVE_RIGHT                   32786
#define ID_FILE_CREATEHTML_AS           32787
#define ID_BUTTON32790                  32790
#define ID_FILE_CREATEACTIVEXHTML       32791

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32792
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
