// HTMLActive.h: interface for the CHTMLActive class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HTMLACTIVE_H__C06A7C49_3920_415F_8D86_31F6B8523EB9__INCLUDED_)
#define AFX_HTMLACTIVE_H__C06A7C49_3920_415F_8D86_31F6B8523EB9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CHTMLActiveFile : public CObject  
{
public:
	CHTMLActiveFile();
	virtual ~CHTMLActiveFile();

};

#endif // !defined(AFX_HTMLACTIVE_H__C06A7C49_3920_415F_8D86_31F6B8523EB9__INCLUDED_)
