// HTMLContainerDoc.cpp : implementation of the CHTMLContainerDoc class
//

#include "stdafx.h"
#include "HTMLContainer.h"

#include "MainFrm.h"
#include "ContrVw.h"
#include "HTMLContainerDoc.h"
#include "CntrItem.h"
#include <Shlwapi.h>
#include "HTMLFile.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CParserException
/////////////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNAMIC(CParserException, CException)

CParserException::CParserException(char* pchMessage)
{
	m_strMessage = pchMessage;
	m_nError = GetLastError();
}

BOOL CParserException::GetErrorMessage(LPTSTR lpstrError, UINT nMaxError,
		PUINT pnHelpContext /*= NULL*/)
{

	char text[500];
	if(m_nError == 0)
	{
		wsprintf(text, "%s", (const char*) m_strMessage);
	}
	else
	{
		wsprintf(text, "%s ������ ����� #%d", (const char*) m_strMessage, m_nError);
	}
	strncpy(lpstrError, text, nMaxError - 1);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CLoadingException
/////////////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNAMIC(CLoadingException, CException)

CLoadingException::CLoadingException(char* pchMessage)
{
	m_strMessage = pchMessage;
	m_nError = GetLastError();
}

BOOL CLoadingException::GetErrorMessage(LPTSTR lpstrError, UINT nMaxError,
		PUINT pnHelpContext /*= NULL*/)
{

	char text[500];
	if(m_nError == 0)
	{
		wsprintf(text, "%s", (const char*) m_strMessage);
	}
	else
	{
		wsprintf(text, "%s ������ ����� #%d", (const char*) m_strMessage, m_nError);
	}
	strncpy(lpstrError, text, nMaxError - 1);
	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CParser
/////////////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNAMIC(CParser, CObject)

CParser::CParser() : m_strValue("")
{
	m_rc.SetRect(0,0,0,0);
	m_ntypeObj = 0;
}

CParser::~CParser()
{

}

BOOL CParser::parseString(CString str)
{
//	str.MakeUpper();
	checkSubString((char*)(LPCTSTR)str);

	//parse object values from saved file...
	char szStr[400];
	char szSubStr[50] = "";
	char seps[] = "<;>";
	char *token;
	char *subtoken;
	char subseps[] = " ";

	strcpy(szStr, (char*)(LPCTSTR)str);

	checkSubString(szStr);

	// let's find the first two tokens...
	token = strtok( szStr, seps );
	checkSubString(token);
	TRACE ("%s\n", token);	
	strcpy(szSubStr, token);

	subtoken = strtok(token, subseps); 
	checkSubString(subtoken);
	_strupr(subtoken);

	TRACE ("%s\n", subtoken);	
	// get type of object
	if (strcmp(subtoken, "LABEL") == 0)
		m_ntypeObj = 1;
	else
		if (strcmp(subtoken, "TEXTEDIT") == 0)
			m_ntypeObj = 2;
	else
		if (strcmp(subtoken, "BUTTON") == 0)
			m_ntypeObj = 3;

	if (m_ntypeObj == 0)
		throw new CParserException("Object type");



	// getting value "left":
	char sztrim[40] = "LEFT=\"";
	subtoken = strtok( NULL, subseps );
	_strupr(subtoken);
	checkSubString(subtoken);
	TRACE ("%s\n", subtoken);	
	StrTrim(subtoken, sztrim);
	m_rc.left = StrToInt(subtoken);
	if (m_rc.left == 0 || m_rc.left < MAXLEFT )
		throw new CParserException("left");

	// then find other tokens...
	strcpy(szStr, (char*)(LPCTSTR)str+(strlen(szSubStr) + 1) );
	checkSubString(szStr);

	// getting value "top"
	token = strtok( szStr, seps );
	checkSubString(token);
	_strupr(token);
	TRACE ("%s\n", token);	
	strcpy(sztrim,"; TOP=\"");
	StrTrim(token, sztrim);
	m_rc.top = StrToInt(token);
	if (m_rc.top == 0 || m_rc.top < MAXTOP)
		throw new CParserException("top");

	if (m_ntypeObj != TEXT_EDIT)
	{
		// getting value "height"
		token = strtok( NULL, seps );
		_strupr(token);
		checkSubString(token);
		TRACE ("%s\n", token);	
		strcpy(sztrim,"; HEIGHT=\"");
		StrTrim(token, sztrim);
		m_rc.bottom = StrToInt(token) + m_rc.top;
		if (m_rc.bottom == m_rc.top || m_rc.bottom > MAXBOTTOM)
			throw new CParserException("height");
	}
	else
	{
		m_rc.bottom = m_rc.top + DEFAULTHEIGHT;
	}

	// getting value "width"
	token = strtok( NULL, seps );
	_strupr(token);
	checkSubString(token);
	TRACE ("%s\n", token);	
	strcpy(sztrim,"; WIDTH=\"");
	StrTrim(token, sztrim);
	m_rc.right = StrToInt(token) + m_rc.left;
	if (m_rc.right == m_rc.left || m_rc.right > MAXRIGHT)
		throw new CParserException("width");

	// getting the "Text (Caption) value"
	token = strtok( NULL, seps );
	checkSubString(token);
	TRACE ("%s\n", token);	

	CString strValue  = token;
	CString strSubValue;

	// Checking param "Text or Value"
	int nFindL = -1;
	int nFindR = -1;

	// check for correcting words...
	switch (m_ntypeObj)
	{
	case LABEL:
	case TEXT_EDIT:
		strSubValue = strValue.Left(7); // mean " Text="...
		strSubValue.MakeUpper();
		nFindL = strSubValue.Find(" TEXT=\"");
		break;
	case BUTTON:
		strSubValue = strValue.Left(10); // mean " Caption="...
		strSubValue.MakeUpper();
		nFindL = strSubValue.Find(" CAPTION=\"");
		break;
	}
	// 
	if (nFindL != -1)
	{
		nFindL = strValue.Find("\"");
		nFindR = strValue.Find("\"", nFindL + 1);
	}
	
	if (nFindL == -1 || nFindR == -1)
		throw new CParserException("Object text Value");

	m_strValue = strValue.Mid(nFindL + 1, nFindR - nFindL - 1);

	if (m_strValue.GetLength() > 255)
		throw new CParserException("Object text Value > 255 symbols");

/*	switch (m_ntypeObj)
	{
	case LABEL:
	case TEXT_EDIT:
		strcpy(sztrim,"; Text=\"");
		break;
	case BUTTON:
		strcpy(sztrim,"; Caption=\"");
		break;
	}
	StrTrim(token, sztrim);
	if (token == 0)
		checkSubString(token);
	
	TRACE ("%s\n", token);	
	m_strValue = token;*/

//	if (/*m_strValue.GetLength() == 0 || */m_strValue.GetLength() > 255)
//		throw new CParserException("Object text Value");
	
	return TRUE;
}

void CParser::checkSubString(char* szStr)
{
	if (szStr != NULL)
	{
		if (strlen(szStr) == 0)
			throw new CParserException("����� ������ ������");
	}
	else
		throw new CParserException("����� ������ ������");

}


/////////////////////////////////////////////////////////////////////////////
// CHTMLContainerDoc

IMPLEMENT_DYNCREATE(CHTMLContainerDoc, COleDocument)

BEGIN_MESSAGE_MAP(CHTMLContainerDoc, COleDocument)
	//{{AFX_MSG_MAP(CHTMLContainerDoc)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_AS, OnUpdateFileSaveAs)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, OnUpdateFileSave)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CLEAR_ALL, OnUpdateEditClearAll)
	ON_COMMAND(ID_EDIT_CLEAR_ALL, OnEditClearAll)
	ON_COMMAND(ID_FILE_CREATEHTML, OnFileCreatehtml)
	ON_UPDATE_COMMAND_UI(ID_FILE_CREATEHTML, OnUpdateFileCreatehtml)
	ON_COMMAND(ID_FILE_CREATEHTML_AS, OnFileCreatehtmlAs)
	ON_UPDATE_COMMAND_UI(ID_FILE_CREATEHTML_AS, OnUpdateFileCreatehtmlAs)
	ON_COMMAND(ID_FILE_CREATEACTIVEXHTML, OnFileCreateactivexhtml)
	ON_UPDATE_COMMAND_UI(ID_FILE_CREATEACTIVEXHTML, OnUpdateFileCreateactivexhtml)
	//}}AFX_MSG_MAP
	// Enable default OLE container implementation
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, COleDocument::OnUpdatePasteMenu)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE_LINK, COleDocument::OnUpdatePasteLinkMenu)
	ON_UPDATE_COMMAND_UI(ID_OLE_EDIT_CONVERT, COleDocument::OnUpdateObjectVerbMenu)
	ON_COMMAND(ID_OLE_EDIT_CONVERT, COleDocument::OnEditConvert)
	ON_UPDATE_COMMAND_UI(ID_OLE_EDIT_LINKS, COleDocument::OnUpdateEditLinksMenu)
	ON_COMMAND(ID_OLE_EDIT_LINKS, COleDocument::OnEditLinks)
	ON_UPDATE_COMMAND_UI_RANGE(ID_OLE_VERB_FIRST, ID_OLE_VERB_LAST, COleDocument::OnUpdateObjectVerbMenu)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHTMLContainerDoc construction/destruction

CHTMLContainerDoc::CHTMLContainerDoc() : szDoc(800,900)
{
	// Use OLE compound files
	m_nLabels = m_nTextEdits = m_nButtons = 0; // number elements of each type
	m_bLoading = FALSE;
	EnableCompoundFile();
}

CHTMLContainerDoc::~CHTMLContainerDoc()
{
}

BOOL CHTMLContainerDoc::OnNewDocument()
{
	if (!COleDocument::OnNewDocument())
		return FALSE;

	if (m_arrTree.GetSize() > 0)
	{
		CMainFrame *pFrame = (CMainFrame*)AfxGetApp()->GetMainWnd();
		ASSERT_VALID(pFrame);
		pFrame->OnClearAll();

		m_arrTree.RemoveAll();

	}
	
	m_nLabels = m_nTextEdits = m_nButtons = 0; // number elements of each type
	
	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CHTMLContainerDoc serialization

void CHTMLContainerDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}

	// Calling the base class COleDocument enables serialization
	//  of the container document's COleClientItem objects.
	COleDocument::Serialize(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CHTMLContainerDoc diagnostics

#ifdef _DEBUG
void CHTMLContainerDoc::AssertValid() const
{
	COleDocument::AssertValid();
}

void CHTMLContainerDoc::Dump(CDumpContext& dc) const
{
	COleDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CHTMLContainerDoc commands

void CHTMLContainerDoc::AddTreeElem(treeElem *pElem)
{
	m_arrTree.Add(pElem);
}

void CHTMLContainerDoc::OnTreeClicked(HTREEITEM item)
{
	CMainFrame *pFrame = (CMainFrame*)AfxGetApp()->GetMainWnd();
	ASSERT_VALID(pFrame);
	CHTMLContainerView* pView = (CHTMLContainerView*)pFrame->GetActiveView();
	ASSERT_VALID(pView);

	for(int i =0;i < m_arrTree.GetSize();i++)
	{
		treeElem* pElem = (treeElem*)m_arrTree.GetAt(i);
		if (item == pElem->m_htreeNode)
		{
			pView->InvalidateItem(pView->m_pSelection); // invalidating old element...
			pView->SetSelection(pElem->pHTMLItem);
			pView->InvalidateItem(pElem->pHTMLItem);
			
			POINT pt;
			CRect rect;
			CClientDC dc(pView);
			pView->OnPrepareDC(&dc);

			pView->GetClientRect(rect);
			CPoint delta = pView->GetScrollPosition();
			rect.top    = rect.top + delta.x;
			rect.bottom = rect.bottom + delta.x;
			rect.left   = rect.left + delta.y;
			rect.right  = rect.right + delta.y;
			
			pt.x = pElem->pHTMLItem->m_rect.left;
			pt.y = pElem->pHTMLItem->m_rect.top;
			if (!rect.PtInRect(pt))
			{
				pt.x = pt.x - 10;
				pt.y = pt.y - 10;
				pView->ScrollToPosition(pt);
			}
			return;
		}
	}


}

UINT CHTMLContainerDoc::GetObjectNumber(UINT type)
{
	switch(type)
	{
	case LABEL:
		return ++m_nLabels;
	case TEXT_EDIT:
		return ++m_nTextEdits;
	case BUTTON:
		return ++m_nButtons;
	default:
		return 0;
	}

	return 0;
}

void CHTMLContainerDoc::OnSelectObject(CHTMLContainerItem *pItem)
{
	CMainFrame *pFrame = (CMainFrame*)AfxGetApp()->GetMainWnd();
	ASSERT_VALID(pFrame);

	for(int i =0;i < m_arrTree.GetSize();i++)
	{
		treeElem* pElem = (treeElem*)m_arrTree.GetAt(i);
		if (pItem == pElem->pHTMLItem)
		{
			pFrame->OnSelectElem(i, pElem->m_htreeNode);
			return;
		}
	}
}

BOOL CHTMLContainerDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	CStdioFile myFile;
	CFileException fileException;

	try
	{
		CString strPath;

		if (lstrlen(lpszPathName) == 0)
			strPath = GetPathName();
		else
			strPath = lpszPathName;
		
		myFile.Open( lpszPathName, CFile::modeCreate | CFile::modeWrite | CFile::typeText);

		POSITION pos = GetStartPosition();
		while (pos != NULL)
		{
			CHTMLContainerItem* pItem = (CHTMLContainerItem*)GetNextItem(pos);
			pItem->SaveObjectCondition(&myFile);
		}
	
		myFile.Close();
	}
	catch (CFileException e)
	{
		CString error;
		error.Format("File could not be opened %s", e.m_cause);
		AfxMessageBox(error);
	}
	
	SetModifiedFlag(FALSE);
	return TRUE;
}

void CHTMLContainerDoc::OnUpdateFileSaveAs(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(IsModified());
}

void CHTMLContainerDoc::OnUpdateFileSave(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(IsModified());	
}

BOOL CHTMLContainerDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	CStdioFile myFile;
	CFileException fileException;
	CString str;

	CFileFind finder;

	if (!finder.FindFile(lpszPathName))
	{
		str.Format("������ �������� ����� %s", lpszPathName);
		AfxMessageBox(str, MB_ICONERROR | MB_OK);
		return FALSE;
	}

	if (!COleDocument::OnNewDocument())
		return FALSE;

	// deleting objects...
	OnEditClearAll();

	CMainFrame *pFrame = (CMainFrame*)AfxGetApp()->GetMainWnd();
	CHTMLContainerView* pView = NULL;

	if (pFrame)
	{
		pView = (CHTMLContainerView*)pFrame->GetActiveView();
		if (pView)
			pView->m_pSelection = NULL;
	}

	CRect rc;
	CString strPropValue;
	CParser parser;
	int nStrings = 0;

	m_nLabels = m_nTextEdits = m_nButtons = 0; // number elements of each type
	try
	{
		myFile.Open( lpszPathName, CFile::modeRead | CFile::typeText);
		while( myFile.ReadString(str)) 
		{
			nStrings++;
			try
			{
				m_bLoading = TRUE;
				parser.parseString(str);
				objElem* pElem = new objElem();

				pElem->m_nTypeObject = parser.m_ntypeObj;
				pElem->rcObject = parser.m_rc;
				pElem->strPropertyValue = parser.m_strValue;

				m_arrLoadedObjects.Add(pElem);

				m_bLoading = FALSE;
			}
			catch (CParserException* e)
			{
				CString err;
				TCHAR  szErrMessage[500];
				e->GetErrorMessage(szErrMessage, 400);
				err.Format("������ ����� � ������ %d: �������� - %s. ���������� �� ����� ���������! ", nStrings, szErrMessage);
				AfxMessageBox(err, MB_OK | MB_ICONERROR);
				e->Delete();
			}
		}
		myFile.Close();
	}
	catch (...)
	{
		CString error;
		error.Format("������ �������� ����� %s", lpszPathName);
		AfxMessageBox(error, MB_OK | MB_ICONERROR);
	}

	return TRUE;
}

BOOL CHTMLContainerDoc::parseString(CString str, UINT &nTypeObj, CRect &rc, CString &strPropValue)
{
	CParser  parser;

	parser.parseString(str);

	return FALSE;
}

void CHTMLContainerDoc::OnUpdateEditClearAll(CCmdUI* pCmdUI) 
{
	POSITION pos = GetStartPosition();	// first position of objects
	CHTMLContainerItem* pItem = (CHTMLContainerItem*)GetNextClientItem(pos);
	pCmdUI->Enable (pItem != NULL);
}

void CHTMLContainerDoc::OnEditClearAll() 
{
	POSITION pos = GetStartPosition();
	while (pos)
	{
		CHTMLContainerItem* pItem = (CHTMLContainerItem*)GetNextClientItem(pos);
		if (pItem)
			pItem->Delete();
	}
	SetModifiedFlag();

	CMainFrame *pFrame = (CMainFrame*)AfxGetApp()->GetMainWnd();
	if (pFrame)
	{
		ASSERT_VALID(pFrame);
		pFrame->OnClearAll();

		CHTMLContainerView* pView = (CHTMLContainerView*)pFrame->GetActiveView();
		if (pView)
		{
			ASSERT_VALID(pView);
			pView->m_pSelection = NULL;

			UpdateAllViews(NULL);
		}
	}

}

void CHTMLContainerDoc::OnCloseDocument() 
{
	COleDocument::OnCloseDocument();
}

BOOL CHTMLContainerDoc::SaveModified() 
{

	if (CDocument::IsModified())
	{
		if (lstrlen(GetPathName()) != 0)
		{
			OnSaveDocument(GetPathName());
		}
		else
		{
			CString strMessage;
			strMessage.Format(" ��������� ��������� ?", GetPathName());
			int nResult = AfxMessageBox(strMessage, MB_YESNOCANCEL | MB_ICONEXCLAMATION);

			switch(nResult)
			{
			case IDYES:
			{
					CString pathCntrFile;			
					char BASED_CODE szFilter[] = "HTMLContainer Files (*.cnt)|*.cnt|All Files (*.*)|*.*||";
					CFileDialog dlg(FALSE,"HTMLContainer Files",NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,szFilter);

					if(dlg.DoModal() != IDOK )
					{
						AfxMessageBox("���� � ���������� �� ������!");
						return FALSE;
					}
					else
					{
						((CHTMLContainerApp*)(AfxGetApp()))->m_strPathHTMLFile = pathCntrFile 
							= dlg.GetPathName();
					}	
					OnSaveDocument(pathCntrFile);
					SetPathName(pathCntrFile);
					return TRUE;
			}
			case IDNO:
				return FALSE;
			case IDCANCEL:
				return FALSE;
			}
		}
		
	}

	return TRUE;
}

void CHTMLContainerDoc::OnDeleteItem(CHTMLContainerItem *pItem)
{
	CMainFrame *pFrame = (CMainFrame*)AfxGetApp()->GetMainWnd();
	ASSERT_VALID(pFrame);

	CHTMLContainerView* pView = (CHTMLContainerView*)pFrame->GetActiveView();
	ASSERT_VALID(pView);
	
	for( int i =0; i < m_arrTree.GetSize(); i++ )
	{
		treeElem* pElem = (treeElem*)m_arrTree.GetAt(i);
		if (pItem == pElem->pHTMLItem)
		{
			CRect rc = pItem->m_rect;
			int nNewElem = pFrame->OnDeleteElem(i, pElem->m_htreeNode);
			pItem->Delete();
//			pView->m_pSelection = NULL;
//			UpdateAllViews(NULL);
			pView->InvalidateOldRect(rc);
			m_arrTree.RemoveAt(i);

			if (m_arrTree.GetSize() > 0 && nNewElem >= 0)
			{
				pElem = (treeElem*)m_arrTree.GetAt(nNewElem);
				pView->m_pSelection = pElem->pHTMLItem;
				pView->InvalidateItem(pElem->pHTMLItem);
			}
			else
			{
				pView->m_pSelection = NULL;
			}
			return;
		}
	}
}

TCHAR* CHTMLContainerDoc::GetElemName(CHTMLContainerItem *pItem)
{
	for( int i =0; i < m_arrTree.GetSize(); i++ )
	{
		treeElem* pElem = (treeElem*)m_arrTree.GetAt(i);
		if (pItem == pElem->pHTMLItem)
		{
			return pElem->szName;
			
		}
	}

	return NULL;
}

treeElem* CHTMLContainerDoc::GetElem(unsigned int nIndex)
{
	return (treeElem*)m_arrTree.GetAt(nIndex);
}

void CHTMLContainerDoc::OnComboClicked(UINT nIndex)
{
	treeElem* pElem = (treeElem*)m_arrTree.GetAt(nIndex);
	OnTreeClicked(pElem->m_htreeNode);
}

void CHTMLContainerDoc::OnChangeProperty(LPCTSTR lpszText, UINT nIndex)
{
	CMainFrame *pFrame = (CMainFrame*)AfxGetApp()->GetMainWnd();
	ASSERT_VALID(pFrame);

	CHTMLContainerView* pView = (CHTMLContainerView*)pFrame->GetActiveView();
	ASSERT_VALID(pView);

	if (pView->m_pSelection)
	{
		treeElem* pElem = (treeElem*)m_arrTree.GetAt(nIndex);
		pElem->pHTMLItem->SetStringValue(lpszText);
		pView->InvalidateItem(pElem->pHTMLItem);
	}
}


BOOL CHTMLContainerDoc::isIntersectObject(CRect rc)
{
	CMainFrame *pFrame = (CMainFrame*)AfxGetApp()->GetMainWnd();
	ASSERT_VALID(pFrame);

	CHTMLContainerView* pView = (CHTMLContainerView*)pFrame->GetActiveView();
	ASSERT_VALID(pView);

	POSITION pos = GetStartPosition();

	while (pos != NULL)
	{
		CHTMLContainerItem* pItem = (CHTMLContainerItem*)GetNextItem(pos);
		
		if (pItem == pView->m_pSelection)
			continue;

		CRect rectT;
		if (rectT.IntersectRect(rc, pItem->m_rect))
		{
			return TRUE; // return top item at point
		}

	}
	
	return FALSE;

}

void CHTMLContainerDoc::OnFileCreatehtml() 
{
	if (!prepareBeforeHTML())
		return;

	CString pathHTMLFile = ((CHTMLContainerApp*)(AfxGetApp()))->m_strPathHTMLFile;
	CHTMLFile myHtmlFile;

	if (myHtmlFile.processContainerFile(GetPathName()))
	{
		if (myHtmlFile.createOutputFile(pathHTMLFile))
		{
			ShellExecute(0, _T("open"),
			pathHTMLFile, 0, 0, SW_SHOWNORMAL);
		}
	}
	else
	{
		AfxMessageBox("��������� ������ ��� ��������� ����� � ������������!\n  HTML ���� �� ������!");
	}
}

void CHTMLContainerDoc::OnUpdateFileCreatehtml(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_arrTree.GetSize() > 0);
}

void CHTMLContainerDoc::OnFileCreatehtmlAs() 
{
	((CHTMLContainerApp*)(AfxGetApp()))->m_strPathHTMLFile = "";
	OnFileCreatehtml();
}

void CHTMLContainerDoc::OnUpdateFileCreatehtmlAs(CCmdUI* pCmdUI) 
{
//	pCmdUI->Enable(IsModified() && m_arrTree.GetSize() > 0);
	pCmdUI->Enable(m_arrTree.GetSize() > 0);
}

BOOL CHTMLContainerDoc::prepareBeforeHTML()
{

	CHTMLFile myHtmlFile;
	CString pathHTMLFile = ((CHTMLContainerApp*)(AfxGetApp()))->m_strPathHTMLFile;

	if (IsModified())
	{
		if (!SaveModified() || lstrlen(GetPathName()) == 0)
		{
			AfxMessageBox("���� HTML ��������� ������ ����� ���������� ��������� ���������",
				MB_ICONEXCLAMATION | MB_OK);
			return FALSE;
		}
	}

	if ( pathHTMLFile == "")
	{
		char BASED_CODE szFilter[] = "HTML Files (*.html)|*.htm|All Files (*.*)|*.*||";
		CFileDialog dlg(FALSE,"HTML Files",NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,szFilter);

		if(dlg.DoModal() != IDOK )
		{
			AfxMessageBox("HTML ���� �� ������!");
			return FALSE;
		}
		else
		{
			((CHTMLContainerApp*)(AfxGetApp()))->m_strPathHTMLFile = pathHTMLFile 
				 = dlg.GetPathName();
		}
	}

	return TRUE;
}

void CHTMLContainerDoc::OnFileCreateactivexhtml() 
{
	if (!prepareBeforeHTML())
		return;

	CString pathHTMLFile = ((CHTMLContainerApp*)(AfxGetApp()))->m_strPathHTMLFile;
	CHTMLFile myHtmlFile;

	if (myHtmlFile.processContainerFile(GetPathName()))
	{
		if (myHtmlFile.createOutputFile(pathHTMLFile, TRUE))
		{
			ShellExecute(0, _T("open"),
			pathHTMLFile, 0, 0, SW_SHOWNORMAL);
		}
	}
	else
	{
		AfxMessageBox("��������� ������ ��� ��������� ����� � ������������!\n  HTML ���� �� ������!");
	}

}

void CHTMLContainerDoc::OnUpdateFileCreateactivexhtml(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_arrTree.GetSize() > 0);
}
