// HTMLContainerDoc.h : interface of the CHTMLContainerDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_HTMLCONTAINERDOC_H__4D33140B_2F5F_11D6_B72D_00D0B728548D__INCLUDED_)
#define AFX_HTMLCONTAINERDOC_H__4D33140B_2F5F_11D6_B72D_00D0B728548D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CParserException : public CException
{
	DECLARE_DYNAMIC(CParserException)
public:
// Constructor
	CParserException(char* pchMessage);

public:
	~CParserException() {}
	virtual BOOL GetErrorMessage(LPTSTR lpstrError, UINT nMaxError,
		PUINT pnHelpContext = NULL);
private:
	CString m_strMessage;
	int m_nError;
};

class CLoadingException : public CException
{
	DECLARE_DYNAMIC(CLoadingException)
public:
// Constructor
	CLoadingException(char* pchMessage);

public:
	~CLoadingException() {}
	virtual BOOL GetErrorMessage(LPTSTR lpstrError, UINT nMaxError,
		PUINT pnHelpContext = NULL);
private:
	CString m_strMessage;
	int m_nError;
};

class CParser : public CObject
{
	DECLARE_DYNAMIC(CParser)
public:
	CParser();
	CRect   m_rc;
	UINT    m_ntypeObj;
	CString m_strValue;
public:
	void checkSubString(char* szStr);
	~CParser();
	BOOL parseString(CString str);
};


class CHTMLContainerDoc : public COleDocument
{
protected: // create from serialization only
	CHTMLContainerDoc();
	DECLARE_DYNCREATE(CHTMLContainerDoc)

// Attributes
public:
	CSize     szDoc;
	CPtrArray m_arrTree;           // array of Tree elements
	CPtrArray m_arrLoadedObjects;  // array of Loaded Objects
	UINT	  m_nLabels, m_nTextEdits, m_nButtons;
	BOOL      m_bLoading;

// Operations
public:
	friend class CMainFrame;
	friend class CHTMLContainerApp;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHTMLContainerDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual void OnCloseDocument();
	protected:
	virtual BOOL SaveModified();
	//}}AFX_VIRTUAL

// Implementation
public:
	BOOL prepareBeforeHTML();
	BOOL isIntersectObject(CRect rc);
	void OnChangeProperty(LPCTSTR szText, UINT nIndex);
	void OnComboClicked(UINT nIndex);
	treeElem* GetElem(unsigned int nIndex);
	TCHAR* GetElemName(CHTMLContainerItem* pItem);
	void OnDeleteItem(CHTMLContainerItem* pItem);
	BOOL parseString(CString str, UINT&nTypeObj, CRect& rc, CString &strPropValue);
	void OnSelectObject(CHTMLContainerItem* pItem);
	UINT GetObjectNumber(UINT type);
	void OnTreeClicked(HTREEITEM item);
	void AddTreeElem(treeElem* pElem);
	virtual ~CHTMLContainerDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CHTMLContainerDoc)
	afx_msg void OnUpdateFileSaveAs(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileSave(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditClearAll(CCmdUI* pCmdUI);
	afx_msg void OnEditClearAll();
	afx_msg void OnFileCreatehtml();
	afx_msg void OnUpdateFileCreatehtml(CCmdUI* pCmdUI);
	afx_msg void OnFileCreatehtmlAs();
	afx_msg void OnUpdateFileCreatehtmlAs(CCmdUI* pCmdUI);
	afx_msg void OnFileCreateactivexhtml();
	afx_msg void OnUpdateFileCreateactivexhtml(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HTMLCONTAINERDOC_H__4D33140B_2F5F_11D6_B72D_00D0B728548D__INCLUDED_)
