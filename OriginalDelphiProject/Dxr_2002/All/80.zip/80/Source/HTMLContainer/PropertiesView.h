#if !defined(AFX_PROPERTIESVIEW_H__339A4E27_5CDB_44EE_B8E2_EB605113CB32__INCLUDED_)
#define AFX_PROPERTIESVIEW_H__339A4E27_5CDB_44EE_B8E2_EB605113CB32__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropertiesView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropertiesView form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

//#include "GridBase\gridcell.h"
//#include "GridBase\gridctrl.h"
#include "Propedit.h"

class CHTMLContainerDoc;

class CPropertiesView : public CFormView
{
protected:
	CPropertiesView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPropertiesView)
	CHTMLContainerDoc* GetDocument();

// Form Data
public:
	//{{AFX_DATA(CPropertiesView)
	enum { IDD = IDD_PROPERTIES };
	CStatic	m_stPropertyName;
	CPropertyEdit m_editProperty;
//	CPropertyEdit m_editProperty;
//	CPropEdit	m_EditWnd;
	CComboBox	m_Elements;
//	CPropertyEdit  m_Edit2;
	//}}AFX_DATA
// Attributes
public:

// Operations
public:
	void disableProperties();
	void ChangeProperty();
	int  OnDeleteItem(UINT nItem);
	void OnClearAll();
	BOOL OnSelectObject(int nIndex);
	void OnInsertObject(int nIndex);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPropertiesView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPropertiesView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPropertiesView)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSelchangeElements();
	//}}AFX_MSG
//	afx_msg LRESULT OnInsertObject(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPERTIESVIEW_H__339A4E27_5CDB_44EE_B8E2_EB605113CB32__INCLUDED_)
