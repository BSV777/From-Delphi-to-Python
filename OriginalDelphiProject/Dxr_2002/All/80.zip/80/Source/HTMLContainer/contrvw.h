// ContrVw.h : interface of the CHTMLContainerView class
//
/////////////////////////////////////////////////////////////////////////////

class CHTMLContainerItem;

class CHTMLContainerView : public CScrollView
{
	CSize szLogScreen;					// ���������� �������� � ���������� ����� ������
	CRect m_rcDefault;					// Default Rect

protected: // create from serialization only
	CHTMLContainerView();
	DECLARE_DYNCREATE(CHTMLContainerView)

// Attributes
public:
	CHTMLContainerDoc* GetDocument();
	// m_pSelection holds the selection to the current CHTMLContainerItem.
	// For many applications, such a member variable isn't adequate to
	//  represent a selection, such as a multiple selection or a selection
	//  of objects that are not CHTMLContainerItem objects.  This selection
	//  mechanism is provided just to help you get started.

	// TODO: replace this selection mechanism with one appropriate to your app.
	CHTMLContainerItem* m_pSelection;
	friend class CMainFrame;

// Operations
public:
	CHTMLContainerItem* HitTestItems(CPoint point);
	void SetSelection(CHTMLContainerItem* pItem);
	void SetupTracker(CHTMLContainerItem* pItem, CRectTracker* pTracker);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHTMLContainerView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual BOOL IsSelected(const CObject* pDocItem) const;// Container support
	virtual BOOL OnScrollBy(CSize sizeScroll, BOOL bDoScroll = TRUE);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
public:
	void InvalidateOldRect(CRect rc);
	void InvalidateItem(CHTMLContainerItem* pItem);
	void tryInflateRect(CRect* prc);
	void processLoading(UINT nTypeObject, CRect rc, LPCTSTR strProperty);
	CHTMLContainerItem* isIntersectWithObject(CRect rc);
	BOOL processCreation(CRect rect);
	virtual ~CHTMLContainerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CHTMLContainerView)
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnCancelEditCntr();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnEditClear();
	afx_msg void OnUpdateEditClear(CCmdUI* pCmdUI);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnItemProperties();
	afx_msg void OnItemDelete();
	afx_msg void OnUpdateItemDelete(CCmdUI* pCmdUI);
	afx_msg void OnMoveDown();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ContrVw.cpp
inline CHTMLContainerDoc* CHTMLContainerView::GetDocument()
   { return (CHTMLContainerDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

class CIntersectTracker : public CRectTracker
{
public: 
	friend class CMainFrame;
	CHTMLContainerDoc*  m_pDoc;
	CHTMLContainerView* m_pView;
	BOOL                m_bTextEditControl;
	CIntersectTracker(CHTMLContainerDoc*  pDoc,
					  CHTMLContainerView* pView,
					  BOOL bTextEditing = FALSE);
	virtual ~CIntersectTracker(); 
	virtual void DrawTrackerRect( LPCRECT lpRect,
								  CWnd* pWndClipTo, 
								  CDC* pDC, 
								  CWnd* pWnd ); 

	virtual void OnChangedRect(const CRect& rectOld ); 
	virtual void  AdjustRect( int nHandle, LPRECT lpRect );
	BOOL isIntersectRect(CRect rc);

};

