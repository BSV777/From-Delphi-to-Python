#if !defined(__MYBAR_H__)
#define __MYBAR_H__

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// mybar.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTreeBar window
//#include "HTMLContainerDoc.h"
//#include "ContrVw.h"

class CHTMLContainerDoc;
class CHTMLContainerView;
class CHTMLContainerItem;

#ifndef baseCMyBar
#define baseCMyBar CSizingControlBarG
#endif


class CTreeBar : public baseCMyBar
{
// Construction
public:
	CTreeBar();
	CTreeBar(CHTMLContainerDoc* pDoc, CHTMLContainerView* pView);

// Attributes
public:
	friend class CMainFrame;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTreeBar)
	//}}AFX_VIRTUAL

// Implementation
public:
	BOOL SelectItem(treeElem* pElem);
	void OnDeleteItem(HTREEITEM hitem);
	void OnClearAll();
	CHTMLContainerDoc* GetDocument();
	virtual ~CTreeBar();

protected:
	CTreeCtrl  m_tree;       // instant bar child
//	CStatic    m_stText;
//	CComboBox  m_cmbProperties;

	CImageList m_imageList;
	CHTMLContainerDoc* m_pDoc;
	CHTMLContainerView* m_pView;
	HTREEITEM  m_htreeActiveNode;

	// Generated message map functions
protected:
	void OnSelectObject(HTREEITEM hItem);
	//{{AFX_MSG(CTreeBar)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
//	afx_msg void OnPaint();
	//}}AFX_MSG
	afx_msg LRESULT OnInsertObject(WPARAM wParam, LPARAM lParam);
//	afx_msg LRESULT OnSelectObject(WPARAM wParam, LPARAM lParam);
	afx_msg void OnTreeChanged(NMHDR* pNotifyStruct, LRESULT* result);

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(__MYBAR_H__)
