// CntrItem.cpp : implementation of the CHTMLContainerItem class
//

#include "stdafx.h"
#include "HTMLContainer.h"

#include "HTMLContainerDoc.h"
#include "CntrItem.h"
#include "ContrVw.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define	DISPID_EDTTEXT    0x1
#define DISPID_LBLTEXT    0x2
#define DISPID_BTNCAPTION 0x1

/////////////////////////////////////////////////////////////////////////////
// CHTMLContainerItem implementation

IMPLEMENT_SERIAL(CHTMLContainerItem, COleClientItem, 0)

CHTMLContainerItem::CHTMLContainerItem(CHTMLContainerDoc* pContainer)
	: COleClientItem(pContainer),szMax(600, 700)
{
	// TODO: add one-time construction code here
	m_rect.SetRect(10, 10, 50, 50);
	m_ntypeObj = 0;
}



CHTMLContainerItem::CHTMLContainerItem(CHTMLContainerDoc* pContainer, CRect rc)
	: COleClientItem(pContainer), szMax(600, 700)
{
	//m_rect.SetRect(rc.top, rc.left, rc.bottom, rc.right);
	m_rect.SetRect(rc.left, rc.top, rc.right, rc.bottom);
	m_ntypeObj = 1;
}

CHTMLContainerItem::~CHTMLContainerItem()
{
	// TODO: add cleanup code here

}


void CHTMLContainerItem::OnChange(OLE_NOTIFICATION nCode, DWORD dwParam)
{
	ASSERT_VALID(this);

	COleClientItem::OnChange(nCode, dwParam);

	// When an item is being edited (either in-place or fully open)
	//  it sends OnChange notifications for changes in the state of the
	//  item or visual appearance of its content.

	// TODO: invalidate the item by calling UpdateAllViews
	//  (with hints appropriate to your application)

	GetDocument()->UpdateAllViews(NULL);
		// for now just update ALL views/no hints

}

BOOL CHTMLContainerItem::OnChangeItemPosition(const CRect& rectPos)
{
	ASSERT_VALID(this);

	CHTMLContainerView* pView = GetActiveView();
	if ( !pView )	return FALSE;

	CRect r = rectPos;
	CClientDC dc(0);
	pView->OnPrepareDC(&dc);
	dc.DPtoLP(r);

	if (r != m_rect)
		ChangeSelection(r);

	return COleClientItem::OnChangeItemPosition(rectPos);

}

void CHTMLContainerItem::OnGetItemPosition(CRect& rPosition)
{
	// Get the coordinates of the item being edited in place (pixels)

	ASSERT_VALID(this);
	rPosition = m_rect;
	CHTMLContainerView* pView = GetActiveView();
	ASSERT_VALID(pView);
	CClientDC dc(0);
	pView->OnPrepareDC(&dc);
	dc.LPtoDP(rPosition);
}

void CHTMLContainerItem::OnActivate()
{
	// allow only one inplace active item per frame
	CView* pView = GetActiveView();
	ASSERT_VALID(pView);
	COleClientItem* pItem = GetDocument()->GetInPlaceActiveItem(pView);
	if (pItem != NULL && pItem != this)
		pItem->Close();

	COleClientItem::OnActivate();
}

void CHTMLContainerItem::OnDeactivateUI(BOOL bUndoable)
{
	COleClientItem::OnDeactivateUI(bUndoable);

	// hide the object if it is not an outside-in object
	DWORD dwMisc = 0;
	m_lpObject->GetMiscStatus(GetDrawAspect(), &dwMisc);
	if (dwMisc & OLEMISC_INSIDEOUT)
		DoVerb(OLEIVERB_HIDE, NULL);
}

void CHTMLContainerItem::Serialize(CArchive& ar)
{
	ASSERT_VALID(this);

	// Call base class first to read in COleClientItem data.
	// Since this sets up the m_pDocument pointer returned from
	//  CHTMLContainerItem::GetDocument, it is a good idea to call
	//  the base class Serialize first.
	COleClientItem::Serialize(ar);

	// now store/retrieve data specific to CHTMLContainerItem
	if (ar.IsStoring())
	{
		// TODO: add storing code here
		ar << m_rect;
	}
	else
	{
		// TODO: add loading code here
		ar >> m_rect;
	}
}

/////////////////////////////////////////////////////////////////////////////
// CHTMLContainerItem diagnostics

#ifdef _DEBUG
void CHTMLContainerItem::AssertValid() const
{
	COleClientItem::AssertValid();
}

void CHTMLContainerItem::Dump(CDumpContext& dc) const
{
	COleClientItem::Dump(dc);
}
#endif

/////////////////////////////////////////////////////////////////////////////

void CHTMLContainerItem::ChangeSelection(CRect r)
{
	InvalidateItem();	// invalidate old item
	m_rect = r;			// update to new rectangle
	InvalidateItem();	// invalidate new item
	if (IsInPlaceActive())
		SetItemRects();

	GetDocument()->SetModifiedFlag();
}

void CHTMLContainerItem::InvalidateItem()
{
	GetDocument()->UpdateAllViews(NULL, UPD_ITEM, this);
//	GetDocument()->UpdateAllViews(NULL, NULL, this);
}

void CHTMLContainerItem::UpdateFromServerExtent()
{
	CSize szReal, szObj = m_rect.Size();

	if (!GetCachedExtent(&szReal))	// HIMETRIC
		return;

	CClientDC dc(NULL);

	dc.HIMETRICtoDP(&szReal);		// Pixels
	
	if ( (szReal.cx != szObj.cx || szReal.cy != szObj.cy)
			&&	!IsInPlaceActive() ) 
		ChangeSelection (CRect(m_rect.TopLeft(),CSize (min(szReal.cx,szMax.cx),
								min(szReal.cy,szMax.cy))));
}

BOOL CHTMLContainerItem::SaveObjectCondition(CStdioFile *pFile)
{
	CString strCondition;
	TCHAR   szTypeObj[30] = "";
	TCHAR   szTypeProperty[30] = "";
	switch(m_ntypeObj)
	{
	case LABEL:
		{
			lstrcpy(szTypeObj, TEXT("<Label"));
			lstrcpy(szTypeProperty,TEXT("Text"));
			break;
		}
	case TEXT_EDIT:
		{
			lstrcpy(szTypeObj, TEXT("<TextEdit"));
			lstrcpy(szTypeProperty,TEXT("Text"));
			break;
		}
	case BUTTON:
		{
			lstrcpy(szTypeObj, TEXT("<Button"));
			lstrcpy(szTypeProperty,TEXT("Caption"));
			break;
		}
	}

	if (m_ntypeObj != TEXT_EDIT)
	{

		strCondition.Format("%s left=\"%d\"; top=\"%d\"; height=\"%d\"; width=\"%d\"; %s=\"%s\">\n",
											szTypeObj,
											m_rect.left,
											m_rect.top,
											m_rect.Height(),
											m_rect.Width(),
											szTypeProperty,
											(LPCTSTR)GetStringValue());
	}
	else
	{
		strCondition.Format("%s left=\"%d\"; top=\"%d\"; width=\"%d\"; %s=\"%s\">\n",
											szTypeObj,
											m_rect.left,
											m_rect.top,
											m_rect.Width(),
											szTypeProperty,
											(LPCTSTR)GetStringValue());
	}

	try
	{
		pFile->WriteString((LPCTSTR)strCondition);
	}
	catch (CFileException e)
	{
		CString error;
		error.Format("Error saving the element! Eror is:  %s", e.m_cause);
		AfxMessageBox(error);
	}

	return TRUE;
}

CString CHTMLContainerItem::GetStringValue()
{
	CString result;
	DISPID dwDispID = NULL;

	switch(m_ntypeObj)
	{
	case LABEL:
		{
			dwDispID = DISPID_LBLTEXT;
			break;
		}
	case TEXT_EDIT:
		{
			dwDispID = DISPID_EDTTEXT;
			break;
		}
	case BUTTON:
		{
			dwDispID = DISPID_BTNCAPTION;
			break;
		}
	}

	try
	{
		LPDISPATCH pDispatch;
		HRESULT hr = m_lpObject->QueryInterface(IID_IDispatch,(LPVOID*)&pDispatch);
		if (SUCCEEDED(hr) && dwDispID != NULL)
		{
			if (SUCCEEDED(hr) && dwDispID != NULL)
			{
				COleDispatchDriver dispDrv(pDispatch);
				dispDrv.InvokeHelper(dwDispID, DISPATCH_PROPERTYGET, VT_BSTR, (void*)&result, NULL);
			}
		}
	}
	catch(COleException *e)
	{
		TRACE ("COleException caught. HRESULT = %x\n", e->m_sc);
		e->Delete();
	}

	return result;
}

void CHTMLContainerItem::SetStringValue(LPCTSTR lpszNewValue)
{
	DISPID dwDispID = NULL;
	static BYTE parms[] = VTS_BSTR;

	switch(m_ntypeObj)
	{
	case LABEL:
		{
			dwDispID = DISPID_LBLTEXT;
			break;
		}
	case TEXT_EDIT:
		{
			dwDispID = DISPID_EDTTEXT;
			break;
		}
	case BUTTON:
		{
			dwDispID = DISPID_BTNCAPTION;
			break;
		}
	}

	LPDISPATCH pDispatch;
	HRESULT hr = m_lpObject->QueryInterface(IID_IDispatch,(LPVOID*)&pDispatch);
	if (SUCCEEDED(hr) && dwDispID != NULL)
	{
		try
		{
			COleDispatchDriver dispDrv(pDispatch);
			dispDrv.InvokeHelper(dwDispID, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, lpszNewValue);
		}
		catch(COleException *e)
		{
			TRACE ("COleException caught. HRESULT = %x\n", e->m_sc);
			e->Delete();
		}
	}

}

BOOL CHTMLContainerItem::IsModified() const
{
	// espesially for this stupid competition I have to
	// overwrite this method...
	return FALSE;
}
