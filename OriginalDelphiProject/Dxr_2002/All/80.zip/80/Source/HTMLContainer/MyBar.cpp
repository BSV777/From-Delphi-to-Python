// mybar.cpp : implementation file
//

#include "stdafx.h"
#include "HTMLContainer.h"
#include "mybar.h"
#include "HTMLContainerDoc.h"
#include "ContrVw.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define IDC_TREEVIEW      WM_USER + 1000
#define IDC_CMBPROPERTIES WM_USER + 1001
#define IDC_STCHEADER     WM_USER + 1002

/////////////////////////////////////////////////////////////////////////////
// CTreeBar

CTreeBar::CTreeBar()
{
	m_pDoc  = NULL;
	m_pView = NULL;
}

CTreeBar::~CTreeBar()
{
}

CTreeBar::CTreeBar(CHTMLContainerDoc* pDoc, CHTMLContainerView* pView)
{
	m_pDoc  = pDoc;
	m_pView = pView;
}


BEGIN_MESSAGE_MAP(CTreeBar, baseCMyBar)
	//{{AFX_MSG_MAP(CTreeBar)
	ON_WM_CREATE()
//	ON_WM_PAINT()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_USERINSERTOBJECT, OnInsertObject)
//	ON_MESSAGE(WM_USERSELECTOBJECT, OnSelectObject)
//	ON_NOTIFY(NM_CLICK, IDC_TREEVIEW, OnTreeClicked)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREEVIEW, OnTreeChanged)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CTreeBar message handlers

int CTreeBar::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (baseCMyBar::OnCreate(lpCreateStruct) == -1)
		return -1;

	SetSCBStyle(GetSCBStyle() | SCBS_SIZECHILD);

	if (!m_tree.Create(WS_CHILD|WS_VISIBLE|
		TVS_HASLINES|TVS_HASBUTTONS|TVS_LINESATROOT,
		CRect(0, 0, 0, 0), this, IDC_TREEVIEW))
	{
		TRACE0("Failed to create bar child\n");
		return -1;		
	}

	m_tree.ModifyStyleEx(0, WS_EX_CLIENTEDGE);

/*	if (!m_cmbProperties.Create( WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST , CRect(0,0,0,0), this, IDC_CMBPROPERTIES))
	{
		TRACE0("Failed to create combo properties\n");
		return -1;		
	}
	m_cmbProperties.ModifyStyleEx(0, WS_EX_CLIENTEDGE);

	if (!m_stText.Create( "�������� �������", WS_CHILD|WS_VISIBLE | SS_CENTER , CRect(0,0,0,0), this, IDC_STCHEADER))
	{
		TRACE0("Failed to create Header textEdit\n");
		return -1;		
	}
	m_stText.ModifyStyleEx(0, WS_EX_CLIENTEDGE);*/

	m_imageList.Create(16, 16, 0, 7, 7); // 32, 32 for large icons
	HICON hIcon[7];

	hIcon[0] = AfxGetApp()->LoadIcon(IDI_DOCUMENT);
	hIcon[1] = AfxGetApp()->LoadIcon(IDI_BUTTON);
	hIcon[2] = AfxGetApp()->LoadIcon(IDI_SBUTTON);
	hIcon[3] = AfxGetApp()->LoadIcon(IDI_EDIT);
	hIcon[4] = AfxGetApp()->LoadIcon(IDI_SEDIT);
	hIcon[5] = AfxGetApp()->LoadIcon(IDI_LABEL);
	hIcon[6] = AfxGetApp()->LoadIcon(IDI_SLABEL);

	for (int n = 0; n < 7; n++)
	{
		m_imageList.Add(hIcon[n]);
	}

	m_tree.SetImageList(&m_imageList, TVSIL_NORMAL);

	HTREEITEM hDocument;

	TV_INSERTSTRUCT tvinsert;
//	POSITION pos;

	CString strRoot;

	strRoot = _T("��������");

	tvinsert.hParent = NULL;
	tvinsert.hInsertAfter = TVI_LAST;
	tvinsert.item.mask = TVIF_IMAGE | TVIF_SELECTEDIMAGE | TVIF_TEXT;
	tvinsert.item.hItem = NULL; 
	tvinsert.item.state = 0;
	tvinsert.item.stateMask = 0;
	tvinsert.item.cchTextMax = 6;
	tvinsert.item.iSelectedImage = 0;
	tvinsert.item.cChildren = 0;
	tvinsert.item.lParam = 0;

	tvinsert.item.pszText = (char*)(LPCTSTR)strRoot;
	tvinsert.item.iImage = 0;
	tvinsert.item.iSelectedImage = 0;
	hDocument = m_tree.InsertItem(&tvinsert);

	return 0;
}

LRESULT CTreeBar::OnInsertObject(WPARAM wParam, LPARAM lParam)
{
	//AfxMessageBox("ObInsertObject");
	CHTMLContainerDoc* pDoc = GetDocument();
	CString strText;
	HTREEITEM hDocument = m_tree.GetRootItem();

	TV_INSERTSTRUCT* tvinsert = new TV_INSERTSTRUCT;

	tvinsert->hParent = hDocument;
	tvinsert->hInsertAfter = TVI_LAST;
	tvinsert->item.mask = TVIF_IMAGE | TVIF_SELECTEDIMAGE | TVIF_TEXT;
	tvinsert->item.hItem = NULL; 
	tvinsert->item.state = 0;
	tvinsert->item.stateMask = 0;
	tvinsert->item.cchTextMax = 128;
	tvinsert->item.iSelectedImage = 0;
	tvinsert->item.cChildren = 0;
	tvinsert->item.lParam = 0;

	UINT n_object = pDoc->GetObjectNumber(lParam);

	switch (lParam)
	{
	case LABEL:
		{
			strText.Format("%s %d",_T("Label"),n_object);
			tvinsert->item.pszText = (char*)(LPCTSTR)strText;
			tvinsert->item.iImage = 5;
			tvinsert->item.iSelectedImage = 6;
			break;
		}

	case TEXT_EDIT :
		{
			strText.Format("%s %d",_T("Text Edit"),n_object);
			tvinsert->item.pszText = (char*)(LPCTSTR)strText;
			tvinsert->item.iImage = 3;
			tvinsert->item.iSelectedImage = 4;
			break;

		}

	case BUTTON:
		{
			strText.Format("%s %d",_T("Button"),n_object);
			tvinsert->item.pszText = (char*)(LPCTSTR)strText;
			tvinsert->item.iImage = 1;
			tvinsert->item.iSelectedImage = 2;
			break;
		}

	default:  // error ?
		return 0;
	}

	treeElem* ptreeElem = new treeElem();
	memset(ptreeElem,0, sizeof(treeElem));

	CHTMLContainerItem* pItem = (CHTMLContainerItem*)wParam;
	ASSERT(pItem != 0);

	ptreeElem->m_htreeNode = m_tree.InsertItem(tvinsert);
	ptreeElem->pHTMLItem = pItem;
	lstrcpy(ptreeElem->szName, (LPCTSTR)strText);

	m_tree.SelectItem(ptreeElem->m_htreeNode);
	m_tree.Select(ptreeElem->m_htreeNode, TVGN_CARET);
		
	pDoc->AddTreeElem(ptreeElem);

	return 0;
}

//void CTreeBar::OnTreeClicked(NMHDR* pNotifyStruct, LRESULT* result)
/*void CTreeBar::OnTreeClicked(UINT nFlags, CPoint point)
{
	UINT uFlags;
	HTREEITEM hSelItem = m_tree.HitTest(point, &uFlags);

	if ((hSelItem != NULL) && (TVHT_ONITEM & uFlags))
	{
		CHTMLContainerDoc* pDoc = GetDocument();
		pDoc->OnTreeClicked(hSelItem);

	}

//	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNotifyStruct;
	

//	HTREEITEM hSelItem = m_tree.GetSelectedItem();
//	HTREEITEM hSelItem = pNMTreeView->itemNew.hItem;
//	if (hSelItem != NULL)
//		pDoc->OnTreeClicked(hSelItem);

}*/

//LRESULT CTreeBar::OnSelectObject(WPARAM wParam, LPARAM lParam)
void CTreeBar::OnSelectObject(HTREEITEM hItem)
{
	ASSERT(hItem != 0);
	m_tree.SelectItem(hItem);
}

void CTreeBar::OnTreeChanged(LPNMHDR pnmhdr, LRESULT* pLResult)
{
	CHTMLContainerDoc* pDoc = GetDocument();
	HTREEITEM hSelItem = m_tree.GetSelectedItem();

	if (!pDoc->m_bLoading)
	{
		if (hSelItem != NULL)
			pDoc->OnTreeClicked(hSelItem);
	}
}

CHTMLContainerDoc* CTreeBar::GetDocument()
{
	CDocTemplate* pTemplate = ((CHTMLContainerApp*) AfxGetApp())->pDocTemplate;
	ASSERT_VALID(pTemplate);

	POSITION pos = pTemplate->GetFirstDocPosition();
	CHTMLContainerDoc* pDoc = (CHTMLContainerDoc*)pTemplate->GetNextDoc(pos);
	ASSERT_VALID(pDoc);
	
	return pDoc;
}

void CTreeBar::OnClearAll()
{
	// clearing the array...
	CHTMLContainerDoc* pDoc = GetDocument();
	pDoc->m_arrTree.RemoveAll();

	HTREEITEM hRoot = m_tree.GetRootItem();

	HTREEITEM hNextItem;
	HTREEITEM hChildItem = m_tree.GetChildItem(hRoot);

	while (hChildItem != NULL)
	{
		hNextItem = m_tree.GetNextItem(hChildItem, TVGN_NEXT);
		m_tree.DeleteItem(hChildItem);
		hChildItem = hNextItem;
	}
}

void CTreeBar::OnDeleteItem(HTREEITEM hitem)
{
	m_tree.DeleteItem(hitem);
}

BOOL CTreeBar::SelectItem(treeElem* pElem)
{
	CHTMLContainerDoc* pDoc = GetDocument();

	m_tree.SetItem(pElem->m_htreeNode, TVIF_STATE, NULL, 0, 0, TVIS_BOLD, 
      TVIS_BOLD, 0);

	CDC* pDC = m_tree.GetDC();
	RECT r;
	if ( m_tree.GetItemRect(pElem->m_htreeNode, &r, FALSE) )
	{

		CBrush backBrush(GetSysColor(COLOR_BTNFACE));
//		ASSERT_VALID(backBrush);

		pDC->FillRect(&r, &backBrush);
//		int s = ::FillRect (hdc, &rc, backBrush);
		m_tree.SelectItem(pElem->m_htreeNode);

	}

	return TRUE;

}

/*void CTreeBar::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CRect r;
	
	CDC* pDC = m_tree.GetDC();
	HTREEITEM hItem = m_tree.GetSelectedItem();
	if (hItem)
	{

		if ( m_tree.GetItemRect(hItem, &r, FALSE) )
		{

			CBrush backBrush(GetSysColor(COLOR_BTNFACE));
			pDC->FillRect(&r, &backBrush);
		}
	
	}

	// Do not call baseCMyBar::OnPaint() for painting messages
}*/
