// mybar.cpp : implementation file
//

#include "stdafx.h"
#include "HTMLContainer.h"
#include "mybar2.h"
#include "HTMLContainerDoc.h"
#include "ContrVw.h"
#include "PropertiesView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define IDC_TREEVIEW WM_USER + 1000

/////////////////////////////////////////////////////////////////////////////
// CPropertiesBar

CPropertiesBar::CPropertiesBar()
{
	m_pDoc  = NULL;
	m_pView = NULL;
	ZeroMemory(&m_Context, sizeof(m_Context));
	// Create a frame object.
	CRuntimeClass *pRuntimeClass = RUNTIME_CLASS(CFrameWnd);
	CObject* pObject = pRuntimeClass->CreateObject();
	ASSERT( pObject->IsKindOf( RUNTIME_CLASS( CFrameWnd ) ) );
	m_pFrameWnd = (CFrameWnd *)pObject;
}

CPropertiesBar::~CPropertiesBar()
{
}

CPropertiesBar::CPropertiesBar(CHTMLContainerDoc* pDoc, CHTMLContainerView* pView)
{
	m_pDoc  = pDoc;
	m_pView = pView;
}


BEGIN_MESSAGE_MAP(CPropertiesBar, baseCMyBar)
	//{{AFX_MSG_MAP(CPropertiesBar)
	ON_WM_CREATE()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CPropertiesBar message handlers


BOOL CPropertiesBar::Create( CWnd* pParentWnd, CRuntimeClass *pViewClass,	
					   CCreateContext *pContext, LPCTSTR lpszWindowName, 
					   DWORD dwStyle,	UINT nID)
{
	ASSERT(pViewClass != NULL);
	ASSERT(pViewClass->IsDerivedFrom(RUNTIME_CLASS(CWnd)));
	if (pContext)
		memcpy(&m_Context, pContext, sizeof(m_Context));
	else 
	{
		CFrameWnd *fw = (CFrameWnd *)AfxGetMainWnd();
		if (fw)
		{
			m_Context.m_pCurrentFrame = fw;
		}
	}

	m_Context.m_pNewViewClass = pViewClass;

	return baseCMyBar::Create(lpszWindowName,	pParentWnd,	nID,dwStyle);
}

int CPropertiesBar::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (baseCMyBar::OnCreate(lpCreateStruct) == -1)
		return -1;

	if (!m_pFrameWnd->Create(NULL, NULL, WS_CHILD | WS_CLIPCHILDREN | WS_VISIBLE,
					CRect(0,0,0,0), this, NULL, 0, &m_Context))
	{
		return -1;
	}

/*	// Setting the ActiveView...
	CView* pView = NULL;
	if (m_pFrameWnd->GetActiveView() == NULL)
	{
		CWnd* pWnd = m_pFrameWnd->GetDescendantWindow(AFX_IDW_PANE_FIRST, TRUE);
		if (pWnd != NULL && pWnd->IsKindOf(RUNTIME_CLASS(CView)))
		{
			pView = (CView*)pWnd;
			m_pFrameWnd->SetActiveView(pView, FALSE);
		}
	}*/

	return 0;

}

void CPropertiesBar::OnSize(UINT nType, int cx, int cy) 
{
	CRect rc;

	baseCMyBar::OnSize(nType, cx, cy);
	GetClientRect(rc);
	m_pFrameWnd->MoveWindow(rc);
}

CHTMLContainerDoc* CPropertiesBar::GetDocument()
{
	CDocTemplate* pTemplate = ((CHTMLContainerApp*) AfxGetApp())->pDocTemplate;
	ASSERT_VALID(pTemplate);

	POSITION pos = pTemplate->GetFirstDocPosition();
	CHTMLContainerDoc* pDoc = (CHTMLContainerDoc*)pTemplate->GetNextDoc(pos);
	ASSERT_VALID(pDoc);
	
	return pDoc;
}

CPropertiesView* CPropertiesBar::GetView()
{
	// well, I _really_ know, that with this class I use
	// CPropertiesView class... 
	// CPropertiesView* pView = (CPropertiesView*)m_Context.m_pNewViewClass;


	if (m_pFrameWnd->GetActiveView() == NULL)
	{
		// Setting the ActiveView...

		CView* pView = NULL;
		if (m_pFrameWnd->GetActiveView() == NULL)
		{
			CWnd* pWnd = m_pFrameWnd->GetDescendantWindow(AFX_IDW_PANE_FIRST, TRUE);
			if (pWnd != NULL && pWnd->IsKindOf(RUNTIME_CLASS(CView)))
			{
				pView = (CView*)pWnd;
				m_pFrameWnd->SetActiveView(pView, FALSE);
			}	
		}
	}

	CPropertiesView* pPropView = NULL;
	pPropView = ((CPropertiesView*)m_pFrameWnd->GetActiveView());
	ASSERT_VALID(pPropView);

	return pPropView;

/*	CRuntimeClass* pView = (CRuntimeClass*)m_Context.m_pNewViewClass;

	if( pView->IsDerivedFrom(RUNTIME_CLASS(CPropertiesView)) ) 
	{
		return (CPropertiesView*)pView;
	}
	else
		return NULL;*/
}
