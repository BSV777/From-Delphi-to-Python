There is no bin files - ask to compile.
Can't compile in VS7