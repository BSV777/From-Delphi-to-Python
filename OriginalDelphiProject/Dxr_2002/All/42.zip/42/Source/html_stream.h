#ifndef html_streamH
#define html_streamH

#include <fstream.h>

class htmlStream : public ofstream {
    private:
    

    public:
        htmlStream(char fname[]) : ofstream(fname) {}

        void __fastcall putCell(bool, int, bool, int, int, int, AnsiString);
};

#endif
