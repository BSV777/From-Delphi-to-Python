#ifndef htmlTextEditH
#define htmlTextEditH

#include <SysUtils.hpp>
#include <Controls.hpp>
#include <Classes.hpp>
#include <Forms.hpp>
#include "htmlControl.h"

class PACKAGE htmlTextEdit : public htmlControl
{
    private:
        TEdit* edit;

    protected:

        AnsiString __fastcall getText(void);
        void __fastcall setText(AnsiString);

    public:
        __fastcall htmlTextEdit(TComponent* Owner);

        virtual AnsiString __fastcall toHhtml(void);
        
    __published:
        __property AnsiString text = { read=getText, write=setText };
};

#endif
