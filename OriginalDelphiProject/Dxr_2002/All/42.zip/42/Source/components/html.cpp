#include <vcl.h>
#pragma hdrstop
USERES("html.res");
USEPACKAGE("vcl50.bpi");
USEUNIT("htmlControl.cpp");
USEUNIT("htmlLabel.cpp");
USEUNIT("htmlTextEdit.cpp");
USEUNIT("htmlButton.cpp");

#pragma package(smart_init)

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
    return 1;
}

