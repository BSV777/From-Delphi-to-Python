#ifndef htmlLabelH
#define htmlLabelH

#include <SysUtils.hpp>
#include <Controls.hpp>
#include <Classes.hpp>
#include <Forms.hpp>
#include "htmlControl.h"

class PACKAGE htmlLabel : public htmlControl
{
    private:
        TLabel *label;

    protected:

        void __fastcall setText(AnsiString);
        AnsiString __fastcall getText(void);

    public:
        __fastcall htmlLabel(TComponent* Owner);

        virtual AnsiString __fastcall toHhtml(void);        

    __published:
        __property AnsiString text = { read=getText, write=setText };
};

#endif
