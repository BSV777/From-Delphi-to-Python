// ============================================================================
//
//  htmlControl.h, htmlControl.cpp
//  �����: ����� ������� (atv_jr@hotbox.ru)
//  ���� ���������: 28.03.02
//
//
// ============================================================================

#include <vcl.h>
#pragma hdrstop

#include "htmlControl.h"
#pragma package(smart_init)

#define PTS_SIZE 5
#define PTS_OFFSET 2
#define OUT_OF_BOUNDARY 10000

static inline void ValidCtrCheck(htmlControl *) {
    new htmlControl(NULL);
}

namespace Htmlcontrol
{

    void __fastcall PACKAGE Register()
    {
         TComponentClass classes[1] = {__classid(htmlControl)};
         RegisterComponents("Samples", classes, 0);
    }
}

void checkRect(TRect& r) {
    if (r.Top > r.Bottom) { int tmp = r.Top; r.Top = r.Bottom; r.Bottom = tmp; }
    if (r.Left > r.Right) { int tmp = r.Left; r.Left = r.Right; r.Right = tmp; }
}

__fastcall htmlControl::htmlControl(TComponent* Owner)
    : TCustomControl(Owner)
{
    if (dynamic_cast<TScrollingWinControl*>(Owner) != NULL)
        Parent = (TScrollingWinControl*)Owner;

    Canvas->Brush->Style = bsSolid;
    Canvas->Font->Charset = DEFAULT_CHARSET; Canvas->Font->Color = clBlack;
    Canvas->Font->Size = 8; Canvas->Font->Name = "MS Sans Serif";

    Fselected = false;
    pressed = false;
    resize = false;

    OnMouseDown = processMouseDown;
    OnMouseMove = processMouseMove;
    OnMouseUp = processMouseUp;

    control = NULL;

    allowWidthChange = true;
    allowHeightChange = true;

    properties = new vector<TProperty>;
    addProperty("Left", getLeft, setLeft, "10");
    addProperty("Right", getRight, setRight, "100");
    addProperty("Top", getTop, setTop, "10");
    addProperty("Bottom", getBottom, setBottom, "29");

    name = "Control";
}

void __fastcall htmlControl::SetParent(TWinControl* AParent) {
    int h = 0;
    if (control) h = control->Height;

    TCustomControl::SetParent(AParent);

    if (Parent != NULL && control) control->Height = h;

    HWND notUsed;

    if (Parent != NULL)
        Canvas->Handle = GetDeviceContext(notUsed);
}

void __fastcall htmlControl::Paint(void) {
    if (control) {
        updateSize();

        if (dynamic_cast<TWinControl*>(control) != NULL) {
            ((TWinControl*)control)->PaintTo(Canvas->Handle, PTS_OFFSET, PTS_OFFSET);
        }

        if (dynamic_cast<TLabel*>(control) != NULL) {
            Canvas->Brush->Color = Parent->Brush->Color;

            TRect r = Rect(PTS_OFFSET, PTS_OFFSET,
                           PTS_OFFSET + control->Width, PTS_OFFSET + control->Height);
            Canvas->TextRect(r, PTS_OFFSET, PTS_OFFSET, ((TLabel*)control)->Caption);
        }

        Parent->Repaint();
    }

    if (Selected) {

        Canvas->Brush->Color = clBlack;

        Canvas->FillRect(Rect(0, 0, PTS_SIZE, PTS_SIZE));
        Canvas->FillRect(Rect(0, Height-PTS_SIZE, PTS_SIZE, Height));
        Canvas->FillRect(Rect(Width-PTS_SIZE, 0, Width, PTS_SIZE));
        Canvas->FillRect(Rect(Width-PTS_SIZE, Height-PTS_SIZE, Width, Height));

        Canvas->FillRect(Rect((Width-PTS_SIZE)/2, 0, (Width+PTS_SIZE)/2, PTS_SIZE));
        Canvas->FillRect(Rect((Width-PTS_SIZE)/2, Height-PTS_SIZE, (Width+PTS_SIZE)/2, Height));
        Canvas->FillRect(Rect(0, (Height-PTS_SIZE)/2, PTS_SIZE, (Height+PTS_SIZE)/2));
        Canvas->FillRect(Rect(Width-PTS_SIZE, (Height-PTS_SIZE)/2, Width, (Height+PTS_SIZE)/2));

    }
}

void __fastcall htmlControl::setControl(TControl* cntrl) {
    if (control) RemoveControl(control);

    control = cntrl;
    control->Left = OUT_OF_BOUNDARY; control->Top = OUT_OF_BOUNDARY;

    InsertControl(control);

    Repaint();
}

void __fastcall htmlControl::updateSize(void) {
    if (control) {
        if (control->Width < 1) control->Width = 1;
        if (control->Height < 1) control->Height = 1;

        Width = 2*PTS_OFFSET + control->Width;
        Height = 2*PTS_OFFSET + control->Height;
    }
}

void __fastcall htmlControl::select(void) {
    Fselected = true;
    Repaint();
}

void __fastcall htmlControl::unSelect(void) {
    Fselected = false;
    Repaint();    
}

void __fastcall htmlControl::setSelected(bool sel) {
    if (sel && FOnSelect)
        FOnSelect(this, false, sel);

    Fselected = sel;
    Repaint();
}

void __fastcall htmlControl::processMouseDown(TObject*, TMouseButton btn, TShiftState state, int x, int y) {
    parent_show_hint = Parent->ShowHint;
    parent_hint = Parent->Hint;

    ox = x; oy = y;

    if (btn == mbLeft &&
        x >= PTS_OFFSET && x <= Width-PTS_OFFSET &&
        y >= PTS_OFFSET && y <= Height-PTS_OFFSET)
    {
        bool sel;
        if (FOnSelect) FOnSelect(this, state.Contains(ssShift) || state.Contains(ssCtrl), sel);

        pressed = sel;
        if (FOnCanMove) FOnCanMove(this, pressed);

        Fselected = sel;
        Repaint();
    }

    if (btn == mbLeft && Selected) {
        resize_type = rtNone;

        if (x >= 0 && x < PTS_SIZE && y >= 0 && y < PTS_SIZE)                       resize_type = rtNW;
        if (x >= 0 && x < PTS_SIZE && y > Height-PTS_SIZE && y <= Height)           resize_type = rtSW;
        if (x > Width-PTS_SIZE && x <= Width && y >= 0 && y < PTS_SIZE)             resize_type = rtNE;
        if (x > Width-PTS_SIZE && x <= Width && y > Height-PTS_SIZE && y <= Height) resize_type = rtSE;

        if (x >= (Width-PTS_SIZE)/2 && x <= (Width+PTS_SIZE)/2 && y >= 0 && y < PTS_SIZE)             resize_type = rtN;
        if (x >= (Width-PTS_SIZE)/2 && x <= (Width+PTS_SIZE)/2 && y > Height-PTS_SIZE && y <= Height) resize_type = rtS;
        if (x >= 0 && x < PTS_SIZE && y >= (Height-PTS_SIZE)/2 && y <= (Height+PTS_SIZE)/2)           resize_type = rtW;
        if (x > Width-PTS_SIZE && x <= Width && y >= (Height-PTS_SIZE)/2 && y <= (Height+PTS_SIZE)/2) resize_type = rtE;

        if (resize_type) {
            if (FOnCanResize != NULL)
                FOnCanResize(this, resize);

            if (resize)
                pressed = false;
        }
    }

    updateHint(x, y);
}

void __fastcall htmlControl::processMouseMove(TObject*, TShiftState, int x, int y) {
    Cursor = crDefault;

    if (Selected) {
        if (FOnCanResize != NULL) {
            bool can_resize;
            FOnCanResize(this, can_resize);

            if (can_resize) {
                if (x >= 0 && x < PTS_SIZE && y >= 0 && y < PTS_SIZE ||
                    x > Width-PTS_SIZE && x <= Width && y > Height-PTS_SIZE && y <= Height)
                    Cursor = crSizeNWSE;

                if (x >= 0 && x < PTS_SIZE && y > Height-PTS_SIZE && y <= Height ||
                    x > Width-PTS_SIZE && x <= Width && y >= 0 && y < PTS_SIZE)
                    Cursor = crSizeNESW;

                if (x >= (Width-PTS_SIZE)/2 && x <= (Width+PTS_SIZE)/2 &&
                    (y >= 0 && y < PTS_SIZE || y > Height-PTS_SIZE && y <= Height) &&
                    allowHeightChange)
                    Cursor = crSizeNS;

                if (y >= (Height-PTS_SIZE)/2 && y <= (Height+PTS_SIZE)/2 &&
                    (x >= 0 && x < PTS_SIZE || x > Width-PTS_SIZE && x <= Width) &&
                    allowWidthChange)
                    Cursor = crSizeWE;
            }
        }
    }

    Application->ProcessMessages();    

    if (pressed) {
        if (FOnMoving)
            FOnMoving(this, x-ox+PTS_OFFSET, y-oy+PTS_OFFSET);
    }

    if (resize) {
        int dx = x-ox, dy = y-oy;

        resize_rect = getRect();

        if (allowHeightChange) {
            if (resize_type & rtN) resize_rect.Top += dy;
            if (resize_type & rtS) resize_rect.Bottom += dy;
        }
        if (allowWidthChange) {
            if (resize_type & rtW) resize_rect.Left += dx;
            if (resize_type & rtE) resize_rect.Right += dx;
        }

        checkRect(resize_rect);

        if (FOnResizing != NULL) FOnResizing(this, resize_rect);
    }

    updateHint(x, y);    
}

void __fastcall htmlControl::processMouseUp(TObject*, TMouseButton, TShiftState, int x, int y) {
    if (pressed) {

        if (FOnEndMove) {
            int dx = x-ox+PTS_OFFSET, dy = y-oy+PTS_OFFSET;
            FOnEndMove(this, dx, dy);
        }

        pressed = false;
    }

    if (resize) {

        Cursor = crDefault; Application->ProcessMessages();

        if (FOnEndResize != NULL) 
            FOnEndResize(this, resize_rect);

        resize = false;
    }

    Parent->ShowHint = parent_show_hint;
    Parent->Hint = parent_hint;
}

void __fastcall htmlControl::moveTo(int dx, int dy) {
    Top = Top + dy - PTS_OFFSET;
    Left = Left + dx - PTS_OFFSET;
}

TRect& __fastcall htmlControl::getRect(void) {
    return *(new TRect(Rect(Left+PTS_OFFSET, Top+PTS_OFFSET,
                            Left+Width-PTS_OFFSET, Top+Height-PTS_OFFSET)) );
}

void __fastcall htmlControl::resizeTo(TRect r) {
    Top = r.Top - PTS_OFFSET;
    Left = r.Left - PTS_OFFSET;

    if (control) {
        control->Height = r.Height();
        control->Width = r.Width();

        Repaint();
    }
}

void __fastcall htmlControl::updateHint(int x, int y) {
    int xx, yy;
    getScrollPos(xx, yy);

    Parent->ShowHint = true;

    if (pressed) Parent->Hint = AnsiString(xx + Left + PTS_OFFSET + x - ox) + ", " +
                                AnsiString(yy + Top + PTS_OFFSET + y - oy);

    if (resize) Parent->Hint = AnsiString(resize_rect.Width()) + " x " +
                               AnsiString(resize_rect.Height());

    Application->ActivateHint(ClientToScreen(TPoint(x, y)));
}

AnsiString __fastcall htmlControl::getLeft(void) {
    return AnsiString(left);
}

AnsiString __fastcall htmlControl::getRight(void) {
    return AnsiString(right);
}

AnsiString __fastcall htmlControl::getTop(void) {
    return AnsiString(top);
}

AnsiString __fastcall htmlControl::getBottom(void) {
    return AnsiString(bottom);
}

void __fastcall htmlControl::setLeft(AnsiString s) {
    try {
        int v = s.ToInt();
        left = v;
    }
    catch(...) {
        throw "Wrong value";
    }
}

void __fastcall htmlControl::setRight(AnsiString s) {
    try {
        int v = s.ToInt();
        right = v;
    }
    catch(...) {
        throw "Wrong value";
    }

    Repaint();
}

void __fastcall htmlControl::setTop(AnsiString s) {
    try {
        int v = s.ToInt();
        top = v;
    }
    catch(...) {
        throw "Wrong value";
    }
}

void __fastcall htmlControl::setBottom(AnsiString s) {
    try {
        int v = s.ToInt();
        bottom = v;
    }
    catch(...) {
        throw "Wrong value";
    }
}

void __fastcall htmlControl::addProperty(AnsiString name, TGetFunc get, TSetFunc set, AnsiString def) {
    properties->push_back(TProperty(name, get, set, def));
}

void __fastcall htmlControl::getProperties(vector<TProperty>& vec) {
    vec = *properties;
}

void __fastcall htmlControl::getScrollPos(int& x, int& y) {
    if (Parent) {
        x = ((TScrollingWinControl*)Parent)->HorzScrollBar->ScrollPos;
        y = ((TScrollingWinControl*)Parent)->VertScrollBar->ScrollPos;
    }
    else
        x = y = 0;
}

int __fastcall htmlControl::getIntLeft(void) {
    int xx, yy;
    getScrollPos(xx, yy);

    return xx + Left + PTS_OFFSET;
}

int __fastcall htmlControl::getIntRight(void) {
    int xx, yy;
    getScrollPos(xx, yy);

    return xx + Left + Width - PTS_OFFSET;
}

int __fastcall htmlControl::getIntTop(void) {
    int xx, yy;
    getScrollPos(xx, yy);

    return yy + Top + PTS_OFFSET;
}

int __fastcall htmlControl::getIntBottom(void) {
    int xx, yy;
    getScrollPos(xx, yy);

    return yy + Top + Height - PTS_OFFSET;
}

void __fastcall htmlControl::setIntLeft(int v) {
    int xx, yy;
    getScrollPos(xx, yy);

    Left = v - PTS_OFFSET - xx;
}

void __fastcall htmlControl::setIntRight(int v) {
    int xx, yy;
    getScrollPos(xx, yy);

    if (control && allowWidthChange)
        control->Width = v - Left - PTS_OFFSET - xx;

    updateSize();
    Repaint();
}

void __fastcall htmlControl::setIntTop(int v) {
    int xx, yy;
    getScrollPos(xx, yy);

    Top = v - PTS_OFFSET - yy;
}

void __fastcall htmlControl::setIntBottom(int v) {
    int xx, yy;
    getScrollPos(xx, yy);

    if (control && allowHeightChange)
        control->Height = v - Top - PTS_OFFSET - yy;

    updateSize();        
    Repaint();
}

ostream& operator<<(ostream& str, htmlControl& p) {
    AnsiString text = AnsiString("<") + p.name;

    for(unsigned int i = 0; i < p.properties->size(); i++) {
        text += " ";
        text += (*p.properties)[i].name.LowerCase();
        text += "=\"";
        text += (*p.properties)[i].get();
        text += "\"";

        if (i+1 != p.properties->size()) text += ";";
    }

    text += ">";

    str << text.c_str();
    return str;
}

AnsiString __fastcall htmlControl::toHhtml(void) {
    return "c";
}
