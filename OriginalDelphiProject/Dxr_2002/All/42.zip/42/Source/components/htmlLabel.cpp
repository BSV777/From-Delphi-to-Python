#include <vcl.h>
#pragma hdrstop

#include "htmlLabel.h"
#pragma link "htmlControl"
#pragma package(smart_init)

static inline void ValidCtrCheck(htmlLabel *)
{
    new htmlLabel(NULL);
}

namespace Htmllabel
{
    void __fastcall PACKAGE Register()
    {
         TComponentClass classes[1] = {__classid(htmlLabel)};
         RegisterComponents("Samples", classes, 0);
    }
}

__fastcall htmlLabel::htmlLabel(TComponent* Owner)
    : htmlControl(Owner)
{
    name = "Label";

    label = new TLabel(this); label->Font->Size = 8;
    label->Caption = "�����"; label->AutoSize = false; label->WordWrap = false;

    setControl(label);

    addProperty("Text", getText, setText, "");
}

AnsiString __fastcall htmlLabel::getText(void) {
    return label->Caption;
}

void __fastcall htmlLabel::setText(AnsiString s) {
    label->Caption = s.SubString(1, 255);
    Repaint();
}

AnsiString __fastcall htmlLabel::toHhtml(void) {
    int len = (right-left) / 5.2;
    AnsiString res = label->Caption.SubString(1, len);
    return res;
}
