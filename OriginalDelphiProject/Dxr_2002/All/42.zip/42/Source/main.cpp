// ============================================================================
//
//  main.h, main.cpp
//  �����: ����� ������� (atv_jr@hotbox.ru)
//  ���� ���������: 28.03.02
//
//  ���� ���������� ��������� 
//
// ============================================================================

#include <vcl.h>
#pragma hdrstop

#include "main.h"
#include "export.cpp"
#include <typeinfo>
#include <vcl\Clipbrd.hpp>
#include <stdlib.h>
#include <fstream.h>
#include "htmlControl.cpp"
#include "about.h"

#pragma package(smart_init)
#pragma resource "*.dfm"
TMainForm *MainForm;

__fastcall TMainForm::TMainForm(TComponent* Owner)
    : TForm(Owner)
{
    move = false;
    shapes = NULL;
    resize_shape = NULL;

    registerClasses();

    Inspector = new TInspector(this);
    Inspector->ManualDock(LeftDockPanel, Inspector, alClient);
    Inspector->Show();

    newEditor();

    updateInspector();
    updateEditMenu();
}

// ============================================================================
//
// ============================================================================

void __fastcall TMainForm::updateShape(int x, int y) {
    if (x <= shape_ox) {
        shape->Width = shape_ox - x;
        shape->Left = x;
    }
    else shape->Width = x - shape->Left + 1;

    if (y <= shape_oy) {
        shape->Height = shape_oy - y;
        shape->Top = y;
    }
    else shape->Height = y - shape->Top + 1;

    if (insert) {
        shape->Hint = AnsiString(shape->Width) + " x " + AnsiString(shape->Height);

        Application->ActivateHint(EditorBox->ClientToScreen(TPoint(x, y)));
    }
    else
        shape->Hint = "";
}

void __fastcall TMainForm::OnMouseDown(TObject *Sender, TMouseButton Button,
      TShiftState Shift, int x, int y)
{
    shape_ox = x; shape_oy = y;
    updateShape(x, y);
    shape->Visible = true;

    insert = (CompMouseBtn->Down == false);
}

void __fastcall TMainForm::OnMouseMove(TObject *Sender, TShiftState Shift,
      int x, int y)
{
    if (shape->Visible) updateShape(x, y);
}

void __fastcall TMainForm::OnMouseUp(TObject *Sender, TMouseButton Button,
      TShiftState Shift, int X, int Y)
{
    shape->Visible = false;

    if (insert)
        insertHtmlComponent();
    else
    {
        if (!Shift.Contains(ssShift) && !Shift.Contains(ssCtrl))
            clearSelection();

        for (int i = 0; i < ComponentCount; i++) {
            TComponent* tmp = Components[i];

            if (dynamic_cast<htmlControl *>(tmp) != NULL)
            {
                htmlControl* cntrl = (htmlControl*)tmp;

                if (inShape(cntrl))
                {
                    if (!cntrl->Selected)
                        addToSelection(cntrl);
                    else
                        if (Shift.Contains(ssCtrl)) {
                            removeFromSelection(cntrl);
                        }
                }
            }
        }
    }
}

bool __fastcall TMainForm::inShape(TWinControl* cntrl) {
    Windows::TPoint cntrl_lu = cntrl->ClientToScreen(TPoint(0, 0));
    Windows::TPoint cntrl_rd = cntrl->ClientToScreen(TPoint(cntrl->Width, cntrl->Height));

    Windows::TPoint shape_lu = shape->ClientToScreen(TPoint(0, 0));
    Windows::TPoint shape_rd = shape->ClientToScreen(TPoint(shape->Width, shape->Height));

    if (
        cntrl_lu.x >= shape_lu.x && cntrl_lu.x <= shape_rd.x &&
        cntrl_lu.y >= shape_lu.y && cntrl_lu.y <= shape_rd.y ||
        cntrl_rd.x >= shape_lu.x && cntrl_rd.x <= shape_rd.x &&
        cntrl_rd.y >= shape_lu.y && cntrl_rd.y <= shape_rd.y
       )
        return true;
    else
        return false;
}

// ============================================================================
//
// ============================================================================

void __fastcall TMainForm::updateInspector(void) {
    unsigned int size = selection.size();
    if (size != 1)
        Inspector->clear();
    else
        Inspector->showProperties(selection[0]);
}

// ============================================================================
//
// ============================================================================

void __fastcall TMainForm::addToSelection(htmlControl* cntrl) {
    cntrl->select();
    selection.push_back(cntrl);
    updateInspector();
    updateEditMenu();    

    Repaint();
}

void __fastcall TMainForm::removeFromSelection(htmlControl* cntrl) {
    vector<htmlControl*>::iterator iter = selection.begin();

    for(; iter != NULL && *iter != cntrl; iter++);

    (*iter)->unSelect();
    selection.erase(iter);

    updateInspector();
    updateEditMenu();    
    Repaint();
}

void __fastcall TMainForm::clearSelection(void) {
    for(unsigned int i = 0; i < selection.size(); i++)
        selection[i]->unSelect();

    selection.clear();

    updateInspector();
    updateEditMenu();
    Repaint();
}

void __fastcall TMainForm::htmlControlSelect(TObject *Sender, bool shift, bool &sel) {
    if (!((htmlControl*)Sender)->Selected)
    {
        if (!shift)
            clearSelection();

        addToSelection((htmlControl*)Sender);
        sel = true;

        if (selection.size() > 1)
            move = false;
        else
            move = true;
    }
    else
    {
        if (shift && selection.size() > 1) {
            removeFromSelection((htmlControl*)Sender);

            sel = false;
            move = false;
        }
        else {
            sel = true;
            move = true;
        }
    }
}

// ============================================================================
//
// ============================================================================

void __fastcall TMainForm::htmlControlCanMove(TObject *Sender, bool &can) {
    can = move;
}

void __fastcall TMainForm::htmlControlMoving(TObject *Sender, int dx, int dy) {
    if (move) {
        if (shapes == NULL) {
            shapes = new vector<TShape*>(selection.size());

            for(unsigned int i = 0; i < shapes->size(); i++) {
                TRect r = selection[i]->getRect();

                (*shapes)[i] = new TShape(this);

                TShape *s = (*shapes)[i];
                s->Width = r.Width(); s->Height = r.Height();
                s->Brush->Style = bsClear;
                s->Pen->Style = psSolid; s->Pen->Color = clGray; s->Pen->Width = 2;
                s->Visible = true;

                s->Parent = ((htmlControl*)Sender)->Parent;
            }
        }

        for (unsigned int i = 0; i < shapes->size(); i++) {
            (*shapes)[i]->Left = selection[i]->Left + dx;
            (*shapes)[i]->Top = selection[i]->Top + dy;
        }
    }
}

void __fastcall TMainForm::htmlControlEndMove(TObject *Sender, int dx, int dy) {
    if (move) {
        for (unsigned int i = 0; i < selection.size(); i++) {
            selection[i]->moveTo(dx, dy);

            if (shapes)
                (*shapes)[i]->Visible = false;
        }

        if (shapes) {
            delete shapes;
            shapes = NULL;
        }

        checkOverlap();
    }

    if (dx != 0 || dy != 0)
        changed = true;

    updateInspector();
}

// ============================================================================
//
// ============================================================================

void __fastcall TMainForm::htmlControlCanResize(TObject *Sender, bool &can) {
    can = (selection.size() == 1);
}

void __fastcall TMainForm::htmlControlResizing(TObject *Sender, TRect r) {
    if (resize_shape == NULL) {
        resize_shape = new TShape(this);

        resize_shape->Brush->Style = bsClear;
        resize_shape->Pen->Style = psSolid; resize_shape->Pen->Color = clGray; resize_shape->Pen->Width = 2;
        resize_shape->Visible = true;

        resize_shape->Parent = ((htmlControl*)Sender)->Parent;
    }

    resize_shape->Top = r.Top; resize_shape->Left = r.Left;
    resize_shape->Width = r.Width(); resize_shape->Height = r.Height();
}

void __fastcall TMainForm::htmlControlEndResize(TObject *Sender, TRect r) {
    ((htmlControl*)Sender)->resizeTo(r);

    if (resize_shape) {
        resize_shape->Visible = false;
        resize_shape = NULL;
    }

    checkOverlap();

    changed = true;
    updateInspector();
}

// ============================================================================
//
// ============================================================================

void __fastcall TMainForm::LeftDockPanelDockOver(TObject *Sender,
      TDragDockObject *Source, int X, int Y, TDragState State,
      bool &Accept)
{
    Accept = true;
    Source->DockRect = TRect(ClientToScreen(TPoint(0, LeftDockPanel->Top)),
                             ClientToScreen(TPoint(INSPECTOR_DEAFULT_WIDTH, ClientHeight)));
}

void __fastcall TMainForm::LeftDockPanelDockDrop(TObject *Sender,
      TDragDockObject *Source, int X, int Y)
{
    showDockPanel();
}

void __fastcall TMainForm::LeftDockPanelUnDock(TObject *Sender,
      TControl *Client, TWinControl *NewTarget, bool &Allow)
{
    hideDockPanel();
}

void __fastcall TMainForm::hideDockPanel(void) {
    LeftDockPanel->Width = 0;
    LeftSplitter->Visible = false;
}

void __fastcall TMainForm::showDockPanel(void) {
    LeftDockPanel->Width = INSPECTOR_DEAFULT_WIDTH;
    LeftSplitter->Left = INSPECTOR_DEAFULT_WIDTH; LeftSplitter->Visible = true;
}

// ============================================================================
//
// ============================================================================

void __fastcall TMainForm::updateCaption(void) {
    AnsiString name = filename;
    if (name == "") name = "����� �����";
    Caption = "�������� HTML-���� - " + name;
}

bool __fastcall TMainForm::newEditor(void) {
    bool result = true;

    if (changed) {
        int res = MessageBox(Handle, "����� ���� ��������.\n��������� ���������?",
                             "��������������", MB_YESNOCANCEL | MB_ICONQUESTION);
        switch (res) {
            case IDYES :
                Save();

            case IDNO :
                result = true;
                break;

            case IDCANCEL :
                result = false;
                break;
        }
    }
    else result = true;

    if (result) changed = false;

    return result;
}

void __fastcall TMainForm::FileNewItemClick(TObject *Sender) {
    if (newEditor()) {
        EditSelAllItemClick(this);
        EditDelItemClick(this);

        filename = "";
        updateCaption();

        changed = false;
    }
}

void __fastcall TMainForm::FileOpenItemClick(TObject *Sender) {
    if (newEditor() && OpenDlg->Execute()) {
        EditSelAllItemClick(this);
        EditDelItemClick(this);                

        filename = OpenDlg->FileName;
        updateCaption();

        clearSelection();

        vector<htmlControl*> data;
        readData(filename.c_str(), data);

        for (unsigned int i = 0; i < data.size(); i++) {
            htmlControl *control = data[i];

            control->Parent = EditorBox;

            control->onCanMove = htmlControlCanMove;
            control->onCanResize = htmlControlCanResize;
            control->onEndMove = htmlControlEndMove;
            control->onEndResize = htmlControlEndResize;
            control->onMoving = htmlControlMoving;
            control->onResizing = htmlControlResizing;
            control->onSelect = htmlControlSelect;

            clearSelection();
            control->Selected = true;

            checkOverlap();
        }

        clearSelection();

        changed = false;
    }
}

void __fastcall TMainForm::FileSaveItemClick(TObject *Sender) {
    Save();
}

void __fastcall TMainForm::FileSaveAsItemClick(TObject *Sender) {
    SaveAs();
}

void __fastcall TMainForm::FileExitItemClick(TObject *Sender) {
    Close();
}

void __fastcall TMainForm::FormCloseQuery(TObject *Sender, bool &CanClose) {
    CanClose = newEditor();
}

void __fastcall TMainForm::Save(void) {
    if (filename == "")
        SaveAs();
    else
    {
        changed = false;

        vector<htmlControl*> data;
        createData(data);
        writeData(filename.c_str(), data);
    }
}

void __fastcall TMainForm::SaveAs(void) {
    if (SaveDlg->Execute()) {
        filename = SaveDlg->FileName;
        updateCaption();
        
        Save();
    }
}

// ============================================================================
//
// ============================================================================

void __fastcall TMainForm::ViewInspectorItemClick(TObject *Sender) {
    if (!Inspector->Floating)
        showDockPanel();        

    Inspector->Show();
}

void __fastcall TMainForm::EditSelAllItemClick(TObject *Sender) {
    clearSelection();

    for (int i = 0; i < ComponentCount; i++) {
        TComponent* tmp = Components[i];

        if (dynamic_cast<htmlControl *>(tmp) != NULL)
            addToSelection((htmlControl*)tmp);

    }
}

void __fastcall TMainForm::EditDelItemClick(TObject *Sender) {
    for (unsigned int i = 0; i < selection.size(); i++) {
        selection[i]->Parent = NULL;
        delete selection[i];

        changed = true;
    }

    selection.clear();

    updateInspector();
    updateEditMenu();
    Repaint();
}

void __fastcall TMainForm::CompBtnClick(TObject *Sender) {
    clearSelection();
}

void __fastcall TMainForm::insertHtmlComponent(void) {
    htmlControl* control;
    if (CompLabelBtn->Down)
        control = new htmlLabel(this);
    else {
        if (CompTextEditBtn->Down)
            control = new htmlTextEdit(this);
        else
            control = new htmlButton(this);
    }

    control->left = shape->Left; control->top = shape->Top;
    control->Width = 1; control->Height = 1;

    if (shape->Width > 0 && shape->Height > 0) {
        control->right = shape->Left + shape->Width;
        control->bottom = shape->Top + shape->Height;
    }

    control->Parent = EditorBox;

    control->onCanMove = htmlControlCanMove;
    control->onCanResize = htmlControlCanResize;
    control->onEndMove = htmlControlEndMove;
    control->onEndResize = htmlControlEndResize;
    control->onMoving = htmlControlMoving;
    control->onResizing = htmlControlResizing;
    control->onSelect = htmlControlSelect;

    clearSelection();
    control->Selected = true;

    CompMouseBtn->Down = true;

    checkOverlap();

    changed = true;
}

void __fastcall TMainForm::HelpAboutItemClick(TObject *Sender) {
    TAboutForm *about = new TAboutForm(this);
    about->ShowModal();
}

// ============================================================================
//
// ============================================================================

void __fastcall TMainForm::registerClasses(void) {
    RegisterClasses(&__classid(htmlLabel), 0);
    RegisterClasses(&__classid(htmlButton), 0);
    RegisterClasses(&__classid(htmlTextEdit), 0);
    RegisterClasses(&__classid(TLabel), 0);
    RegisterClasses(&__classid(TButton), 0);
    RegisterClasses(&__classid(TEdit), 0);
}


void __fastcall TMainForm::EditCutItemClick(TObject *Sender) {
    for(unsigned int i = 0; i < selection.size(); i++) {
        htmlControl* control = selection[i];
        control->unSelect();
        Clipboard()->SetComponent(control);
    }

    EditDelItemClick(Sender);
}

void __fastcall TMainForm::EditCopyItemClick(TObject *Sender) {
    for(unsigned int i = 0; i < selection.size(); i++) {
        htmlControl* control = selection[i];
        control->unSelect();
        Clipboard()->SetComponent(control);
    }
}

void __fastcall TMainForm::EditPasteItemClick(TObject *Sender) {
    htmlControl *control;
    try {
        control = (htmlControl*)Clipboard()->GetComponent(this, EditorBox);

        if (control) {
            int top = control->top, left = control->left;

            control->Parent = EditorBox;

            control->top = top; control->left = left;

            control->onCanMove = htmlControlCanMove;
            control->onCanResize = htmlControlCanResize;
            control->onEndMove = htmlControlEndMove;
            control->onEndResize = htmlControlEndResize;
            control->onMoving = htmlControlMoving;
            control->onResizing = htmlControlResizing;
            control->onSelect = htmlControlSelect;

            clearSelection();
            control->Selected = true;

            changed = true;
        }

        checkOverlap();        
    }
    catch (...) {
    }
}

void __fastcall TMainForm::updateEditMenu(void) {
    bool vis = (selection.size() > 0);

    EditCutItem->Enabled = vis;
    EditCopyItem->Enabled = vis;
    EditDelItem->Enabled = vis;
}

void __fastcall TMainForm::checkOverlap(void) {
    for(unsigned int i = 0; i < selection.size(); i++) {
        for (int j = 0; j < ComponentCount; j++) {
            TComponent* tmp = Components[j];

            if (dynamic_cast<htmlControl *>(tmp) != NULL &&
                tmp != selection[i])
            {
                htmlControl* contr = (htmlControl*)tmp;

                int h = selection[i]->bottom - selection[i]->top,
                    top = selection[i]->top,
                    bot = top + h,
                    left = selection[i]->left,
                    right = selection[i]->right;

                int to_bot = bot - (contr->bottom);

                if ((top >= contr->top && top <= contr->bottom ||
                     bot >= contr->top && bot <= contr->bottom ||
                     top >= contr->top && bot <= contr->bottom ||
                     top <= contr->top && bot >= contr->bottom) &&
                    (left >= contr->left && left <= contr->right ||
                     right >= contr->left && right <= contr->right ||
                     left >= contr->left && right <= contr->right ||
                     left <= contr->left && right >= contr->right ))
                {
                    int disp = (h-to_bot) + 1;
                    selection[i]->top = selection[i]->top + disp;
                    j = -1;
                    contr->Repaint();
                }
            }
        }
    }
    Repaint();
}

// ============================================================================
//
// ============================================================================

void __fastcall TMainForm::createData(vector<htmlControl*>& data) {
    data.clear();

    for(int i = 0; i < ComponentCount; i++) {
        TComponent* tmp = Components[i];

        if (dynamic_cast<htmlControl *>(tmp) != NULL)
        {
            htmlControl* contr = (htmlControl*)tmp;
            int top = contr->top;

            vector<htmlControl*>::iterator iter = data.begin();
            for(; iter < data.end() && (*iter)->top < top; iter++);

            if (iter)
                data.insert(iter, contr);
            else
                data.push_back(contr);
        }
    }
}

// ============================================================================
//
// ============================================================================

void __fastcall TMainForm::ConvertBtnClick(TObject *Sender) {
    ConvertHTMLItemClick(Sender);
}

void __fastcall TMainForm::ConvertHTMLItemClick(TObject *Sender) {
    AnsiString fname = "";
    if (filename != "") {
        fname = filename.SubString(1, filename.Pos(".")) + "htm";
    }

    SaveHtmlDlg->FileName = fname;

    if (SaveHtmlDlg->Execute()) {

        vector<htmlControl*> data;
        createData(data);

        exportData(SaveHtmlDlg->FileName.c_str(), data);

    }
}

// ============================================================================
//
// ============================================================================

istream& operator>>(istream& is, htmlControl **contr) {
    *contr = NULL;

    AnsiString str = "";
    char ch = ' ';
    while (!is.eof() && ch != '>') {
        is.get(ch); str += ch;
    }

    if (ch == '>') {
        str.Delete(1, 1); str.Delete(str.Length(), 1); str += ";";

        int space = str.Pos(" ");
        AnsiString name = str.SubString(1, space-1).LowerCase();
        str.Delete(1, space);

        if (name == "textedit") *contr = new htmlTextEdit(MainForm);
        if (name == "button")   *contr = new htmlButton(MainForm);
        if (name == "label")    *contr = new htmlLabel(MainForm);

        if (contr) {
            for (unsigned int i = 0; i < (*contr)->properties->size(); i++)
                (*(*contr)->properties)[i].set((*(*contr)->properties)[i].def);

            while (str != "") {
                str.Trim();
                int delim_1 = str.Pos("="), delim_2 = str.Pos(";");

                if (delim_1 != 0 && delim_2 != 0 && delim_1 < delim_2) {
                    AnsiString param_name = str.SubString(1, delim_1-1).Trim().LowerCase(),
                               param_value = str.SubString(delim_1+1, delim_2-delim_1-1).Trim();

                    int len = param_value.Length();
                    if (param_value[1] == '\"' && param_value[len] == '\"') {
                        param_value.Delete(len, 1); param_value.Delete(1, 1);

                        unsigned int i = 0;
                        for (; i < (*contr)->properties->size() &&
                                   (*(*contr)->properties)[i].name.LowerCase() != param_name;
                             i++);

                        if (i < (*contr)->properties->size())
                            (*(*contr)->properties)[i].set(param_value);
                    }

                    str.Delete(1, delim_2);
                }
                else break;

            }
        }
    }

    return is;
}


