/////////////////////////////////////////////////////////////////////////////
// Editor.cpp : Defines the class behaviors for the application.
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Editor.h"

#include "MainFrm.h"
#include "ChildFrm.h"
#include "EditorDoc.h"
#include "EditorView.h"
#include "ErrorsView.h"

#include "ABCObject.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


void ExportHTML( CString sourceFile, CString targetFile );
 
/////////////////////////////////////////////////////////////////////////////
// CEditorApp
/////////////////////////////////////////////////////////////////////////////

CEditorApp theApp;

BEGIN_MESSAGE_MAP(CEditorApp, CWinApp)
	//{{AFX_MSG_MAP(CEditorApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditorApp construction
/////////////////////////////////////////////////////////////////////////////

CEditorApp::CEditorApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

int CEditorApp::ExitInstance() 
{
	CABCObject::ABCExit();
	
	return CWinApp::ExitInstance();
}

CString CEditorApp::GetArgument( int nIndex )
{
	CString argStr;
	argStr.Empty();

	int spacecount = 0;

	for( unsigned int i = 0; i < strlen( m_lpCmdLine ); i++ )
	{
		char symbol = m_lpCmdLine[i];
		if ( nIndex == spacecount )
		{
			argStr.Insert( argStr.GetLength(), symbol );
		}

		if ( symbol == ' ' )
			spacecount++;
	}

	return argStr;
}

BOOL CEditorApp::InitInstance()
{
	CString abcFile = GetArgument( 0 );
	CString HTMLFile = GetArgument( 1 );;

	if ( abcFile.GetLength() && HTMLFile.GetLength() )
	{
		ExportHTML( abcFile, HTMLFile );
		return FALSE;
	}

	CABCObject::ABCInit();

#ifdef _AFXDLL
	Enable3dControls();
#else
	Enable3dControlsStatic();
#endif

	// Change the registry key under which our settings are stored.
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CMainFrame::m_pABCDocTemplate = new CMultiDocTemplate(
		IDR_EDITORTYPE,
		RUNTIME_CLASS(CEditorDoc),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CEditorView));
	AddDocTemplate(CMainFrame::m_pABCDocTemplate);

	CMainFrame::m_pErrorsDocTemplate = new CMultiDocTemplate(
		IDR_ERRORS,
		RUNTIME_CLASS(CErrorsDoc),
		RUNTIME_CLASS(CErrorsFrame), // custom MDI child frame
		RUNTIME_CLASS(CErrorsView));
	AddDocTemplate(CMainFrame::m_pErrorsDocTemplate);


	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;

	// Enable drag/drop open
	m_pMainWnd->DragAcceptFiles();

	// Enable DDE Execute open
//	EnableShellOpen();
//	RegisterShellFileTypes(TRUE);

	// Dispatch commands specified on the command line
//	if (!ProcessShellCommand(cmdInfo))
//		return FALSE;

	// The main window has been initialized, so show and update it.
	pMainFrame->ShowWindow(m_nCmdShow);
	pMainFrame->UpdateWindow();

	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CEditorApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CEditorApp message handlers

