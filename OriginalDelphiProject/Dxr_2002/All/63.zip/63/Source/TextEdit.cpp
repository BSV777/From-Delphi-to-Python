/////////////////////////////////////////////////////////////////////////////
// TextEdit.cpp : implementation file
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"


#include "TextEdit.h"

/////////////////////////////////////////////////////////////////////////////
// CABCTextEdit
/////////////////////////////////////////////////////////////////////////////

void CABCTextEdit::Draw(CDC* pDC)
{
	LOGFONT lf;
	memset(&lf, 0, sizeof(LOGFONT));
	lf.lfHeight = 8;
	strcpy(lf.lfFaceName, "MS Sans Serif");
	CFont textFont;
	textFont.CreatePointFontIndirect( &lf, pDC );
	CFont* oldFont = pDC->GetCurrentFont();
	pDC->SelectObject( &textFont );

	CRect rect = GetRect();

	CPen* pOldPen = pDC->GetCurrentPen();
	pDC->SetMapMode(  MM_TEXT );

	CPen penBlack( PS_SOLID, 1, RGB(0, 0, 0) );
	CPen penGray( PS_SOLID, 1, GetSysColor( COLOR_3DLIGHT) );

	pDC->SelectObject(&penBlack); 
	pDC->MoveTo( rect.left, rect.bottom );
	pDC->LineTo( rect.left, rect.top );
	pDC->LineTo( rect.right, rect.top );
	pDC->LineTo( rect.right, rect.top + 1 );
	pDC->LineTo( rect.left + 1, rect.top  + 1 );
	pDC->LineTo( rect.left + 1, rect.bottom );
	pDC->LineTo( rect.left + 2, rect.bottom );
	pDC->SelectObject(&penGray); 
	pDC->LineTo( rect.right, rect.bottom );
	pDC->LineTo( rect.right, rect.top + 1 );

	CRect textRect = GetRect();
	textRect.InflateRect( -2, -2 );
	pDC->SetBkColor( GetSysColor( COLOR_WINDOW ) );
	pDC->DrawText( m_Text, &textRect, DT_SINGLELINE  | DT_VCENTER );

	pDC->SelectObject( pOldPen );
	pDC->SelectObject( oldFont );
}

CString CABCTextEdit::GetObjectHTMLString()
{
	CString htmlStr;

	CString textStr = m_Text;
	textStr.Replace( "\"", "&quot;" );

	CRect textRect = GetRect();
//	textRect.InflateRect( -2, -2 );

	htmlStr.Format( "<INPUT type=text value=\"%s\" style=\"WIDTH:%upx; HEIGHT:%upx;\">", textStr, textRect.Width(), textRect.Height()  );

	return htmlStr;
}

CString CABCTextEdit::GetObjectString()
{
	CString propStr;

	CString textStr = m_Text;
	// ������ ������� �������� ���������
	textStr.Replace( "\"", "\"\"" );

	propStr.Format("<%s %s=\"%d\"; %s=\"%d\"; %s=\"%d\"; %s=\"%d\"; %s=\"%s\">",
				    GetObjectName(),
					ABCProperty_Left, m_Rect.left,
					ABCProperty_Top, m_Rect.top,
					ABCProperty_Width, m_Rect.Width(),
					ABCProperty_Height, m_Rect.Height(),
					ABCProperty_Text, textStr );

	return propStr;
}

int CABCTextEdit::SetProperty( CString propName, CString propValue)
{
	propName.MakeLower();

	if ( propName == ABCProperty_Text )
	{
		m_Text = propValue;
		return ABCOSetProperty_Ok;
	}

	if ( propName == ABCProperty_Height )
	{
		return ABCOSetProperty_Ok;
	}
	return CABCObject::SetProperty( propName, propValue);
}


