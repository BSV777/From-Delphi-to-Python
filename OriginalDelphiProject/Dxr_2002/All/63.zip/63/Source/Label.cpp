/////////////////////////////////////////////////////////////////////////////
// Label.cpp : implementation file
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Label.h"

/////////////////////////////////////////////////////////////////////////////
// CABCLabel
/////////////////////////////////////////////////////////////////////////////

void CABCLabel::Draw(CDC* pDC)
{
	LOGFONT lf;
	memset(&lf, 0, sizeof(LOGFONT));
	lf.lfHeight = 8;
	strcpy(lf.lfFaceName, "MS Sans Serif");
	CFont textFont;
	textFont.CreatePointFontIndirect( &lf, pDC );
	CFont* oldFont = pDC->GetCurrentFont();
	pDC->SelectObject( &textFont );

	CPen penBlack( PS_DOT, 1, RGB(0, 0, 0) );

	CPen* pOldPen = pDC->GetCurrentPen();

	pDC->SelectObject(&penBlack);

	CRect rect = GetRect();

	pDC->Rectangle( rect );

	CRect textRect = GetRect();
	textRect.InflateRect( -2, -2 );
	pDC->SetBkColor( GetSysColor( COLOR_WINDOW ) );
	pDC->DrawText( m_Text, &textRect, DT_SINGLELINE  | DT_VCENTER );

	pDC->SelectObject( pOldPen );
	pDC->SelectObject( oldFont );
}

CString CABCLabel::GetObjectHTMLString()
{
	CString htmlStr;

	CString textStr = m_Text;
	textStr.Replace( "\"", "&quot;" );

	htmlStr.Format( "<DIV> %s </DIV>", textStr );

	return htmlStr;
}

CString CABCLabel::GetObjectString()
{
	CString propStr;

	CString textStr = m_Text;
	// ������ ������� �������� ���������
	textStr.Replace( "\"", "\"\"" );

	propStr.Format("<%s %s=\"%d\"; %s=\"%d\"; %s=\"%d\"; %s=\"%d\"; %s=\"%s\">",
				    GetObjectName(),
					ABCProperty_Left, m_Rect.left,
					ABCProperty_Top, m_Rect.top,
					ABCProperty_Width, m_Rect.Width(),
					ABCProperty_Height, m_Rect.Height(),
					ABCProperty_Text, textStr );

	return propStr;
}

int CABCLabel::SetProperty( CString propName, CString propValue)
{
	propName.MakeLower();
	int nValue = atoi( propValue);

	if ( propName == ABCProperty_Text )
	{
		m_Text = propValue;
		return ABCOSetProperty_Ok;
	}

	if ( propName == ABCProperty_Height )
	{
		if ( nValue )
		{
			m_Rect.bottom = m_Rect.top + nValue;
			return ABCOSetProperty_Ok;
		}
		else
		{
			return ABCOSetProperty_InvalidValue;
		}
	}

	return CABCObject::SetProperty( propName, propValue);
}

