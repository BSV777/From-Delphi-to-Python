/////////////////////////////////////////////////////////////////////////////
// ErrorView.h
/////////////////////////////////////////////////////////////////////////////

#if !defined( __ERRORSVIEW_H )
#define __ERRORSVIEW_H

#include <afxtempl.h>
#include <afxwin.h>
#include <afxext.h>
#include <afx.h>

/////////////////////////////////////////////////////////////////////////////
// class CErrorsFrame
/////////////////////////////////////////////////////////////////////////////
class CErrorsFrame : public CMDIChildWnd
{
	DECLARE_DYNCREATE(CErrorsFrame)
public:
	CErrorsFrame();

protected:
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// class CErrorsDoc
/////////////////////////////////////////////////////////////////////////////
class CErrorsView;
class CErrorsDoc : public CDocument
{

public:
	CErrorsView* m_pView;

	CStringArray m_Errors;

public:

	CErrorsDoc();
	~CErrorsDoc();

	DECLARE_DYNCREATE(CErrorsDoc)

	void AddError( CString errorStr );
	virtual void SetTitle( LPCTSTR lpszTitle );

	afx_msg void OnUpdate(CCmdUI* pCmdUI);

protected:
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
// class CErrorsView
/////////////////////////////////////////////////////////////////////////////

typedef CMap< UINT, UINT&, DWORD, DWORD& > CMapPos;
class CErrorsView : public CScrollView
{
	int m_CharHeight;
	int m_CharWidth;
	int m_LinesPerPage;
	int m_CharsPerPage;
	
	CFont m_Font;

public:
	int m_LineTotal;
	int m_MaxLineLength;

protected:
	CErrorsView();

	DECLARE_DYNCREATE(CErrorsView)

	CErrorsDoc* GetDocument();

	void SetScroll();

protected:
	virtual void OnDraw(CDC* pDC);

	virtual void OnInitialUpdate();

	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);

	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	DECLARE_MESSAGE_MAP()
};

#endif