/////////////////////////////////////////////////////////////////////////////
// ErrorView.cpp
/////////////////////////////////////////////////////////////////////////////

#include "ErrorsView.h"

#include <winspool.h>

static UINT FileFrameIndicators[] =
{
	ID_SEPARATOR
//	ID_INDICATOR_REC
};

BOOL PrintRawFile( LPTSTR pPrinterName, char * pFileName );

/////////////////////////////////////////////////////////////////////////////
// class CErrorsFrame
/////////////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNCREATE(CErrorsFrame, CMDIChildWnd)

BEGIN_MESSAGE_MAP(CErrorsFrame, CMDIChildWnd)
END_MESSAGE_MAP()

CErrorsFrame::CErrorsFrame()
{
}

/////////////////////////////////////////////////////////////////////////////
// class CErrorsDoc
/////////////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNCREATE(CErrorsDoc, CDocument)

BEGIN_MESSAGE_MAP(CErrorsDoc, CDocument)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, OnUpdate)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_AS, OnUpdate)
END_MESSAGE_MAP()

CErrorsDoc::CErrorsDoc()
{
}

CErrorsDoc::~CErrorsDoc()
{
	m_Errors.RemoveAll();
}

void CErrorsDoc::AddError( CString errorStr )
{
	m_Errors.Add( errorStr );

	if ( m_pView )
	{
		m_pView->SetScroll();
	}
}

void CErrorsDoc::OnUpdate(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable( FALSE );
}

void CErrorsDoc::SetTitle( LPCTSTR lpszTitle )
{
	CString titleStr = "������";
	//titleStr.Format( "������: %s", lpszTitle );
//	titleStr.Format( "������:" );
//	CDocument::SetTitle( lpszTitle );
	CDocument::SetTitle( titleStr );
}

/////////////////////////////////////////////////////////////////////////////
// class CErrorsView
/////////////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNCREATE( CErrorsView, CScrollView )

BEGIN_MESSAGE_MAP( CErrorsView, CScrollView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_KEYDOWN()
END_MESSAGE_MAP()

CErrorsView::CErrorsView()
{
	m_LineTotal = 0;
	m_MaxLineLength = 0;
	m_LinesPerPage = 1;
	m_CharsPerPage = 1;
}

CErrorsDoc* CErrorsView::GetDocument()
{
	return (CErrorsDoc*)m_pDocument;
}

BOOL CErrorsView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	dwStyle |= WS_HSCROLL | WS_VSCROLL;
	if ( !CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext) )
	{
		return FALSE;
	}
	
	GetDocument()->m_pView = this;

	LOGFONT logFont;
	memset( &logFont, 0, sizeof( LOGFONT ));

	CDC* pDC = GetDC();
	logFont.lfHeight = -MulDiv( 10, GetDeviceCaps(pDC->GetSafeHdc(), LOGPIXELSY), 72);
	logFont.lfWeight = FW_MEDIUM;

	logFont.lfCharSet = ANSI_CHARSET;

	logFont.lfPitchAndFamily = FIXED_PITCH;
	strcpy( logFont.lfFaceName, "Courier" );

	m_Font.CreateFontIndirect( &logFont );
	m_Font.GetLogFont( &logFont );

	TEXTMETRIC metrics;
	pDC->SelectObject( &m_Font );
	pDC->GetTextMetrics( &metrics );
	m_CharHeight = metrics.tmHeight;// + metrics.tmExternalLeading;

	return TRUE;
}

void CErrorsView::OnDraw(CDC* pDC )
{
	int y = 0;
	CFont* oldFont = pDC->GetCurrentFont();
	pDC->SelectObject( &m_Font );

	for( int i = 0; i < GetDocument()->m_Errors.GetSize(); i++ )
	{
		pDC->TabbedTextOut( 0, y, GetDocument()->m_Errors.GetAt( i ), 0, NULL, 0 );
		y += m_CharHeight;
	}

	pDC->SelectObject( oldFont );
}

void CErrorsView::OnInitialUpdate() 
{
	CScrollView::OnInitialUpdate();
	SetScroll();
}

void CErrorsView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CScrollView::OnKeyDown( nChar, nRepCnt, nFlags );

	switch (nChar)
	{
		case VK_HOME:
			OnVScroll(SB_TOP, 0, NULL);
			OnHScroll(SB_LEFT, 0, NULL);
        break;
	    case VK_END:
		    OnVScroll(SB_BOTTOM, 0, NULL);
			OnHScroll(SB_RIGHT, 0, NULL);
	        break;
		case VK_UP:
			OnVScroll(SB_LINEUP, 0, NULL);
	        break;
		case VK_DOWN:
			OnVScroll(SB_LINEDOWN, 0, NULL);
        break;
	    case VK_PRIOR:
		    OnVScroll(SB_PAGEUP, 0, NULL);
			break;
	    case VK_NEXT:
		    OnVScroll(SB_PAGEDOWN, 0, NULL);
			break;
	    case VK_LEFT:
		    OnHScroll(SB_LINELEFT, 0, NULL);
			break;
	    case VK_RIGHT:
		    OnHScroll(SB_LINERIGHT, 0, NULL);
			break;
	    default:
		    break;
    }
}

void CErrorsView::OnSize(UINT nType, int cx, int cy) 
{
	SetScroll();
	CScrollView::OnSize(nType, cx, cy);
}


void CErrorsView::SetScroll()
{
	int maxWidthLine = 0;

	CDC* pDC = GetDC();
	if ( pDC )
	{
		CFont* oldFont = pDC->GetCurrentFont();
		pDC->SelectObject( &m_Font );

		for( int i = 0; i < GetDocument()->m_Errors.GetSize(); i++ )
		{
			CSize lineSize = pDC->GetTextExtent( GetDocument()->m_Errors.GetAt(i) );
			maxWidthLine = __max( maxWidthLine, lineSize.cx );
		}

		pDC->SelectObject( oldFont );
	}

	CSize sizeTotal( maxWidthLine, m_CharHeight * GetDocument()->m_Errors.GetSize() );

	SetScrollSizes( MM_TEXT, sizeTotal );
}
