/////////////////////////////////////////////////////////////////////////////
// EditorView.h : interface of the CEditorView class
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_EDITORVIEW_H__604888AF_3198_11D6_849E_0001031609FA__INCLUDED_)
#define AFX_EDITORVIEW_H__604888AF_3198_11D6_849E_0001031609FA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxcoll.h>

#include "ABCObject.h"
#include "EditorDoc.h"

/////////////////////////////////////////////////////////////////////////////
// class CTracker
/////////////////////////////////////////////////////////////////////////////

class CEditorView;
class CMainFrame;

class CTracker : public CRectTracker
{
	CEditorView* m_pView;
	CMainFrame* m_pMainWnd;
	HCURSOR m_SaveCursor;

public:

	CTracker( CEditorView* pView, CMainFrame* pMainWnd );

	virtual void AdjustRect( int nHandle, LPRECT lpRect );
	virtual UINT GetHandleMask() const;
	virtual void OnChangedRect(const CRect& rectOld);

	void DPToLP( CRect* pRect );
	void LPToDP( CRect* pRect );
};

/////////////////////////////////////////////////////////////////////////////
// class CEditorView
/////////////////////////////////////////////////////////////////////////////

class CMainFrame;
class CABCObject;

class CEditorView : public CScrollView
{
	CMainFrame* m_pMainWnd;

	BOOL   m_IsCaptured;

    CTracker* m_pTracker;

	CSize m_ShadowSize; 

	void SetScroll();

	CString msgStr;

protected: // create from serialization only
	CEditorView();
	DECLARE_DYNCREATE(CEditorView)

// Attributes
public:
	CEditorDoc* GetDocument();

	UINT m_IDButton;
	CABCObject* m_pTrackObject;
	int m_ObjectType;

	HCURSOR m_DropCursor;
	HCURSOR m_NoDropCursor;
	CMenu m_PopupMenu;


	enum ShowStatusBarMode
	{
		ShowStatusBar_Object = 1,
		ShowStatusBar_Capture = 2
	};

// Operations
public:

	void Capture( BOOL bCapture = TRUE );

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditorView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CEditorView();

	CSize GetShadowSize(){ return m_ShadowSize; }
	int GetTrackObjectType();
	CRect GetTrackerRect();
	BOOL IsCaptured(){ return m_IsCaptured; };
	BOOL IsPointInShadow( CPoint point );
	void SetTracker( CABCObject* pObject );
	void ShowStatusBarText( int mode = ShowStatusBar_Object );


#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CEditorView)
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in EditorView.cpp
inline CEditorDoc* CEditorView::GetDocument()
   { return (CEditorDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITORVIEW_H__604888AF_3198_11D6_849E_0001031609FA__INCLUDED_)
