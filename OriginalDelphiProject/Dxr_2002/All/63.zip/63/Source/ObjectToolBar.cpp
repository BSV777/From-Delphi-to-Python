// ObjectToolBar.cpp : implementation file
//

#include "stdafx.h"
#include "Editor.h"
#include "ObjectToolBar.h"
#include "ABCObject.h"
#include "EditorView.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CObjectToolBar

BEGIN_MESSAGE_MAP(CObjectToolBar, CToolBar)
	//{{AFX_MSG_MAP(CObjectToolBar)
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CObjectToolBar::CObjectToolBar()
{
	m_DropCursor = NULL;
	m_NoDropCursor = CABCObject::GetNoDropCursor();

    m_IsCaptured = FALSE;
	m_IDButton = NULL;
	m_ObjectType = CABCObject::ABCObject_Null;
}

CObjectToolBar::~CObjectToolBar()
{
}

void CObjectToolBar::Capture( BOOL bCapture )
{
	if ( bCapture )
	{
		if ( !m_IsCaptured )
		{
			SetCapture();
			m_IsCaptured = TRUE;
			GetToolBarCtrl().CheckButton( m_IDButton );
			::SetCursor( m_NoDropCursor );
		}
	}
	else
	{
		if ( m_IsCaptured )
		{
			::ReleaseCapture();
			m_IsCaptured = FALSE;
			GetToolBarCtrl().CheckButton( m_IDButton, FALSE  );
			m_IDButton = NULL;
			m_ObjectType = CABCObject::ABCObject_Null;
		}
	}
}

CSize CObjectToolBar::CalcDynamicLayout(int nLength, DWORD dwMode)
{
	if ((nLength == -1) && !(dwMode & LM_MRUWIDTH) && !(dwMode & LM_COMMIT) &&
		((dwMode & LM_HORZDOCK) || (dwMode & LM_VERTDOCK)))
	{
		return CalcFixedLayout(dwMode & LM_STRETCH, dwMode & LM_HORZDOCK);
	}

	dwMode = LM_VERTDOCK | LM_COMMIT;

	return CalcLayout( dwMode, nLength);
}

CView* CObjectToolBar::GetActiveView()
{
	CMDIFrameWnd* pMainWnd = (CMDIFrameWnd*)AfxGetMainWnd();
	if ( pMainWnd )
	{
		CMDIChildWnd* pChildWnd = (CMDIChildWnd*) pMainWnd->MDIGetActive();
		if ( pChildWnd )
		{
			CView* pView = pChildWnd->GetActiveView();
			if ( pView )
			{
				if ( pView->IsKindOf(RUNTIME_CLASS( CEditorView )))
				{
					return pView;
				}
			}
		}
	}

	return NULL;
}

BOOL CObjectToolBar::IsMouseInBar( CPoint point )
{
	CRect rect;
	GetClientRect( &rect );

	if ( rect.PtInRect( point ) )
	{
		return TRUE;
	}

	return FALSE;
}


BOOL CObjectToolBar::IsMouseInView( CPoint point )
{
	CEditorView* pView = (CEditorView*) GetActiveView();

	if ( pView )
	{
		CPoint spoint = point;
		ClientToScreen( &spoint );
		pView->ScreenToClient( &spoint );

		CRect srect;
		pView->GetClientRect( &srect );

		if ( srect.PtInRect( spoint ) && !pView->IsPointInShadow( spoint ) )
		{
			return TRUE;
		}
	}

	return FALSE;
}


void CObjectToolBar::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if ( m_IsCaptured )
	{

		if ( IsMouseInView( point ) && !IsMouseInBar( point ) )
		{
			CPoint vpoint = ToViewPoint( point );
			GetActiveView()->SendMessage( WM_COMMAND, m_IDButton, (LPARAM) &vpoint );
		}

		Capture( FALSE );
		return;
	}

	CToolBar::OnLButtonUp(nFlags, point);
}

void CObjectToolBar::OnMouseMove(UINT nFlags, CPoint point) 
{
	if ( nFlags == MK_LBUTTON )
	{
		CMainFrame* pWnd = (CMainFrame*) AfxGetMainWnd();

		if ( !IsMouseInBar( point )  && !m_IsCaptured )
		{
			m_IDButton = NULL;
			m_ObjectType = CABCObject::ABCObject_Null;

			TBBUTTON tb;
			GetToolBarCtrl().GetButton( GetToolBarCtrl().GetHotItem(), &tb );

			m_ObjectType = CABCObject::GetTypeByID( tb.idCommand );

			if( m_ObjectType != CABCObject::ABCObject_Null )
			{
				m_IDButton = tb.idCommand;
				m_DropCursor = CABCObject::GetObjectCursor( m_ObjectType );
				Capture();
			}
		}

		if ( m_IsCaptured )
		{
			if ( IsMouseInView( point ) &&  !IsMouseInBar( point ) )
			{
				::SetCursor( m_DropCursor );
			}
			else
			{
				::SetCursor( m_NoDropCursor );
			}
		}
	}
	
	CToolBar::OnMouseMove(nFlags, point);
}

CPoint CObjectToolBar::ToViewPoint( CPoint point )
{
	CPoint vpoint( -1, -1 );

	CView* pView = GetActiveView();

	if ( pView )
	{
		vpoint = point;
		ClientToScreen( &vpoint );
		pView->ScreenToClient( &vpoint );
	}

	return vpoint;
}



