/////////////////////////////////////////////////////////////////////////////
// InsertObjectDialog.cpp : implementation file
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Editor.h"
#include "InsertObjectDialog.h"
#include "ABCObject.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInsertObjectDialog dialog
/////////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CInsertObjectDialog, CDialog)
	//{{AFX_MSG_MAP(CInsertObjectDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


CInsertObjectDialog::CInsertObjectDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CInsertObjectDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CInsertObjectDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_Type = CABCObject::ABCObject_Null;
}

void CInsertObjectDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInsertObjectDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


/////////////////////////////////////////////////////////////////////////////
// CInsertObjectDialog message handlers

BOOL CInsertObjectDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();

	CListBox* pList = (CListBox*) GetDlgItem( IDC_LIST_OBJECTS );

	if( !ABCObjectMap.IsEmpty() )
	{
		POSITION pos = ABCObjectMap.GetStartPosition();

		WORD keyValue = NULL;
		void* pValue = NULL;
		ABCObjectStruct* pObject = NULL;

		while( pos != NULL )
		{
			ABCObjectMap.GetNextAssoc( pos, keyValue, pValue );
			pObject = (ABCObjectStruct*) pValue;

			int nIndex = pList->AddString( pObject->m_Name );
			pList->SetItemData( nIndex, pObject->m_Type );
		}
	}

	pList->SetCurSel( 0 );

	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CInsertObjectDialog::OnOK() 
{
	// TODO: Add extra validation here
	CListBox* pList = (CListBox*) GetDlgItem( IDC_LIST_OBJECTS );

	m_Type = pList->GetItemData( pList->GetCurSel() );

	CDialog::OnOK();
}
