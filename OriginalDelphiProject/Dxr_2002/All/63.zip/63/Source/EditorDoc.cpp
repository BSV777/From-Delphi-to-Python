/////////////////////////////////////////////////////////////////////////////
// EditorDoc.cpp : implementation of the CEditorDoc class
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Editor.h"
#include "EditorDoc.h"
#include "EditorView.h"
#include "InsertObjectDialog.h"
#include "PropertyDialog.h"
#include "ErrorsView.h"

#include "ABCObject.h"
#include "Parser.h"
#include "MainFrm.h"
#include "ExpHTML.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditorDoc

IMPLEMENT_DYNCREATE(CEditorDoc, CDocument)

BEGIN_MESSAGE_MAP(CEditorDoc, CDocument)
	//{{AFX_MSG_MAP(CEditorDoc)
	ON_COMMAND(ID_DELETE_OBJECT, OnDeleteObject)
	ON_COMMAND(ID_ADD_OBJECT, OnAddObject)
	ON_COMMAND(ID_PROPERTY_OBJECT, OnPropertyObject)
	ON_UPDATE_COMMAND_UI(ID_DELETE_OBJECT, OnUpdateCommand )
	ON_COMMAND(ID_ADD_BUTTON, OnAddButton)
	ON_COMMAND(ID_ADD_LABEL, OnAddLabel)
	ON_COMMAND(ID_ADD_TEXTEDIT, OnAddTextEdit)
	ON_COMMAND(ID_SAVE_TO_HTML, OnSaveToHtml)
	ON_UPDATE_COMMAND_UI(ID_PROPERTY_OBJECT, OnUpdateCommand )
	ON_UPDATE_COMMAND_UI(ID_SAVE_TO_HTML, OnUpdateSaveToHtml)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditorDoc construction/destruction

CEditorDoc::CEditorDoc()
{
	m_pView = NULL;
}

CEditorDoc::~CEditorDoc()
{
	for( int i = 0; i < m_ObjectsPtr.GetSize(); i++ )
	{
		CABCObject* pObject = (CABCObject*) m_ObjectsPtr.GetAt( i );
		CABCObject::DestroyObject( pObject );
	}

	m_ObjectsPtr.RemoveAll();
}

void CEditorDoc::AddObject( int type, CPoint point )
{
	CABCObject* pObject = CABCObject::CreateObject( type, point );

	if ( pObject )
	{
		if ( !CABCObject::IsObjectIntersect(  &m_ObjectsPtr, pObject->GetRect(), NULL ) )
		{
			m_ObjectsPtr.Add( pObject );
			m_pView->SetTracker( pObject );
			UpdateAllViews( NULL );
			SetModifiedFlag();
		}
		else
		{
			CABCObject::DestroyObject( pObject );
		}
	}
}

CABCObject* CEditorDoc::GetObjectByPoint( CPoint point )
{
	for( int i = 0; i < m_ObjectsPtr.GetSize(); i++ )
	{
		CABCObject* pObject = (CABCObject*) m_ObjectsPtr.GetAt( i );
		CRect rectInter;
		if ( pObject->GetRect().PtInRect( point ) )
		{
			return pObject;
		}
	}

	return NULL;
}

void CEditorDoc::OnAddButton() 
{
	m_pView->m_IDButton = ID_ADD_BUTTON;
	m_pView->m_ObjectType = CABCObject::ABCObject_Button;
	m_pView->Capture();
}

void CEditorDoc::OnAddLabel() 
{
	m_pView->m_IDButton = ID_ADD_LABEL;
	m_pView->m_ObjectType = CABCObject::ABCObject_Label;
	m_pView->Capture();
}

void CEditorDoc::OnAddObject() 
{
	CInsertObjectDialog dlg;

	if ( dlg.DoModal() == IDOK )
	{
		if ( dlg.m_Type != CABCObject::ABCObject_Null )
		{
			m_pView->m_IDButton = NULL;
			m_pView->m_ObjectType = dlg.m_Type;
			m_pView->Capture();
		}
	}
}

void CEditorDoc::OnAddTextEdit() 
{
	m_pView->m_IDButton = ID_ADD_TEXTEDIT;
	m_pView->m_ObjectType = CABCObject::ABCObject_TextEdit;
	m_pView->Capture();
}

void CEditorDoc::OnDeleteObject() 
{
	if ( m_pView->m_pTrackObject )
	{
		if ( AfxMessageBox( "������� ���������� ������ ?", MB_YESNOCANCEL    ) == IDYES )
		{
			for( int i = 0; i < m_ObjectsPtr.GetSize(); i++ )
			{
				CABCObject* pObject = (CABCObject*) m_ObjectsPtr.GetAt( i );
				if ( pObject == m_pView->m_pTrackObject )
				{
					CABCObject::DestroyObject( pObject );
					m_ObjectsPtr.RemoveAt( i );
					m_pView->SetTracker( NULL );
					UpdateAllViews( NULL );
					SetModifiedFlag();
					break;
				}
			}
		}
	}
}


BOOL CEditorDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}

BOOL CEditorDoc::OnOpenDocument(LPCTSTR lpszPathName ) 
{
	BOOL result = TRUE;
	CWaitCursor waitCursor;
	CABCParser* pParser = new CABCParser( lpszPathName, &m_ObjectsPtr );

	if ( !pParser->Run() )
	{
		CStringArray* pErrors = pParser->GetErrors();
		if ( pErrors->GetSize() )
		{
			CMainFrame* pMainWnd = (CMainFrame*) AfxGetMainWnd();
			if ( pMainWnd )
			{
				CErrorsDoc* pDoc = (CErrorsDoc*)pMainWnd->ShowErrors( lpszPathName );
				if ( pDoc )
				{
					for( int i = 0; i < pErrors->GetSize(); i++ )
					{
						pDoc->AddError( pErrors->GetAt(i) );
					}
				}
			}	
		}

		if ( pParser->GetErrorType() & CABCParser::Error )
		{
			result = FALSE;
		}
	}

	if ( result )
	{
		// �������� � ������ ������������� objectsRect.left � objectsRect.top 
		// � ��� ��������� �����
		CRect objectsRect = CABCObject::GetObjectsRect( &m_ObjectsPtr );
		CSize shadowSize = m_pView->GetShadowSize();
		CPoint offset( __min( objectsRect.left, 0 ), __min( objectsRect.top, 0 ) );
		CABCObject::OffsetObjectsRects( &m_ObjectsPtr, shadowSize.cx - offset.x, shadowSize.cx - offset.y );
	}

	delete pParser;
	
	return result;
}

void CEditorDoc::OnPropertyObject() 
{
	if ( m_pView->m_pTrackObject )
	{
		CPropertyDialog dlg;
		dlg.m_ObjectName = m_pView->m_pTrackObject->GetObjectName();
		dlg.m_Text = m_pView->m_pTrackObject->GetText();

		if( dlg.DoModal() == IDOK )
		{
			if ( m_pView->m_pTrackObject->GetText() != dlg.m_Text )
			{
				m_pView->m_pTrackObject->SetText( dlg.m_Text );
				CRect rectTracker = m_pView->GetTrackerRect();
				UpdateAllViews(NULL, (LPARAM)(LPCRECT)rectTracker);
				SetModifiedFlag();
			}
		}
	}
}

BOOL CEditorDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	CWaitCursor waitCursor;

	CStdioFile file;

	if( file.Open( lpszPathName, CFile::modeWrite | CFile::modeCreate | CFile::typeText )  )
	{

		for( int i = 0; i < m_ObjectsPtr.GetSize(); i++ )
		{
			CABCObject* pObject = (CABCObject*) m_ObjectsPtr.GetAt( i );

			CRect rectSave = pObject->GetRect();
			CRect rect = rectSave;
			CSize shadowSize = m_pView->GetShadowSize();
			rect.OffsetRect( -shadowSize.cx, -shadowSize.cx );

			pObject->SetRect( rect );

			CString wStr;
			wStr.Format( "%s\n", pObject->GetObjectString() );

			pObject->SetRect( rectSave );

			file.WriteString( wStr );
		}

		file.Close();

		SetModifiedFlag( FALSE );
		return TRUE;
	}
	else
	{
		file.Abort();
	}
	
	return FALSE;
}


void CEditorDoc::OnSaveToHtml() 
{
	char BASED_CODE szFilter[] = "(*.html)|*.html|(*.*)|*.*||";
 
	CFileDialog dlgFile( FALSE, "html", NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter );

	dlgFile.m_ofn.lpstrTitle = "��������� � ������� HTML";

	if ( dlgFile.DoModal() == IDOK )
	{
		CString HTMLFile = dlgFile.GetPathName();
		
		CABCExportHTML* pExpHTML = new CABCExportHTML( &m_ObjectsPtr, HTMLFile);

		pExpHTML->Run();

		delete pExpHTML;
	}
}

void CEditorDoc::OnUpdateCommand(CCmdUI* pCmdUI) 
{
	CMenu* pPopupMenu = m_pView->m_PopupMenu.GetSubMenu( 0 );

	if ( !m_pView->m_pTrackObject )
	{
		pCmdUI->Enable( FALSE );
		pPopupMenu->EnableMenuItem( pCmdUI->m_nID, MF_BYCOMMAND | MF_GRAYED );
	}
	else
	{
		pCmdUI->Enable();
		pPopupMenu->EnableMenuItem( pCmdUI->m_nID, MF_BYCOMMAND | MF_ENABLED );

	}
}

void CEditorDoc::OnUpdateSaveToHtml(CCmdUI* pCmdUI) 
{
	if ( m_ObjectsPtr.GetSize() )
	{
		pCmdUI->Enable();
	}
	else
	{
		pCmdUI->Enable( FALSE );
	}
}

/////////////////////////////////////////////////////////////////////////////
// CEditorDoc diagnostics
/////////////////////////////////////////////////////////////////////////////

#ifdef _DEBUG
void CEditorDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CEditorDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG




