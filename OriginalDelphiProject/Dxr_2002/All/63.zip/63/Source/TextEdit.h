/////////////////////////////////////////////////////////////////////////////
// TextEdit.h : header file
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEXTEDIT_H__93DA4E11_3687_11D6_84A2_0001031609FA__INCLUDED_)
#define AFX_TEXTEDIT_H__93DA4E11_3687_11D6_84A2_0001031609FA__INCLUDED_

#include "ABCObject.h"


/////////////////////////////////////////////////////////////////////////////
// CABCTextEdit
/////////////////////////////////////////////////////////////////////////////

class CABCTextEdit : public CABCObject
{

public:

	CABCTextEdit() : CABCObject( ABCObject_TextEdit ) {	m_Rect = CRect( CPoint( 0, 0 ), GetDefaultSize() );};
	CABCTextEdit( CPoint point ) : CABCObject( ABCObject_TextEdit, point ) { m_Rect = CRect( point, GetDefaultSize() );};
	~CABCTextEdit(){};

	virtual CSize GetDefaultSize() { return CSize( 110, 20 ); }; 
	virtual CString GetObjectHTMLString();
	virtual void Draw(CDC* pDC);
	virtual CString GetObjectString();
	virtual int SetProperty( CString propName, CString propValue);
};

#endif // !defined(AFX_TEXTEDIT_H__93DA4E11_3687_11D6_84A2_0001031609FA__INCLUDED_)
