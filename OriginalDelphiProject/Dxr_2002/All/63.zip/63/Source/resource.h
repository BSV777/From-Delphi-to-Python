//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Editor.rc
//
#define IDD_ABOUTBOX                    100
#define IDC_DROP                        105
#define IDC_NODROP                      106
#define IDR_MAINFRAME                   128
#define IDR_EDITORTYPE                  129
#define IDD_ADD_OBJECT                  131
#define IDC_DROP_TEXTEDIT               135
#define IDC_DROP_BUTTON                 136
#define IDR_POPUP                       136
#define IDC_DROP_LABEL                  137
#define IDD_PROPERTY                    137
#define IDR_ERRORS                      139
#define IDB_PROPERTY_OBJECT             213
#define IDB_ADD_OBJECT                  214
#define IDB_DELETE_OBJECT               215
#define IDC_LIST_OBJECTS                1000
#define IDC_SCROLLBAR1                  1003
#define IDC_EDIT_TEXT                   1008
#define ID_DELETE_OBJECT                32772
#define ID_PROPERTY_OBJECT              32773
#define ID_OBJECT_TOOLBAR               32777
#define ID_ADD_OBJECT                   -32753
#define ID_ADD_TEXTEDIT                 32784
#define ID_ADD_BUTTON                   32785
#define ID_ADD_LABEL                    32786
#define ID_SAVE_TO_HTML                 32787
#define AFX_IDP_ASK_TO_SAVE_RUS         57605
#define ID_INDICATOR_POS                57638
#define ID_INDICATOR_DIM                57639

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32788
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
