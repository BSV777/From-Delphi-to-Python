/////////////////////////////////////////////////////////////////////////////
// MainFrm.cpp : implementation of the CMainFrame class
/////////////////////////////////////////////////////////////////////////////

#include <afxpriv.h>
#include "stdafx.h"
#include "Editor.h"
#include "EditorView.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_POS,
	ID_INDICATOR_DIM
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

CMultiDocTemplate* CMainFrame::m_pABCDocTemplate = NULL;
CMultiDocTemplate* CMainFrame::m_pErrorsDocTemplate = NULL;


IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_OBJECT_TOOLBAR, OnObjectToolbar)
	ON_UPDATE_COMMAND_UI(ID_OBJECT_TOOLBAR, OnUpdateObjectToolbar)
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	//}}AFX_MSG_MAP
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_POS, OnUpdateStatusBar )
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_DIM, OnUpdateStatusBar )
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
}


/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG


void CMainFrame::CheckObjectButton( UINT nID, BOOL bCheck )
{
	m_ObjectToolBar.GetToolBarCtrl().CheckButton( nID, bCheck );
}


int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	m_wndStatusBar.SetPaneInfo( 1, m_wndStatusBar.GetItemID( 1 ), m_wndStatusBar.GetPaneStyle( 1 ), 80 );
	m_wndStatusBar.SetPaneInfo( 2, m_wndStatusBar.GetItemID( 2 ), m_wndStatusBar.GetPaneStyle( 2 ), 80 );

	if (!m_ObjectToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | WS_CAPTION | CBRS_RIGHT
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC ) ||
		!m_ObjectToolBar.LoadToolBar(IDR_EDITORTYPE ))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	m_ObjectToolBar.EnableDocking( CBRS_ALIGN_RIGHT );
	EnableDocking( CBRS_ALIGN_ANY );
	DockControlBar( &m_ObjectToolBar, AFX_IDW_DOCKBAR_RIGHT  );

	return 0;
}



void CMainFrame::OnFileNew() 
{
	m_pABCDocTemplate->OpenDocumentFile(NULL);
}

void CMainFrame::OnFileOpen() 
{
	CString fileName;

	if (AfxGetApp()->m_pDocManager->DoPromptFileName( fileName, AFX_IDS_OPENFILE, OFN_HIDEREADONLY | OFN_FILEMUSTEXIST, TRUE, m_pABCDocTemplate ))
	{
		m_pABCDocTemplate->OpenDocumentFile( fileName );
	}


/*	CFileDialog dlgFile(bOpenFileDialog);

	CString title;
	VERIFY(title.LoadString(nIDSTitle));

	dlgFile.m_ofn.Flags |= lFlags;

	CString strFilter;
	CString strDefault;
	if (pTemplate != NULL)
	{
		ASSERT_VALID(pTemplate);
		_AfxAppendFilterSuffix(strFilter, dlgFile.m_ofn, pTemplate, &strDefault);
	}
	else
	{
		// do for all doc template
		POSITION pos = m_templateList.GetHeadPosition();
		BOOL bFirst = TRUE;
		while (pos != NULL)
		{
			CDocTemplate* pTemplate = (CDocTemplate*)m_templateList.GetNext(pos);
			_AfxAppendFilterSuffix(strFilter, dlgFile.m_ofn, pTemplate,
				bFirst ? &strDefault : NULL);
			bFirst = FALSE;
		}
	}

	// append the "*.*" all files filter
	CString allFilter;
	VERIFY(allFilter.LoadString(AFX_IDS_ALLFILTER));
	strFilter += allFilter;
	strFilter += (TCHAR)'\0';   // next string please
	strFilter += _T("*.*");
	strFilter += (TCHAR)'\0';   // last string
	dlgFile.m_ofn.nMaxCustFilter++;

	dlgFile.m_ofn.lpstrFilter = strFilter;
	dlgFile.m_ofn.lpstrTitle = title;
	dlgFile.m_ofn.lpstrFile = fileName.GetBuffer(_MAX_PATH);

	int nResult = dlgFile.DoModal();
	fileName.ReleaseBuffer();
	return nResult == IDOK;
*/
//	m_pDocManager->OnFileOpen();

}


void CMainFrame::OnObjectToolbar() 
{
	ShowControlBar( &m_ObjectToolBar, TRUE, FALSE);
}

void CMainFrame::OnUpdateObjectToolbar(CCmdUI* pCmdUI) 
{
	if( m_ObjectToolBar.GetStyle() & WS_VISIBLE )
	{
		pCmdUI->Enable( FALSE );
	}
	else
	{
		pCmdUI->Enable( TRUE );
	}
}

void CMainFrame::OnUpdateStatusBar( CCmdUI* pCmdUI )
{
	CFrameWnd::OnIdleUpdateCmdUI();

	CMDIChildWnd* pChildWnd = (CMDIChildWnd*) MDIGetActive();
	if ( pChildWnd )
	{
		CView* pView = pChildWnd->GetActiveView();
		if ( pView )
		{
			if ( pView->IsKindOf(RUNTIME_CLASS( CEditorView )))
			{
				CEditorView* pEditorView = (CEditorView*) pView;

				if( pEditorView->IsCaptured() || m_ObjectToolBar.IsCaptured() )
				{
					pEditorView->ShowStatusBarText( CEditorView::ShowStatusBar_Capture );
					return;
				}

				pEditorView->ShowStatusBarText( CEditorView::ShowStatusBar_Object );
				return;
			}
		}
	}

	SetStatusBarText(  "", ""  );
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMDIFrameWnd::PreCreateWindow(cs) )
		return FALSE;

	return TRUE;
}


BOOL CMainFrame::PreTranslateMessage(MSG* pMsg) 
{
	if ( pMsg->message == WM_KEYDOWN )
	{
		m_ObjectToolBar.Capture( FALSE );
	}

	return CMDIFrameWnd::PreTranslateMessage(pMsg);
}

void CMainFrame::SetStatusBarText(  CString posStr, CString dimStr  )
{
	m_wndStatusBar.SetPaneText( 1, posStr, TRUE );
	m_wndStatusBar.SetPaneText( 2, dimStr, TRUE );
}

CDocument* CMainFrame::ShowErrors( CString fileName )
{
	return m_pErrorsDocTemplate->OpenDocumentFile( NULL );
}
