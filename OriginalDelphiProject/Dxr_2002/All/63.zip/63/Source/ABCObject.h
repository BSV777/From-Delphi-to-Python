/////////////////////////////////////////////////////////////////////////////
// ABCObject.h : header file
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ABCOBJECT_H__93DA4E11_3687_11D6_84A2_0001031609FA__INCLUDED_)
#define AFX_ABCOBJECT_H__93DA4E11_3687_11D6_84A2_0001031609FA__INCLUDED_


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

const CString ABCProperty_Left		= "left";
const CString ABCProperty_Top		= "top";
const CString ABCProperty_Width		= "width";
const CString ABCProperty_Height	= "height";
const CString ABCProperty_Text		= "text";
const CString ABCProperty_Caption	= "caption";


const unsigned int ABCObject_RectInflate = 2;

extern HCURSOR m_NoDropCursor;

extern HCURSOR ABC_TextEditCursor;
extern HCURSOR ABC_ButtonCursor;
extern HCURSOR ABC_LabelCursor;

typedef struct
{
	CString m_Name;
	int m_Type;
	HCURSOR m_Cursor;
} ABCObjectStruct;

extern CMapWordToPtr ABCObjectMap;

/////////////////////////////////////////////////////////////////////////////
// CABCObject
/////////////////////////////////////////////////////////////////////////////

class CABCObject
{
protected:

	int m_Type;
	CRect m_Rect;
	CString m_Text;

	static void LoadCursors();

public:
	CABCObject( int type, CPoint point = CPoint( 0, 0 ) );
	~CABCObject();

	virtual CSize GetDefaultSize() { return CSize( 0, 18 ); }; 
	CString GetObjectName() { return GetObjectName( m_Type ); };
	virtual CString GetObjectString() { return ""; };
	virtual CString GetObjectHTMLString() { return ""; };
	CRect GetRect() { return m_Rect; };
	CString GetText() { return m_Text; };
	int GetType(){ return m_Type; };
	virtual void Draw(CDC* pDC) {};
	virtual int SetProperty( CString propName, CString propValue);
	void SetRect( CRect newRect ) { m_Rect = newRect; };
	void SetText( CString newText ) { m_Text = newText; }

	static void ABCInit();
	static void ABCExit();

	static CABCObject* CreateObject( int type, CPoint point = CPoint( 0, 0 ) );
	static void DestroyObject( CABCObject* pObject );
	static HCURSOR GetNoDropCursor();
	static HCURSOR GetObjectCursor( int type );
	static int GetTypeByID( UINT nID );
	static CString GetObjectName( int type );
	static int GetObjectType( CString name );

	static CRect GetObjectsRect( CPtrArray* pObjectsPtr );
	static void OffsetObjectsRects( CPtrArray* pObjectsPtr, int x, int y );
	static void NormalizeObjectsRects( CPtrArray* pObjectsPtr );
	static BOOL IsObjectIntersect( CPtrArray* pObjectsPtr, CRect rect, CABCObject* pExludeObject );



public:
	enum ABCObjectType
	{
		ABCObject_Null		 = 0,
		ABCObject_TextEdit	 = 1,
		ABCObject_Button	 = 2,
		ABCObject_Label		 = 3
	};

public:
	enum ABCSetPropertyErrors
	{
		ABCOSetProperty_Ok			 = 0,
		ABCOSetProperty_InvalidName	 = 1,
		ABCOSetProperty_InvalidValue = 2,
	};
};

#endif // !defined(AFX_ABCOBJECT_H__93DA4E11_3687_11D6_84A2_0001031609FA__INCLUDED_)
