/////////////////////////////////////////////////////////////////////////////
// EditorDoc.h : interface of the CEditorDoc class
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_EDITORDOC_H__604888AD_3198_11D6_849E_0001031609FA__INCLUDED_)
#define AFX_EDITORDOC_H__604888AD_3198_11D6_849E_0001031609FA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// class CEditorDoc
/////////////////////////////////////////////////////////////////////////////

class CEditorView;
class CABCObject;

class CEditorDoc : public CDocument
{

protected: // create from serialization only
	CEditorDoc();
	DECLARE_DYNCREATE(CEditorDoc)

// Attributes
public:

	CEditorView* m_pView;
	CPtrArray m_ObjectsPtr;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditorDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	//virtual BOOL SaveModified();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CEditorDoc();

	void AddObject( int type, CPoint point );
	CABCObject* GetObjectByPoint( CPoint point );

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
public:
	//{{AFX_MSG(CEditorDoc)
	afx_msg void OnDeleteObject();
	afx_msg void OnAddObject();
	afx_msg void OnPropertyObject();
	afx_msg void OnUpdateCommand(CCmdUI* pCmdUI);
	afx_msg void OnAddButton();
	afx_msg void OnAddLabel();
	afx_msg void OnAddTextEdit();
	afx_msg void OnSaveToHtml();
	afx_msg void OnUpdateSaveToHtml(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITORDOC_H__604888AD_3198_11D6_849E_0001031609FA__INCLUDED_)
