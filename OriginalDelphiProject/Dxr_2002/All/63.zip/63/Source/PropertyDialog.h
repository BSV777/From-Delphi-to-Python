/////////////////////////////////////////////////////////////////////////////
// PropertyDialog.h : header file
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROPERTYDIALOG_H__5A0F38F5_A942_4416_B3C4_FB8B49223A5D__INCLUDED_)
#define AFX_PROPERTYDIALOG_H__5A0F38F5_A942_4416_B3C4_FB8B49223A5D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CPropertyDialog dialog
/////////////////////////////////////////////////////////////////////////////

class CPropertyDialog : public CDialog
{
// Construction
public:
	CPropertyDialog( CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPropertyDialog)
	enum { IDD = IDD_PROPERTY };
	CString	m_Text;
	//}}AFX_DATA
	CString m_ObjectName;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPropertyDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPropertyDialog)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPERTYDIALOG_H__5A0F38F5_A942_4416_B3C4_FB8B49223A5D__INCLUDED_)
