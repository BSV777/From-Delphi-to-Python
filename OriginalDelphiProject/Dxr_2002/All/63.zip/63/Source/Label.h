/////////////////////////////////////////////////////////////////////////////
// Label.h : header file
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LABEL_H__93DA4E11_3687_11D6_84A2_0001031609FA__INCLUDED_)
#define AFX_LABEL_H__93DA4E11_3687_11D6_84A2_0001031609FA__INCLUDED_

#include "ABCObject.h"


/////////////////////////////////////////////////////////////////////////////
// CABCLabel
/////////////////////////////////////////////////////////////////////////////

class CABCLabel : public CABCObject
{

public:
	CABCLabel() : CABCObject( ABCObject_Label ) {	m_Rect = CRect( CPoint( 0, 0 ), GetDefaultSize() );};
	CABCLabel( CPoint point ) : CABCObject( ABCObject_Label, point ) {	m_Rect = CRect( point, GetDefaultSize() );};
	~CABCLabel(){};

	virtual CSize GetDefaultSize() { return CSize( 100, 20 ); }; 
	virtual void Draw(CDC* pDC);
	virtual CString GetObjectString();
	virtual CString GetObjectHTMLString();
	virtual int SetProperty( CString propName, CString propValue);
};

#endif // !defined(AFX_LABEL_H__93DA4E11_3687_11D6_84A2_0001031609FA__INCLUDED_)
