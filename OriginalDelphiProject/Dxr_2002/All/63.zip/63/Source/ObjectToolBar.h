/////////////////////////////////////////////////////////////////////////////
// ObjectToolBar.h : header file
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OBJECTTOOLBAR_H__58A00156_34F5_11D6_84A0_0001031609FA__INCLUDED_)
#define AFX_OBJECTTOOLBAR_H__58A00156_34F5_11D6_84A0_0001031609FA__INCLUDED_

#include "ABCObject.h"


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


/////////////////////////////////////////////////////////////////////////////
// CObjectToolBar window

class CObjectToolBar : public CToolBar
{
	HCURSOR m_DropCursor;
	HCURSOR m_NoDropCursor;

	BOOL   m_IsCaptured;

	UINT m_IDButton;
	int m_ObjectType;

	CView* GetActiveView();

	BOOL IsMouseInBar( CPoint point );
	BOOL IsMouseInView( CPoint point );
	CPoint ToViewPoint( CPoint point );
		

// Construction
public:
	CObjectToolBar();

// Attributes
public:

// Operations
public:
	BOOL IsCaptured(){ return m_IsCaptured; };

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CObjectToolBar)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CObjectToolBar();

	virtual CSize CalcDynamicLayout(int nLength, DWORD nMode);

	void Capture( BOOL bCapture = TRUE );

	// Generated message map functions
protected:
	//{{AFX_MSG(CObjectToolBar)
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OBJECTTOOLBAR_H__58A00156_34F5_11D6_84A0_0001031609FA__INCLUDED_)
