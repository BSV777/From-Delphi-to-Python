/////////////////////////////////////////////////////////////////////////////
// EditorView.cpp : implementation of the CEditorView class
/////////////////////////////////////////////////////////////////////////////

#include <stdlib.h>


#include "stdafx.h"
#include "Editor.h"

#include "EditorDoc.h"
#include "EditorView.h"
#include "MainFrm.h"

#include "ABCObject.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const CString posStrFormat = "  %d, %d";
const CString dimStrFormat = "  %d x %d";


/////////////////////////////////////////////////////////////////////////////
// class CTracker
/////////////////////////////////////////////////////////////////////////////

CTracker::CTracker(  CEditorView* pView, CMainFrame* pMainWnd ) : CRectTracker()
{
	m_pView = pView;
	m_pMainWnd = pMainWnd;
	m_SaveCursor = NULL;
};

void CTracker::AdjustRect( int nHandle, LPRECT lpRect )
{
	// ����������� m_rect, ����� �� �� �������
	// �� ����� � ������� ����� ���� CEditorView

	CRectTracker::AdjustRect( nHandle, lpRect );

	switch( nHandle )
	{
		case hitLeft:
		case hitTop:
		case hitTopLeft:
		case hitTopRight:
			// �������� ���������� ����������
			DPToLP( &m_rect );

			m_rect.left = __max( m_rect.left, 0 );
			m_rect.top = __max( m_rect.top, 0 );

			LPToDP( &m_rect );

		break;
	}
}

UINT CTracker::GetHandleMask() const
{
	UINT mask = 0xff;

	if ( m_pView )
	{
		// TextEdit ����� �������� ������ �������������� ������
		if ( m_pView->GetTrackObjectType() == CABCObject::ABCObject_TextEdit )
		{
			mask = 0x80 | 0x20;
		}
	}

	return mask;
}

void CTracker::OnChangedRect(const CRect& rectOld)
{
	if ( m_pMainWnd )
	{
		if ( m_pView )
		{
			CString posStr = "";
			CString dimStr = "";
			CRect rect = m_rect;
			DPToLP( &rect );

			CSize shadowSize = m_pView->GetShadowSize();

			if ( rect.left < shadowSize.cx || rect.top < shadowSize.cy )
			{
				if ( !m_SaveCursor )
				{
					m_SaveCursor = ::SetCursor( m_pView->m_NoDropCursor );
				}
			}
			else
			{
				if ( m_SaveCursor )
				{
					::SetCursor( m_SaveCursor );
					m_SaveCursor = NULL;
				}
			}

			rect.OffsetRect( -shadowSize.cx, -shadowSize.cy );

			posStr.Format( posStrFormat, __max( rect.left, 0 ), __max( rect.top, 0 ) );
			dimStr.Format( dimStrFormat, rect.Width(), rect.Height() );
			m_pMainWnd->SetStatusBarText(  posStr, dimStr  );
		}
	}
}

void CTracker::DPToLP( CRect* pRect )
{
	if ( m_pView )
	{
		CClientDC dc( m_pView );
		m_pView->OnPrepareDC(&dc);
		dc.DPtoLP( pRect );
	}
}

void CTracker::LPToDP( CRect* pRect )
{
	if ( m_pView )
	{
		CClientDC dc( m_pView );
		m_pView->OnPrepareDC(&dc);
		dc.LPtoDP( pRect );
	}
}



/////////////////////////////////////////////////////////////////////////////
// CEditorView
/////////////////////////////////////////////////////////////////////////////


IMPLEMENT_DYNCREATE(CEditorView, CScrollView)

BEGIN_MESSAGE_MAP(CEditorView, CScrollView)
	//{{AFX_MSG_MAP(CEditorView)
	ON_WM_CONTEXTMENU()
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_KEYDOWN()
	ON_WM_SETCURSOR()
	ON_WM_SIZE()
	ON_WM_LBUTTONDBLCLK()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditorView construction/destruction

CEditorView::CEditorView()
{
	m_pMainWnd = ( CMainFrame* ) AfxGetMainWnd();
	m_PopupMenu.LoadMenu( IDR_POPUP );

	m_DropCursor = NULL;
	m_NoDropCursor = CABCObject::GetNoDropCursor();

    m_IsCaptured = FALSE;
	m_IDButton = NULL;
	m_ObjectType = CABCObject::ABCObject_Null;

	m_ShadowSize.cx = 5; 
	m_ShadowSize.cy = 5; 

	m_pTracker = new CTracker( this, m_pMainWnd );
	SetTracker( NULL );;
}

CEditorView::~CEditorView()
{
	delete m_pTracker;

	m_PopupMenu.DestroyMenu();
}

/////////////////////////////////////////////////////////////////////////////
// CEditorView diagnostics

#ifdef _DEBUG
void CEditorView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CEditorView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CEditorDoc* CEditorView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CEditorDoc)));
	return (CEditorDoc*)m_pDocument;
}
#endif //_DEBUG


BOOL CEditorView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	dwStyle |= WS_HSCROLL | WS_VSCROLL;
	if ( CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext) )
	{
		GetDocument()->m_pView = this;
		return TRUE;
	}

	return FALSE;
}


void CEditorView::Capture( BOOL bCapture )
{
	CMainFrame* pWnd = (CMainFrame*)AfxGetMainWnd();

	if ( bCapture )
	{
		SetCapture();
		m_IsCaptured = TRUE;
		pWnd->CheckObjectButton( m_IDButton );
		m_DropCursor = CABCObject::GetObjectCursor( m_ObjectType );
	}
	else
	{
		if (m_IsCaptured)
		{
	        ::ReleaseCapture();
		    m_IsCaptured = FALSE;
		}
		pWnd->CheckObjectButton( m_IDButton, FALSE );
		m_IDButton = NULL;
		m_ObjectType = CABCObject::ABCObject_Null;
	}
}

CRect CEditorView::GetTrackerRect()
{
	CRect rectTracker;
	m_pTracker->GetTrueRect(rectTracker);
	return rectTracker;
}

int CEditorView::GetTrackObjectType()
{
	if ( m_pTrackObject )
	{
		return m_pTrackObject->GetType();
	}

	return CABCObject::ABCObject_Null;
}

BOOL CEditorView::IsPointInShadow( CPoint point )
{
	point.x += GetScrollPos( SB_HORZ );
	point.y += GetScrollPos( SB_VERT );

	CSize sizeTotal = GetTotalSize();
	CRect shadowRectO( 0, 0, sizeTotal.cx, sizeTotal.cy );
	CRect shadowRectI = shadowRectO;

	shadowRectI.InflateRect( -m_ShadowSize.cx, -m_ShadowSize.cy );

	return ( shadowRectO.PtInRect( point ) && !shadowRectI.PtInRect( point ) );
}

BOOL CEditorView::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	switch( wParam )
	{
		case ID_ADD_TEXTEDIT:
		case ID_ADD_BUTTON:
		case ID_ADD_LABEL:
			m_IDButton = wParam;
			CPoint* pPoint = (CPoint*) lParam;

			pPoint->x += GetScrollPos( SB_HORZ );
			pPoint->y += GetScrollPos( SB_VERT );

			GetDocument()->AddObject( CABCObject::GetTypeByID( m_IDButton ), *pPoint );
			return TRUE;
		break;
	}

	return CScrollView::OnCommand(wParam, lParam);
}


void CEditorView::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	CMenu* pPopupMenu = m_PopupMenu.GetSubMenu( 0 );
	pPopupMenu->TrackPopupMenu( TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, pWnd );
}


void CEditorView::OnDraw(CDC* pDC)
{

	CBrush* pOldBrush = pDC->GetCurrentBrush();

	CBrush brushShadow( GetSysColor( COLOR_3DSHADOW ) );

	CSize sizeTotal = GetTotalSize();

	CRect shadowRect( 0, 0, sizeTotal.cx, sizeTotal.cy );

	CRgn shadowRgn;
	shadowRgn.CreateRectRgnIndirect( shadowRect );
	
	pDC->FrameRgn( &shadowRgn, &brushShadow, m_ShadowSize.cx, m_ShadowSize.cy );

	pDC->SelectObject( pOldBrush );

	for( int i = 0; i < GetDocument()->m_ObjectsPtr.GetSize(); i++ )
	{
		CABCObject* pObject = (CABCObject*) GetDocument()->m_ObjectsPtr.GetAt( i );
		pObject->Draw( pDC );
	}

	SetTracker( m_pTrackObject );

    pDC->LPtoDP( m_pTracker->m_rect );
	m_pTracker->Draw(pDC);

}

void CEditorView::OnInitialUpdate() 
{
	CScrollView::OnInitialUpdate();
	SetScroll();
}

void CEditorView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	Capture( FALSE );
	CScrollView::OnKeyDown( nChar, nRepCnt, nFlags );

	switch (nChar)
	{
		case VK_HOME:
			OnVScroll(SB_TOP, 0, NULL);
			OnHScroll(SB_LEFT, 0, NULL);
        break;
	    case VK_END:
		    OnVScroll(SB_BOTTOM, 0, NULL);
			OnHScroll(SB_RIGHT, 0, NULL);
	        break;
		case VK_UP:
			OnVScroll(SB_LINEUP, 0, NULL);
	        break;
		case VK_DOWN:
			OnVScroll(SB_LINEDOWN, 0, NULL);
        break;
	    case VK_PRIOR:
		    OnVScroll(SB_PAGEUP, 0, NULL);
			break;
	    case VK_NEXT:
		    OnVScroll(SB_PAGEDOWN, 0, NULL);
			break;
	    case VK_LEFT:
		    OnHScroll(SB_LINELEFT, 0, NULL);
			break;
	    case VK_RIGHT:
		    OnHScroll(SB_LINERIGHT, 0, NULL);
			break;
	    default:
		    break;
    }
}

void CEditorView::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	CScrollView::OnLButtonDblClk(nFlags, point);
	GetDocument()->OnPropertyObject();
}

void CEditorView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CPoint spoint = point;

	spoint.x += GetScrollPos( SB_HORZ );
	spoint.y += GetScrollPos( SB_VERT );

	if ( m_IsCaptured )
	{
		int type = m_ObjectType;

		Capture( FALSE );

		CRect rect;
		GetClientRect( &rect );
		if ( rect.PtInRect( point ) && !IsPointInShadow( point ) )
		{
			GetDocument()->AddObject( type, spoint );
		}
	}
	else
	{
		CRect rectSave;
		m_pTracker->GetTrueRect(rectSave);

		CEditorDoc* pDoc = GetDocument();

		CABCObject* pObject = pDoc->GetObjectByPoint( spoint );

		if ( pObject && pObject != m_pTrackObject )
		{
			SetTracker( pObject );
			pDoc->UpdateAllViews(NULL, (LPARAM)(LPCRECT)rectSave);
		}
		else
		{
			if ( m_pTrackObject )
			{
				int hit = m_pTracker->HitTest( point );

		        if( m_pTracker->Track( this, point ))
				{
					CRect rectTracker = m_pTracker->m_rect;
					m_pTracker->DPToLP( &rectTracker );

					if ( hit != CRectTracker::hitMiddle )
					{
						rectTracker.left = __max( rectTracker.left, m_ShadowSize.cx );
						rectTracker.top = __max( rectTracker.top, m_ShadowSize.cy );
					}
					else
					{
						if ( rectTracker.left < m_ShadowSize.cx )
						{
							rectTracker.OffsetRect( m_ShadowSize.cx - rectTracker.left, 0 );
						}
						if ( rectTracker.top < m_ShadowSize.cy )
						{
							rectTracker.OffsetRect( 0, m_ShadowSize.cy - rectTracker.top );
						}
					}

					if( !CABCObject::IsObjectIntersect(  &pDoc->m_ObjectsPtr, rectTracker, m_pTrackObject ) )
					{
						m_pTrackObject->SetRect( rectTracker );
						SetScroll();
					}
					else
					{
						SetTracker( m_pTrackObject );
					}
					pDoc->SetModifiedFlag();
					pDoc->UpdateAllViews(NULL, (LPARAM)(LPCRECT)rectSave);
				}
			}
        }
    }

	CScrollView::OnLButtonDown(nFlags, point);
}

void CEditorView::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (m_IsCaptured)
	{
		CRect rect;
		GetClientRect( &rect );
		if ( rect.PtInRect( point ) && !IsPointInShadow( point ) )
		{
			::SetCursor( m_DropCursor );
		}
		else
		{
			::SetCursor( m_NoDropCursor );
		}
	}
	
	CScrollView::OnMouseMove(nFlags, point);
}

void CEditorView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	Capture( FALSE );

	CScrollView::OnRButtonDown(nFlags, point);
}

BOOL CEditorView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	if ( m_pTracker->SetCursor( pWnd, nHitTest ) )
	{
		return TRUE;
	}

	return CScrollView::OnSetCursor(pWnd, nHitTest, message);
}

void CEditorView::OnSize(UINT nType, int cx, int cy) 
{
	SetScroll();
	CScrollView::OnSize(nType, cx, cy);
}

void CEditorView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	CScrollView::OnUpdate( pSender, lHint, pHint );
	SetScroll();
}

BOOL CEditorView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CScrollView::PreCreateWindow(cs);
}

void CEditorView::SetScroll()
{
	CRect rect;
	GetClientRect( &rect );

	CSize sizeTotal = GetTotalSize();

	sizeTotal.cx = __max( sizeTotal.cx, rect.Width() + m_ShadowSize.cx );
	sizeTotal.cy = __max( sizeTotal.cy, rect.Height() + m_ShadowSize.cy );

	CSize sizeObjects( 0, 0 );

	for( int i = 0; i < GetDocument()->m_ObjectsPtr.GetSize(); i++ )
	{
		CABCObject* pObject = (CABCObject*) GetDocument()->m_ObjectsPtr.GetAt( i );
		CRect rect = pObject->GetRect();

		rect.OffsetRect( m_ShadowSize.cx, m_ShadowSize.cy );

		sizeObjects.cx = __max( sizeObjects.cx, rect.right );
		sizeObjects.cy = __max( sizeObjects.cy, rect.bottom );
	}

	sizeTotal.cx = __max( sizeTotal.cx, sizeObjects.cx );
	sizeTotal.cy = __max( sizeTotal.cy, sizeObjects.cy );

	SetScrollSizes( MM_TEXT, sizeTotal);
}

void CEditorView::ShowStatusBarText( int mode )
{
	CString posStr = "";
	CString dimStr = "";
	CPoint point;

	switch( mode )
	{
		case ShowStatusBar_Object:
			if ( m_pTrackObject &&  m_pTrackObject )
			{
				CRect rect = m_pTrackObject->GetRect();
				rect.OffsetRect( -m_ShadowSize.cx, -m_ShadowSize.cy );

				posStr.Format( posStrFormat, rect.left, rect.top );
				dimStr.Format( dimStrFormat, rect.Width(), rect.Height() );
			}
		break;

		case ShowStatusBar_Capture:
			if ( ::GetCursorPos( &point ) )
			{
				CRect rect;
				GetClientRect( &rect );
				ScreenToClient( &point );
				if ( rect.PtInRect( point ) && !IsPointInShadow( point ) )
				{
					point.Offset( GetScrollPos( SB_HORZ ) - m_ShadowSize.cx, GetScrollPos( SB_VERT ) - m_ShadowSize.cy );
					posStr.Format( posStrFormat, point.x, point.y );
				}
			}
		break;
	}

	m_pMainWnd->SetStatusBarText( posStr, dimStr );
}

void CEditorView::SetTracker( CABCObject* pObject )
{
	m_pTrackObject = pObject;

	if ( m_pTrackObject )
	{
		m_pTracker->m_rect = m_pTrackObject->GetRect();
		m_pTracker->m_nStyle = CRectTracker::resizeOutside  | CRectTracker::hatchedBorder;
	}
	else
	{
		m_pTracker->m_rect.SetRectEmpty();
		m_pTracker->m_nStyle = NULL;
	}
}


