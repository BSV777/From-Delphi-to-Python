/////////////////////////////////////////////////////////////////////////////
// Button.h : header file
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_BUTTON_H__93DA4E11_3687_11D6_84A2_0001031609FA__INCLUDED_)
#define AFX_BUTTON_H__93DA4E11_3687_11D6_84A2_0001031609FA__INCLUDED_

#include "ABCObject.h"


/////////////////////////////////////////////////////////////////////////////
// CABCButton
/////////////////////////////////////////////////////////////////////////////

class CABCButton : public CABCObject
{

public:
	CABCButton() : CABCObject( ABCObject_Button ) {	m_Rect = CRect( CPoint( 0, 0 ), GetDefaultSize() );};
	CABCButton( CPoint point ) : CABCObject( ABCObject_Button, point ) { m_Rect = CRect( point, GetDefaultSize() );};
	~CABCButton() {};

	virtual CSize GetDefaultSize() { return CSize( 80, 28 ); }; 
	virtual void Draw(CDC* pDC);
	virtual CString GetObjectString();
	virtual CString GetObjectHTMLString();
	virtual int SetProperty( CString propName, CString propValue);
};

#endif // !defined(AFX_BUTTON_H__93DA4E11_3687_11D6_84A2_0001031609FA__INCLUDED_)
