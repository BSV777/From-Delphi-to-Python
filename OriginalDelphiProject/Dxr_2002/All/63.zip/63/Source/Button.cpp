/////////////////////////////////////////////////////////////////////////////
// Button.cpp : implementation file
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Button.h"

/////////////////////////////////////////////////////////////////////////////
// CABCButton
/////////////////////////////////////////////////////////////////////////////

void CABCButton::Draw(CDC* pDC)
{
	LOGFONT lf;
	memset(&lf, 0, sizeof(LOGFONT));
	lf.lfHeight = 8;
	strcpy(lf.lfFaceName, "MS Sans Serif");
	CFont textFont;
	textFont.CreatePointFontIndirect( &lf, pDC );
	CFont* oldFont = pDC->GetCurrentFont();
	pDC->SelectObject( &textFont );

	CRect rect = GetRect();
	DWORD buttonColor = GetSysColor( COLOR_3DLIGHT);

	CPen* pOldPen = pDC->GetCurrentPen();
	CBrush* pOldBrush = pDC->GetCurrentBrush();

	CPen penBlack( PS_SOLID, 1, RGB(0, 0, 0) );

	CBrush brushButton( buttonColor );

	pDC->FillRect( rect, &brushButton );

	pDC->SelectObject(&penBlack); 
	pDC->MoveTo( rect.left, rect.bottom );
	pDC->LineTo( rect.right, rect.bottom );
	pDC->LineTo( rect.right, rect.top );
	pDC->LineTo( rect.right - 1, rect.top );
	pDC->LineTo( rect.right - 1, rect.bottom - 1 );
	pDC->LineTo( rect.left, rect.bottom - 1 );

	CRect textRect = GetRect();
	textRect.InflateRect( -2, -2 );

	pDC->SetBkColor( buttonColor );

	pDC->DrawText( m_Text, &textRect, DT_SINGLELINE | DT_CENTER | DT_VCENTER );

	pDC->SelectObject( pOldPen );
	pDC->SelectObject( pOldBrush );
	pDC->SelectObject( oldFont );
}

CString CABCButton::GetObjectHTMLString()
{
	CString htmlStr;

	CString textStr = m_Text;
	textStr.Replace( "\"", "&quot;" );

	CRect textRect = GetRect();
//	textRect.InflateRect( -3, -3 );

	htmlStr.Format( "<INPUT type=button value=\"%s\" style=\"WIDTH:%upx; HEIGHT:%upx;\">", textStr, textRect.Width(), textRect.Height() );

	return htmlStr;

}

CString CABCButton::GetObjectString()
{
	CString propStr;

	CString textStr = m_Text;
	// ������ ������� �������� ���������
	textStr.Replace( "\"", "\"\"" );

	propStr.Format("<%s %s=\"%d\"; %s=\"%d\"; %s=\"%d\"; %s=\"%d\"; %s=\"%s\">",
				    GetObjectName(),
					ABCProperty_Left, m_Rect.left,
					ABCProperty_Top, m_Rect.top,
					ABCProperty_Width, m_Rect.Width(),
					ABCProperty_Height, m_Rect.Height(),
					ABCProperty_Caption, textStr );

	return propStr;
}

int CABCButton::SetProperty( CString propName, CString propValue)
{
	propName.MakeLower();
	int nValue = atoi( propValue);

	if ( propName == ABCProperty_Caption )
	{
		m_Text = propValue;
		return ABCOSetProperty_Ok;
	}

	if ( propName == ABCProperty_Height )
	{
		if ( nValue )
		{
			m_Rect.bottom = m_Rect.top + nValue;
			return ABCOSetProperty_Ok;
		}
		else
		{
			return ABCOSetProperty_InvalidValue;
		}
	}

	return CABCObject::SetProperty( propName, propValue);
}


