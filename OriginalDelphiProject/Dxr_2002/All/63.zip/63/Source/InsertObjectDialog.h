/////////////////////////////////////////////////////////////////////////////
// InsertObjectDialog.h : header file
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_INSERTOBJECTDIALOG_H__F65794B6_34CC_11D6_84A0_0001031609FA__INCLUDED_)
#define AFX_INSERTOBJECTDIALOG_H__F65794B6_34CC_11D6_84A0_0001031609FA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CInsertObjectDialog dialog
/////////////////////////////////////////////////////////////////////////////

class CInsertObjectDialog : public CDialog
{
// Construction
public:
	CInsertObjectDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CInsertObjectDialog)
	enum { IDD = IDD_ADD_OBJECT };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


	int m_Type;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInsertObjectDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CInsertObjectDialog)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INSERTOBJECTDIALOG_H__F65794B6_34CC_11D6_84A0_0001031609FA__INCLUDED_)
