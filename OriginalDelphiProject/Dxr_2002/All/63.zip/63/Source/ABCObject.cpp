/////////////////////////////////////////////////////////////////////////////
// ABCObject.cpp : implementation file
/////////////////////////////////////////////////////////////////////////////

#include <stdlib.h>

#include "stdafx.h"
#include "Editor.h"

#include "ABCObject.h"
#include "Button.h"
#include "Label.h"
#include "TextEdit.h"

HCURSOR ABC_NoDropCursor = NULL;

HCURSOR ABC_TextEditCursor = NULL;
HCURSOR ABC_ButtonCursor = NULL;
HCURSOR ABC_LabelCursor = NULL;

CMapWordToPtr ABCObjectMap;
CMapStringToPtr ABCObjectMapByName;

/////////////////////////////////////////////////////////////////////////////
// CABCObject
/////////////////////////////////////////////////////////////////////////////

CABCObject::CABCObject( int type, CPoint point )
{
	m_Type = type;
	m_Rect = CRect( point, GetDefaultSize() );
	m_Text = "";
}

CABCObject::~CABCObject()
{
}

void CABCObject::ABCInit()
{
	LoadCursors();

// ��������� Map 
	ABCObjectStruct* pObject = NULL;
	CString m_ObjectName;

// TextEdit
	pObject = new ABCObjectStruct;
	pObject->m_Name = "TextEdit";
	pObject->m_Type = ABCObject_TextEdit;
	pObject->m_Cursor = ABC_TextEditCursor;
	ABCObjectMap.SetAt( ABCObject_TextEdit, pObject );

	m_ObjectName = pObject->m_Name;
	m_ObjectName.MakeLower();
	ABCObjectMapByName.SetAt( m_ObjectName, pObject );

// Button
	pObject = new ABCObjectStruct;
	pObject->m_Name = "Button";
	pObject->m_Type = ABCObject_Button;
	pObject->m_Cursor = ABC_ButtonCursor;
	ABCObjectMap.SetAt( ABCObject_Button, pObject );

	m_ObjectName = pObject->m_Name;
	m_ObjectName.MakeLower();
	ABCObjectMapByName.SetAt( m_ObjectName, pObject );

// Label
	pObject = new ABCObjectStruct;
	pObject->m_Name = "Label";
	pObject->m_Type = ABCObject_Label;
	pObject->m_Cursor = ABC_LabelCursor;
	ABCObjectMap.SetAt( ABCObject_Label, pObject );

	m_ObjectName = pObject->m_Name;
	m_ObjectName.MakeLower();
	ABCObjectMapByName.SetAt( m_ObjectName, pObject );
}

void CABCObject::ABCExit()
{
	// �������� Map
	if( !ABCObjectMap.IsEmpty() )
	{
		POSITION pos = ABCObjectMap.GetStartPosition();

		WORD keyValue = NULL;
		void* pValue = NULL;
		ABCObjectStruct* pObject = NULL;

		while( pos != NULL )
		{
			ABCObjectMap.GetNextAssoc( pos, keyValue, pValue );
			pObject = (ABCObjectStruct*) pValue;
			delete pObject;
		}
	}
	ABCObjectMap.RemoveAll();
	ABCObjectMapByName.RemoveAll();
}

CABCObject* CABCObject::CreateObject( int type, CPoint point )
{
	CABCObject* pObject = NULL;

	switch( type )
	{
		case ABCObject_TextEdit:
			pObject = new CABCTextEdit( point );
		break;
		case ABCObject_Button:
			pObject = new CABCButton( point );
		break;
		case ABCObject_Label:
			pObject = new CABCLabel( point );
		break;
	}

	return pObject;
}

void CABCObject::DestroyObject( CABCObject* pObject )
{
	switch( pObject->GetType() )
	{
		case ABCObject_TextEdit:
			delete (CABCTextEdit*)pObject;
		break;
		case ABCObject_Button:
			delete (CABCButton*)pObject;
		break;
		case ABCObject_Label:
			delete (CABCLabel*)pObject;
		break;
	}
}

HCURSOR CABCObject::GetNoDropCursor()
{
	return ABC_NoDropCursor;
}

HCURSOR CABCObject::GetObjectCursor( int type )
{
	void* pValue = NULL;
	if ( ABCObjectMap.Lookup( type, pValue ) )
	{
		return ((ABCObjectStruct*)(pValue))->m_Cursor;
	}

	return NULL;
}

CString CABCObject::GetObjectName( int type )
{
	void* pValue = NULL;
	if ( ABCObjectMap.Lookup( type, pValue ) )
	{
		return ((ABCObjectStruct*)(pValue))->m_Name;
	}

	return "";
}

CRect CABCObject::GetObjectsRect( CPtrArray* pObjectsPtr )
{
	CRect objectsRect(0,0,0,0);

	for( int i = 0; i < pObjectsPtr->GetSize(); i++ )
	{
		CABCObject* pObject = (CABCObject*) pObjectsPtr->GetAt( i );
		CRect rect = pObject->GetRect();
		objectsRect.left = __min( objectsRect.left, rect.left );
		objectsRect.top = __min( objectsRect.top, rect.top );
		objectsRect.right = __max( objectsRect.right, rect.right );
		objectsRect.bottom = __max( objectsRect.bottom, rect.bottom );
	}

	return objectsRect;
}

int CABCObject::GetObjectType( CString name )
{
	void* pValue = NULL;
	if ( ABCObjectMapByName.Lookup( name, pValue ) )
	{
		return ((ABCObjectStruct*)(pValue))->m_Type;
	}

	return ABCObject_Null;
}

int CABCObject::GetTypeByID( UINT nID )
{
	switch( nID )
	{
		case ID_ADD_TEXTEDIT:
			return ABCObject_TextEdit;
		break;
		case ID_ADD_BUTTON:
			return ABCObject_Button;
		break;
		case ID_ADD_LABEL:
			return ABCObject_Label;
		break;
	}

	return ABCObject_Null;
}

BOOL CABCObject::IsObjectIntersect( CPtrArray* pObjectsPtr, CRect rect, CABCObject* pExludeObject )
{
	for( int i = 0; i < pObjectsPtr->GetSize(); i++ )
	{
		CABCObject* pObject = (CABCObject*) pObjectsPtr->GetAt( i );

		if ( pExludeObject )
		{
			if ( pExludeObject == pObject )
			{
				continue;
			}
		}

		CRect rectInter;
		if ( rectInter.IntersectRect( rect, pObject->GetRect() ) )
		{
			return TRUE;
		}
	}

	return FALSE;
}

void CABCObject::LoadCursors()
{
	if ( !ABC_NoDropCursor )
		ABC_NoDropCursor = ::LoadCursor( AfxGetApp()->m_hInstance, MAKEINTRESOURCE( IDC_NODROP ));
	
	if( !ABC_TextEditCursor )
		ABC_TextEditCursor = ::LoadCursor( AfxGetApp()->m_hInstance, MAKEINTRESOURCE( IDC_DROP_TEXTEDIT ));

	if( !ABC_ButtonCursor )
		ABC_ButtonCursor = ::LoadCursor( AfxGetApp()->m_hInstance, MAKEINTRESOURCE( IDC_DROP_BUTTON ));

	if( !ABC_LabelCursor )
		ABC_LabelCursor = ::LoadCursor( AfxGetApp()->m_hInstance, MAKEINTRESOURCE( IDC_DROP_LABEL ));
}

void CABCObject::NormalizeObjectsRects( CPtrArray* pObjectsPtr )
{
	for( int i = 0; i < pObjectsPtr->GetSize(); i++ )
	{
		CABCObject* pObject = (CABCObject*) pObjectsPtr->GetAt( i );
		CRect rect = pObject->GetRect();
		rect.NormalizeRect();
		pObject->SetRect( rect );
	}
}

void CABCObject::OffsetObjectsRects( CPtrArray* pObjectsPtr, int x, int y )
{
	for( int i = 0; i < pObjectsPtr->GetSize(); i++ )
	{
		CABCObject* pObject = (CABCObject*) pObjectsPtr->GetAt( i );
		CRect rect = pObject->GetRect();
		rect.OffsetRect( x, y );
		pObject->SetRect( rect );
	}
}

int CABCObject::SetProperty( CString propName, CString propValue)
{
	propName.MakeLower();
	int nValue = atoi( propValue);

	if ( propName == ABCProperty_Left )
	{
		m_Rect.OffsetRect( -m_Rect.left, 0 );
		m_Rect.OffsetRect( nValue, 0 );
		return ABCOSetProperty_Ok;
	}

	if ( propName == ABCProperty_Top )
	{
		m_Rect.OffsetRect( 0, -m_Rect.top );
		m_Rect.OffsetRect( 0, nValue );
		return ABCOSetProperty_Ok;
	}

	if ( propName == ABCProperty_Width )
	{
		if ( nValue )
		{
			m_Rect.right = m_Rect.left + nValue;
			return ABCOSetProperty_Ok;
		}
		else
		{
			return ABCOSetProperty_InvalidValue;
		}
	}

	return ABCOSetProperty_InvalidName;
}



