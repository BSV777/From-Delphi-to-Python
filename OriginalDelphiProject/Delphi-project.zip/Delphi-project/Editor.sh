#!/bin/bash

LANG=ru_RU.utf8 wine Editor.exe
