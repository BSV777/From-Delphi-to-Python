<?php
echo strtoupper($_GET['input']);
?>
