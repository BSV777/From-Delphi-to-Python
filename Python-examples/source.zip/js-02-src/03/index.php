<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html>
<head>
	<title>AJAX</title>
	<script language="javascript" src="script.js"></script>
</head>
<body>
	<input id="inpText" />
	<button id="btnRun">����������� ������</button>
	<div id="divResult"></div>
</body>
</html>
