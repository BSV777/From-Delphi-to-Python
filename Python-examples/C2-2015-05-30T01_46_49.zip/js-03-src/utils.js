function changeBorder(elem)
{
	elem.css('border', '3px solid red');

}