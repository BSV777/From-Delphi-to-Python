<?php

	$tours = array(
				'france' => array('Париж', 'Марсель', 'Ницца'),
				'spain' => array('Мадрид', 'Барселона', 'Гранада'),
				'russia' => array('Колыма', 'Бобруйск', 'Оймякон')
			);
		
	$country = $_GET['country'];
	echo $_GET['jsoncallback']. '(' . json_encode($tours[$country]) . ')';
