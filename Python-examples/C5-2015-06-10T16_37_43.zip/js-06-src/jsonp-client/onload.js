$(document).ready(function(){

	$('#country').change(function(){
		var country = $(this).find('option:selected').val();
		$.getJSON("http://javascript/6/jsonp/index.php?jsoncallback=?", {country: country}, 
					print_tours); 
	});
	
	
	function print_tours(data){
		var res = $('#result');
		res.empty();
				
		if(data == null)
			return;
		
		for(var i = 0; i < data.length; i++)
			res.append('<div>' + data[i] + '</div>');
	}
});