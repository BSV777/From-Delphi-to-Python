$(document).ready(function(){

	$('#country').change(function(){
		var country = $(this).find('option:selected').val();
		$.getJSON("http://javascript/6/jsonp/index.php?jsoncallback=?", {country: country}, 
					print_tours); 
	});
	
	
	function print_tours(data){
		var res = $('#towns');
		res.children().filter(':gt(0)').remove();
		
		for(var i = 0; i < data.length; i++){
			var option = document.createElement('option');
			option.value = data[i];
			option.innerHTML = data[i];
			res.append(option);
		}
	}
});