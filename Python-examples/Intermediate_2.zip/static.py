class someClass(object):
    staticValue = 123
    
    @staticmethod
    def someMethod():
        pass

someClass.someMethod()
v = someClass.someMethod()
x = someClass.staticValue


