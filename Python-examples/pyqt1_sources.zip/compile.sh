#!/bin/sh
eval "python /usr/lib/pymodules/python2.6/PyQt4/uic/pyuic.py window.ui > window.py"

